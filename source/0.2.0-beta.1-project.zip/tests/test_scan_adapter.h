// SPDX-License-Identifier: GPL-3.0-or-later
// Included by the actual live adapter harness. These tests exercise the real
// channel store, scan controller, metadata gate, UI and receive ownership.
static const uint16_t scan_test_groups[]={1,10,100,1000};
static normal_model scan_test_start(unsigned count,bool mixed) {
    normal_model model=normal_boot(false,false);
    feature_pause();
    for(unsigned i=0;i<count;++i) {
        uint8_t record[32];memcpy(record,channel_record,32);
        pref_put(record,440075000u+(mixed && i>=2 ? 1000000u : 0u));
        pref_put(record+4,442075000u+i*1000000u);
        feature_put16(record+8,0x293);feature_put16(record+10,scan_test_groups[i]);
        record[12]=P25_CS_OCCUPIED|(2u<<2);record[13]=0;
        memset(record+14,0,12);snprintf((char *)record+14,12,"Group %u",scan_test_groups[i]);
        assert(radio_functions_set_power(record,i+1u));
        assert(p25_cs_record_valid(i,record) && feature_commit(i,record,false));
    }
    const unsigned slots[]={0,1,2,3};adapter_scan_channels(slots,count,1,0);
    assert(feature_scan_start());normal_step(&model,false);
    assert(channel_scan.running && channel_scan.cursor==0 && mon_running && frequency==440075000u);
    assert(rx_tg_filter && !rx_promiscuous && control.talkgroup==1);
    assert(!feature_scan_received_slot());
    mock_decode_value=1234;return model;
}
static void scan_test_receive(unsigned index) {
    p25_channel_frames frames;assert(p25_channel_build(&frames,0x293,scan_test_groups[index],42));
    p25_rx unit={0};receive_unit(&unit,0x293,0,frames.hdu);receive_unit(&unit,0x293,5,frames.ldu1);
}
static void test_scan_logical_groups(void) {
    for(unsigned member=0;member<4;++member) {
        (void)scan_test_start(4,false);
        unsigned reads=pref_flash_reads,writes=pref_flash_writes,erases=pref_flash_erases;
        pref_flash_forbidden=true;
        for(unsigned i=0;i<4;++i)assert(feature_scan_group_allows(scan_test_groups[i]));
        assert(!feature_scan_group_allows(0) && !feature_scan_group_allows(123));
        scan_test_receive(member);
        assert(decode_calls==9 && monitor.voices==9 && !monitor.rejected && !mon_failed);
        assert(feature_scan_received_slot()==member+1u && channel_scan.cursor==0);
        assert(control.talkgroup==1 && control.tx_frequency==442075000u);
        assert(!ui_view(0).rx_muted && ui_view(0).channel_number==member+1u);
        feature_scan_poll();assert(channel_scan.holding);
        assert(pref_flash_reads==reads && pref_flash_writes==writes && pref_flash_erases==erases);
        pref_flash_forbidden=false;reset();
    }
    // The cache is also used by the explicit identity hooks: no external flash
    // access is permitted in the synchronous demodulation/decode path.
    (void)scan_test_start(4,false);pref_flash_forbidden=true;
    feature_scan_match_group(1000);assert(feature_scan_received_slot()==4);
    feature_scan_match_group(123);assert(!feature_scan_group_allows(123));
    pref_flash_forbidden=false;reset();
}
static void test_scan_continuous_receiver(void) {
    const unsigned counts[]={1,4};
    for(unsigned c=0;c<sizeof counts/sizeof *counts;++c) {
        normal_model model=scan_test_start(counts[c],false);
        unsigned setups=fm_recorder_calls,inits=codec_inits;
        monitor.units=37;
        for(unsigned elapsed=0;elapsed<8;++elapsed) {
            now+=1100000u;monitor.last_raw_us=now;
            normal_step(&model,false);
            assert(channel_scan.running && channel_scan.cursor==0 && mon_running);
            assert(fm_recorder_calls==setups && codec_inits==inits && monitor.units==37);
            assert(frequency==440075000u && !rf_keys && !pa_keys);
        }
        // Calls for the last logical entry are still accepted after repeated
        // old one-second dwell boundaries, without restarting acquisition.
        scan_test_receive(counts[c]-1u);
        assert(decode_calls==9 && feature_scan_received_slot()==counts[c]);
        reset();
    }
}
static void test_scan_mute_boundaries(void) {
    for(unsigned condition=0;condition<5;++condition) {
        (void)scan_test_start(4,false);p25_rx unit={0};p25_channel_frames foreign;
        assert(p25_channel_build(&foreign,0x293,123,42));
        uint8_t invalid[216];memset(invalid,0x55,sizeof invalid);
        const uint8_t *header=condition==0 ? foreign.hdu : condition==2 ? invalid
            : condition==3 ? call_vector_hdu_encrypted : condition==4 ? call_vector_hdu_vendor : call_vector_hdu_clear;
        const uint8_t *link=condition==0 ? foreign.ldu1 : condition==2 ? invalid
            : condition==4 ? call_vector_ldu1_vendor : call_vector_ldu1_group;
        uint16_t nac=condition==1 ? 0x2a3 : 0x293;
        pref_flash_forbidden=true;
        receive_unit(&unit,nac,0,header);receive_unit(&unit,nac,5,link);
        receive_no_output();assert(!feature_scan_received_slot());
        feature_scan_poll();assert(!channel_scan.holding);
        pref_flash_forbidden=false;reset();
    }
}
static void scan_test_assert_adopted(unsigned index,const uint8_t expected[32]) {
    assert(!channel_scan.running && feature_memory()==index+1u && feature_key()==index);
    assert(!memcmp(channel_record,expected,32));
    assert(control.talkgroup==scan_test_groups[index] && control.tx_frequency==442075000u+index*1000000u);
    assert(feature_tx_power()==index+1u && strstr(channel_label,(const char *)expected+14));
}
static void test_scan_received_channel_adoption(void) {
    (void)scan_test_start(4,false);uint8_t expected[32];
    assert(p25_cs_read(&channel_store,3,expected));scan_test_receive(3);
    assert(channel_scan.cursor==0 && control.talkgroup==1 && feature_tx_power()==1);
    feature_stop_scan(true);scan_test_assert_adopted(3,expected);
    reset();
    // A fresh PTT uses the received member's complete TX profile. This catches
    // adopting only a display channel number while retaining another split,
    // power selection or talkgroup from the group's acquisition entry.
    normal_model model=scan_test_start(4,false);
    assert(p25_cs_read(&channel_store,2,expected));scan_test_receive(2);
    normal_step(&model,true);scan_test_assert_adopted(2,expected);
    assert(call_active && control.tx_frequency==444075000u && feature_tx_power()==3);
    normal_step(&model,false);normal_step(&model,false);
    assert(!call_active && !rf_keys && !pa_keys);reset();
    // A failing matched-channel read must leave record/key/TX fields bound to
    // the valid acquisition entry. No partially adopted target is persisted.
    (void)scan_test_start(4,false);uint8_t prior[32];memcpy(prior,channel_record,32);
    scan_test_receive(3);unsigned writes=pref_flash_writes,failed=pref_flash_fail_hits;
    pref_flash_fail_addr=p25_cs_record_addr(&channel_store,channel_store.active_bank,3);
    pref_flash_fail_match=1;feature_stop_scan(true);pref_flash_fail_addr=0;
    assert(pref_flash_fail_hits==failed+1 && !pref_flash_fail_match && pref_flash_writes==writes);
    assert(!channel_scan.running && feature_memory()==1 && feature_key()==0);
    assert(!memcmp(channel_record,prior,32) && control.tx_frequency==442075000u && control.talkgroup==1);
    assert(feature_tx_power()==1 && !strcmp(reason,"channel_read_failed"));reset();
    model=scan_test_start(4,false);scan_test_receive(3);
    pref_flash_fail_addr=p25_cs_record_addr(&channel_store,channel_store.active_bank,3);
    pref_flash_fail_match=1;normal_step(&model,true);pref_flash_fail_addr=0;
    assert(!pref_flash_fail_match && !channel_scan.running && feature_memory()==1 && feature_key()==0);
    assert(!call_active && !prepared && !hardware_running && !callback && !rf_keys && !pa_keys);
    assert(control.state==RADIO_FAULT && control.inhibit && !control.tx_enabled);
    assert(!strcmp(reason,"channel_read_failed"));reset();
}
static void test_scan_unique_carriers(void) {
    normal_model model=scan_test_start(4,true);
    unsigned setups=fm_recorder_calls;
    assert(feature_scan_group_allows(1) && feature_scan_group_allows(10));
    assert(!feature_scan_group_allows(100) && !feature_scan_group_allows(1000));
    for(unsigned visit=0;visit<4;++visit) {
        now=channel_scan.due_us;monitor.last_raw_us=now;normal_step(&model,false);
        // Profile selection pauses first; the following task iteration opens
        // its receiver. Logical siblings never consume their own RF dwell.
        monitor.last_raw_us=now;normal_step(&model,false);
        bool other=(visit&1u)==0;
        assert(channel_scan.cursor==(other ? 2 : 0));
        assert(frequency==(other ? 441075000u : 440075000u) && mon_running);
        assert(fm_recorder_calls==++setups);
        assert(feature_scan_group_allows(other ? 1000 : 10));
        assert(!feature_scan_group_allows(other ? 10 : 1000));
    }
    reset();
    // Interleaved logical entries must not bias the cycle toward one carrier:
    // A / B / A / C is three RF visits, with both A destinations cached.
    model=scan_test_start(4,false);feature_stop_scan(false);feature_pause();
    const uint32_t frequencies[]={440075000u,441075000u,440075000u,442075000u};
    for(unsigned i=0;i<4;++i) {
        uint8_t record[32];assert(p25_cs_read(&channel_store,i,record));
        pref_put(record,frequencies[i]);assert(feature_commit(i,record,false));
    }
    assert(feature_scan_start());normal_step(&model,false);
    assert(feature_scan_group_allows(1) && feature_scan_group_allows(100));
    const unsigned visit_slots[]={1,3,0,1,3,0};setups=fm_recorder_calls;
    for(unsigned i=0;i<sizeof visit_slots/sizeof *visit_slots;++i) {
        now=channel_scan.due_us;monitor.last_raw_us=now;normal_step(&model,false);
        normal_step(&model,false);
        assert(channel_scan.cursor==visit_slots[i] && frequency==frequencies[visit_slots[i]] && mon_running);
        assert(fm_recorder_calls==++setups);
    }
    reset();
}
static void scan_test_partial(p25_rx *parser,const uint8_t *frame,unsigned first,unsigned last) {
    for(unsigned i=first;i<last;++i)assert(!p25_rx_push(parser,(frame[i/4]>>(6u-2u*(i%4u)))&3u));
}
static void test_scan_acquisition_boundary(void) {
    (void)scan_test_start(4,true);p25_channel_frames frames;
    assert(p25_channel_build(&frames,0x293,10,42));
    p25_rx *parser=&monitor.demod.lane[0].rx;
    uint32_t due=channel_scan.due_us;now=due-1000u;
    scan_test_partial(parser,frames.hdu,0,57);
    assert(parser->symbols==57 && parser->expected==396 && parser->nac==0x293);
    unsigned setups=fm_recorder_calls;
    pref_flash_forbidden=true;now=due;feature_scan_poll();
    assert(channel_scan.cursor==0 && mon_running && channel_scan.due_us==due+400000u);
    // Finish the actual framed header and first voice within the grace. The
    // first complete unit may arrive after nominal dwell, before any retune.
    now+=180000u;scan_test_partial(parser,frames.hdu,57,395);
    unsigned i=395;assert(p25_rx_push(parser,(frames.hdu[i/4]>>(6u-2u*(i%4u)))&3u));
    mon_receive(parser,NULL);p25_rx unit={0};receive_unit(&unit,0x293,5,frames.ldu1);feature_scan_poll();
    assert(channel_scan.cursor==0 && channel_scan.holding && feature_scan_received_slot()==2);
    assert(decode_calls==9 && monitor.voices==9 && fm_recorder_calls==setups);
    pref_flash_forbidden=false;reset();
    // Late entry can have a complete, allowed LDU1 but still need the next
    // LDU2's encryption-sync metadata before it is safe to play any voice.
    (void)scan_test_start(4,true);now=channel_scan.due_us-1000u;
    receive_unit(&unit,0x293,5,frames.ldu1);
    assert(monitor.call.state==P25_RX_WAIT_METADATA && monitor.call.group_valid && !decode_calls);
    due=channel_scan.due_us;now=due;feature_scan_poll();
    assert(channel_scan.cursor==0 && !channel_scan.holding && channel_scan.due_us==due+400000u);
    now+=180000u;receive_unit(&unit,0x293,10,frames.ldu2);feature_scan_poll();
    assert(channel_scan.cursor==0 && channel_scan.holding && feature_scan_received_slot()==2 && !decode_calls);
    receive_unit(&unit,0x293,5,frames.ldu1);assert(decode_calls==9);
    reset();
    // A never-completed NID-valid unit earns only one grace, not an unlimited
    // series of extensions that would starve other carrier groups.
    (void)scan_test_start(4,true);parser=&monitor.demod.lane[0].rx;
    scan_test_partial(parser,frames.ldu1,0,57);due=channel_scan.due_us;
    now=due;feature_scan_poll();assert(channel_scan.cursor==0 && channel_scan.due_us==due+400000u);
    now=channel_scan.due_us;feature_scan_poll();
    assert(channel_scan.cursor==2 && frequency==441075000u);reset();
    // A validated NID for another NAC never extends this carrier's dwell.
    (void)scan_test_start(4,true);assert(p25_channel_build(&frames,0x2a3,10,42));
    parser=&monitor.demod.lane[0].rx;scan_test_partial(parser,frames.ldu1,0,57);
    now=channel_scan.due_us;feature_scan_poll();
    assert(channel_scan.cursor==2 && frequency==441075000u);reset();
    // A complete, positively identified foreign TG cannot buy grace merely
    // because a matching NAC or an overlapping partial unit was observed.
    (void)scan_test_start(4,true);assert(p25_channel_build(&frames,0x293,123,42));
    receive_unit(&unit,0x293,0,frames.hdu);receive_unit(&unit,0x293,5,frames.ldu1);
    parser=&monitor.demod.lane[0].rx;scan_test_partial(parser,frames.ldu1,0,57);
    now=channel_scan.due_us;feature_scan_poll();
    assert(channel_scan.cursor==2 && frequency==441075000u);reset();
}
static void test_scan_receiver_ready_dwell(void) {
    normal_model model=scan_test_start(4,true);
    feature_pause();assert(!mon_running);
    now+=1500000u;feature_scan_poll();assert(channel_scan.cursor==0);
    // Time spent without a running receiver is never charged to acquisition.
    now+=2500000u;normal_step(&model,false);
    assert(mon_running && channel_scan.cursor==0 && channel_scan.due_us-now==999000u);
    now=channel_scan.due_us-1u;monitor.last_raw_us=now;normal_step(&model,false);
    assert(channel_scan.cursor==0);
    monitor.last_raw_us=now;normal_step(&model,false);
    assert(channel_scan.cursor==2 && frequency==441075000u);reset();
}
static void expanded_profile(unsigned slot,unsigned tg,bool prom,bool rx_only) {
    uint8_t record[32];memcpy(record,channel_record,32);
    pref_put(record,440075000u);pref_put(record+4,442075000u);
    feature_put16(record+8,0x293);feature_put16(record+10,tg);
    record[12]=(uint8_t)(P25_CS_OCCUPIED|(prom ? P25_CS_PROM : P25_CS_TG_FILTER)|(rx_only ? P25_CS_RX_ONLY : 0));
    record[13]=0;memset(record+14,0,12);snprintf((char *)record+14,12,"Channel %u",slot+1u);
    assert(feature_commit(slot,record,false));
    if(feature_key()==slot) {memcpy(channel_record,record,32);memcpy(channel_saved,record,32);feature_apply();}
}
static void expanded_tg_list(unsigned base,unsigned reply,unsigned fixed,unsigned count) {
    uint8_t descriptor[32]={0},record[32]={0};unsigned key=p25_cs_scan_key(15);
    memcpy(descriptor,"TG list 16",10);descriptor[12]=1;descriptor[13]=(uint8_t)reply;
    feature_put16(descriptor+14,base);feature_put16(descriptor+16,fixed);
    feature_put16(descriptor+18,250);feature_put16(descriptor+20,700);descriptor[22]=(uint8_t)count;
    assert(p25_cs_begin(&channel_store,channel_store.revision));
    assert(p25_cs_stage_write(&channel_store,key,descriptor) && p25_cs_stage_write(&channel_store,key+1u,record));
    for(unsigned part=0;part<4;++part) {
        memset(record,0,32);
        for(unsigned i=0;i<16 && part*16u+i<count;++i)feature_put16(record+2u*i,part*16u+i+1u);
        assert(p25_cs_stage_write(&channel_store,key+2u+part,record));
    }
    uint32_t crc;assert(p25_cs_stage_crc(&channel_store,&crc) && p25_cs_commit(&channel_store,crc));
    global_record[12]=15;feature_mirror_store();
}
static void expanded_receive(unsigned group) {
    p25_channel_frames frames;assert(p25_channel_build(&frames,0x293,group,42));
    p25_rx unit={0};receive_unit(&unit,0x293,0,frames.hdu);receive_unit(&unit,0x293,5,frames.ldu1);
}
static void test_expanded_channels_zones(void) {
    normal_model model=normal_boot(false,false);feature_pause();
    expanded_profile(0,1,false,false);expanded_profile(127,10,false,false);expanded_profile(255,1000,false,false);
    assert(feature_select_channel(256));normal_step(&model,false);
    assert(feature_memory()==256 && feature_key()==255 && global_record[10]==0 && global_record[24]==1);
    assert(ui_view(0).channel_number==256 && strstr(channel_label,"M256"));
    model=normal_power_reload();assert(feature_memory()==256 && feature_key()==255);
    turn_encoder(&model,1);assert(feature_memory()==1);
    turn_encoder(&model,1);assert(feature_memory()==128);
    turn_encoder(&model,1);assert(feature_memory()==256);
    feature_pause();uint8_t descriptor[32]={0},map[32]={0};memcpy(descriptor,"Zone sixteen",12);
    p25_cs_map_set(map,0,true);p25_cs_map_set(map,255,true);
    assert(p25_cs_begin(&channel_store,channel_store.revision));
    assert(p25_cs_stage_write(&channel_store,p25_cs_zone_key(15),descriptor));
    assert(p25_cs_stage_write(&channel_store,p25_cs_zone_key(15)+1u,map));
    global_record[26]=16;assert(p25_cs_stage_write(&channel_store,P25_CS_GLOBAL,global_record));
    uint32_t crc;assert(p25_cs_stage_crc(&channel_store,&crc) && p25_cs_commit(&channel_store,crc));
    model=normal_power_reload();assert(feature_zone()==16 && feature_memory()==256 && !strcmp(feature_zone_name,"Zone sixteen"));
    turn_encoder(&model,1);assert(feature_memory()==1);turn_encoder(&model,1);assert(feature_memory()==256);
    assert(!feature_select_channel(128) && feature_memory()==256);
    choose(MENU_MEMORY,5);home();normal_step(&model,false);assert(!feature_zone() && feature_memory()==256);
    feature_pause();pref_flash_fail_addr=p25_cs_record_addr(&channel_store,channel_store.active_bank,p25_cs_zone_key(15));
    pref_flash_fail_match=1;assert(!feature_zone_next());pref_flash_fail_addr=0;
    assert(!feature_zone() && feature_memory()==256 && !strcmp(feature_zone_name,"All channels"));
    assert(feature_zone_next() && feature_zone()==16 && feature_memory()==256);
    normal_step(&model,false);assert(!rf_keys && !pa_keys);reset();
}
static void test_independent_tg_scan(void) {
    normal_model model=normal_boot(false,false);feature_pause();expanded_profile(255,77,true,false);
    uint8_t original[32];assert(p25_cs_read(&channel_store,255,original));
    expanded_tg_list(256,1,0,64);assert(feature_scan_start());normal_step(&model,false);
    assert(channel_scan.running && feature_scan_tg() && channel_scan.cursor==255 && !rx_promiscuous && rx_tg_filter);
    assert(channel_scan.dwell_us==250000u && channel_scan.hold_us==700000u && feature_scan_group_size()==64);
    assert(feature_scan_group_allows(1) && feature_scan_group_allows(64) && !feature_scan_group_allows(77));
    unsigned reads=pref_flash_reads;pref_flash_forbidden=true;
    expanded_receive(64);assert(feature_scan_received_group()==64 && feature_scan_received_slot()==256 && !ui_view(0).rx_muted);
    for(unsigned i=0;i<8;++i) {now=channel_scan.due_us;monitor.last_raw_us=now;feature_scan_poll();}
    assert(mon_running && channel_scan.cursor==255 && pref_flash_reads==reads);
    pref_flash_forbidden=false;assert(feature_stop_scan(true));
    assert(feature_memory()==256 && control.talkgroup==64 && feature_temporary_tg && rx_promiscuous && !rx_tg_filter);
    feature_pause();preferences_poll(false);assert(!pref_dirty);
    uint8_t saved[32];assert(p25_cs_read(&channel_store,255,saved) && !memcmp(saved,original,32));
    model=normal_power_reload();assert(feature_memory()==256 && control.talkgroup==77 && !feature_temporary_tg && rx_promiscuous);
    assert(feature_scan_start());normal_step(&model,false);assert(!rx_promiscuous && rx_tg_filter);
    feature_stop_scan(false);assert(rx_promiscuous && !rx_tg_filter);
    assert(p25_cs_read(&channel_store,255,saved) && !memcmp(saved,original,32));reset();
}
static void test_scan_reply_policies(void) {
    normal_model model=normal_boot(false,false);feature_pause();
    expanded_profile(0,1,false,false);expanded_profile(255,77,true,false);
    // Channel-list Selected reply preserves the actual selected VFO rather
    // than replacing it with whichever list member was visited first.
    const unsigned slots[]={0,255};adapter_scan_channels(slots,2,0,0);
    unsigned selected=feature_key();uint8_t original[32];memcpy(original,channel_record,32);
    assert(feature_scan_start());normal_step(&model,false);expanded_receive(1);
    assert(feature_stop_scan(true) && feature_key()==selected && !feature_memory() && !memcmp(channel_record,original,32));
    feature_pause();expanded_tg_list(256,0,0,4);assert(feature_scan_start());normal_step(&model,false);expanded_receive(4);
    assert(feature_stop_scan(true) && feature_memory()==256 && control.talkgroup==77 && !feature_temporary_tg);
    feature_pause();expanded_tg_list(256,2,1,4);assert(feature_scan_start());normal_step(&model,false);expanded_receive(4);
    assert(feature_stop_scan(true) && feature_memory()==1 && control.talkgroup==1);
    // Fixed RX-only reply is never an RF grant, even after a valid receive.
    feature_pause();expanded_profile(0,1,false,true);expanded_tg_list(256,2,1,4);
    assert(feature_scan_start());normal_step(&model,false);expanded_receive(4);normal_step(&model,true);
    assert(!channel_scan.running && feature_memory()==1 && !call_active && !prepared && !rf_keys && !pa_keys && control.inhibit);
    normal_step(&model,false);reset();
    // RX-only listening can still use a separately permitted Fixed reply;
    // profile loading precedes the final normal permission decision.
    model=normal_boot(false,false);feature_pause();expanded_profile(0,1,false,false);expanded_profile(255,77,true,true);
    expanded_tg_list(256,2,1,4);assert(feature_scan_start());normal_step(&model,false);assert(control.inhibit);
    normal_step(&model,true);assert(!channel_scan.running && feature_memory()==1 && call_active);
    normal_step(&model,false);normal_step(&model,false);assert(!rf_keys && !pa_keys);reset();
    // An unreadable Fixed reply refuses the fresh edge; it cannot transmit
    // using the otherwise valid currently monitored base profile.
    model=normal_boot(false,false);feature_pause();expanded_profile(0,1,false,false);expanded_profile(255,77,true,false);
    expanded_tg_list(256,2,1,4);assert(feature_scan_start());normal_step(&model,false);
    pref_flash_fail_addr=p25_cs_record_addr(&channel_store,channel_store.active_bank,0);pref_flash_fail_match=1;
    normal_step(&model,true);pref_flash_fail_addr=0;
    assert(!pref_flash_fail_match && !channel_scan.running && feature_memory()==256 && control.state==RADIO_FAULT);
    assert(!call_active && !prepared && !callback && !rf_keys && !pa_keys && control.inhibit);
    reset();
    // Selected reply to an intentionally empty original VFO is refused too.
    model=normal_boot(false,false);feature_pause();expanded_profile(0,1,false,false);
    uint8_t empty[32]={0};assert(feature_commit(P25_CS_VFO_A,empty,false));
    const unsigned only[]={0};adapter_scan_channels(only,1,0,0);assert(feature_scan_start());normal_step(&model,false);
    normal_step(&model,true);
    assert(!channel_scan.running && control.state==RADIO_FAULT && !call_active && !prepared && !rf_keys && !pa_keys);
    reset();
}
static void test_scan_cached_hop_reads(void) {
    normal_model model=scan_test_start(4,true);
    unsigned reads=pref_flash_reads;now=channel_scan.due_us;monitor.last_raw_us=now;feature_scan_poll();
    assert(channel_scan.cursor==2 && pref_flash_reads==reads+1u);
    normal_step(&model,false);assert(mon_running);reads=pref_flash_reads;
    now=channel_scan.due_us;monitor.last_raw_us=now;feature_scan_poll();
    assert(channel_scan.cursor==0 && pref_flash_reads==reads+1u);
    reset();
}
