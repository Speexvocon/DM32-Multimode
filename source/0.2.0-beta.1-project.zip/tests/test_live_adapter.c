// SPDX-License-Identifier: GPL-3.0-or-later
// Actual adapter with PCM callbacks and modem IRQs preempting a timed encoder.
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
static volatile uint32_t mock_dac_power,mock_dac_drive;
static bool mock_pa_selected,mock_rf_selected,mock_dmr_keyed;
static unsigned dac_restores;
#define DAC_PD_CTRL mock_dac_power
#define DAC_B_OFF (1u<<1)
void hrc_dac_b_power(bool on);
static volatile unsigned char speaker_window[160];
#define P25_SPEAKER_PCM_WINDOW speaker_window
#include "../src/firmware/dm32_p25_live.c"
#include "radio_dmr_stub.h"
#include "p25_test_vectors.h"
#include "fixtures/p25_call_vectors.h"
#include "../src/firmware/p25_interleave.h"
#include "../external/RadioFoundry/RadioFoundry/drivers/input/sharedptt/shared_ptt.c"
static uint32_t now,next_pcm,next_rf,release_after,rf_at,hard_at,pa_at;
static uint32_t tuned_rx,tuned_tx;
static uint8_t tuned_power;
static radio_bw_t tuned_bw;
static radio_mode_t frontend_mode;
static unsigned fm_recorder_calls;
static uint32_t regs[512]; static uint8_t buf[16384], wire[40000];
// The real board writes this mask once in hrc7000_power_on_init(), before
// intercepted DMR board initialization. Safe stops subsequently clear it.
#define MOCK_NATIVE_SYS_MASK 0x1187fu
static bool mock_irq_enabled[64];
// Deliberately independent from the selected writer phase. The physical model
// latches a prefix, then reads the final 1..6 bytes after the next publication.
// One delayed byte reproduces the observed +36-byte endpoint substitution;
// this is a regression hypothesis, not a claim about the chip's exact prefetch.
static bool delayed_model,delayed_pending;
static unsigned delayed_phase,delayed_tail,delayed_blocks,delayed_n,delayed_half;
static uint8_t delayed_wire[40000];
static hrc7000_t modem={.regs=regs,.buf=buf};
static audio_block_cb_t callback;
static unsigned wire_n,source_n,rf_keys,pa_keys,loss,encode_cost,codec_inits,encode_calls;
static unsigned decode_calls;
static int16_t mock_decode_value;
static bool cal=true,tune=true,start_ok=true,missing_pcm,missing_rf;
static uint16_t battery=8000;
static unsigned battery_reads,signal_reads;
static int16_t signal_dbm=-73;
static uint8_t signal_noise=12;
static bool signal_tone_ok=true,analog_audio,key_backlight;
static bool mock_bcast_on,mock_bcast_audio,mock_bcast_hold,mock_bcast_available=true;
static bool mock_bcast_tune_ok=true,mock_bcast_seek_up;
static unsigned mock_bcast_power_ons,mock_bcast_power_offs,mock_bcast_tunes,mock_bcast_seeks,mock_bcast_polls;
static uint8_t mock_bcast_volume;
static bcast_status_t mock_bcast_status;
static uint8_t screen_backlight;
static bool scripted_scan;
static uint32_t scripted_keys;
static bool mock_ptt_high=true;
static unsigned applied_mic_gain;
void hrc7000_set_mic_gain(hrc7000_t *m,uint8_t db) {(void)m;applied_mic_gain=db;}
static bool timers[7];
static uint32_t timer_period,notify_count;
static bool pcm_irq_enabled;
volatile uint32_t ulPortYieldRequired;
static char output[8192]; static size_t output_n;
static const char *host_input;
static char drawn_hint[256],drawn_screen[4096];
static unsigned gfx_flushes,hint_clears;
static uint32_t gfx_delay_us;
static bool gfx_release_ptt;
static void advance(uint32_t us);
static bool inject_rx_clock_irq;
static uint32_t irq_depth;
static bool inject_speaker_fault;
uint32_t hrc_micros(void) {
    uint32_t sampled=now;
    if(inject_rx_clock_irq && !irq_depth) {
        inject_rx_clock_irq=false;monitor.last_raw_us=++now;
    }
    return sampled;
}
uint32_t hal_millis(void) {return now/1000u;}
uint32_t hrc_irq_save(void) { return irq_depth++; }
void hrc_irq_restore(uint32_t x) {
    irq_depth=x;
    if(!x && inject_speaker_fault) {inject_speaker_fault=false;mon_failed=true;}
}
void hrc_irq_enable(uint8_t s,bool on) {
    if(s==IRQ_MODEM_SYS && on && native_irq_owned) {
        // A native PIC source may become visible only after the modem mask
        // and stale flags are restored, outside the brief global IRQ lock.
        assert(regs[C7_SYS_INTERP_MASK/4] && regs[C7_SYS_INTERP_CLEAR/4]==UINT32_MAX);
        assert(!irq_depth);
    }
    assert(s<sizeof mock_irq_enabled/sizeof *mock_irq_enabled);mock_irq_enabled[s]=on;
    if(s==IRQ_PCM_RD)pcm_irq_enabled=on;
}
void hrc_irq_register(uint8_t s,void (*f)(void)) { (void)s; (void)f; }
void hrc_timer_periodic(uint8_t t,uint32_t us) {assert(t==SPEAKER_TIMER);timer_period=us;timers[t]=true;}
void vTaskGenericNotifyGiveFromISR(TaskHandle_t h,UBaseType_t index,BaseType_t *woken) {(void)index;assert(h==mon_task_handle);++notify_count;*woken=pdTRUE;}
uint32_t ulTaskGenericNotifyTake(UBaseType_t index,BaseType_t clear,TickType_t timeout) {(void)index;(void)clear;(void)timeout;uint32_t n=notify_count;notify_count=0;return n;}
void hrc_timer_stop(uint8_t t) { timers[t]=false; }
void hrc_timer_ack(uint8_t t) { (void)t; }
void hrc_timer_oneshot(uint8_t t,uint32_t us) { timers[t]=true; if(t==HARD_TIMER) {assert(us==RADIO_TX_GUARD_PERIOD_US);hard_at=now+us;}else if(t==TIMER_PA)pa_at=now+us; }
void hrc_pin_write(uint8_t p,bool v) {
    if(p==PIN_KEY_BACKLIGHT) {key_backlight=v;return;}
    assert(p==PIN_MIC_PATH && !v);
}
bool hrc_pin_read(uint8_t p) {
    if(p==PIN_PTT)return mock_ptt_high;
    assert(p==PIN_SPK_SOURCE || p==PIN_MIC_PATH);return p==PIN_MIC_PATH;
}
void board_rf_safe(void) {
    mock_pa_selected=false;mock_dac_drive=0;mock_dac_power|=DAC_B_OFF;
}
void hrc_dac_b_power(bool on) {
    if(on) {
        assert(!mock_pa_selected && !mock_dac_drive);
        if(call_active && frontend_mode==RADIO_MODE_DMR) {
            assert(!hardware_running && !mock_rf_selected && tx_dac_restore);
            ++dac_restores;
        }
        mock_dac_power&=~DAC_B_OFF;
    } else mock_dac_power|=DAC_B_OFF;
}
void board_init(void) {}
bool bf_cal_valid(void) { return cal; }
const char *bf_cal_source(void) { return cal ? "mock" : "none"; }
void hrc7000_audio_bits(hrc7000_t *m,uint32_t set,uint32_t clear) {
    uint32_t read_only=hrc7000_rd(m,C7_AUDIO_CONTROL)&C7_AUDIO_RING_FULL;
    m->audio_ctl=(m->audio_ctl|set)&~clear; hrc7000_wr(m,C7_AUDIO_CONTROL,m->audio_ctl|read_only);
}
void hrc_audio_pcm_stats(uint32_t *b,uint32_t *o,uint32_t *u) { *b=source_n; *o=loss; *u=0; }
void hrc_audio_pcm_reset_stats(void) { loss=0; }
bool imbe_bench_init(void) {if(!radio_codec_acquire(RADIO_CODEC_P25))return false;++codec_inits;return true;}
bool imbe_bench_ready(void) {return radio_codec_owner()==RADIO_CODEC_P25;}
bool imbe_bench_release(void) {return radio_codec_owner()!=RADIO_CODEC_P25 || radio_codec_release(RADIO_CODEC_P25);}
void imbe_bench_decode_pcm(const uint8_t *p,int16_t *o) {
    (void)p;++decode_calls;for(unsigned i=0;i<160;++i)o[i]=mock_decode_value;
}
void imbe_bench_encode_pcm(int16_t *p,uint8_t *o) {
    ++encode_calls;
    memset(o,(uint8_t)p[0],11); advance(encode_cost ? encode_cost : encoded%7==0 ? 24967 : 7000);
}
static void nop(void) {}
static bool yes(void) { return true; }
static void mode(radio_mode_t m) {
    if(native_irq_owned && m!=frontend_mode) {
        if(m==RADIO_MODE_DMR)__wrap_hrc_dmr_enter();else __wrap_hrc_dmr_leave();
    }
    frontend_mode=m;if(m==RADIO_MODE_DMR)hrc_dac_b_power(true);
}
void hrc7000_fm_rx(hrc7000_t *m,bool wide) { ++fm_recorder_calls;hrc7000_wr(m,C7_FM_BANDWIDTH,wide ? 0x4f : 0x40);hrc7000_wr(m,C7_WORK_MODE,0x80);hrc7000_wr(m,C7_FM_PTT,0); }
static void mute(bool b) {
    if(b)assert(!mock_bcast_audio);
    if(b)assert(frontend_mode==RADIO_MODE_FM && !mock_rf_selected && !callback
                && !(regs[C7_AUDIO_CONTROL/4]&C7_AUDIO_RING_PLAY));
    analog_audio=b;
}
static bool rx(uint32_t f,radio_bw_t b,const subtone_t *t) {
    tuned_rx=f;tuned_bw=b;regs[C7_FM_BANDWIDTH/4]=b==RADIO_BW_25K ? 0x4f : 0x40;
    if(frontend_mode==RADIO_MODE_FM) {regs[C7_WORK_MODE/4]=0x80;regs[C7_FM_PTT/4]=0;}
    (void)t;return tune;
}
static void signal_status(radio_status_t *s) {
    ++signal_reads;*s=(radio_status_t){signal_dbm,signal_noise,false,signal_tone_ok};
}
static bool tx_on(uint32_t f,radio_bw_t b,uint8_t p,const subtone_t *t) {
    tuned_tx=f;tuned_power=p;(void)b;(void)t;assert(p<board.power_count);hrc_dac_b_power(true);
    if(frontend_mode==RADIO_MODE_FM) {
        assert(!analog_audio && !callback && !(regs[C7_AUDIO_CONTROL/4]&C7_AUDIO_RING_PLAY));
        assert(regs[C7_WORK_MODE/4]==0x80);
        regs[C7_FM_PTT/4]=1;mock_rf_selected=mock_pa_selected=true;mock_dac_drive=1408;
        ++rf_keys;++pa_keys;mock_dmr_keyed=false;
    } else mock_dmr_keyed=true;
    return tune;
}
static void tx_off(void) {regs[C7_FM_PTT/4]=0;mock_dmr_keyed=false;mock_rf_selected=false;mock_pa_selected=false;mock_dac_drive=0;}
static void rf(bool on) { if(on)++rf_keys;else {mock_pa_selected=false;mock_dac_drive=0;}mock_rf_selected=on; }
static void pa(void) {
    ++pa_keys;assert(mock_rf_selected && mock_dmr_keyed);
    assert(((mock_dac_power&DAC_B_OFF)==0)==tx_dac_restore);
    mock_pa_selected=true;mock_dac_drive=1408; // Native calibrated low-power value; never changed by diagnostics.
}
static uint16_t batt(void) {++battery_reads;return battery;}
static void led(uint8_t l,bool on) { (void)l;(void)on; }
static void latch(bool on) { (void)on; }
static void level(uint8_t l) {assert(l<=100);screen_backlight=l;}
static uint32_t scan(void) { return scripted_scan ? scripted_keys : now-capture_started<release_after ? 1 : 0; }
static size_t read_port(uint8_t *p,size_t n) {
    size_t available=host_input ? strlen(host_input) : 0;
    if(n>available)n=available;
    if(n) {memcpy(p,host_input,n);host_input+=n;}
    return n;
}
static size_t write_port(const uint8_t *p,size_t n) {
    assert(!digital_dmr.tx_armed);
    assert(output_n+n<sizeof output); memcpy(output+output_n,p,n); output_n+=n; output[output_n]=0; return n;
}
static bool audio_start(audio_block_cb_t c,void *ctx) {
    (void)ctx; assert(regs[C7_WORK_MODE/4]==2 && regs[C7_LAYER2_TXRX_CTRL/4]==0);
    callback=start_ok ? c : NULL; next_pcm=now+20000; return start_ok;
}
static void audio_end(void) { callback=NULL; }
static const hal_stream_t port={.start=yes,.read=read_port,.write=write_port};
static void speaker_route(bool on) {if(on)assert(!analog_audio && !mock_bcast_audio);hrc7000_audio_bits(&modem,on ? C7_AUDIO_RING_PLAY : 0,on ? 0 : C7_AUDIO_RING_PLAY);}
static bool bcast_power(bool on) {
    if(on) {++mock_bcast_power_ons;assert(!call_active && !hardware_running && !callback);}
    else {++mock_bcast_power_offs;assert(!mock_bcast_audio);}
    if(!mock_bcast_available)return false;
    mock_bcast_on=on;return true;
}
static bool bcast_tune(uint32_t khz) {
    assert(mock_bcast_on && !mock_bcast_audio);++mock_bcast_tunes;
    assert(khz>=65000 && khz<=108000 && !(khz%50));
    if(!mock_bcast_tune_ok)return false;
    mock_bcast_status=(bcast_status_t){.khz=khz,.station=true,.stereo=true,.rssi=70};return true;
}
static bool bcast_seek(bool up) {
    assert(mock_bcast_on && !mock_bcast_audio);++mock_bcast_seeks;mock_bcast_seek_up=up;
    uint32_t khz=mock_bcast_status.khz;
    mock_bcast_status.khz=up ? khz>=107000 ? 65000 : khz+1000 : khz<=66000 ? 108000 : khz-1000;
    return true;
}
static void bcast_volume(uint8_t value) {assert(value<=BCAST_VOLUME_MAX);mock_bcast_volume=value;}
static bool bcast_status(bcast_status_t *value) {
    ++mock_bcast_polls;if(!mock_bcast_on || !mock_bcast_available)return false;
    *value=mock_bcast_status;value->tuning=mock_bcast_hold;return true;
}
static void bcast_audio(bool on) {
    if(on)assert(mock_bcast_on && !analog_audio && !callback && !mon_running
                && !analog_fm.running && !digital_dmr.running && !(regs[C7_AUDIO_CONTROL/4]&C7_AUDIO_RING_PLAY));
    mock_bcast_audio=on;
}
static const hal_bcast_t bcast={.lo_khz=65000,.hi_khz=108000,.grid_khz=50,.power=bcast_power,
    .tune=bcast_tune,.seek=bcast_seek,.volume=bcast_volume,.status=bcast_status,.audio=bcast_audio};
static const hal_audio_t audio={.start=audio_start,.stop=audio_end,.speaker_pcm=speaker_route};
static const hal_radio_t radio={.init=nop,.audio=mute,.set_mode=mode,.rx=rx,.tx=tx_on,.tx_off=tx_off,.status=signal_status};
static const hal_power_t power={.battery_mv=batt,.led=led,.switch_on=yes,.latch=latch};
static int encoder_delta;
static int8_t encoder(void) {int8_t delta=(int8_t)encoder_delta;encoder_delta=0;return delta;}
static const hal_input_t input={.init=nop,.scan=scan,.encoder=encoder};
static const hal_display_t display={.init=nop,.set_backlight=level};
static const hal_flash_t pref_flash;
// Optional RX-only descriptors must not widen normal communications channels.
static const band_t bands[]={{400000000,480000000,true},{65000000,108000000,false},{108000000,136000000,false}};
static const char *const power_names[]={"L-","L","L+","L++","M","M+","M++","H-","H"};
static const keymap_entry_t test_keys[]={
    {.bit=0,.short_action=ACT_PTT}, {.bit=1,.short_action=ACT_SELECT},
    {.bit=2,.short_action=ACT_BACK}, {.bit=3,.short_action=ACT_DIGIT_4},
    {.bit=4,.short_action=ACT_CONTEXT}, {.bit=5,.short_action=ACT_QUICK},
    {.bit=6,.short_action=ACT_NAV_LEFT}, {.bit=7,.short_action=ACT_NAV_RIGHT},
    {.bit=8,.short_action=ACT_MONITOR}, {.bit=9,.short_action=ACT_AB}
};
const board_t board={.keymap=test_keys,.keymap_len=10,.host_port=&port,.audio=&audio,.radio=&radio,.power=&power,.input=&input,
    .display=&display,.flash=&pref_flash,.bands=bands,.band_count=3,.battery_critical_mv=6400,
    .power_count=9,.power_names=power_names,.power_default=0,.bcast=&bcast,.caps=CAP_BCAST_FM,
    .dmr=&radio_dmr_stub_modem,.vocoder=&radio_dmr_stub_vocoder};
static const hrc_dmr_board_t rf_hooks={.rf_switch=rf,.pa_on=pa,.pa_delay_us=28000};
bool gfx_init(const hal_display_t *d) { (void)d;return true; }
int gfx_width(void) {return 220;}
int gfx_height(void) {return 310;}
void gfx_frame_begin(void) { assert((!hardware_running || native_irq_owned) && !audio_on); }
void gfx_clear(color_t c) { (void)c;drawn_hint[0]=drawn_screen[0]=0; }
static void gfx_bounds(int x,int y,int w,int h) {
    assert(x>=0 && y>=0 && w>=0 && h>=0 && x+w<=220 && y+h<=310);
}
void gfx_fill(int x,int y,int w,int h,color_t c) {
    (void)c;gfx_bounds(x,y,w,h);
    if(x==0 && y==260) {assert(w==220 && h==50);++hint_clears;drawn_hint[0]=0;}
}
void gfx_rect(int x,int y,int w,int h,color_t c) {(void)c;gfx_bounds(x,y,w,h);}
void gfx_round_fill(int x,int y,int w,int h,color_t c) {(void)c;gfx_bounds(x,y,w,h);}
void gfx_hline(int x,int y,int w,color_t c) {(void)c;gfx_bounds(x,y,w,1);}
void gfx_vline(int x,int y,int h,color_t c) {(void)c;gfx_bounds(x,y,1,h);}
void gfx_pixel(int x,int y,color_t c) {(void)c;gfx_bounds(x,y,1,1);}
int gfx_text_width(const font_t *f,const char *s) {return (int)strlen(s)*f->w;}
void gfx_text_fit(const font_t *f,const char *s,int max_w,char *out,size_t cap) {
    if(!cap)return;
    size_t fit=max_w>0 ? (size_t)(max_w/f->w) : 0,n=strlen(s);
    if(fit>=cap)fit=cap-1;
    if(n<=fit) {memcpy(out,s,n+1);return;}
    if(!fit) {out[0]=0;return;}
    size_t head=fit/2,tail=fit-1-head;
    memcpy(out,s,head);out[head]='~';memcpy(out+head+1,s+n-tail,tail);out[fit]=0;
}
void gfx_icon_battery(int x,int y,int w,int h,uint8_t pct,color_t outline,color_t fill) {
    (void)outline;(void)fill;gfx_bounds(x,y,w,h);assert(pct<=100);
}
void gfx_icon_bars(int x,int y,int w,int h,uint8_t count,uint8_t lit,color_t on,color_t off) {
    (void)on;(void)off;gfx_bounds(x,y,w,h);assert(count && lit<=count);
}
int gfx_text(const font_t *f,int x,int y,const char *s,color_t c) {
    (void)c;gfx_bounds(x,y,(int)strlen(s)*f->w,f->h);
    size_t n=strlen(drawn_screen),len=strlen(s);
    if(n+len+2<sizeof drawn_screen) {memcpy(drawn_screen+n,s,len);drawn_screen[n+len]='\n';drawn_screen[n+len+1]=0;}
    if(y>=260) {
        n=strlen(drawn_hint);assert(n+len+2<sizeof drawn_hint);
        memcpy(drawn_hint+n,s,len);drawn_hint[n+len]=' ';drawn_hint[n+len+1]=0;
    }
    return x+(int)len*f->w;
}
void gfx_flush(void) {
    assert((!hardware_running || native_irq_owned) && !audio_on);
    // A synchronous transfer must never occupy the sole native TX feeder.
    assert(!digital_dmr.tx_armed);
    ++gfx_flushes;
    if(gfx_delay_us)advance(gfx_delay_us);
    if(gfx_release_ptt) {mock_ptt_high=true;scripted_keys=0;gfx_release_ptt=false;}
}
const font_t font_6x12={.w=6,.h=12},font_8x16={.w=8,.h=16},font_12x24={.w=12,.h=24};
void vTaskDelete(TaskHandle_t h) { (void)h; }
UBaseType_t uxTaskGetStackHighWaterMark(TaskHandle_t h) { (void)h;return 3000; }
void vTaskDelay(TickType_t t) { advance(t*1000); }
BaseType_t xTaskCreate(TaskFunction_t f,const char *const n,configSTACK_DEPTH_TYPE d,void *const p,UBaseType_t pr,TaskHandle_t *const h) {
    (void)f;(void)n;(void)p;(void)pr;(void)h;assert(d==4096 || d==512);if(h)*h=(TaskHandle_t)1;return pdPASS;
}
static void delayed_flush(void) {
    if(!delayed_pending)return;
    assert(delayed_n+delayed_tail<=sizeof delayed_wire);
    memcpy(delayed_wire+delayed_n,buf+36*delayed_half+36-delayed_tail,delayed_tail);
    delayed_n+=delayed_tail;delayed_pending=false;
}
static void record_publication(void) {
    // Logical input is the complete block the adapter just published. The
    // consumer's independently selected half can still hold previous content.
    unsigned written=tx_writer==TX_WRITER_DUP ? 0u : (tx_write_half^1u)*36u;
    assert(wire_n+36<=sizeof wire);memcpy(wire+wire_n,buf+written,36);wire_n+=36;
    if(tx_writer==TX_WRITER_DUP)assert(!memcmp(buf,buf+36,36));
    if(!delayed_model)return;
    // A prefix was fetched in the previous slot, but its final bytes remain
    // live in RAM during this next publication. No knowledge of writer mode.
    delayed_flush();
    delayed_half=(delayed_phase+delayed_blocks)%2u;
    assert(delayed_n+36-delayed_tail<=sizeof delayed_wire);
    memcpy(delayed_wire+delayed_n,buf+36*delayed_half,36-delayed_tail);
    delayed_n+=36-delayed_tail;delayed_pending=true;++delayed_blocks;
}
static void advance(uint32_t us) {
    while(us) {
        unsigned step=us>1000 ? 1000 : us; now+=step; us-=step;
        if(callback && !missing_pcm && (int32_t)(now-next_pcm)>=0) {
            int16_t p[160],sp[160]; ++source_n;
            for(unsigned i=0;i<160;++i) p[i]=(int16_t)source_n;
            callback(p,sp,NULL); next_pcm+=20000;
        }
        if(hardware_running && frontend_mode==RADIO_MODE_DMR && !next_rf) { rf_at=now; next_rf=now+1000; }
        if(hardware_running && timers[HARD_TIMER] && (int32_t)(now-hard_at)>=0) isr_hard_stop();
        if(hardware_running && frontend_mode==RADIO_MODE_DMR && !missing_rf && (int32_t)(now-next_rf)>=0) {
            unsigned before=live.timing.blocks; boundary();
            if(live.timing.blocks!=before) {
                record_publication();
            } else if(delayed_model && live.timing.state==P25_TX_DRAINING) {
                // The final block's tail is consumed during the existing RF
                // drain, without publishing/latching another block.
                delayed_flush();
            }
            unsigned half=tx_write_half,blocks=live.timing.blocks;uint8_t previous[72];memcpy(previous,buf,72);
            boundary(); // simultaneous SYS/slot duplicate cannot clear TX request
            assert(tx_write_half==half && live.timing.blocks==blocks && !memcmp(previous,buf,72));
            next_rf+=30000;
            if(!pa_started && hardware_running)isr_rftx();
        }
        if(hardware_running && timers[TIMER_PA] && (int32_t)(now-pa_at)>=0)isr_pa();
    }
}
static void reset(void) {
    radio_broadcast_stop(&broadcast);memset(&broadcast,0,sizeof broadcast);broadcast_show=false;broadcast_due=0;
    radio_tx_guard_stop(&hard_guard);call_tot_expired=false;call_soft_limit_us=0;call_capture_frames=0;
    mock_bcast_on=mock_bcast_audio=mock_bcast_hold=mock_bcast_seek_up=false;
    mock_bcast_available=mock_bcast_tune_ok=true;mock_bcast_volume=0;memset(&mock_bcast_status,0,sizeof mock_bcast_status);
    mock_bcast_power_ons=mock_bcast_power_offs=mock_bcast_tunes=mock_bcast_seeks=mock_bcast_polls=0;tuned_power=0;
    if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    decode_calls=0;mock_decode_value=0;
    scripted_scan=false;scripted_keys=0;encoder_delta=0;
    mock_ptt_high=true;
    owner_tx_inhibit=false;rx_promiscuous=false;normal_mode=false;
    ptt_release_required=ptt_release_seen=false;ptt_release_since=0;mon_have_nac=false;mon_call_nac=0;
    tx_fixed=false;tx_pairs=14;tx_startup_extra=0;
    mon_pcm_backend=false;mon_pcm_pending=false;
    memset(&pref_store,0,sizeof pref_store);memset(&pref_saved,0,sizeof pref_saved);mic_gain_db=11;pref_dirty=false;pref_state="not_loaded";
    mon_enabled=false;mon_stop("reset");mon_used=mon_failed=false;mon_local_tone=mon_output_tone=mon_replay=false;mon_tone_hz=1000;mon_tone_phase=0;mon_fifo_limit=8;mon_service_ms=2;mon_timer_us=0;notify_count=timer_period=0;mon_audio_enabled=true;
    cleanup(); memset(regs,0,sizeof regs);memset(mock_irq_enabled,0,sizeof mock_irq_enabled);
    memset(&pcmq,0,sizeof pcmq); p25_live_tx_init(&live);
    radio_dmr_stub_reset();memset(&digital_dmr,0,sizeof digital_dmr);
    assert(radio_codec_bind_dmr(&rx_storage,sizeof rx_storage));
    native_irq_owned=dmr_hard_timeout=false;dmr_ui_serial=dmr_ui_due=0;
    dmr_ui_pending=false;memset(&dmr_ui_cost,0,sizeof dmr_ui_cost);
    command_deferred_reset();
    radio_dmr_hal dmr_hal={.radio=board.radio,.modem=board.dmr,.audio=board.audio,
        .vocoder=board.vocoder,.acquire=dmr_acquire,.release=dmr_release};
    radio_dmr_init(&digital_dmr,&dmr_hal);
    tx_writer=TX_WRITER_DUP;tx_write_half=0;tx_dac_restore=false;memset((void *)&tx_dac,0,sizeof tx_dac);
    mock_dac_power=0xa5u|DAC_B_OFF;mock_dac_drive=0;mock_pa_selected=mock_rf_selected=mock_dmr_keyed=false;dac_restores=0;
    delayed_model=delayed_pending=false;delayed_phase=delayed_tail=delayed_blocks=delayed_n=delayed_half=0;
    ui_battery_mv=ui_battery_pct=ui_rssi_bars=0;ui_battery_valid=ui_rssi_valid=false;ui_rssi_dbm=0;
    ui_battery_due=ui_rssi_due=ui_signal_us=ui_meter_max_us=ui_header_shown=0;
    memset(&ui_strength,0,sizeof ui_strength);
    memset(&channel_store,0,sizeof channel_store);memset(channel_record,0,32);memset(channel_saved,0,32);
    memset(global_record,0,32);memset(global_saved,0,32);memset(&analog_fm,0,sizeof analog_fm);
    memset(&radio_lights,0,sizeof radio_lights);memset(&channel_scan,0,sizeof channel_scan);
    features_ready=rx_tg_filter=cps_active=cps_link=false;cps_transaction=cps_activity_us=light_keys=lock_mask=lock_select_mask=0;
    light_screen_level=light_key_level=255;channel_label[0]=0;
    regs[C7_SYS_INTERP_MASK/4]=MOCK_NATIVE_SYS_MASK;
    __wrap_hrc_dmr_board_init(&modem,&rf_hooks);
    memset(&control,0,sizeof control); control.nac=0x293;control.talkgroup=control.source_id=1;field=EDIT_RX;
    menu_open=false;menu_page=MENU_ROOT;menu_item=0;edit_from_menu=diag_from_menu=false;reason="idle";
    rx_lab=rx_checked=rx_pass=false; editing=false; digit_count=0; key_candidate=key_stable=key_changed_at=0;
    session_enabled=armed=call_active=audio_on=hardware_running=prepared=pa_started=false;
    now=0xffff0000u; next_rf=wire_n=source_n=rf_keys=pa_keys=loss=encode_cost=output_n=codec_inits=encode_calls=pa_at=0;
    cal=tune=start_ok=true;battery=8000;battery_reads=signal_reads=0;signal_dbm=-73;signal_noise=12;
    signal_tone_ok=true;analog_audio=key_backlight=false;screen_backlight=80;missing_pcm=missing_rf=false;
    release_after=40000000u; ptt_mask=1; frequency=control.tx_frequency=440075000; display_ok=true;
    drawn_hint[0]=drawn_screen[0]=0;gfx_flushes=hint_clears=0;
    gfx_delay_us=0;gfx_release_ptt=false;
    host_input=NULL;
}
static void issue(const char *s,bool down) { strcpy(command,s); parse_command(down); }
static void receive_unit(p25_rx *unit,uint16_t nac,uint8_t duid,const uint8_t *bytes) {
    unit->nac=nac;unit->duid=duid;
    memset(unit->frame,0,sizeof unit->frame);
    if(bytes)memcpy(unit->frame,bytes,duid==0 ? 99 : duid==3 ? 18 : 216);
    mon_receive(unit,NULL);
}
static bool start_call(void) {
    armed=true;arm_until=now+ARM_US;radio_inhibit(&control,false);return begin_capture();
}
static void run(void) {
    unsigned iterations=0;
    while(call_active) { poll_call(scan()!=0); advance(1000); assert(++iterations<40000); }
    cleanup();
}
static void check_wire(void) {
    unsigned expected_bytes=339+encoded/9*216+18;
    assert(wire_n==(expected_bytes+35)/36*36);
    for(unsigned i=0;i<240;++i) assert(wire[i]==0x77);
    assert(!memcmp(wire+240,p25_test_hdu,99));
    for(unsigned u=0;u<encoded/9;++u) {
        uint8_t p[9][11],ldu[216];
        for(unsigned j=0;j<9;++j) memset(p[j],u*9+j<pcmq.captured ? (uint8_t)(u*9+j+1) : 0,11);
        p25_live_ldu(ldu,(const uint8_t (*)[11])p,(u&1)!=0);
        assert(!memcmp(wire+339+u*216,ldu,216));
    }
    assert(!memcmp(wire+339+encoded/9*216,p25_test_tdu,18));
    for(unsigned i=expected_bytes;i<wire_n;++i) assert(wire[i]==0x77);
}
static void check_fixed_wire(void) {
    const unsigned prefix=P25_TEST_PREAMBLE_BYTES+tx_startup_extra;
    const unsigned bytes=prefix+99+encoded/9*216+18;
    assert(encoded && encoded%18==0 && wire_n==(bytes+35)/36*36);
    for(unsigned i=0;i<prefix;++i)assert(wire[i]==0x77);
    assert(!memcmp(wire+prefix,call_frames.hdu,99));
    for(unsigned u=0;u<encoded/9;++u) {
        const uint8_t *actual=wire+prefix+99+u*216;
        const uint8_t *base=(u&1) ? call_frames.ldu2 : call_frames.ldu1;
        const uint8_t *fixture=(u&1) ? p25_test_ldu2 : p25_test_ldu1;
        assert(!memcmp(actual,base,216));
        for(unsigned f=0;f<9;++f) {
            uint8_t expected[11],got[11];unsigned errors;
            assert(p25_rx_voice(fixture,f,expected,&errors) && !errors);
            assert(p25_rx_voice(actual,f,got,&errors) && !errors);
            assert(!memcmp(got,expected,11));
        }
    }
    assert(!memcmp(wire+prefix+99+encoded/9*216,call_frames.tdu,18));
    for(unsigned i=bytes;i<wire_n;++i)assert(wire[i]==0x77);
    assert(!pcmq.captured && !pcmq.accepting && !source_n && !callback && !audio_on);
    assert(!codec_inits && !encode_calls && !max_encode && !payload_hash);
    assert(live.published==encoded/9 && live.consumed==encoded/9 && !live.count && !live.underruns);
    p25_rx parser;p25_rx_init(&parser);unsigned accepted=0;
    for(unsigned i=prefix;i<wire_n;++i)for(unsigned j=0;j<4;++j)
        if(p25_rx_push(&parser,(wire[i]>>(6-2*j))&3)) {assert(parser.nac==control.nac);++accepted;}
    assert(accepted==encoded/9+2);
}
static void reject_tx_diag(const char *s,bool down) {
    const bool fixed=tx_fixed;const unsigned pairs=tx_pairs,extra=tx_startup_extra;
    const tx_writer_mode writer=tx_writer;const bool dac=tx_dac_restore;
    output_n=0;output[0]=0;issue(s,down);
    assert(!strncmp(output,"ERR ",4));
    assert(tx_fixed==fixed && tx_pairs==pairs && tx_startup_extra==extra);
    assert(tx_writer==writer && tx_dac_restore==dac);
}
enum {ROOT_OPERATING,ROOT_CHANNEL,ROOT_AUDIO_TX,ROOT_SETTINGS,ROOT_TOOLS};
enum {TX_PERMISSION,TX_POWER,TX_TOT};
enum {FUNCTIONS_P1,FUNCTIONS_P2,FUNCTIONS_SK1,FUNCTIONS_SK2};
enum {TOOLS_BROADCAST,TOOLS_BCAST_FREQ,TOOLS_DIAGNOSTICS};
enum {CHANNEL_RX,CHANNEL_TX,CHANNEL_SIMPLEX,CHANNEL_NAC,CHANNEL_MODE,CHANNEL_FM,CHANNEL_RX_ONLY,CHANNEL_FILTER};
enum {VOICE_TALKGROUP,VOICE_RADIO_ID,VOICE_MIC};
enum {DIAG_STATUS,DIAG_FRAME_TEST,DIAG_BENCH};
enum {MEM_MODE,MEM_VFO,MEM_SAVE,MEM_RECALL,MEM_SCAN};
enum {SCAN_START,SCAN_LIST,SCAN_MEMBER};
enum {DISPLAY_SCREEN,DISPLAY_LIGHT,DISPLAY_LOCK};
enum {FM_BANDWIDTH,FM_SQUELCH,FM_TX_TYPE,FM_TX_CODE,FM_RX_TYPE,FM_RX_CODE};
static void home(void) {
    if(editing)local_action(ACT_BACK,false);
    if(rx_lab)local_action(ACT_BACK,false);
    for(unsigned i=0;menu_open && i<3;++i)local_action(ACT_BACK,false);
    assert(!menu_open && !editing && !rx_lab);
}
static void menu_select_index(unsigned item) {
    assert(menu_open && item<menu_count());
    for(unsigned i=0;i<item;++i)local_action(ACT_NAV_DOWN,false);
    local_action(ACT_SELECT,false);
}
static void choose(ui_menu page,unsigned item) {
    assert(page<=MENU_TOOLS);
    home();local_action(ACT_SELECT,false);
    assert(menu_open && menu_page==MENU_ROOT && !menu_item);
    if(page!=MENU_ROOT) {
        unsigned root=page==MENU_MEMORY || page==MENU_SCAN ? ROOT_OPERATING
            : page==MENU_CHANNEL || page==MENU_FM || page==MENU_DMR ? ROOT_CHANNEL
            : page==MENU_VOICE || page==MENU_TRANSMIT || page==MENU_AUDIO_TX ? ROOT_AUDIO_TX
            : page==MENU_DISPLAY || page==MENU_FUNCTIONS || page==MENU_SETTINGS ? ROOT_SETTINGS : ROOT_TOOLS;
        menu_select_index(root);
        if(page==MENU_SCAN)menu_select_index(MEM_SCAN);
        else if(page==MENU_VOICE || page==MENU_TRANSMIT)menu_select_index(page==MENU_VOICE ? 0u : 1u);
        else if(page==MENU_DISPLAY || page==MENU_FUNCTIONS)menu_select_index(page==MENU_DISPLAY ? 0u : 1u);
        else if(page==MENU_DIAGNOSTICS)menu_select_index(TOOLS_DIAGNOSTICS);
        else if(page==MENU_FM || page==MENU_DMR)menu_select_index(CHANNEL_FM);
        assert(menu_open && menu_page==page && !menu_item);
    }
    menu_select_index(item);
}
static void cycle_filter(void) {choose(MENU_CHANNEL,CHANNEL_FILTER);home();}
static void toggle_owner_tx(void) {choose(MENU_TRANSMIT,TX_PERMISSION);home();}
static void enter_digits(const char *value) {
    for(;*value;++value) local_action(ACT_DIGIT_0+*value-'0',false);
}
static uint8_t pref_flash_mem[32768];
static unsigned pref_flash_reads,pref_flash_writes,pref_flash_erases;
static uint32_t pref_flash_fail_addr;
static unsigned pref_flash_fail_match,pref_flash_fail_hits;
static bool pref_flash_forbidden;
static bool pref_flash_read(uint32_t addr,void *out,uint32_t size) {
    assert(!pref_flash_forbidden && addr>=0x711000u && addr+size<=0x719000u);
    ++pref_flash_reads;
    if(addr==pref_flash_fail_addr && pref_flash_fail_match && !--pref_flash_fail_match) {
        ++pref_flash_fail_hits;return false;
    }
    memcpy(out,pref_flash_mem+addr-0x711000u,size);return true;
}
static bool pref_flash_write(uint32_t addr,const void *in,uint32_t size) {
    assert(!pref_flash_forbidden && addr>=0x711000u && addr+size<=0x719000u);
    ++pref_flash_writes;
    for(unsigned i=0;i<size;++i)pref_flash_mem[addr-0x711000u+i]&=((const uint8_t *)in)[i];
    return true;
}
static bool pref_flash_erase(uint32_t addr) {
    assert(!pref_flash_forbidden && addr>=0x711000u && addr<0x719000u && !(addr%4096u));
    ++pref_flash_erases;memset(pref_flash_mem+addr-0x711000u,255,4096);return true;
}
static const hal_flash_map_t pref_flash_map={.settings_addr=0x711000u,.settings_size=32768u};
static const hal_flash_t pref_flash={.size=0x1000000u,.erase_size=4096u,.read=pref_flash_read,
    .write=pref_flash_write,.erase=pref_flash_erase,.map=&pref_flash_map};
static void check_stored_profile(unsigned revision) {
    p25_cs_store reopened;uint8_t global[32],channel[32];
    assert(p25_cs_open(&reopened,&pref_flash) && reopened.have_active && reopened.writable);
    assert(reopened.revision==revision && p25_cs_read(&reopened,P25_CS_GLOBAL,global));
    unsigned pane=global[9],slot=global[10+pane],key=slot ? slot-1u : P25_CS_VFO_A+pane;
    assert(p25_cs_read(&reopened,key,channel) && p25_cs_record_valid(key,channel));
    assert(pref_get(channel)==frequency && pref_get(channel+4)==control.tx_frequency);
    assert(p25_cs_get16(channel+8)==control.nac && p25_cs_get16(channel+10)==control.talkgroup);
    assert(pref_get(global)==control.source_id && global[4]==mic_gain_db && global[13]==owner_tx_inhibit);
    assert(((channel[12]>>2)&3u)==feature_filter());
}
static void test_preference_noop(void) {
    reset();issue("CHANNEL 440075000 440075000 659 10 1234567 22",false);
    // Load a genuine committed record, then forbid even a read during no-ops.
    // A needless save cannot pass by silently failing a mocked flash write.
    memset(pref_flash_mem,255,sizeof pref_flash_mem);p25_preferences original=pref_current();
    pref_pack(pref_flash_mem,&original,4);pref_flash_forbidden=false;
    preferences_restore();assert(features_ready && pref_store.have && pref_store.seq==4);
    pref_state="saved";pref_dirty=false;
    pref_flash_reads=pref_flash_writes=pref_flash_erases=0;pref_flash_forbidden=true;
    issue("CHANNEL 440075000 440075000 659 10 1234567 22",false);
    assert(!strcmp(pref_state,"saved") && !pref_dirty && pref_store.seq==4);
    assert(!pref_flash_reads && !pref_flash_writes && !pref_flash_erases);
    // Re-entering the same gain through the real keypad editor has the same
    // pending transition as CHANNEL, resolved by the next main-loop poll.
    choose(MENU_VOICE,VOICE_MIC);assert(editing && field==EDIT_MIC);enter_digits("22");local_action(ACT_SELECT,false);
    assert(!editing && !strcmp(pref_state,"pending"));preferences_poll(false);
    assert(!strcmp(pref_state,"saved") && !pref_dirty && pref_store.seq==4);
    assert(!pref_flash_reads && !pref_flash_writes && !pref_flash_erases);
    // A real gain change must migrate to an atomic bank, retaining the exact
    // V3 fallback. Reopen the committed store instead of counting two writes.
    home();
    pref_flash_forbidden=false;issue("CHANNEL 440075000 440075000 659 10 1234567 23",false);
    assert(!strcmp(pref_state,"saved") && !pref_dirty && pref_store.seq==5 && pref_saved.mic_db==23);
    assert(pref_flash_reads && pref_flash_writes>2 && pref_flash_erases==4);
    check_stored_profile(5);
    uint8_t legacy[64];pref_pack(legacy,&original,4);assert(!memcmp(pref_flash_mem,legacy,64));
    pref_flash_reads=pref_flash_writes=pref_flash_erases=0;pref_flash_forbidden=true;
    // Reverting an unsaved edit also restores the known saved status, while
    // read-only records keep their read-only label rather than claiming a save.
    mic_gain_db=24;pref_state="pending";preferences_poll(true);assert(pref_dirty && !strcmp(pref_state,"pending"));
    mic_gain_db=23;preferences_poll(false);assert(!pref_dirty && !strcmp(pref_state,"saved"));
    pref_store.writable=false;issue("CHANNEL 440075000 440075000 659 10 1234567 23",false);
    assert(!strcmp(pref_state,"read_only") && !pref_dirty && pref_store.seq==5);
    // Equality alone is insufficient without a valid known record. Do not
    // relabel invalid values, defaults, or an existing save failure as saved.
    pref_store.writable=true;pref_store.have=false;pref_state="pending";preferences_poll(false);
    assert(!strcmp(pref_state,"pending") && !pref_dirty);
    pref_state="defaults";preferences_poll(false);assert(!strcmp(pref_state,"defaults"));
    pref_store.have=true;frequency=0;pref_saved=pref_current();pref_state="pending";preferences_poll(false);
    assert(!strcmp(pref_state,"pending") && !pref_dirty);
    frequency=440075000;pref_saved=pref_current();pref_state="save_failed";preferences_poll(false);
    assert(!strcmp(pref_state,"save_failed") && !pref_dirty);
    assert(!pref_flash_reads && !pref_flash_writes && !pref_flash_erases && pref_store.seq==5);
    pref_flash_forbidden=false;reset();
}
static void assert_rf_safe(void) {
    assert(!hardware_running && !mock_pa_selected && !mock_rf_selected && !mock_dac_drive);
    assert((mock_dac_power&DAC_B_OFF) && !timers[TIMER_PA] && !timers[HARD_TIMER]);
}
static void fixed_path(const char *writer,bool restore,unsigned pairs,unsigned extra) {
    char cmd[40];
    snprintf(cmd,sizeof cmd,"TXWRITER %s",writer);issue(cmd,false);
    issue(restore ? "TXDAC RESTORE" : "TXDAC KEEP",false);
    issue("TXSOURCE FIXED1011",false);
    snprintf(cmd,sizeof cmd,"TXPAIRS %u",pairs);issue(cmd,false);
    snprintf(cmd,sizeof cmd,"TXALIGN %u",extra);issue(cmd,false);
    issue("SESSION 440075000 ALLOW_RF",false);
}
static void test_writer_and_dac_paths(void) {
    const char *writers[]={"DUP","ALT0","ALT1"};
    for(unsigned mode=0;mode<3;++mode)for(unsigned phase=0;phase<2;++phase)
    for(unsigned tail=1;tail<=6;tail+=5)for(unsigned restore=0;restore<2;++restore) {
        reset();fixed_path(writers[mode],restore,2,0);
        delayed_model=true;delayed_phase=phase;delayed_tail=tail;
        assert(begin_capture());run();check_fixed_wire();assert_rf_safe();
        assert(delayed_blocks==live.timing.blocks && delayed_n==wire_n && !delayed_pending);
        assert(tx_dac.seen==0x3fu && tx_dac.before_tx==0xa5u && tx_dac.prepared==0xa5u);
        assert(tx_dac.after_stop==0xa7u && tx_dac.end==0xa7u);
        assert(tx_dac.pre_rf==(restore ? 0xa5u : 0xa7u) && tx_dac.pa==tx_dac.pre_rf);
        assert(dac_restores==restore && rf_keys==1 && pa_keys==1);
        if(mode && phase==mode-1u) {
            assert(!memcmp(delayed_wire,wire,wire_n));
            unsigned tdu=P25_TEST_PREAMBLE_BYTES+tx_startup_extra+99+encoded/9*216;
            assert(!memcmp(delayed_wire+tdu,call_frames.tdu,18));
        } else if(mode) {
            assert(memcmp(delayed_wire,wire,wire_n)); // Consumer phase is not chosen to make the writer pass.
        } else {
            unsigned differences=0;
            for(unsigned b=0;b<delayed_blocks;++b)for(unsigned j=0;j<36;++j) {
                unsigned from=b*36+j;
                if(j>=36-tail && b+1<delayed_blocks)from+=36;
                assert(delayed_wire[b*36+j]==wire[from]);
                differences+=delayed_wire[b*36+j]!=wire[b*36+j];
            }
            assert(differences); // In particular, tail=1 reproduces the +36 endpoint-byte substitution.
        }
    }
    // Odd block counts and cancelled calls leave a different final software
    // half, but each new RF start must return to the selected initial half.
    for(unsigned phase=0;phase<2;++phase) {
        reset();fixed_path(writers[phase+1],true,1,4);
        for(unsigned c=0;c<2;++c) {
            delayed_model=true;delayed_phase=phase;delayed_tail=1;
            delayed_pending=false;delayed_n=delayed_blocks=wire_n=next_rf=0;
            tx_write_half=phase^1u;
            assert(begin_capture());
            while(!hardware_running) {poll_call(true);advance(1000);}
            assert(tx_write_half==phase);
            run();check_fixed_wire();assert_rf_safe();
            assert(live.timing.blocks%2u==1 && tx_write_half==(phase^1u));
            assert(delayed_n==wire_n && !memcmp(delayed_wire,wire,wire_n));
        }
        next_rf=wire_n=0;delayed_model=false;assert(begin_capture());
        while(!live.timing.blocks) {poll_call(true);advance(1000);}
        assert(tx_write_half==(phase^1u));issue("STOP",true);cleanup();assert_rf_safe();
        issue("SESSION 440075000 ALLOW_RF",false);next_rf=wire_n=0;assert(begin_capture());
        while(!hardware_running) {poll_call(true);advance(1000);}
        assert(tx_write_half==phase);run();check_fixed_wire();assert_rf_safe();
        reset();fixed_path(writers[phase+1],true,14,35);
        delayed_model=true;delayed_phase=phase;delayed_tail=6;
        assert(begin_capture());run();check_fixed_wire();assert_rf_safe();
        assert(delayed_n==wire_n && !delayed_pending && !memcmp(delayed_wire,wire,wire_n));
    }
    // Rejected late/underrun boundaries do not touch either RAM half or phase.
    for(unsigned fault=0;fault<2;++fault) {
        reset();fixed_path("ALT1",true,14,0);assert(begin_capture());
        while(!hardware_running) {poll_call(true);advance(1000);}
        while(!live.timing.blocks)advance(1000);
        unsigned half=tx_write_half;uint8_t previous[72];memcpy(previous,buf,72);
        if(!fault)now=live.timing.last_boundary_us+P25_TX_LATE_US+1;
        else {now=live.timing.last_boundary_us+30000u;live.header_pos=339;live.count=0;live.finished=false;}
        boundary();assert(!hardware_running && tx_write_half==half && !memcmp(previous,buf,72));
        cleanup();assert_rf_safe();unsigned old_pa=pa_keys;isr_pa();assert(pa_keys==old_pa);assert_rf_safe();
    }
    // Restore is a power-only preparation at RF start. Pre-RF cancellation,
    // setup/audio faults, STOP, queue loss and watchdogs all retain the kill.
    for(unsigned fault=0;fault<8;++fault) {
        reset();fixed_path("ALT0",true,14,0);
        if(fault==0)tune=false;
        else if(fault==1) {tx_fixed=false;start_ok=false;}
        bool started=begin_capture();
        if(fault<2) {assert(!started);cleanup();}
        else if(fault==2) {assert(started);poll_call(false);cleanup();assert(!dac_restores && !rf_keys && !pa_keys);}
        else {
            assert(started);while(!hardware_running) {poll_call(true);advance(1000);}
            while(!pa_keys) {poll_call(true);advance(1000);}
            if(fault==3)issue("STOP",true);
            else if(fault==4) {hard_guard.remaining=1;isr_hard_stop();}
            else if(fault==5) {missing_rf=true;advance((uint32_t)hard_guard.remaining*RADIO_TX_GUARD_PERIOD_US);}
            else if(fault==6) {live.count=0;live.finished=false;live.header_pos=339;now=live.timing.last_boundary_us+30000u;boundary();}
            else {pcmq.overflow=1;poll_call(true);}
            cleanup();assert(!session_enabled);
        }
        assert_rf_safe();unsigned old_pa=pa_keys;isr_pa();assert(pa_keys==old_pa);assert_rf_safe();
        assert((mock_dac_power&~DAC_B_OFF)==0xa5u);
    }
    // MIC and fixed source share the exact writer/DAC path; microphone/codec
    // work must not change selected-half publication or byte ordering.
    reset();issue("TXWRITER ALT1",false);issue("TXDAC RESTORE",false);
    delayed_model=true;delayed_phase=1;delayed_tail=6;release_after=1000000;
    assert(start_call());run();check_wire();assert_rf_safe();
    assert(delayed_n==wire_n && !delayed_pending && !memcmp(delayed_wire,wire,wire_n));
    assert(codec_inits==1 && encode_calls==encoded && dac_restores==1);
}
typedef struct {bool was_down,dirty;} normal_model;
static void check_normal_wire(void) {
    unsigned bytes=339+encoded/9*216+18;
    assert(wire_n==(bytes+35)/36*36);
    for(unsigned i=0;i<240;++i)assert(wire[i]==0x77);
    assert(!memcmp(wire+240,call_frames.hdu,99));
    for(unsigned u=0;u<encoded/9;++u) {
        uint8_t voice[9][11],ldu[216];
        for(unsigned j=0;j<9;++j)memset(voice[j],u*9+j<pcmq.captured ? (uint8_t)(u*9+j+1) : 0,11);
        p25_live_ldu_template(ldu,(const uint8_t (*)[11])voice,(u&1) ? call_frames.ldu2 : call_frames.ldu1);
        assert(!memcmp(wire+339+u*216,ldu,216));
    }
    assert(!memcmp(wire+339+encoded/9*216,call_frames.tdu,18));
    for(unsigned i=bytes;i<wire_n;++i)assert(wire[i]==0x77);
}
static void normal_step(normal_model *model,bool down) {
    scripted_scan=true;scripted_keys=down ? ptt_mask : 0;mock_ptt_high=!down;
    normal_tick(scripted_keys,&model->was_down,&model->dirty);advance(1000);
}
static normal_model normal_boot_start(bool inhibit,bool raw_high,bool filtered_down) {
    reset();tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;mon_pcm_backend=true;
    p25_preferences p={440075000,440075000,0x293,10,1234567,0,22,inhibit,0};
    pref_flash_forbidden=false;memset(pref_flash_mem,255,sizeof pref_flash_mem);pref_pack(pref_flash_mem,&p,7);
    preferences_restore();assert(pref_store.have && pref_store.seq==7 && owner_tx_inhibit==inhibit);
    pref_flash_reads=pref_flash_writes=pref_flash_erases=0;
    scripted_scan=true;scripted_keys=filtered_down ? ptt_mask : 0;mock_ptt_high=raw_high;
    key_candidate=key_stable=scripted_keys;key_changed_at=now;
    hardware_stop();boot_policy();
    normal_model model={.was_down=filtered_down,.dirty=false};return model;
}
static normal_model normal_boot(bool inhibit,bool held) {
    normal_model model=normal_boot_start(inhibit,!held,held);
    normal_step(&model,held);
    if(!held)for(unsigned i=0;i<50;++i)normal_step(&model,false);
    assert(ptt_release_required==held);return model;
}
static normal_model normal_power_reload(void) {
    reset();tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;mon_pcm_backend=true;
    pref_flash_forbidden=false;preferences_restore();
    scripted_scan=true;scripted_keys=0;mock_ptt_high=true;key_candidate=key_stable=0;key_changed_at=now;
    hardware_stop();boot_policy();normal_model model={0};
    for(unsigned i=0;i<51;++i)normal_step(&model,false);
    assert(!ptt_release_required);
    if(frequency)assert(feature_dmr() ? digital_dmr.running : feature_fm() ? analog_fm.running : mon_running);
    else assert(!digital_dmr.running && !analog_fm.running && !mon_running);
    return model;
}
static void normal_voice_call(normal_model *model,unsigned hold_us) {
    wire_n=source_n=next_rf=0;output_n=0;
    normal_step(model,true);assert(call_active);
    uint32_t started=now;unsigned count=0;
    while(call_active) {normal_step(model,now-started<hold_us);assert(++count<40000);}
    normal_step(model,false);check_normal_wire();assert_rf_safe();
    assert(mon_enabled && mon_running && mon_pcm_backend && !session_enabled && normal_mode);
}
typedef struct {shared_ptt_t gate;uint32_t last_raw,stable,ms;} board_ptt_model;
static void board_ptt_step(normal_model *model,board_ptt_model *input,bool raw_high,bool rx_seen,uint32_t rx_ms) {
    mock_ptt_high=raw_high;scripted_scan=true;
    uint32_t raw=shared_ptt_pressed(&input->gate,!raw_high,rx_seen,rx_ms,input->ms) ? ptt_mask : 0;
    // Same two-consecutive-scan filter as pinned input_dm32.c. The shared-line
    // gate above is the actual upstream implementation, not a test translation.
    if(raw==input->last_raw)input->stable=raw;
    input->last_raw=raw;scripted_keys=input->stable;
    // The idle recorder still produces noise IRQs while this test holds PTT;
    // keep their timestamp alive without injecting unrelated demodulator data.
    if(mon_running)monitor.last_raw_us=now;
    normal_tick(scripted_keys,&model->was_down,&model->dirty);advance(1000);++input->ms;
}
static void test_board_ptt_boot_guard(void) {
    normal_model model=normal_boot_start(false,false,false);
    board_ptt_model input={.ms=1000};
    board_ptt_step(&model,&input,false,false,0);
    assert(!input.stable && !model.was_down && ptt_release_required);
    assert(strstr(drawn_hint,"Release PTT"));
    // The first real board scan reports released despite raw held PTT. After
    // 20ms plus a second scan it reports pressed; neither may become a TX edge.
    for(unsigned i=0;i<2100;++i)board_ptt_step(&model,&input,false,false,0);
    assert(input.stable==ptt_mask && ptt_release_required && !ptt_release_seen);
    assert(!call_active && !pcmq.captured && !encoded && !rf_keys && !pa_keys);
    unsigned flushes=gfx_flushes,clears=hint_clears;
    uint32_t irq_mask=regs[C7_SYS_INTERP_MASK/4];
    // First high scan still has filtered DOWN; only the next scan begins the
    // continuous raw-high AND filtered-release qualification interval.
    board_ptt_step(&model,&input,true,false,0);assert(ptt_release_required && !ptt_release_seen);
    board_ptt_step(&model,&input,true,false,0);assert(ptt_release_seen && ptt_release_required);
    for(unsigned i=0;i<49;++i)board_ptt_step(&model,&input,true,false,0);
    assert(ptt_release_required && gfx_flushes==flushes);
    // One low contact bounce must restart qualification even while the board
    // gate still reports released; a filtered bitmap alone cannot clear it.
    board_ptt_step(&model,&input,false,false,0);assert(!input.stable && !ptt_release_seen);
    for(unsigned i=0;i<50;++i)board_ptt_step(&model,&input,true,false,0);
    assert(ptt_release_required);
    board_ptt_step(&model,&input,true,false,0);assert(!ptt_release_required);
    assert(mon_running && regs[C7_SYS_INTERP_MASK/4]==irq_mask && !rf_keys && !pcmq.captured);
    assert(gfx_flushes==flushes+1 && hint_clears==clears+1 && !strstr(drawn_hint,"PTT"));
    // A genuine new press is accepted after that physical release; normal
    // microphone capture and RF remain available through the same board gate.
    for(unsigned i=0;i<600 && !pa_keys;++i)board_ptt_step(&model,&input,false,false,0);
    assert(call_active && hardware_running && pcmq.captured>=18 && rf_keys==1 && pa_keys==1);
    issue("STOP",true);assert_rf_safe();
    // Recent UART bytes can suppress the filtered PTT for arbitrarily long,
    // but cannot qualify raw LOW as a physical release. Quiet expiry afterward
    // must also not create a boot press.
    model=normal_boot_start(false,false,false);input=(board_ptt_model){.ms=4000};
    for(unsigned i=0;i<200;++i)board_ptt_step(&model,&input,false,true,input.ms);
    assert(!input.stable && input.gate.ignored && ptt_release_required);
    uint32_t last_rx=input.ms-1;
    for(unsigned i=0;i<400;++i)board_ptt_step(&model,&input,false,true,last_rx);
    assert(input.stable==ptt_mask && ptt_release_required && !call_active && !pcmq.captured && !rf_keys);
    // Both clocks wrap independently: the shared-line gate uses milliseconds,
    // while release qualification uses the wrapping microsecond hardware clock.
    model=normal_boot_start(false,true,false);input=(board_ptt_model){.ms=UINT32_MAX-25u};now=UINT32_MAX-25000u;
    for(unsigned i=0;i<50;++i)board_ptt_step(&model,&input,true,false,0);
    assert(ptt_release_required && !call_active && !rf_keys);
    board_ptt_step(&model,&input,true,false,0);assert(!ptt_release_required && mon_running);
    model=normal_boot_start(false,false,false);input=(board_ptt_model){.ms=UINT32_MAX-10u};
    for(unsigned i=0;i<100;++i)board_ptt_step(&model,&input,false,false,0);
    assert(input.stable==ptt_mask && ptt_release_required && !call_active && !pcmq.captured && !rf_keys);
    for(unsigned i=0;i<52;++i)board_ptt_step(&model,&input,true,false,0);
    assert(!ptt_release_required && mon_running);
    reset();
}
static void test_grouped_navigation(void) {
    normal_model model=normal_boot(false,false);
    p25_preferences original=pref_current();
    local_action(ACT_SELECT,false);
    assert(menu_open && menu_page==MENU_ROOT && menu_item==ROOT_OPERATING);
    assert(menu_count()==5 && strstr(drawn_screen,"Operating") && strstr(drawn_screen,"Audio & TX"));
    assert(!ptt_start_requested(true,false));
    local_action(ACT_NAV_UP,false);assert(menu_item==ROOT_TOOLS);
    local_action(ACT_NAV_DOWN,false);assert(menu_item==ROOT_OPERATING);
    for(unsigned i=0;i<ROOT_TOOLS;++i)local_action(ACT_NAV_DOWN,false);
    local_action(ACT_SELECT,false);assert(menu_page==MENU_TOOLS && !menu_item);
    menu_select_index(TOOLS_DIAGNOSTICS);
    assert(menu_page==MENU_DIAGNOSTICS && menu_item==DIAG_STATUS);
    local_action(ACT_NAV_UP,false);assert(menu_item==DIAG_BENCH);
    local_action(ACT_NAV_DOWN,false);assert(menu_item==DIAG_STATUS);
    local_action(ACT_BACK,false);assert(menu_page==MENU_TOOLS && menu_item==TOOLS_DIAGNOSTICS);
    local_action(ACT_BACK,false);assert(menu_page==MENU_ROOT && menu_item==ROOT_TOOLS);
    home();
    // Entering, browsing and cancelling an editor never changes the channel,
    // permission or saved record; even a physical PTT while it is open is ignored.
    choose(MENU_CHANNEL,CHANNEL_RX);
    assert(editing && field==EDIT_RX && edit_from_menu && !menu_open);
    assert(strstr(drawn_screen,"RX frequency") && strstr(drawn_screen,"Current 440.075000 MHz"));
    enter_digits("4410750");
    normal_step(&model,true);normal_step(&model,false);
    assert(!call_active && !pcmq.captured && !rf_keys && !pa_keys);
    local_action(ACT_BACK,false);
    assert(!editing && menu_open && menu_page==MENU_CHANNEL && menu_item==CHANNEL_RX);
    local_action(ACT_BACK,false);assert(menu_page==MENU_ROOT && menu_item==ROOT_CHANNEL);
    choose(MENU_VOICE,VOICE_MIC);enter_digits("42");local_action(ACT_BACK,false);
    assert(!editing && menu_page==MENU_VOICE && menu_item==VOICE_MIC);
    local_action(ACT_BACK,false);assert(menu_page==MENU_AUDIO_TX && menu_item==0);
    local_action(ACT_BACK,false);assert(menu_page==MENU_ROOT && menu_item==ROOT_AUDIO_TX);
    home();normal_step(&model,false);
    p25_preferences unchanged=pref_current();
    assert(!memcmp(&original,&unchanged,sizeof original));
    assert(!pref_dirty && pref_store.seq==7 && !pref_flash_writes);
    // A committed edit returns to its category, still blocks PTT, and persists
    // only the chosen field. Back is required to return to normal operation.
    choose(MENU_VOICE,VOICE_RADIO_ID);enter_digits("123456");local_action(ACT_SELECT,false);
    assert(!editing && menu_open && menu_page==MENU_VOICE && menu_item==VOICE_RADIO_ID);
    assert(control.source_id==123456 && !ptt_start_requested(true,false));
    normal_step(&model,true);normal_step(&model,false);assert(!call_active && !rf_keys && !pa_keys);
    home();normal_step(&model,false);
    assert(pref_store.seq==8 && pref_flash_writes>2);check_stored_profile(8);
    model=normal_power_reload();original.id=123456;unchanged=pref_current();
    assert(!memcmp(&original,&unchanged,sizeof original) && pref_store.seq==8);
    // Menu diagnostics returns to the menu that opened it. The direct P2
    // shortcut returns home; neither entry grants a lab session or keys RF.
    choose(MENU_DIAGNOSTICS,DIAG_STATUS);
    assert(rx_lab && diag_from_menu && !menu_open && !ptt_start_requested(true,false));
    local_action(ACT_BACK,false);
    assert(!rx_lab && menu_open && menu_page==MENU_DIAGNOSTICS && menu_item==DIAG_STATUS);
    choose(MENU_DIAGNOSTICS,DIAG_FRAME_TEST);assert(rx_lab && rx_checked && rx_pass);
    local_action(ACT_BACK,false);
    assert(menu_open && menu_page==MENU_DIAGNOSTICS && menu_item==DIAG_FRAME_TEST);
    home();local_action(ACT_NAV_RIGHT,false);
    assert(rx_lab && !diag_from_menu && !ptt_start_requested(true,false));
    local_action(ACT_BACK,false);
    assert(!rx_lab && !menu_open && !editing && !session_enabled && !armed);
    // P1 starts a home editor; cancellation and saving return home, rather
    // than inheriting an earlier menu-origin editor's navigation destination.
    local_action(ACT_CONTEXT,false);assert(editing && !edit_from_menu);
    local_action(ACT_BACK,false);assert(!editing && !menu_open);
    enter_digits("4400750");local_action(ACT_SELECT,false);
    assert(!editing && !menu_open && !session_enabled && !armed);
    normal_step(&model,false);unchanged=pref_current();
    assert(!memcmp(&original,&unchanged,sizeof original) && pref_store.seq==8);
    assert(!rf_keys && !pa_keys && !pcmq.captured);
    reset();
}
static void test_cached_meters(void) {
    normal_model model=normal_boot(false,false);(void)model;
    // Poll deadlines cross uint32 wrap: ADC is cached for one second and RSSI
    // for 250ms, rather than reading either device during each redraw.
    now=UINT32_MAX-100000u;ui_battery_valid=ui_rssi_valid=false;
    ui_battery_due=ui_rssi_due=now;battery_reads=signal_reads=0;
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,now);
    monitor.raw_head=monitor.raw_tail=0;ui_meters_poll();
    assert(battery_reads==1 && signal_reads==1 && ui_battery_mv==8000 && ui_battery_pct==88);
    p25_ui_view view=ui_view(0);assert(view.rssi_valid && view.rssi_bars==5 && !view.battery_low);
    unsigned flushes=gfx_flushes;screen("HOME");
    assert(gfx_flushes==flushes && battery_reads==1 && signal_reads==1); // RX full redraw stays frozen.
    now+=249999u;ui_meters_poll();assert(battery_reads==1 && signal_reads==1);
    signal_dbm=-74;++now;ui_meters_poll();
    assert(battery_reads==1 && signal_reads==2 && ui_rssi_dbm==-73); // 1dB jitter is suppressed.
    signal_dbm=-96;now+=250000u;ui_meters_poll();assert(signal_reads==3 && ui_rssi_bars==3);
    signal_dbm=20;now+=250000u;ui_meters_poll();assert(signal_reads==4 && !ui_rssi_valid);
    signal_dbm=-110;now+=250000u;ui_meters_poll();
    assert(battery_reads==2 && signal_reads==5 && ui_rssi_valid && ui_rssi_bars==2);
    // Timing-sensitive audio/TX/capture paths must not perform meter I/O even
    // if both cache deadlines have expired.
    ui_battery_due=ui_rssi_due=now;
    for(unsigned busy=0;busy<5;++busy) {
        call_active=busy==0;prepared=busy==1;audio_on=busy==2;
        hardware_running=busy==3;rx_sampling=busy==4;
        ui_meters_poll();assert(battery_reads==2 && signal_reads==5);
    }
    call_active=prepared=audio_on=hardware_running=rx_sampling=false;
    // A raw backlog defers only the modem status transaction. Once drained,
    // the due sample occurs without waiting another 250ms or restarting RX.
    monitor.raw_head=4;ui_meters_poll();assert(battery_reads==3 && signal_reads==5);
    monitor.raw_head=0;ui_meters_poll();assert(battery_reads==3 && signal_reads==6);
    now+=RADIO_SIGNAL_STALE_US;view=ui_view(0);assert(!view.rssi_valid);
    battery=6400;ui_battery_due=now;ui_meters_poll();view=ui_view(0);
    assert(view.battery_low && view.battery_pct==0);
    battery=8200;ui_battery_due=now;ui_meters_poll();view=ui_view(0);
    assert(!view.battery_low && view.battery_pct==100);
    // A receiver restart late in the wrapping microsecond clock must schedule
    // RSSI relative to that restart, not compare its signed deadline with zero.
    now=0x80010000u;unsigned sampled=signal_reads;
    mon_stop("meter_restart");assert(!ui_rssi_valid && !mon_running);
    mon_poll(false);assert(mon_running);ui_meters_poll();
    assert(signal_reads==sampled+1 && ui_rssi_valid);
    assert(mon_running && !rf_keys && !pa_keys && !pcmq.captured && !pref_flash_writes);
    reset();
}
static void test_unified_fm(void) {
    normal_model model=normal_boot(false,false);
    // The mode selector owns the P25-to-FM handoff. Analog controls cannot
    // create invalid wide/tone fields while the channel is still P25.
    choose(MENU_CHANNEL,CHANNEL_FM);assert(menu_page==MENU_CHANNEL && !feature_fm());
    choose(MENU_CHANNEL,CHANNEL_MODE);assert(feature_fm());
    choose(MENU_FM,FM_BANDWIDTH);assert(channel_record[12]&P25_CS_WIDE);
    choose(MENU_FM,FM_SQUELCH);enter_digits("9");local_action(ACT_SELECT,false);
    choose(MENU_FM,FM_TX_TYPE);choose(MENU_FM,FM_RX_TYPE);
    home();normal_step(&model,false);
    assert(analog_fm.running && analog_fm.owned && !mon_running && !pcm_irq_enabled && !callback);
    assert(frontend_mode==RADIO_MODE_FM && analog_fm.config.bandwidth==RADIO_BW_25K);
    assert(analog_fm.config.squelch==9 && analog_fm.config.tx_tone.type==TONE_CTCSS);
    assert(analog_fm.config.rx_tone.type==TONE_CTCSS && !rf_keys && !pa_keys);
    for(unsigned i=0;i<30;++i)normal_step(&model,false);
    assert(analog_audio && analog_fm.audio_open && !(regs[C7_AUDIO_CONTROL/4]&C7_AUDIO_RING_PLAY));
    unsigned encodes=encode_calls,captured=pcmq.captured;
    normal_step(&model,true);
    assert(call_active && hardware_running && analog_fm.transmitting && !analog_audio);
    assert(rf_keys==1 && pa_keys==1 && timers[HARD_TIMER] && applied_mic_gain==11 && mic_gain_db==22);
    assert(encode_calls==encodes && pcmq.captured==captured && !callback && !mock_dmr_keyed);
    for(unsigned i=0;i<20;++i)normal_step(&model,true);
    normal_step(&model,false);
    assert(!call_active && !analog_fm.transmitting && analog_fm.running && !timers[HARD_TIMER]);
    assert_rf_safe();
    // Without a main-loop poll the independent timer still removes PA drive;
    // task cleanup later retunes FM and requires a qualified release.
    normal_step(&model,true);assert(analog_fm.transmitting && hard_at-now<=P25_FM_TX_MAX_US);
    advance((uint32_t)hard_guard.remaining*RADIO_TX_GUARD_PERIOD_US+1u);
    assert(!hardware_running && !call_active && !mock_pa_selected && !mock_dac_drive && (mock_dac_power&DAC_B_OFF));
    normal_step(&model,true);assert(!analog_fm.transmitting && ptt_release_required);assert_rf_safe();
    unsigned keyed=rf_keys;for(unsigned i=0;i<30;++i)normal_step(&model,true);
    assert(rf_keys==keyed && !call_active);
    for(unsigned i=0;i<51;++i)normal_step(&model,false);
    assert(!ptt_release_required);
    normal_step(&model,true);assert(analog_fm.transmitting && rf_keys==keyed+1);
    normal_step(&model,false);assert_rf_safe();
    // Returning to P25 clears FM-only fields and restores codec/PCM ownership.
    choose(MENU_CHANNEL,CHANNEL_MODE);assert(feature_dmr());
    choose(MENU_CHANNEL,CHANNEL_MODE);assert(feature_p25());home();normal_step(&model,false);
    assert(mon_running && mon_pcm_backend && !analog_fm.owned && !analog_audio);
    assert(!(channel_record[12]&P25_CS_WIDE) && !feature_u16(channel_record+26) && !feature_u16(channel_record+28));
    assert(p25_cs_record_valid(feature_key(),channel_record) && !pref_dirty);
    // Receive-only is independent of owner TX permission and survives a reload.
    choose(MENU_CHANNEL,CHANNEL_RX_ONLY);home();normal_step(&model,false);
    assert(!owner_tx_inhibit && !control.tx_enabled && (channel_record[12]&P25_CS_RX_ONLY));
    model=normal_power_reload();assert(mon_running && !control.tx_enabled && !owner_tx_inhibit);
    normal_step(&model,true);normal_step(&model,false);assert(!call_active && !rf_keys && !pa_keys);
    reset();
}
static void test_unified_dmr(void) {
    normal_model model=normal_boot(false,false);
    assert(mon_running && radio_codec_owner()==RADIO_CODEC_P25);
    choose(MENU_CHANNEL,CHANNEL_MODE);assert(feature_fm());
    choose(MENU_CHANNEL,CHANNEL_MODE);assert(feature_dmr());
    choose(MENU_DMR,0);enter_digits("15");local_action(ACT_SELECT,false);
    choose(MENU_DMR,1); // TS2
    choose(MENU_DMR,2); // private
    choose(MENU_DMR,3); // repeater / hotspot
    choose(MENU_VOICE,VOICE_TALKGROUP);enter_digits("16777215");local_action(ACT_SELECT,false);
    unsigned p25_inits=codec_inits;
    home();normal_step(&model,false);
    assert(digital_dmr.running && native_irq_owned && !mon_running && !analog_fm.owned);
    assert(radio_codec_owner()==RADIO_CODEC_DMR && codec_inits==p25_inits);
    assert(radio_dmr_stub.native_inits && radio_dmr_stub.native_enters);
    assert(digital_dmr.config.cc==15 && digital_dmr.config.ts==2);
    assert(digital_dmr.config.target_id==16777215u && digital_dmr.config.source_id==1234567u);
    assert(digital_dmr.config.private_call && digital_dmr.config.rmo && !pref_dirty);
    // New 24-bit channel fields survive the real atomic store and a cold boot.
    model=normal_power_reload();
    assert(feature_dmr() && digital_dmr.running && radio_channel_get_destination(channel_record)==16777215u);
    assert(radio_channel_get_color_code(channel_record)==15 && radio_channel_get_timeslot(channel_record)==2);
    assert(radio_channel_get_private(channel_record) && radio_channel_get_repeater(channel_record));
    output_n=0;issue("STATUS",false);
    assert(strstr(output,"mode=DMR") && strstr(output,"16777215"));
    unsigned encoded_before=encode_calls,captured_before=pcmq.captured;
    p25_inits=codec_inits;
    normal_step(&model,true);
    assert(digital_dmr.tx_armed && call_active && hardware_running && timers[HARD_TIMER]);
    assert(radio_dmr_stub.ptt_starts==1 && !callback && !prepared && !wire_n);
    assert(encode_calls==encoded_before && pcmq.captured==captured_before && codec_inits==p25_inits);
    normal_step(&model,false);
    assert(!call_active && !digital_dmr.tx_armed && digital_dmr.running && !timers[HARD_TIMER]);
    assert(!mon_running && !analog_fm.owned && radio_codec_owner()==RADIO_CODEC_DMR);
    radio_dmr_stub.view.state=DMR_CALL_STATE_RX;radio_dmr_stub.view.phase=DMR_CALL_PHASE_RX_VOICE;
    radio_dmr_stub.view.cc=7;radio_dmr_stub.view.ts=2;
    radio_dmr_stub.view.caller.src=16777215u;radio_dmr_stub.view.caller.dst=12345678u;
    radio_dmr_stub.view.caller.group=false;radio_dmr_stub.view.caller.encrypted=false;++radio_dmr_stub.view.serial;
    p25_ui_view view=ui_view(0);
    assert(view.mode_dmr && !view.mode_fm && view.rx_active && view.private_call);
    assert(view.rx_group==12345678u && view.rx_source==16777215u && view.cc==7 && view.ts==2);
    radio_dmr_stub.view.caller.encrypted=true;view=ui_view(0);assert(view.rx_muted);
    // Leaving DMR stops its audio/IRQs and releases the codec before P25 starts.
    choose(MENU_CHANNEL,CHANNEL_MODE);assert(feature_p25());home();normal_step(&model,false);
    assert(!digital_dmr.owned && !native_irq_owned && mon_running && radio_codec_owner()==RADIO_CODEC_P25);
    assert(radio_dmr_stub.stops && radio_dmr_stub.native_leaves && codec_inits>p25_inits);
    reset();
}
static void test_dmr_tx_display_pacing(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_CHANNEL,CHANNEL_MODE);choose(MENU_CHANNEL,CHANNEL_MODE);home();normal_step(&model,false);
    missing_rf=true; // Native modem is a stub here; do not run P25 slot IRQs.
    unsigned before=gfx_flushes,polls=radio_dmr_stub.polls;
    radio_dmr_stub.view.state=DMR_CALL_STATE_RX;radio_dmr_stub.view.phase=DMR_CALL_PHASE_RX_VOICE;
    radio_dmr_stub.view.cc=7;radio_dmr_stub.view.ts=2;radio_dmr_stub.view.caller.group=false;
    assert(radio_channel_set_color_code(channel_record,3));
    assert(radio_channel_set_timeslot(channel_record,1));
    assert(radio_channel_set_destination(channel_record,10));radio_channel_set_private(channel_record,false);
    drawn_screen[0]=0;
    // A transfer long enough to overflow the native encoder queue is legal
    // before admission, but must not recur during access/voice/ending.
    gfx_delay_us=602000u;normal_step(&model,true);
    assert(digital_dmr.tx_armed && gfx_flushes==before+1);
    assert(strstr(drawn_screen,"TRANSMITTING") && dmr_ui_pending);
    assert(strstr(drawn_screen,"TX CC 3 TS1") && strstr(drawn_screen,"TG 10"));
    assert(dmr_ui_cost.max_us==602000u && radio_dmr_stub.polls==polls+1);
    const uint8_t phases[]={DMR_CALL_PHASE_TX_ACCESS,DMR_CALL_PHASE_TX_WAKEUP,
        DMR_CALL_PHASE_TX_VOICE,DMR_CALL_PHASE_TX_ENDING};
    for(unsigned p=0;p<sizeof phases;++p) {
        radio_dmr_stub.view.phase=phases[p];++radio_dmr_stub.view.serial;
        now+=1000000u;normal_step(&model,true);
        assert(digital_dmr.tx_armed && gfx_flushes==before+1);
        assert(radio_dmr_stub.polls==polls+p+2 && timers[HARD_TIMER]);
    }
    // One idle redraw coalesces all intermediate changes and restores RX.
    gfx_delay_us=0;drawn_screen[0]=0;normal_step(&model,false);
    assert(!digital_dmr.tx_armed && gfx_flushes==before+2 && !dmr_ui_pending);
    assert(!strstr(drawn_screen,"TRANSMITTING") && !timers[HARD_TIMER]);
    dmr_indicator();assert(gfx_flushes==before+2);
    // Physical release while the preview is in flight vetoes the stale edge.
    unsigned starts=radio_dmr_stub.ptt_starts;
    gfx_delay_us=602000u;gfx_release_ptt=true;normal_step(&model,true);
    assert(!digital_dmr.tx_armed && radio_dmr_stub.ptt_starts==starts);
    assert(!timers[HARD_TIMER] && !dmr_ui_pending);
    normal_step(&model,false);
    gfx_delay_us=0;normal_step(&model,true);assert(digital_dmr.tx_armed);
    normal_step(&model,false);
    reset();
}
static void test_dmr_tx_serial_pacing(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_CHANNEL,CHANNEL_MODE);choose(MENU_CHANNEL,CHANNEL_MODE);home();normal_step(&model,false);
    missing_rf=true;output_n=0;output[0]=0;
    // Coalesce status requests arriving on the same pass as accepted PTT.
    host_input="STATUS\nSTATUS\nSTATUS\n";normal_step(&model,true);
    assert(digital_dmr.tx_armed && !output_n && command_deferred==COMMAND_DEFER_STATUS);
    host_input="CHANNEL junk\nSTATUS\n";normal_step(&model,true);
    assert(digital_dmr.tx_armed && normal_mode && !output_n);
    assert(command_deferred==(COMMAND_DEFER_STATUS|COMMAND_DEFER_BUSY));
    command_overflow=true;host_input="\n";normal_step(&model,true);
    assert(!output_n && digital_dmr.tx_armed && !command_overflow);
    // Cancellation still removes native ownership immediately. Its reply waits
    // until the following idle pass; queued STATUS does not delay cancellation.
    host_input="STOP\nSTOP\nCPS HELLO\n";normal_step(&model,true);
    assert(!digital_dmr.owned && !hardware_running && !call_active && !output_n);
    assert(command_deferred&COMMAND_DEFER_STOP_ACK);
    host_input=NULL;normal_step(&model,false);
    assert(!strcmp(output,"OK STOP\r\n") && !(command_deferred&COMMAND_DEFER_STOP_ACK));
    normal_step(&model,false);
    assert(strstr(output,"DMRTX ") && !command_deferred);
    reset();
}
static void assert_dmr_rx_interrupt_path(uint32_t expected_mask) {
    // Both layers are required: enabling the PIC alone leaves deframe and
    // embedded-LC events suppressed inside the modem after hardware_stop().
    assert(regs[C7_SYS_INTERP_MASK/4]==expected_mask);
    assert(regs[C7_SYS_INTERP_CLEAR/4]==UINT32_MAX);
    assert(mock_irq_enabled[IRQ_MODEM_SYS]);
    assert(mock_irq_enabled[IRQ_MODEM_TS_TX]);
    assert(mock_irq_enabled[IRQ_MODEM_TS_RX]);
    assert(mock_irq_enabled[IRQ_MODEM_RF_TX]);
}
static void assert_dmr_interrupts_stopped(void) {
    assert(!regs[C7_SYS_INTERP_MASK/4]);
    assert(!mock_irq_enabled[IRQ_MODEM_SYS]);
    assert(!mock_irq_enabled[IRQ_MODEM_TS_TX]);
    assert(!mock_irq_enabled[IRQ_MODEM_TS_RX]);
    assert(!mock_irq_enabled[IRQ_MODEM_RF_TX]);
}
static void test_dmr_rx_interrupt_handoff(void) {
    normal_model model=normal_boot(false,false);
    assert(mon_running && regs[C7_SYS_INTERP_MASK/4]==(1u<<14));
    // P25's raw recorder owns a different internal interrupt mask. Entering
    // DMR must restore the original board mask, not inherit that recorder mask.
    choose(MENU_CHANNEL,CHANNEL_MODE);choose(MENU_CHANNEL,CHANNEL_MODE);home();
    regs[C7_SYS_INTERP_CLEAR/4]=0;normal_step(&model,false);
    assert(digital_dmr.running && native_irq_owned && !mon_running);
    assert_dmr_rx_interrupt_path(MOCK_NATIVE_SYS_MASK);
    // A saved DMR channel also traverses hardware_stop() during a cold boot.
    model=normal_power_reload();
    assert(feature_dmr() && digital_dmr.running);
    assert_dmr_rx_interrupt_path(MOCK_NATIVE_SYS_MASK);
    // Safe stopping must keep both layers masked; an unowned native entry
    // cannot reopen them. A subsequent legitimate start must recover both.
    radio_dmr_stop(&digital_dmr);assert_dmr_interrupts_stopped();
    unsigned entered=radio_dmr_stub.native_enters;
    __wrap_hrc_dmr_enter();assert(radio_dmr_stub.native_enters==entered);
    assert_dmr_interrupts_stopped();
    regs[C7_SYS_INTERP_CLEAR/4]=0;normal_step(&model,false);
    assert(digital_dmr.running);assert_dmr_rx_interrupt_path(MOCK_NATIVE_SYS_MASK);
    // Prove the restoration uses the board's captured value, rather than a
    // production literal that happens to pass the normal boot fixture.
    radio_dmr_stop(&digital_dmr);
    uint32_t board_mask=MOCK_NATIVE_SYS_MASK|(1u<<14);
    regs[C7_SYS_INTERP_MASK/4]=board_mask;
    __wrap_hrc_dmr_board_init(&modem,&rf_hooks);hardware_stop();
    assert_dmr_interrupts_stopped();normal_step(&model,false);
    assert(digital_dmr.running);assert_dmr_rx_interrupt_path(board_mask);
    // Missing initialization fails acquisition instead of claiming a running,
    // permanently deaf DMR owner. No RF or codec ownership may be retained.
    radio_dmr_stop(&digital_dmr);assert_dmr_interrupts_stopped();
    __wrap_hrc_dmr_board_init(&modem,&rf_hooks);
    unsigned initialized=radio_dmr_stub.native_inits;
    assert(!dmr_acquire(NULL));
    assert(digital_dmr.error==RADIO_DMR_RX_FAILED);
    assert(!native_irq_owned && radio_codec_owner()==RADIO_CODEC_NONE);
    assert(radio_dmr_stub.native_inits==initialized && !rf_keys && !pa_keys);
    assert_dmr_interrupts_stopped();
    reset();
}
static void test_dmr_boot_and_missing_codec(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_CHANNEL,CHANNEL_MODE);choose(MENU_CHANNEL,CHANNEL_MODE);home();normal_step(&model,false);
    assert(feature_dmr() && digital_dmr.running);
    // Simulate cold boot with PTT held, using the same saved DMR channel.
    reset();tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;mon_pcm_backend=true;
    pref_flash_forbidden=false;preferences_restore();scripted_scan=true;scripted_keys=ptt_mask;mock_ptt_high=false;
    hardware_stop();boot_policy();model=(normal_model){.was_down=true};
    for(unsigned i=0;i<100;++i)normal_step(&model,true);
    assert(digital_dmr.running && ptt_release_required && !radio_dmr_stub.ptt_starts && !call_active);
    for(unsigned i=0;i<51;++i)normal_step(&model,false);
    normal_step(&model,true);assert(radio_dmr_stub.ptt_starts==1 && digital_dmr.tx_armed);
    normal_step(&model,false);
    reset();tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;mon_pcm_backend=true;
    pref_flash_forbidden=false;preferences_restore();radio_dmr_stub.codec_present=false;
    scripted_scan=true;scripted_keys=0;mock_ptt_high=true;hardware_stop();boot_policy();model=(normal_model){0};
    normal_step(&model,false);
    assert(feature_dmr() && !digital_dmr.running && !native_irq_owned && !mon_running && !call_active);
    assert(digital_dmr.error==RADIO_DMR_NO_CODEC && !strcmp(ui_state_label(),"AMBE codec required"));
    assert(!rf_keys && !pa_keys && !wire_n && !callback && !encode_calls);
    reset();
}
static void test_dmr_borrowed_evidence_and_commands(void) {
    normal_model model=normal_boot(false,false);
    monitor.trace.frames=3;monitor.trace.hash=0x12345678;assert(mon_used);
    choose(MENU_CHANNEL,CHANNEL_MODE);choose(MENU_CHANNEL,CHANNEL_MODE);home();normal_step(&model,false);
    assert(digital_dmr.running && !mon_used && !strcmp(rx_reason,"dmr_workspace"));
    assert(((uint8_t *)&rx_storage)[0]==0xa7 && !monitor.trace.frames && !rxcap.count);
    output_n=0;issue("STATUS",false);
    assert(digital_dmr.running && strstr(output,"reason=dmr_workspace"));
    assert(!strstr(output,"RXFRAME ") && !strstr(output,"RXTRACE "));
    // Evidence requests stop/drain native ownership before looking at the
    // invalidated capture/trace. Poisoned native state is never exported.
    const char *reads[]={"RXPCM 0 0","RXBITS 0","RXDEMOD CLEAR","RXREAD 0 0"};
    for(unsigned i=0;i<sizeof reads/sizeof reads[0];++i) {
        if(!digital_dmr.running)normal_step(&model,false);
        assert(digital_dmr.running);output_n=0;issue(reads[i],false);
        assert(!digital_dmr.owned && !native_irq_owned && radio_codec_owner()==RADIO_CODEC_NONE);
        assert(!strncmp(output,"ERR ",4) && !strstr(output,"RXDATA ") && !strstr(output,"RXPCM 0 0 "));
    }
    normal_step(&model,false);assert(digital_dmr.running);
    output_n=0;issue("RXCAP 440075000 0",false);
    assert(strstr(output,"OK RXCAP") && rx_job && !digital_dmr.owned && !native_irq_owned);
    assert(!mon_used && !rxcap.count && ((uint8_t *)&rx_storage)[0]==0);
    assert(radio_codec_owner()==RADIO_CODEC_NONE && !rf_keys && !pa_keys);
    rx_end("cancelled");rx_lab=false;
    output_n=0;issue("RADIO",false);normal_step(&model,false);assert(digital_dmr.running);
    output_n=0;issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    assert(strstr(output,"OK RXMON") && !digital_dmr.owned && !native_irq_owned);
    assert(mon_running && mon_used && radio_codec_owner()==RADIO_CODEC_P25);
    assert(!monitor.demod.frames && !monitor.trace.frames && !monitor.raw_overflow);
    reset();
}
static void adapter_scan_channels(const unsigned *slots,unsigned count,unsigned reply,unsigned fixed) {
    feature_pause();uint8_t descriptor[32]={0},map[32]={0};
    memcpy(descriptor,"Test scan",9);descriptor[13]=(uint8_t)reply;
    feature_put16(descriptor+16,fixed);feature_put16(descriptor+18,1000);feature_put16(descriptor+20,2000);
    for(unsigned i=0;i<count;++i)p25_cs_map_set(map,slots[i],true);
    unsigned key=p25_cs_scan_key(0);assert(p25_cs_begin(&channel_store,channel_store.revision));
    assert(p25_cs_stage_write(&channel_store,key,descriptor) && p25_cs_stage_write(&channel_store,key+1u,map));
    uint8_t zero[32]={0};for(unsigned i=2;i<6;++i)assert(p25_cs_stage_write(&channel_store,key+i,zero));
    uint32_t crc;assert(p25_cs_stage_crc(&channel_store,&crc) && p25_cs_commit(&channel_store,crc));
    feature_mirror_store();
}
static void test_vfo_memory_scan(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_MEMORY,MEM_SAVE);enter_digits("1");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    uint8_t memory[32];assert(p25_cs_read(&channel_store,0,memory) && pref_get(memory)==440075000 && !memory[13]);
    enter_digits("4410750");local_action(ACT_SELECT,false);normal_step(&model,false);
    choose(MENU_MEMORY,MEM_SAVE);enter_digits("2");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    assert(p25_cs_read(&channel_store,1,memory) && pref_get(memory)==441075000 && !memory[13]);
    const unsigned slots[]={0,1};adapter_scan_channels(slots,2,2,1);
    choose(MENU_MEMORY,MEM_VFO);normal_step(&model,false);
    assert(feature_vfo()==1 && !feature_memory() && frequency==440075000);
    enter_digits("4460750");local_action(ACT_SELECT,false);normal_step(&model,false);
    choose(MENU_MEMORY,MEM_VFO);normal_step(&model,false);
    assert(!feature_vfo() && !feature_memory() && frequency==441075000);
    choose(MENU_MEMORY,MEM_VFO);normal_step(&model,false);assert(feature_vfo()==1 && frequency==446075000);
    choose(MENU_MEMORY,MEM_VFO);normal_step(&model,false);
    choose(MENU_MEMORY,MEM_RECALL);enter_digits("1");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    assert(!feature_vfo() && feature_memory()==1 && frequency==440075000);
    choose(MENU_MEMORY,MEM_MODE);normal_step(&model,false);
    assert(!feature_memory() && frequency==441075000); // Recall did not overwrite VFO A.
    choose(MENU_SCAN,SCAN_START);normal_step(&model,false);
    assert(channel_scan.running && channel_scan.cursor==0 && frequency==440075000);
    assert(ui_view(0).channel_mode && ui_view(0).channel_number==1);
    now+=1000000u;monitor.last_raw_us=now;normal_step(&model,false);
    assert(channel_scan.cursor==1 && frequency==441075000);
    assert(ui_view(0).channel_number==2);
    normal_step(&model,false);assert(mon_running); // Open the newly selected carrier.
    p25_rx unit={0};receive_unit(&unit,0x293,0,p25_test_hdu);
    receive_unit(&unit,0x293,5,p25_test_ldu1); // Scan holds a classified clear call.
    now+=500000u;monitor.last_raw_us=now;normal_step(&model,false);
    assert(channel_scan.holding && channel_scan.cursor==1);
    now+=1500000u;monitor.last_raw_us=now;normal_step(&model,false);assert(channel_scan.cursor==1);
    now+=501000u;monitor.last_raw_us=now;normal_step(&model,false);
    assert(channel_scan.cursor==0 && frequency==440075000);
    // Fresh PTT stops the single-receiver scan and adopts its current channel;
    // cancelling during preparation still emits no RF and resumes that channel.
    normal_step(&model,true);assert(!channel_scan.running && feature_memory()==1 && call_active);
    normal_step(&model,false);normal_step(&model,false);
    assert(!call_active && mon_running && !rf_keys && !pa_keys);
    check_stored_profile(channel_store.revision);
    model=normal_power_reload();assert(feature_memory()==1 && frequency==440075000);
    choose(MENU_MEMORY,MEM_MODE);normal_step(&model,false);assert(!feature_memory() && frequency==441075000);
    choose(MENU_MEMORY,MEM_VFO);normal_step(&model,false);assert(feature_vfo()==1 && frequency==446075000);
    reset();
}
// Exercise the physical encoder through normal_tick rather than simulating
// NAV_UP/DOWN: wake, locks and PTT guards live above local_action().
static void turn_encoder(normal_model *model,int delta) {
    encoder_delta=delta;normal_step(model,false);assert(!encoder_delta);
}
static void test_frequency_channel_modes(void) {
    normal_model model=normal_boot(false,false);
    // Empty memories cannot claim Channel mode or discard the frequency VFO.
    uint32_t own=frequency;
    choose(MENU_MEMORY,MEM_MODE);home();normal_step(&model,false);
    assert(!feature_memory() && frequency==own && !strcmp(reason,"no_memories"));
    const unsigned slots[]={1,7,32};
    const char *frequencies[]={"4400750","4410750","4460750"};
    for(unsigned i=0;i<3;++i) {
        enter_digits(frequencies[i]);local_action(ACT_SELECT,false);normal_step(&model,false);
        choose(MENU_MEMORY,MEM_SAVE);char number[3];snprintf(number,sizeof number,"%u",slots[i]);
        enter_digits(number);local_action(ACT_SELECT,false);home();normal_step(&model,false);
    }
    enter_digits("4470750");local_action(ACT_SELECT,false);normal_step(&model,false);own=frequency;
    choose(MENU_MEMORY,MEM_MODE);home();normal_step(&model,false);
    assert(feature_memory()==1 && frequency==440075000);
    p25_ui_view view=ui_view(0);assert(view.channel_mode && view.channel_number==1 && !view.active_side);
    turn_encoder(&model,1);assert(feature_memory()==7 && frequency==441075000);
    turn_encoder(&model,1);assert(feature_memory()==32 && frequency==446075000);
    turn_encoder(&model,1);assert(feature_memory()==1);
    turn_encoder(&model,-1);assert(feature_memory()==32);
    turn_encoder(&model,2);assert(feature_memory()==7);
    turn_encoder(&model,-2);assert(feature_memory()==32);
    // A dark screen wakes on the first physical detent; a locked radio never
    // changes the selected channel, including the release of a lock chord.
    radio_lights.screen_on=false;turn_encoder(&model,1);
    assert(radio_lights.screen_on && feature_memory()==32);
    radio_lights.locked=true;turn_encoder(&model,1);assert(feature_memory()==32);
    radio_lights.locked=false;radio_lights.consume_release=false;
    // Channel digits and # choose memory numbers, preserving the VFO and all
    // channel frequencies. Empty/out-of-range requests remain cancelable.
    enter_digits("7");assert(editing && field==EDIT_RECALL && digit_count==1);
    local_action(ACT_SELECT,false);normal_step(&model,false);
    assert(!editing && feature_memory()==7 && frequency==441075000);
    enter_digits("2");local_action(ACT_SELECT,false);assert(editing && feature_memory()==7);
    local_action(ACT_BACK,false);assert(!editing && !menu_open);
    local_action(ACT_CONTEXT,false);enter_digits("33");local_action(ACT_SELECT,false);
    assert(editing && feature_memory()==7);local_action(ACT_BACK,false);
    enter_digits("0");local_action(ACT_SELECT,false);assert(editing && feature_memory()==7);
    local_action(ACT_BACK,false);normal_step(&model,false);
    choose(MENU_MEMORY,MEM_MODE);home();normal_step(&model,false);
    assert(!feature_memory() && frequency==own && !ui_view(0).channel_mode);
    turn_encoder(&model,1);assert(frequency==own+12500u);own=frequency;
    choose(MENU_MEMORY,MEM_MODE);home();normal_step(&model,false);
    assert(feature_memory()==7 && frequency==441075000); // Last channel on A.
    // Both side keys can be assigned the existing wire action without
    // sacrificing A/B ownership or opening a laboratory/test screen.
    for(unsigned key=RADIO_FUNCTION_SK1;key<=RADIO_FUNCTION_SK2;++key) {
        assert(radio_functions_set_action(global_record,(radio_function_key)key,RADIO_FUNCTION_MEMORY));
    }
    pref_state="pending";feature_pause();preferences_poll(false);
    local_action(ACT_MONITOR,false);normal_step(&model,false);assert(!feature_memory() && frequency==own);
    local_action(ACT_AB,false);normal_step(&model,false);assert(feature_memory()==7 && !feature_vfo());
    model=normal_power_reload();assert(feature_memory()==7 && frequency==441075000);
    assert(radio_functions_get_action(global_record,RADIO_FUNCTION_SK1)==RADIO_FUNCTION_MEMORY);
    assert(radio_functions_get_action(global_record,RADIO_FUNCTION_SK2)==RADIO_FUNCTION_MEMORY);
    // An unresolved dirty profile cannot change selection or VFO ownership.
    feature_pause();mic_gain_db=23;pref_state="pending";channel_store.writable=false;pref_store.writable=false;
    turn_encoder(&model,1);assert(feature_memory()==7 && frequency==441075000 && pref_dirty);
    assert(!rf_keys && !pa_keys);reset();
    // Switching from an unconfigured side must enable reception on a valid
    // other side, rather than carrying RX OFF across the A/B selection.
    model=normal_boot(false,false);feature_pause();uint8_t empty[32]={0};
    assert(feature_commit(P25_CS_VFO_A,empty,false));model=normal_power_reload();
    assert(!feature_vfo() && !frequency && !mon_enabled && !mon_running);
    local_action(ACT_AB,false);normal_step(&model,false);
    assert(feature_vfo()==1 && frequency==440075000 && mon_enabled && mon_running);
    assert(!rf_keys && !pa_keys);reset();
}
static void test_scan_read_failure(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_MEMORY,MEM_SAVE);enter_digits("1");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    enter_digits("4410750");local_action(ACT_SELECT,false);normal_step(&model,false);
    choose(MENU_MEMORY,MEM_SAVE);enter_digits("2");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    const unsigned slots[]={0,1};adapter_scan_channels(slots,2,2,1);
    uint8_t prior[32],target[32],record[32];
    assert(p25_cs_read(&channel_store,0,prior) && p25_cs_read(&channel_store,1,target));
    choose(MENU_SCAN,SCAN_START);normal_step(&model,false);
    assert(channel_scan.running && channel_scan.cursor==0 && frequency==440075000);
    // The candidate passes the membership read, but its separate profile load
    // fails. Adopting it must not bind the previous profile to that memory key.
    pref_flash_fail_addr=p25_cs_record_addr(&channel_store,channel_store.active_bank,1);
    pref_flash_fail_match=1;unsigned failed=pref_flash_fail_hits,writes=pref_flash_writes;
    now=channel_scan.due_us;monitor.last_raw_us=now;feature_scan_poll();
    assert(pref_flash_fail_hits==failed+1 && !pref_flash_fail_match && pref_flash_writes==writes);
    pref_flash_fail_addr=0;
    assert(!channel_scan.running && !channel_scan.holding && channel_scan.cursor==0);
    assert(feature_memory()==1 && feature_key()==0 && frequency==440075000 && control.tx_frequency==440075000);
    assert(!memcmp(channel_record,prior,32) && !strcmp(reason,"channel_read_failed"));
    // A subsequent ordinary settings save belongs to the adopted prior memory.
    choose(MENU_VOICE,VOICE_TALKGROUP);enter_digits("11");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    assert(!pref_dirty && control.talkgroup==11);check_stored_profile(channel_store.revision);
    p25_cs_store reopened;assert(p25_cs_open(&reopened,&pref_flash));
    assert(p25_cs_read(&reopened,1,record) && !memcmp(record,target,32));
    assert(p25_cs_read(&reopened,0,record) && p25_cs_get16(record+10)==11 && pref_get(record)==440075000);
    assert(p25_cs_read(&reopened,P25_CS_GLOBAL,record) && record[10+record[9]]==1);
    reset();
}
static void ui_keys_step(normal_model *model,uint32_t keys) {
    scripted_scan=true;scripted_keys=keys;mock_ptt_high=(keys&ptt_mask)==0;
    // Supply the idle recorder's noise-IRQ timestamp while testing input/UI.
    if(mon_running)monitor.last_raw_us=now;
    normal_tick(keys,&model->was_down,&model->dirty);advance(1000);
}
static void test_lights_and_key_lock(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_DISPLAY,DISPLAY_SCREEN);enter_digits("2");local_action(ACT_SELECT,false);
    choose(MENU_DISPLAY,DISPLAY_LIGHT);enter_digits("1");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    assert(radio_lights.screen_seconds==2 && radio_lights.keypad_seconds==1);
    radio_ux_activity(&radio_lights,now,false);
    now+=1100000u;ui_keys_step(&model,0);assert(screen_backlight==80 && !key_backlight);
    now+=1100000u;ui_keys_step(&model,0);assert(!screen_backlight && !key_backlight);
    // The first ordinary press wakes the display without entering a digit.
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,8);
    assert(screen_backlight==80 && key_backlight && !editing && !menu_open);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,8);
    assert(editing && digit_count==1);
    // A single physical star retains its editor backspace action.
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,32);
    assert(editing && !digit_count && !radio_lights.locked);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    local_action(ACT_BACK,false);
    // A single star neither opens a home menu nor alters an open menu.
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,32);
    assert(!menu_open && !editing && !radio_lights.locked);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,2);
    assert(menu_open && menu_page==MENU_ROOT && menu_item==ROOT_OPERATING);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,32);
    assert(menu_open && menu_page==MENU_ROOT && menu_item==ROOT_OPERATING && !radio_lights.locked);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    local_action(ACT_BACK,false);
    // The former hash combination is no longer the lock shortcut.
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<1010;++i)ui_keys_step(&model,2|16);
    assert(!radio_lights.locked && !editing && !menu_open);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<1010;++i)ui_keys_step(&model,2|32);
    assert(radio_lights.locked && !editing && !menu_open);
    assert(strstr(drawn_hint,"Locked / hold OK + *"));
    for(unsigned i=0;i<1010;++i)ui_keys_step(&model,2|32);
    assert(radio_lights.locked);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,2);
    assert(!menu_open);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    normal_voice_call(&model,1000000);
    assert(radio_lights.locked && rf_keys && pa_keys);
    // Hash cannot unlock either; a fresh star chord does, exactly once.
    for(unsigned i=0;i<1010;++i)ui_keys_step(&model,2|16);
    assert(radio_lights.locked);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    for(unsigned i=0;i<1010;++i)ui_keys_step(&model,2|32);
    assert(!radio_lights.locked && !editing && !menu_open);
    for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
    model=normal_power_reload();
    assert(radio_lights.screen_seconds==2 && radio_lights.keypad_seconds==1 && !radio_lights.locked);
    assert(!rf_keys && !pa_keys && !pref_dirty);
    reset();
}
static void test_radio_reception_wakes_display(void) {
    for(unsigned mode=0;mode<3;++mode) {
        normal_model model=normal_boot(false,false);
        for(unsigned step=0;step<mode;++step)choose(MENU_CHANNEL,CHANNEL_MODE);
        home();normal_step(&model,false);
        assert(mode==0 ? mon_running : mode==1 ? analog_fm.running : digital_dmr.running);
        mon_have_sync=false;analog_fm.audio_open=false;
        radio_dmr_stub.view.state=DMR_CALL_STATE_IDLE;
        radio_dmr_stub.view.phase=DMR_CALL_PHASE_IDLE;
        radio_ux_init(&radio_lights,now);
        radio_lights.screen_seconds=2;radio_lights.keypad_seconds=1;radio_lights.locked=true;
        uint32_t key_activity=radio_lights.activity_us;
        now+=3000000u;
        // A full-scale, current RF-strength reading is not valid call/sync
        // evidence and must not wake the screen in any receive mode.
        radio_signal_configure(&ui_strength,(radio_signal_mode)(RADIO_SIGNAL_P25+mode),frequency,now);
        radio_signal_sample(&ui_strength,now,-50);
        ui_rssi_valid=true;ui_rssi_dbm=-50;ui_rssi_bars=5;
        feature_lights();
        assert(!screen_backlight && !key_backlight && radio_lights.locked);
        if(mode==0) {
            // P25 sync evidence has a finite life; an old detection alone
            // cannot hold or wake the screen after the carrier has gone.
            mon_have_sync=true;mon_sync_us=now-400000u;feature_lights();
            assert(!screen_backlight && !key_backlight);
            mon_sync_us=now;
        } else if(mode==1)analog_fm.audio_open=true;
        else {
            radio_dmr_stub.view.state=DMR_CALL_STATE_RX;
            radio_dmr_stub.view.phase=DMR_CALL_PHASE_RX_VOICE;
        }
        feature_lights();
        assert(screen_backlight==80 && !key_backlight);
        assert(radio_lights.locked && !radio_lights.consume_release);
        assert(radio_lights.activity_us==key_activity && radio_lights.screen_activity_us==now);
        // Reception lasting longer than the screen timeout holds only the
        // display. It neither refreshes the keypad timer nor unlocks keys.
        now+=3000000u;if(mode==0)mon_sync_us=now;
        feature_lights();
        assert(screen_backlight==80 && !key_backlight && radio_lights.locked);
        assert(radio_lights.activity_us==key_activity && !radio_lights.consume_release);
        mon_have_sync=false;analog_fm.audio_open=false;
        radio_dmr_stub.view.state=DMR_CALL_STATE_IDLE;
        radio_dmr_stub.view.phase=DMR_CALL_PHASE_IDLE;
        now+=1999999u;feature_lights();assert(screen_backlight==80 && !key_backlight);
        ++now;feature_lights();assert(!screen_backlight && !key_backlight);
        assert(radio_lights.locked && radio_lights.activity_us==key_activity);
        assert(!call_active && !rf_keys && !pa_keys);
        reset();
    }
}
static void test_programming_browse_noop(void) {
    normal_model model=normal_boot(false,false);
    unsigned revision=channel_store.revision;
    uint8_t initial_channel[32],initial_globals[32];
    memcpy(initial_channel,channel_record,32);memcpy(initial_globals,global_record,32);
    pref_flash_reads=pref_flash_writes=pref_flash_erases=0;
    // A real HELLO pauses normal reception and flushes eligible settings before
    // opening its read session. Repeated downloads must not migrate a no-op.
    for(unsigned attempt=0;attempt<4;++attempt) {
        output_n=0;issue("CPS HELLO",false);
        assert(cps_link && !cps_active && !mon_running);
        assert(strstr(output,"CPS HELLO DM32P25 4 256 2 7 "));
        for(unsigned key=0;key<P25_CS_RECORDS;++key) {
            char cmd[32];snprintf(cmd,sizeof cmd,"CPS GET %u",key);
            output_n=0;issue(cmd,false);assert(strstr(output,"CPS DATA "));
            normal_step(&model,false);
        }
        output_n=0;issue("CPS HELLO",false);
        now+=3000001u;normal_step(&model,false);
        assert(!cps_link && !cps_active && mon_running);
        assert(!pref_flash_writes && !pref_flash_erases && channel_store.revision==revision);
    }
    // Browse all root rows and cancel several editors while the actual main
    // loop runs between actions, instead of testing navigation in isolation.
    for(unsigned attempt=0;attempt<4;++attempt) {
        local_action(ACT_SELECT,false);normal_step(&model,false);
        for(unsigned i=0;i<8;++i) {
            local_action(ACT_NAV_DOWN,false);normal_step(&model,false);
        }
        home();normal_step(&model,false);
        choose(MENU_CHANNEL,CHANNEL_RX);enter_digits("4410750");
        local_action(ACT_BACK,false);normal_step(&model,false);
        home();normal_step(&model,false);
        choose(MENU_DISPLAY,DISPLAY_SCREEN);enter_digits("30");
        local_action(ACT_BACK,false);normal_step(&model,false);
        home();normal_step(&model,false);
        assert(!memcmp(initial_channel,channel_record,32) && !memcmp(initial_channel,channel_saved,32));
        assert(!memcmp(initial_globals,global_record,32) && !memcmp(initial_globals,global_saved,32));
        assert(!pref_dirty && channel_store.revision==revision);
        assert(!pref_flash_writes && !pref_flash_erases);
    }
    reset();
}
static void test_programmable_transmit(void) {
    // Menu edits feed all three real controller paths, remain channel-scoped,
    // and survive a storage reopen. Native DMR itself is the established stub.
    for(unsigned mode_index=0;mode_index<3;++mode_index) {
        normal_model model=normal_boot(false,false);
        for(unsigned i=0;i<mode_index;++i)choose(MENU_CHANNEL,CHANNEL_MODE);
        choose(MENU_TRANSMIT,TX_TOT);enter_digits("15");local_action(ACT_SELECT,false);
        assert(!editing && menu_page==MENU_TRANSMIT && feature_tx_tot()==15);
        for(unsigned level=1;level<9;++level) {
            choose(MENU_TRANSMIT,TX_POWER);assert(feature_tx_power()==level);
        }
        home();normal_step(&model,false);
        model=normal_power_reload();
        assert(feature_tx_power()==8 && feature_tx_tot()==15);
        if(mode_index==1)assert(analog_fm.config.power==8 && analog_fm.tx_limit_us==15000000u);
        else if(mode_index==2)assert(digital_dmr.config.power==8 && digital_dmr.config.tot_s==15);
        missing_rf=mode_index==2;
        normal_step(&model,true);assert(call_active);
        if(mode_index<2)assert(tuned_power==8);
        if(mode_index==0) {
            assert(call_capture_frames==750 && call_soft_limit_us==18000000u);
            assert(live.rf_limit_us==20000000u);
            while(!hardware_running)normal_step(&model,true);
        } else assert(hard_guard.remaining==17);
        assert(timers[HARD_TIMER] && hard_at-now<=RADIO_TX_GUARD_PERIOD_US);
        // Force a stopped main task: each one-second IRQ must rearm itself,
        // and only the final tick may remove RF. The IRQ also crosses wrap.
        unsigned initial=hard_guard.remaining;
        missing_rf=true; // Do not introduce unrelated overdue slot boundaries.
        now=hard_at-1u;advance(1);
        assert(hardware_running && hard_guard.remaining==initial-1u && timers[HARD_TIMER]);
        advance((uint32_t)hard_guard.remaining*RADIO_TX_GUARD_PERIOD_US);
        assert(!hardware_running && !call_active && !timers[HARD_TIMER] && !hard_guard.remaining);
        normal_step(&model,true);assert(!call_active);
        normal_step(&model,false);
        if(mode_index<2)assert_rf_safe();
        else assert(!mock_pa_selected && !mock_rf_selected && !mock_dac_drive && !timers[HARD_TIMER]);
        reset();
    }
    normal_model model=normal_boot(false,false);
    // Reject a too-short timeout atomically in the real editor.
    choose(MENU_TRANSMIT,TX_TOT);enter_digits("14");local_action(ACT_SELECT,false);
    assert(editing && feature_tx_tot()==30);local_action(ACT_BACK,false);
    choose(MENU_TRANSMIT,TX_TOT);enter_digits("600");local_action(ACT_SELECT,false);
    home();normal_step(&model,false);assert(feature_tx_tot()==600);
    // The maximum valid selection reaches the PCM producer without reserving
    // a 600-second recording, and its RF watchdog remains a bounded countdown.
    normal_step(&model,true);assert(call_capture_frames==30000 && live.rf_limit_us==605000000u);
    normal_step(&model,false);normal_step(&model,false);assert_rf_safe();
    reset();
    // A normal P25 timeout can be completed by the RF IRQ before the main
    // loop observes it. It must retain the timeout reason and release gate.
    model=normal_boot(false,false);
    choose(MENU_TRANSMIT,TX_TOT);enter_digits("15");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    normal_voice_call(&model,20000000u);
    assert(!strcmp(reason,"time_limit") && pcmq.captured==750 && encoded==756 && ptt_release_required);
    assert(!hard_guard.remaining && !timers[HARD_TIMER]);
    unsigned keyed=rf_keys;
    for(unsigned i=0;i<100;++i)normal_step(&model,true);
    assert(rf_keys==keyed && !call_active);
    for(unsigned i=0;i<51;++i)normal_step(&model,false);
    assert(!ptt_release_required && mon_running);
    reset();
    // A physical release during a slow FM preview vetoes admission before
    // the immediate native FM keying call, just as in the DMR regression.
    model=normal_boot(false,false);choose(MENU_CHANNEL,CHANNEL_MODE);home();normal_step(&model,false);
    gfx_delay_us=602000u;gfx_release_ptt=true;normal_step(&model,true);
    assert(!call_active && !hardware_running && !analog_fm.transmitting && !rf_keys && !pa_keys);
    gfx_delay_us=0;normal_step(&model,false);assert_rf_safe();reset();
}
static void test_broadcast_functions(void) {
    for(unsigned mode_index=0;mode_index<3;++mode_index) {
        normal_model model=normal_boot(false,false);
        for(unsigned i=0;i<mode_index;++i)choose(MENU_CHANNEL,CHANNEL_MODE);
        home();normal_step(&model,false);
        uint8_t original[32];memcpy(original,channel_record,32);
        unsigned old_rf=rf_keys,old_pa=pa_keys;
        // Actual SK1 edge from the board map; retaining it cannot repeat.
        for(unsigned i=0;i<30;++i)ui_keys_step(&model,1u<<8);
        for(unsigned i=0;i<120;++i)ui_keys_step(&model,1u<<8);
        assert(broadcast_show && broadcast.running && mock_bcast_on && mock_bcast_audio);
        assert(mock_bcast_power_ons==1 && mock_bcast_volume==BCAST_VOLUME_MAX && mock_bcast_status.khz==87500);
        assert(!mon_running && !analog_fm.owned && !digital_dmr.owned && !native_irq_owned && !callback);
        for(unsigned i=0;i<30;++i)ui_keys_step(&model,0);
        local_action(ACT_NAV_UP,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
        assert(mock_bcast_status.khz==87550 && broadcast.khz==87550 && mock_bcast_audio);
        local_action(ACT_NAV_DOWN,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
        assert(broadcast.khz==87500);
        unsigned seeks=mock_bcast_seeks;
        local_action(ACT_SELECT,false);normal_step(&model,false);assert(mock_bcast_seeks==seeks);
        local_action(ACT_NAV_RIGHT,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
        assert(mock_bcast_seeks==1 && mock_bcast_seek_up && broadcast.khz==88500);
        local_action(ACT_NAV_LEFT,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
        assert(mock_bcast_seeks==2 && !mock_bcast_seek_up && broadcast.khz==87500);
        // Programming-plug activity / idle host has no bearing on tuner life.
        host_input=NULL;for(unsigned i=0;i<2200;++i)normal_step(&model,false);
        local_action(ACT_BACK,false);normal_step(&model,false);
        assert(!broadcast_show && !broadcast.owned && !mock_bcast_on && !mock_bcast_audio);
        assert(!memcmp(original,channel_record,32) && frequency==440075000 && !owner_tx_inhibit);
        assert(mode_index==0 ? mon_running : mode_index==1 ? analog_fm.running : digital_dmr.running);
        // PTT leaves the tuner with a release guard; it must never turn that
        // same held key into an implicit channel transmission.
        local_action(ACT_MONITOR,false);normal_step(&model,false);assert(broadcast_show);
        normal_step(&model,true);assert(!broadcast_show && ptt_release_required && !call_active);
        for(unsigned i=0;i<200;++i)normal_step(&model,true);
        assert(!call_active && rf_keys==old_rf && pa_keys==old_pa);
        for(unsigned i=0;i<51;++i)normal_step(&model,false);
        assert(!ptt_release_required);
        // Host RADIO is refused while the tuner owns audio; STOP returns to
        // the saved radio first. A programming read pauses ownership directly.
        local_action(ACT_MONITOR,false);normal_step(&model,false);assert(broadcast_show);
        output_n=0;issue("RADIO",false);assert(strstr(output,"ERR broadcast") && broadcast_show);
        issue("STOP",false);normal_step(&model,false);assert(!broadcast_show && !broadcast.owned);
        local_action(ACT_MONITOR,false);normal_step(&model,false);assert(broadcast_show);
        output_n=0;issue("CPS HELLO",false);assert(strstr(output,"CPS HELLO DM32P25 4 ") && !broadcast.owned);
        now+=3000001u;normal_step(&model,false);assert(!cps_link && !broadcast_show);
        assert(mode_index==0 ? mon_running : mode_index==1 ? analog_fm.running : digital_dmr.running);
        assert(rf_keys==old_rf && pa_keys==old_pa);
        reset();
    }
    normal_model model=normal_boot(false,false);
    choose(MENU_TOOLS,TOOLS_BCAST_FREQ);enter_digits("1017000");local_action(ACT_SELECT,false);
    home();normal_step(&model,false);model=normal_power_reload();
    assert(radio_functions_get_broadcast_khz(global_record)==101700);
    local_action(ACT_MONITOR,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
    assert(broadcast.khz==101700 && mock_bcast_audio);
    // A failed tuner start has a visible exit and does not sacrifice the
    // retained P25 profile or leave either transmitter/audio producer active.
    local_action(ACT_BACK,false);normal_step(&model,false);mock_bcast_available=false;
    local_action(ACT_MONITOR,false);normal_step(&model,false);
    assert(!broadcast.running && !call_active && !rf_keys && !pa_keys);
    local_action(ACT_BACK,false);normal_step(&model,false);assert(mon_running && !broadcast.owned);
    reset();
}
static void test_button_assignments(void) {
    normal_model model=normal_boot(false,false);
    choose(MENU_MEMORY,MEM_SAVE);enter_digits("1");local_action(ACT_SELECT,false);home();normal_step(&model,false);
    // P1 defaults to memory/VFO; P2 remains operational status; SK2 is A/B.
    local_action(ACT_NAV_LEFT,false);normal_step(&model,false);assert(feature_memory()==1);
    local_action(ACT_NAV_LEFT,false);normal_step(&model,false);assert(!feature_memory());
    local_action(ACT_NAV_RIGHT,false);assert(rx_lab);local_action(ACT_BACK,false);
    unsigned initial_vfo=feature_vfo();local_action(ACT_AB,false);normal_step(&model,false);
    assert(feature_vfo()==(initial_vfo^1u));
    // Explicit Disabled is different from the stored zero/default shortcut.
    choose(MENU_FUNCTIONS,FUNCTIONS_SK1);home();normal_step(&model,false);
    assert(radio_functions_get_action_raw(global_record,RADIO_FUNCTION_SK1)==RADIO_FUNCTION_NONE);
    local_action(ACT_MONITOR,false);normal_step(&model,false);assert(!broadcast_show && mon_running);
    // Cycle P1 through every wire action and wrap to the original default.
    for(unsigned action=1;action<RADIO_FUNCTION_COUNT;++action) {
        choose(MENU_FUNCTIONS,FUNCTIONS_P1);
        assert(radio_functions_get_action_raw(global_record,RADIO_FUNCTION_P1)==action);
    }
    choose(MENU_FUNCTIONS,FUNCTIONS_P1);assert(!radio_functions_get_action_raw(global_record,RADIO_FUNCTION_P1));
    // Remap P1 to power and P2 to broadcast using the same menu a user sees.
    for(unsigned i=0;i<RADIO_FUNCTION_POWER;++i)choose(MENU_FUNCTIONS,FUNCTIONS_P1);
    for(unsigned i=0;i<RADIO_FUNCTION_BROADCAST;++i)choose(MENU_FUNCTIONS,FUNCTIONS_P2);
    home();normal_step(&model,false);model=normal_power_reload();
    unsigned level=feature_tx_power();local_action(ACT_NAV_LEFT,false);
    assert(feature_tx_power()==(level+1u)%board.power_count);
    local_action(ACT_NAV_RIGHT,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
    assert(broadcast_show && mock_bcast_audio);
    unsigned seeks=mock_bcast_seeks;
    local_action(ACT_NAV_RIGHT,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
    assert(broadcast_show && mock_bcast_seeks==seeks+1 && mock_bcast_seek_up);
    local_action(ACT_NAV_LEFT,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
    assert(broadcast_show && mock_bcast_seeks==seeks+2 && !mock_bcast_seek_up);
    assert(feature_tx_power()==(level+1u)%board.power_count && !rx_lab);
    local_action(ACT_BACK,false);normal_step(&model,false);assert(!broadcast_show && mon_running);
    assert(!rf_keys && !pa_keys && !pcmq.captured);
    reset();
}
static void broadcast_input(const char *text) {
    for(;*text;++text)local_action(*text=='#' ? ACT_CONTEXT : ACT_DIGIT_0+*text-'0',false);
}
static void test_broadcast_keypad(void) {
    normal_model model=normal_boot(false,false);
    local_action(ACT_MONITOR,false);for(unsigned i=0;i<120;++i)normal_step(&model,false);
    assert(broadcast_show && broadcast.audio_open && mock_bcast_audio);
    const char *inputs[]={"87#5","101#7","875","1017","10175","1017000","108","65"};
    const uint32_t expected[]={87500,101700,87500,101700,101750,101700,108000,65000};
    for(unsigned i=0;i<sizeof inputs/sizeof *inputs;++i) {
        uint32_t before=broadcast.khz;unsigned tunes=mock_bcast_tunes;
        broadcast_input(inputs[i]);
        assert(editing && field==EDIT_BCAST && broadcast_show && broadcast.khz==before);
        assert(mock_bcast_audio && mock_bcast_tunes==tunes && !mon_running);
        local_action(ACT_SELECT,false);assert(!editing && broadcast_show);
        for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
        assert(broadcast.khz==expected[i] && mock_bcast_audio);
        assert(radio_functions_get_broadcast_khz(global_record)==expected[i]);
        assert(!rf_keys && !pa_keys && !pcmq.captured);
    }
    // A fast entry during an asynchronous seek stays editable; OK must wait
    // rather than drop the draft, send a second tuner command or persist it.
    mock_bcast_hold=true;local_action(ACT_NAV_RIGHT,false);
    for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
    unsigned tunes=mock_bcast_tunes;broadcast_input("87#5");local_action(ACT_SELECT,false);
    assert(editing && broadcast.busy && !strcmp(reason,"broadcast_busy") && mock_bcast_tunes==tunes);
    mock_bcast_hold=false;for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
    assert(editing && !broadcast.busy && mock_bcast_audio);
    local_action(ACT_SELECT,false);for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
    assert(!editing && broadcast.khz==87500 && mock_bcast_audio);
    // Off-band/off-grid input leaves both the playing station and saved
    // frequency untouched. Back cancels input before it can leave the tuner.
    const char *invalid[]={"64#95","108#05","101#71","9999"};
    for(unsigned i=0;i<sizeof invalid/sizeof *invalid;++i) {
        uint32_t before=broadcast.khz,saved=radio_functions_get_broadcast_khz(global_record);
        unsigned tunes=mock_bcast_tunes,writes=pref_flash_writes;
        broadcast_input(invalid[i]);local_action(ACT_SELECT,false);
        for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
        assert(editing && broadcast_show && !strcmp(reason,"invalid_frequency"));
        assert(broadcast.khz==before && radio_functions_get_broadcast_khz(global_record)==saved);
        assert(mock_bcast_tunes==tunes && pref_flash_writes==writes && mock_bcast_audio);
        local_action(ACT_BACK,false);assert(!editing && broadcast_show && mock_bcast_audio);
    }
    // Star edits only the draft; a cancelled entry never retunes. The keypad
    // decimal marker itself is stored as '.', not a hidden scale conversion.
    broadcast_input("101#7");assert(editing && digit_count==5 && !memcmp(frequency_digits,"101.7",5));
    local_action(ACT_QUICK,false);assert(digit_count==4 && !memcmp(frequency_digits,"101.",4));
    local_action(ACT_DIGIT_5,false);local_action(ACT_SELECT,false);
    for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
    assert(!editing && broadcast.khz==101500 && mock_bcast_audio);
    broadcast_input("87#5");local_action(ACT_BACK,false);
    assert(!editing && broadcast_show && broadcast.khz==101500);
    local_action(ACT_BACK,false);normal_step(&model,false);
    assert(!broadcast_show && mon_running);
    local_action(ACT_MONITOR,false);for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
    assert(broadcast.khz==101500 && mock_bcast_audio);
    // Seek keys override entry and home assignments, clear the draft and seek.
    for(unsigned key=0;key<2;++key) {
        broadcast_input("101#7");unsigned seeks=mock_bcast_seeks;
        local_action(key ? ACT_NAV_RIGHT : ACT_NAV_LEFT,false);
        assert(!editing && !digit_count && broadcast_show && mock_bcast_seeks==seeks+1);
        for(unsigned tick=0;tick<120;++tick)normal_step(&model,false);
        assert(mock_bcast_seek_up==(key!=0) && mock_bcast_audio);
    }
    // A held PTT, STOP or CPS read cannot strand the manual editor or cause a
    // stale draft to become an RX/TX frequency when channel listening returns.
    broadcast_input("101#7");normal_step(&model,true);
    assert(!editing && !digit_count && !broadcast_show && !broadcast.owned && ptt_release_required);
    for(unsigned tick=0;tick<100;++tick)normal_step(&model,true);
    assert(!call_active && !rf_keys && !pa_keys);
    for(unsigned tick=0;tick<51;++tick)normal_step(&model,false);
    assert(!ptt_release_required && mon_running);
    local_action(ACT_MONITOR,false);normal_step(&model,false);broadcast_input("101#7");
    issue("STOP",false);normal_step(&model,false);
    assert(!editing && !digit_count && !broadcast_show && mon_running);
    local_action(ACT_MONITOR,false);normal_step(&model,false);broadcast_input("101#7");
    output_n=0;issue("CPS HELLO",false);
    assert(strstr(output,"CPS HELLO DM32P25 4 ") && !editing && !digit_count && !broadcast_show);
    now+=3000001u;normal_step(&model,false);assert(mon_running && !cps_link && frequency==440075000);
    // The saved Functions editor accepts the same MHz/compact forms and then
    // restores its own menu; it never powers the broadcast receiver by itself.
    choose(MENU_TOOLS,TOOLS_BCAST_FREQ);broadcast_input("87#5");local_action(ACT_SELECT,false);
    assert(!editing && menu_open && menu_page==MENU_TOOLS && !broadcast_show);
    assert(radio_functions_get_broadcast_khz(global_record)==87500);
    home();normal_step(&model,false);model=normal_power_reload();
    assert(radio_functions_get_broadcast_khz(global_record)==87500 && mon_running);
    local_action(ACT_MONITOR,false);normal_step(&model,false);broadcast_input("101#7");
    local_action(ACT_MONITOR,false);normal_step(&model,false);
    assert(!editing && !digit_count && !broadcast_show && mon_running);
    assert(!rf_keys && !pa_keys);
    reset();
}
static void test_communications_bands(void) {
    assert(board_in_band(100000000,false) && board_in_band(120000000,false));
    assert(!channel_in_band(100000000,false) && !channel_in_band(120000000,false));
    for(unsigned mode_index=0;mode_index<3;++mode_index) {
        normal_model model=normal_boot(false,false);
        for(unsigned i=0;i<mode_index;++i)choose(MENU_CHANNEL,CHANNEL_MODE);
        home();normal_step(&model,false);
        uint8_t original[32];memcpy(original,channel_record,32);
        choose(MENU_CHANNEL,CHANNEL_RX);enter_digits("1200000");local_action(ACT_SELECT,false);
        assert(editing && frequency==440075000 && !memcmp(original,channel_record,32));
        local_action(ACT_BACK,false);home();normal_step(&model,false);
        unsigned revision=channel_store.revision;
        // Exercise the actual transaction parser, not just its UI guard. The
        // generic storage accepts these RX-only frequencies, but the complete
        // communications image must refuse publication for all three modes.
        for(unsigned hz=100000000u;hz<=120000000u;hz+=20000000u) {
            output_n=0;issue("CPS HELLO",false);assert(strstr(output,"CPS HELLO DM32P25 4 "));
            char line[120];snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
            output_n=0;issue(line,false);assert(strstr(output,"CPS OK BEGIN"));
            uint8_t bad[32];memcpy(bad,original,32);pref_put(bad,hz);bad[12]|=P25_CS_RX_ONLY;
            assert(p25_cs_record_valid(feature_key(),bad));
            int n=snprintf(line,sizeof line,"CPS PUT 11223344 %u ",feature_key());
            for(unsigned i=0;i<32;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02X",bad[i]);
            output_n=0;issue(line,false);assert(strstr(output,"CPS OK PUT"));
            uint32_t crc;assert(p25_cs_stage_crc(&channel_store,&crc));
            snprintf(line,sizeof line,"CPS COMMIT 11223344 %08lX",(unsigned long)crc);
            output_n=0;issue(line,false);assert(strstr(output,"CPS ERR COMMIT"));
            assert(channel_store.revision==revision && !memcmp(original,channel_record,32));
            issue("CPS ABORT 11223344",false);
            now+=3000001u;normal_step(&model,false);assert(!cps_link && !cps_active);
        }
        assert(!rf_keys && !pa_keys);
        reset();
    }
}
static void test_promiscuous_receive(void) {
    // The root receive-filter choice persists PROM independently of TX policy.
    // Exercise both owner values through the real preference ring and reload.
    for(unsigned inhibit=0;inhibit<2;++inhibit) {
        normal_model model=normal_boot(inhibit,false);assert(!rx_promiscuous);
        cycle_filter();assert(rx_promiscuous && !menu_open);normal_step(&model,false);
        assert(pref_store.seq==8 && pref_flash_writes>2 && pref_current().prom_mode==1);check_stored_profile(8);
        model=normal_power_reload();
        assert(rx_promiscuous && owner_tx_inhibit==(bool)inhibit && pref_store.seq==8 && !pref_dirty);
        unsigned writes=pref_flash_writes;
        issue("STOP",false);assert(!normal_mode && rx_promiscuous && owner_tx_inhibit==(bool)inhibit);
        issue("CHANNEL 440075000 440075000 659 10 1234567 22",false);
        assert(rx_promiscuous && owner_tx_inhibit==(bool)inhibit && pref_store.seq==8 && pref_flash_writes==writes);
        issue("RADIO",false);normal_step(&model,false);
        assert(normal_mode && mon_running && rx_promiscuous && owner_tx_inhibit==(bool)inhibit);
        choose(MENU_DIAGNOSTICS,DIAG_BENCH);normal_step(&model,false);
        assert(!normal_mode && !mon_running && rx_promiscuous && owner_tx_inhibit==(bool)inhibit);
        choose(MENU_DIAGNOSTICS,DIAG_BENCH);normal_step(&model,false);
        assert(normal_mode && mon_running && rx_promiscuous && owner_tx_inhibit==(bool)inhibit);
        assert(pref_store.seq==8 && pref_flash_writes==writes);
        cycle_filter();normal_step(&model,false);assert(!rx_promiscuous && pref_store.seq==9);
        model=normal_power_reload();
        assert(!rx_promiscuous && owner_tx_inhibit==(bool)inhibit && pref_store.seq==9);
    }
    normal_model model=normal_boot(false,false);
    p25_channel_frames selected,other;
    assert(p25_channel_build(&selected,0x293,10,1234567) && p25_channel_build(&other,0x2a3,123,123456));
    // Mute only the speaker queue in this call-history test; decoding and the
    // retained payload/PCM trace still use the actual receive adapter.
    mon_audio_enabled=false;
    p25_rx unit={0};unsigned init=codec_inits;
    receive_unit(&unit,0x2a3,5,other.ldu1);
    assert(monitor.rejected==1 && !monitor.voices && codec_inits==init && !mon_have_nac);
    receive_unit(&unit,0x293,0,selected.hdu);
    assert(!monitor.voices && monitor.call.ess_valid && !monitor.call.lc_valid);
    receive_unit(&unit,0x293,5,selected.ldu1);
    assert(monitor.voices==9 && decode_calls==9 && mon_have_nac && mon_call_nac==0x293);
    assert(monitor.trace.frames==9 && monitor.trace.from_hdu);
    receive_unit(&unit,0x293,10,selected.ldu2);
    assert(monitor.voices==18 && decode_calls==18 && monitor.trace.frames==18);
    init=codec_inits;receive_unit(&unit,0x2a3,10,other.ldu2);
    assert(monitor.rejected==2 && monitor.voices==18 && codec_inits==init && mon_call_nac==0x293 && monitor.trace.frames==18);
    cycle_filter();normal_step(&model,false);assert(rx_promiscuous);
    mon_audio_enabled=false;
    receive_unit(&unit,0x2a3,5,other.ldu1);
    assert(!monitor.voices && !monitor.rejected && mon_call_nac==0x2a3 && monitor.call.lc_valid && !monitor.call.ess_valid);
    receive_unit(&unit,0x2a3,10,other.ldu2);
    assert(!monitor.voices && !monitor.trace.frames); // ESS applies to the next pair.
    receive_unit(&unit,0x2a3,5,other.ldu1);
    assert(monitor.voices==9 && monitor.trace.frames==9);
    // A terminator for another NAC cannot close the active PROM call.
    init=codec_inits;receive_unit(&unit,0x293,3,NULL);
    assert(mon_have_nac && mon_call_nac==0x2a3 && !monitor.ending && codec_inits==init);
    // Accepted NAC changes reset predictive history and retained trace rather
    // than inheriting decoder evidence from the previous network.
    mon_tone_phase=123;receive_unit(&unit,0x293,5,selected.ldu1);
    assert(mon_call_nac==0x293 && !monitor.trace.frames && !monitor.trace.from_hdu && !mon_tone_phase);
    receive_unit(&unit,0x293,10,selected.ldu2);assert(!monitor.trace.frames);
    receive_unit(&unit,0x293,5,selected.ldu1);assert(monitor.trace.frames==9);
    receive_unit(&unit,0x293,3,NULL);assert(!mon_have_nac && monitor.ending && !mon_have_sync);
    receive_unit(&unit,0x293,5,selected.ldu1);assert(!monitor.trace.frames && !monitor.trace.from_hdu);
    receive_unit(&unit,0x293,0,selected.hdu);
    assert(!monitor.trace.frames && monitor.trace.from_hdu && !monitor.last_voice_us);
    receive_unit(&unit,0x293,5,selected.ldu1);assert(monitor.trace.frames==9 && monitor.trace.from_hdu);
    now+=600001u;monitor.last_raw_us=now;normal_step(&model,false);
    assert(!mon_have_nac && monitor.ending && !mon_failed);
    receive_unit(&unit,0x293,5,selected.ldu1);assert(!monitor.trace.frames && !monitor.trace.from_hdu);
    receive_unit(&unit,0x293,10,selected.ldu2);assert(!monitor.trace.frames);
    receive_unit(&unit,0x293,5,selected.ldu1);assert(monitor.trace.frames==9);
    reset();
}
static void test_normal_operation(void) {
    reset();tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;mon_pcm_backend=true;
    frequency=control.tx_frequency=0;pref_flash_forbidden=false;memset(pref_flash_mem,255,sizeof pref_flash_mem);
    preferences_restore();boot_policy();normal_model unset={0};normal_step(&unset,false);
    assert(!mon_enabled && !mon_running && !control.tx_enabled && !rf_keys && !pref_store.have);
    normal_step(&unset,true);normal_step(&unset,false);assert(!rf_keys && !pa_keys);
    // Fresh setup uses the default owner permission once the frequency is
    // valid; saving the first channel must not require a second TX-enable step.
    enter_digits("4400750");local_action(ACT_SELECT,false);
    for(unsigned i=0;i<51;++i)normal_step(&unset,false);
    assert(normal_mode && mon_running && !owner_tx_inhibit && !rx_promiscuous && control.tx_enabled);
    normal_step(&unset,true);assert(call_active);
    normal_step(&unset,false);normal_step(&unset,false);assert(!call_active && !rf_keys && mon_running);
    normal_model model=normal_boot(false,false);
    assert(mon_enabled && mon_running && mon_pcm_backend && !session_enabled && normal_mode);
    assert(control.tx_enabled && !control.inhibit && !armed && !tx_fixed && !tx_startup_extra);
    assert(tx_writer==TX_WRITER_ALT1 && tx_dac_restore && !rf_keys && !pa_keys);
    assert((regs[C7_SYS_INTERP_MASK/4]&(1u<<14)) && !pref_flash_writes);
    assert(control.state==RADIO_RX_IDLE);
    p25_rx unit={0};receive_unit(&unit,0x293,0,p25_test_hdu);normal_step(&model,false);
    assert(control.state==RADIO_RX_SYNC);
    unit.duid=5;memcpy(unit.frame,p25_test_ldu1,216);mon_receive(&unit,NULL);normal_step(&model,false);
    assert(control.state==RADIO_RX_VOICE);
    p25_ui_view receiving=ui_view(2);
    assert(receiving.rx_active && receiving.rx_group_valid && receiving.rx_source_valid);
    assert(receiving.rx_nac==0x293 && receiving.rx_group==1 && receiving.rx_source==1);
    assert(receiving.tx_group==10 && receiving.tx_source==1234567 && receiving.display_hz==440075000);
    unit.duid=3;mon_receive(&unit,NULL);normal_step(&model,false);assert(control.state==RADIO_RX_IDLE);
    local_action(ACT_SELECT,false);normal_step(&model,false);
    assert(menu_open && control.state==RADIO_RX_PAUSED && !mon_running);
    local_action(ACT_BACK,false);normal_step(&model,false);
    assert(!menu_open && control.state==RADIO_RX_IDLE && mon_running);
    // Boot-held PTT is never a transmit edge; release then a fresh press is.
    model=normal_boot(false,true);
    for(unsigned i=0;i<30;++i)normal_step(&model,true);
    assert(!call_active && !rf_keys && !pa_keys && ptt_release_required);
    for(unsigned i=0;i<51;++i)normal_step(&model,false);
    assert(!ptt_release_required);
    // Exercise the real speaker ownership transition before standalone PTT.
    int16_t pcm[160]={0};for(unsigned i=0;i<18;++i)assert(mon_pcm_push(&monitor,pcm));
    mon_speaker_step();assert(mon_pcm_pending && pcm_irq_enabled);
    normal_step(&model,true);
    assert(call_active && !mon_running && !mon_pcm_pending && !pcm_irq_enabled);
    unsigned consumed=mon_pcm_consumed;mon_pcm_irq();assert(mon_pcm_consumed==consumed);
    normal_step(&model,false);normal_step(&model,false);
    assert(!call_active && !rf_keys && !pa_keys && mon_running && !strcmp(reason,"released_before_rf"));
    normal_voice_call(&model,1000000);assert(rf_keys==1 && pa_keys==1);
    normal_voice_call(&model,1000000);assert(rf_keys==2 && pa_keys==2);
    assert(!owner_tx_inhibit && !pref_current().tx_inhibit && pref_store.seq==7 && !pref_flash_writes);
    // A held key through the finite limit cannot start another call. The
    // normal owner setting and the saved sequence are independent of the limit.
    model=normal_boot(false,false);output_n=0;normal_step(&model,true);assert(call_active);
    unsigned count=0;while(call_active) {normal_step(&model,true);assert(++count<40000);}
    check_normal_wire();
    unsigned keys=rf_keys;for(unsigned i=0;i<20;++i)normal_step(&model,true);
    assert(rf_keys==keys && !call_active && !owner_tx_inhibit);
    normal_step(&model,false);assert(mon_running && !pref_flash_writes && pref_store.seq==7);
    // Persisted inhibit allows receive but never authorizes PTT, and transient
    // PC commands cannot rewrite that owner setting or append a settings record.
    model=normal_boot(true,false);assert(mon_running && !control.tx_enabled && control.inhibit);
    radio_state inhibited_state=control.state;
    assert(!radio_request_tx(&control,true,false,true) && control.state==inhibited_state);
    control.inhibit=false;assert(!radio_request_tx(&control,true,false,true));control.inhibit=true;
    control.tx_enabled=true;assert(!radio_request_tx(&control,true,false,true));control.tx_enabled=false;
    normal_step(&model,true);normal_step(&model,false);
    assert(!call_active && !rf_keys && !pa_keys && mon_running);
    issue("STOP",false);preferences_poll(false);
    assert(!normal_mode && !mon_enabled && owner_tx_inhibit && pref_store.seq==7 && !pref_flash_writes);
    issue("SESSION 440075000 ALLOW_RF",false);preferences_poll(false);
    assert(session_enabled && !normal_mode && owner_tx_inhibit && pref_current().tx_inhibit);
    issue("STOP",false);issue("ARM 440075000 ALLOW_RF",false);preferences_poll(false);
    assert(armed && owner_tx_inhibit && pref_store.seq==7 && !pref_flash_writes);
    now=arm_until;normal_step(&model,false);assert(!armed && !control.tx_enabled && owner_tx_inhibit);
    // Selecting the retained owner permission is a real settings change once;
    // STOP and diagnostic overrides afterward must not silently persist it.
    model=normal_boot(false,false);toggle_owner_tx();normal_step(&model,false);
    assert(owner_tx_inhibit && pref_current().tx_inhibit && pref_store.seq==8 && pref_flash_writes>2);check_stored_profile(8);
    unsigned saved_writes=pref_flash_writes;
    issue("STOP",false);issue("SESSION 440075000 ALLOW_RF",false);preferences_poll(false);
    assert(owner_tx_inhibit && pref_store.seq==8 && pref_flash_writes==saved_writes);
    // FIXED remains a diagnostic source even when the retained owner permits
    // normal microphone use; only explicit ARM/SESSION grants its RF session.
    model=normal_boot(false,false);issue("STOP",false);
    codec_inits=encode_calls=0;
    issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 1",false);
    normal_step(&model,true);normal_step(&model,false);assert(!call_active && !rf_keys);
    issue("SESSION 440075000 ALLOW_RF",false);normal_step(&model,true);assert(call_active);
    while(call_active)normal_step(&model,true);
    normal_step(&model,false);check_fixed_wire();assert(!owner_tx_inhibit && !pref_flash_writes);
    assert(normal_resume());normal_step(&model,false);
    assert(normal_mode && !tx_fixed && mon_running && mon_pcm_backend && !session_enabled);
    // No calibration/low battery cannot key RF. A setup fault and the hard
    // watchdog require an explicit normal-resume acknowledgement and fresh PTT.
    for(unsigned fault=0;fault<4;++fault) {
        model=normal_boot(false,false);
        if(fault==0)cal=false;else if(fault==1)battery=6000;else if(fault==2)tune=false;
        normal_step(&model,true);
        if(fault<3) {assert(!hardware_running && !rf_keys && !pa_keys);}
        else {
            while(!pa_keys)normal_step(&model,true);
            hard_guard.remaining=1;isr_hard_stop();normal_step(&model,true);assert_rf_safe();
        }
        normal_step(&model,false);unsigned before=rf_keys;
        normal_step(&model,true);normal_step(&model,false);assert(rf_keys==before);
        assert(!owner_tx_inhibit && !pref_current().tx_inhibit && pref_store.seq==7 && !pref_flash_writes);
        cal=tune=true;battery=8000;assert(normal_resume());normal_step(&model,false);
        assert(mon_running && control.tx_enabled);
    }
    // RX failures also latch a visible fault instead of silently becoming an
    // idle radio, and do not change the owner's persisted TX permission.
    for(unsigned fault=0;fault<3;++fault) {
        model=normal_boot(false,false);
        if(fault==0)now+=200001u;
        else if(fault==1)mon_failed=true;
        else {mon_stop("test_restart");tune=false;}
        normal_step(&model,false);
        assert(control.state==RADIO_FAULT && control.inhibit && !control.tx_enabled && !mon_running);
        normal_step(&model,true);normal_step(&model,false);assert(!rf_keys && !pa_keys);
        assert(!owner_tx_inhibit && !pref_current().tx_inhibit && pref_store.seq==7 && !pref_flash_writes);
        tune=true;assert(normal_resume());normal_step(&model,false);
        assert(mon_running && control.state==RADIO_RX_IDLE && control.tx_enabled);
    }
    pref_flash_forbidden=false;reset();
}
#include "test_receive_adapter.h"
static void receive_selected_group_start(void) {
    normal_model model=normal_boot(false,false);
    cycle_filter();normal_step(&model,false);
    cycle_filter();normal_step(&model,false);
    assert(mon_running && rx_tg_filter && !rx_promiscuous && control.talkgroup==10);
    assert(feature_filter()==2 && !pref_dirty);check_stored_profile(channel_store.revision);
    mock_decode_value=1234;
}
static void test_selected_group_receive(void) {
    p25_channel_frames foreign;assert(p25_channel_build(&foreign,0x293,123,42));
    p25_rx unit={0};receive_selected_group_start();
    receive_unit(&unit,0x293,0,foreign.hdu);
    receive_unit(&unit,0x293,5,foreign.ldu1);
    receive_unit(&unit,0x293,10,foreign.ldu2);
    assert(monitor.call.group_valid && monitor.call.group==123 && monitor.rejected>=2);
    receive_no_output();
    // A matching network's foreign talkgroup must not hold the scanner.
    radio_scan_start(&channel_scan,now,0,0);uint32_t due=channel_scan.due_us;
    feature_scan_poll();assert(channel_scan.running && !channel_scan.holding && channel_scan.due_us==due);
    feature_stop_scan(false);
    receive_unit(&unit,0x293,0,call_vector_hdu_clear);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(decode_calls==9 && monitor.voices==9 && monitor.pcm_head!=monitor.pcm_tail);
    // Both terminator forms have no TG identity. They end an accepted call
    // without discarding or decoding its already-qualified speaker tail.
    for(unsigned i=0;i<2;++i) {
        receive_selected_group_start();
        receive_unit(&unit,0x293,0,call_vector_hdu_clear);
        receive_unit(&unit,0x293,5,call_vector_ldu1_group);
        receive_unit(&unit,0x293,10,call_vector_ldu2_clear);
        mon_speaker_step();assert(mon_pcm_pending && pcm_irq_enabled && mon_routed);
        unsigned head=monitor.pcm_head,tail=monitor.pcm_tail,pos=monitor.pcm_pos;
        unsigned inits=codec_inits,rejected=monitor.rejected;
        receive_unit(&unit,0x293,i ? 15 : 3,NULL);
        assert(monitor.ending && !monitor.call.active && !monitor.call.group_valid);
        assert(monitor.pcm_head==head && monitor.pcm_tail==tail && monitor.pcm_pos==pos);
        assert(!monitor.discarded_pcm && monitor.rejected==rejected && codec_inits==inits);
        assert(decode_calls==18 && mon_pcm_pending && pcm_irq_enabled && mon_routed);
        for(unsigned half=0;half<36;++half){now+=10000;mon_pcm_irq();}
        mon_speaker_step();
        assert(monitor.played==18 && mon_pcm_submitted==2880 && mon_pcm_consumed==2880);
        assert(!monitor.starved && !monitor.discarded_pcm && decode_calls==18);
        assert(monitor.pcm_head==monitor.pcm_tail && !mon_pcm_pending && !mon_routed);
    }
    // A wrong-group or unclassifiable new header purges an accepted call's
    // queued PCM, including its half-frame already waiting for the speaker.
    uint8_t unknown[99];memset(unknown,0x55,sizeof unknown);
    const uint8_t *headers[]={foreign.hdu,unknown};
    for(unsigned i=0;i<2;++i) {
        receive_selected_group_start();
        receive_unit(&unit,0x293,0,call_vector_hdu_clear);
        receive_unit(&unit,0x293,5,call_vector_ldu1_group);
        receive_unit(&unit,0x293,10,call_vector_ldu2_clear);
        mon_speaker_step();assert(mon_pcm_pending && pcm_irq_enabled && mon_routed);
        receive_unit(&unit,0x293,0,headers[i]);
        assert(decode_calls==18 && monitor.voices==18 && monitor.discarded_pcm==18);
        assert(monitor.pcm_head==monitor.pcm_tail && !mon_pcm_pending && !pcm_irq_enabled && !mon_routed);
        assert(!i || !monitor.call.group_valid);
    }
    // PROM is selection only: foreign NAC and talkgroup clear voice plays,
    // while the existing independent encrypted/unsupported vectors stay mute.
    receive_gate_start();rx_promiscuous=true;rx_tg_filter=false;
    receive_unit(&unit,0x2a3,0,foreign.hdu);
    receive_unit(&unit,0x2a3,5,foreign.ldu1);
    assert(!monitor.rejected && decode_calls==9 && monitor.voices==9 && monitor.call.group==123);
    const uint8_t *links[]={call_vector_ldu1_group,call_vector_ldu1_vendor};
    for(unsigned i=0;i<2;++i) {
        receive_gate_start();rx_promiscuous=true;rx_tg_filter=false;
        receive_unit(&unit,0x2a3,0,i ? call_vector_hdu_clear : call_vector_hdu_encrypted);
        receive_unit(&unit,0x2a3,5,links[i]);receive_no_output();
        assert(monitor.call.state==(i ? P25_RX_UNSUPPORTED : P25_RX_ENCRYPTED));
    }
    reset();
}
#include "test_scan_adapter.h"
int main(void) {
    assert(tx_writer==TX_WRITER_ALT1 && tx_dac_restore && mon_pcm_backend && !owner_tx_inhibit && !rx_promiscuous);
    test_board_ptt_boot_guard();
    test_grouped_navigation();
    test_cached_meters();
    test_unified_fm();
    test_unified_dmr();
    test_dmr_tx_display_pacing();
    test_dmr_tx_serial_pacing();
    test_dmr_rx_interrupt_handoff();
    test_dmr_boot_and_missing_codec();
    test_dmr_borrowed_evidence_and_commands();
    test_vfo_memory_scan();test_frequency_channel_modes();
    test_scan_read_failure();
    test_lights_and_key_lock();
    test_radio_reception_wakes_display();
    test_programmable_transmit();
    test_broadcast_functions();
    test_button_assignments();
    test_broadcast_keypad();
    test_communications_bands();
    test_programming_browse_noop();
    test_promiscuous_receive();
    test_normal_operation();
    test_receive_qualification();
    test_selected_group_receive();
    test_scan_logical_groups();test_scan_continuous_receiver();
    test_scan_mute_boundaries();test_scan_received_channel_adoption();
    test_scan_unique_carriers();test_scan_acquisition_boundary();test_scan_receiver_ready_dwell();
    test_expanded_channels_zones();test_independent_tg_scan();test_scan_reply_policies();test_scan_cached_hop_reads();
    test_preference_noop();
    // Diagnostic configuration never arms RF, and malformed/busy requests are
    // atomic. It remains separate from retained channel preferences.
    reset();assert(!tx_fixed && tx_pairs==14 && !tx_startup_extra && tx_writer==TX_WRITER_DUP && !tx_dac_restore);
    issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 28",false);issue("TXALIGN 35",false);
    assert(tx_fixed && tx_pairs==28 && tx_startup_extra==35 && !armed && !session_enabled && !rf_keys);
    const char *bad_diag[]={"TXSOURCE","TXSOURCE INVALID","TXSOURCE FIXED1011 extra","TXSOURCE MIC extra","TXSOURCEFIXED1011",
        "TXPAIRS 0","TXPAIRS 29","TXPAIRS -1","TXPAIRS 14 extra","TXPAIRS1","TXPAIRS 4294967297",
        "TXALIGN 36","TXALIGN -1","TXALIGN 1 extra","TXALIGN1","TXALIGN 4294967296",
        "TXWRITER","TXWRITER ALT2","TXWRITER ALT0 extra","TXWRITERALT0","TXWRITER alt0",
        "TXDAC","TXDAC BAD","TXDAC RESTORE extra","TXDACRESTORE","TXDAC keep"};
    for(unsigned i=0;i<sizeof bad_diag/sizeof *bad_diag;++i)reject_tx_diag(bad_diag[i],false);
    const char *diag_commands[]={"TXSOURCE MIC","TXPAIRS 1","TXALIGN 0","TXWRITER ALT1","TXDAC RESTORE"};
    for(unsigned i=0;i<sizeof diag_commands/sizeof *diag_commands;++i) {
        const char *cmd=diag_commands[i];reject_tx_diag(cmd,true);
        armed=true;reject_tx_diag(cmd,false);armed=false;
        session_enabled=true;reject_tx_diag(cmd,false);session_enabled=false;
        call_active=true;reject_tx_diag(cmd,false);call_active=false;
        prepared=true;reject_tx_diag(cmd,false);prepared=false;
        mon_enabled=true;reject_tx_diag(cmd,false);mon_enabled=false;
        mon_running=true;reject_tx_diag(cmd,false);mon_running=false;
        rx_job=true;reject_tx_diag(cmd,false);rx_job=false;
        rx_sampling=true;reject_tx_diag(cmd,false);rx_sampling=false;
        editing=true;reject_tx_diag(cmd,false);editing=false;
        menu_open=true;reject_tx_diag(cmd,false);menu_open=false;
        rx_lab=true;reject_tx_diag(cmd,false);rx_lab=false;
    }
    issue("TXSOURCE MIC",false);assert(!tx_fixed && !tx_startup_extra && tx_pairs==28);
    issue("TXWRITER ALT0",false);issue("TXDAC RESTORE",false);issue("TXSOURCE MIC",false);issue("STOP",false);
    assert(tx_writer==TX_WRITER_ALT0 && tx_dac_restore && !armed && !session_enabled);
    status();assert(strstr(output,"TXPATH writer=ALT0 dac=RESTORE") && strstr(output,"TXPATH ")<strstr(output,"TXDIAG "));
    assert(strstr(output,"TXDIAG ") && strstr(output,"source=MIC"));
    test_writer_and_dac_paths();
    // All physical alignments traverse the actual calibrated board setup,
    // duplicated modem halves and ISR boundary path with current metadata.
    for(unsigned extra=0;extra<36;++extra) {
        reset();control.nac=0x2a3;control.talkgroup=123;control.source_id=123456;
        char cmd[32];snprintf(cmd,sizeof cmd,"TXALIGN %u",extra);
        issue("TXSOURCE FIXED1011",false);issue(cmd,false);issue("SESSION 440075000 ALLOW_RF",false);
        assert(ptt_start_requested(true,false) && !ptt_start_requested(true,true));
        assert(begin_capture() && !audio_on && !callback && !pcmq.accepting);run();
        assert(!strcmp(reason,"complete") && encoded==14*18 && session_enabled && !armed);
        assert(!hardware_running && !pa_started && rf_keys==1 && pa_keys==1);
        check_fixed_wire();assert(!ptt_start_requested(true,true) && ptt_start_requested(true,false));
    }
    // Pair bounds and consecutive fresh presses retain the finite fixed source.
    reset();issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 1",false);issue("TXALIGN 35",false);
    issue("SESSION 440075000 ALLOW_RF",false);
    for(unsigned c=0;c<2;++c) {
        next_rf=wire_n=0;assert(begin_capture());run();check_fixed_wire();
        assert(encoded==18 && session_enabled && tx_fixed && tx_startup_extra==35);
    }
    reset();issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 28",false);
    issue("SESSION 440075000 ALLOW_RF",false);assert(begin_capture());run();check_fixed_wire();assert(encoded==28*18);
    // Releasing before RF keys nothing; later release drains a bounded number
    // of complete pairs, including an odd already-published unit.
    reset();issue("TXSOURCE FIXED1011",false);issue("SESSION 440075000 ALLOW_RF",false);
    assert(begin_capture());poll_call(false);assert(!call_active && !rf_keys && !wire_n);cleanup();
    assert(!strcmp(reason,"released_before_rf") && session_enabled);
    for(unsigned release=100000;release<=700000;release+=100000) {
        reset();issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 28",false);issue("TXALIGN 35",false);
        issue("SESSION 440075000 ALLOW_RF",false);release_after=release;assert(begin_capture());run();
        assert(!strcmp(reason,"complete") && encoded<28*18 && session_enabled);check_fixed_wire();
    }
    // Mic-driver loss is irrelevant when fixed LDUs bypass that driver.
    reset();issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 1",false);
    issue("SESSION 440075000 ALLOW_RF",false);missing_pcm=true;assert(begin_capture());loss=1;run();check_fixed_wire();
    reset();issue("TXSOURCE FIXED1011",false);issue("SESSION 440075000 ALLOW_RF",false);
    assert(begin_capture());while(!hardware_running) {poll_call(true);advance(1000);}
    issue("STOP",true);assert(!call_active && !hardware_running && !session_enabled && !audio_on && !callback);
    reset();issue("TXSOURCE FIXED1011",false);issue("SESSION 440075000 ALLOW_RF",false);
    assert(begin_capture());while(!hardware_running) {poll_call(true);advance(1000);}
    hard_guard.remaining=1;isr_hard_stop();cleanup();assert(!call_active && !hardware_running && !session_enabled && !strcmp(reason,"hard_timeout"));
    reset();issue("TXSOURCE FIXED1011",false);issue("SESSION 440075000 ALLOW_RF",false);
    missing_rf=true;assert(begin_capture());run();assert(!session_enabled && !hardware_running && !strcmp(reason,"rf_timing"));
    for(unsigned fault=0;fault<3;++fault) {
        reset();issue("TXSOURCE FIXED1011",false);issue("SESSION 440075000 ALLOW_RF",false);
        if(fault==0)cal=false;else if(fault==1)battery=6000;else tune=false;
        assert(!begin_capture());cleanup();assert(!rf_keys && !pa_keys && !hardware_running && !callback);
    }
    reset();issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 1",false);
    issue("SESSION 440075000 ALLOW_RF",false);start_ok=false;assert(begin_capture());run();check_fixed_wire();
    // The fixed source shares the normal RX/TX ownership transition: active
    // speaker PCM is stopped before RF, and an enabled monitor can resume.
    reset();issue("TXSOURCE FIXED1011",false);issue("TXPAIRS 1",false);
    issue("RXBACKEND PCM",false);issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    int16_t fixed_pcm[160]={0};
    for(unsigned f=0;f<18;++f)assert(mon_pcm_push(&monitor,fixed_pcm));
    mon_speaker_step();assert(mon_pcm_pending && pcm_irq_enabled);
    codec_inits=0;assert(start_call());
    assert(!mon_running && !mon_pcm_pending && !pcm_irq_enabled && !mon_routed);
    mon_pcm_irq();assert(!mon_pcm_consumed);run();check_fixed_wire();
    mon_poll(false);assert(mon_running && mon_enabled && mon_pcm_backend && !hardware_running);
    // Selecting MIC restores the original no-shift live voice stream and codec.
    reset();issue("TXSOURCE FIXED1011",false);issue("TXALIGN 35",false);issue("TXSOURCE MIC",false);
    release_after=1000000;assert(start_call());run();check_wire();assert(codec_inits==1 && encode_calls==encoded);
    // Native-style PCM transport: distinct signed samples expose half swaps,
    // byte-order mistakes, replay and skipped samples across ring wraps.
    reset();issue("RXBACKEND PCM",false);assert(mon_pcm_backend);
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    issue("RXBACKEND FIFO",false);assert(mon_pcm_backend);
    assert(!timers[SPEAKER_TIMER]);
    for(unsigned f=0;f<18;++f) {
        int16_t pcm[160];for(unsigned i=0;i<160;++i)pcm[i]=(int16_t)(f*160+i-1400);
        assert(mon_pcm_push(&monitor,pcm));
    }
    mon_speaker_step();assert(mon_pcm_pending && mon_pcm_submitted==80 && !mon_pcm_consumed);
    assert(pcm_irq_enabled && (regs[C7_AUDIO_CONTROL/4]&(C7_AUDIO_PCM_SPK|C7_AUDIO_RING_PLAY))==C7_AUDIO_PCM_SPK);
    for(unsigned half=0;half<200;++half) {
        for(unsigned i=0;i<80;++i) {
            uint16_t expected=(uint16_t)(half*80+i-1400);
            assert(speaker_window[2*i]==(uint8_t)expected && speaker_window[2*i+1]==(uint8_t)(expected>>8));
        }
        if(half%2==0 && half<164) {
            unsigned f=18+half/2;int16_t pcm[160];
            for(unsigned i=0;i<160;++i)pcm[i]=(int16_t)(f*160+i-1400);
            assert(mon_pcm_push(&monitor,pcm));
        }
        if(half==198)monitor.ending=true;
        now+=10000;mon_pcm_irq();
    }
    assert(mon_pcm_submitted==16000 && mon_pcm_consumed==16000 && mon_pcm_irqs==200);
    assert(!pcm_irq_enabled && !mon_pcm_pending && monitor.played==100 && !monitor.starved && mon_pcm_gap==10000);
    mon_speaker_step();assert(!mon_routed && !(regs[C7_AUDIO_CONTROL/4]&C7_AUDIO_PCM_SPK));
    issue("STOP",false);unsigned old=mon_pcm_consumed;mon_pcm_irq();assert(mon_pcm_consumed==old);
    issue("RXBACKEND FIFO",false);assert(!mon_pcm_backend);
    reset();issue("RXBACKEND PCM",true);assert(!mon_pcm_backend);
    issue("RXBACKEND PCM extra",false);assert(!mon_pcm_backend);
    issue("RXBACKEND PCM",false);issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    int16_t pcm80test[160]={0};monitor.ending=true;assert(mon_pcm_push(&monitor,pcm80test));
    mon_speaker_step();now+=30001;mon_speaker_step();
    assert(mon_failed && !mon_pcm_pending && !(regs[C7_AUDIO_CONTROL/4]&C7_AUDIO_PCM_SPK));
    issue("STOP",false);assert(!mon_running && !mon_routed);
    // Starvation disables the consumer instead of repeating the last half.
    reset();issue("RXBACKEND PCM",false);issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    monitor.ending=true;assert(mon_pcm_push(&monitor,pcm80test));mon_speaker_step();monitor.ending=false;
    now+=10000;mon_pcm_irq();now+=10000;mon_pcm_irq();
    assert(monitor.starved==1 && !pcm_irq_enabled && !mon_pcm_pending && mon_pcm_consumed==160);
    mon_speaker_step();assert(!mon_routed);
    for(unsigned f=0;f<18;++f)assert(mon_pcm_push(&monitor,pcm80test));
    mon_speaker_step();assert(mon_pcm_pending && pcm_irq_enabled);
    issue("STOP",false);issue("SESSION 440075000 ALLOW_RF",false);
    issue("RXBACKEND FIFO",false);assert(mon_pcm_backend);
    issue("STOP",false);
    reset();issue("RXBACKEND PCM",false);issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    monitor.ending=true;assert(mon_pcm_push(&monitor,pcm80test));mon_speaker_step();
    release_after=1000000;assert(start_call());
    assert(!mon_running && !mon_pcm_pending && !(regs[C7_AUDIO_CONTROL/4]&(C7_AUDIO_PCM_SPK|C7_AUDIO_RING_PLAY)));
    mon_pcm_irq();assert(!mon_pcm_consumed);run();check_wire();
    fm_recorder_calls=0; // Existing recorder tests below keep a cumulative count.
    reset();issue("CHANNEL 440075000 440075000 659 10 1234567 7",false);
    assert(frequency==440075000 && control.talkgroup==10 && control.source_id==1234567 && mic_gain_db==7 && control.inhibit && !session_enabled);
    issue("CHANNEL 440075000 440075000 659 99 1 43",false);assert(control.talkgroup==10 && mic_gain_db==7);
    issue("CHANNEL 440075000 440075000 659 99 1 7 extra",false);assert(control.talkgroup==10);
    issue("CHANNEL 440075000 440075000 659 99 1 7",true);assert(control.talkgroup==10);
    issue("SESSION 440075000 ALLOW_RF",false);
    issue("CHANNEL 440075000 440075000 659 99 1 7",false);assert(control.talkgroup==10);
    release_after=1000000;assert(begin_capture() && applied_mic_gain==7);run();assert(!live.underruns && wire_n>240);
    reset();choose(MENU_VOICE,VOICE_MIC);assert(editing && field==EDIT_MIC);
    local_action(ACT_DIGIT_4,false);local_action(ACT_DIGIT_2,false);local_action(ACT_SELECT,false);assert(!editing && mic_gain_db==42);

    reset(); assert(!begin_capture());
    armed=true; arm_until=now; assert(!begin_capture());
    issue("ARM 440075000 ALLOW_RF",true); assert(!armed);
    issue("ARM 100000000 ALLOW_RF",false); assert(!armed);
    cal=false; issue("ARM 440075000 ALLOW_RF",false); assert(!armed);cal=true;
    battery=6000; issue("ARM 440075000 ALLOW_RF",false);assert(!armed);battery=8000;
    issue("ARM 440075000 ALLOW_RF junk",false);assert(!armed);
    issue("ARM 440075000 ALLOW_RF",false);assert(armed && !hardware_running);
    screen("ARMED / UNPLUG CABLE"); screen("HOLD PTT / SPEAK NOW");
    assert(start_call()); assert(!armed && !hardware_running); run();
    assert(!strcmp(reason,"time_limit") && pcmq.captured==1500 && encoded==1512);
    assert(live.consumed==168 && !live.underruns && !pcmq.overflow && rf_keys==1 && pa_keys==1);
    assert(rf_at-capture_started>=360000); check_wire(); status();
    // Release across all positions of a full LDU pair, including exact boundaries.
    for(unsigned n=0;n<36;++n) {
        reset(); release_after=800000+n*10000;assert(start_call());run();
        assert(!strcmp(reason,"complete") && encoded%18==0 && encoded>=pcmq.captured);check_wire();
    }
    reset(); release_after=100000; assert(start_call());run(); assert(!rf_keys && !wire_n);
    reset(); missing_pcm=true;assert(start_call());run();assert(!strcmp(reason,"pcm_stalled") && !rf_keys);
    reset(); missing_rf=true;assert(start_call());run();assert(!strcmp(reason,"rf_timing"));
    reset(); encode_cost=100000;assert(start_call());run();assert(pcmq.overflow);
    reset();assert(start_call());loss=1;run();assert(!strcmp(reason,"pcm_driver_loss"));
    reset();start_ok=false;assert(!start_call());cleanup();assert(!call_active && !hardware_running);
    reset();tune=false;assert(!start_call());cleanup();assert(!rf_keys);
    reset();assert(start_call());while(!hardware_running) {poll_call(true);advance(1000);}
    issue("STOP",true);assert(!hardware_running && !audio_on && !armed && !call_active);
    reset();assert(start_call());while(!hardware_running) {poll_call(true);advance(1000);}
    hard_guard.remaining=1;isr_hard_stop();assert(!hardware_running && !call_active);cleanup();
    reset(); assert(start_call()); while(!hardware_running) { poll_call(true);advance(1000); }
    assert(hard_at-live.timing.started_us==RADIO_TX_GUARD_PERIOD_US);
    assert(hard_guard.remaining==live.rf_limit_us/1000000u);
    missing_rf=true; now=hard_at-1; advance(1);
    assert(hardware_running && hard_guard.remaining==live.rf_limit_us/1000000u-1u);
    advance((uint32_t)hard_guard.remaining*RADIO_TX_GUARD_PERIOD_US);
    assert(!hardware_running && !call_active && !strcmp(reason,"hard_timeout")); cleanup();
    // One session permits multiple complete calls without serial rearming.
    reset(); issue("SESSION 440075000 ALLOW_RF",true); assert(!session_enabled);
    issue("SESSION 440075000 ALLOW_RF junk",false); assert(!session_enabled);
    issue("SESSION 440075000 ALLOW_RF",false); assert(session_enabled && !armed);
    screen("SESSION READY"); advance(ARM_US+1); // No one-shot idle expiry.
    for(unsigned call=0;call<3;++call) {
        assert(!ptt_start_requested(true,true)); // Held PTT never retriggers.
        assert(ptt_start_requested(true,false));
        next_rf=wire_n=source_n=0;
        release_after=call==1 ? 2200000 : 40000000;
        assert(begin_capture());
        assert(!ptt_start_requested(true,false) && !begin_capture());
        run(); check_wire();
        assert(session_enabled && !armed && !hardware_running && !strcmp(reason,call==1 ? "complete" : "time_limit"));
        if(ptt_release_required) {
            assert(!ptt_start_requested(true,false));mock_ptt_high=true;
            assert(!ptt_release_poll(false));advance(50000u);assert(ptt_release_poll(false));
        }
        screen("SESSION / RELEASE PTT");
    }
    release_after=100000; assert(begin_capture()); run();
    assert(session_enabled && !strcmp(reason,"released_before_rf"));
    issue("STOP",false); assert(!session_enabled && !ptt_start_requested(true,false));
    issue("SESSION 440075000 ALLOW_RF",false); missing_pcm=true; release_after=40000000;
    assert(begin_capture()); run(); assert(!session_enabled);
    reset(); issue("SESSION 440075000 ALLOW_RF",false); assert(begin_capture());
    while(!hardware_running) { poll_call(true); advance(1000); }
    hard_guard.remaining=1;isr_hard_stop(); assert(!session_enabled); cleanup();
    reset(); issue("SESSION 440075000 ALLOW_RF",false);
    issue("ARM 440075000 ALLOW_RF",false); assert(armed && !session_enabled);
    // Unified home: save a valid frequency, explicitly resume owner TX, then
    // use fresh PTT without granting a diagnostic PC session.
    reset(); frequency=0;
    local_action(ACT_SELECT,false); assert(menu_open && !ptt_start_requested(true,false));
    local_action(ACT_BACK,false); assert(!menu_open);
    const char *digits="4400750";
    for(unsigned i=0;i<7;++i) local_action(ACT_DIGIT_0+digits[i]-'0',false);
    assert(editing && digit_count==7 && !hardware_running);
    local_action(ACT_DIGIT_9,false); assert(digit_count==7);
    local_action(ACT_SELECT,false);assert(!editing && frequency==440075000 && !session_enabled);
    home();assert(!ptt_start_requested(true,false));toggle_owner_tx();
    assert(normal_mode && control.tx_enabled && !session_enabled);
    assert(ptt_start_requested(true,false) && !ptt_start_requested(true,true));
    // Invalid or cancelled edits retain the active channel; editing blocks PTT.
    local_action(ACT_CONTEXT,false); assert(editing && !ptt_start_requested(true,false));
    assert(!begin_capture());
    local_action(ACT_DIGIT_1,false); local_action(ACT_SELECT,false);
    assert(editing && !strcmp(reason,"invalid_frequency") && frequency==440075000);
    local_action(ACT_QUICK,false); assert(digit_count==0);
    for(unsigned i=0;i<7;++i) local_action(ACT_DIGIT_9,false);
    local_action(ACT_SELECT,false); assert(editing && frequency==440075000);
    local_action(ACT_BACK,false);assert(!editing && control.tx_enabled && normal_mode && !session_enabled);
    // Menu inhibit is explicit, retained across frequency edits and navigation.
    toggle_owner_tx();
    assert(control.inhibit && !session_enabled && !ptt_start_requested(true,false));
    for(unsigned i=0;i<7;++i) local_action(ACT_DIGIT_0+digits[i]-'0',false);
    local_action(ACT_SELECT,false);assert(!session_enabled && control.inhibit);
    cal=false;toggle_owner_tx();assert(!session_enabled && !control.tx_enabled && owner_tx_inhibit);cal=true;
    battery=6000;toggle_owner_tx();assert(!session_enabled && !control.tx_enabled && owner_tx_inhibit);battery=8000;
    toggle_owner_tx();
    assert(normal_mode && control.tx_enabled && !session_enabled && !control.inhibit);
    // Bounce and held OK cannot perform two distinct actions.
    for(unsigned i=0;i<7;++i) local_action(ACT_DIGIT_0+digits[i]-'0',false);
    keypad_poll(2); advance(10000); keypad_poll(0); advance(10000); keypad_poll(2);
    assert(editing); advance(25000); keypad_poll(2);
    assert(!editing && control.tx_enabled && normal_mode && !session_enabled && !menu_open);
    advance(100000); keypad_poll(2); assert(!menu_open);
    keypad_poll(0); advance(25000); keypad_poll(0);
    keypad_poll(2); advance(25000); keypad_poll(2); assert(menu_open);
    local_action(ACT_BACK,false);
    // Ignore conflicting keys and edits during a call; BACK drains through TDU.
    keypad_poll(0); advance(25000); keypad_poll(0);
    keypad_poll(2|8); advance(25000); keypad_poll(2|8); assert(!editing);
    assert(radio_request_tx(&control,true,false,ptt_start_requested(true,false)));
    assert(begin_capture()); local_action(ACT_DIGIT_1,false); assert(!editing && call_active);
    while(!hardware_running) {poll_call(true);advance(1000);}
    keypad_poll(1|4); advance(25000); keypad_poll(1|4);
    assert(control.cancel && call_active);run();check_wire();
    assert(!call_active && control.tx_enabled && normal_mode && !session_enabled && !hardware_running && !audio_on);
    assert(control.state==RADIO_RX_RESTORE && !control.cancel);
    assert(!ptt_start_requested(true,true));
    // Diagnostics suspends PTT and retains channel/TX inhibit policy on return.
    reset();issue("SESSION 440075000 ALLOW_RF",false);
    local_action(ACT_NAV_RIGHT,false);assert(rx_lab && !ptt_start_requested(true,false));
    local_action(ACT_SELECT,false);assert(rx_checked && rx_pass && !hardware_running);
    local_action(ACT_DIGIT_1,false);assert(!editing);
    local_action(ACT_BACK,false);assert(!rx_lab && session_enabled);
    // Fault cannot be dismissed by merely editing frequency or returning home.
    reason="pcm_stalled";cleanup();assert(control.state==RADIO_FAULT && !session_enabled);
    local_action(ACT_BACK,false); assert(control.state==RADIO_FAULT);
    for(unsigned i=0;i<7;++i) local_action(ACT_DIGIT_0+digits[i]-'0',false);
    local_action(ACT_SELECT,false);assert(!session_enabled && !ptt_start_requested(true,false));
    toggle_owner_tx();
    assert(normal_mode && control.tx_enabled && !session_enabled && control.state==RADIO_RX_RESTORE);
    // Controller enforces direction ownership and rejects config changes mid-call.
    assert(!radio_request_tx(&control,true,true,true));
    assert(radio_request_tx(&control,true,false,true));
    assert(!radio_configure(&control,441000000,true));
    control.state=RADIO_TX_DRAIN;assert(!radio_request_tx(&control,true,false,true));
    radio_complete(&control,false);assert(radio_request_tx(&control,true,false,true));
    // Actual keypad configuration and split TX tuning, including protected frames.
    reset();choose(MENU_CHANNEL,CHANNEL_TX);enter_digits("4450750");local_action(ACT_SELECT,false);
    assert(control.split && frequency==440075000 && control.tx_frequency==445075000);
    choose(MENU_CHANNEL,CHANNEL_NAC);enter_digits("29");local_action(ACT_NAV_UP,false);enter_digits("3");local_action(ACT_SELECT,false);
    assert(control.nac==0x2a3);
    choose(MENU_VOICE,VOICE_TALKGROUP);enter_digits("65535");local_action(ACT_SELECT,false);assert(control.talkgroup==65535);
    choose(MENU_VOICE,VOICE_RADIO_ID);enter_digits("16777215");local_action(ACT_SELECT,false);assert(control.source_id==16777215);
    choose(MENU_VOICE,VOICE_RADIO_ID);enter_digits("16777216");local_action(ACT_SELECT,false);
    assert(editing && control.source_id==16777215);local_action(ACT_BACK,false);
    choose(MENU_VOICE,VOICE_TALKGROUP);enter_digits("0");local_action(ACT_SELECT,false);assert(editing && control.talkgroup==65535);
    local_action(ACT_BACK,false);
    // Frequency saving must preserve split TX; simplex is an explicit menu action.
    home();enter_digits("4410750");local_action(ACT_SELECT,false);
    assert(frequency==441075000 && control.tx_frequency==445075000 && control.split);
    toggle_owner_tx();assert(normal_mode && control.tx_enabled && !session_enabled);
    release_after=1000000;assert(begin_capture());
    assert(tuned_rx==445075000 && tuned_tx==445075000); // TX preparation uses the TX PLL frequency.
    local_action(ACT_CONTEXT,false);assert(!editing);
    issue("SESSION 446000000 ALLOW_RF",false);assert(control.tx_frequency==445075000);
    run();
    assert(!memcmp(wire+240,call_frames.hdu,99));
    assert(!memcmp(wire+339+encoded/9*216,call_frames.tdu,18));
    for(unsigned u=0;u<encoded/9;++u) {
        uint8_t voice[9][11],ldu[216];
        for(unsigned j=0;j<9;++j) memset(voice[j],u*9+j<pcmq.captured ? (uint8_t)(u*9+j+1) : 0,11);
        p25_live_ldu_template(ldu,(const uint8_t (*)[11])voice,(u&1) ? call_frames.ldu2 : call_frames.ldu1);
        assert(!memcmp(wire+339+u*216,ldu,216));
    }
    p25_rx parsed;p25_rx_init(&parsed);unsigned accepted=0;
    for(unsigned i=240;i<wire_n;++i) for(unsigned j=0;j<4;++j)
        if(p25_rx_push(&parsed,(wire[i]>>(6-2*j))&3)) {assert(parsed.nac==0x2a3);++accepted;}
    assert(accepted==encoded/9+2);
    choose(MENU_CHANNEL,CHANNEL_SIMPLEX);assert(!control.split && control.tx_frequency==frequency);
    // Full-scale input over 30 seconds exceeds a 32-bit absolute-sample sum.
    imbe_mic_queue q={0}; q.accepting=true;
    int16_t full[160], consumed_pcm[160];
    for(unsigned i=0;i<160;++i) full[i]=-32768;
    for(unsigned f=0;f<LIVE_CAPTURE_FRAMES;++f) {
        mic_queue_push(&q,full,f*20000u);assert(mic_queue_pop(&q,consumed_pcm));
    }
    assert(q.sum_abs==UINT64_C(7864320000) && q.clipped==240000 && !q.accepting);
    // Actual RX capture adapter: receive-only setup, bounded IRQ snapshots,
    // invalid/duplicate halves, command gating, timeout and cancellation.
    reset();issue("RXCAP 440075000 100",false);
    assert(rx_job && !rx_sampling && !session_enabled && control.inhibit);
    assert(tuned_rx==440075000 && !rf_keys && !pa_keys);
    assert(!ptt_start_requested(true,false) && !begin_capture());
    issue("SESSION 440075000 ALLOW_RF",false);assert(!session_enabled);
    now=rx_due;rx_poll(false);assert(rx_sampling);
    regs[C7_SYS_INTERP_LIST/4]=1u<<14;
    regs[C7_FM_ADDR_SW/4]=0;isr_sys();assert(rxcap.invalid==1 && rxcap.count==0);
    for(unsigned i=0;i<1024;++i)buf[C7_FM_RX_AUDIO+i]=(uint8_t)(i*7);
    for(unsigned i=0;i<RXCAP_BLOCKS;++i) {
        now+=32000;regs[C7_FM_ADDR_SW/4]=(i&1)+1;isr_sys();
    }
    isr_sys();assert(rxcap.count==RXCAP_BLOCKS && !rxcap.accepting);
    assert(!memcmp(rxcap.data[1],buf+C7_FM_RX_AUDIO+512,512));
    assert(RXCAP_BLOCKS==144 && !memcmp(rxcap.data[143],buf+C7_FM_RX_AUDIO+512,512));
    rx_poll(false);assert(!rx_job && !rx_sampling && !strcmp(rx_reason,"complete"));
    assert(!rf_keys && !pa_keys && !rxcap.gaps && !rxcap.repeats && rxcap.maxgap==32000);
    output_n=0;issue("RXREAD 1 7",false);assert(strstr(output,"RXDATA 1 7 "));
    issue("RXREAD 144 0",false);assert(strstr(output,"ERR RXREAD"));
    issue("RXCAP 440075000 0",false);rx_poll(false);now+=RXCAP_TIMEOUT_US+1;rx_poll(false);
    assert(!rx_job && !strcmp(rx_reason,"capture_timeout"));
    issue("RXCAP 440075000 100",false);rx_poll(true);
    assert(!rx_job && !strcmp(rx_reason,"ptt_cancelled"));
    issue("RXCAP 440075000 100",false);local_action(ACT_BACK,false);
    assert(!rx_job && !strcmp(rx_reason,"cancelled"));
    issue("RXPROFILE 1",false);issue("RXCAP 440075000 0",false);rx_poll(false);
    assert(tuned_bw==RADIO_BW_25K && rx_capture_profile==1 && rx_signal_count==1);
    assert(rx_signals[0].dbm==-73 && rx_pin_mic && !rx_pin_source);
    issue("RXPROFILE 0",false);assert(rx_profile==1);
    now+=100000;rx_poll(false);assert(rx_signal_count==2);
    local_action(ACT_BACK,false);output_n=0;issue("RXMETA",false);issue("RXSIGNAL 1",false);
    assert(strstr(output,"RXMETA profile=1 samples=2") && strstr(output,"RXSIGNAL 1 100000 -73 12"));
    issue("RXPROFILE 8",false);assert(rx_profile==1);
    for(unsigned profile=0;profile<8;++profile) {
        char cmd[32];snprintf(cmd,sizeof cmd,"RXPROFILE %u",profile);issue(cmd,false);
        regs[0x128/4]=0x04c03b83;
        issue("RXCAP 440075000 0",false);rx_poll(false);
        assert(rx_capture_profile==profile && control.inhibit && !rf_keys && !pa_keys);
        assert(frontend_mode==((profile&4) ? RADIO_MODE_DMR : RADIO_MODE_FM));
        if(profile&4)assert(regs[C7_WORK_MODE/4]==0x80 && regs[C7_FM_PTT/4]==0);
        assert(tuned_bw==((profile&1) ? RADIO_BW_25K : RADIO_BW_12K5));
        assert(rx_reg_bw==((profile&1 ? 0x4fu : 0x40u)&(profile&2 ? ~0x40u : ~0u)));
        assert(rx_reg_phase==0x04c03b83);
        issue("RXPROFILE 0",false);assert(rx_profile==profile);
        local_action(ACT_BACK,false);assert(frontend_mode==RADIO_MODE_FM);
    }
    assert(fm_recorder_calls==4);
    issue("RXPROFILE 4",false);tune=false;issue("RXCAP 440075000 0",false);
    assert(!rx_job && frontend_mode==RADIO_MODE_FM && control.inhibit && !rf_keys && !pa_keys);
    assert(!strcmp(rx_reason,"tune_failed"));tune=true;
    issue("RXPROFILE 0",false);issue("RXCAP 440075000 0",false);rx_poll(false);
    assert(rx_reg_bw==0x40);local_action(ACT_BACK,false);
    issue("RXPROFILE 0",false);assert(rx_profile==0);
    output_n=0;issue("RXDEMOD CLEAR",false);assert(strstr(output,"ERR RXDEMOD"));
    memset(&rxcap,0,sizeof rxcap);rxcap.count=RXCAP_BLOCKS;
    output_n=0;issue("RXDEMOD CLEAR",true);assert(strstr(output,"ERR RXDEMOD"));
    output_n=0;issue("RXDEMOD CLEAR",false);
    assert(strstr(output,"RXDEMOD units=0 voices=0") && control.inhibit && !session_enabled && !rf_keys && !pa_keys);
    output_n=0;issue("RXDEMOD CLEAR PROFILE",false);
    assert(strstr(output,"RXSTAGES profiled=1") && !rf_keys && !pa_keys);
    rxcap.gaps=1;output_n=0;issue("RXDEMOD CLEAR",false);assert(strstr(output,"ERR RXDEMOD"));
    // Continuous receiver owns the shared storage/codec until stopped for TX.
    reset();output_n=0;issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    assert(mon_running && mon_enabled && mon_used && control.inhibit && !session_enabled);
    assert(monitor.demod.hunt_clock_us==hrc_micros && !monitor.demod.clock_us);
    output_n=0;issue("STATUS",false);assert(strstr(output,"RXHUNT rearms=0"));
    assert(frontend_mode==RADIO_MODE_DMR && regs[C7_FM_BANDWIDTH/4]==0 && !rf_keys && !pa_keys);
    output_n=0;issue("RXCAP 440075000 0",false);assert(strstr(output,"ERR stop RX"));
    regs[C7_SYS_INTERP_LIST/4]=1u<<14;regs[C7_FM_ADDR_SW/4]=1;
    memset(buf+C7_FM_RX_AUDIO,0,1024);now+=32000;isr_sys();mon_poll(false);
    assert(monitor.raw_blocks==1 && monitor.raw_head==monitor.raw_tail);
    p25_rx unit={0};receive_unit(&unit,control.nac,0,p25_test_hdu);
    receive_unit(&unit,control.nac,5,p25_test_ldu1);assert(monitor.voices==9 && !mon_pcm_peek(&monitor));
    receive_unit(&unit,control.nac,10,p25_test_ldu2);assert(monitor.voices==18 && mon_pcm_peek(&monitor));
    regs[C7_AUDIO_CONTROL/4]|=C7_AUDIO_RING_FULL;mon_speaker_step();assert(!monitor.played);
    regs[C7_AUDIO_CONTROL/4]&=~C7_AUDIO_RING_FULL;mon_speaker_step();assert(monitor.played==1);
    unit.nac^=1;mon_receive(&unit,NULL);assert(monitor.rejected==1 && monitor.voices==18);
    unit.nac=control.nac;unit.duid=3;mon_receive(&unit,NULL);assert(monitor.ending);
    mon_poll(true);assert(!mon_running && !mon_routed && !rf_keys && !pa_keys);
    mon_poll(false);assert(mon_running && monitor.voices==0);
    for(unsigned i=0;i<MON_RAW_BLOCKS;++i) {now+=32000;regs[C7_FM_ADDR_SW/4]=(i&1)+1;isr_sys();}
    assert(mon_failed && monitor.raw_overflow==1);mon_poll(false);
    assert(!mon_running && !mon_enabled && !rf_keys && !pa_keys);
    output_n=0;issue("RXDEMOD CLEAR",false);assert(strstr(output,"ERR RXDEMOD"));
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);now+=200001;mon_poll(false);
    assert(!mon_running && !strcmp(mon_reason,"input_timeout"));
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);issue("STOP",false);
    assert(!mon_running && !mon_enabled && control.inhibit);
    issue("RXMON 440075000 CLEAR",false);tune=false;mon_poll(false);
    assert(!mon_running && !mon_enabled && frontend_mode==RADIO_MODE_FM);tune=true;
    // Actual RX -> complete TX -> RX ownership transition, including speaker mute.
    reset();issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    toggle_owner_tx();assert(normal_mode && control.tx_enabled && !session_enabled && !mon_running);mon_poll(false);assert(mon_running);
    release_after=1000000;assert(begin_capture());assert(!mon_running && !mon_routed);
    run();check_wire();assert(!call_active && !prepared && mon_enabled);
    mon_poll(false);assert(mon_running && !monitor.voices && !hardware_running);
    issue("RXMON OFF",false);assert(!mon_running);
    // An IRQ after the clock sample must not cause unsigned timeout underflow.
    reset();issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    inject_rx_clock_irq=true;mon_poll(false);assert(mon_running && !mon_failed);
    inject_rx_clock_irq=false;
    now+=200001;mon_poll(false);assert(!mon_running && !strcmp(mon_reason,"input_timeout"));
    assert(mon_fault_age==200001 && mon_fault_mask==(1u<<14));
    issue("RXAUDIO OFF",false);assert(!mon_audio_enabled);
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    receive_unit(&unit,control.nac,0,p25_test_hdu);
    receive_unit(&unit,control.nac,5,p25_test_ldu1);
    assert(monitor.voices==9 && !monitor.pcm_high && !mon_routed);
    issue("RXAUDIO ON",false);assert(!mon_audio_enabled);
    issue("RXMON OFF",false);issue("RXAUDIO ON",false);assert(mon_audio_enabled);
    // SYNC requires a matching valid unit, expires, and clears on TDU/stop.
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    assert(!mon_sync_active(now));receive_unit(&unit,control.nac^1,0,p25_test_hdu);assert(!mon_sync_active(now));
    receive_unit(&unit,control.nac,0,p25_test_hdu);assert(mon_sync_active(now));
    mon_indicator();assert(mon_badge_sync);
    now+=400000;mon_indicator();assert(!mon_badge_sync);
    now=0xfffffff0u;mon_receive(&unit,NULL);now+=100;assert(mon_sync_active(now));
    unit.duid=3;mon_receive(&unit,NULL);mon_indicator();assert(!mon_sync_active(now));
    unit.duid=0;mon_receive(&unit,NULL);mon_stop("test");assert(!mon_sync_active(now));
    // Trace preserves decoded samples before optional tone substitution.
    reset();issue("RXOUTPUT TONE",false);assert(mon_output_tone);
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    issue("RXOUTPUT DECODED",false);assert(mon_output_tone);
    receive_unit(&unit,control.nac,0,p25_test_hdu);
    receive_unit(&unit,control.nac,5,p25_test_ldu1);
    assert(monitor.trace.frames==9 && monitor.trace.from_hdu);
    assert(monitor.trace.pcm[0][2]==0 && monitor.pcm[0][2]==2000);
    assert(monitor.voices==9 && !rf_keys && !pa_keys);
    output_n=0;issue("RXPCM 0 0",false);assert(strstr(output,"ERR trace"));
    issue("STOP",false);output_n=0;issue("RXPCM 0 0",false);
    assert(strstr(output,"RXPCM 0 0 0 00000000"));
    output_n=0;issue("RXPCM 9 0",false);assert(strstr(output,"ERR RXPCM"));
    output_n=0;issue("RXPCM 0 5",false);assert(strstr(output,"ERR RXPCM"));
    output_n=0;issue("RXBITS 8",false);assert(strstr(output,"RXBITS 8 "));
    output_n=0;issue("RXBITS 9",false);assert(strstr(output,"ERR RXBITS"));
    output_n=0;issue("RXPCM 0 0",true);assert(strstr(output,"ERR trace"));
    issue("RXOUTPUT DECODED",false);assert(!mon_output_tone);
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);assert(!monitor.trace.frames);
    receive_unit(&unit,control.nac,0,p25_test_hdu);
    receive_unit(&unit,control.nac,5,p25_test_ldu1);assert(monitor.pcm[0][2]==0);
    receive_unit(&unit,control.nac,0,p25_test_hdu);assert(!monitor.trace.frames && monitor.trace.from_hdu);
    // Playback retains a wrapped trace, starts only when stopped, and drains once.
    reset();output_n=0;issue("RXMON 440075000 REPLAY",false);assert(strstr(output,"ERR REPLAY"));
    issue("RXTONE 997",false);assert(mon_tone_hz==997);
    issue("RXTONE 999",false);assert(mon_tone_hz==997);
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    issue("RXTONE 1011",false);assert(mon_tone_hz==997);
    for(unsigned f=0;f<120;++f) {
        int16_t samples[160];uint8_t bits[11]={0};
        for(unsigned i=0;i<160;++i)samples[i]=(int16_t)f;
        pcm_trace_record(&monitor.trace,bits,samples);
    }
    uint32_t saved_hash=monitor.trace.hash;
    output_n=0;issue("RXMON 440075000 REPLAY",false);assert(strstr(output,"ERR REPLAY"));
    issue("STOP",false);issue("RXMON 440075000 REPLAY",false);mon_poll(false);
    assert(mon_running && mon_replay && monitor.trace.frames==120 && monitor.trace.hash==saved_hash);
    now+=19998000;monitor.last_raw_us=now;mon_poll(false);mon_speaker_step();assert(!mon_pushes);
    now+=2000;monitor.last_raw_us=now;mon_poll(false);
    assert(mon_local_frames==18 && monitor.pcm[0][0]==8 && monitor.pcm[17][159]==25);
    for(unsigned i=0;mon_running && i<4000;++i) {
        now+=2000;monitor.last_raw_us=now;mon_poll(false);mon_speaker_step();
    }
    assert(!mon_running && !mon_enabled && !strcmp(mon_reason,"replay_complete"));
    assert(monitor.played==112 && mon_pushes==560 && !monitor.voices && !monitor.units);
    assert(monitor.trace.hash==saved_hash && monitor.trace.frames==120 && !monitor.starved);
    assert(!rf_keys && !pa_keys);
    issue("RXMON 440075000 REPLAY",false);mon_poll(false);mon_poll(true);mon_poll(false);
    assert(!mon_running && !mon_enabled && monitor.trace.hash==saved_hash);
    issue("RXTONE 1011",false);assert(mon_tone_hz==1011);
    // The real queue producer advances phase once per enqueued frame, never while full.
    reset();issue("RXTONE 997",false);issue("RXMON 440075000 LOCAL",false);mon_poll(false);
    now+=20000000;monitor.last_raw_us=now;mon_poll(false);
    assert(mon_local_frames==18 && mon_tone_phase==(18u*160u*997u)%8000u);
    assert(memcmp(monitor.pcm[0],monitor.pcm[1],320)!=0);
    uint32_t saved_phase=mon_tone_phase;mon_poll(false);assert(mon_tone_phase==saved_phase);
    issue("STOP",false);assert(!mon_running && !mon_enabled);
    // Sub-tick timer only notifies the task; FIFO and codec work stay outside ISR.
    for(unsigned period=250;period<=500;period+=250) {
        reset();issue(period==250 ? "RXTIMER 250" : "RXTIMER 500",false);
        assert(mon_timer_us==period && !timers[SPEAKER_TIMER]);
        issue("RXTIMER 100",false);assert(mon_timer_us==period);
        issue("RXTIMER 500 extra",false);assert(mon_timer_us==period);
        issue("RXSERVICE 1",true);assert(mon_timer_us==period);
        issue("RXMON 440075000 LOCAL",false);mon_poll(false);
        assert(timers[SPEAKER_TIMER] && timer_period==period);
        issue("RXSERVICE 1",false);assert(mon_timer_us==period);
        now+=20000000;monitor.last_raw_us=now;mon_poll(false);
        unsigned before=mon_pushes;
        mon_speaker_tick();mon_speaker_tick();
        assert(mon_timer_ticks==2 && notify_count==2 && mon_pushes==before);
        assert(ulPortYieldRequired && ulTaskNotifyTake(pdTRUE,0)==2);
        mon_speaker_step();assert(mon_pushes>before);
        mon_poll(true);assert(!mon_running && !timers[SPEAKER_TIMER]);
        mon_speaker_tick();assert(mon_timer_ticks==2 && !notify_count);
        // No pending RX timer can write during the following transmit.
        release_after=1000000;assert(start_call());assert(!timers[SPEAKER_TIMER]);run();check_wire();
        issue("RXSERVICE 1",false);assert(!mon_timer_us && mon_service_ms==1);
    }
    reset();issue("RXTIMER 500",false);tune=false;
    issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    assert(!mon_running && !timers[SPEAKER_TIMER]);
    // A recorder fault arriving between burst chunks must stop further writes.
    reset();issue("RXMON 440075000 LOCAL",false);mon_poll(false);
    now+=20000000;monitor.last_raw_us=now;mon_poll(false);
    inject_speaker_fault=true;mon_speaker_step();
    assert(mon_failed && mon_pushes==1 && monitor.pcm_pos==32 && !irq_depth);
    mon_speaker_step();assert(mon_pushes==1);
    issue("STOP",false);
    uint32_t stopped_calls=mon_step_calls;mon_speaker_step();
    assert(mon_step_calls==stopped_calls);
    // Cached telemetry bins retain unsigned-clock-wrap behavior and saturation.
    mon_first_push=UINT32_MAX-500000u;mon_perf_index=0;
    assert(mon_perf_at(mon_first_push+999999u)==&mon_perf[0]);
    assert(mon_perf_at(mon_first_push+1000000u)==&mon_perf[1]);
    assert(mon_perf_at(mon_first_push+40000000u)==&mon_perf[31]);
    // Service-rate changes are idle-only; telemetry follows successful writes,
    // distinguishes backpressure, and keeps playback-relative bins bounded.
    reset();issue("RXSERVICE 1",false);assert(mon_service_ms==1);
    issue("RXSERVICE 0",false);assert(mon_service_ms==1);
    issue("RXSERVICE 2 trailing",false);assert(mon_service_ms==1);
    issue("RXSERVICE 2",true);assert(mon_service_ms==1);
    issue("RXFIFO SINGLE",false);issue("RXMON 440075000 LOCAL",false);mon_poll(false);
    issue("RXSERVICE 2",false);assert(mon_service_ms==1);
    output_n=0;issue("RXPERF",false);assert(strstr(output,"ERR stop"));
    now+=20000000;monitor.last_raw_us=now;mon_poll(false);mon_speaker_step();
    assert(mon_pushes==1 && mon_perf[0].pushes==1);
    now+=1000;regs[C7_AUDIO_CONTROL/4]|=C7_AUDIO_RING_FULL;mon_speaker_step();
    assert(mon_pushes==1 && mon_perf[0].full==1);
    now+=5000;regs[C7_AUDIO_CONTROL/4]&=~C7_AUDIO_RING_FULL;mon_speaker_step();
    assert(mon_pushes==2 && mon_perf[0].max_gap==6000 && mon_worst_at==6000 && mon_worst_queue==18);
    now=mon_first_push+1001000;mon_speaker_step();assert(mon_perf[1].pushes==1);
    now=mon_first_push+40000000;mon_speaker_step();assert(mon_perf[31].pushes==1);
    issue("STOP",false);output_n=0;issue("RXPERF",false);
    assert(strstr(output,"service_ms=1") && strstr(output,"second=31") && strstr(output,"OK RXPERF"));
    issue("RXSERVICE 2",false);assert(mon_service_ms==2);
    issue("RXMON 440075000 LOCAL",false);mon_poll(false);
    assert(!mon_perf[0].pushes && !mon_perf[31].pushes && !mon_worst_at);
    // Local PCM isolation: delayed, phase-continuous, bounded, no RF/decoder work.
    for(unsigned mode=0;mode<2;++mode) {
        reset();issue(mode ? "RXFIFO BURST" : "RXFIFO SINGLE",false);
        assert(mon_fifo_limit==(mode ? 8u : 1u));
        issue("RXMON 440075000 LOCAL",false);mon_poll(false);
        assert(mon_running && control.inhibit && mon_local_tone);
        issue(mode ? "RXFIFO SINGLE" : "RXFIFO BURST",false);
        assert(mon_fifo_limit==(mode ? 8u : 1u));
        now+=19998000;monitor.last_raw_us=now;mon_poll(false);mon_speaker_step();assert(!mon_pushes);
        now+=2000;monitor.last_raw_us=now;mon_poll(false);
        assert(mon_local_frames==18 && !monitor.units && !monitor.voices);
        int16_t tone[160];mon_local_frame(tone);
        for(unsigned i=8;i<160;++i)assert(tone[i]==tone[i%8]);
        assert(tone[0]==0 && tone[2]==2000 && tone[6]==-2000);
        regs[C7_AUDIO_CONTROL/4]|=C7_AUDIO_RING_FULL;mon_speaker_step();assert(mon_full==1 && !mon_pushes);
        regs[C7_AUDIO_CONTROL/4]&=~C7_AUDIO_RING_FULL;mon_speaker_step();assert(mon_pushes==(mode ? 8u : 1u));
        for(unsigned i=0;mon_running && i<4000;++i) {
            now+=2000;monitor.last_raw_us=now;mon_poll(false);mon_speaker_step();
        }
        assert(!mon_running && !mon_enabled && !strcmp(mon_reason,"local_complete"));
        assert(mon_local_frames==300 && mon_pushes==1500 && monitor.played==300);
        assert(!monitor.starved && !monitor.pcm_overflow && !monitor.units && !monitor.voices && !rf_keys && !pa_keys);
    }
    reset();issue("RXMON 440075000 LOCAL",false);mon_poll(false);mon_poll(true);mon_poll(false);
    assert(!mon_enabled && !mon_running && !mon_routed);
    reset();issue("RXMON 440075000 LOCAL",false);mon_poll(false);issue("STOP",false);
    assert(!mon_enabled && !mon_running && control.inhibit);
    // Completed local mode must not divert a subsequent normal voice TX.
    release_after=1000000;assert(start_call());run();check_wire();
    puts("Live adapter: normal boot/PTT/RX, retained owner permission, fixed/MIC TX, all 36 startup alignments, exact bytes, faults and PCM ownership passed");
}
