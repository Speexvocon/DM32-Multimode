// SPDX-License-Identifier: GPL-3.0-or-later
// Unified P25, DMR and analog FM. Versioned settings in the designated data-flash ring.
#include "p25_live_tx.h"
#include "p25_live_frame.h"
#include "p25_rx.h"
#include "p25_receive_bench.h"
#include "p25_monitor.h"
#include "p25_test_tone.h"
#include "radio_control.h"
#include "rx_capture.h"
#define MIC_FRAMES LIVE_CAPTURE_FRAMES
#include "imbe_mic_queue.h"
#include "imbe_bench.h"
#include "board.h"
#include "hal_time.h"
#include "p25_preferences.h"
#include "p25_channel_store.h"
#include "p25_fm.h"
#include "radio_tx_guard.h"
#include "radio_broadcast.h"
#include "radio_broadcast_input.h"
#include "radio_channel.h"
#include "radio_dmr.h"
#include "dmr/ambe/ambeVoice.h"
#include "radio_dmr_metrics.h"
#include "radio_service_schedule.h"
#include "radio_signal_meter.h"
#include "radio_codec_workspace.h"
#include "radio_ux.h"
#include "platform.h"
#include "pins.h"
#include "audio_pcm.h"
#include "dmr_glue.h"
#include "cal/baofeng/baofeng_cal.h"
#include "ui/gfx.h"
#include "p25_radio_ui.h"
#include "FreeRTOS.h"
#include "task.h"
#include "config.h"
#include "app/watchdog.h"
#if CONFIG_CRASH_LOG
#include "crash/crash.h"
#endif
#include <stdio.h>
#include <stdlib.h>

#define PHY_READY (1u<<12)
#define ARM_US 30000000u
#define HARD_TIMER 6
#define SPEAKER_TIMER 4 // Exclusive to this overlay; APRS TX is not started here.
_Static_assert((uint64_t)RADIO_TX_GUARD_PERIOD_US*(HRC_APB_HZ/1000000u)<=UINT32_MAX,
               "RF watchdog exceeds hardware timer range");
static hrc7000_t *dev;
static const hrc_dmr_board_t *hooks;
static p25_live_tx live;
static radio_tx_guard hard_guard;
static radio_broadcast broadcast;
static bool broadcast_show;
static volatile bool call_tot_expired;
static uint32_t broadcast_due,call_soft_limit_us;
static unsigned call_capture_frames;
static imbe_mic_queue pcmq;
static uint8_t payload[9][11];
static unsigned encoded, target, max_encode, max_pack;
static uint32_t arm_until, ptt_mask, capture_started, last_pcm;
static uint32_t driver_loss, payload_hash, saved_rf_mode;
static uint32_t pcm_mode, pcm_audio, rf_audio;
static radio_control control={.nac=0x293,.talkgroup=1,.source_id=1};
static radio_dmr digital_dmr;
static volatile bool native_irq_owned;
static volatile bool dmr_hard_timeout;
static uint32_t dmr_ui_serial,dmr_ui_due;
static bool dmr_ui_pending;
static radio_dmr_cost_t dmr_ui_cost;
static uint32_t power_sample_us;
static uint32_t native_sys_irq_mask;
extern void __real_hrc_dmr_board_init(hrc7000_t *,const hrc_dmr_board_t *);
extern void __real_hrc_dmr_enter(void),__real_hrc_dmr_leave(void);
extern bool hrc_vocoder_resume(void),hrc_vocoder_quiesce(void);
static p25_channel_frames call_frames;
// Volatile diagnostics; boot and TXSOURCE MIC restore normal speech alignment.
#if DM32_LAB_DIAGNOSTICS
static bool tx_fixed;
static unsigned tx_pairs=14, tx_startup_extra;
#else
static const bool tx_fixed=false;
static const unsigned tx_pairs=14,tx_startup_extra=0;
#endif
// Hardware-validated defaults; diagnostic alternatives never grant RF permission.
typedef enum { TX_WRITER_DUP, TX_WRITER_ALT0, TX_WRITER_ALT1 } tx_writer_mode;
#if DM32_LAB_DIAGNOSTICS
static tx_writer_mode tx_writer=TX_WRITER_ALT1;
#else
static const tx_writer_mode tx_writer=TX_WRITER_ALT1;
#endif
static uint8_t tx_write_half;
#if DM32_LAB_DIAGNOSTICS
static bool tx_dac_restore=true;
#else
static const bool tx_dac_restore=true;
#endif
enum { TX_DAC_BEFORE_TX=1u, TX_DAC_AFTER_STOP=2u, TX_DAC_PRE_RF=4u, TX_DAC_PA=8u, TX_DAC_END=16u, TX_DAC_PREPARED=32u };
static volatile struct {
    uint32_t before_tx,prepared,after_stop,pre_rf,pa,end,seen;
} tx_dac;
static const char *tx_writer_name(void) {
    return tx_writer==TX_WRITER_ALT0 ? "ALT0" : tx_writer==TX_WRITER_ALT1 ? "ALT1" : "DUP";
}
static p25_pref_store pref_store;
static p25_preferences pref_saved;
static unsigned mic_gain_db=11;
// Owner permission is persistent; diagnostic sessions and STOP are temporary.
static bool owner_tx_inhibit,rx_promiscuous,normal_mode,ptt_release_required;
static bool ptt_release_seen;
static uint32_t ptt_release_since;
static bool pref_dirty;
static const char *pref_state="not_loaded";
static p25_preferences pref_current(void) {
    p25_preferences p={control.frequency,control.tx_frequency,control.nac,control.talkgroup,control.source_id,control.split,mic_gain_db,owner_tx_inhibit,rx_promiscuous};return p;
}
static void preferences_restore(void);
static void preferences_poll(bool down);

#define frequency control.frequency
static bool session_enabled,armed, audio_on, prepared, display_ok;
static volatile bool call_active, hardware_running, pa_started;
static const char *reason="idle";
static char command[120];
static size_t command_used;
static bool command_overflow;
static bool editing, rx_lab, rx_checked, rx_pass;
static bool menu_open;
typedef enum {MENU_ROOT,MENU_CHANNEL,MENU_VOICE,MENU_DIAGNOSTICS,MENU_MEMORY,MENU_SCAN,MENU_DISPLAY,MENU_FM,MENU_DMR,MENU_TRANSMIT,MENU_FUNCTIONS,MENU_AUDIO_TX,MENU_SETTINGS,MENU_TOOLS} ui_menu;
static ui_menu menu_page;
static unsigned menu_item;
static bool edit_from_menu,diag_from_menu;
typedef enum { EDIT_RX, EDIT_TX, EDIT_NAC, EDIT_TG, EDIT_ID, EDIT_MIC, EDIT_MEMORY, EDIT_SCREEN, EDIT_LIGHT, EDIT_TXTONE, EDIT_RXTONE, EDIT_RECALL, EDIT_SQL, EDIT_DMR_CC, EDIT_TOT, EDIT_BCAST } edit_field;
static edit_field field;
static const char *field_names[]={"RX frequency","TX frequency","NAC code","Destination ID","Radio ID","Digital mic gain","Save channel","Screen timeout","Keypad light","TX tone code","RX tone code","Select channel","FM squelch","DMR color code","TX timeout","Broadcast FM"};
static unsigned field_digits(void);
static char frequency_digits[9];
static char scan_received_label[16];
static unsigned digit_count;
static uint32_t key_candidate, key_stable, key_changed_at;
// DMR borrows the idle P25 receive/capture storage; IMBE keeps its own small
// state while this union is in active use by P25. No queues or captures shrink.
static union { rx_capture capture; p25_monitor monitor; } rx_storage __attribute__((aligned(8)));
#define rxcap rx_storage.capture
#define monitor rx_storage.monitor
#if DM32_LAB_DIAGNOSTICS
_Static_assert(sizeof(p25_monitor)<=sizeof(rx_capture),"Monitor must reuse capture budget");
#endif
_Static_assert(sizeof(rx_storage)>=RADIO_CODEC_WORKSPACE_BYTES,"DMR window exceeds receive storage");
#if DM32_LAB_DIAGNOSTICS
_Static_assert(offsetof(rx_capture,count)>=RADIO_CODEC_WORKSPACE_BYTES,"DMR window overwrites capture metadata");
#endif
static bool mon_enabled,mon_used;
#if DM32_LAB_DIAGNOSTICS
static bool mon_local_tone,mon_output_tone,mon_replay;
#else
static const bool mon_local_tone=false,mon_output_tone=false,mon_replay=false;
#endif
static unsigned mon_tone_hz=1000;
static uint32_t mon_tone_phase;
static unsigned mon_fifo_limit=8; // Preserve the measured baseline until A/B tested.
static unsigned mon_service_ms=2;
static unsigned mon_timer_us=500; // Current measured baseline; runtime alternatives remain available.
#if DM32_LAB_DIAGNOSTICS
static bool mon_pcm_backend=true;
#else
static const bool mon_pcm_backend=true;
#endif // Validated PCM_RD output; FIFO is diagnostic-only.
static volatile bool mon_pcm_pending;
static volatile uint32_t mon_pcm_submitted,mon_pcm_consumed,mon_pcm_irqs,mon_pcm_last,mon_pcm_gap;
#ifndef P25_SPEAKER_PCM_WINDOW
#define P25_SPEAKER_PCM_WINDOW ((volatile uint8_t *)C7_PCM_SPK_ADDR)
#endif
static void mon_pcm_disable(void);
static volatile uint32_t mon_timer_ticks;
static uint32_t mon_notify_max;
static uint32_t mon_hdu,mon_ldu1,mon_ldu2,mon_tdu;
static uint32_t mon_step_max_us,mon_step_total_us,mon_step_calls;
#if DM32_LAB_DIAGNOSTICS
static unsigned mon_perf_index;
// Playback-relative seconds 0..30; bin 31 includes all later activity.
typedef struct {uint32_t pushes,full,max_gap,max_service,empty,route_missing;} mon_perf_bin;
static mon_perf_bin mon_perf[32];
#endif
static uint32_t mon_worst_at,mon_worst_queue;
static uint32_t mon_local_started,mon_local_frames;
static uint32_t mon_pushes,mon_full,mon_first_push,mon_last_push,mon_push_gap;
#if DM32_LAB_DIAGNOSTICS
static void mon_local_frame(int16_t pcm[160]) {p25_tone_frame(pcm,&mon_tone_phase,mon_tone_hz);}
#endif
static bool mon_audio_enabled=true;
static uint32_t mon_fault_age,mon_fault_audio,mon_fault_mask,mon_fault_mode;
static bool mon_have_sync,mon_badge_sync;
#define mon_have_nac monitor.call.active
#define mon_call_nac monitor.call.nac
static unsigned mon_badge_phase;
static char mon_shown_context[48];
static uint32_t mon_sync_us,mon_voice_us,mon_ui_max_us,mon_spk_last_us,mon_spk_gap_us;
static volatile bool mon_running,mon_failed,mon_routed;
static TaskHandle_t mon_task_handle;
static uint32_t mon_empty_since;
static const char *mon_reason="disabled";
static void mon_stop(const char *why);
static void mon_poll(bool down);
static void mon_status(void);
static bool normal_resume(void);
static bool rx_job;
static volatile bool rx_sampling;
static uint32_t rx_hz;
static const char *rx_reason="not_run";
#if DM32_LAB_DIAGNOSTICS
static uint32_t rx_due,rx_started;
static unsigned rx_profile,rx_capture_profile;
typedef struct { uint32_t us; int16_t dbm; uint8_t noise; } rx_signal;
static rx_signal rx_signals[60];
static unsigned rx_signal_count;
static uint32_t rx_signal_due, rx_signal_max_us;
#endif
// Slow, task-context meter samples. No frontend/ADC reads from audio or IRQ code.
static uint16_t ui_battery_mv;
static uint8_t ui_battery_pct,ui_rssi_bars;
static bool ui_battery_valid,ui_rssi_valid;
static int16_t ui_rssi_dbm;
static uint32_t ui_battery_due,ui_rssi_due,ui_signal_us,ui_meter_max_us,ui_header_shown;
static radio_signal_meter ui_strength;
#if DM32_LAB_DIAGNOSTICS
static uint32_t rx_reg_work, rx_reg_rf, rx_reg_bw, rx_reg_audio, rx_reg_phase;
static bool rx_pin_source, rx_pin_mic;
#endif
static void rx_end(const char *why);
static void screen(const char *title);
static void dmr_tx_preview(void);
static void send(const char *s);
static void normal_permission(void);
static bool ptt_start_requested(bool down,bool was_down);
static void hardware_stop(void);
static bool hard_guard_arm(unsigned seconds);
static void broadcast_screen(void);
static void broadcast_leave(bool ptt_down);
static void broadcast_toggle(void);
static void home_hint_refresh(void);
// Communications modes use the supported VHF/UHF frontend paths. Optional
// AM and broadcast board entries are routed separately, never as P25/DMR/FM.
static bool channel_in_band(uint32_t hz,bool need_tx) {
    return ((hz>=136000000u && hz<=174000000u) || (hz>=400000000u && hz<=480000000u))
        && board_in_band(hz,need_tx);
}
#include "p25_radio_features.h"
static unsigned field_digits(void) { return field<=EDIT_TX || field==EDIT_BCAST ? 7 : field==EDIT_NAC ? 3 : field==EDIT_TG ? (feature_dmr() ? 8u : 5u) : field==EDIT_MIC || field==EDIT_DMR_CC ? 2 : field==EDIT_ID ? 8 : field==EDIT_SQL ? 1 : field==EDIT_TXTONE || field==EDIT_RXTONE ? 4 : 3; }

void imbe_profile_mark(unsigned stage) { (void)stage; }
void __wrap_hrc_dmr_board_init(hrc7000_t *m,const hrc_dmr_board_t *h) {
    dev=m;hooks=h;
    // The board's power-on initialization has installed its native event mask.
    // Safe stops clear it; ordinary native DMR re-entry does not reinstall it.
    native_sys_irq_mask=hrc7000_rd(m,C7_SYS_INTERP_MASK);
}
void __wrap_hrc_dmr_enter(void) {
    if(!native_irq_owned)return;
    uint32_t lock=hrc_irq_save();
    hrc_irq_enable(IRQ_MODEM_SYS,false);hrc_irq_enable(IRQ_MODEM_TS_TX,false);
    hrc_irq_enable(IRQ_MODEM_TS_RX,false);hrc_irq_enable(IRQ_MODEM_RF_TX,false);
    hrc7000_wr(dev,C7_SYS_INTERP_CLEAR,0xffffffffu);
    hrc7000_wr(dev,C7_SYS_INTERP_MASK,native_sys_irq_mask);
    hrc_irq_restore(lock);
    // Native run installs layer-2 state before enabling its PIC sources.
    __real_hrc_dmr_enter();
}
void __wrap_hrc_dmr_leave(void) {if(native_irq_owned)__real_hrc_dmr_leave();}
static void wr(uint32_t r,uint32_t v) { hrc7000_wr(dev,r,v); }
static void send(const char *s) { board.host_port->write((const uint8_t *)s,strlen(s)); }

// IRQ-safe RF kill; audio/board cleanup is deferred to task context.
static void hardware_stop(void) {
    bool ending=call_active || hardware_running;
    mon_pcm_disable();
    hrc_timer_stop(SPEAKER_TIMER);hrc_irq_enable(IRQ_TIMER4,false);
    if(dev) { wr(C7_LAYER2_TXRX_CTRL,0); wr(C7_LAYER2_CONTROL,0xc0); wr(C7_SYS_INTERP_MASK,0); }
    hrc_irq_enable(IRQ_MODEM_SYS,false);
    hrc_irq_enable(IRQ_MODEM_TS_TX,false); hrc_irq_enable(IRQ_MODEM_TS_RX,false);
    hrc_irq_enable(IRQ_MODEM_RF_TX,false); hrc_irq_enable(IRQ_MODEM_RF_RX,false);
    hrc_timer_stop(TIMER_PA); hrc_timer_stop(HARD_TIMER);radio_tx_guard_stop(&hard_guard);
    if(hardware_running && hooks && !analog_fm.owned) hooks->rf_switch(false);
    board_rf_safe(); hardware_running=false; pa_started=false;
    if(ending) {tx_dac.end=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_END;}
}
static void stop_call(const char *why,bool revoke) {
    uint32_t lock=hrc_irq_save();
    reason=why; pcmq.accepting=false;
    p25_test_tx_abort(&live.timing,P25_TX_CANCELLED);
    hardware_stop(); call_active=false; armed=false;
    if(revoke) {session_enabled=false;radio_inhibit(&control,true);}
    hrc_irq_restore(lock);
}
static void fail(const char *why) { stop_call(why,true); }
static bool ptt_fresh_request(bool down,bool was_down) {
    bool permitted=(normal_mode && !tx_fixed) || session_enabled
        || (armed && (int32_t)(hrc_micros()-arm_until)<0);
    return down && !was_down && !ptt_release_required && !broadcast_show && !rx_job && !editing && !menu_open && !rx_lab
        && control.state!=RADIO_FAULT
        && !call_active && !prepared && permitted;
}
static bool ptt_start_requested(bool down,bool was_down) {
    return ptt_fresh_request(down,was_down) && control.tx_enabled && !control.inhibit;
}
static void boundary(void) {
    if(!hardware_running) return;
    uint8_t block[36]; uint32_t now=hrc_micros();
    if(!p25_live_tx_boundary(&live,now,block)) {
        if(!p25_test_tx_active(&live.timing)) {
            reason=live.timing.state==P25_TX_DONE ? "complete" : live.underruns ? "rf_underrun" : "rf_timing";
            if(live.timing.state!=P25_TX_DONE) session_enabled=false;
            hardware_stop(); call_active=false; pcmq.accepting=false;
        } else if(live.timing.state==P25_TX_DRAINING && now-live.timing.last_boundary_us>=15000u) {
            wr(C7_LAYER2_TXRX_CTRL,0);
        }
        return;
    }
    // SEND_DATA0/1 alternate (pinned modem-hrc7000.md 2.10). Updating both
    // can replace the still-playing half's tail. Both possible initial halves
    // remain selectable until the physical phase is measured on this radio.
    if(tx_writer==TX_WRITER_DUP) {
        for(unsigned i=0;i<36;++i) { dev->buf[i]=block[i]; dev->buf[36+i]=block[i]; }
    } else {
        unsigned offset=tx_write_half ? 36u : 0u;
        for(unsigned i=0;i<36;++i)dev->buf[offset+i]=block[i];
        tx_write_half^=1u; // Only after a unique boundary published a full block.
    }
    wr(C7_LAYER2_TXRX_CTRL,0x80);
}
static void isr_sys(void) {
    uint32_t list=hrc7000_rd(dev,C7_SYS_INTERP_LIST); wr(C7_SYS_INTERP_CLEAR,list);
    if(mon_running) {
        if((list&(1u<<14)) && !mon_raw_push(&monitor,dev->buf+C7_FM_RX_AUDIO,
            hrc7000_rd(dev,C7_FM_ADDR_SW)&3,hrc_micros()))mon_failed=true;
        return;
    }
    if(rx_sampling) {
        if(list&(1u<<14))rxcap_push(&rxcap,dev->buf+C7_FM_RX_AUDIO,
                                  hrc7000_rd(dev,C7_FM_ADDR_SW)&3,hrc_micros());
        return;
    }
    if(list&PHY_READY) boundary();
}
static void isr_slot(void) { wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX); boundary(); }
static void isr_rftx(void) {
    wr(C7_INTERP_CLEAR,C7_INT_RF_TX);
    if(hardware_running && p25_test_tx_active(&live.timing) && !pa_started) {
        pa_started=true; hooks->rf_switch(true); hrc_timer_oneshot(TIMER_PA,hooks->pa_delay_us);
    }
}
static void isr_rfrx(void) { wr(C7_INTERP_CLEAR,C7_INT_RF_RX); }
static void isr_pa(void) {
    hrc_timer_ack(TIMER_PA); hrc_timer_stop(TIMER_PA);
    if(hardware_running && p25_test_tx_active(&live.timing)) {
        hooks->pa_on();tx_dac.pa=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PA;
    }
}
static bool hard_guard_arm(unsigned seconds) {
    uint32_t lock=hrc_irq_save();hrc_timer_stop(HARD_TIMER);
    bool ok=radio_tx_guard_start(&hard_guard,seconds);
    if(ok)hrc_timer_oneshot(HARD_TIMER,RADIO_TX_GUARD_PERIOD_US);
    hrc_irq_restore(lock);return ok;
}
static void isr_hard_stop(void) {
    hrc_timer_ack(HARD_TIMER);
    if(!hard_guard.remaining) {hrc_timer_stop(HARD_TIMER);return;}
    if(!radio_tx_guard_tick(&hard_guard)) {
        hrc_timer_oneshot(HARD_TIMER,RADIO_TX_GUARD_PERIOD_US);return;
    }
    if(native_irq_owned) {
        // Quiesce slot/PA IRQs immediately; task context stops the call engine.
        dmr_hard_timeout=true;hardware_stop();call_active=false;return;
    }
    p25_test_tx_abort(&live.timing,P25_TX_TIMEOUT);
    session_enabled=false; radio_inhibit(&control,true); reason="hard_timeout"; pcmq.accepting=false; call_active=false; hardware_stop();
}
static void p25_irqs_install(void) {
    hrc_irq_register(IRQ_MODEM_SYS,isr_sys);hrc_irq_register(IRQ_MODEM_TS_TX,isr_slot);
    hrc_irq_register(IRQ_MODEM_TS_RX,isr_slot);hrc_irq_register(IRQ_MODEM_RF_TX,isr_rftx);
    hrc_irq_register(IRQ_MODEM_RF_RX,isr_rfrx);hrc_irq_register(IRQ_TIMER3,isr_pa);
    hrc_irq_enable(IRQ_TIMER3,true);
}
static bool dmr_acquire(void *ctx) {
    (void)ctx;
    if(!dev || !hooks || call_active || prepared || audio_on || mon_running || rx_job)return false;
    if(!native_sys_irq_mask) {digital_dmr.error=RADIO_DMR_RX_FAILED;return false;}
    hardware_stop();
    if(!imbe_bench_release())return false;
    if(!board.vocoder || !board.vocoder->present()) {digital_dmr.error=RADIO_DMR_NO_CODEC;return false;}
    // Old trace/capture bytes cease to be evidence once native state uses them.
    mon_used=false;memset(&rx_storage,0,sizeof rx_storage);rx_reason="dmr_workspace";
#if DM32_LAB_DIAGNOSTICS
    rx_signal_count=0;
#endif
    rx_hz=0;
    if(!hrc_vocoder_resume())return false;
    __real_hrc_dmr_board_init(dev,hooks);
    native_irq_owned=true;dmr_hard_timeout=false;return true;
}
static void dmr_release(void *ctx) {
    (void)ctx;
    // The backend has stopped AMBE audio and left DMR before this callback.
    __real_hrc_dmr_leave();
    native_irq_owned=false;
    bool released=hrc_vocoder_quiesce();
    hardware_stop();p25_irqs_install();
    if(!released) {reason="codec_busy";radio_complete(&control,true);}
}
static uint32_t dmr_clock_us(void *ctx) {(void)ctx;return hrc_micros();}
static void dmr_native_tx_diag(radio_dmr_native_tx_diag_t *out,void *ctx) {(void)ctx;hrc_dmr_tx_diag(out);}
static void feature_dmr_tick(bool down) {
    bool home=!menu_open && !editing && !rx_lab && !rx_job && !cps_link && !cps_active;
    if(!normal_mode || !feature_dmr() || !mon_enabled || !frequency || !home) {
        if(digital_dmr.owned && !digital_dmr.tx_armed)radio_dmr_stop(&digital_dmr);
        return;
    }
    if(mon_running)mon_stop("dmr");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    if(!digital_dmr.owned && control.state!=RADIO_FAULT) {
        radio_dmr_config config={.rx_hz=frequency,.tx_hz=control.tx_frequency,
            .source_id=control.source_id,.target_id=radio_channel_get_destination(channel_record),
            .cc=(uint8_t)radio_channel_get_color_code(channel_record),
            .ts=(uint8_t)radio_channel_get_timeslot(channel_record),.power=(uint8_t)feature_tx_power(),.tot_s=(uint16_t)feature_tx_tot(),
            .private_call=radio_channel_get_private(channel_record),.rmo=radio_channel_get_repeater(channel_record),
            .filter=rx_promiscuous ? RADIO_DMR_FILTER_PROM : rx_tg_filter ? RADIO_DMR_FILTER_TARGET : RADIO_DMR_FILTER_SLOT,
            .rx_only=(channel_record[12]&16u)!=0,.owner_permission=!owner_tx_inhibit};
        if(!feature_tx_settings_valid() || !radio_dmr_start(&digital_dmr,&config)) {
            reason=radio_dmr_error_name(digital_dmr.error);radio_complete(&control,true);screen("HOME");return;
        }
        hrc7000_set_mic_gain(dev,(uint8_t)mic_gain_db);
        dmr_ui_serial=UINT32_MAX;dmr_ui_due=hrc_micros();reason="listening";
        radio_receive_state(&control,true,true,false,false);screen("HOME");
    }
    if(!digital_dmr.running)return;
    digital_dmr.config.owner_permission=!owner_tx_inhibit;
    digital_dmr.config.rx_only=(channel_record[12]&16u)!=0;
    bool allowed=home && !ptt_release_required && control.tx_enabled && !control.inhibit && !control.cancel;
    bool was_tx=digital_dmr.tx_armed;
    radio_dmr_tx_result old_result=digital_dmr.diagnostics.result;
    if(!was_tx && down && allowed && !digital_dmr.ptt_last
       && !digital_dmr.release_required && !digital_dmr.config.rx_only) {
        // LCD transfers share this task with native burst feeding. Show TX
        // before starting the producer/slot engine, then leave graphics alone
        // through access, voice and terminator drain. A release during a slow
        // preview must not turn the cached key sample into an unwanted call.
        dmr_tx_preview();
        down=down && !hrc_pin_read(PIN_PTT);
    }
    // Arm independently before the first call into the slot engine can key RF.
    if(!was_tx && down && allowed && !hard_guard_arm(feature_tx_tot()+2u))allowed=false;
    radio_dmr_poll(&digital_dmr,hal_millis(),down,allowed);
    // A board-level refusal need not change the native call view's serial.
    if(old_result!=digital_dmr.diagnostics.result)dmr_ui_serial=UINT32_MAX;
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    call_active=hardware_running=digital_dmr.tx_armed;
    if(!digital_dmr.tx_armed) {hrc_timer_stop(HARD_TIMER);radio_tx_guard_stop(&hard_guard);}
    if(was_tx && !digital_dmr.tx_armed) {
        control.cancel=false;radio_complete(&control,false);
        reason=digital_dmr.tx_error==DMR_TX_OK ? "listening" : radio_dmr_tx_error_name(digital_dmr.tx_error);
        normal_permission();
        if(down) {ptt_release_required=true;ptt_release_seen=false;}
    }
    if(dv && digital_dmr.tx_armed) {
        control.state=dv->phase==DMR_CALL_PHASE_TX_ENDING ? RADIO_TX_DRAIN : RADIO_TX_VOICE;
        reason="voice_call";
    } else if(dv) {
        bool rx=dv->state==DMR_CALL_STATE_RX;
        radio_receive_state(&control,true,true,rx,dv->phase==DMR_CALL_PHASE_RX_VOICE);
    }
    board.power->led(LED_GREEN,dv && dv->state==DMR_CALL_STATE_RX);
}
static void capture(const int16_t *pcm,int16_t *speaker,void *ctx) {
    (void)ctx; memset(speaker,0,320);
    uint32_t lock=hrc_irq_save();
    if(call_active && pcmq.accepting) {
        mic_queue_push_limit(&pcmq,pcm,hrc_micros(),call_capture_frames);last_pcm=hrc_micros();
        if(pcmq.captured>=call_capture_frames)call_tot_expired=true;
    }
    hrc_irq_restore(lock);
}
static void audio_stop(void) {
    if(audio_on) { board.audio->stop(); audio_on=false; }
    // Do not change modem mode or PA while queued RF is draining.
}
static void cleanup(void) {
    audio_stop();
    // Completion may arrive in the PHY IRQ before poll_call runs again.
    if(prepared && call_tot_expired && (!strcmp(reason,"complete") || !strcmp(reason,"time_limit"))) {
        reason="time_limit";ptt_release_required=true;ptt_release_seen=false;
    }
    if(prepared)ui_battery_due=hrc_micros()+3000000u; // Let pack voltage recover before refreshing its icon.
    uint32_t lock=hrc_irq_save(); hardware_stop();
    if(prepared) wr(C7_RF_MODE,saved_rf_mode);
    hrc_irq_restore(lock);
    if(prepared) { board.radio->tx_off(); board.radio->set_mode(RADIO_MODE_FM); }
    prepared=false; board_rf_safe(); board.power->led(LED_RED,false);
    // The main loop resumes an enabled receiver only after TX cleanup.
    bool fault=strcmp(reason,"complete") && strcmp(reason,"released_before_rf")
        && strcmp(reason,"idle") && strcmp(reason,"cancelled") && strcmp(reason,"time_limit");
    radio_complete(&control,fault);
    if(fault) {session_enabled=armed=false;radio_inhibit(&control,true);}
    if(!normal_mode && !session_enabled)radio_inhibit(&control,true);
    if(normal_mode && !fault)radio_receive_state(&control,mon_enabled,false,false,false);
}
static void normal_permission(void) {
    if(!normal_mode || call_active || prepared || radio_busy(&control))return;
    if(control.state==RADIO_FAULT) {radio_inhibit(&control,true);return;}
    bool blocked=owner_tx_inhibit || broadcast_show || cps_link || cps_active || (channel_record[12]&16u) || !feature_tx_settings_valid() || !channel_in_band(frequency,false)
        || !channel_in_band(control.tx_frequency,true) || !bf_cal_valid()
        || board.power->battery_mv()<board.battery_critical_mv;
    radio_inhibit(&control,blocked);
}
static bool normal_resume(void) {
    if(call_active || prepared || rx_job)return false;
    if(mon_running)mon_stop("resume_radio");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
    normal_mode=true;session_enabled=armed=false;
#if DM32_LAB_DIAGNOSTICS
    tx_fixed=false;tx_startup_extra=0;tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;
    mon_pcm_backend=true;mon_local_tone=mon_replay=mon_output_tone=false;
#endif
    mon_audio_enabled=true;
    editing=menu_open=rx_lab=false;edit_from_menu=diag_from_menu=false;digit_count=0;
    radio_complete(&control,false);
    mon_enabled=channel_in_band(frequency,false);mon_reason=mon_enabled ? "ready" : "no_channel";
    reason=mon_enabled ? "listening" : "enter_frequency";
    normal_permission();radio_receive_state(&control,mon_enabled,false,false,false);
    return mon_enabled;
}
static void boot_policy(void) {
    // The shared UART/PTT driver initially reports released while its 20-ms
    // low filter settles. Never use that first filtered scan as permission.
    ptt_release_required=true;ptt_release_seen=false;
    (void)normal_resume();
}
static void dmr_cost_status(const char *name,const radio_dmr_cost_t *cost) {
    char line[160];
    snprintf(line,sizeof line,"DMRCOST kind=%s calls=%lu total_us=%lu max_us=%lu saturated=%lu\r\n",name,
        (unsigned long)cost->calls,(unsigned long)cost->total_us,(unsigned long)cost->max_us,(unsigned long)cost->saturated);
    send(line);
}
static void dmr_diagnostic_status(void) {
    char line[360];radio_dmr_diagnostics d;
    radio_dmr_rx_diag_t rx;hrc_dmr_rx_diag(&rx);
    snprintf(line,sizeof line,"DMRHW saved_mask=%08lx current_mask=%08lx active=%u callback=%u closed=%u deferred=%u sys=%lu ts_rx=%lu ts_tx=%lu ticks=%lu\r\n",
        (unsigned long)native_sys_irq_mask,(unsigned long)(dev ? hrc7000_rd(dev,C7_SYS_INTERP_MASK) : 0u),
        (unsigned)rx.active,(unsigned)rx.callback_bound,(unsigned)rx.deferred_closed,(unsigned)rx.deferred_active,
        (unsigned long)rx.sys_ints,(unsigned long)rx.ts_rx_ints,(unsigned long)rx.ts_tx_ints,(unsigned long)rx.ticks);send(line);
    snprintf(line,sizeof line,"DMRBURST voice=%lu header=%lu end=%lu crc=%lu unusable=%lu late=%lu overflow=%lu cc=%u ts=%d type=%08lx sys_list=%08lx l2=%08lx\r\n",
        (unsigned long)rx.rx_voice,(unsigned long)rx.rx_lc_header,(unsigned long)rx.rx_terminator,
        (unsigned long)rx.rx_crc_err,(unsigned long)rx.rx_unusable,(unsigned long)rx.late_entry,(unsigned long)rx.ev_overflow,
        (unsigned)rx.last_cc,(int)rx.last_ts,(unsigned long)rx.last_rx_type_info,(unsigned long)rx.last_sys_list,
        (unsigned long)rx.last_l2_status);send(line);
    ambe_voice_stats_t voice;dmr_call_stats_t calls;
    uint32_t rx_lock=hrc_irq_save();ambeVoiceGetStats(&voice);dmr_call_get_stats(&calls);hrc_irq_restore(rx_lock);
    snprintf(line,sizeof line,"DMRRXCALL scope=mode calls=%lu played=%lu bursts=%lu lost=%lu duplicate=%lu encrypted=%lu cc_drop=%lu ts_drop=%lu event_overflow=%lu\r\n",
        (unsigned long)calls.rx_calls,(unsigned long)calls.rx_calls_played,(unsigned long)calls.rx_voice_bursts,
        (unsigned long)calls.rx_lost_frames,(unsigned long)calls.rx_dup_dropped,(unsigned long)calls.rx_enc_dropped,
        (unsigned long)calls.rx_cc_dropped,(unsigned long)calls.rx_ts_dropped,(unsigned long)calls.evq_overflows);send(line);
    snprintf(line,sizeof line,"DMRRXAUDIO scope=boot in=%lu frames=%lu bad=%lu lost=%lu concealed=%lu silence=%lu queue_max=%lu empty=%lu overflow=%lu bit_corrections=%lu peak=%lu repeats=%lu\r\n",
        (unsigned long)voice.rx_in,(unsigned long)voice.rx_frames,(unsigned long)voice.rx_bad,(unsigned long)voice.rx_lost,
        (unsigned long)voice.rx_concealed,(unsigned long)voice.rx_silence,(unsigned long)voice.rx_queue_max,
        (unsigned long)voice.rx_underruns,(unsigned long)voice.rx_overflows,(unsigned long)voice.rx_bit_errors,
        (unsigned long)voice.rx_peak,(unsigned long)voice.rx_repeats);send(line);
    if(radio_dmr_get_diagnostics(&digital_dmr,&d)) {
        snprintf(line,sizeof line,"DMRTX result=%s backend=%s native=%s phase=%u last_tx_phase=%u valid=%u start_ms=%lu end_ms=%lu calls=%lu denied=%lu frames=%lu repeats=%lu overflow=%lu source_empty=%lu event_overflow=%lu\r\n",
            radio_dmr_tx_result_name(d.result),radio_dmr_error_name(d.backend_error),radio_dmr_tx_error_name(d.tx_error),
            d.phase,d.last_tx_phase,(unsigned)d.metrics_valid,(unsigned long)d.start_ms,(unsigned long)d.end_ms,
            (unsigned long)d.calls,(unsigned long)d.denied,(unsigned long)d.encoded_frames,(unsigned long)d.encoded_repeats,
            (unsigned long)d.encoded_overflows,(unsigned long)d.source_underruns,(unsigned long)d.event_overflows);send(line);
        snprintf(line,sizeof line,"DMRMIC blocks=%lu peak=%lu level_db=%lu spread_db=%lu zc=%lu\r\n",
            (unsigned long)d.mic_blocks,(unsigned long)d.mic_peak,(unsigned long)d.mic_level_db,
            (unsigned long)d.mic_spread_db,(unsigned long)d.mic_zc);send(line);
        snprintf(line,sizeof line,"DMRPACE scope=attempt valid=%u poll_gap_us=%lu\r\n",
            (unsigned)d.poll_timing_valid,(unsigned long)d.poll_gap_max_us);send(line);
        dmr_cost_status("poll",&d.poll_cost);
        snprintf(line,sizeof line,"DMRDRIVER scope=attempt valid=%u bursts=%lu underrun=%lu rejected=%lu done=%lu event_overflow=%lu\r\n",
            (unsigned)d.native_metrics_valid,(unsigned long)d.native_tx_bursts,(unsigned long)d.native_tx_underruns,
            (unsigned long)d.native_tx_rejected,(unsigned long)d.native_tx_done,(unsigned long)d.native_event_overflows);send(line);
    }
    radio_dmr_audio_diag_t audio;radio_dmr_vocoder_diag_t codec;
    hrc_audio_pcm_diag(&audio);hrc_vocoder_diag(&codec);
    snprintf(line,sizeof line,"DMRPCM counts_scope=native_reset cost_scope=boot blocks=%lu overwritten=%lu fifo_underrun_available=0 service_gap_us=%lu callback_gap_us=%lu\r\n",
        (unsigned long)audio.blocks,(unsigned long)audio.overruns,
        (unsigned long)audio.service_gap_max_us,(unsigned long)audio.callback_gap_max_us);send(line);
    snprintf(line,sizeof line,"DMRSPK scope=boot backend=PCM half_samples=80 prefill_samples=320 submitted=%lu consumed=%lu irqs=%lu irq_gap_us=%lu queue_max_samples=%lu\r\n",
        (unsigned long)audio.output_submitted,(unsigned long)audio.output_consumed,
        (unsigned long)audio.output_irqs,(unsigned long)audio.output_irq_gap_max_us,
        (unsigned long)audio.output_queue_max);send(line);
    snprintf(line,sizeof line,"DMRSPKFAULT scope=boot overflow=%lu starvation=%lu restart=%lu drain=%lu discarded_samples=%lu timeout=%lu\r\n",
        (unsigned long)audio.output_overflows,(unsigned long)audio.output_starvations,
        (unsigned long)audio.output_restarts,(unsigned long)audio.output_drains,
        (unsigned long)audio.output_discarded,(unsigned long)audio.output_timeouts);send(line);
    snprintf(line,sizeof line,"DMRCODEC scope=owner reset_rejected=%lu encode_rejected=%lu decode_rejected=%lu\r\n",
        (unsigned long)codec.reset_rejected,(unsigned long)codec.encode_rejected,(unsigned long)codec.decode_rejected);send(line);
    dmr_cost_status("service",&audio.service);dmr_cost_status("callback",&audio.callback);
    dmr_cost_status("reset",&codec.reset);dmr_cost_status("encode",&codec.encode);dmr_cost_status("decode",&codec.decode);
    dmr_cost_status("dmr_display",&dmr_ui_cost);
#if CONFIG_WATCHDOG
    uint32_t lock=hrc_irq_save();watchdog_state_t wd=*watchdog_state();hrc_irq_restore(lock);
    snprintf(line,sizeof line,"WATCHDOG feeds=%lu last_idle_ms=%lu last_fed_ms=%lu max_gap_ms=%lu seen=%u starving=%u\r\n",
        (unsigned long)wd.feeds,(unsigned long)wd.last_idle_ms,(unsigned long)wd.last_fed_ms,
        (unsigned long)wd.max_gap_ms,(unsigned)wd.seen,(unsigned)wd.starving);send(line);
#endif
#if CONFIG_CRASH_LOG
    const crash_reset_t *boot=crash_reset();const crash_record_t *crash=crash_last();
    snprintf(line,sizeof line,"RESET cause=%s flags=%08lx prior_uptime_ms=%lu warm=%lu crash=%u kind=%u code=%lu pc=%08lx task=%.8s\r\n",
        crash_reset_name(boot->cause),(unsigned long)boot->flags,(unsigned long)boot->uptime_ms,(unsigned long)boot->warm,
        (unsigned)(crash!=NULL),crash ? crash->kind : 0u,(unsigned long)(crash ? crash->cause : 0u),
        (unsigned long)(crash ? crash->pc : 0u),crash ? crash->task : "none");send(line);
#endif
}
enum {COMMAND_DEFER_STATUS=1u,COMMAND_DEFER_BUSY=2u,COMMAND_DEFER_STOP_ACK=4u};
static unsigned command_deferred;
static bool command_critical_pass;
static void command_deferred_reset(void) {command_deferred=0;command_critical_pass=false;}
static bool command_tx_critical(bool down) {
    if(digital_dmr.tx_armed)return true; // Access/wake-up and ending also need polling.
    bool home=!menu_open && !editing && !rx_lab && !rx_job && !cps_link && !cps_active;
    return normal_mode && feature_dmr() && home && digital_dmr.running && down
        && !digital_dmr.ptt_last && !digital_dmr.release_required && !ptt_release_required
        && control.tx_enabled && !control.inhibit && !control.cancel
        && !owner_tx_inhibit && !(channel_record[12]&16u);
}
static void status(void) {
    // A complete snapshot has hundreds of milliseconds of synchronous UART
    // wire time. Even a BUSY reply must not interrupt an active TX/capture.
    if(call_active || rx_sampling || command_tx_critical(false)) {
        command_deferred|=COMMAND_DEFER_STATUS;return;
    }
    command_deferred&=~(COMMAND_DEFER_STATUS|COMMAND_DEFER_BUSY);
    char line[448];
    snprintf(line,sizeof line,"TXPATH writer=%s dac=%s dac_seen=%02lx dac_before_tx=%08lx dac_prepared=%08lx dac_after_stop=%08lx dac_pre_rf=%08lx dac_pa=%08lx dac_end=%08lx\r\n",
        tx_writer_name(),tx_dac_restore ? "RESTORE" : "KEEP",(unsigned long)tx_dac.seen,
        (unsigned long)tx_dac.before_tx,(unsigned long)tx_dac.prepared,(unsigned long)tx_dac.after_stop,(unsigned long)tx_dac.pre_rf,
        (unsigned long)tx_dac.pa,(unsigned long)tx_dac.end);send(line);
    snprintf(line,sizeof line,"TXDIAG source=%s pairs=%u startup_extra=%u ldu_phase=%u\r\n",
        tx_fixed ? "FIXED1011" : "MIC",tx_pairs,tx_startup_extra,
        (LIVE_STARTUP_BASE_BYTES+99u+tx_startup_extra)%36u);
    send(line);
    snprintf(line,sizeof line,"OPERATING mode=%s owner_inhibit=%u ptt_release=%u prom=%u\r\n",
        normal_mode ? "RADIO" : "BENCH",(unsigned)owner_tx_inhibit,(unsigned)ptt_release_required,(unsigned)rx_promiscuous);send(line);
    snprintf(line,sizeof line,"LIVE git=%s armed=%u session=%u hz=%lu active=%u rf=%u state=%u reason=%s cal=%s captured=%u encoded=%u pcm_high=%u overflow=%u driver_loss=%lu ldu_high=%u published=%u consumed=%u underrun=%u blocks=%lu dup=%lu late=%lu maxgap=%lu max_encode_us=%u max_pack_us=%u hash=%08lx\r\n",
        BENCH_GIT,(unsigned)armed,(unsigned)session_enabled,(unsigned long)frequency,(unsigned)call_active,(unsigned)hardware_running,
        (unsigned)live.timing.state,reason,bf_cal_source(),pcmq.captured,encoded,pcmq.high,pcmq.overflow,
        (unsigned long)driver_loss,live.high,live.published,live.consumed,live.underruns,
        (unsigned long)live.timing.blocks,(unsigned long)live.timing.duplicate_irqs,
        (unsigned long)live.timing.late_irqs,(unsigned long)live.timing.max_gap_us,max_encode,max_pack,
        (unsigned long)payload_hash);
    send(line);
    if(mon_used) {send("RXCAP pending=0 sampling=0 hz=0 blocks=0 invalid=0 repeats=0 gaps=0 maxgap_us=0 reason=monitor_storage\r\n");mon_status();}
#if DM32_LAB_DIAGNOSTICS
    else {snprintf(line,sizeof line,"RXCAP pending=%u sampling=%u hz=%lu blocks=%lu invalid=%lu repeats=%lu gaps=%lu maxgap_us=%lu reason=%s\r\n",
        (unsigned)rx_job,(unsigned)rx_sampling,(unsigned long)rx_hz,(unsigned long)rxcap.count,
        (unsigned long)rxcap.invalid,(unsigned long)rxcap.repeats,(unsigned long)rxcap.gaps,
        (unsigned long)rxcap.maxgap,rx_reason);send(line);}
#endif
    snprintf(line,sizeof line,"RADIO rx_hz=%lu tx_hz=%lu split=%u nac=%03lx tg=%lu source=%lu ui_state=%u inhibit=%u\r\n",
        (unsigned long)frequency,(unsigned long)control.tx_frequency,(unsigned)control.split,
        (unsigned long)control.nac,(unsigned long)control.talkgroup,(unsigned long)control.source_id,
        (unsigned)control.state,(unsigned)control.inhibit);send(line);
    snprintf(line,sizeof line,"UIMETER battery_pct=%u battery_mv=%u rssi_dbm=%d bars=%u valid=%u max_poll_us=%lu\r\n",
        (unsigned)ui_battery_pct,(unsigned)ui_battery_mv,(int)ui_rssi_dbm,(unsigned)ui_rssi_bars,
        (unsigned)ui_rssi_valid,(unsigned long)ui_meter_max_us);send(line);
    snprintf(line,sizeof line,"PREF state=%s dirty=%u writable=%u sequence=%lu mic_db=%u version=%u tx_inhibit=%u prom_mode=%u\r\n",pref_state,pref_dirty,pref_store.writable,(unsigned long)pref_store.seq,mic_gain_db,PREF_VERSION,(unsigned)owner_tx_inhibit,(unsigned)rx_promiscuous);send(line);
    snprintf(line,sizeof line,"CODEPLUG version=%u revision=%lu active=%u legacy=%u mode=%s vfo=%c memory=%u filter=%u scan=%u list=%u locked=%u screen_s=%u keypad_s=%u cps=%u scan_members=%u scan_match=%u\r\n",
        P25_CS_VERSION,(unsigned long)channel_store.revision,(unsigned)channel_store.have_active,(unsigned)channel_store.have_legacy,
        feature_mode_name(),'A'+feature_vfo(),feature_memory(),feature_filter(),(unsigned)channel_scan.running,
        global_record[12]+1u,(unsigned)radio_lights.locked,radio_lights.screen_seconds,radio_lights.keypad_seconds,(unsigned)(cps_link || cps_active),feature_scan_group_size(),feature_scan_received_slot());send(line);
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    snprintf(line,sizeof line,"DMR running=%u owned=%u cc=%u ts=%u destination=%lu private=%u repeater=%u phase=%u error=%s codec_owner=%u\r\n",
        (unsigned)digital_dmr.running,(unsigned)digital_dmr.owned,radio_channel_get_color_code(channel_record),
        radio_channel_get_timeslot(channel_record),(unsigned long)(feature_dmr() ? radio_channel_get_destination(channel_record) : 0u),
        (unsigned)radio_channel_get_private(channel_record),(unsigned)radio_channel_get_repeater(channel_record),
        dv ? dv->phase : 0u,radio_dmr_error_name(digital_dmr.error),(unsigned)radio_codec_owner());send(line);
    dmr_diagnostic_status();
    snprintf(line,sizeof line,"TXSPAN captured_ms=%lu encoded_ms=%lu boundary_span_us=%lu\r\n",(unsigned long)pcmq.captured*20u,(unsigned long)encoded*20u,(unsigned long)(live.timing.blocks ? live.timing.last_boundary_us-live.timing.started_us : 0));send(line);
    snprintf(line,sizeof line,"LIVE_AUDIO peak=%u mean_abs=%lu clipped=%u mode=%08lx pcm_audio=%08lx rf_audio=%08lx stack_free_bytes=%lu\r\n",
        pcmq.peak,(unsigned long)(pcmq.captured ? pcmq.sum_abs/(pcmq.captured*160u) : 0),pcmq.clipped,
        (unsigned long)pcm_mode,(unsigned long)pcm_audio,(unsigned long)rf_audio,
        (unsigned long)(uxTaskGetStackHighWaterMark(NULL)*sizeof(StackType_t)));
    send(line);
}
static const char *message(void) {
    if(radio_busy(&control)) return "RX paused / clear voice";
    if(!strcmp(reason,"invalid_frequency")) return "Invalid value / check digits";
    if(!strcmp(reason,"frequency_saved")) return !strcmp(pref_state,"saved") ? "Setting saved" : "Setting changed / save pending";
    if(!strcmp(reason,"battery_low")) return "Battery too low for TX";
    if(!strcmp(reason,"calibration_invalid")) return "Calibration unavailable";
    if(control.state==RADIO_FAULT) return "Call stopped / see diagnostics";
    if(!strcmp(reason,"complete")) return "Call finished";
    if(!strcmp(reason,"released_before_rf")) return "Call cancelled before RF";
    return !strcmp(pref_state,"saved") ? "Channel settings retained" : "Settings: see diagnostics";
}
static bool mon_sync_active(uint32_t now) {
    return mon_running && mon_have_sync && now-mon_sync_us<400000u;
}
static void mon_context(char *line,size_t size) {
    const p25_receive_policy *c=&monitor.call;
    if(mon_running && !radio_busy(&control) && !mon_local_tone && !mon_replay && c->active) {
        if(c->state==P25_RX_CLEAR && c->group_valid && c->source_valid)
            snprintf(line,size,"RX %03X  TG %u  ID %lu",c->nac,c->group,(unsigned long)c->source);
        else snprintf(line,size,"%03X / %s",c->nac,p25_receive_label(c));
    } else snprintf(line,size,"%s",tx_fixed ? "FIXED RF TEST / HOLD PTT" : mon_enabled ? (mon_replay ? "20s delay / saved tail once" : mon_local_tone ? "20s unplug delay / 6s tone" : mon_output_tone ? "TEST TONE / decoding active" : mon_audio_enabled ? (rx_promiscuous ? "PROM / all NACs and talkgroups" : "NAC filter / all talkgroups") : "RX audio muted / PC setting") : mon_used ? mon_reason : message());
}
static void ui_meters_poll(void) {
    uint32_t now=hrc_micros(),begin=now;
    bool blocked=call_active || prepared || audio_on || hardware_running || rx_sampling;
    radio_signal_mode mode=blocked ? RADIO_SIGNAL_OFF : digital_dmr.running ? RADIO_SIGNAL_DMR
        : analog_fm.running && analog_fm.have_status ? RADIO_SIGNAL_FM
        : mon_running && !mon_local_tone && !mon_replay ? RADIO_SIGNAL_P25 : RADIO_SIGNAL_OFF;
    radio_signal_configure(&ui_strength,mode,frequency,now);
    ui_rssi_valid=radio_signal_read(&ui_strength,now,NULL);
    if(!ui_rssi_valid)ui_rssi_bars=0;
    if(blocked)return;
    if(!ui_battery_valid || (int32_t)(now-ui_battery_due)>=0) {
        ui_battery_mv=board.power->battery_mv();
        unsigned empty=board.battery_critical_mv ? board.battery_critical_mv : 6400u;
        ui_battery_pct=board.power->battery_pct ? board.power->battery_pct()
            : ui_battery_mv<=empty ? 0 : ui_battery_mv>=8200u ? 100
            : (uint8_t)((ui_battery_mv-empty)*100u/(8200u-empty));
        ui_battery_valid=true;ui_battery_due=now+1000000u;
    }
    if(radio_signal_due(&ui_strength,now) && board.radio->status
       && (!mon_running || mon_count(monitor.raw_head,monitor.raw_tail,MON_RAW_BLOCKS)<4u)
       ) {
        radio_status_t st={0};if(analog_fm.running)st=analog_fm.status;else board.radio->status(&st);
        radio_signal_sample(&ui_strength,now,st.rssi_dbm);
    }
    int16_t strength;
    if(radio_signal_read(&ui_strength,now,&strength)) {
        if(!ui_rssi_valid || abs((int)strength-ui_rssi_dbm)>=2)ui_rssi_dbm=strength;
        ui_rssi_valid=true;ui_signal_us=now;ui_rssi_bars=radio_signal_bars(ui_rssi_dbm);
    } else {
        ui_rssi_valid=false;ui_rssi_bars=0;
    }
    uint32_t elapsed=hrc_micros()-begin;
    if(elapsed>ui_meter_max_us)ui_meter_max_us=elapsed;
}
static const char *home_hint(void) {
    if(cps_link || cps_active)return "Programming / PTT paused";
    if(!strcmp(reason,"no_memories"))return "No saved channels";
    if(!strcmp(reason,"channel_read_failed"))return "Channel read failed";
    if(!frequency)return "Set a receive frequency";
    if(radio_busy(&control))return "Release PTT to finish";
    if(ptt_release_required)return "Release PTT before use";
    if(control.state==RADIO_FAULT)return "Open menu to review fault";
    if(radio_lights.locked)return "Locked / hold OK + *";
    if(!strcmp(pref_state,"save_failed"))return "Settings save failed";
    if(!strcmp(pref_state,"read_only"))return "Settings are read-only";
    if(!strcmp(reason,"empty_scan_list"))return "Scan list is empty";
    if(!strcmp(reason,"memory_saved"))return "Channel saved";
    if(!strcmp(reason,"channel_empty"))return "Channel is empty";
    if(feature_dmr() && digital_dmr.diagnostics.result==RADIO_DMR_TX_FAILED) {
        switch(digital_dmr.tx_error) {
        case DMR_TX_ERR_BUSY:return "Channel busy / try again";
        case DMR_TX_ERR_NO_REPEATER:return "Repeater did not answer";
        case DMR_TX_ERR_TIMEOUT:return "Transmit time limit";
        case DMR_TX_ERR_STALLED:return "Modem stalled / see Info";
        default:return "Call refused / see Info";
        }
    }
    return control.tx_enabled ? "" : "Transmit disabled";
}
static const char *ui_state_label(void) {
    if(control.state==RADIO_TX_DRAIN)return "Finishing call";
    if(radio_busy(&control))return "Voice call";
    if(control.state==RADIO_FAULT)return feature_dmr() && digital_dmr.error==RADIO_DMR_NO_CODEC ? "AMBE codec required" : "Radio fault / see Info";
    if(control.state==RADIO_RX_RESTORE)return "Returning to receive";
    if(control.state==RADIO_RX_PAUSED)return "Receive paused";
    if(!frequency)return "Set your frequency";
    if(cps_link || cps_active)return "Programming";
    if(normal_mode && feature_dmr()) {
        if(digital_dmr.error==RADIO_DMR_NO_CODEC)return "AMBE codec required";
        const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
        if(dv && dv->state==DMR_CALL_STATE_RX)return dv->caller.encrypted ? "Encrypted / muted"
            : dv->phase==DMR_CALL_PHASE_RX_BUSY ? "Call filtered" : "Receiving DMR";
        return channel_scan.running ? "CH SCAN / DMR" : "DMR listening";
    }
    if(normal_mode && feature_fm())return analog_fm.audio_open ? "Receiving FM" : channel_scan.running ? "CH SCAN / FM" : "FM listening";
    if(rx_tg_filter && monitor.call.active && monitor.call.group_valid && !feature_scan_group_allows(monitor.call.group))return "Talkgroup filtered";
    if(channel_scan.running && !mon_have_sync)return feature_scan_tg() ? "TG SCAN / listening" : "CH SCAN / listening";
    if(!mon_enabled)return normal_mode ? "Receive unavailable" : "Bench mode";
    if(mon_local_tone)return "Local speaker test";
    if(mon_replay)return "Saved audio playback";
    if(mon_output_tone)return "Decoder tone test";
    if(mon_running && monitor.call.active) {
        switch(monitor.call.state) {
        case P25_RX_CLEAR:return "Receiving voice";
        case P25_RX_ENCRYPTED:return "Encrypted / muted";
        case P25_RX_UNSUPPORTED:return "Unsupported / muted";
        case P25_RX_BAD_METADATA:return "Signal not decoded";
        default:return "Identifying call...";
        }
    }
    return "Listening";
}
static p25_ui_view ui_view(unsigned phase) {
    const p25_receive_policy *c=&monitor.call;
    p25_ui_view v={0};
    v.tx_active=radio_busy(&control);v.display_hz=v.tx_active ? control.tx_frequency : frequency;
    v.receive_hz=frequency;
    v.tx_frequency=control.tx_frequency;v.split=control.split;
    v.tx_nac=control.nac;v.tx_group=control.talkgroup;v.tx_source=control.source_id;
    v.battery_pct=ui_battery_pct;v.battery_low=ui_battery_valid && (ui_battery_pct<=15u
        || (board.battery_low_mv && ui_battery_mv<=board.battery_low_mv));
    v.rssi_valid=(mon_running || analog_fm.running || digital_dmr.running) && ui_rssi_valid
        && radio_signal_read(&ui_strength,hrc_micros(),NULL);
    v.rssi_bars=ui_rssi_bars;v.phase=(uint8_t)phase;
    if(!normal_mode || feature_p25()) {
        v.rx_active=mon_running && !v.tx_active && !mon_local_tone && !mon_replay && c->active;
        v.rx_nac=c->nac;v.rx_group=c->group;v.rx_source=c->source;
        v.rx_group_valid=c->group_valid;v.rx_source_valid=c->source_valid;
        v.rx_muted=c->state!=P25_RX_CLEAR || (rx_tg_filter && (!c->group_valid || !feature_scan_group_allows(c->group)));
    }
    v.mode_fm=normal_mode && feature_fm();v.mode_dmr=normal_mode && feature_dmr();
    v.wide_fm=(channel_record[12]&32u)!=0;v.locked=radio_lights.locked;
    v.scanning=channel_scan.running;v.tg_scanning=feature_scan_tg();v.channel_label=channel_label;v.squelch=channel_record[30];
    v.active_side=(uint8_t)feature_vfo();v.channel_mode=feature_memory()!=0 || channel_scan.running;
    v.channel_number=(uint16_t)(channel_scan.running ? channel_scan.cursor+1u : feature_memory());v.channel_name=(const char *)channel_record+14;
    if(channel_scan.running && feature_p25() && feature_scan_received_slot()) {
        v.channel_number=(uint16_t)feature_scan_received_slot();
        if(feature_scan_tg() || v.channel_number!=channel_scan.cursor+1u) {
            snprintf(scan_received_label,sizeof scan_received_label,"TG %u",feature_scan_received_group());
            v.channel_name=scan_received_label;
        }
    }
    v.tone=feature_u16(channel_record+(v.tx_active ? 26 : 28));
    if(v.mode_fm) {v.phase=analog_fm.audio_open ? 2 : 0;v.rx_active=analog_fm.audio_open;v.rx_muted=false;}
    if(v.mode_dmr) {
        const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
        v.tx_group=radio_channel_get_destination(channel_record);
        v.cc=(uint8_t)radio_channel_get_color_code(channel_record);v.ts=(uint8_t)radio_channel_get_timeslot(channel_record);
        v.private_call=radio_channel_get_private(channel_record);v.rx_active=dv && dv->state==DMR_CALL_STATE_RX;
        v.rx_group_valid=v.rx_source_valid=v.rx_active;v.rx_muted=false;v.phase=0;
        if(dv) {
            v.phase=dv->phase==DMR_CALL_PHASE_RX_VOICE && !dv->caller.encrypted ? 2 : v.rx_active ? 1 : 0;
            v.rx_muted=v.rx_active && (dv->caller.encrypted || dv->phase!=DMR_CALL_PHASE_RX_VOICE);
            if(v.rx_active) {v.rx_group=dv->caller.dst;v.rx_source=dv->caller.src;
                v.cc=dv->cc;v.ts=dv->ts;v.private_call=!dv->caller.group;}
        }
    }
    v.debug_active=!normal_mode || tx_fixed || mon_local_tone || mon_replay || mon_output_tone
        || !mon_pcm_backend || !mon_audio_enabled || tx_writer!=TX_WRITER_ALT1 || !tx_dac_restore;
    v.state=ui_state_label();v.hint=home_hint();v.filter=rx_promiscuous ? "PROM" : rx_tg_filter ? (v.mode_dmr ? "CC+ID" : "NAC+TG") : v.mode_dmr ? "CC" : "NAC filter";
    return v;
}
static uint32_t ui_header_token(const p25_ui_view *v) {
    return v->battery_pct | (uint32_t)v->battery_low<<7 | (uint32_t)v->rssi_bars<<8
        | (uint32_t)v->rssi_valid<<11 | (uint32_t)v->phase<<12;
}
static void mon_badge(unsigned phase) {
    p25_ui_view v=ui_view(phase);p25_ui_header(&v);ui_header_shown=ui_header_token(&v);
}
static void mon_indicator(void) {
    uint32_t now=hrc_micros();bool synced=mon_sync_active(now);
    bool voice=synced && mon_voice_us && now-mon_voice_us<400000u;
    unsigned phase=voice ? 2u : synced ? 1u : 0u;
    radio_receive_state(&control,mon_enabled,mon_running,synced,voice);
    board.power->led(LED_GREEN,synced);
    if(!display_ok || !mon_running)return;
    char context[48];mon_context(context,sizeof context);
    bool context_changed=strcmp(context,mon_shown_context)!=0;
    p25_ui_view v=ui_view(phase);uint32_t token=ui_header_token(&v);
    bool phase_changed=phase!=mon_badge_phase;
    if(!phase_changed && !context_changed && token==ui_header_shown)return;
    // Only changed header/call bands are touched; recorder/speaker IRQs stay live.
    uint32_t start=hrc_micros();gfx_frame_begin();
    if(token!=ui_header_shown)mon_badge(phase);
    if(context_changed || phase_changed) {
        p25_ui_call(&v);snprintf(mon_shown_context,sizeof mon_shown_context,"%s",context);
    }
    gfx_flush();uint32_t elapsed=hrc_micros()-start;
    if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
    mon_badge_sync=synced;mon_badge_phase=phase;
}
static void dmr_indicator(void) {
    if(!display_ok || !digital_dmr.running || menu_open || editing || rx_lab || cps_link || cps_active)return;
    if(digital_dmr.tx_armed) {dmr_ui_pending=true;return;}
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    if(!dv)return;
    uint32_t now=hrc_micros();
    p25_ui_view v=ui_view(0);uint32_t token=ui_header_token(&v);
    if(!dmr_ui_pending && dv->serial==dmr_ui_serial && token==ui_header_shown)return;
    if(!dmr_ui_pending && (int32_t)(now-dmr_ui_due)<0)return;
    // Encoding and IRQs running at higher priority do not feed the native
    // call queue: this controller does. Flush only before/after transmission.
    uint32_t start=hrc_micros();
    gfx_frame_begin();p25_ui_header(&v);p25_ui_channel(&v);p25_ui_call(&v);p25_ui_hint(&v);gfx_flush();
    radio_dmr_cost_record(&dmr_ui_cost,hrc_micros()-start);
    ui_header_shown=token;dmr_ui_serial=dv->serial;dmr_ui_due=now+100000u;
    dmr_ui_pending=false;
}
static void dmr_tx_preview(void) {
    if(!display_ok)return;
    p25_ui_view v=ui_view(0);
    v.tx_active=true;v.rx_active=false;v.phase=0;v.rssi_valid=false;
    v.cc=(uint8_t)radio_channel_get_color_code(channel_record);
    v.ts=(uint8_t)radio_channel_get_timeslot(channel_record);
    v.private_call=radio_channel_get_private(channel_record);
    v.display_hz=control.tx_frequency;v.state="Voice call";v.hint="";
    uint32_t start=hrc_micros();
    gfx_frame_begin();p25_ui_header(&v);p25_ui_channel(&v);p25_ui_call(&v);p25_ui_hint(&v);gfx_flush();
    radio_dmr_cost_record(&dmr_ui_cost,hrc_micros()-start);
    // The preview has no matching RX serial/token. Always restore the newest
    // idle/RX view, even if PTT was released before the native call began.
    dmr_ui_pending=true;
}
static const char *function_name(unsigned action) {
    static const char *const names[]={"Default","Disabled","Frequency / Channel","Side A / B","Scan","Cycle power","Broadcast FM","Radio status","Keypad lock"};
    return action<RADIO_FUNCTION_COUNT ? names[action] : "Disabled";
}
static const char *power_name(void) {
    unsigned level=feature_tx_power();
    return board.power_names && level<board.power_count ? board.power_names[level] : "Unavailable";
}
static void power_cycle(void) {
    unsigned count=board.power_count<RADIO_POWER_LEVELS ? board.power_count : RADIO_POWER_LEVELS;
    if(count && radio_functions_set_power(channel_record,(feature_tx_power()+1u)%count))pref_state="pending";
}
static unsigned menu_count(void) {return menu_page==MENU_MEMORY ? 6u : menu_page==MENU_ROOT ? 5u
    : menu_page==MENU_CHANNEL ? 8u : menu_page==MENU_FUNCTIONS || menu_page==MENU_DMR ? 4u
    : menu_page==MENU_AUDIO_TX || menu_page==MENU_SETTINGS ? 2u : menu_page==MENU_FM ? 6u
    : menu_page==MENU_DIAGNOSTICS && !DM32_LAB_DIAGNOSTICS ? 1u : 3u;}
// Each leaf has one fixed parent; Back restores the item that opened it.
static void menu_back(void) {
    switch(menu_page) {
    case MENU_MEMORY:menu_page=MENU_ROOT;menu_item=0;break;
    case MENU_CHANNEL:menu_page=MENU_ROOT;menu_item=1;break;
    case MENU_AUDIO_TX:menu_page=MENU_ROOT;menu_item=2;break;
    case MENU_SETTINGS:menu_page=MENU_ROOT;menu_item=3;break;
    case MENU_TOOLS:menu_page=MENU_ROOT;menu_item=4;break;
    case MENU_SCAN:menu_page=MENU_MEMORY;menu_item=4;break;
    case MENU_VOICE:menu_page=MENU_AUDIO_TX;menu_item=0;break;
    case MENU_TRANSMIT:menu_page=MENU_AUDIO_TX;menu_item=1;break;
    case MENU_DISPLAY:menu_page=MENU_SETTINGS;menu_item=0;break;
    case MENU_FUNCTIONS:menu_page=MENU_SETTINGS;menu_item=1;break;
    case MENU_DIAGNOSTICS:menu_page=MENU_TOOLS;menu_item=2;break;
    case MENU_FM:case MENU_DMR:menu_page=MENU_CHANNEL;menu_item=5;break;
    default:menu_open=false;break;
    }
}
static void menu_row(unsigned item,char *label,size_t label_n,char *value,size_t value_n) {
    label[0]=value[0]=0;
    if(menu_page==MENU_ROOT) {
        const char *names[]={"Operating","Channel","Audio & TX","Settings","Tools"};
        const char *values[]={"Frequency / Channel, A/B, scan","Frequencies, mode and filters",
            "Voice, radio ID, power, timeout","Display, keypad and buttons","Broadcast FM and radio status"};
        snprintf(label,label_n,"%s",names[item]);snprintf(value,value_n,"%s",values[item]);
    } else if(menu_page==MENU_AUDIO_TX) {
        snprintf(label,label_n,"%s",item ? "Transmit" : "Voice & ID");
        if(item)snprintf(value,value_n,"Power %s / timeout %us",power_name(),feature_tx_tot());
        else snprintf(value,value_n,"Destination, radio ID, mic gain");
    } else if(menu_page==MENU_SETTINGS) {
        snprintf(label,label_n,"%s",item ? "Button actions" : "Display & keys");
        snprintf(value,value_n,"%s",item ? "Assign P1, P2, SK1 and SK2" : "Screen, keypad light and lock");
    } else if(menu_page==MENU_TOOLS) {
        const char *names[]={"Broadcast FM","Broadcast frequency","Diagnostics"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"Listen / pauses radio channel");
        else if(item==1) {uint32_t khz=radio_functions_get_broadcast_khz(global_record);snprintf(value,value_n,"%lu.%03lu MHz",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));}
        else snprintf(value,value_n,"%s",DM32_LAB_DIAGNOSTICS ? "Status and optional test tools" : "Build, battery and counters");
    } else if(menu_page==MENU_TRANSMIT) {
        const char *names[]={"Transmit permission","Channel power","TX timeout"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%s",owner_tx_inhibit ? "Inhibited / select to enable" : "Enabled / select to inhibit");
        else if(item==1)snprintf(value,value_n,"%s / select next",power_name());
        else snprintf(value,value_n,"%u seconds",feature_tx_tot());
    } else if(menu_page==MENU_FUNCTIONS) {
        const char *names[]={"P1 button","P2 button","SK1 button","SK2 button"};
        snprintf(label,label_n,"%s",names[item]);
        snprintf(value,value_n,"%s / select next",function_name(radio_functions_get_action(global_record,(radio_function_key)item)));
    } else if(menu_page==MENU_CHANNEL) {
        const char *names[]={"Receive frequency","Transmit frequency","Use simplex",feature_dmr() ? "Color code" : "NAC code","Modulation",feature_dmr() ? "DMR settings" : "FM settings","Receive only","Receive filter"};
        snprintf(label,label_n,"%s",names[item]);
        if(item<=1) {uint32_t hz=item ? control.tx_frequency : frequency;snprintf(value,value_n,"%lu.%06lu MHz",(unsigned long)(hz/1000000u),(unsigned long)(hz%1000000u));}
        else if(item==2)snprintf(value,value_n,"%s",control.split ? "Set TX to receive frequency" : "TX and RX use same frequency");
        else if(item==3) {if(feature_dmr())snprintf(value,value_n,"%u",radio_channel_get_color_code(channel_record));
            else snprintf(value,value_n,"%03lX (hex)",(unsigned long)control.nac);}
        else if(item==4)snprintf(value,value_n,"%s / select next",feature_mode_name());
        else if(item==5)snprintf(value,value_n,"%s",feature_dmr() ? "Slot, call type and access" : feature_fm() ? "Width, squelch and tones" : "Select FM or DMR first");
        else if(item==6)snprintf(value,value_n,"%s",(channel_record[12]&16u) ? "On / channel TX disabled" : "Off / normal owner TX setting");
        else snprintf(value,value_n,"%s",feature_dmr() ? (rx_promiscuous ? "PROM / any CC / selected slot" : rx_tg_filter ? "Color code + destination" : "Color code / all groups / slot")
            : rx_promiscuous ? "PROM / all NACs and talkgroups" : rx_tg_filter ? "Configured NAC + talkgroup" : "Configured NAC / all groups");
    } else if(menu_page==MENU_VOICE) {
        const char *names[]={feature_dmr() ? "TX destination" : "TX talkgroup","Radio ID","Digital mic gain"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%lu",(unsigned long)(feature_dmr() ? radio_channel_get_destination(channel_record) : control.talkgroup));
        else if(item==1)snprintf(value,value_n,"%lu",(unsigned long)control.source_id);
        else snprintf(value,value_n,"%u dB",mic_gain_db);
    } else if(menu_page==MENU_DMR) {
        const char *names[]={"Color code","Timeslot","Call type","Operation"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%u",radio_channel_get_color_code(channel_record));
        else if(item==1)snprintf(value,value_n,"Slot %u",radio_channel_get_timeslot(channel_record));
        else if(item==2)snprintf(value,value_n,"%s",radio_channel_get_private(channel_record) ? "Private / unit to unit" : "Group / talkgroup");
        else snprintf(value,value_n,"%s",radio_channel_get_repeater(channel_record) ? "Repeater / hotspot" : "Direct / simplex");
    } else if(menu_page==MENU_MEMORY) {
        const char *names[]={"Operating mode","Side A / B","Save channel","Select channel","Scan lists","Selected zone"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%s",feature_memory() ? "Channel / select for Frequency" : "Frequency / select for Channel");
        else if(item==1)snprintf(value,value_n,"Active side %c / select other",'A'+feature_vfo());
        else if(item==5)snprintf(value,value_n,"%.12s / select next",feature_zone_name);
        else snprintf(value,value_n,"%s",item==4 ? "16 named lists / CH or TG" : "Choose channel 001 to 256");
    } else if(menu_page==MENU_SCAN) {
        const char *names[]={channel_scan.running ? "Stop scanning" : "Start scanning","Selected scan list","Edit list in CPS"};
        snprintf(label,label_n,"%s",names[item]);
        uint8_t descriptor[32];feature_scan_description(descriptor);
        if(item==0)snprintf(value,value_n,"%s / dwell %ums / hold %ums",descriptor[12] ? "TG SCAN" : "CH SCAN",feature_u16(descriptor+18),feature_u16(descriptor+20));
        else if(item==1)snprintf(value,value_n,"%u: %.12s / next",global_record[12]+1u,descriptor[0] ? (const char *)descriptor : "Unused");
        else snprintf(value,value_n,"Type, members, timing and reply");
    } else if(menu_page==MENU_DISPLAY) {
        const char *names[]={"Screen off after","Keypad light","Lock keypad"};
        snprintf(label,label_n,"%s",names[item]);
        if(item<2) {unsigned seconds=item ? radio_lights.keypad_seconds : radio_lights.screen_seconds;
            if(seconds)snprintf(value,value_n,"%u seconds",seconds);else snprintf(value,value_n,"Always on");}
        else snprintf(value,value_n,"Hold OK + * for 1s to unlock");
    } else if(menu_page==MENU_FM) {
        const char *names[]={"Bandwidth","Squelch","TX tone type","TX tone code","RX tone type","RX tone code"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%s",(channel_record[12]&32u) ? "Wide / 25 kHz" : "Narrow / 12.5 kHz");
        else if(item==1)snprintf(value,value_n,"%u / 0 opens squelch",channel_record[30]);
        else feature_tone_label(item<4 ? 26 : 28,value,value_n);
    } else {
#if DM32_LAB_DIAGNOSTICS
        const char *names[]={"Radio status","Run frame test",normal_mode ? "Enter bench mode" : "Return to radio"};
        snprintf(label,label_n,"%s",names[item]);
        snprintf(value,value_n,"%s",item==0 ? "Build, battery and counters" : item==1 ? "Software only / no RF" : "Optional diagnostic tools");
#else
        snprintf(label,label_n,"Radio status");
        snprintf(value,value_n,"Build, battery and counters");
#endif
    }
}
static void broadcast_entry_label(char *line,size_t size) {
    uint32_t khz;
    if(radio_broadcast_input_khz(frequency_digits,digit_count,&khz))
        snprintf(line,size,"%lu.%03lu MHz",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));
    else snprintf(line,size,"%.*s_",(int)digit_count,frequency_digits);
}
static void broadcast_screen(void) {
    if(!display_ok)return;
    char line[48];p25_ui_view v=ui_view(0);
    v.mode_fm=true;v.mode_dmr=false;v.tx_active=false;
    v.rx_active=broadcast.audio_open;v.phase=broadcast.audio_open ? 2u : 0u;v.rssi_valid=false;
    gfx_frame_begin();gfx_clear(P25_UI_BG);p25_ui_palette();p25_ui_header(&v);
    gfx_text(&font_12x24,8,52,"Broadcast FM",P25_UI_FG);
    uint32_t khz=broadcast.khz ? broadcast.khz : radio_functions_get_broadcast_khz(global_record);
    snprintf(line,sizeof line,"%lu.%03lu MHz",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));
    gfx_text(&font_12x24,8,104,line,P25_UI_CYAN);
    gfx_text(&font_8x16,8,156,broadcast.failed ? "Receiver unavailable" : broadcast.busy ? "Tuning..." : broadcast.have_status && broadcast.status.stereo ? "Stereo" : "Listening",P25_UI_FG);
    if(editing) {
        gfx_text(&font_6x12,8,182,"New frequency (MHz)",P25_UI_MUTED);
        broadcast_entry_label(line,sizeof line);
        gfx_round_fill(4,200,212,36,P25_UI_PANEL);gfx_text(&font_12x24,12,205,line,P25_UI_FG);
        const char *hint=!strcmp(reason,"invalid_frequency") ? "Use 65-108 MHz / 50 kHz steps"
            : broadcast.busy ? "Wait for tuning, then press OK" : "Example: 101#7 or 1017";
        gfx_text(&font_6x12,8,245,hint,!strcmp(reason,"invalid_frequency") ? P25_UI_AMBER : P25_UI_MUTED);
        gfx_text(&font_6x12,8,268,"OK: tune  *: erase  #: decimal",P25_UI_MUTED);
        gfx_text(&font_8x16,8,290,"Back: cancel entry",P25_UI_CYAN);
    } else {
        gfx_text(&font_8x16,8,192,"Radio channel paused",P25_UI_MUTED);
        gfx_text(&font_6x12,8,228,"P1: seek down  P2: seek up",P25_UI_MUTED);
        gfx_text(&font_6x12,8,248,"Up/Down: tune 50 kHz",P25_UI_MUTED);
        gfx_text(&font_6x12,8,268,"Keypad: frequency  OK: tune",P25_UI_MUTED);
        gfx_text(&font_8x16,8,290,"Back: return to radio",P25_UI_CYAN);
    }
    gfx_flush();
}
static void broadcast_leave(bool ptt_down) {
    radio_broadcast_stop(&broadcast);broadcast_show=false;
    editing=false;digit_count=0;edit_from_menu=false;
    // A key held during broadcast must never become an implicit TX on exit.
    if(ptt_down || !hrc_pin_read(PIN_PTT)) {ptt_release_required=true;ptt_release_seen=false;}
    (void)normal_resume();screen("HOME");
}
static void broadcast_toggle(void) {
    if(broadcast_show) {broadcast_leave(false);return;}
    if(call_active || prepared || rx_job || audio_on || hardware_running)return;
    feature_stop_scan(true);feature_pause();preferences_poll(false);
    session_enabled=armed=false;editing=menu_open=rx_lab=false;
    board_rf_safe();board.radio->audio(false);
    bool started=radio_broadcast_start(&broadcast,board.bcast,radio_functions_get_broadcast_khz(global_record));
    broadcast_show=true;broadcast_due=hrc_micros();
    if(!started)broadcast.failed=true;
    radio_inhibit(&control,true);control.state=RADIO_RX_PAUSED;
    board.power->led(LED_GREEN,false);reason="broadcast_fm";broadcast_screen();
}
static void screen(const char *title) {
    (void)title;
    // Full LCD flush remains frozen while audio/PHY runs.
    if(!display_ok || audio_on || hardware_running || rx_sampling || mon_running)return;
    if(broadcast_show) {broadcast_screen();return;}
    if(!ui_battery_valid)ui_meters_poll();
    char line[48];p25_ui_view v=ui_view(0);
    gfx_frame_begin();gfx_clear(P25_UI_BG);
    if(!rx_job && !rx_lab && !menu_open && !editing) {
        p25_ui_home(&v);mon_context(mon_shown_context,sizeof mon_shown_context);
        ui_header_shown=ui_header_token(&v);mon_badge_sync=false;mon_badge_phase=0;
        gfx_flush();return;
    }
    p25_ui_palette();p25_ui_header(&v);
    if(rx_job) {
        gfx_text(&font_12x24,8,50,"RX capture",P25_UI_FG);
        gfx_text(&font_8x16,8,100,!strcmp(rx_reason,"recording") ? "Recording RF input" : "Waiting to record",P25_UI_FG);
        gfx_text(&font_8x16,8,140,"Transmitter disabled",P25_UI_AMBER);
        gfx_text(&font_8x16,8,284,"Back: cancel",P25_UI_CYAN);
    } else if(rx_lab) {
        gfx_text(&font_12x24,8,46,"Radio status",P25_UI_FG);
        gfx_text(&font_8x16,8,84,DM32_LAB_DIAGNOSTICS ? (rx_checked ? (rx_pass ? "Frame test: PASS" : "Frame test: FAIL") : "Frame test: not run") : "Operational counters",P25_UI_CYAN);
        snprintf(line,sizeof line,"PCM loss %lu / overflow %u",(unsigned long)driver_loss,pcmq.overflow);
        p25_ui_text(&font_6x12,8,114,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"RX frames %lu / FEC %lu",(unsigned long)(mon_used ? monitor.voices : 0),(unsigned long)(mon_used ? monitor.corrected : 0));
        p25_ui_text(&font_6x12,8,138,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Refill %lu / raw loss %lu",(unsigned long)(mon_used ? monitor.starved : 0),(unsigned long)(mon_used ? monitor.raw_overflow : 0));
        p25_ui_text(&font_6x12,8,162,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Mic %u dB / clip %lu",mic_gain_db,(unsigned long)pcmq.clipped);
        p25_ui_text(&font_6x12,8,186,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Battery %u.%02u V / cal %s",ui_battery_mv/1000u,(ui_battery_mv%1000u)/10u,bf_cal_source());
        p25_ui_text(&font_6x12,8,210,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Settings: %s",pref_dirty ? "pending" : pref_state);
        p25_ui_text(&font_6x12,8,234,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Build %s / %s",BENCH_GIT,mon_used ? mon_reason : reason);
        p25_ui_text(&font_6x12,8,258,204,line,P25_UI_MUTED);
        gfx_text(&font_6x12,8,288,DM32_LAB_DIAGNOSTICS ? "OK: frame test   Back: return" : "Back: return",P25_UI_CYAN);
    } else if(menu_open) {
        const char *heading=menu_page==MENU_ROOT ? "Radio menu" : menu_page==MENU_CHANNEL ? "Channel"
            : menu_page==MENU_VOICE ? "Voice & ID" : menu_page==MENU_MEMORY ? "Operating"
            : menu_page==MENU_SCAN ? "Scan lists" : menu_page==MENU_DISPLAY ? "Display & keys"
            : menu_page==MENU_FM ? "FM settings" : menu_page==MENU_DMR ? "DMR settings"
            : menu_page==MENU_TRANSMIT ? "Transmit" : menu_page==MENU_FUNCTIONS ? "Button actions"
            : menu_page==MENU_AUDIO_TX ? "Audio & TX" : menu_page==MENU_SETTINGS ? "Settings" : menu_page==MENU_TOOLS ? "Tools" : "Diagnostics";
        gfx_text(&font_12x24,8,44,heading,P25_UI_FG);
        unsigned first=menu_item>=5u ? menu_item-4u : 0u;
        for(unsigned row=0;row<5u && first+row<menu_count();++row) {
            unsigned i=first+row;
            char label[32],value[48];menu_row(i,label,sizeof label,value,sizeof value);
            int y=78+(int)row*39;
            if(i==menu_item) {gfx_round_fill(4,y-2,212,37,P25_UI_PANEL);gfx_fill(4,y+1,3,28,P25_UI_CYAN);}
            p25_ui_text(&font_8x16,12,y,196,label,i==menu_item ? P25_UI_CYAN : P25_UI_FG);
            p25_ui_text(&font_6x12,12,y+18,196,value,P25_UI_MUTED);
        }
        gfx_text(&font_6x12,8,292,"Up/Down: choose  OK: open  Back",P25_UI_MUTED);
    } else {
        gfx_text(&font_12x24,8,48,field_names[field],P25_UI_FG);
        uint32_t current=field==EDIT_RX ? frequency : field==EDIT_TX ? control.tx_frequency : field==EDIT_NAC ? control.nac
            : field==EDIT_TG ? (feature_dmr() ? radio_channel_get_destination(channel_record) : control.talkgroup) : field==EDIT_ID ? control.source_id : field==EDIT_MIC ? mic_gain_db
            : field==EDIT_MEMORY || field==EDIT_RECALL ? feature_memory() : field==EDIT_SCREEN ? radio_lights.screen_seconds
            : field==EDIT_LIGHT ? radio_lights.keypad_seconds : field==EDIT_SQL ? channel_record[30]
            : field==EDIT_DMR_CC ? radio_channel_get_color_code(channel_record)
            : field==EDIT_TOT ? feature_tx_tot() : field==EDIT_BCAST ? radio_functions_get_broadcast_khz(global_record)*1000u
            : feature_tone(field==EDIT_TXTONE ? 26 : 28).value;
        if(field==EDIT_MEMORY || field==EDIT_RECALL)snprintf(line,sizeof line,"Current %s",channel_label[0] ? channel_label : "Frequency");
        else if(field<=EDIT_TX || field==EDIT_BCAST)snprintf(line,sizeof line,"Current %lu.%06lu MHz",(unsigned long)(current/1000000u),(unsigned long)(current%1000000u));
        else if(field==EDIT_NAC)snprintf(line,sizeof line,"Current %03lX (hex)",(unsigned long)current);
        else if((field==EDIT_TXTONE || field==EDIT_RXTONE) && feature_tone(field==EDIT_TXTONE ? 26 : 28).type>=TONE_DCS)
            snprintf(line,sizeof line,"Current DCS %03lo",(unsigned long)current);
        else snprintf(line,sizeof line,"Current %lu%s",(unsigned long)current,field==EDIT_MIC ? " dB" : "");
        p25_ui_text(&font_8x16,8,88,204,line,P25_UI_MUTED);
        char digits[9]="________";memcpy(digits,frequency_digits,digit_count);
        if(field<=EDIT_TX)snprintf(line,sizeof line,"%.3s.%.4s",digits,digits+3);
        else if(field==EDIT_BCAST)broadcast_entry_label(line,sizeof line);
        else {digits[field_digits()]=0;snprintf(line,sizeof line,"%s",digits);}
        gfx_round_fill(4,118,212,46,P25_UI_PANEL);gfx_text(&font_12x24,12,128,line,P25_UI_FG);
        const char *range=field<=EDIT_TX ? "7 digits; e.g. 1457000" : field==EDIT_BCAST ? "65-108 MHz; 101#7 or 1017" : field==EDIT_TOT ? "15-600 seconds" : field==EDIT_NAC ? "Hex 000-FFF; Up/Down A-F"
            : field==EDIT_TG ? (feature_dmr() ? "1 to 16777215" : "1 to 65535") : field==EDIT_ID ? "1 to 16777215" : field==EDIT_MIC ? "0 to 42 dB"
            : field==EDIT_MEMORY || field==EDIT_RECALL ? "Channel number 001 to 256" : field==EDIT_SCREEN || field==EDIT_LIGHT ? "0-600 seconds; 0 always on"
            : field==EDIT_DMR_CC ? "0 to 15" : field==EDIT_SQL ? "0-9; 0 opens squelch" : feature_tone(field==EDIT_TXTONE ? 26 : 28).type>=TONE_DCS ? "DCS octal code; 0 disables" : "CTCSS Hz x 10; 0 disables";
        p25_ui_text(&font_8x16,8,184,204,range,P25_UI_MUTED);
        if(!strcmp(reason,"invalid_frequency") || !strcmp(reason,"channel_empty"))gfx_text(&font_8x16,8,220,"Check value and try again",P25_UI_AMBER);
        gfx_text(&font_8x16,8,268,field==EDIT_RECALL ? "OK: select  Back: cancel" : "OK: save   Back: cancel",P25_UI_CYAN);
        gfx_text(&font_6x12,8,294,field==EDIT_BCAST ? "*: erase  #: decimal" : "*: erase last digit",P25_UI_MUTED);
    }
    gfx_flush();
}
static void home_hint_refresh(void) {
    if(!display_ok || call_active || prepared || rx_job || editing || menu_open || rx_lab)return;
    if(!mon_running) {screen("HOME");return;}
    uint32_t start=hrc_micros();gfx_frame_begin();p25_ui_view v=ui_view(mon_badge_phase);
    p25_ui_hint(&v);gfx_flush();
    uint32_t elapsed=hrc_micros()-start;if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
}
static bool ptt_release_poll(bool filtered_down) {
    if(!ptt_release_required)return false;
    // A real held key keeps this shared pin LOW, even while the logical input
    // filter or recent host UART data temporarily reports no press. Require a
    // continuous physical HIGH plus logical release before accepting new PTT.
    if(filtered_down || !hrc_pin_read(PIN_PTT)) {ptt_release_seen=false;return false;}
    uint32_t now=hrc_micros();
    if(!ptt_release_seen) {ptt_release_since=now;ptt_release_seen=true;return false;}
    if(now-ptt_release_since<50000u)return false;
    ptt_release_required=false;return true;
}
#if DM32_LAB_DIAGNOSTICS
static bool rx_frame_test(void) {
    p25_rx r; p25_rx_init(&r);
    uint8_t payloads[9][11],frame[216],decoded[11];unsigned errors;
    for(unsigned i=0;i<99;++i) ((uint8_t*)payloads)[i]=(uint8_t)(i*37u);
    p25_live_ldu(frame,(const uint8_t (*)[11])payloads,false);
    bool done=false;
    for(unsigned i=0;i<864;++i) done=p25_rx_push(&r,(frame[i/4]>>(6-2*(i%4)))&3);
    if(!done || r.nac!=0x293 || r.duid!=5) return false;
    for(unsigned i=0;i<9;++i) if(!p25_rx_voice(r.frame,i,decoded,&errors) || errors || memcmp(decoded,payloads[i],11)) return false;
    return true;
}
#endif
static void menu_edit(edit_field next) {
    preferences_poll(false);
    field=next;edit_from_menu=true;editing=true;menu_open=false;digit_count=0;
    reason=next==EDIT_RECALL ? "enter_channel" : "enter_frequency";
}
static void menu_transmit(void) {
    armed=false;
    if(normal_mode && control.tx_enabled) {
        owner_tx_inhibit=true;radio_inhibit(&control,true);reason="tx_inhibited";pref_state="pending";
    } else if(!channel_in_band(control.tx_frequency,true) || !channel_in_band(frequency,false))reason="enter_frequency";
    else if(!bf_cal_valid())reason="calibration_invalid";
    else if(board.power->battery_mv()<board.battery_critical_mv)reason="battery_low";
    else {owner_tx_inhibit=false;(void)normal_resume();reason="ptt_ready";pref_state="pending";}
}
// Key actions are accepted only on debounced fresh presses; saves are deferred.
static void local_action(unsigned action,bool ptt_down) {
    if(cps_link || cps_active)return;
    if(broadcast_show) {
        // P1/P2 have fixed seek meanings here, independent of home shortcuts.
        bool toggle=(action==ACT_MONITOR && radio_functions_get_action(global_record,RADIO_FUNCTION_SK1)==RADIO_FUNCTION_BROADCAST)
            || (action==ACT_AB && radio_functions_get_action(global_record,RADIO_FUNCTION_SK2)==RADIO_FUNCTION_BROADCAST);
        if(toggle) {broadcast_leave(ptt_down);return;}
        if(action==ACT_BACK) {
            if(editing) {editing=false;digit_count=0;reason="broadcast_fm";broadcast_screen();}
            else broadcast_leave(ptt_down);
            return;
        }
        if(ptt_down)return;
        if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9) {
            if(!editing) {field=EDIT_BCAST;editing=true;edit_from_menu=false;digit_count=0;}
            if(digit_count<field_digits())frequency_digits[digit_count++]=(char)('0'+action-ACT_DIGIT_0);
            reason="enter_frequency";
        } else if(action==ACT_CONTEXT) {
            if(!editing) {field=EDIT_BCAST;editing=true;edit_from_menu=false;digit_count=0;}
            if(digit_count && digit_count<field_digits() && !memchr(frequency_digits,'.',digit_count))
                frequency_digits[digit_count++]='.';
            reason="enter_frequency";
        } else if(action==ACT_QUICK && editing) {
            if(digit_count)--digit_count;
            reason="enter_frequency";
        } else if(action==ACT_SELECT && editing) {
            uint32_t khz;
            if(!radio_broadcast_input_khz(frequency_digits,digit_count,&khz))reason="invalid_frequency";
            else if(broadcast.busy)reason="broadcast_busy";
            else if(broadcast.owned && broadcast.running
                    && (khz==broadcast.khz || radio_broadcast_tune(&broadcast,khz))) {
                (void)radio_functions_set_broadcast_khz(global_record,khz);pref_state="pending";
                editing=false;digit_count=0;reason="broadcast_fm";
            }
        } else if(action==ACT_NAV_LEFT || action==ACT_NAV_RIGHT) {
            editing=false;digit_count=0;reason="broadcast_fm";
            (void)radio_broadcast_seek(&broadcast,action==ACT_NAV_RIGHT);
        } else if(action==ACT_NAV_UP || action==ACT_NAV_DOWN) {
            editing=false;digit_count=0;reason="broadcast_fm";
            uint32_t khz=broadcast.khz;
            if(action==ACT_NAV_UP)khz=khz>=RADIO_BCAST_MAX_KHZ ? RADIO_BCAST_MIN_KHZ : khz+RADIO_BCAST_STEP_KHZ;
            else khz=khz<=RADIO_BCAST_MIN_KHZ ? RADIO_BCAST_MAX_KHZ : khz-RADIO_BCAST_STEP_KHZ;
            (void)radio_broadcast_tune(&broadcast,khz);
        }
        broadcast_screen();return;
    }
    // Reassign only home-screen function keys; menu navigation and * retain
    // their fixed meanings, including the OK + * unlock chord.
    if(!ptt_down && !call_active && !prepared && !editing && !menu_open && !rx_lab) {
        int key=action==ACT_NAV_LEFT ? RADIO_FUNCTION_P1 : action==ACT_NAV_RIGHT ? RADIO_FUNCTION_P2
            : action==ACT_MONITOR ? RADIO_FUNCTION_SK1 : action==ACT_AB ? RADIO_FUNCTION_SK2 : -1;
        if(key>=0) {
            unsigned fn=radio_functions_get_action(global_record,(radio_function_key)key);
            if(fn==RADIO_FUNCTION_NONE)return;
            if(fn==RADIO_FUNCTION_BROADCAST) {broadcast_toggle();return;}
            if(fn==RADIO_FUNCTION_SCAN) {
                if(channel_scan.running) {feature_stop_scan(true);feature_pause();reason="listening";}
                else (void)feature_scan_start();
                screen("HOME");return;
            }
            if(fn==RADIO_FUNCTION_POWER || fn==RADIO_FUNCTION_LOCK) {
                feature_stop_scan(true);feature_pause();
                if(fn==RADIO_FUNCTION_POWER)power_cycle();
                else {radio_lights.locked=true;reason="keypad_locked";}
                screen("HOME");return;
            }
            action=fn==RADIO_FUNCTION_MEMORY ? ACT_NAV_LEFT : fn==RADIO_FUNCTION_AB ? ACT_AB : ACT_NAV_RIGHT;
        }
    }
    if(!call_active && !prepared) {feature_stop_scan(true);feature_pause();}
    if(rx_job) {if(action==ACT_BACK) {rx_end("cancelled");screen("INFO");}return;}
    if(action==ACT_BACK) {
        if(call_active || prepared) {control.cancel=true;return;}
        if(editing) {
            editing=false;digit_count=0;menu_open=edit_from_menu;edit_from_menu=false;
        } else if(rx_lab) {
            rx_lab=false;menu_open=diag_from_menu;diag_from_menu=false;
        } else if(menu_open && menu_page!=MENU_ROOT) {
            menu_back();
        } else menu_open=false;
        screen("HOME");return;
    }
    if(ptt_down || call_active || prepared)return;
    if(rx_lab) {
#if DM32_LAB_DIAGNOSTICS
        if(action==ACT_SELECT) {rx_pass=rx_frame_test();rx_checked=true;screen("INFO");}
#endif
        return;
    }
    if(menu_open) {
        if(action==ACT_NAV_UP)menu_item=(menu_item+menu_count()-1u)%menu_count();
        else if(action==ACT_NAV_DOWN)menu_item=(menu_item+1u)%menu_count();
        else if(action==ACT_SELECT) {
            if(menu_page==MENU_ROOT) {
                static const ui_menu groups[]={MENU_MEMORY,MENU_CHANNEL,MENU_AUDIO_TX,MENU_SETTINGS,MENU_TOOLS};
                menu_page=groups[menu_item];menu_item=0;
            } else if(menu_page==MENU_AUDIO_TX) {
                menu_page=menu_item ? MENU_TRANSMIT : MENU_VOICE;menu_item=0;
            } else if(menu_page==MENU_SETTINGS) {
                menu_page=menu_item ? MENU_FUNCTIONS : MENU_DISPLAY;menu_item=0;
            } else if(menu_page==MENU_TOOLS) {
                if(menu_item==0) {broadcast_toggle();return;}
                else if(menu_item==1)menu_edit(EDIT_BCAST);
                else {menu_page=MENU_DIAGNOSTICS;menu_item=0;}
            } else if(menu_page==MENU_TRANSMIT) {
                if(menu_item==0)menu_transmit();
                else if(menu_item==1)power_cycle();
                else menu_edit(EDIT_TOT);
            } else if(menu_page==MENU_FUNCTIONS) {
                unsigned next=(radio_functions_get_action_raw(global_record,(radio_function_key)menu_item)+1u)%RADIO_FUNCTION_COUNT;
                (void)radio_functions_set_action(global_record,(radio_function_key)menu_item,(radio_function_action)next);pref_state="pending";
            } else if(menu_page==MENU_CHANNEL) {
                if(menu_item==0)menu_edit(EDIT_RX);
                else if(menu_item==1)menu_edit(EDIT_TX);
                else if(menu_item==3)menu_edit(feature_dmr() ? EDIT_DMR_CC : EDIT_NAC);
                else if(menu_item==2) {
                    if(channel_in_band(frequency,true)) {control.split=false;control.tx_frequency=frequency;reason="frequency_saved";pref_state="pending";}
                    else reason="invalid_frequency";
                } else if(menu_item==4) {
                    feature_capture();
                    radio_channel_mode_t next=(radio_channel_mode_t)((radio_channel_get_mode(channel_record)+1u)%3u);
                    if(radio_channel_set_mode(channel_record,next)) {
                        feature_apply();radio_complete(&control,false);normal_permission();pref_state="pending";
                    }
                }
                else if(menu_item==5) {if(feature_fm() || feature_dmr()) {menu_page=feature_dmr() ? MENU_DMR : MENU_FM;menu_item=0;}}
                else if(menu_item==6) {channel_record[12]^=16u;pref_state="pending";}
                else {unsigned next=(feature_filter()+1u)%3u;rx_promiscuous=next==1u;rx_tg_filter=next==2u;pref_state="pending";reason="rx_filter_saved";}
            } else if(menu_page==MENU_VOICE) {
                menu_edit(menu_item==0 ? EDIT_TG : menu_item==1 ? EDIT_ID : EDIT_MIC);
            } else if(menu_page==MENU_DMR) {
                if(menu_item==0)menu_edit(EDIT_DMR_CC);
                else if(menu_item==1)(void)radio_channel_set_timeslot(channel_record,radio_channel_get_timeslot(channel_record)==1u ? 2u : 1u);
                else if(menu_item==2)radio_channel_set_private(channel_record,!radio_channel_get_private(channel_record));
                else radio_channel_set_repeater(channel_record,!radio_channel_get_repeater(channel_record));
                pref_state="pending";
            } else if(menu_page==MENU_MEMORY) {
                if(menu_item==0) {
                    (void)feature_toggle_mode();
                    menu_open=false;
                } else if(menu_item==1) {(void)feature_select_vfo(true);menu_open=false;}
                else if(menu_item<4)menu_edit(menu_item==2 ? EDIT_MEMORY : EDIT_RECALL);
                else if(menu_item==4) {menu_page=MENU_SCAN;menu_item=0;}
                else (void)feature_zone_next();
            } else if(menu_page==MENU_SCAN) {
                if(menu_item==0) {menu_open=false;if(channel_scan.running) {feature_stop_scan(true);feature_pause();reason="listening";}else (void)feature_scan_start();}
                else if(menu_item==1)feature_scan_next();
                else reason="edit_list_in_cps";
            } else if(menu_page==MENU_DISPLAY) {
                if(menu_item<2)menu_edit(menu_item==0 ? EDIT_SCREEN : EDIT_LIGHT);
                else {radio_lights.locked=true;menu_open=false;reason="keypad_locked";}
            } else if(menu_page==MENU_FM) {
                if(menu_item==0) {channel_record[12]^=32u;pref_state="pending";}
                else if(menu_item==1)menu_edit(EDIT_SQL);
                else if(menu_item==3 || menu_item==5)menu_edit(menu_item==3 ? EDIT_TXTONE : EDIT_RXTONE);
                else {unsigned offset=menu_item==2 ? 26u : 28u;unsigned type=(feature_u16(channel_record+offset)>>14)+1u;
                    type%=4u;feature_put16(channel_record+offset,type ? (type<<14)|(type==1u ? 1000u : 19u) : 0u);pref_state="pending";}
            } else if(menu_item<2) {
#if DM32_LAB_DIAGNOSTICS
                if(menu_item==1) {rx_pass=rx_frame_test();rx_checked=true;}
#endif
                menu_open=false;rx_lab=true;diag_from_menu=true;
            }
#if DM32_LAB_DIAGNOSTICS
            else {
                menu_open=false;diag_from_menu=false;
                if(normal_mode) {normal_mode=false;mon_enabled=false;session_enabled=armed=false;radio_inhibit(&control,true);radio_receive_state(&control,false,false,false,false);reason="bench";}
                else (void)normal_resume();
            }
#endif
        }
        screen("MENU");return;
    }
    if(!editing && action==ACT_NAV_RIGHT) {rx_lab=true;diag_from_menu=false;screen("INFO");return;}
    if(!editing && action==ACT_AB) {(void)feature_select_vfo(true);screen("HOME");return;}
    if(!editing && (action==ACT_NAV_UP || action==ACT_NAV_DOWN)) {
        if(feature_memory())(void)feature_recall(action==ACT_NAV_UP ? 1 : -1);
        else {uint32_t step=12500u,hz=action==ACT_NAV_UP ? frequency+step : frequency>=step ? frequency-step : 0;
            if(radio_configure(&control,hz,channel_in_band(hz,false))) {reason="frequency_saved";pref_state="pending";}}
        screen("HOME");return;
    }
    if(!editing && action==ACT_NAV_LEFT) {
        (void)feature_toggle_mode();
        screen("HOME");return;
    }
    if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9) {
        if(!editing) {armed=false;field=feature_memory() ? EDIT_RECALL : EDIT_RX;editing=true;edit_from_menu=false;digit_count=0;}
        if(digit_count<field_digits())frequency_digits[digit_count++]=(char)('0'+action-ACT_DIGIT_0);
        reason=field==EDIT_RECALL ? "enter_channel" : "enter_frequency";
    } else if(action==ACT_CONTEXT && editing && field==EDIT_BCAST) {
        if(digit_count && digit_count<field_digits() && !memchr(frequency_digits,'.',digit_count))
            frequency_digits[digit_count++]='.';
        reason="enter_frequency";
    } else if(action==ACT_CONTEXT && !editing) {
        armed=false;field=feature_memory() ? EDIT_RECALL : EDIT_RX;editing=true;edit_from_menu=false;digit_count=0;
        reason=field==EDIT_RECALL ? "enter_channel" : "enter_frequency";
    } else if(editing && field==EDIT_NAC && (action==ACT_NAV_UP || action==ACT_NAV_DOWN)) {
        if(!digit_count)frequency_digits[digit_count++]='0';
        char c=frequency_digits[digit_count-1];unsigned value=c<='9' ? c-'0' : c-'A'+10;
        value=(value+(action==ACT_NAV_UP ? 1 : 15))%16;
        frequency_digits[digit_count-1]="0123456789ABCDEF"[value];
    } else if(action==ACT_QUICK && editing) {
        if(digit_count)--digit_count;
        if(field==EDIT_BCAST)reason="enter_frequency";
    } else if(action==ACT_SELECT) {
        if(editing) {
            uint32_t value=0;
            for(unsigned i=0;field!=EDIT_BCAST && i<digit_count;++i) {
                unsigned digit=frequency_digits[i]<='9' ? frequency_digits[i]-'0' : frequency_digits[i]-'A'+10;
                value=value*(field==EDIT_NAC ? 16u : 10u)+digit;
            }
            bool valid=digit_count!=0;
            if(field<=EDIT_TX) {
                value*=100u;
                valid=digit_count==7 && channel_in_band(value,field==EDIT_TX || !control.split);
                if(field==EDIT_RX)valid=radio_configure(&control,value,valid);
                else if(valid) {control.tx_frequency=value;control.split=true;}
            } else if(field==EDIT_NAC) {valid=valid && value<=0xfff;if(valid)control.nac=value;}
            else if(field==EDIT_TG) {valid=valid && value && value<=(feature_dmr() ? 0xffffffu : 0xffffu);
                if(valid) {if(feature_dmr())valid=radio_channel_set_destination(channel_record,value);else {control.talkgroup=value;feature_temporary_tg=false;}}}
            else if(field==EDIT_DMR_CC)valid=valid && radio_channel_set_color_code(channel_record,value);
            else if(field==EDIT_MIC) {valid=valid && value<=42;if(valid)mic_gain_db=value;}
            else if(field==EDIT_TOT)valid=valid && value>=RADIO_TOT_MIN_SECONDS && radio_functions_set_tot_seconds(global_record,value);
            else if(field==EDIT_BCAST) {
                uint32_t khz;valid=radio_broadcast_input_khz(frequency_digits,digit_count,&khz)
                    && radio_functions_set_broadcast_khz(global_record,khz);
            }
            else if(field==EDIT_ID) {valid=valid && value && value<=0xffffff;if(valid)control.source_id=value;}
            else if(field==EDIT_MEMORY)valid=valid && feature_save_memory(value);
            else if(field==EDIT_RECALL) {
                reason="channel_empty";valid=valid && value>=1 && value<=P25_CS_CHANNELS;
                if(valid)valid=feature_select_channel(value);
            } else if(field==EDIT_SCREEN || field==EDIT_LIGHT) {
                valid=valid && value<=600;
                if(valid) {if(field==EDIT_SCREEN)radio_lights.screen_seconds=(uint16_t)value;else radio_lights.keypad_seconds=(uint16_t)value;}
            } else if(field==EDIT_SQL) {valid=valid && value<=9;if(valid)channel_record[30]=(uint8_t)value;}
            else {
                unsigned offset=field==EDIT_TXTONE ? 26u : 28u,type=feature_u16(channel_record+offset)>>14;
                if(!value)feature_put16(channel_record+offset,0);
                else if(type>=2) {
                    unsigned code=0;for(unsigned i=0;i<digit_count;++i) {unsigned digit=(unsigned)(frequency_digits[i]-'0');if(digit>7)valid=false;code=(code<<3)|digit;}
                    valid=valid && code && code<=511;if(valid)feature_put16(channel_record+offset,(type<<14)|code);
                } else {valid=valid && value>=600 && value<=2600;if(valid)feature_put16(channel_record+offset,(1u<<14)|value);}
            }
            if(!valid) {if(field!=EDIT_RECALL)reason="invalid_frequency";}
            else {
                editing=false;digit_count=0;reason=field==EDIT_MEMORY ? "memory_saved" : "frequency_saved";pref_state="pending";
                menu_open=edit_from_menu;edit_from_menu=false;
                if(normal_mode) {mon_enabled=channel_in_band(frequency,false);mon_reason=mon_enabled ? "ready" : "no_channel";}
            }
        } else {menu_open=true;menu_page=MENU_ROOT;menu_item=0;}
    } else return;
    screen("HOME");
}
// Encoder drivers may return accumulated detents. Channel selection resolves
// the final populated slot once, rather than flashing intermediate selections.
static void local_encoder(int steps) {
    if(!steps || cps_link || cps_active || call_active || prepared)return;
    if(broadcast_show || editing || rx_lab || rx_job) {
        local_action(steps>0 ? ACT_NAV_UP : ACT_NAV_DOWN,false);return;
    }
    if(menu_open) {
        unsigned count=menu_count(),delta=(steps>0 ? (unsigned)steps : 0u-(unsigned)steps)%count;
        menu_item=(menu_item+(steps>0 ? count-delta : delta))%count;
        screen("MENU");return;
    }
    if(channel_scan.running) {feature_stop_scan(true);feature_pause();}
    if(feature_memory())(void)feature_recall(steps);
    else {
        feature_stop_scan(true);feature_pause();
        int64_t hz=(int64_t)frequency+(int64_t)steps*12500;
        if(hz>=0 && hz<=UINT32_MAX && radio_configure(&control,(uint32_t)hz,channel_in_band((uint32_t)hz,false))) {
            reason="frequency_saved";pref_state="pending";
        } else reason="invalid_frequency";
    }
    screen("HOME");
}
static void keypad_poll(uint32_t keys) {
    uint32_t now=hrc_micros();
    if(keys!=key_candidate) { key_candidate=keys; key_changed_at=now; return; }
    if(now-key_changed_at<25000u || keys==key_stable) return;
    uint32_t pressed=keys&~key_stable; key_stable=keys;
    // BACK requests a controlled call end even with PTT held.
    for(unsigned i=0;i<board.keymap_len;++i) {
        const keymap_entry_t *k=&board.keymap[i];
        if(k->short_action==ACT_BACK && (pressed&(1u<<k->bit))) {
            local_action(ACT_BACK,(keys&ptt_mask)!=0); return;
        }
    }
    uint32_t other=keys&~ptt_mask;
    if(!other || (other&(other-1u))) return; // reject chords
    for(unsigned i=0;i<board.keymap_len;++i) {
        const keymap_entry_t *k=&board.keymap[i];
        if(pressed&(1u<<k->bit)) local_action(k->short_action,(keys&ptt_mask)!=0);
    }
}
static bool begin_capture(void) {
    if(mon_running)mon_stop("transmit");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    if(rx_job || call_active || prepared || editing || menu_open || rx_lab || control.state==RADIO_FAULT) return false;
    bool permitted=(normal_mode && !tx_fixed && !owner_tx_inhibit) || session_enabled
        || (armed && (int32_t)(hrc_micros()-arm_until)<0);
    armed=false;
    if(!permitted || control.inhibit || !control.tx_enabled || !dev || !hooks || !board.audio || !bf_cal_valid() || !channel_in_band(control.tx_frequency,true) || !channel_in_band(frequency,false)
       || board.power->battery_mv()<board.battery_critical_mv) return false;
    if(!p25_channel_build(&call_frames,control.nac,control.talkgroup,control.source_id)) return false;
    board.radio->audio(false); board.radio->set_mode(RADIO_MODE_DMR);
    // DMR board TX prepares calibrated settings, but RF switch and PA wait for
    // our IRQ handlers. Normal DMR entry/exit are interposed above.
    saved_rf_mode=hrc7000_rd(dev,C7_RF_MODE); prepared=true;
    tx_dac.before_tx=tx_dac.prepared=tx_dac.after_stop=tx_dac.pre_rf=tx_dac.pa=tx_dac.end=tx_dac.seen=0;
    if(!board.radio->rx(control.tx_frequency,RADIO_BW_12K5,NULL)) return false;
    tx_dac.before_tx=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_BEFORE_TX;
    if(!feature_tx_settings_valid() || !board.radio->tx(control.tx_frequency,RADIO_BW_12K5,(uint8_t)feature_tx_power(),NULL)) return false;
    tx_dac.prepared=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PREPARED;
    saved_rf_mode=hrc7000_rd(dev,C7_RF_MODE);
    uint32_t lock=hrc_irq_save(); hardware_stop();
    tx_dac.after_stop=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_AFTER_STOP;
    wr(C7_LAYER2_SLOTON,0); wr(C7_FM_PTT,0);
    wr(C7_WORK_MODE,C7_WORK_MODE_FM); wr(C7_WORK_MODE,0x02);
    hrc7000_audio_bits(dev,0,C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY|C7_AUDIO_PCM_SPK|C7_AUDIO_PCM_MIC);
    wr(C7_AUDIO_BUFFER_CLR,3);
    hrc_pin_write(PIN_MIC_PATH,false);
    hrc_irq_restore(lock);
    p25_live_tx_init(&live); memcpy(live.hdu,call_frames.hdu,99); memcpy(live.tdu,call_frames.tdu,18); memset(&pcmq,0,sizeof pcmq); memset(payload,0,sizeof payload);
    if(!p25_live_tx_set_startup_extra(&live,tx_startup_extra))return false;
    unsigned seconds=feature_tx_tot();call_capture_frames=seconds*50u;call_tot_expired=false;
    call_soft_limit_us=(seconds+3u)*1000000u;
    if(!p25_live_tx_set_rf_limit(&live,(seconds+5u)*1000000u))return false;
    encoded=target=max_encode=max_pack=driver_loss=rf_audio=0; payload_hash=2166136261u;
    if(!tx_fixed && !imbe_bench_init())return false;
    hrc_audio_pcm_reset_stats();
    capture_started=last_pcm=hrc_micros(); reason="running"; call_active=true; pcmq.accepting=!tx_fixed;
    if(tx_fixed) {
        target=tx_pairs*18u;payload_hash=0;
        pcm_mode=hrc7000_rd(dev,C7_WORK_MODE);pcm_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
        return true; // No microphone or codec work for the pre-encoded fixture.
    }
    hrc7000_set_mic_gain(dev,(uint8_t)mic_gain_db);
    audio_on=board.audio->start(capture,NULL);
    pcm_mode=hrc7000_rd(dev,C7_WORK_MODE); pcm_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
    if(!audio_on) { fail("audio_start"); return false; }
    return true;
}
static void start_rf(void) {
    uint32_t lock=hrc_irq_save();
    if(!call_active || !p25_live_tx_start(&live,hrc_micros())) { hrc_irq_restore(lock); return; }
    tx_write_half=tx_writer==TX_WRITER_ALT1 ? 1u : 0u;
    // hardware_stop powers the native PA-drive DAC down after board TX setup.
    // Restore only its power, while RF/PA and DAC_DATA_B are still off; the
    // existing calibrated board hook supplies the selected level's PA drive.
    if(tx_dac_restore)hrc_dac_b_power(true);
    tx_dac.pre_rf=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PRE_RF;
    for(unsigned i=0;i<72;++i) dev->buf[i]=0x77;
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);
    wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    wr(C7_SYS_INTERP_MASK,PHY_READY);
    hardware_running=true; pa_started=false; control.state=RADIO_TX_VOICE;
    rf_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
    hrc_irq_enable(IRQ_MODEM_SYS,true);
    hrc_irq_enable(IRQ_MODEM_TS_TX,true); hrc_irq_enable(IRQ_MODEM_TS_RX,true);
    hrc_irq_enable(IRQ_MODEM_RF_TX,true); hrc_irq_enable(IRQ_MODEM_RF_RX,true);
    (void)hard_guard_arm(live.rf_limit_us/1000000u);
    wr(C7_LAYER2_CONTROL,0x82);
    hrc_irq_restore(lock);
}
static void poll_call(bool down) {
    if(!call_active) return;
    uint32_t now=hrc_micros(), blocks=0, under=0;
    if(!tx_fixed)hrc_audio_pcm_stats(&blocks,&driver_loss,&under);
    (void)blocks; (void)under;
    if(driver_loss || pcmq.overflow) { fail(driver_loss ? "pcm_driver_loss" : "pcm_overflow"); return; }
    if(now-capture_started>call_soft_limit_us) { fail("call_timeout"); return; }
    if(pcmq.accepting && now-last_pcm>=200000u) { fail("pcm_stalled"); return; }
    if((!down || control.cancel) && !hardware_running) { stop_call("released_before_rf",false); return; }
    if(tx_fixed) {
        uint32_t lock=hrc_irq_save();
        if(!down || control.cancel) {
            // Preserve already-published audio, rounding up only to a complete
            // alternating pair. Release never publishes a fresh full fixture.
            target=((live.published+1u)/2u)*18u;
            control.state=RADIO_TX_DRAIN;
        }
        if(encoded<target && live.count<LIVE_BANKS) {
            const uint8_t *ldu=((encoded/9u)&1u) ? call_frames.ldu2 : call_frames.ldu1;
            if(!p25_live_tx_push(&live,ldu)) {hrc_irq_restore(lock);fail("ldu_publish");return;}
            encoded+=9u;
        }
        if(encoded==target && !live.finished && !p25_live_tx_finish(&live)) {
            hrc_irq_restore(lock);fail("ldu_publish");return;
        }
        hrc_irq_restore(lock);
    } else {
    uint32_t lock=hrc_irq_save();
    if(!down || control.cancel) pcmq.accepting=false;
    bool finished=!pcmq.accepting;
    if(finished && !target) target=((pcmq.captured+17u)/18u)*18u;
    if(target && encoded==target && !live.finished) (void)p25_live_tx_finish(&live);
    int16_t pcm[160]; bool have=mic_queue_pop(&pcmq,pcm);
    hrc_irq_restore(lock);
    if(finished) { control.state=RADIO_TX_DRAIN; audio_stop(); }
    if(!have && target && encoded<target) { memset(pcm,0,sizeof pcm); have=true; }
    if(have) {
        uint32_t start=hrc_micros(); imbe_bench_encode_pcm(pcm,payload[encoded%9u]);
        if(!imbe_bench_ready()) {fail("codec_owner");return;}
        uint32_t elapsed=hrc_micros()-start; if(elapsed>max_encode) max_encode=elapsed;
        for(unsigned i=0;i<11;++i) payload_hash=(payload_hash^payload[encoded%9u][i])*16777619u;
        ++encoded;
        if(encoded%9u==0) {
            uint8_t ldu[216]; start=hrc_micros();
            p25_live_ldu_template(ldu,(const uint8_t (*)[11])payload,((encoded/9u)&1u)==0 ? call_frames.ldu2 : call_frames.ldu1);
            elapsed=hrc_micros()-start; if(elapsed>max_pack) max_pack=elapsed;
            lock=hrc_irq_save();
            bool ok=call_active && p25_live_tx_push(&live,ldu);
            if(ok && target && encoded==target) ok=p25_live_tx_finish(&live);
            hrc_irq_restore(lock);
            if(!ok) { fail("ldu_publish"); return; }
        }
    }
    }
    // PTT may have been released while the encoder ran. Do not initiate RF then.
    down=(board.input->scan()&ptt_mask)!=0;
    if(!hardware_running && down && !control.cancel && live.count>=2) start_rf();
    uint32_t lock=hrc_irq_save();
    p25_test_tx_poll_limit(&live.timing,hrc_micros(),true,live.rf_limit_us); // normal release drains through TDU
    if(hardware_running && !p25_test_tx_active(&live.timing)) {
        reason=live.timing.state==P25_TX_DONE ? (call_tot_expired ? "time_limit" : "complete") : "rf_timing";
        if(call_tot_expired) {ptt_release_required=true;ptt_release_seen=false;}
        if(live.timing.state!=P25_TX_DONE) session_enabled=false;
        hardware_stop(); call_active=false; pcmq.accepting=false;
    }
    hrc_irq_restore(lock);
}
static void rx_end(const char *why) {
    uint32_t lock=hrc_irq_save();
#if DM32_LAB_DIAGNOSTICS
    rxcap.accepting=false;
#endif
    rx_sampling=false;rx_job=false;rx_reason=why;
    hardware_stop();hrc_irq_restore(lock);
    board.radio->set_mode(RADIO_MODE_FM);board.radio->audio(false);board_rf_safe();
}
static void rx_poll(bool down) {
#if DM32_LAB_DIAGNOSTICS
    if(!rx_job)return;
    if(down) {rx_end("ptt_cancelled");screen("INFO");return;}
    uint32_t now=hrc_micros();
    if(!rx_sampling && (int32_t)(now-rx_due)>=0) {
        rxcap_reset(&rxcap);rx_started=now;rx_reason="recording";
        rx_signal_count=0;rx_signal_max_us=0;rx_signal_due=now;
        rx_reg_work=hrc7000_rd(dev,C7_WORK_MODE);rx_reg_rf=hrc7000_rd(dev,C7_RF_MODE);
        rx_reg_bw=hrc7000_rd(dev,C7_FM_BANDWIDTH);rx_reg_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
        rx_reg_phase=hrc7000_rd(dev,0x128u); // PHASE_OUT: AF input min/max, read-only
        rx_pin_source=hrc_pin_read(PIN_SPK_SOURCE);rx_pin_mic=hrc_pin_read(PIN_MIC_PATH);
        screen("INFO");
        rx_started=now=hrc_micros();rx_signal_due=now;
        uint32_t lock=hrc_irq_save();
        wr(C7_SYS_INTERP_CLEAR,0xffffffffu);rx_sampling=true;
        wr(C7_SYS_INTERP_MASK,1u<<14);hrc_irq_enable(IRQ_MODEM_SYS,true);
        hrc_irq_restore(lock);
    }
    // RF chip bus accesses are task-only. Never put them in the 32-ms ISR.
    if(rx_sampling && rxcap.accepting && board.radio->status && rx_signal_count<60
       && (int32_t)(now-rx_signal_due)>=0) {
        radio_status_t st={0};uint32_t begin=hrc_micros();board.radio->status(&st);
        uint32_t elapsed=hrc_micros()-begin;
        if(elapsed>rx_signal_max_us)rx_signal_max_us=elapsed;
        rx_signals[rx_signal_count++]=(rx_signal){begin-rx_started,st.rssi_dbm,st.noise};
        rx_signal_due=hrc_micros()+100000u;
    }
    if(rx_sampling && (!rxcap.accepting || now-rx_started>RXCAP_TIMEOUT_US)) {
        rx_end(rxcap.count==RXCAP_BLOCKS ? "complete" : "capture_timeout");
        screen("INFO");status();
    }
#else
    (void)down;
#endif
}
// Advance at most 31 times per call, rather than divide on every timer wakeup.
#if DM32_LAB_DIAGNOSTICS
static mon_perf_bin *mon_perf_at(uint32_t now) {
    uint32_t age=now-mon_first_push;
    while(mon_perf_index<31 && age>=(mon_perf_index+1u)*1000000u)++mon_perf_index;
    return &mon_perf[mon_perf_index];
}
#endif
// Dedicated speaker PCM path: fixed 80-sample halves, no codec or board work
// in the consumed-buffer ISR. Byte stores match the stock playback routine.
static void mon_pcm_disable(void) {
    hrc_irq_enable(IRQ_PCM_RD,false);
    if(dev) {
        hrc7000_audio_bits(dev,0,C7_AUDIO_PCM_SPK);
        wr(C7_INTERP_CLEAR,C7_INT_PCM_RD);
    }
    mon_pcm_pending=false;
}
static void mon_pcm_load(const int16_t *samples) {
    volatile uint8_t *window=P25_SPEAKER_PCM_WINDOW;
    for(unsigned i=0;i<80;++i) {
        uint16_t s=(uint16_t)samples[i];
        window[2*i]=(uint8_t)s;window[2*i+1]=(uint8_t)(s>>8);
    }
    hrc_barrier();
    mon_pcm_commit_samples(&monitor,80);
    mon_pcm_submitted+=80;mon_pcm_pending=true;
}
static void mon_pcm_irq(void) {
    wr(C7_INTERP_CLEAR,C7_INT_PCM_RD);
    if(!mon_pcm_backend || !mon_running || mon_failed || !mon_routed || !mon_pcm_pending) {
        mon_pcm_disable();return;
    }
    uint32_t now=hrc_micros(),gap=now-mon_pcm_last;
    if(gap>mon_pcm_gap)mon_pcm_gap=gap;
    mon_pcm_last=now;++mon_pcm_irqs;mon_pcm_consumed+=80;
    mon_pcm_pending=false;
    const int16_t *chunk=mon_pcm_peek(&monitor);
    if(chunk)mon_pcm_load(chunk);
    else mon_pcm_disable(); // Do not replay stale RAM on starvation or end.
}
static void mon_pcm_service(void) {
    if(!mon_running || mon_failed) {mon_pcm_disable();return;}
    if(mon_pcm_pending) {
        // A missing peripheral event must not replay the same half forever.
        if(hrc_micros()-mon_pcm_last>30000u) {mon_pcm_disable();mon_failed=true;}
        return;
    }
    const int16_t *chunk=mon_pcm_peek(&monitor);
    if(!chunk) {
        if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
        return;
    }
    mon_pcm_load(chunk); // Prime RAM before starting the hardware consumer.
    if(!mon_routed) {board.audio->speaker_pcm(true);mon_routed=true;}
    // Board hook supplies source selection and amp ownership but enables ring.
    // Replace that source; never leave both PCM and prompt playback enabled.
    hrc7000_audio_bits(dev,0,C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY);
    wr(C7_INTERP_CLEAR,C7_INT_PCM_RD);
    mon_pcm_last=hrc_micros();
    hrc_irq_enable(IRQ_PCM_RD,true);
    hrc7000_audio_bits(dev,C7_AUDIO_PCM_SPK,0);
}
// Higher-priority speaker service does no codec work and never starts the mic.
static void mon_speaker_step(void) {
    uint32_t lock=hrc_irq_save();
    if(mon_pcm_backend) {mon_pcm_service();hrc_irq_restore(lock);return;}
#if DM32_LAB_DIAGNOSTICS
    uint32_t now=hrc_micros(),step_started=now;
    bool measure_step=mon_running;
    if(mon_routed && mon_spk_last_us) {
        uint32_t gap=now-mon_spk_last_us;if(gap>mon_spk_gap_us)mon_spk_gap_us=gap;
    }
    mon_perf_bin *perf=mon_pushes ? mon_perf_at(now) : NULL;
    if(perf && mon_routed && mon_spk_last_us) {
        uint32_t gap=now-mon_spk_last_us;if(gap>perf->max_service)perf->max_service=gap;
        if(!(hrc7000_rd(dev,C7_AUDIO_CONTROL)&C7_AUDIO_RING_PLAY))++perf->route_missing;
    }
    mon_spk_last_us=mon_routed ? now : 0;
    if(mon_running && !mon_failed) {
        const int16_t *chunk=mon_pcm_peek(&monitor);
        if(chunk) {
            mon_empty_since=0;
            if(!mon_routed) {board.audio->speaker_pcm(true);mon_routed=true;}
            // Bound the work per tick even when a mock/empty FIFO accepts forever.
            for(unsigned n=0;n<mon_fifo_limit && chunk && mon_running && !mon_failed;++n) {
                if(!hrc7000_prompt_push(dev,chunk)) {++mon_full;if(perf)++perf->full;break;}
                uint32_t pushed=hrc_micros();
                if(mon_pushes) {
                    uint32_t gap=pushed-mon_last_push;
                    if(gap>mon_push_gap) {mon_push_gap=gap;mon_worst_at=pushed-mon_first_push;mon_worst_queue=mon_count(monitor.pcm_head,monitor.pcm_tail,MON_PCM_FRAMES);}
                    perf=mon_perf_at(pushed);
                    if(gap>perf->max_gap)perf->max_gap=gap;
                } else {mon_first_push=pushed;perf=&mon_perf[0];}
                ++perf->pushes;
                mon_last_push=pushed;++mon_pushes;
                mon_pcm_commit(&monitor);
                // A chunk and its queue commit stay atomic, but let recorder/timer
                // IRQs run between chunks. Recheck fault state before another write.
                hrc_irq_restore(lock);lock=hrc_irq_save();
                chunk=mon_pcm_peek(&monitor);
            }
        } else if(mon_routed) {
            if(perf)++perf->empty;
            if(!mon_empty_since)mon_empty_since=hrc_micros();
            if(hrc_micros()-mon_empty_since>=40000u) {board.audio->speaker_pcm(false);mon_routed=false;}
        }
    } else if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
    uint32_t cost=hrc_micros()-step_started;
    if(measure_step) {
        if(cost>mon_step_max_us)mon_step_max_us=cost;
        mon_step_total_us+=cost;++mon_step_calls;
    }
#endif
    hrc_irq_restore(lock);
}
// Timer only wakes the higher-priority task: no codec, FIFO, board or UART work in ISR.
static void mon_speaker_tick(void) {
    hrc_timer_ack(SPEAKER_TIMER);
    if(mon_running && !mon_failed && mon_timer_us && mon_task_handle) {
        ++mon_timer_ticks;
        BaseType_t woken=pdFALSE;
        vTaskNotifyGiveFromISR(mon_task_handle,&woken);
        portYIELD_FROM_ISR(woken);
    }
}
static void mon_speaker_task(void *arg) {
    (void)arg;
    for(;;) {
        if(mon_timer_us) {
            // One-tick fallback prevents a lost/stopped timer from blocking cleanup.
            uint32_t pending=ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(1));
            if(mon_running && pending>mon_notify_max)mon_notify_max=pending;
            mon_speaker_step();
        } else {mon_speaker_step();vTaskDelay(pdMS_TO_TICKS(mon_service_ms));}
    }
}
static void mon_stop(const char *why) {
    if(!mon_running)return;
    uint32_t lock=hrc_irq_save();mon_running=false;ui_rssi_valid=false;ui_rssi_due=hrc_micros();mon_reason=why;mon_pcm_disable();
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,hrc_micros());
    mon_have_sync=false;board.power->led(LED_GREEN,false);
    if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
    hardware_stop();hrc_irq_restore(lock);
    board.radio->audio(false);board.radio->set_mode(RADIO_MODE_FM);board_rf_safe();
}
static void mon_discard_audio(void) {
    // A newly unknown/encrypted call must not leave old queued speech playing.
    // The peripheral can consume only its already submitted 10-ms half.
    uint32_t lock=hrc_irq_save();
    mon_pcm_disable();
    monitor.discarded_pcm+=mon_count(monitor.pcm_head,monitor.pcm_tail,MON_PCM_FRAMES);
    monitor.pcm_tail=monitor.pcm_head;monitor.pcm_pos=0;
    monitor.playing=false;monitor.ending=false;
    if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
    hrc_irq_restore(lock);
}
static void mon_reset_voice(void) {
    if(!imbe_bench_init())mon_failed=true;
    p25_voice_policy_init(&monitor.quality);
    memset(monitor.last_good_pcm,0,sizeof monitor.last_good_pcm);
    mon_tone_phase=0;mon_voice_us=0;monitor.last_voice_us=0;
}
static void mon_receive(const p25_rx *frame,void *context) {
    (void)context;++monitor.units;
    if(!rx_promiscuous && frame->nac!=control.nac) {++monitor.rejected;return;}
    monitor.nid_recovered+=frame->nid_corrected!=0;
    p25_call_metadata metadata;
    bool valid=p25_call_decode(frame->frame,frame->duid,&metadata);
    bool completed_tail=monitor.ending && !monitor.call.active;
    p25_receive_event event=p25_receive_update(&monitor.call,frame->nac,frame->duid,
                                              &metadata,valid,hrc_micros());
    // A terminator has no talkgroup and clears call identity in the policy.
    // It must drain an already-qualified tail, never flush it as an unknown TG.
    bool terminator=frame->duid==3 || frame->duid==15;
    bool group_allowed=terminator || !rx_tg_filter || (monitor.call.group_valid && feature_scan_group_allows(monitor.call.group));
    if(!terminator && group_allowed && monitor.call.group_valid && monitor.call.state==P25_RX_CLEAR)
        feature_scan_match_group(monitor.call.group);
    if(!group_allowed) {event.voice=false;++monitor.rejected;}
    // Preserve a completed, validated tail when the following clear HDU arrives
    // before the speaker catches up. New codec/identity still reset; encrypted,
    // unknown and unsupported boundaries must never preserve authorization.
    bool keep_tail=group_allowed && completed_tail && event.new_call && frame->duid==0 && valid
        && metadata.classification==P25_CALL_CLEAR && metadata.ess_valid && metadata.mfid_valid && !metadata.mfid;
    if((event.discard && !keep_tail) || !group_allowed)mon_discard_audio();
    if(event.reset)mon_reset_voice();
#if DM32_LAB_DIAGNOSTICS
    if(event.new_call)pcm_trace_init(&monitor.trace,frame->duid==0);
#endif
    if(frame->duid==3 || frame->duid==15) {
        ++mon_tdu;
        if(event.end) {
            mon_have_sync=false;mon_voice_us=0;
            p25_voice_policy_init(&monitor.quality);
            memset(monitor.last_good_pcm,0,sizeof monitor.last_good_pcm);
            uint32_t lock=hrc_irq_save();monitor.ending=true;hrc_irq_restore(lock);
        }
        return;
    }
    mon_sync_us=hrc_micros();mon_have_sync=true;
    if(!valid)++monitor.metadata_bad;
    if(frame->duid==0)++mon_hdu;
    if(frame->duid!=5 && frame->duid!=10)return;
    if(frame->duid==5)++mon_ldu1;else ++mon_ldu2;
    if(!event.voice) {
        if(monitor.call.state==P25_RX_ENCRYPTED)++monitor.encrypted_units;
        else if(monitor.call.state==P25_RX_UNSUPPORTED)++monitor.unsupported_units;
        else ++monitor.unqualified_units;
        return;
    }
    for(unsigned i=0;i<9 && !mon_failed;++i) {
        uint8_t bits[11];int16_t pcm[160];p25_voice_quality quality;
        if(!p25_rx_voice_quality(frame->frame,i,bits,&quality)) {mon_failed=true;break;}
        bool had_good=monitor.quality.have_good;
        p25_voice_action action=p25_voice_policy_frame(&monitor.quality,bits,quality.e0,quality.et);
        if(action==P25_VOICE_ACCEPT) {
            imbe_bench_decode_pcm(bits,pcm);memcpy(monitor.last_good_pcm,pcm,sizeof pcm);
            if(!imbe_bench_ready()) {mon_failed=true;break;}
        } else if(action==P25_VOICE_REPEAT) {
            memcpy(pcm,monitor.last_good_pcm,sizeof pcm);++monitor.repeated;
        } else {
            memset(pcm,0,sizeof pcm);memset(monitor.last_good_pcm,0,sizeof monitor.last_good_pcm);
            if(had_good && !imbe_bench_init()) {mon_failed=true;break;} // Once when concealment enters mute.
            ++monitor.muted;
        }
#if DM32_LAB_DIAGNOSTICS
        pcm_trace_record(&monitor.trace,bits,pcm);
        monitor.trace.tone_substituted=mon_output_tone;
        if(mon_output_tone)mon_local_frame(pcm); // Preserve actual decode evidence before substitution.
#endif
        uint32_t lock=hrc_irq_save();
        monitor.ending=false;
        if(mon_audio_enabled && !mon_pcm_push(&monitor,pcm))mon_failed=true;
        ++monitor.voices;monitor.corrected+=quality.et;monitor.last_voice_us=hrc_micros();
        if(action!=P25_VOICE_MUTE)mon_voice_us=monitor.last_voice_us;
        hrc_irq_restore(lock);
    }
}
static bool mon_start(void) {
    if(!board.audio || !board.audio->speaker_pcm || !dev || !hooks)return false;
    if(!mon_task_handle && xTaskCreate(mon_speaker_task,"p25spk",512,NULL,6,&mon_task_handle)!=pdPASS)return false;
    hardware_stop();board.radio->audio(false);board.radio->set_mode(RADIO_MODE_DMR);
    if(!board.radio->rx(frequency,RADIO_BW_12K5,NULL)) {
        board.radio->set_mode(RADIO_MODE_FM);board_rf_safe();return false;
    }
    hardware_stop();hrc7000_fm_rx(dev,false);hrc7000_audio_bits(dev,0,C7_AUDIO_FM_PLAY);
    wr(C7_FM_BANDWIDTH,hrc7000_rd(dev,C7_FM_BANDWIDTH)&~(1u<<6));
#if DM32_LAB_DIAGNOSTICS
    if(mon_replay)mon_init_replay(&monitor);else
#endif
    mon_init(&monitor);
    monitor.demod.hunt_clock_us=hrc_micros;
    if(!imbe_bench_init())return false;
    mon_tone_phase=0;mon_used=true;mon_failed=false;mon_empty_since=0;
    mon_fault_age=mon_fault_audio=mon_fault_mask=mon_fault_mode=0;
    mon_have_sync=mon_badge_sync=mon_have_nac=false;mon_badge_phase=0;mon_voice_us=0;mon_ui_max_us=mon_spk_last_us=mon_spk_gap_us=0;
    mon_pushes=mon_full=mon_first_push=mon_last_push=mon_push_gap=0;
#if DM32_LAB_DIAGNOSTICS
    memset(mon_perf,0,sizeof mon_perf);mon_perf_index=0;
#endif
    mon_worst_at=mon_worst_queue=0;
    mon_timer_ticks=mon_notify_max=0;mon_hdu=mon_ldu1=mon_ldu2=mon_tdu=0;
    mon_pcm_submitted=mon_pcm_consumed=mon_pcm_irqs=mon_pcm_last=mon_pcm_gap=0;
    mon_pcm_pending=false;
    mon_step_max_us=mon_step_total_us=mon_step_calls=0;
    mon_local_started=hrc_micros();mon_local_frames=0;
    monitor.last_raw_us=hrc_micros();mon_reason=mon_replay ? "replay_delay" : mon_local_tone ? "local_delay" : "receiving";
    radio_receive_state(&control,mon_enabled,true,false,false);screen("HOME");
    uint32_t lock=hrc_irq_save();
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);mon_running=true;ui_rssi_valid=false;ui_rssi_due=hrc_micros();
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,hrc_micros());
    if(mon_pcm_backend)hrc_irq_register(IRQ_PCM_RD,mon_pcm_irq);
    wr(C7_SYS_INTERP_MASK,1u<<14);hrc_irq_enable(IRQ_MODEM_SYS,true);
    if(mon_timer_us && !mon_pcm_backend) {
        hrc_irq_register(IRQ_TIMER4,mon_speaker_tick);
        hrc_timer_ack(SPEAKER_TIMER);hrc_irq_enable(IRQ_TIMER4,true);
        hrc_timer_periodic(SPEAKER_TIMER,mon_timer_us);
    }
    hrc_irq_restore(lock);return true;
}
static void mon_poll(bool down) {
    if(down || !mon_enabled || rx_job || call_active || prepared || editing || menu_open || rx_lab
       || cps_link || cps_active || (normal_mode && !feature_p25()) || control.state==RADIO_FAULT) {
        if(mon_local_tone || mon_replay)mon_enabled=false;
        if(mon_running)mon_stop(down ? "ptt" : "paused");
        return;
    }
    if(!channel_in_band(frequency,false))return;
    if(!mon_running) {
        if(!mon_start()) {
            mon_enabled=false;mon_reason="setup_failed";
            if(normal_mode) {reason="rx_setup_failed";radio_complete(&control,true);radio_inhibit(&control,true);}
            screen("HOME");
        }
        return;
    }
    // Snapshot time and the ISR-owned timestamp atomically. Otherwise an IRQ
    // between these reads can make last_raw_us newer than now and underflow.
    uint32_t lock=hrc_irq_save();
    uint32_t input_age=hrc_micros()-monitor.last_raw_us;
    bool input_failed=mon_failed;
    hrc_irq_restore(lock);
    if(input_failed || input_age>200000u) {
        mon_fault_age=input_age;mon_fault_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
        mon_fault_mask=hrc7000_rd(dev,C7_SYS_INTERP_MASK);mon_fault_mode=hrc7000_rd(dev,C7_WORK_MODE);
        mon_enabled=false;mon_stop(input_failed ? "queue_or_input_fault" : "input_timeout");
        if(normal_mode) {reason=mon_reason;session_enabled=false;radio_complete(&control,true);radio_inhibit(&control,true);}
        screen("HOME");return;
    }
    uint8_t block[512];lock=hrc_irq_save();
    bool have=mon_raw_pop(&monitor,block);hrc_irq_restore(lock);
#if DM32_LAB_DIAGNOSTICS
    if(mon_local_tone || mon_replay) {
        uint32_t age=hrc_micros()-mon_local_started;
        if(age>=20000000u) {
            unsigned goal=mon_replay ? pcm_trace_kept(&monitor.trace) : 300u;
            while(mon_local_frames<goal) {
                lock=hrc_irq_save();
                bool room=mon_count(monitor.pcm_head,monitor.pcm_tail,MON_PCM_FRAMES)<MON_PREFILL;
                hrc_irq_restore(lock);if(!room)break;
                int16_t pcm[160];
                if(mon_replay) {
                    uint32_t seq=monitor.trace.frames-goal+mon_local_frames;
                    memcpy(pcm,monitor.trace.pcm[seq%PCM_TRACE_FRAMES],sizeof pcm);
                } else mon_local_frame(pcm);
                lock=hrc_irq_save();mon_pcm_push(&monitor,pcm);++mon_local_frames;hrc_irq_restore(lock);
            }
            lock=hrc_irq_save();
            if(mon_local_frames==goal)monitor.ending=true;
            bool done=monitor.played==goal && !mon_routed;
            hrc_irq_restore(lock);
            mon_reason=mon_replay ? "replay_pcm" : "local_tone";
            if(done || age>=30000000u) {
                mon_enabled=false;mon_stop(done ? (mon_replay ? "replay_complete" : "local_complete") : "local_timeout");screen("HOME");
            }
        }
        return; // Discard RF samples: playback does not demodulate or decode.
    }
#endif
    if(have) {
        uint32_t start=hrc_micros();
        for(unsigned i=0;i<256 && !mon_failed;++i)
            p25_demod_push(&monitor.demod,(int16_t)((unsigned)block[2*i]*256+block[2*i+1]),mon_receive,NULL);
        uint32_t elapsed=hrc_micros()-start;if(elapsed>monitor.max_block_us)monitor.max_block_us=elapsed;
    }
    if(monitor.call.active && hrc_micros()-monitor.call.last_unit_us>600000u) {
        p25_receive_reset(&monitor.call);mon_reset_voice();mon_have_sync=false;
        lock=hrc_irq_save();monitor.ending=true;hrc_irq_restore(lock);
    }
    mon_indicator();
}
static void mon_status(void) {
    char line[448];
    snprintf(line,sizeof line,"RXBACKEND mode=%s submitted_samples=%lu consumed_samples=%lu irqs=%lu pending=%u max_irq_gap_us=%lu\r\n",
        mon_pcm_backend ? "PCM" : "FIFO",(unsigned long)mon_pcm_submitted,(unsigned long)mon_pcm_consumed,
        (unsigned long)mon_pcm_irqs,(unsigned)mon_pcm_pending,(unsigned long)mon_pcm_gap);send(line);
    snprintf(line,sizeof line,"RXMON enabled=%u running=%u reason=%s raw=%lu raw_high=%lu pcm_high=%lu raw_overflow=%lu pcm_overflow=%lu gaps=%lu units=%lu voices=%lu played=%lu starved=%lu corrected=%lu rejected=%lu max_block_us=%lu spk_stack_free=%lu\r\n",
        (unsigned)mon_enabled,(unsigned)mon_running,mon_reason,(unsigned long)monitor.raw_blocks,
        (unsigned long)monitor.raw_high,(unsigned long)monitor.pcm_high,(unsigned long)monitor.raw_overflow,
        (unsigned long)monitor.pcm_overflow,(unsigned long)monitor.gaps,(unsigned long)monitor.units,
        (unsigned long)monitor.voices,(unsigned long)monitor.played,(unsigned long)monitor.starved,
        (unsigned long)monitor.corrected,(unsigned long)monitor.rejected,(unsigned long)monitor.max_block_us,
        mon_task_handle ? (unsigned long)(uxTaskGetStackHighWaterMark(mon_task_handle)*sizeof(StackType_t)) : 0ul);
    send(line);
    snprintf(line,sizeof line,"RXCALL active=%u state=%u nac=%03x group_valid=%u group=%u source_valid=%u source=%lu ess_valid=%u algid=%02x keyid=%u status=%s\r\n",
        (unsigned)monitor.call.active,(unsigned)monitor.call.state,monitor.call.nac,
        (unsigned)monitor.call.group_valid,monitor.call.group,(unsigned)monitor.call.source_valid,
        (unsigned long)monitor.call.source,(unsigned)monitor.call.ess_valid,monitor.call.algid,
        monitor.call.keyid,p25_receive_label(&monitor.call));send(line);
    snprintf(line,sizeof line,"RXQUALITY nid_recovered_units=%lu metadata_bad=%lu encrypted_units=%lu unsupported_units=%lu unqualified_units=%lu repeated=%lu muted=%lu discarded_pcm=%lu\r\n",
        (unsigned long)monitor.nid_recovered,(unsigned long)monitor.metadata_bad,
        (unsigned long)monitor.encrypted_units,(unsigned long)monitor.unsupported_units,
        (unsigned long)monitor.unqualified_units,(unsigned long)monitor.repeated,
        (unsigned long)monitor.muted,(unsigned long)monitor.discarded_pcm);send(line);
    uint32_t bad_nid=0,syncs=0;
    for(unsigned lane=0;lane<10;++lane) {bad_nid+=monitor.demod.lane[lane].rx.bad_nid;syncs+=monitor.demod.lane[lane].rx.syncs;}
    snprintf(line,sizeof line,"RXFRAME hdu=%lu ldu1=%lu ldu2=%lu tdu=%lu sync_hyp=%lu bad_nid_hyp=%lu acquisitions=%lu\r\n",(unsigned long)mon_hdu,(unsigned long)mon_ldu1,(unsigned long)mon_ldu2,(unsigned long)mon_tdu,(unsigned long)syncs,(unsigned long)bad_nid,(unsigned long)monitor.demod.acquisitions);send(line);
    int32_t phase_min=monitor.demod.lane[0].next_q16,phase_max=phase_min;
    int32_t period_min=monitor.demod.lane[0].period_q16,period_max=period_min;
    for(unsigned i=1;i<10;++i) {
        const p25_demod_lane *l=&monitor.demod.lane[i];
        if(l->next_q16<phase_min)phase_min=l->next_q16;
        if(l->next_q16>phase_max)phase_max=l->next_q16;
        if(l->period_q16<period_min)period_min=l->period_q16;
        if(l->period_q16>period_max)period_max=l->period_q16;
    }
    snprintf(line,sizeof line,"RXHUNT rearms=%lu idle_ticks=%u history_ticks=%u cost_us=%lu max_us=%lu phase_min_q16=%ld phase_max_q16=%ld period_min_q16=%ld period_max_q16=%ld\r\n",
        (unsigned long)monitor.demod.hunt_rearms,monitor.demod.idle_ticks,monitor.demod.hunt_filled,
        (unsigned long)monitor.demod.hunt_us,(unsigned long)monitor.demod.hunt_max_us,
        (long)phase_min,(long)phase_max,(long)period_min,(long)period_max);send(line);
    snprintf(line,sizeof line,"RXMON_IO audio_enabled=%u routed=%u fault_age_us=%lu fault_audio=%08lx fault_mask=%08lx fault_mode=%08lx\r\n",
        (unsigned)mon_audio_enabled,(unsigned)mon_routed,(unsigned long)mon_fault_age,
        (unsigned long)mon_fault_audio,(unsigned long)mon_fault_mask,(unsigned long)mon_fault_mode);
    send(line);
    snprintf(line,sizeof line,"RXMON_UI sync=%u max_flush_us=%lu max_speaker_gap_us=%lu\r\n",
        (unsigned)mon_sync_active(hrc_micros()),(unsigned long)mon_ui_max_us,(unsigned long)mon_spk_gap_us);
    send(line);
    snprintf(line,sizeof line,"RXFIFO mode=%s service_ms=%u timer_us=%u local=%u replay=%u tone_hz=%u generated=%lu chunks=%lu full=%lu span_us=%lu max_push_gap_us=%lu\r\n",
        mon_fifo_limit==1 ? "SINGLE" : "BURST",mon_timer_us ? 0u : mon_service_ms,mon_timer_us,(unsigned)mon_local_tone,(unsigned)mon_replay,mon_tone_hz,(unsigned long)mon_local_frames,
        (unsigned long)mon_pushes,(unsigned long)mon_full,(unsigned long)(mon_pushes ? mon_last_push-mon_first_push : 0),
        (unsigned long)mon_push_gap);send(line);
#if DM32_LAB_DIAGNOSTICS
    snprintf(line,sizeof line,"RXTRACE frames=%lu kept=%u payloads=%lu hash=%08lx from_hdu=%u output=%s recorded_output=%s\r\n",
        (unsigned long)monitor.trace.frames,pcm_trace_kept(&monitor.trace),
        (unsigned long)(monitor.trace.frames<PCM_TRACE_PAYLOADS ? monitor.trace.frames : PCM_TRACE_PAYLOADS),
        (unsigned long)monitor.trace.hash,(unsigned)monitor.trace.from_hdu,mon_output_tone ? "TONE" : "DECODED",monitor.trace.tone_substituted ? "TONE" : "DECODED");send(line);
#endif
}
#if DM32_LAB_DIAGNOSTICS
static void rx_bench_yield(void) {vTaskDelay(pdMS_TO_TICKS(1));}
static bool txdiag_number(const char *key,unsigned *value) {
    size_t n=strlen(key);
    if(strncmp(command,key,n))return false;
    const char *s=command+n;
    size_t length=strlen(s);
    if(length<1 || length>2)return false;
    unsigned result=0;
    for(unsigned i=0;i<length;++i) {
        if(s[i]<'0' || s[i]>'9')return false;
        result=result*10u+(unsigned)(s[i]-'0');
    }
    *value=result;return true;
}
#endif
static void parse_command(bool down) {
    bool defer_reply=command_critical_pass || command_tx_critical(down);
    if(defer_reply && strcmp(command,"STOP")) {
        command_deferred|=!strcmp(command,"STATUS") ? COMMAND_DEFER_STATUS : COMMAND_DEFER_BUSY;
        return;
    }
    if(feature_cps(down))return;
    if(broadcast_show && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        send("ERR broadcast FM active; return to radio first\r\n");return;
    }
    if(broadcast_show && !strcmp(command,"STOP")) {
        broadcast_leave(down);send("OK STOP\r\n");return;
    }
#if !DM32_LAB_DIAGNOSTICS
    if(!strncmp(command,"RX",2) || !strncmp(command,"TXSOURCE",8) || !strncmp(command,"TXPAIRS",7)
       || !strncmp(command,"TXALIGN",7) || !strncmp(command,"TXWRITER",8) || !strncmp(command,"TXDAC",5)
       || !strncmp(command,"ARM",3) || !strncmp(command,"SESSION",7)) {
        send("ERR UNAVAILABLE; lab diagnostics disabled\r\n");return;
    }
#endif
    if((cps_link || cps_active) && strcmp(command,"STATUS") && strcmp(command,"STOP")) {send("ERR programming session active\r\n");return;}
    if(digital_dmr.owned && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        if(down || call_active || hardware_running) {send("ERR DMR call active\r\n");return;}
        radio_dmr_stop(&digital_dmr);
    }
    if(analog_fm.owned && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        if(down || call_active || hardware_running) {send("ERR FM call active\r\n");return;}
        p25_fm_stop(&analog_fm);
    }
    if(!strcmp(command,"RADIO")) {
        if(down || call_active || prepared || rx_job || editing || menu_open) {send("ERR RADIO requires idle/PTT released\r\n");return;}
        (void)normal_resume();send("OK RADIO; owner TX inhibit retained\r\n");return;
    }
#if DM32_LAB_DIAGNOSTICS
    if(!strncmp(command,"TXSOURCE",8) || !strncmp(command,"TXPAIRS",7) || !strncmp(command,"TXALIGN",7)
       || !strncmp(command,"TXWRITER",8) || !strncmp(command,"TXDAC",5)) {
        if(down || armed || session_enabled || call_active || prepared || mon_enabled || mon_running
           || rx_job || rx_sampling || editing || menu_open || rx_lab) {
            send("ERR stop RX/TX session and release PTT before TX diagnostics\r\n");return;
        }
        unsigned value;
        if(!strcmp(command,"TXWRITER DUP") || !strcmp(command,"TXWRITER ALT0") || !strcmp(command,"TXWRITER ALT1")) {
            tx_writer=!strcmp(command,"TXWRITER ALT0") ? TX_WRITER_ALT0 : !strcmp(command,"TXWRITER ALT1") ? TX_WRITER_ALT1 : TX_WRITER_DUP;
            send("OK TXWRITER\r\n");
        } else if(!strcmp(command,"TXDAC KEEP") || !strcmp(command,"TXDAC RESTORE")) {
            tx_dac_restore=!strcmp(command,"TXDAC RESTORE");send("OK TXDAC\r\n");
        } else if(!strcmp(command,"TXSOURCE MIC") || !strcmp(command,"TXSOURCE FIXED1011")) {
            tx_fixed=!strcmp(command,"TXSOURCE FIXED1011");
            if(!tx_fixed)tx_startup_extra=0;
            send("OK TXSOURCE\r\n");
        } else if(txdiag_number("TXPAIRS ",&value) && value>=1 && value<=28) {
            tx_pairs=value;send("OK TXPAIRS\r\n");
        } else if(txdiag_number("TXALIGN ",&value) && value<=LIVE_STARTUP_EXTRA_MAX_BYTES) {
            tx_startup_extra=value;send("OK TXALIGN\r\n");
        } else {send("ERR TXSOURCE MIC|FIXED1011 | TXPAIRS 1..28 | TXALIGN 0..35 | TXWRITER DUP|ALT0|ALT1 | TXDAC KEEP|RESTORE\r\n");return;}
        normal_mode=false;radio_inhibit(&control,true);screen("HOME");return;
    }
    if(!strncmp(command,"RXBACKEND ",10)) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down || armed || session_enabled
           || (strcmp(command,"RXBACKEND FIFO") && strcmp(command,"RXBACKEND PCM"))) {
            send("ERR RXBACKEND FIFO|PCM; stopped RX/TX session required\r\n");return;
        }
        mon_pcm_disable();mon_pcm_backend=!strcmp(command,"RXBACKEND PCM");
        send("OK RXBACKEND\r\n");return;
    }
    if(!strncmp(command,"RXTIMER ",8)) {
        unsigned us;char extra;
        if(sscanf(command,"RXTIMER %u %c",&us,&extra)!=1 || (us!=250 && us!=500)
           || mon_enabled || mon_running || rx_job || call_active || prepared || down) {
            send("ERR RXTIMER 250|500; stopped RX/TX required\r\n");return;
        }
        mon_timer_us=us;send("OK RXTIMER\r\n");return;
    }
    if(!strncmp(command,"RXSERVICE ",10)) {
        unsigned ms;char extra;
        if(sscanf(command,"RXSERVICE %u %c",&ms,&extra)!=1 || (ms!=1 && ms!=2)
           || pdMS_TO_TICKS(ms)==0 || mon_enabled || mon_running || rx_job || call_active || prepared || down) {
            send("ERR RXSERVICE 1|2; stopped RX/TX required\r\n");return;
        }
        mon_timer_us=0;mon_service_ms=ms;send("OK RXSERVICE\r\n");return;
    }
    if(!strcmp(command,"RXPERF")) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXPERF\r\n");return;}
        char line[256];
        snprintf(line,sizeof line,"RXPERF service_ms=%u timer_us=%u ticks=%lu notify_max=%lu step_max_us=%lu step_total_us=%lu step_calls=%lu worst_at_us=%lu worst_queue_frames=%lu bins=32\r\n",mon_timer_us ? 0u : mon_service_ms,mon_timer_us,(unsigned long)mon_timer_ticks,(unsigned long)mon_notify_max,(unsigned long)mon_step_max_us,(unsigned long)mon_step_total_us,(unsigned long)mon_step_calls,(unsigned long)mon_worst_at,(unsigned long)mon_worst_queue);send(line);
        for(unsigned i=0;i<32;++i) {
            const mon_perf_bin *p=&mon_perf[i];
            if(!p->pushes && !p->full && !p->empty)continue;
            snprintf(line,sizeof line,"RXPERF_BIN second=%u pushes=%lu full=%lu max_gap_us=%lu max_service_us=%lu empty=%lu route_missing=%lu\r\n",i,(unsigned long)p->pushes,(unsigned long)p->full,(unsigned long)p->max_gap,(unsigned long)p->max_service,(unsigned long)p->empty,(unsigned long)p->route_missing);send(line);
        }
        send("OK RXPERF\r\n");return;
    }
    if(!strncmp(command,"RXTONE ",7)) {
        unsigned hz;char extra;
        if(sscanf(command,"RXTONE %u %c",&hz,&extra)!=1 || (hz!=997 && hz!=1000 && hz!=1011)
           || mon_enabled || mon_running || rx_job || call_active || prepared || down) {
            send("ERR RXTONE 997|1000|1011; stopped RX/TX required\r\n");return;
        }
        mon_tone_hz=hz;mon_tone_phase=0;send("OK RXTONE\r\n");return;
    }
    if(!strcmp(command,"RXOUTPUT DECODED") || !strcmp(command,"RXOUTPUT TONE")) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXOUTPUT\r\n");return;}
        mon_output_tone=!strcmp(command,"RXOUTPUT TONE");send("OK RXOUTPUT\r\n");screen("HOME");return;
    }
    if(!strncmp(command,"RXPCM ",6) || !strncmp(command,"RXBITS ",7)) {
        unsigned index,slice;char extra;
        if(mon_enabled || mon_running || !mon_used || rx_job || call_active || prepared || down) {
            send("ERR trace download requires stopped RX/TX and monitor evidence\r\n");return;
        }
        char line[192];
        if(!strncmp(command,"RXPCM ",6)) {
            if(sscanf(command,"RXPCM %u %u %c",&index,&slice,&extra)!=2 || index>=pcm_trace_kept(&monitor.trace) || slice>=5) {
                send("ERR RXPCM <retained-frame> <slice 0..4>\r\n");return;
            }
            uint32_t seq=monitor.trace.frames-pcm_trace_kept(&monitor.trace)+index;
            const int16_t *samples=&monitor.trace.pcm[seq%PCM_TRACE_FRAMES][slice*32];
            int n=snprintf(line,sizeof line,"RXPCM %u %u %lu ",index,slice,(unsigned long)seq);
            for(unsigned i=0;i<32;++i) {uint16_t x=(uint16_t)samples[i];n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x%02x",x&255u,x>>8);}
            snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);
        } else {
            if(sscanf(command,"RXBITS %u %c",&index,&extra)!=1 || index>=monitor.trace.frames || index>=PCM_TRACE_PAYLOADS) {
                send("ERR RXBITS <payload-index>\r\n");return;
            }
            int n=snprintf(line,sizeof line,"RXBITS %u ",index);
            for(unsigned i=0;i<11;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x",monitor.trace.payload[index][i]);
            snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);
        }
        return;
    }
    if(!strcmp(command,"RXFIFO SINGLE") || !strcmp(command,"RXFIFO BURST")) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXFIFO\r\n");return;}
        mon_fifo_limit=!strcmp(command,"RXFIFO SINGLE") ? 1 : 8;send("OK RXFIFO\r\n");return;
    }
    if(!strcmp(command,"RXAUDIO ON") || !strcmp(command,"RXAUDIO OFF")) {
        if(mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXAUDIO\r\n");return;}
        mon_audio_enabled=!strcmp(command,"RXAUDIO ON");send("OK RXAUDIO\r\n");screen("HOME");return;
    }
    if(!strcmp(command,"RXMON OFF")) {mon_enabled=false;mon_stop("disabled");send("OK RXMON OFF\r\n");screen("HOME");return;}
    if(!strncmp(command,"RXMON ",6)) {
        unsigned long hz;char mode[8],extra;
        if(sscanf(command,"RXMON %lu %7s %c",&hz,mode,&extra)!=2 || (strcmp(mode,"CLEAR") && strcmp(mode,"LOCAL") && strcmp(mode,"REPLAY"))
           || hz>480000000u || !channel_in_band((uint32_t)hz,false) || down || rx_job || call_active || prepared) {
            send("ERR RXMON <Hz> CLEAR/LOCAL/REPLAY | RXMON OFF; idle/PTT released\r\n");return;
        }
        if(!strcmp(mode,"REPLAY") && (mon_running || mon_enabled || !mon_used || !pcm_trace_kept(&monitor.trace))) {send("ERR REPLAY requires stopped retained PCM\r\n");return;}
        if(strcmp(mode,"CLEAR") && !mon_audio_enabled) {send("ERR playback requires RXAUDIO ON\r\n");return;}
        if(mon_running)mon_stop("retune");
        mon_local_tone=!strcmp(mode,"LOCAL");mon_replay=!strcmp(mode,"REPLAY");
        normal_mode=false;session_enabled=false;armed=false;radio_inhibit(&control,true);frequency=(uint32_t)hz;if(!control.split)control.tx_frequency=frequency;
        menu_open=editing=rx_lab=false;mon_enabled=true;mon_reason="ready";
        screen("HOME");send(mon_replay ? "OK RXMON REPLAY; 20s delay; retained tail once; TX inhibited\r\n" : mon_local_tone ? "OK RXMON LOCAL; 20s delay; 6s tone; TX inhibited\r\n" : "OK RXMON CLEAR; NAC filter; all talkgroups; TX inhibited\r\n");return;
    }
    if(mon_running && strcmp(command,"STOP") && strcmp(command,"STATUS")) {
        send("ERR stop RX monitor before diagnostics or TX configuration\r\n");return;
    }
    if(!strcmp(command,"RXDEMOD CLEAR") || !strcmp(command,"RXDEMOD CLEAR PROFILE")) {
        if(mon_used || down || rx_job || rx_sampling || call_active || prepared || hardware_running
            || rxcap.count!=RXCAP_BLOCKS || rxcap.gaps || rxcap.repeats || rxcap.invalid) {
            send("ERR RXDEMOD stopped complete gap-free known-clear capture required\r\n");return;
        }
        hardware_stop();armed=false;session_enabled=false;control.inhibit=true;
        send("OK RXDEMOD known-clear bench; RF and speaker off\r\n");
        if(!imbe_bench_init()) {send("ERR codec owner\r\n");return;}
        p25_receive_result result;
        p25_receive_bench_profile(&rxcap.data[0][0],RXCAP_BLOCKS*RXCAP_BYTES/2,(uint16_t)control.nac,
            hrc_micros,imbe_bench_decode_pcm,rx_bench_yield,&result,strstr(command," PROFILE")!=NULL);
        char line[320];
        snprintf(line,sizeof line,"RXDEMOD units=%lu voices=%lu corrected=%lu hash=%08lx elapsed_us=%lu active_us=%lu decode_us=%lu max_decode_us=%lu max_block_us=%lu state_bytes=%lu stack_free_bytes=%lu\r\n",
            (unsigned long)result.units,(unsigned long)result.voices,(unsigned long)result.corrected,
            (unsigned long)result.pcm_hash,(unsigned long)result.elapsed_us,(unsigned long)result.active_us,(unsigned long)result.decode_us,
            (unsigned long)result.max_decode_us,(unsigned long)result.max_block_us,(unsigned long)result.state_bytes,
            (unsigned long)(uxTaskGetStackHighWaterMark(NULL)*sizeof(StackType_t)));
        send(line);
        snprintf(line,sizeof line,"RXSTAGES profiled=%u fir_us=%lu symbol_us=%lu sync_us=%lu fec_us=%lu sync_tests=%lu fec_candidates=%lu fec_skipped=%lu\r\n",
            strstr(command," PROFILE")!=NULL,(unsigned long)result.fir_us,(unsigned long)result.symbol_us,
            (unsigned long)result.sync_us,(unsigned long)result.fec_us,(unsigned long)result.sync_tests,
            (unsigned long)result.fec_candidates,(unsigned long)result.fec_skipped);
        send(line);return;
    }
#endif
    if(!strncmp(command,"CHANNEL ",8)) {
        unsigned long rx,tx,nac,tg,id,gain;char extra;
        if(down || editing || menu_open || mon_enabled || mon_running || rx_job || call_active || prepared || armed || session_enabled) {send("ERR stop RX/TX before CHANNEL\r\n");return;}
        if(sscanf(command,"CHANNEL %lu %lu %lu %lu %lu %lu %c",&rx,&tx,&nac,&tg,&id,&gain,&extra)!=6) {send("ERR CHANNEL rx tx nac_decimal tg id mic_db\r\n");return;}
        p25_preferences p={(uint32_t)rx,(uint32_t)tx,(uint32_t)nac,(uint32_t)tg,(uint32_t)id,rx!=tx,(uint32_t)gain,owner_tx_inhibit,rx_promiscuous};
        if(rx>UINT32_MAX || tx>UINT32_MAX || nac>UINT32_MAX || tg>UINT32_MAX || id>UINT32_MAX || gain>UINT32_MAX || !pref_values(&p) || !channel_in_band(p.rx,false) || !channel_in_band(p.tx,true)) {send("ERR invalid channel\r\n");return;}
        frequency=p.rx;control.tx_frequency=p.tx;control.nac=p.nac;control.talkgroup=p.tg;control.source_id=p.id;control.split=p.split;mic_gain_db=p.mic_db;
        normal_mode=false;radio_inhibit(&control,true);pref_state="pending";preferences_poll(false);screen("HOME");send("OK CHANNEL; TX inhibited\r\n");return;
    }
    if(!strcmp(command,"STOP")) {
        if(cps_active)p25_cs_abort(&channel_store);
        cps_active=cps_link=false;feature_stop_scan(true);
        if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
        if(analog_fm.owned)p25_fm_stop(&analog_fm);
        normal_mode=false;session_enabled=false;mon_enabled=false;mon_stop("cancelled");
    }
    if(!strcmp(command,"STOP") && rx_job)rx_end("cancelled");
    if(!strcmp(command,"STOP")) {
        radio_inhibit(&control,true);menu_open=false;editing=false;digit_count=0;
        fail("cancelled");cleanup();screen("DISARMED");
        if(defer_reply)command_deferred|=COMMAND_DEFER_STOP_ACK;
        else send("OK STOP\r\n");
        return;
    }
    if(!strcmp(command,"STATUS")) { status(); return; }
#if DM32_LAB_DIAGNOSTICS
    if(!strncmp(command,"RXPROFILE ",10)) {
        unsigned profile;char extra;
        if(sscanf(command,"RXPROFILE %u %c",&profile,&extra)!=1 || profile>7 || down
           || rx_job || call_active || prepared) {send("ERR RXPROFILE 0..7; bit0=wide bit1=bypass bit2=DMR RF; idle only\r\n");return;}
        rx_profile=profile;send("OK RXPROFILE\r\n");return;
    }
    if(!strcmp(command,"RXMETA")) {
        if(rx_job || call_active) {send("ERR RXMETA stopped capture only\r\n");return;}
        char line[300];snprintf(line,sizeof line,"RXMETA profile=%u samples=%u max_poll_us=%lu work=%08lx rf=%08lx bw=%08lx audio=%08lx phase=%08lx spk_source=%u mic_path=%u\r\n",
            rx_capture_profile,rx_signal_count,(unsigned long)rx_signal_max_us,
            (unsigned long)rx_reg_work,(unsigned long)rx_reg_rf,(unsigned long)rx_reg_bw,
            (unsigned long)rx_reg_audio,(unsigned long)rx_reg_phase,(unsigned)rx_pin_source,(unsigned)rx_pin_mic);send(line);return;
    }
    if(!strncmp(command,"RXSIGNAL ",9)) {
        unsigned index;char extra;
        if(sscanf(command,"RXSIGNAL %u %c",&index,&extra)!=1 || rx_job || call_active
           || index>=rx_signal_count) {send("ERR RXSIGNAL index; stopped capture only\r\n");return;}
        char line[100];snprintf(line,sizeof line,"RXSIGNAL %u %lu %d %u\r\n",index,
            (unsigned long)rx_signals[index].us,(int)rx_signals[index].dbm,rx_signals[index].noise);send(line);return;
    }
    if(!strncmp(command,"RXCAP ",6)) {
        unsigned long hz,delay;char extra;
        if(sscanf(command,"RXCAP %lu %lu %c",&hz,&delay,&extra)!=2 || delay>30000u
           || hz>480000000u || !channel_in_band((uint32_t)hz,false) || down || rx_job
           || call_active || prepared || !dev || !hooks) {send("ERR RXCAP <Hz> <delay_ms 0..30000>; idle/PTT released\r\n");return;}
        mon_enabled=false;mon_used=false;memset(&rx_storage,0,sizeof rx_storage);
        armed=false;radio_inhibit(&control,true);hardware_stop();
        board.radio->audio(false);board.radio->set_mode((rx_profile&4u) ? RADIO_MODE_DMR : RADIO_MODE_FM);
        if(!board.radio->rx((uint32_t)hz,(rx_profile&1u) ? RADIO_BW_25K : RADIO_BW_12K5,NULL)) {rx_end("tune_failed");send("ERR RXCAP tune\r\n");return;}
        // DMR frontend, but no DMR slot engine: retain only the FM PCM recorder.
        // Board DMR setup applies its existing RF register table and DMR bandwidth.
        hardware_stop();
        if(rx_profile&4u) {
            hrc7000_fm_rx(dev,(rx_profile&1u)!=0);
            hrc7000_audio_bits(dev,0,C7_AUDIO_FM_PLAY);
        }
        // C7000 FM_BANDWIDTH bit 6 is the audio band-pass enable.
        // Diagnostic-only bypass after normal RX setup; normal RX/TX reprograms it.
        if(rx_profile&2u)wr(C7_FM_BANDWIDTH,hrc7000_rd(dev,C7_FM_BANDWIDTH)&~(1u<<6));
        rx_capture_profile=rx_profile;
        board_rf_safe();wr(C7_SYS_INTERP_MASK,0);
        rx_hz=(uint32_t)hz;rx_due=hrc_micros()+(uint32_t)delay*1000u;
        rx_reason="waiting";rx_job=true;menu_open=editing=false;rx_lab=true;
        screen("INFO");send("OK RXCAP scheduled; PA off; download after recording\r\n");return;
    }
    if(!strncmp(command,"RXREAD ",7)) {
        unsigned block,slice;char extra;
        if(sscanf(command,"RXREAD %u %u %c",&block,&slice,&extra)!=2 || rx_job || call_active
           || mon_used || block>=rxcap.count || slice>=8) {send("ERR RXREAD <block> <slice 0..7>; stopped capture only\r\n");return;}
        char line[220];int n=snprintf(line,sizeof line,"RXDATA %u %u %lu %u ",block,slice,
                                    (unsigned long)rxcap.times[block],rxcap.halves[block]);
        for(unsigned i=0;i<64;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x",rxcap.data[block][slice*64+i]);
        snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);return;
    }
    unsigned long hz; char action[16],consent[16],extra;
    if(sscanf(command,"%15s %lu %15s %c",action,&hz,consent,&extra)!=3
       || (strcmp(action,"ARM") && strcmp(action,"SESSION")) || strcmp(consent,"ALLOW_RF")
       || hz>480000000ul || !channel_in_band((uint32_t)hz,true) || down || call_active || prepared || rx_job
       || !bf_cal_valid() || board.power->battery_mv()<board.battery_critical_mv) {
        send("ERR use STATUS | STOP | ARM/SESSION <Hz> ALLOW_RF; release PTT\r\n"); return;
    }
    normal_mode=false;mon_enabled=false;radio_complete(&control,false); menu_open=rx_lab=false; editing=false; digit_count=0; frequency=control.tx_frequency=(uint32_t)hz; control.split=false; arm_until=hrc_micros()+ARM_US;
    radio_inhibit(&control,false);
    session_enabled=!strcmp(action,"SESSION"); armed=!session_enabled;
    reason=session_enabled ? "session_ready" : "armed";
    screen(session_enabled ? "SESSION READY" : "ARMED / UNPLUG CABLE");
    send(session_enabled ? "OK LIVE SESSION; fresh PTT per call; STOP or power off ends\r\n"
                         : "OK LIVE ARMED 30s; unplug cable then fresh PTT\r\n");
#else
    send("ERR use RADIO | STATUS | STOP | CPS\r\n");
#endif
}
static void command_deferred_flush(bool down) {
    if(!command_deferred || command_tx_critical(down) || call_active || prepared || hardware_running || rx_sampling)return;
    // At most one deferred response per pass, regardless of the request count.
    // Only the idle controller may pay the full snapshot's UART wire time.
    if(command_deferred&COMMAND_DEFER_STOP_ACK) {
        command_deferred&=~COMMAND_DEFER_STOP_ACK;send("OK STOP\r\n");return;
    }
    unsigned pending=command_deferred;command_deferred_reset();
    if(pending&COMMAND_DEFER_STATUS)status();
    else if(pending&COMMAND_DEFER_BUSY)send("ERR DMR call active; request ignored\r\n");
}
static void commands(bool down) {
    bool critical=command_tx_critical(down);
    command_critical_pass=critical;
    uint8_t b[32]; size_t n=board.host_port->read(b,sizeof b);
    for(size_t i=0;i<n;++i) {
        if(b[i]=='\n' || b[i]=='\r') {
            if(command_used || command_overflow) {
                command[command_used]=0;
                if(command_overflow) {
                    if(critical || command_tx_critical(down))command_deferred|=COMMAND_DEFER_BUSY;
                    else send("ERR command too long\r\n");
                } else if(!strcmp(command,"STATUS"))command_deferred|=COMMAND_DEFER_STATUS;
                else parse_command(down);
            }
            command_used=0; command_overflow=false;
        } else if(b[i]>=32 && b[i]<127 && !command_overflow) {
            if(command_used+1<sizeof command) command[command_used++]=(char)b[i]; else command_overflow=true;
        }
    }
    // STOP may have ended the call in this pass. Its acknowledgement waits for
    // the next pass instead of introducing UART work into that critical pass.
    command_critical_pass=false;
    if(!critical)command_deferred_flush(down);
}
// The hardware loop and host adapter exercise exactly the same ordering.
static void normal_tick(uint32_t keys,bool *was_down,bool *dirty) {
    bool down=(keys&ptt_mask)!=0,old_arm=armed,old_session=session_enabled;
    if(dmr_hard_timeout) {
        radio_dmr_stop(&digital_dmr);dmr_hard_timeout=false;
        call_active=hardware_running=false;control.cancel=false;
        radio_complete(&control,false);reason="time_limit";
        ptt_release_required=true;ptt_release_seen=false;
    }
    bool release_changed=ptt_release_poll(down);
    bool keypad_allowed=feature_keys(keys);
    keypad_poll(keypad_allowed ? keys : keys&ptt_mask);
    if(board.input->encoder) {
        int step=board.input->encoder();
        if(step) {
            bool woke=radio_ux_activity(&radio_lights,hrc_micros(),true);
            if(!woke && keypad_allowed && !down)local_encoder(step);
        }
    }
    if(armed && (int32_t)(hrc_micros()-arm_until)>=0) {
        armed=false;if(!normal_mode && !session_enabled)radio_inhibit(&control,true);reason="arm_expired";
    }
    commands(down);
    if(cps_link && hrc_micros()-cps_activity_us>=(cps_active ? 60000000u : 3000000u)) {
        if(cps_active)p25_cs_abort(&channel_store);
        cps_active=cps_link=false;reason="listening";screen("HOME");
    }
    if(broadcast_show) {
        uint32_t now=hrc_micros();
        if(down) {
            broadcast_leave(true);*was_down=true;
            feature_lights();return;
        }
        if(broadcast.owned && (int32_t)(now-broadcast_due)>=0) {
            broadcast_due=now+100000u;
            bool busy=broadcast.busy,had_status=broadcast.have_status;
            bool stereo=broadcast.status.stereo;uint32_t khz=broadcast.khz;
            bool ok=radio_broadcast_poll(&broadcast);
            if(ok && !broadcast.busy && radio_functions_get_broadcast_khz(global_record)!=broadcast.khz) {
                (void)radio_functions_set_broadcast_khz(global_record,broadcast.khz);pref_state="pending";
            }
            if(!ok || busy!=broadcast.busy || had_status!=broadcast.have_status
               || stereo!=broadcast.status.stereo || khz!=broadcast.khz)broadcast_screen();
        }
        preferences_poll(down);ui_meters_poll();feature_lights();
        board.power->led(LED_RED,false);board.power->led(LED_GREEN,false);
        *was_down=down;
        if(radio_service_due(&power_sample_us,now,RADIO_POWER_PERIOD_US) && !board.power->switch_on()) {
            radio_broadcast_stop(&broadcast);broadcast_show=false;
            hardware_stop();board.power->latch(false);
        }
        return;
    }
    rx_poll(down);normal_permission();
    const char *old_pref_state=pref_state;preferences_poll(down);
    if(old_pref_state!=pref_state)screen("HOME");
    if(normal_mode && !radio_busy(&control) && control.state!=RADIO_FAULT) {
        if(editing || menu_open || rx_lab || cps_link || cps_active)control.state=RADIO_RX_PAUSED;
        else radio_receive_state(&control,mon_enabled,feature_dmr() ? digital_dmr.running : feature_fm() ? analog_fm.running : mon_running,false,false);
    }
    // Inhibited or already-held PTT does not interrupt reception.
    bool scan_reply=channel_scan.running && normal_mode && !owner_tx_inhibit
        && bf_cal_valid() && board.power->battery_mv()>=board.battery_critical_mv
        && ptt_fresh_request(down,*was_down);
    if((scan_reply || ptt_start_requested(down,*was_down)) && !feature_stop_scan(true)) {
        // A reply must never fall back to another talkgroup when the matched
        // memory could not be loaded. Preserve the base profile, cancel TX and
        // require explicit channel recovery before another transmission.
        radio_complete(&control,true);radio_inhibit(&control,true);
        ptt_release_required=true;ptt_release_seen=false;reason="channel_read_failed";
    }
    if(normal_mode && feature_dmr())feature_dmr_tick(down);
    else if(normal_mode && feature_fm())feature_fm_tick(down,*was_down);
    else mon_poll(ptt_start_requested(down,*was_down));
    // Process pending receiver input before deciding that a scan dwell elapsed.
    // A first qualifying P25 unit at the deadline must be allowed to hold RX.
    feature_scan_poll();
    ui_meters_poll();
    if(normal_mode && feature_dmr())dmr_indicator();
    if(display_ok && normal_mode && feature_fm() && analog_fm.running && !call_active && !editing && !menu_open && !rx_lab) {
        p25_ui_view view=ui_view(0);uint32_t token=ui_header_token(&view);
        if(token!=ui_header_shown) {gfx_frame_begin();p25_ui_header(&view);gfx_flush();ui_header_shown=token;}
    }
    if(release_changed)home_hint_refresh();
    if((old_arm!=armed || old_session!=session_enabled) && !call_active)screen("HOME");
    if((!normal_mode || feature_p25()) && ptt_start_requested(down,*was_down)
       && radio_request_tx(&control,down,*was_down,true)) {
        screen("VOICE CALL");*dirty=true;
        if(!begin_capture())fail("setup_failed");
    }
    *was_down=down;if(!normal_mode || feature_p25())poll_call(down && !control.cancel);
    if(!call_active && *dirty) {
        cleanup();if(!normal_mode)status();screen("HOME");*dirty=false;
    }
    if(!call_active && !digital_dmr.owned)board_rf_safe();
    board.power->led(LED_RED,hardware_running);
    feature_lights();
    if(radio_service_due(&power_sample_us,hrc_micros(),RADIO_POWER_PERIOD_US)
       && !board.power->switch_on()) {
        mon_enabled=false;if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
        mon_stop("power_off");if(analog_fm.owned)p25_fm_stop(&analog_fm);if(rx_job)rx_end("power_off");
        fail("power_off");cleanup();board.power->latch(false);
    }
}
static void live_task(void *arg) {
    (void)arg; board_rf_safe(); board_init(); board_rf_safe();
    board.input->init(); board.radio->init(); board.radio->audio(false);
    radio_dmr_hal dmr_hal={.radio=board.radio,.modem=board.dmr,.audio=board.audio,.vocoder=board.vocoder,
        .acquire=dmr_acquire,.release=dmr_release,.clock_us=dmr_clock_us,.tx_diag=dmr_native_tx_diag};
    radio_dmr_init(&digital_dmr,&dmr_hal);
    if(!radio_codec_bind_dmr(&rx_storage,sizeof rx_storage)) {board_rf_safe();vTaskDelete(NULL);return;}
    preferences_restore();
    board.display->init(); display_ok=gfx_init(board.display); board.display->set_backlight(80);
    for(unsigned i=0;i<board.keymap_len;++i) if(board.keymap[i].short_action==ACT_PTT) ptt_mask|=1u<<board.keymap[i].bit;
    if(!dev || !hooks || !ptt_mask || !board.host_port || !board.host_port->start()) {
        board_rf_safe(); vTaskDelete(NULL); return;
    }
    p25_irqs_install();
    hrc_irq_register(IRQ_TIMER6,isr_hard_stop);hrc_irq_enable(IRQ_TIMER6,true);
    hardware_stop();
    key_candidate=key_stable=board.input->scan(); key_changed_at=hrc_micros();
    uint32_t sampled_keys=key_stable,key_sample_us=key_changed_at;
    power_sample_us=key_changed_at;
    bool was_down=(key_stable&ptt_mask)!=0, dirty=false;
    boot_policy();screen("HOME");status();
    for(;;) {
        if(radio_service_due(&key_sample_us,hrc_micros(),RADIO_INPUT_PERIOD_US))
            sampled_keys=board.input->scan();
        normal_tick(sampled_keys,&was_down,&dirty);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}
void __wrap_app_start(void) {
#if CONFIG_CRASH_LOG
    crash_init();
#endif
    // Native DMR audio runs at priority 5 and must preempt controller/LCD work.
    if(xTaskCreate(live_task,"p25live",4096,NULL,RADIO_CONTROL_PRIORITY,NULL)!=pdPASS) { board_rf_safe(); for(;;) {} }
}
