$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$upstream = Join-Path $root 'external/RadioFoundry/RadioFoundry'
$output = Join-Path $root 'build/imbe-ui-preview'
New-Item -ItemType Directory -Force -Path $output | Out-Null
$includes = @('hal','core','drivers','boards/dm32','platform/hrc7000','platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include') | ForEach-Object { '-I' + (Join-Path $upstream $_) }
& gcc -std=gnu11 -O1 -ffunction-sections -fdata-sections '-Wl,--gc-sections' -Wall -Wextra -Werror -Wno-unused-parameter -DCONFIG_DMR=1 -DCONFIG_FONT_AA=1 -DGFX_INDEXED=1 -DGFX_MAX_ROWS=320 -DGFX_FB_BYTES=40960 '-DBENCH_GIT="preview"' -I (Join-Path $root 'tests/diag-stubs') @includes -I (Join-Path $root 'src/firmware') (Join-Path $root 'tests/render_imbe_ui.c') (Join-Path $upstream 'core/ui/gfx.c') (Join-Path $upstream 'core/ui/fonts.c') -o (Join-Path $output 'render.exe')
if ($LASTEXITCODE -ne 0) { throw 'Benchmark renderer build failed' }
& (Join-Path $output 'render.exe') $output
if ($LASTEXITCODE -ne 0) { throw 'Benchmark renderer failed' }
