$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$codec = Join-Path $projectRoot 'research/references/nostar/imbe_vocoder'
$op25 = Join-Path $projectRoot 'research/references/boatbod/op25/op25/gr-op25_repeater/lib'
$build = Join-Path $projectRoot 'build/p25-1011'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$sources = @(Get-ChildItem -LiteralPath $codec -Filter '*.cc' -File | ForEach-Object FullName)
$exe = Join-Path $build 'decode_test_pair.exe'
& g++ -std=c++17 -O2 -fwrapv -I $codec -I $op25 (Join-Path $projectRoot 'src/host/decode_test_pair.cpp') @sources -o $exe
if ($LASTEXITCODE -ne 0) { throw 'Test-vector decoder build failed' }
& $exe (Join-Path $projectRoot 'fixtures/p25-1011/voice-ldu-pair.bin') (Join-Path $build 'decoded.s16le')
if ($LASTEXITCODE -ne 0) { throw "Test-vector decoding failed: $LASTEXITCODE" }
& python (Join-Path $projectRoot 'scripts/check-tone-audio.py')
if ($LASTEXITCODE -ne 0) { throw 'Decoded audio verification failed' }
