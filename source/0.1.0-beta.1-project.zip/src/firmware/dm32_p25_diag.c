// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (c) 2026 DM32 P25 research contributors
// Experimental linked application. RadioFoundry's pinned source remains unchanged.
#include "p25_test_tx.h"
#include "board.h"
#include "platform.h"
#include "dmr_glue.h"
#include "cal/baofeng/baofeng_cal.h"
#include "ui/gfx.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#if CONFIG_P25_TEST_TX
#include "p25_diag_ui.h"
#define PHY_READY (1u << 12)
#define ARM_TTL_US 30000000u
#define HARD_STOP_TIMER 6

static hrc7000_t *dev;
static const hrc_dmr_board_t *rf_hooks;
static p25_test_tx tx;
static bool armed, hardware_running, pa_started, display_ok, rf_prepared;
static uint32_t frequency, arm_until, ptt_mask;
static uint32_t sys_irqs, ts_irqs, rftx_irqs, saved_rf_mode;
static uint8_t variant=1, half;
static bool invert;
static char command[96];
static size_t command_used;
static bool command_overflow;
static bool setup_failed, arm_expired;

// Interpose only the cross-object entry points; do not start the normal DMR engine.
void __wrap_hrc_dmr_board_init(hrc7000_t *modem, const hrc_dmr_board_t *hooks)
{
    dev = modem;
    rf_hooks = hooks;
}
void __wrap_hrc_dmr_enter(void) {}
void __wrap_hrc_dmr_leave(void) {}

static void wr(uint32_t off, uint32_t value) { hrc7000_wr(dev, off, value); }
static void send_text(const char *text)
{
    if (board.host_port != NULL) (void)board.host_port->write((const uint8_t *)text, strlen(text));
}

static void hardware_stop(void)
{
    // Called with CPU interrupts masked, including from the independent hard stop ISR.
    if (dev != NULL) {
        wr(C7_LAYER2_TXRX_CTRL, 0);
        wr(C7_LAYER2_CONTROL, 0xc0);
        wr(C7_SYS_INTERP_MASK, 0);
    }
    hrc_irq_enable(IRQ_MODEM_SYS, false);
    hrc_irq_enable(IRQ_MODEM_TS_TX, false);
    hrc_irq_enable(IRQ_MODEM_TS_RX, false);
    hrc_irq_enable(IRQ_MODEM_RF_TX, false);
    hrc_irq_enable(IRQ_MODEM_RF_RX, false);
    hrc_timer_stop(TIMER_PA);
    hrc_timer_stop(HARD_STOP_TIMER);
    if (hardware_running && rf_hooks != NULL) rf_hooks->rf_switch(false);
    board_rf_safe();
    hardware_running = false;
    pa_started = false;
}

static void boundary(void)
{
    uint8_t block[P25_TX_BLOCK_BYTES];
    if (!hardware_running) return;
    uint32_t now = hrc_micros();
    if (!p25_test_tx_boundary(&tx, now, block)) {
        if (!p25_test_tx_active(&tx)) hardware_stop();
        else if (tx.state == P25_TX_DRAINING && now-tx.last_boundary_us >= 15000u)
            wr(C7_LAYER2_TXRX_CTRL, 0);
        // A duplicate SYS/TS event must not clear a pending send.
        return;
    }
    uint8_t policy = variant & 0x0cu;
    for (uint32_t i=0; i<P25_TX_BLOCK_BYTES; ++i) {
        if (policy == 0 || half == 0) dev->buf[i] = block[i];
        if (policy == 0 || half == 1) dev->buf[0x24u+i] = block[i];
    }
    half ^= 1u;
    wr(C7_LAYER2_TXRX_CTRL, 0x80u | ((variant & 2u) ? 1u : 0u));
}

static void isr_sys(void)
{
    uint32_t list = hrc7000_rd(dev, C7_SYS_INTERP_LIST);
    wr(C7_SYS_INTERP_CLEAR, list);
    ++sys_irqs;
    if (list & PHY_READY) boundary();
}
static void isr_slot(void)
{
    wr(C7_INTERP_CLEAR, C7_INT_TS_TX | C7_INT_TS_RX);
    ++ts_irqs;
    boundary();
}
static void isr_rftx(void)
{
    wr(C7_INTERP_CLEAR, C7_INT_RF_TX);
    ++rftx_irqs;
    if (hardware_running && p25_test_tx_active(&tx) && !pa_started) {
        pa_started = true;
        rf_hooks->rf_switch(true);
        hrc_timer_oneshot(TIMER_PA, rf_hooks->pa_delay_us);
    }
}
static void isr_rfrx(void) { wr(C7_INTERP_CLEAR, C7_INT_RF_RX); }
static void isr_pa(void)
{
    hrc_timer_ack(TIMER_PA);
    hrc_timer_stop(TIMER_PA);
    if (hardware_running && p25_test_tx_active(&tx)) rf_hooks->pa_on();
}
static void isr_hard_stop(void)
{
    hrc_timer_ack(HARD_STOP_TIMER);
    p25_test_tx_abort(&tx, P25_TX_TIMEOUT);
    hardware_stop();
}

static void status(void)
{
    char line[256];
    p25_test_tx snapshot;
    uint32_t saved = hrc_irq_save();
    snapshot = tx;
    uint32_t sys=sys_irqs, slots=ts_irqs, rf=rftx_irqs;
    bool running=hardware_running;
    hrc_irq_restore(saved);
    (void)snprintf(line, sizeof(line),
        "P25 git=%s cal=%s armed=%u hz=%lu variant=%u invert=%u state=%u reason=%u hw=%u bytes=%lu blocks=%lu dup=%lu late=%lu maxgap=%lu sys=%lu ts=%lu rf=%lu\r\n",
        P25_PROJECT_GIT, bf_cal_source(), (unsigned)armed, (unsigned long)frequency, (unsigned)variant,
        (unsigned)invert, (unsigned)snapshot.state, (unsigned)snapshot.reason, (unsigned)running,
        (unsigned long)snapshot.offset, (unsigned long)snapshot.blocks,
        (unsigned long)snapshot.duplicate_irqs, (unsigned long)snapshot.late_irqs,
        (unsigned long)snapshot.max_gap_us, (unsigned long)sys, (unsigned long)slots, (unsigned long)rf);
    send_text(line);
}

static void screen(bool starting)
{
    if (!display_ok || hardware_running) return;
    p25_diag_view view;
    uint32_t saved = hrc_irq_save();
    view.tx=tx;
    hrc_irq_restore(saved);
    view.frequency=frequency;
    int32_t remaining=(int32_t)(arm_until-hrc_micros());
    view.arm_seconds=armed && remaining>0 ? ((uint32_t)remaining+999999u)/1000000u : 0;
    view.battery_mv=board.power->battery_mv();
    view.critical_mv=board.battery_critical_mv;
    view.armed=armed; view.starting=starting;
    view.setup_failed=setup_failed; view.arm_expired=arm_expired;
    view.calibration_valid=bf_cal_valid(); view.calibration=bf_cal_source();
    view.git=P25_PROJECT_GIT;
    p25_diag_draw(&view);
}

static bool begin_transmission(void)
{
    armed = false; // Each ARM grants one PTT edge, even if setup fails.
    if (dev == NULL || rf_hooks == NULL || !board_in_band(frequency, true)) return false;
    if (!bf_cal_valid()) return false; // Do not use uncalibrated fallback PA drive.
    if (board.power->battery_mv() < board.battery_critical_mv) return false;
    board.radio->audio(false);
    board.radio->set_mode(RADIO_MODE_DMR);
    if (!board.radio->rx(frequency, RADIO_BW_12K5, NULL)
        || !board.radio->tx(frequency, RADIO_BW_12K5, 0, NULL)) return false;
    uint32_t saved = hrc_irq_save();
    hrc7000_audio_bits(dev, 0, C7_AUDIO_RING_PLAY | C7_AUDIO_FM_PLAY | C7_AUDIO_PCM_SPK | C7_AUDIO_PCM_MIC);
    saved_rf_mode = hrc7000_rd(dev, C7_RF_MODE);
    rf_prepared = true;
    wr(C7_RF_MODE, saved_rf_mode ^ (invert ? (1u << 7) : 0u));
    wr(C7_LAYER2_TXRX_CTRL, 0);
    wr(C7_LAYER2_SLOTON, 0);
    wr(C7_WORK_MODE, C7_WORK_MODE_FM);
    wr(C7_WORK_MODE, (variant & 1u) ? 0x02u : C7_WORK_MODE_PHY);
    wr(C7_AUDIO_BUFFER_CLR, 3);
    for (unsigned i=0; i<72; ++i) dev->buf[i] = 0x77;
    half = (variant & 0x0cu) == 8u ? 1u : 0u;
    sys_irqs=ts_irqs=rftx_irqs=0;
    wr(C7_SYS_INTERP_CLEAR, 0xffffffffu);
    wr(C7_INTERP_CLEAR, C7_INT_TS_TX | C7_INT_TS_RX | C7_INT_RF_TX | C7_INT_RF_RX);
    wr(C7_SYS_INTERP_MASK, PHY_READY);
    (void)p25_test_tx_start(&tx, hrc_micros(), true);
    hardware_running = true;
    pa_started = false;
    hrc_irq_enable(IRQ_MODEM_SYS, true);
    hrc_irq_enable(IRQ_MODEM_TS_TX, true);
    hrc_irq_enable(IRQ_MODEM_TS_RX, true);
    hrc_irq_enable(IRQ_MODEM_RF_TX, true);
    hrc_irq_enable(IRQ_MODEM_RF_RX, true);
    hrc_timer_oneshot(HARD_STOP_TIMER, P25_TX_MAX_US);
    wr(C7_LAYER2_CONTROL, 0x82u); // Own slot clock; CPU supplies complete PHY blocks.
    hrc_irq_restore(saved);
    return true;
}

static void stop_transmission(void)
{
    uint32_t saved = hrc_irq_save();
    hardware_stop();
    if (dev != NULL && rf_prepared) wr(C7_RF_MODE, saved_rf_mode);
    rf_prepared = false;
    hrc_irq_restore(saved);
    board.radio->tx_off();
    board.radio->set_mode(RADIO_MODE_FM);
    board.power->led(LED_RED, false);
}

static void parse_command(bool ptt_down)
{
    if (strcmp(command, "STATUS") == 0) { status(); return; }
    if (strcmp(command, "STOP") == 0) {
        armed = false;
        arm_expired=setup_failed=false;
        uint32_t saved = hrc_irq_save();
        p25_test_tx_abort(&tx, P25_TX_CANCELLED);
        hardware_stop();
        hrc_irq_restore(saved);
        send_text("OK STOP\r\n");
        return;
    }
    unsigned long hz=0;
    unsigned v=0, inv=0;
    char consent[16], extra;
    int count=sscanf(command, "ARM %lu %u %u %15s %c", &hz, &v, &inv, consent, &extra);
    if (count != 4 || strcmp(consent, "ALLOW_RF") != 0 || hz > 480000000ul
        || v > 11u || inv > 1u || !board_in_band((uint32_t)hz, true) || ptt_down
        || p25_test_tx_active(&tx) || hardware_running || !bf_cal_valid()) {
        send_text("ERR command: STATUS | STOP | ARM <Hz> <variant 0..11> <invert 0|1> ALLOW_RF; release PTT; valid calibration required\r\n");
        return;
    }
    frequency = (uint32_t)hz;
    variant = (uint8_t)v;
    invert = inv != 0;
    arm_until = hrc_micros() + ARM_TTL_US;
    armed = true;
    arm_expired=setup_failed=false;
    send_text("OK ARMED 30s; fresh PTT press starts one call\r\n");
}

static void poll_commands(bool ptt_down)
{
    uint8_t bytes[32];
    size_t length = board.host_port->read(bytes, sizeof(bytes));
    for (size_t i=0; i<length; ++i) {
        uint8_t c=bytes[i];
        if (c == '\r' || c == '\n') {
            if (command_used != 0 || command_overflow) {
                command[command_used] = 0;
                if (command_overflow) send_text("ERR command too long\r\n");
                else parse_command(ptt_down);
            }
            command_used = 0;
            command_overflow = false;
        } else if (c >= 32 && c < 127 && !command_overflow) {
            if (command_used+1 < sizeof(command)) command[command_used++] = (char)c;
            else command_overflow = true;
        }
    }
}

static void diagnostic_task(void *arg)
{
    (void)arg;
    board_init();
    board.input->init();
    board.radio->init();
    board.radio->audio(false);
    board.display->init();
    display_ok = gfx_init(board.display);
    board.display->set_backlight(80);
    for (unsigned i=0; i<board.keymap_len; ++i)
        if (board.keymap[i].short_action == ACT_PTT) ptt_mask |= 1u << board.keymap[i].bit;
    if (board.host_port == NULL || !board.host_port->start() || dev == NULL || rf_hooks == NULL || ptt_mask == 0) {
        board_rf_safe();
        vTaskDelete(NULL);
        return;
    }
    hrc_irq_register(IRQ_MODEM_SYS, isr_sys);
    hrc_irq_register(IRQ_MODEM_TS_TX, isr_slot);
    hrc_irq_register(IRQ_MODEM_TS_RX, isr_slot);
    hrc_irq_register(IRQ_MODEM_RF_TX, isr_rftx);
    hrc_irq_register(IRQ_MODEM_RF_RX, isr_rfrx);
    hrc_irq_register(IRQ_TIMER3, isr_pa);
    hrc_irq_register(IRQ_TIMER6, isr_hard_stop);
    hrc_irq_enable(IRQ_TIMER3, true);
    hrc_irq_enable(IRQ_TIMER6, true);
    p25_test_tx_init(&tx);
    send_text("DM32 P25 fixed-pattern diagnostic " P25_PROJECT_GIT " DISARMED\r\n");
    bool was_down=(board.input->scan() & ptt_mask) != 0;
    bool cleanup_needed=false;
    uint32_t next_report=0;
    for (;;) {
        uint32_t now=hrc_micros();
        bool down=(board.input->scan() & ptt_mask) != 0;
        bool previously_armed=armed;
        if (armed && (int32_t)(now-arm_until) >= 0) { armed=false; arm_expired=true; }
        poll_commands(down);
        if (armed != previously_armed && !hardware_running) screen(false);
        if (down && !was_down && armed) {
            cleanup_needed=true;
            screen(true); // Flush the TX warning BEFORE modem timing starts.
            if (!begin_transmission()) {
                setup_failed=true;
                send_text("ERR RF setup refused\r\n");
            }
        }
        was_down=down;
        now=hrc_micros(); // RF setup and host writes may have advanced the clock.
        uint32_t saved=hrc_irq_save();
        p25_test_tx_poll(&tx, now, down);
        bool active=p25_test_tx_active(&tx);
        if (!active && hardware_running) hardware_stop();
        hrc_irq_restore(saved);
        if (!active && cleanup_needed) {
            stop_transmission();
            cleanup_needed=false;
            status();
            screen(false);
        }
        board.power->led(LED_RED, active);
        if (!board.power->switch_on()) {
            saved=hrc_irq_save();
            p25_test_tx_abort(&tx, P25_TX_CANCELLED);
            hardware_stop();
            hrc_irq_restore(saved);
            board.power->latch(false);
        }
        if ((int32_t)(now-next_report) >= 0) {
            status();
            if (!active) screen(false); // LCD transfers must not delay PHY interrupt service.
            next_report=now+1000000u;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void __wrap_app_start(void)
{
    if (xTaskCreate(diagnostic_task, "p25test", 1024, NULL, 5, NULL) != pdPASS) {
        board_rf_safe();
        for (;;) {}
    }
}
#endif
