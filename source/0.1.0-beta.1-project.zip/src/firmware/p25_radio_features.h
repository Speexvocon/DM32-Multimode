// SPDX-License-Identifier: GPL-3.0-or-later
// Unified channel/CPS/UX adapter, included after the live controller globals.
#ifndef P25_RADIO_FEATURES_H
#define P25_RADIO_FEATURES_H
static p25_cs_store channel_store;
static uint8_t channel_record[32],channel_saved[32],global_record[32],global_saved[32];
static radio_ux radio_lights;
static radio_scan channel_scan;
static p25_fm analog_fm;
static bool features_ready,rx_tg_filter,cps_active,cps_link;
static uint32_t cps_transaction,cps_activity_us;
static uint32_t light_keys,lock_mask,lock_select_mask;
static uint8_t light_screen_level=255,light_key_level=255;
static char channel_label[24];
static uint16_t feature_u16(const uint8_t *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static void feature_put16(uint8_t *p,unsigned value) {p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8);}
static bool feature_fm(void) {return (channel_record[12]&2u)!=0;}
static bool feature_dmr(void) {return radio_channel_get_mode(channel_record)==RADIO_CHANNEL_DMR;}
static bool feature_p25(void) {return radio_channel_get_mode(channel_record)==RADIO_CHANNEL_P25;}
static const char *feature_mode_name(void) {return feature_dmr() ? "DMR" : feature_fm() ? "FM" : "P25";}
static unsigned feature_filter(void) {return rx_promiscuous ? 1u : rx_tg_filter ? 2u : 0u;}
static unsigned feature_vfo(void) {return global_record[9]&1u;}
static unsigned feature_memory(void) {return global_record[10+feature_vfo()];}
static unsigned feature_key(void) {unsigned slot=feature_memory();return slot ? slot-1u : 32u+feature_vfo();}
static void feature_mirror_store(void) {
    pref_store.have=channel_store.have_active || channel_store.have_legacy;
    pref_store.writable=channel_store.writable;pref_store.seq=channel_store.revision;
}
static void feature_apply(void) {
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,hrc_micros());
    ui_rssi_valid=false;ui_rssi_bars=0;
    uint32_t rx=pref_get(channel_record),tx=pref_get(channel_record+4);
    bool occupied=(channel_record[12]&1u)!=0;
    frequency=occupied && board_in_band(rx,false) ? rx : 0;
    control.tx_frequency=frequency ? tx : 0;control.split=rx!=tx;
    control.nac=occupied && !feature_dmr() ? feature_u16(channel_record+8) : 0x293u;
    control.talkgroup=occupied && !feature_dmr() ? feature_u16(channel_record+10) : 1u;
    control.source_id=pref_get(global_record);mic_gain_db=global_record[4];
    owner_tx_inhibit=global_record[13]!=0;
    unsigned filter=(channel_record[12]>>2)&3u;rx_promiscuous=filter==1u;rx_tg_filter=filter==2u;
    radio_lights.screen_seconds=feature_u16(global_record+5);
    radio_lights.keypad_seconds=feature_u16(global_record+7);
    if(feature_memory())snprintf(channel_label,sizeof channel_label,"%c M%02u %.12s",'A'+feature_vfo(),feature_memory()%33u,(const char *)channel_record+14);
    else snprintf(channel_label,sizeof channel_label,"VFO %c",'A'+feature_vfo());
}
static void feature_capture(void) {
    if(frequency) {
        pref_put(channel_record,frequency);pref_put(channel_record+4,control.tx_frequency);
        if(!feature_dmr()) {feature_put16(channel_record+8,control.nac);feature_put16(channel_record+10,control.talkgroup);}
        channel_record[12]=(uint8_t)((channel_record[12]&0x72u)|1u|(feature_filter()<<2));
    }
    pref_put(global_record,control.source_id);global_record[4]=(uint8_t)mic_gain_db;
    global_record[13]=(uint8_t)owner_tx_inhibit;
    feature_put16(global_record+5,radio_lights.screen_seconds);
    feature_put16(global_record+7,radio_lights.keypad_seconds);
}
static bool feature_commit(unsigned key,const uint8_t record[32],bool save_globals) {
    if(!features_ready || !channel_store.writable || cps_active || channel_store.staging)return false;
    if(!p25_cs_begin(&channel_store,channel_store.revision))return false;
    bool ok=(key>=35u || p25_cs_stage_write(&channel_store,key,record))
        && (!save_globals || p25_cs_stage_write(&channel_store,34,global_record));
    uint32_t crc=0;
    ok=ok && p25_cs_stage_crc(&channel_store,&crc) && p25_cs_commit(&channel_store,crc);
    if(!ok)p25_cs_abort(&channel_store);
    feature_mirror_store();return ok;
}
static void preferences_restore(void) {
    radio_ux_init(&radio_lights,hrc_micros());
    memset(&channel_scan,0,sizeof channel_scan);memset(&analog_fm,0,sizeof analog_fm);
    cps_active=cps_link=false;features_ready=false;
    memset(channel_record,0,32);memset(global_record,0,32);
    pref_put(global_record,1);global_record[4]=11;feature_put16(global_record+5,60);feature_put16(global_record+7,15);
    bool opened=p25_cs_open(&channel_store,board.flash);
    features_ready=opened && p25_cs_read(&channel_store,34,global_record);
    if(features_ready) {
        unsigned key=feature_key();
        if(!p25_cs_read(&channel_store,key,channel_record) || !(channel_record[12]&1u)) {
            global_record[10+feature_vfo()]=0;
            (void)p25_cs_read(&channel_store,32u+feature_vfo(),channel_record);
        }
        feature_apply();
    } else {feature_apply();channel_store.writable=false;}
    feature_mirror_store();pref_store.flash=board.flash;
    memcpy(channel_saved,channel_record,32);memcpy(global_saved,global_record,32);
    pref_saved=pref_current();pref_dirty=false;
    pref_state=!pref_store.writable ? "read_only" : pref_store.have ? "saved" : "defaults";
    control.inhibit=true;control.tx_enabled=false;
}
static void preferences_poll(bool down) {
    if(!features_ready)return;
    if(normal_mode || !strcmp(pref_state,"pending"))feature_capture();
    pref_dirty=memcmp(channel_record,channel_saved,32) || memcmp(global_record,global_saved,32);
    p25_preferences current=pref_current();
    if(!pref_dirty && pref_store.have && !strcmp(pref_state,"pending") && pref_values(&current))pref_state=pref_store.writable ? "saved" : "read_only";
    if(!pref_dirty || down || mon_running || analog_fm.running || digital_dmr.running || rx_job || prepared || editing || armed
       || audio_on || hardware_running || call_active || channel_scan.running || cps_active)return;
    if(!pref_store.writable) {pref_state="read_only";return;}
    if(!strcmp(pref_state,"save_failed"))return;
    if(feature_commit(feature_key(),channel_record,true)) {
        memcpy(channel_saved,channel_record,32);memcpy(global_saved,global_record,32);
        pref_saved=pref_current();pref_dirty=false;pref_state="saved";
    } else pref_state="save_failed";
}
static void feature_stop_scan(bool adopt) {
    if(channel_scan.running && adopt) {global_record[10+feature_vfo()]=(uint8_t)(channel_scan.cursor+1u);feature_apply();}
    channel_scan.running=channel_scan.holding=false;
}
static void feature_pause(void) {
    if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
    if(mon_running)mon_stop("profile_change");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
}
static bool feature_load_key(unsigned key) {
    uint8_t record[32];
    if(!features_ready || key>=34 || !p25_cs_read(&channel_store,key,record) || !(record[12]&1u)
       || !board_in_band(pref_get(record),false))return false;
    feature_pause();memcpy(channel_record,record,32);feature_apply();
    memcpy(channel_saved,channel_record,32); // Recall does not rewrite the memory.
    mon_enabled=true;mon_reason="ready";reason="listening";
    radio_complete(&control,false);normal_permission();return true;
}
static bool feature_recall(int direction) {
    feature_pause();preferences_poll(false);if(pref_dirty)return false;
    unsigned current=feature_memory();uint8_t record[32];
    for(unsigned step=1;step<=32;++step) {
        unsigned slot=(current ? current-1u : (direction>0 ? 31u : 0u));
        slot=(slot+(direction>0 ? step : 32u-step))%32u;
        if(p25_cs_read(&channel_store,slot,record) && (record[12]&1u) && board_in_band(pref_get(record),false)) {
            if(feature_load_key(slot)) {global_record[10+feature_vfo()]=(uint8_t)(slot+1u);feature_apply();pref_state="pending";return true;}
        }
    }
    reason="no_memories";return false;
}
static bool feature_select_vfo(bool other) {
    feature_stop_scan(true);feature_pause();preferences_poll(false);if(pref_dirty) {reason="save_failed";return false;}
    unsigned next_vfo=other ? feature_vfo()^1u : feature_vfo();
    unsigned selected=other ? global_record[10+next_vfo] : 0;
    unsigned key=selected ? selected-1u : 32u+next_vfo;uint8_t record[32];
    if(!p25_cs_read(&channel_store,key,record) || ((record[12]&1u) && !board_in_band(pref_get(record),false)))return false;
    global_record[9]=(uint8_t)next_vfo;global_record[10+next_vfo]=(uint8_t)selected;memcpy(channel_record,record,32);
    feature_apply();memcpy(channel_saved,channel_record,32);pref_state="pending";
    radio_complete(&control,false);normal_permission();return true;
}
static bool feature_save_memory(unsigned slot) {
    if(slot<1 || slot>32 || !frequency)return false;
    feature_capture();uint8_t saved[32];memcpy(saved,channel_record,32);
    if(!saved[14])snprintf((char *)saved+14,12,"CH %02u",slot);
    if(!feature_commit(slot-1u,saved,false))return false;
    reason="memory_saved";return true;
}
static bool feature_scan_start(void) {
    feature_pause();preferences_poll(false);if(pref_dirty)return false;
    uint8_t record[32];unsigned mask=1u<<global_record[12],found=32;
    for(unsigned i=0;i<32;++i)if(p25_cs_read(&channel_store,i,record) && (record[12]&1u) && (record[13]&mask)) {found=i;break;}
    if(found==32) {reason="empty_scan_list";return false;}
    radio_scan_start(&channel_scan,hrc_micros(),(uint8_t)found,global_record[12]);
    if(!feature_load_key(found)) {feature_stop_scan(false);return false;}
    snprintf(channel_label,sizeof channel_label,"SCAN %u / M%02u",channel_scan.list+1u,found+1u);return true;
}
static void feature_scan_poll(void) {
    if(!channel_scan.running)return;
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    bool signal=feature_dmr() ? radio_dmr_scan_hold(dv)
        : feature_fm() ? analog_fm.have_status && analog_fm.audio_open
        : mon_have_sync && hrc_micros()-mon_sync_us<600000u
          && (!rx_tg_filter || (monitor.call.group_valid && monitor.call.group==control.talkgroup));
    if(!radio_scan_due(&channel_scan,hrc_micros(),signal))return;
    uint8_t record[32];
    for(unsigned step=1;step<=32;++step) {
        unsigned slot=(channel_scan.cursor+step)%32;
        if(p25_cs_read(&channel_store,slot,record) && (record[12]&1u) && (record[13]&(1u<<channel_scan.list))) {
            if(feature_load_key(slot)) {
                channel_scan.cursor=(uint8_t)slot;
                snprintf(channel_label,sizeof channel_label,"SCAN %u / M%02u",channel_scan.list+1u,slot+1u);
            } else {feature_stop_scan(true);reason="channel_read_failed";}
            return;
        }
    }
    feature_stop_scan(false);
}
static bool feature_keys(uint32_t keys) {
    uint32_t now=hrc_micros(),other=keys&~ptt_mask;
    bool down=(keys&ptt_mask)!=0;
    if(other!=light_keys || down)radio_ux_activity(&radio_lights,now,other!=0);
    light_keys=other;
    if(!lock_mask)for(unsigned i=0;i<board.keymap_len;++i) {
        if(board.keymap[i].short_action==ACT_QUICK)lock_mask|=1u<<board.keymap[i].bit;
        if(board.keymap[i].short_action==ACT_SELECT)lock_select_mask|=1u<<board.keymap[i].bit;
    }
    bool chord=lock_mask && lock_select_mask && (keys&lock_mask) && (keys&lock_select_mask);
    bool toggled=radio_ux_lock_chord(&radio_lights,now,chord,other!=0,!down && !call_active && !prepared);
    if(toggled) {
        editing=menu_open=rx_lab=false;edit_from_menu=diag_from_menu=false;digit_count=0;
        reason=radio_lights.locked ? "keypad_locked" : "listening";home_hint_refresh();
    }
    return !radio_lights.locked && !radio_lights.consume_release && !chord;
}
static void feature_lights(void) {
    uint32_t now=hrc_micros();
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    bool receiving=feature_dmr() ? dv && dv->state==DMR_CALL_STATE_RX
        : feature_fm() ? analog_fm.audio_open : mon_running && mon_have_sync && now-mon_sync_us<400000u;
    if(receiving)radio_ux_rx_activity(&radio_lights,now);
    radio_ux_idle(&radio_lights,now,call_active);
    uint8_t screen_level=radio_lights.screen_on ? 80 : 0,key_level=(uint8_t)radio_lights.keypad_on;
    if(screen_level!=light_screen_level && board.display && board.display->set_backlight) {
        board.display->set_backlight(screen_level);light_screen_level=screen_level;
    }
    if(key_level!=light_key_level) {hrc_pin_write(PIN_KEY_BACKLIGHT,key_level!=0);light_key_level=key_level;}
}
static subtone_t feature_tone(unsigned offset) {
    uint16_t packed=feature_u16(channel_record+offset);
    return (subtone_t){.type=(uint8_t)(packed>>14),.value=(uint16_t)(packed&0x3fffu)};
}
static void feature_tone_label(unsigned offset,char *line,size_t n) {
    subtone_t tone=feature_tone(offset);
    if(tone.type==TONE_NONE)snprintf(line,n,"None");
    else if(tone.type==TONE_CTCSS)snprintf(line,n,"CTCSS %u.%u Hz",tone.value/10u,tone.value%10u);
    else snprintf(line,n,"DCS %03o%s",tone.value,tone.type==TONE_DCS_INV ? " I" : " N");
}
static void feature_fm_tick(bool down,bool was_down) {
    bool home=!menu_open && !editing && !rx_lab && !rx_job && !cps_link && !cps_active;
    if(!normal_mode || !feature_fm() || !mon_enabled || !frequency || !home) {
        if(analog_fm.owned && !analog_fm.transmitting)p25_fm_stop(&analog_fm);
        return;
    }
    if(mon_running)mon_stop("analog_fm");
    if(!analog_fm.owned && control.state!=RADIO_FAULT) {
        p25_fm_config config={.rx_hz=frequency,.tx_hz=control.tx_frequency,
            .bandwidth=(channel_record[12]&32u) ? RADIO_BW_25K : RADIO_BW_12K5,
            .rx_tone=feature_tone(28),.tx_tone=feature_tone(26),
            .squelch=channel_record[30],.volume=100,.power=0};
        if(!p25_fm_start(&analog_fm,board.radio,board.audio,&config,hrc_micros())) {
            reason="fm_setup_failed";radio_complete(&control,true);normal_permission();screen("HOME");return;
        }
        reason="listening";radio_receive_state(&control,true,true,false,false);screen("HOME");
    }
    if(ptt_start_requested(down,was_down) && radio_request_tx(&control,down,was_down,true)) {
        feature_stop_scan(true);screen("VOICE CALL");
        hrc7000_set_mic_gain(dev,11); // Restore the native analog path's verified gain.
        call_active=hardware_running=true;control.cancel=false;
        hrc_timer_oneshot(HARD_TIMER,P25_FM_TX_MAX_US);
        if(!p25_fm_tx_begin(&analog_fm,hrc_micros()) || !hardware_running) {
            hardware_stop();call_active=false;p25_fm_stop(&analog_fm);
            reason="fm_tx_failed";radio_complete(&control,true);normal_permission();return;
        }
        control.state=RADIO_TX_VOICE;reason="voice_call";
    }
    bool was_tx=analog_fm.transmitting,was_audio=analog_fm.audio_open;
    if(analog_fm.transmitting && (!down || control.cancel || !call_active))p25_fm_tx_end(&analog_fm,hrc_micros());
    p25_fm_poll(&analog_fm,hrc_micros());
    if(was_tx && !analog_fm.transmitting) {
        bool timeout=analog_fm.timed_out || !strcmp(reason,"hard_timeout");
        hrc_timer_stop(HARD_TIMER);hardware_stop();call_active=false;control.cancel=false;
        if(timeout) {ptt_release_required=true;ptt_release_seen=false;}
        radio_complete(&control,false);reason=timeout ? "time_limit" : "listening";
        normal_permission();radio_receive_state(&control,true,true,false,false);screen("HOME");
    }
    if(!analog_fm.transmitting) {
        radio_receive_state(&control,true,analog_fm.running,analog_fm.audio_open,analog_fm.audio_open);
        if(was_audio!=analog_fm.audio_open)screen("HOME");
        board.power->led(LED_GREEN,analog_fm.audio_open);
    }
}
static bool feature_hex(const char *text,uint8_t *out,unsigned bytes) {
    if(strlen(text)!=bytes*2u)return false;
    for(unsigned i=0;i<bytes;++i) {
        unsigned v=0;
        for(unsigned j=0;j<2;++j) {char c=text[i*2+j];unsigned n=c>='0'&&c<='9' ? (unsigned)(c-'0') : c>='A'&&c<='F' ? (unsigned)(c-'A'+10) : c>='a'&&c<='f' ? (unsigned)(c-'a'+10) : 16u;if(n>15)return false;v=(v<<4)|n;}
        out[i]=(uint8_t)v;
    }
    return true;
}
static bool feature_number(const char *text,unsigned base,unsigned exact_digits,bool nonzero,uint32_t *out) {
    size_t count=strlen(text);if(!count || (exact_digits && count!=exact_digits) || count>10u)return false;
    uint32_t value=0;
    for(size_t i=0;i<count;++i) {
        char c=text[i];unsigned n=c>='0' && c<='9' ? (unsigned)(c-'0') : c>='A' && c<='F' ? (unsigned)(c-'A'+10) : c>='a' && c<='f' ? (unsigned)(c-'a'+10) : 16u;
        if(n>=base || value>(UINT32_MAX-n)/base)return false;
        value=value*base+n;
    }
    if(nonzero && !value)return false;
    *out=value;return true;
}
static bool feature_image_bands(void) {
    uint8_t record[32];
    for(unsigned i=0;i<34;++i) {
        if(!p25_cs_stage_read(&channel_store,i,record))return false;
        if((record[12]&1u) && (!board_in_band(pref_get(record),false)
           || (!(record[12]&16u) && !board_in_band(pref_get(record+4),true))))return false;
    }
    return true;
}
static void feature_cps_error(const char *code) {char line[48];snprintf(line,sizeof line,"CPS ERR %s\r\n",code);send(line);}
static bool feature_cps(bool down) {
    if(strncmp(command,"CPS ",4))return false;
    char line[120],extra;unsigned key;uint32_t tid,revision,crc;uint8_t record[32];
    char tid_text[10],revision_text[12],crc_text[10];
    if(call_active || prepared || hardware_running || audio_on || rx_job || rx_sampling || down || !hrc_pin_read(PIN_PTT)) {feature_cps_error("BUSY");return true;}
    if(!features_ready) {feature_cps_error("STORAGE");return true;}
    if(!strcmp(command,"CPS HELLO")) {
        if(cps_active) {feature_cps_error("TRANSACTION");return true;}
        feature_stop_scan(true);feature_pause();preferences_poll(false);
        cps_link=true;cps_activity_us=hrc_micros();
        uint32_t check=0;
        if(!p25_cs_stage_crc(&channel_store,&check)) {feature_cps_error("STORAGE");return true;}
        screen("HOME");snprintf(line,sizeof line,"CPS HELLO DM32P25 2 32 2 %lu %08lX\r\n",(unsigned long)channel_store.revision,(unsigned long)check);send(line);return true;
    }
    if(sscanf(command,"CPS GET %u %c",&key,&extra)==1) {
        if(key>=35 || !p25_cs_read(&channel_store,key,record)) {feature_cps_error("RECORD");return true;}
        int n=snprintf(line,sizeof line,"CPS DATA %u ",key);
        for(unsigned i=0;i<32;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02X",record[i]);
        cps_activity_us=hrc_micros();snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);return true;
    }
    if(sscanf(command,"CPS BEGIN %9s %11s %c",tid_text,revision_text,&extra)==2) {
        if(!feature_number(tid_text,16,8,true,&tid) || !feature_number(revision_text,10,0,false,&revision)) {feature_cps_error("TRANSACTION");return true;}
        feature_stop_scan(true);feature_pause();
        if(cps_active || !p25_cs_begin(&channel_store,(uint32_t)revision)) {feature_cps_error("REVISION");return true;}
        cps_active=cps_link=true;cps_transaction=(uint32_t)tid;cps_activity_us=hrc_micros();
        snprintf(line,sizeof line,"CPS OK BEGIN %08lX\r\n",(unsigned long)tid);send(line);return true;
    }
    if(!cps_active) {feature_cps_error("TRANSACTION");return true;}
    char encoded_record[65];
    if(sscanf(command,"CPS PUT %9s %u %64s %c",tid_text,&key,encoded_record,&extra)==3) {
        if(!feature_number(tid_text,16,8,true,&tid) || tid!=cps_transaction || key>=35 || !feature_hex(encoded_record,record,32)) {feature_cps_error("RECORD");return true;}
        if(!p25_cs_stage_write(&channel_store,key,record)) {feature_cps_error("INVALID");return true;}
        cps_activity_us=hrc_micros();snprintf(line,sizeof line,"CPS OK PUT %08lX %u\r\n",(unsigned long)tid,key);send(line);return true;
    }
    if(sscanf(command,"CPS ABORT %9s %c",tid_text,&extra)==1 && feature_number(tid_text,16,8,true,&tid) && tid==cps_transaction) {
        p25_cs_abort(&channel_store);cps_active=cps_link=false;
        screen("HOME");
        snprintf(line,sizeof line,"CPS OK ABORT %08lX\r\n",(unsigned long)tid);send(line);return true;
    }
    if(sscanf(command,"CPS COMMIT %9s %9s %c",tid_text,crc_text,&extra)==2 && feature_number(tid_text,16,8,true,&tid)
       && tid==cps_transaction && feature_number(crc_text,16,8,false,&crc)) {
        if(!feature_image_bands() || !p25_cs_commit(&channel_store,crc)) {feature_cps_error("COMMIT");return true;}
        cps_active=false;preferences_restore();(void)normal_resume();screen("HOME");
        snprintf(line,sizeof line,"CPS OK COMMIT %08lX %lu %08lX\r\n",(unsigned long)tid,(unsigned long)channel_store.revision,(unsigned long)crc);send(line);return true;
    }
    feature_cps_error("COMMAND");return true;
}
#endif
