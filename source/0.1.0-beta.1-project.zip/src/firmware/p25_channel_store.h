// SPDX-License-Identifier: GPL-3.0-or-later
// Atomic, bounded-memory codeplug in the DM32-owned 32 KiB settings window.
#ifndef P25_CHANNEL_STORE_H
#define P25_CHANNEL_STORE_H
#include "p25_preferences.h"
#include "radio_channel.h"

enum {
    P25_CS_RECORD_BYTES=32, P25_CS_RECORDS=35, P25_CS_CHANNELS=32,
    P25_CS_VFO_A=32, P25_CS_VFO_B=33, P25_CS_GLOBAL=34,
    P25_CS_BANK_BYTES=16384, P25_CS_SLOTS=256, P25_CS_SLOT_BYTES=64,
    P25_CS_NO_SLOT=65535
};
#define P25_CS_MAGIC 0x43533250u
#define P25_CS_VERSION 2u
// Channel flags: occupied, FM, filter, receive-only, wide FM, DMR (V2).
// Filter0/1/2 is NAC/PROM/NAC+TG for P25; CC/PROM/CC+destination for
// DMR. DMR PROM is limited to the selected timeslot, not both slots.
enum { P25_CS_OCCUPIED=1u, P25_CS_FM=2u, P25_CS_PROM=4u,
       P25_CS_TG_FILTER=8u, P25_CS_RX_ONLY=16u, P25_CS_WIDE=32u, P25_CS_DMR=64u };
// Canonical channel bytes: RX32@0, TX32@4, NAC16@8, TG16@10, flags@12,
// scanmask@13, printable/NUL-padded name12@14, TXtone16@26, RXtone16@28,
// squelch@30, zero@31. Tone top two bits give type; low14 hold its value.
// DMR union: destination24@8; config@11 (CC low4, TS2bit4, privatebit5,
// repeaterbit6, bit7zero). FM/DMR bits are mutually exclusive. DMR tones
// are zero and unused squelch is canonical5. P25/FM V1 payloads stay exact.
// Globals: ID32@0, mic@4, screen-off16@5, keypad-light16@7, activeVFO@9,
// selections A/B@10/11 (0 own VFO, 1..32 memory), scanlist@12, inhibit@13;
// bytes14..31 zero. Timeouts are seconds, 0 always on, maximum600.

typedef struct {
    const hal_flash_t *flash;
    uint32_t revision, legacy_addr;
    uint16_t active_slot[P25_CS_RECORDS], stage_slot[P25_CS_RECORDS];
    uint16_t stage_next;
    uint8_t active_bank, stage_bank, active_version;
    bool writable, have_active, have_legacy, staging, opened;
} p25_cs_store;

static inline uint16_t p25_cs_get16(const uint8_t *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static inline void p25_cs_put16(uint8_t *p,uint16_t n) {p[0]=(uint8_t)n;p[1]=(uint8_t)(n>>8);}
static inline bool p25_cs_zero(const uint8_t *p,unsigned n) {
    while(n--) {if(*p++)return false;}
    return true;
}
static inline bool p25_cs_tone_valid(uint16_t tone) {
    unsigned type=tone>>14,value=tone&0x3fffu;
    return type==0 ? value==0 : type==1 ? value>=600 && value<=2600 : value>=1 && value<=511;
}
static inline bool p25_cs_version(unsigned version) {return version==1u || version==P25_CS_VERSION;}
static inline bool p25_cs_record_valid_version(unsigned version,unsigned key,const uint8_t *p) {
    if(!p25_cs_version(version))return false;
    if(key>=P25_CS_RECORDS)return false;
    if(key==P25_CS_GLOBAL) {
        uint32_t id=pref_get(p);
        return id && id<=0xffffffu && p[4]<=42 && p25_cs_get16(p+5)<=600
            && p25_cs_get16(p+7)<=600 && p[9]<=1 && p[10]<=32 && p[11]<=32
            && p[12]<=3 && p[13]<=1 && p25_cs_zero(p+14,18);
    }
    if(!(p[12]&P25_CS_OCCUPIED))return p25_cs_zero(p,32);
    uint32_t rx=pref_get(p),tx=pref_get(p+4);
    if(rx<100000000u || rx>520000000u || tx<100000000u || tx>520000000u
       || p[12]&0x80u || (version==1u && (p[12]&P25_CS_DMR))
       || ((p[12]>>2)&3u)>2 || p[13]>15 || p[30]>9 || p[31])return false;
    bool ended=false;
    for(unsigned i=14;i<26;++i) {
        if(!p[i])ended=true;
        else if(ended || p[i]<32 || p[i]>126)return false;
    }
    if(p[12]&P25_CS_DMR) {
        return !(p[12]&(P25_CS_FM|P25_CS_WIDE)) && p[30]==5
            && radio_channel_get_destination(p) && !(p[11]&0x80u) && p25_cs_zero(p+26,4);
    }
    if(p25_cs_get16(p+8)>0xfffu || !p25_cs_get16(p+10))return false;
    uint16_t tx_tone=p25_cs_get16(p+26),rx_tone=p25_cs_get16(p+28);
    if(!(p[12]&P25_CS_FM))return !(p[12]&P25_CS_WIDE) && !tx_tone && !rx_tone;
    return p25_cs_tone_valid(tx_tone) && p25_cs_tone_valid(rx_tone);
}
static inline bool p25_cs_record_valid(unsigned key,const uint8_t *p) {
    return p25_cs_record_valid_version(P25_CS_VERSION,key,p);
}
static inline uint32_t p25_cs_crc_add(uint32_t crc,const uint8_t *p,unsigned n) {
    while(n--) {crc^=*p++;for(unsigned j=0;j<8;++j)crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);}return crc;
}
static inline uint32_t p25_cs_addr(const p25_cs_store *s,unsigned bank,unsigned slot) {
    return s->flash->map->settings_addr+bank*P25_CS_BANK_BYTES+slot*P25_CS_SLOT_BYTES;
}
static inline bool p25_cs_read_slot(const p25_cs_store *s,unsigned bank,unsigned slot,uint8_t *b) {
    return s->flash->read(p25_cs_addr(s,bank,slot),b,P25_CS_SLOT_BYTES);
}
static inline bool p25_cs_prefix(const uint8_t *b,unsigned key) {
    return pref_get(b)==P25_CS_MAGIC && p25_cs_version(b[4]) && b[5]==key
        && p25_cs_get16(b+6)==P25_CS_RECORD_BYTES;
}
static inline bool p25_cs_committed(const uint8_t *b) {
    return !pref_get(b+60) && pref_get(b+56)==pref_crc(b,56);
}
static inline bool p25_cs_data_slot(const uint8_t *b) {
    return b[5]<P25_CS_RECORDS && p25_cs_prefix(b,b[5]) && p25_cs_zero(b+40,16)
        && p25_cs_committed(b) && p25_cs_record_valid_version(b[4],b[5],b+8);
}
static inline void p25_cs_pack_slot(uint8_t *b,unsigned key,const uint8_t *record) {
    memset(b,0,64);pref_put(b,P25_CS_MAGIC);b[4]=P25_CS_VERSION;b[5]=(uint8_t)key;
    p25_cs_put16(b+6,P25_CS_RECORD_BYTES);memcpy(b+8,record,32);pref_put(b+56,pref_crc(b,56));
}
static inline bool p25_cs_write_slot(p25_cs_store *s,unsigned slot,const uint8_t *b) {
    uint8_t check[64];uint32_t addr=p25_cs_addr(s,s->stage_bank,slot);
    if(!s->flash->write(addr,b,60) || !s->flash->read(addr,check,60) || memcmp(b,check,60)
       || !s->flash->write(addr+60,b+60,4) || !s->flash->read(addr,check,64) || memcmp(b,check,64)) {
        s->writable=false;s->staging=false;return false;
    }
    return true;
}
// A valid bank is a complete snapshot. Record locations are appended, and only
// the final committed header publishes them. No active-bank write is needed.
static inline bool p25_cs_bank(const p25_cs_store *s,unsigned bank,uint16_t *index,uint32_t *revision,unsigned *version,bool *io_ok) {
    uint8_t b[64],record[32];uint32_t expected,bank_crc,crc=~0u;
    if(!p25_cs_read_slot(s,bank,0,b)) {*io_ok=false;return false;}
    if(!p25_cs_prefix(b,255) || !p25_cs_committed(b)
       || p25_cs_get16(b+16)!=P25_CS_RECORDS || p25_cs_get16(b+18)!=32
       || !p25_cs_zero(b+24,32))return false;
    *version=b[4];
    *revision=pref_get(b+8);expected=pref_get(b+12);bank_crc=pref_get(b+20);
    for(unsigned k=0;k<P25_CS_RECORDS;++k)index[k]=P25_CS_NO_SLOT;
    for(unsigned i=2;i<P25_CS_SLOTS;++i) {
        if(!p25_cs_read_slot(s,bank,i,b)) {*io_ok=false;return false;}
        if(p25_cs_data_slot(b) && b[4]==*version)index[b[5]]=(uint16_t)i;
    }
    for(unsigned k=0;k<P25_CS_RECORDS;++k) {
        if(index[k]==P25_CS_NO_SLOT)return false;
        if(!p25_cs_read_slot(s,bank,index[k],b)) {*io_ok=false;return false;}
        memcpy(record,b+8,32);crc=p25_cs_crc_add(crc,record,32);
    }
    if((crc^~0u)!=expected)return false;
    // The final ordered record is globals. A published memory selection must
    // resolve inside this same snapshot, never in another bank or legacy VFO.
    for(unsigned pane=0;pane<2;++pane)if(record[10+pane]) {
        if(!p25_cs_read_slot(s,bank,index[record[10+pane]-1u],b)) {*io_ok=false;return false;}
        if(!(b[20]&P25_CS_OCCUPIED))return false;
    }
    if(!p25_cs_read_slot(s,bank,1,b)) {*io_ok=false;return false;}
    p25_preferences legacy;
    if(!pref_blank(b) && !pref_unpack(b,&legacy))return false;
    return (p25_cs_crc_add(crc,b,64)^~0u)==bank_crc;
}
// Open never migrates or writes. Unknown records anywhere in the owned window
// disable writes, including unclassifiable torn headers, but valid old settings
// remain readable. A failed initial migration therefore retains its V3 profile.
static inline bool p25_cs_open(p25_cs_store *s,const hal_flash_t *flash) {
    memset(s,0,sizeof *s);s->flash=flash;
    for(unsigned k=0;k<P25_CS_RECORDS;++k)s->active_slot[k]=s->stage_slot[k]=P25_CS_NO_SLOT;
    if(!pref_geometry(flash))return false;
    s->writable=true;
    uint32_t latest=0,rev;unsigned version;uint8_t b[64];p25_preferences legacy;bool io_ok=true;
    for(unsigned bank=0;bank<2;++bank) {
        if(p25_cs_bank(s,bank,s->stage_slot,&rev,&version,&io_ok)
           && (!s->have_active || (int32_t)(rev-s->revision)>0)) {
            s->have_active=true;s->active_bank=(uint8_t)bank;s->revision=rev;s->active_version=(uint8_t)version;
            memcpy(s->active_slot,s->stage_slot,sizeof s->active_slot);
        }
    }
    if(!io_ok) {s->writable=false;return false;}
    for(unsigned i=0;i<2*P25_CS_SLOTS;++i) {
        uint32_t addr=flash->map->settings_addr+i*64u;
        if(!flash->read(addr,b,64)) {s->writable=false;return false;}
        if(pref_blank(b))continue;
        if(pref_get(b)==PREF_MAGIC && pref_version(pref_get(b+4))) {
            if(pref_unpack(b,&legacy) && (!s->have_legacy || (int32_t)(pref_get(b+8)-latest)>0)) {
                latest=pref_get(b+8);s->have_legacy=true;s->legacy_addr=addr;
            }
        } else if(pref_get(b)==P25_CS_MAGIC && p25_cs_version(b[4])
                  && (b[5]<P25_CS_RECORDS || (b[5]==255 && !(i%P25_CS_SLOTS)))
                  && p25_cs_get16(b+6)==32) {
            // Recognized, possibly torn, append record; bank CRC decides visibility.
        } else s->writable=false;
    }
    // Once a bank is committed its embedded legacy bytes are authoritative.
    // Never erase the only legacy fallback merely because a duplicate has a
    // later physical address in the inactive bank.
    if(s->have_active) {
        if(!p25_cs_read_slot(s,s->active_bank,1,b)) {s->writable=false;return false;}
        s->have_legacy=pref_unpack(b,&legacy);
        s->legacy_addr=s->have_legacy ? p25_cs_addr(s,s->active_bank,1) : 0;
    } else if(s->have_legacy)s->revision=latest;
    s->opened=true;
    return true;
}
static inline bool p25_cs_virtual(const p25_cs_store *s,unsigned key,uint8_t *out) {
    uint8_t b[64];p25_preferences p={0};
    bool legacy=s->have_legacy && s->flash->read(s->legacy_addr,b,64) && pref_unpack(b,&p);
    if(s->have_legacy && !legacy)return false;
    memset(out,0,32);
    if(key==P25_CS_GLOBAL) {
        pref_put(out,legacy ? p.id : 1u);out[4]=(uint8_t)(legacy ? p.mic_db : 11u);
        p25_cs_put16(out+5,60);p25_cs_put16(out+7,15);out[13]=(uint8_t)(legacy ? p.tx_inhibit : 0u);
    } else if(legacy && (key==P25_CS_VFO_A || key==P25_CS_VFO_B)) {
        pref_put(out,p.rx);pref_put(out+4,p.tx);p25_cs_put16(out+8,(uint16_t)p.nac);
        p25_cs_put16(out+10,(uint16_t)p.tg);out[12]=(uint8_t)(P25_CS_OCCUPIED|(p.prom_mode ? P25_CS_PROM : 0));
        memcpy(out+14,key==P25_CS_VFO_A ? "VFO A" : "VFO B",5);out[30]=5;
    }
    return true;
}
static inline bool p25_cs_read(const p25_cs_store *s,unsigned key,uint8_t *out) {
    if(!s->opened || !s->flash || key>=P25_CS_RECORDS || !pref_geometry(s->flash))return false;
    if(!s->have_active)return p25_cs_virtual(s,key,out);
    uint8_t b[64];
    if(s->active_slot[key]==P25_CS_NO_SLOT || !p25_cs_read_slot(s,s->active_bank,s->active_slot[key],b)
       || !p25_cs_data_slot(b) || b[5]!=key || b[4]!=s->active_version)return false;
    memcpy(out,b+8,32);return true;
}
static inline bool p25_cs_begin(p25_cs_store *s,uint32_t expected_revision) {
    if(!s->opened || !s->writable || s->staging || expected_revision!=s->revision)return false;
    unsigned bank=s->have_active ? s->active_bank^1u
        : s->have_legacy ? ((s->legacy_addr-s->flash->map->settings_addr)/P25_CS_BANK_BYTES)^1u : 0u;
    uint8_t legacy[64],check[64];memset(legacy,255,64);
    if(s->have_legacy && !s->flash->read(s->legacy_addr,legacy,64))return false;
    s->stage_bank=(uint8_t)bank;
    for(unsigned off=0;off<P25_CS_BANK_BYTES;off+=4096) {
        if(!s->flash->erase(p25_cs_addr(s,bank,0)+off)) {s->writable=false;return false;}
    }
    // Keep an exact legacy record for safe read-only fallback on old firmware.
    uint32_t addr=p25_cs_addr(s,bank,1);
    if((s->have_legacy && !s->flash->write(addr,legacy,64))
       || !s->flash->read(addr,check,64) || memcmp(legacy,check,64)) {s->writable=false;return false;}
    for(unsigned k=0;k<P25_CS_RECORDS;++k)s->stage_slot[k]=P25_CS_NO_SLOT;
    s->stage_next=2;s->staging=true;return true;
}
static inline bool p25_cs_stage_read(const p25_cs_store *s,unsigned key,uint8_t *out) {
    if(!s->staging || key>=P25_CS_RECORDS)return false;
    if(s->stage_slot[key]==P25_CS_NO_SLOT)return p25_cs_read(s,key,out);
    uint8_t b[64];
    if(!p25_cs_read_slot(s,s->stage_bank,s->stage_slot[key],b) || !p25_cs_data_slot(b) || b[5]!=key || b[4]!=P25_CS_VERSION)return false;
    memcpy(out,b+8,32);return true;
}
static inline bool p25_cs_stage_write(p25_cs_store *s,unsigned key,const uint8_t *record) {
    if(!s->staging || !s->writable || s->stage_next>=P25_CS_SLOTS || !p25_cs_record_valid(key,record))return false;
    uint8_t b[64];p25_cs_pack_slot(b,key,record);unsigned slot=s->stage_next++;
    if(!p25_cs_write_slot(s,slot,b))return false;
    s->stage_slot[key]=(uint16_t)slot;return true;
}
static inline bool p25_cs_stage_crc(const p25_cs_store *s,uint32_t *result) {
    // Before BEGIN this is the active (or virtual legacy/default) image CRC;
    // during a transaction it covers the staged view with active fallbacks.
    uint8_t record[32];uint32_t crc=~0u;
    for(unsigned k=0;k<P25_CS_RECORDS;++k) {
        bool ok=s->staging ? p25_cs_stage_read(s,k,record) : p25_cs_read(s,k,record);
        if(!ok || !p25_cs_record_valid(k,record))return false;
        crc=p25_cs_crc_add(crc,record,32);
    }
    *result=crc^~0u;return true;
}
static inline void p25_cs_abort(p25_cs_store *s) {s->staging=false;}
static inline bool p25_cs_commit(p25_cs_store *s,uint32_t expected_crc) {
    uint8_t b[64],record[32],global[32];uint32_t crc;
    if(!s->staging || !s->writable || !p25_cs_stage_crc(s,&crc) || crc!=expected_crc
       || !p25_cs_stage_read(s,P25_CS_GLOBAL,global))return false;
    // Both pane selections must remain meaningful, even when the other VFO is
    // not displayed. An empty own-VFO is allowed as an unconfigured radio.
    for(unsigned pane=0;pane<2;++pane)if(global[10+pane]) {
        if(!p25_cs_stage_read(s,global[10+pane]-1u,record) || !(record[12]&P25_CS_OCCUPIED))return false;
    }
    unsigned missing=0;
    for(unsigned k=0;k<P25_CS_RECORDS;++k)missing+=s->stage_slot[k]==P25_CS_NO_SLOT;
    if(s->stage_next+missing>P25_CS_SLOTS)return false;
    for(unsigned k=0;k<P25_CS_RECORDS;++k)if(s->stage_slot[k]==P25_CS_NO_SLOT) {
        if(!p25_cs_read(s,k,record) || !p25_cs_stage_write(s,k,record))return false;
    }
    // Re-read the staged records: acknowledge only bytes actually in flash.
    uint32_t confirmed;
    if(!p25_cs_stage_crc(s,&confirmed) || confirmed!=crc || !p25_cs_read_slot(s,s->stage_bank,1,b))return false;
    uint32_t bank_crc=p25_cs_crc_add(crc^~0u,b,64)^~0u;
    memset(record,0,32);p25_cs_pack_slot(b,255,record);
    pref_put(b+8,s->revision+1u);pref_put(b+12,crc);p25_cs_put16(b+16,P25_CS_RECORDS);
    p25_cs_put16(b+18,32);pref_put(b+20,bank_crc);pref_put(b+56,pref_crc(b,56));
    if(!p25_cs_write_slot(s,0,b))return false;
    s->active_bank=s->stage_bank;s->active_version=P25_CS_VERSION;s->revision++;s->have_active=true;s->staging=false;
    memcpy(s->active_slot,s->stage_slot,sizeof s->active_slot);
    if(s->have_legacy)s->legacy_addr=p25_cs_addr(s,s->active_bank,1);
    return true;
}
#endif
