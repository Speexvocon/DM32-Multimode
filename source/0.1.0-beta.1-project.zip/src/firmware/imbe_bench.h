// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef IMBE_BENCH_H
#define IMBE_BENCH_H
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#define IMBE_BENCH_FRAMES 300u
#define IMBE_BENCH_GROUP 100u
#ifdef __cplusplus
extern "C" {
#endif
bool imbe_bench_init(void);
bool imbe_bench_ready(void);
bool imbe_bench_release(void);
void imbe_bench_prepare(uint32_t frame);
void imbe_bench_encode(uint8_t payload[11]);
void imbe_bench_source(unsigned frame, int16_t *output);
void imbe_bench_encode_pcm(int16_t *input, uint8_t *payload);
void imbe_bench_decode_pcm(const uint8_t *payload,int16_t *output);
size_t imbe_bench_state_bytes(void);
#ifdef __cplusplus
}
#endif
#endif
