// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic timing and optional finite live microphone capture; RF disabled.
#include "imbe_bench.h"
#include "imbe_bench_expected.h"
#include "imbe_stream.h"
#include "board.h"
#include "platform.h"
#include "ui/gfx.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <string.h>

static bool running, display_ok;
static bool streaming;
#ifdef BENCH_MICROPHONE
#include "imbe_mic.h"
static bool microphone;
static unsigned mic_wait_display;
#endif
static imbe_stream_t stream;
static uint32_t frames, init_us, checksum=2166136261u;
static uint32_t maximum[3], total[3], misses[3], budget_misses[3];
static char command[32];
static size_t used;
static bool overflow;
#ifdef IMBE_STAGE_PROFILE
#include "imbe_profile.h"
static uint32_t stage_total[3][7], stage_max[3][7], stage_count[3][7], stage_start;
static const char *const stage_names[7]={"preprocess","pitch","window_fft","pitch_ref","voicing","spectral","frame_vector"};
void imbe_profile_mark(unsigned stage) {
    uint32_t now=hrc_micros();
    if (stage>0 && stage<=7 && frames<300) {
        unsigned group=frames/100, index=stage-1;
        uint32_t elapsed=now-stage_start;
        stage_total[group][index]+=elapsed;
        if (elapsed>stage_max[group][index]) stage_max[group][index]=elapsed;
        ++stage_count[group][index];
    }
    stage_start=now;
}
#endif
static void send(const char *s) {
    (void)board.host_port->write((const uint8_t *)s,strlen(s));
}
static void status(void) {
#ifdef BENCH_MICROPHONE
    if (microphone) { imbe_mic_status(); return; }
#endif
    char line[256];
    if (streaming) {
        (void)snprintf(line,sizeof line,
            "STREAM git=%s running=%u captured=%u encoded=%u consumed=%u pcm=%u high=%u overflow=%u underrun=%u done=%u match=%u rf=disabled\r\n",
            BENCH_GIT,(unsigned)running,stream.captured,stream.encoded,stream.consumed,
            stream.count,stream.high_water,stream.overflows,stream.underruns,(unsigned)stream.done,
            (unsigned)(stream.done && stream.speech_hash==IMBE_BENCH_EXPECTED && stream.encoded_hash==IMBE_STREAM_EXPECTED && stream.encoded_hash==stream.consumed_hash));
        send(line);
        (void)snprintf(line,sizeof line,
            "STREAM_TIMING startup_us=%lu max_latency_us=%lu stack_free_bytes=%lu speech_hash=%08lx encoded_hash=%08lx consumed_hash=%08lx\r\n",
            (unsigned long)stream.startup_us,(unsigned long)stream.max_latency_us,
            (unsigned long)(uxTaskGetStackHighWaterMark(NULL)*sizeof(StackType_t)),
            (unsigned long)stream.speech_hash,(unsigned long)stream.encoded_hash,(unsigned long)stream.consumed_hash);
        send(line); return;
    }
    (void)snprintf(line,sizeof line,
        "IMBE git=%s running=%u frames=%lu state_bytes=%lu init_us=%lu stack_free_bytes=%lu hash=%08lx match=%u rf=disabled\r\n",
        BENCH_GIT,(unsigned)running,(unsigned long)frames,(unsigned long)imbe_bench_state_bytes(),
        (unsigned long)init_us,(unsigned long)(uxTaskGetStackHighWaterMark(NULL)*sizeof(StackType_t)),
        (unsigned long)checksum,(unsigned)(frames==IMBE_BENCH_FRAMES && checksum==IMBE_BENCH_EXPECTED));
    send(line);
#ifdef BENCH_CLOCK_REGISTERS
    // Read-only diagnostics, outside the encode timer. Raw values allow checking
    // loader clock assumptions without changing PLL, dividers or cache state.
    (void)snprintf(line,sizeof line,
        "IMBE_CLOCK ctrl=%08lx pll=%08lx div=%08lx flash_div=%08lx quad=%08lx cache=%08lx assumed_cpu_hz=%lu assumed_apb_hz=%lu\r\n",
        (unsigned long)CLK_MGR_CTRL,(unsigned long)CLK_MGR_PLL,
        (unsigned long)CLK_MGR_DIV,(unsigned long)LCSFC_BAUDR,
        (unsigned long)QUAD_ENABLE,(unsigned long)REG32(CACHE_BASE),
        (unsigned long)HRC_CPU_HZ,(unsigned long)HRC_APB_HZ);
    send(line);
#endif
    for (unsigned group=0;group<3;++group) {
#ifdef IMBE_STAGE_PROFILE
        for (unsigned stage=0;stage<7;++stage) {
            uint32_t count=stage_count[group][stage];
            (void)snprintf(line,sizeof line,
                "IMBE_STAGE case=%u stage=%s frames=%lu mean_us=%lu max_us=%lu\r\n",
                group,stage_names[stage],(unsigned long)count,
                (unsigned long)(count ? stage_total[group][stage]/count : 0),
                (unsigned long)stage_max[group][stage]);
            send(line);
        }
#endif
        uint32_t n=frames>group*100u ? frames-group*100u : 0;
        if (n>100) n=100;
        (void)snprintf(line,sizeof line,
            "IMBE_CASE index=%u frames=%lu max_us=%lu mean_us=%lu over_15ms=%lu over_20ms=%lu\r\n",
            group,(unsigned long)n,(unsigned long)maximum[group],(unsigned long)(n ? total[group]/n : 0),
            (unsigned long)budget_misses[group],(unsigned long)misses[group]);
        send(line);
    }
}
static void screen(const char *title) {
    if (!display_ok) return;
    char line[48];
    gfx_frame_begin();
    gfx_clear(RGB565(8,16,28));
    gfx_text(&font_12x24,8,16,"IMBE / BENCH",RGB565(64,212,232));
    gfx_text(&font_8x16,8,58,title,RGB565(240,248,255));
    gfx_text(&font_8x16,8,88,"RF DISABLED",RGB565(96,224,152));
    gfx_text(&font_6x12,8,116,
#ifdef BENCH_MICROPHONE
        microphone ? "Live mic / 6 seconds + padding" :
#endif
        "Synthetic audio / no microphone",RGB565(152,176,196));
    (void)snprintf(line,sizeof line,"Frames: %lu / %u",(unsigned long)frames,streaming ? STREAM_FRAMES : 300u);
#ifdef BENCH_MICROPHONE
    if (microphone) (void)snprintf(line,sizeof line,"300 mic + 6 padding frames");
#endif
    gfx_text(&font_8x16,8,150,line,RGB565(240,248,255));
    gfx_text(&font_6x12,8,188,"Results on PC / RUN to repeat",RGB565(152,176,196));
    gfx_text(&font_6x12,8,218,"PTT has no function in this build",RGB565(152,176,196));
    gfx_text(&font_6x12,8,270,BENCH_GIT,RGB565(152,176,196));
    gfx_flush();
}
static void parse(void) {
    if (!strcmp(command,"STATUS")) { status(); return; }
    if (!strcmp(command,"STOP")) {
#ifdef BENCH_MICROPHONE
        if (microphone) imbe_mic_stop();
#endif
        running=false; stream.active=false; board_rf_safe(); send("OK STOP\r\n"); screen("STOPPED"); return;
    }
#ifdef BENCH_MICROPHONE
    if (!strcmp(command,"MIC_DUMP") && !running && microphone) { imbe_mic_dump(); return; }
    if ((!strcmp(command,"MIC") || !strcmp(command,"MIC_DMR") || !strcmp(command,"MIC_WAIT") || !strcmp(command,"MIC_PHY")) && !running) {
        microphone=true; streaming=false; frames=0;
        screen("LIVE MICROPHONE");
        bool phy=!strcmp(command,"MIC_PHY");
        bool delayed=phy || !strcmp(command,"MIC_WAIT");
        running=phy ? imbe_mic_start_phy_delayed() : delayed ? imbe_mic_start_delayed() : !strcmp(command,"MIC_DMR") ? imbe_mic_start_digital() : imbe_mic_start();
        mic_wait_display=delayed ? 21u : 0u;
        send(running ? (phy ? "OK MIC_PHY 20 seconds\r\n" : delayed ? "OK MIC_WAIT 20 seconds\r\n" : "OK MIC 300 live frames\r\n") : "ERR microphone start failed\r\n");
        return;
    }
#endif
    if ((!strcmp(command,"RUN") || !strcmp(command,"STREAM")) && !running) {
        streaming=!strcmp(command,"STREAM");
#ifdef BENCH_MICROPHONE
        microphone=false;
#endif
        frames=0; checksum=2166136261u;
        memset(maximum,0,sizeof maximum); memset(total,0,sizeof total);
        memset(misses,0,sizeof misses); memset(budget_misses,0,sizeof budget_misses);
#ifdef IMBE_STAGE_PROFILE
        memset(stage_total,0,sizeof stage_total); memset(stage_max,0,sizeof stage_max);
        memset(stage_count,0,sizeof stage_count);
#endif
        uint32_t start=hrc_micros(); imbe_bench_init(); init_us=hrc_micros()-start;
        running=true; screen(streaming ? "BUFFERED STREAM" : "ENCODING");
        send(streaming ? "OK STREAM 3006 synthetic frames\r\n" : "OK RUN 300 synthetic frames\r\n");
        if (streaming) stream_init(&stream,hrc_micros());
        return;
    }
    send("ERR use STATUS, RUN/STREAM while idle, or STOP; RF disabled\r\n");
}
static void commands(void) {
    uint8_t bytes[32];
    size_t count=board.host_port->read(bytes,sizeof bytes);
    for (size_t i=0;i<count;++i) {
        uint8_t c=bytes[i];
        if (c=='\r' || c=='\n') {
            if (overflow) send("ERR command too long\r\n");
            else if (used) { command[used]=0; parse(); }
            used=0; overflow=false;
        } else if (c>=32 && c<127 && !overflow) {
            if (used+1<sizeof command) command[used++]=(char)c; else overflow=true;
        }
    }
}
static void benchmark_task(void *arg) {
    (void)arg;
    board_rf_safe(); board_init(); board_rf_safe();
    board.display->init(); display_ok=gfx_init(board.display);
    board.display->set_backlight(80);
    if (board.host_port==NULL || !board.host_port->start()) {
        board_rf_safe(); screen("HOST PORT FAILED"); vTaskDelete(NULL); return;
    }
    screen("READY / PC RUN");
    uint32_t next_report=0;
    for (;;) {
        board_rf_safe();
        if (!board.power->switch_on()) {
#ifdef BENCH_MICROPHONE
            if (microphone) imbe_mic_stop();
#endif
            board.power->latch(false); vTaskDelay(pdMS_TO_TICKS(10)); continue;
        }
        commands();
#ifdef BENCH_MICROPHONE
        if (running && microphone) {
            unsigned seconds=imbe_mic_wait_seconds();
            if (seconds!=mic_wait_display) {
                char title[32];
                mic_wait_display=seconds;
                if (seconds) (void)snprintf(title,sizeof title,"UNPLUG / START IN %uS",seconds);
                else (void)snprintf(title,sizeof title,"RECORDING / SPEAK NOW");
                screen(title);
            }
            running=imbe_mic_poll();
            if (!running) { status(); screen("MIC STOPPED / PC RESULTS"); }
        } else
#endif
        if (running && streaming) {
            stream_advance(&stream,hrc_micros(),imbe_bench_source);
            if (stream_can_encode(&stream)) {
                int16_t input[160]; uint8_t payload[11];
                stream_pop(&stream,input);
                imbe_bench_encode_pcm(input,payload);
                uint32_t completion=hrc_micros();
                stream_advance(&stream,completion,imbe_bench_source);
                stream_commit(&stream,payload,completion);
                frames=stream.encoded;
            }
            if (!stream.active) {
                running=false; status();
                screen(stream.done ? "STREAM DRAINED" : "QUEUE FAILURE");
            }
        } else if (running) {
            uint8_t payload[11];
            imbe_bench_prepare(frames);
            // Leave interrupts enabled. Serial, display, stimulus and hashing
            // are outside the measurement; RTOS/ISR preemption is included.
            uint32_t start=hrc_micros();
            imbe_bench_encode(payload);
            uint32_t elapsed=hrc_micros()-start, group=frames/100u;
            total[group]+=elapsed;
            if (elapsed>maximum[group]) maximum[group]=elapsed;
            if (elapsed>15000u) ++budget_misses[group];
            if (elapsed>20000u) ++misses[group];
            for (unsigned i=0;i<11;++i) checksum=(checksum^payload[i])*16777619u;
            ++frames;
            if (frames==IMBE_BENCH_FRAMES) {
                running=false; status(); screen(checksum==IMBE_BENCH_EXPECTED ? "DONE / DATA MATCH" : "DATA MISMATCH");
            }
        }
        uint32_t now=hrc_micros();
        if ((int32_t)(now-next_report)>=0) { status(); next_report=now+1000000u; }
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}
void __wrap_app_start(void) {
    if (xTaskCreate(benchmark_task,"imbebench",4096,NULL,5,NULL)!=pdPASS) {
        board_rf_safe(); for (;;) {}
    }
}
