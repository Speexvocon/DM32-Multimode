// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef IMBE_MIC_H
#define IMBE_MIC_H
#include <stdbool.h>
bool imbe_mic_start(void);
bool imbe_mic_start_digital(void);
bool imbe_mic_start_delayed(void);
bool imbe_mic_start_phy_delayed(void);
unsigned imbe_mic_wait_seconds(void);
bool imbe_mic_poll(void);
void imbe_mic_stop(void);
void imbe_mic_status(void);
void imbe_mic_dump(void);
#endif
