# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (c) 2026 DM32 P25 research contributors
# Invoke from an unchanged RadioFoundry checkout using -f /path/to/this/file.
ifndef PROJECT_ROOT
$(error PROJECT_ROOT must name the DM32 P25 research checkout)
endif
include Makefile
CONFIG_P25_TEST_TX ?= 1
ifeq ($(CONFIG_P25_TEST_TX),1)
ifneq ($(BOARD),dm32)
$(error The diagnostic adapter has only been prepared for BOARD=dm32)
endif
ifeq ($(CONFIG_DMR),n)
$(error The board's DMR RF setup is required, CONFIG_DMR must be y)
endif
DIAG_NAMES := dm32_p25_diag p25_test_tx
DIAG_OBJ := $(addprefix $(BUILD)/p25-diag/,$(addsuffix .o,$(DIAG_NAMES)))
OBJ += $(DIAG_OBJ)
LDFLAGS += -Wl,--wrap=app_start -Wl,--wrap=hrc_dmr_board_init -Wl,--wrap=hrc_dmr_enter -Wl,--wrap=hrc_dmr_leave
$(TARGET).elf: $(DIAG_OBJ)
$(BUILD)/p25-diag/%.o: $(PROJECT_ROOT)/src/firmware/%.c $(PROJECT_ROOT)/src/firmware/p25_test_tx.h $(PROJECT_ROOT)/src/firmware/p25_diag_ui.h $(PROJECT_ROOT)/fixtures/p25-1011/p25_test_vectors.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -DCONFIG_P25_TEST_TX=1 -DP25_PROJECT_GIT=\"$(shell git -C $(PROJECT_ROOT) rev-parse --short HEAD)\" -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@
endif
