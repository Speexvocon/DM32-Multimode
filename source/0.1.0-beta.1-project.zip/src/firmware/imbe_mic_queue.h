// SPDX-License-Identifier: GPL-3.0-or-later
// Caller serializes producer/consumer with the platform IRQ lock.
#ifndef IMBE_MIC_QUEUE_H
#define IMBE_MIC_QUEUE_H
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#ifndef MIC_FRAMES
#define MIC_FRAMES 300u
#endif
#define MIC_PAD 6u
#define MIC_CAP 8u
typedef struct {
    int16_t pcm[MIC_CAP][160];
    unsigned head, count, captured, high, overflow, peak, clipped;
    uint64_t sum_abs;
    uint32_t first_us, last_us;
    bool accepting;
} imbe_mic_queue;
static inline void mic_queue_push(imbe_mic_queue *q,const int16_t *pcm,uint32_t now) {
    if (!q->accepting) return;
    if (q->count==MIC_CAP) { ++q->overflow; q->accepting=false; return; }
    memcpy(q->pcm[(q->head+q->count)%MIC_CAP],pcm,320);
    uint32_t block_abs=0;
    for (unsigned i=0;i<160;++i) {
        unsigned a=pcm[i]<0 ? (unsigned)(-(int32_t)pcm[i]) : (unsigned)pcm[i];
        if (a>q->peak) q->peak=a;
        block_abs+=a;
        if (a>=32767u) ++q->clipped;
    }
    q->sum_abs+=block_abs;
    if (!q->captured) q->first_us=now;
    q->last_us=now;
    ++q->captured; ++q->count;
    if (q->count>q->high) q->high=q->count;
    if (q->captured==MIC_FRAMES) q->accepting=false;
}
static inline bool mic_queue_pop(imbe_mic_queue *q,int16_t *pcm) {
    if (!q->count) return false;
    memcpy(pcm,q->pcm[q->head],320);
    q->head=(q->head+1)%MIC_CAP; --q->count; return true;
}
#endif
