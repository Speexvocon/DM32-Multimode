// SPDX-License-Identifier: GPL-3.0-or-later
// Small task-context policies. One RF owner; no I/O, allocation or radio grants.
#ifndef RADIO_UX_H
#define RADIO_UX_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
typedef struct {
    uint32_t activity_us,screen_activity_us,combo_since;
    uint16_t screen_seconds,keypad_seconds;
    bool locked,screen_on,keypad_on,combo_seen,combo_fired,consume_release;
} radio_ux;
static inline void radio_ux_init(radio_ux *u,uint32_t now) {
    memset(u,0,sizeof *u);u->activity_us=u->screen_activity_us=now;u->screen_seconds=60;u->keypad_seconds=15;
    u->screen_on=u->keypad_on=true;
}
// Return true only for a fresh wake that should consume an ordinary key press.
// Physical PTT is handled separately and never gated by the keypad lock.
static inline bool radio_ux_activity(radio_ux *u,uint32_t now,bool key_press) {
    bool wake=!u->screen_on;u->activity_us=u->screen_activity_us=now;u->screen_on=u->keypad_on=true;
    if(wake && key_press)u->consume_release=true;
    return wake;
}
// Task-context notification of valid reception (protocol sync/call or open FM
// squelch), never raw RSSI alone. Keep calling while reception remains active.
// Receiving wakes/holds the screen without lighting the keys, unlocking them,
// or consuming the next key press. Its timeout restarts after the last activity.
static inline bool radio_ux_rx_activity(radio_ux *u,uint32_t now) {
    bool wake=!u->screen_on;u->screen_activity_us=now;u->screen_on=true;
    return wake;
}
static inline void radio_ux_idle(radio_ux *u,uint32_t now,bool busy) {
    if(busy) {radio_ux_activity(u,now,false);return;}
    uint32_t idle=now-u->activity_us;
    uint32_t screen_idle=now-u->screen_activity_us;
    // Configured seconds <=600, safely inside the unsigned microsecond window.
    u->screen_on=!u->screen_seconds || screen_idle<(uint32_t)u->screen_seconds*1000000u;
    u->keypad_on=!u->keypad_seconds || idle<(uint32_t)u->keypad_seconds*1000000u;
}
// Deliberate 1-second OK+* chord. Exactly one toggle per complete release.
static inline bool radio_ux_lock_chord(radio_ux *u,uint32_t now,bool chord,bool any_key,bool allowed) {
    if(chord && allowed) {
        if(!u->combo_seen) {u->combo_seen=true;u->combo_since=now;}
        if(!u->combo_fired && now-u->combo_since>=1000000u) {
            u->locked=!u->locked;u->combo_fired=true;u->consume_release=true;
            radio_ux_activity(u,now,false);return true;
        }
    } else if(!any_key) {u->combo_seen=u->combo_fired=u->consume_release=false;}
    else if(!chord)u->combo_seen=false;
    return false;
}
typedef struct {uint32_t due_us,last_signal_us;uint8_t cursor,list;bool running,holding;} radio_scan;
static inline void radio_scan_start(radio_scan *s,uint32_t now,uint8_t cursor,uint8_t list) {
    *s=(radio_scan){.due_us=now+1000000u,.cursor=cursor,.list=list,.running=true};
}
static inline bool radio_scan_due(radio_scan *s,uint32_t now,bool signal) {
    if(!s->running)return false;
    if(signal) {s->last_signal_us=now;s->holding=true;s->due_us=now+2000000u;return false;}
    if((int32_t)(now-s->due_us)<0)return false;
    s->holding=false;s->due_us=now+1000000u;return true;
}
#endif
