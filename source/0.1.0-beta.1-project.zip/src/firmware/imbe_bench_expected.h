// SPDX-License-Identifier: GPL-3.0-or-later
// FNV-1a over 300 x 11 bytes, independently checked via host public codec API.
#pragma once
#define IMBE_BENCH_EXPECTED 0xa445cfc2u
// Continuous 3000-frame cycling stimulus + six zero-PCM padding frames.
// All 33066 bytes compared with a separately compiled untouched encoder.
#define IMBE_STREAM_EXPECTED 0x654ebfbfu
