// SPDX-License-Identifier: GPL-3.0-or-later
// Conventional FM ownership adapter for the pinned board HAL. Task context only.
#ifndef P25_FM_H
#define P25_FM_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "hal_radio.h"
#include "hal_audio.h"

#define P25_FM_STATUS_US 25000u
#define P25_FM_TX_MAX_US 30000000u

typedef struct {
    uint32_t rx_hz,tx_hz;
    radio_bw_t bandwidth;
    subtone_t rx_tone,tx_tone;
    uint8_t squelch,volume,power;
} p25_fm_config;
typedef struct {
    const hal_radio_t *radio;
    const hal_audio_t *audio;
    p25_fm_config config;
    radio_status_t status;
    uint32_t status_due_us,tx_started_us;
    uint8_t close_count,tone_count;
    bool owned,running,transmitting,audio_open,tone_ok,carrier,have_status;
    bool timed_out,failed;
} p25_fm;

static inline bool p25_fm_tone_valid(subtone_t t) {
    return t.type==TONE_NONE || (t.type==TONE_CTCSS && t.value>=600u && t.value<=2600u)
        || ((t.type==TONE_DCS || t.type==TONE_DCS_INV) && t.value<=0777u);
}
static inline bool p25_fm_config_valid(const p25_fm_config *c) {
    return c && c->rx_hz && c->tx_hz
        && (c->bandwidth==RADIO_BW_12K5 || c->bandwidth==RADIO_BW_25K)
        && c->squelch<=9u && c->volume<=100u
        && p25_fm_tone_valid(c->rx_tone) && p25_fm_tone_valid(c->tx_tone);
}
static inline void p25_fm_audio(p25_fm *f,bool on) {
    if(f->audio_open!=on) {f->radio->audio(on);f->audio_open=on;}
}
// Before handing the HAL to P25, unkey and remove BOTH analog and PCM sources.
// An unowned/idempotent stop must not touch another backend's radio hardware.
static inline void p25_fm_stop(p25_fm *f) {
    if(!f || !f->owned)return;
    f->radio->audio(false);f->audio_open=false;
    f->radio->tx_off();
    f->audio->stop();f->audio->speaker_pcm(false);
    f->owned=f->running=f->transmitting=f->have_status=f->carrier=false;
    f->close_count=f->tone_count=0;
}
// Caller stops the P25 recorder/codec/speaker IRQs before this ownership handoff.
// HAL rx/tx enforce board bands; caller additionally validates its advertised
// bands, calibration, power index and owner permission. No RF is keyed here.
static inline bool p25_fm_start(p25_fm *f,const hal_radio_t *radio,const hal_audio_t *audio,
                               const p25_fm_config *config,uint32_t now_us) {
    if(!f || f->owned || !p25_fm_config_valid(config) || !radio || !audio
       || !radio->set_mode || !radio->rx || !radio->tx || !radio->tx_off
       || !radio->audio || !radio->status || !audio->stop || !audio->speaker_pcm)return false;
    p25_fm_config next=*config; // Also permit restarting with &f->config after stop.
    memset(f,0,sizeof *f);f->radio=radio;f->audio=audio;f->config=next;f->owned=true;
    radio->audio(false);audio->stop();audio->speaker_pcm(false);
    radio->tx_off();radio->set_mode(RADIO_MODE_FM);
    if(!radio->rx(next.rx_hz,next.bandwidth,&next.rx_tone)) {
        p25_fm_stop(f);f->failed=true;return false;
    }
    if(radio->volume)radio->volume(next.volume); // DM32 uses its physical knob.
    f->running=true;f->tone_ok=next.rx_tone.type==TONE_NONE;f->status_due_us=now_us;
    return true;
}
// ONLY call after a newly qualified physical PTT AND arming the independent RF
// cutoff. HAL tx() keys FM immediately. Boot-held PTT, owner/calibration/battery
// checks and release after timeout remain the unified controller's responsibility.
// DM32's HAL has no relative mic-gain hook: caller restores its verified native
// FM gain (11dB) before tx_begin, rather than reusing the P25 encoder gain.
static inline bool p25_fm_tx_begin(p25_fm *f,uint32_t now_us) {
    if(!f || !f->owned || !f->running || f->transmitting)return false;
    f->radio->audio(false);f->audio_open=false;f->have_status=f->carrier=false;
    f->close_count=f->tone_count=0;f->tone_ok=f->config.rx_tone.type==TONE_NONE;
    if(!f->radio->tx(f->config.tx_hz,f->config.bandwidth,f->config.power,&f->config.tx_tone)) {
        p25_fm_stop(f);f->failed=true;return false;
    }
    f->transmitting=true;f->tx_started_us=now_us;f->timed_out=false;return true;
}
static inline void p25_fm_tx_end(p25_fm *f,uint32_t now_us) {
    if(!f || !f->owned || !f->transmitting)return;
    f->radio->audio(false);f->audio_open=false;
    f->radio->tx_off(); // HAL contract restores the last RX frequency/tone/width.
    f->transmitting=false;f->have_status=f->carrier=false;
    f->close_count=f->tone_count=0;f->tone_ok=f->config.rx_tone.type==TONE_NONE;
    f->status_due_us=now_us;
}
static inline void p25_fm_poll(p25_fm *f,uint32_t now_us) {
    if(!f || !f->owned || !f->running)return;
    if(f->transmitting) {
        if(now_us-f->tx_started_us>=P25_FM_TX_MAX_US) {
            p25_fm_tx_end(f,now_us);f->timed_out=true;
        }
        return; // Never read the RF bus or open RX audio during a transmission.
    }
    if((int32_t)(now_us-f->status_due_us)<0)return;
    f->status_due_us=now_us+P25_FM_STATUS_US;
    f->radio->status(&f->status);f->have_status=true;
    // Match pinned radio_sm: 2 matching polls to accept a tone, 8 missing to
    // revoke; then 2 noisy polls to close, with 3dB noise hysteresis. DM32's
    // status.carrier is always false, so use its documented noise reading.
    bool tone=f->config.rx_tone.type==TONE_NONE || f->status.tone_ok;
    if(tone==f->tone_ok)f->tone_count=0;
    else if(++f->tone_count>=(tone ? 2u : 8u)) {f->tone_ok=tone;f->tone_count=0;}
    unsigned threshold=f->config.squelch ? 64u-(f->config.squelch-1u)*3u : 255u;
    f->carrier=!f->config.squelch || f->status.noise<threshold;
    bool opens=f->tone_ok && f->carrier;
    bool holds=f->tone_ok && (!f->config.squelch || f->status.noise<threshold+3u);
    if(!f->audio_open) {if(opens) {f->close_count=0;p25_fm_audio(f,true);}}
    else if(holds)f->close_count=0;
    else if(++f->close_count>=2u) {f->close_count=0;p25_fm_audio(f,false);}
}
// Scope: direct analog mic/speaker FM, narrow/wide, RX/TX CTCSS/DCS, low-level
// volume where supported. No PCM, heap, VOX, APRS, DTMF, burst/roger or DCS
// turn-off-tail scheduling. Immediate unkey is intentional; no claim of tested
// FM deviation, sensitivity, tones or audio on this custom firmware is made.
#endif
