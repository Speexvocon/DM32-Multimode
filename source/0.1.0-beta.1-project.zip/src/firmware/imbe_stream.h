// SPDX-License-Identifier: GPL-3.0-or-later
// No-RF paced queue model. LDU banks hold nine uncoded IMBE payloads, not RF bits.
#ifndef IMBE_STREAM_H
#define IMBE_STREAM_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#define STREAM_PCM_CAP 8u
#define STREAM_SPEECH_FRAMES 3000u
#define STREAM_FRAMES 3006u
#ifndef STREAM_RESERVE_US
#define STREAM_RESERVE_US 40000u
#endif
typedef struct {
    int16_t pcm[STREAM_PCM_CAP][160];
    uint8_t ldu[2][9][11];
    unsigned fill[2], read_bank, write_bank, voice_index;
    unsigned head, count, high_water, captured, encoded, consumed;
    unsigned overflows, underruns;
    uint32_t start, arrival, departure, startup_us, max_latency_us;
    uint32_t encoded_hash, consumed_hash, speech_hash;
    bool active, started, done, failed;
} imbe_stream_t;
typedef void (*stream_source_fn)(unsigned, int16_t *);
static inline uint32_t stream_hash(uint32_t hash,const uint8_t *p) {
    for (unsigned i=0;i<11;++i) hash=(hash^p[i])*16777619u;
    return hash;
}
static inline void stream_init(imbe_stream_t *s,uint32_t now) {
    memset(s,0,sizeof *s);
    s->start=now; s->arrival=now+20000u; s->active=true;
    s->encoded_hash=s->consumed_hash=s->speech_hash=2166136261u;
}
// Process arrivals/departures at their ORIGINAL deadlines, including events
// during a blocking encode. Never postpone the sink to hide an underrun.
static inline void stream_advance(imbe_stream_t *s,uint32_t now,stream_source_fn source) {
    while (s->active) {
        bool input=s->captured<STREAM_FRAMES && (int32_t)(now-s->arrival)>=0;
        bool output=s->started && (int32_t)(now-s->departure)>=0;
        if (!input && !output) break;
        if (input && (!output || (int32_t)(s->arrival-s->departure)<=0)) {
            if (s->count==STREAM_PCM_CAP) {
                ++s->overflows; s->failed=true; s->active=false; break;
            }
            int16_t *pcm=s->pcm[(s->head+s->count)%STREAM_PCM_CAP];
            if (s->captured<STREAM_SPEECH_FRAMES) source(s->captured,pcm);
            else memset(pcm,0,320); // Finish the last LDU pair through the codec.
            ++s->captured; ++s->count;
            if (s->count>s->high_water) s->high_water=s->count;
            s->arrival+=20000u;
        } else {
            if (s->fill[s->read_bank]!=9) {
                ++s->underruns; s->failed=true; s->active=false; break;
            }
            s->consumed_hash=stream_hash(s->consumed_hash,s->ldu[s->read_bank][s->voice_index]);
            uint32_t latency=s->departure-(s->start+(s->consumed+1u)*20000u);
            if (latency>s->max_latency_us) s->max_latency_us=latency;
            ++s->consumed;
            if (++s->voice_index==9) {
                s->fill[s->read_bank]=0; s->read_bank^=1u; s->voice_index=0;
            }
            s->departure+=20000u;
            if (s->consumed==STREAM_FRAMES) { s->done=true; s->active=false; }
        }
    }
}
static inline bool stream_can_encode(const imbe_stream_t *s) {
    return s->active && s->count && s->fill[s->write_bank]<9;
}
static inline void stream_pop(imbe_stream_t *s,int16_t *pcm) {
    memcpy(pcm,s->pcm[s->head],320);
    s->head=(s->head+1)%STREAM_PCM_CAP; --s->count;
}
// Call advance(completion_time) BEFORE commit: a late result is not available
// to satisfy an earlier departure. Abort-on-error rather than dropping audio.
static inline void stream_commit(imbe_stream_t *s,const uint8_t *payload,uint32_t now) {
    if (!s->active) return;
    memcpy(s->ldu[s->write_bank][s->fill[s->write_bank]++],payload,11);
    s->encoded_hash=stream_hash(s->encoded_hash,payload);
    if (s->encoded<300) s->speech_hash=stream_hash(s->speech_hash,payload);
    ++s->encoded;
    if (s->fill[s->write_bank]==9) {
        s->write_bank^=1u;
        if (!s->started) {
            s->started=true; s->startup_us=now-s->start+STREAM_RESERVE_US;
            s->departure=now+STREAM_RESERVE_US+20000u;
        }
    }
}
#endif
