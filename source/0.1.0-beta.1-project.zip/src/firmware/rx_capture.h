// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded raw FM RX evidence; no demodulation or assumed P25 sample quality.
#ifndef RX_CAPTURE_H
#define RX_CAPTURE_H
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#define RXCAP_BLOCKS 144u
#define RXCAP_TIMEOUT_US 6000000u
#define RXCAP_BYTES 512u
typedef struct {
    uint8_t data[RXCAP_BLOCKS][RXCAP_BYTES];
    uint32_t times[RXCAP_BLOCKS];
    uint8_t halves[RXCAP_BLOCKS];
    volatile uint32_t count, invalid, repeats, gaps, maxgap, last_us;
    volatile bool accepting;
} rx_capture;
static inline void rxcap_reset(rx_capture *c) { memset(c,0,sizeof *c); c->accepting=true; }
static inline void rxcap_push(rx_capture *c,volatile const uint8_t *ram,unsigned half,uint32_t now) {
    if(!c->accepting) return;
    if(half!=1 && half!=2) { ++c->invalid;return; }
    if(c->count) {
        uint32_t gap=now-c->last_us;
        if(gap>c->maxgap)c->maxgap=gap;
        if(gap>48000u)++c->gaps;
        if(half==c->halves[c->count-1])++c->repeats;
    }
    unsigned n=c->count;
    for(unsigned i=0;i<RXCAP_BYTES;++i)c->data[n][i]=ram[(half-1)*RXCAP_BYTES+i];
    c->times[n]=now;c->halves[n]=(uint8_t)half;c->last_us=now;c->count=n+1;
    if(c->count==RXCAP_BLOCKS)c->accepting=false;
}
#endif
