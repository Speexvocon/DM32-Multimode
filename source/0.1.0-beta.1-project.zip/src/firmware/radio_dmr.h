// SPDX-License-Identifier: GPL-3.0-or-later
// Project-owned DMR backend for the common radio controller. One task owns it.
#ifndef RADIO_DMR_H
#define RADIO_DMR_H
#include <stdbool.h>
#include <stdint.h>
#include "hal_radio.h"
#include "hal_audio.h"
#include "hal_vocoder.h"
#include "dmr/call/dmr_call.h"
#include "radio_dmr_metrics.h"

typedef enum {
    RADIO_DMR_FILTER_TARGET, // own CC/TS and destination policy
    RADIO_DMR_FILTER_SLOT,   // own CC/TS, all destinations
    RADIO_DMR_FILTER_PROM    // any CC/destination, selected TS
} radio_dmr_filter;

typedef enum {
    RADIO_DMR_OK, RADIO_DMR_BAD_CONFIG, RADIO_DMR_NO_HAL,
    RADIO_DMR_NO_CODEC, RADIO_DMR_BUSY, RADIO_DMR_NO_OWNERSHIP,
    RADIO_DMR_RX_FAILED, RADIO_DMR_MODEM_FAILED, RADIO_DMR_TX_REFUSED
} radio_dmr_error;

typedef enum {
    RADIO_DMR_TX_NONE, RADIO_DMR_TX_ACTIVE, RADIO_DMR_TX_COMPLETE,
    RADIO_DMR_TX_FAILED, RADIO_DMR_TX_ABORTED, RADIO_DMR_TX_CANCELLED
} radio_dmr_tx_result;

// Cached per-PTT diagnostics. Only init or a fresh eligible PTT clears the result;
// completion captures counters once, so reading STATUS does not copy native
// statistics in the audio/IRQ path. ACTIVE has no final metrics yet. AMBE totals
// are cumulative across native initializations; the counters here are unsigned
// deltas from this attempt's baseline. Mic summaries describe its latest audio
// blocks (zero if no blocks were delivered), not a cumulative microphone level.
typedef struct {
    uint32_t start_ms, end_ms;
    uint32_t calls, denied, encoded_frames, encoded_repeats, encoded_overflows;
    uint32_t source_underruns, event_overflows;
    // Poll timing covers the accepted PTT's first poll through its finishing
    // poll (including access, drain and board unkey), without idle/RX gaps.
    // Optional HAL callbacks govern availability; zero is not a measurement
    // when the corresponding valid flag is false.
    radio_dmr_cost_t poll_cost;
    uint32_t poll_gap_max_us;
    uint32_t native_tx_bursts, native_tx_underruns, native_tx_rejected, native_tx_done;
    uint32_t native_event_overflows;
    uint32_t mic_peak, mic_blocks, mic_level_db, mic_spread_db, mic_zc;
    radio_dmr_tx_result result;
    radio_dmr_error backend_error;
    uint8_t tx_error, phase, last_tx_phase;
    bool metrics_valid, poll_timing_valid, native_metrics_valid;
} radio_dmr_diagnostics;

typedef struct {
    uint32_t rx_hz, tx_hz, source_id, target_id;
    uint16_t tot_s;
    uint8_t cc, ts, power;
    radio_dmr_filter filter;
    bool private_call, rmo, rx_only, owner_permission;
} radio_dmr_config;

typedef struct {
    const hal_radio_t *radio;
    const hal_dmr_modem_t *modem;
    const hal_audio_t *audio;
    const hal_vocoder_t *vocoder;
    // acquire: stop/quiesce the previous mode and install native DMR IRQs.
    // release: native engine is already halted in FM; hand IRQs back safely.
    // No register/IRQ owner may be changed behind a running backend. On failure
    // acquire may set this backend's error to a more specific platform reason.
    bool (*acquire)(void *ctx);
    void (*release)(void *ctx);
    void *ctx;
    // Optional nonblocking task-context diagnostics. clock_us is a wrapping
    // microsecond clock; tx_diag copies native counters without clearing them.
    // Existing platforms may leave either callback NULL.
    uint32_t (*clock_us)(void *ctx);
    void (*tx_diag)(radio_dmr_native_tx_diag_t *out, void *ctx);
} radio_dmr_hal;

typedef struct {
    radio_dmr_hal hal;
    radio_dmr_config config;
    radio_dmr_error error;
    // Native call outcome is separate from ownership/start/board errors and is
    // retained across PTT release, subsequent RX and stop()/start() handoffs.
    uint8_t tx_error;
    radio_dmr_diagnostics diagnostics;
    uint32_t diag_frames_base, diag_repeats_base, diag_overflows_base;
    uint32_t diag_calls_base, diag_denied_base, diag_underruns_base, diag_events_base;
    radio_dmr_native_tx_diag_t diag_native_base;
    uint32_t diag_poll_last_us;
    bool diag_poll_seen;
    uint32_t last_poll_ms;
    bool owned, running, tx_armed, ptt_last, release_required;
} radio_dmr;

// The upstream call/audio engines are singletons: at most one instance runs.
void radio_dmr_init(radio_dmr *dmr, const radio_dmr_hal *hal);
bool radio_dmr_config_valid(const radio_dmr_config *config);
bool radio_dmr_start(radio_dmr *dmr, const radio_dmr_config *config);
void radio_dmr_stop(radio_dmr *dmr);
// Call at least every 10 ms. PTT must be released after start/inhibition/TOT;
// ptt_allowed also carries the common controller's boot/release/menu policy.
// Permission withdrawal drains the normal terminator; stop() aborts immediately.
void radio_dmr_poll(radio_dmr *dmr, uint32_t now_ms, bool ptt_down, bool ptt_allowed);
const dmr_call_view_t *radio_dmr_view(const radio_dmr *dmr);
// Same owner task as poll(); retained data remains available after stop().
bool radio_dmr_get_diagnostics(const radio_dmr *dmr, radio_dmr_diagnostics *out);
bool radio_dmr_scan_hold(const dmr_call_view_t *view);
const char *radio_dmr_error_name(radio_dmr_error error);
const char *radio_dmr_tx_error_name(uint8_t error);
const char *radio_dmr_tx_result_name(radio_dmr_tx_result result);
#endif
