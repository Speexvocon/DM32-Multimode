// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_receive_bench.h"
#include "p25_demod.h"
#include <string.h>
typedef struct {
    p25_receive_result *result;
    uint32_t (*clock_us)(void);
    void (*decode)(const uint8_t *,int16_t *);
    uint16_t nac;
} bench_context;
static void receive(const p25_rx *frame,void *context) {
    bench_context *c=context;p25_receive_result *r=c->result;
    ++r->units;
    if(frame->nac!=c->nac || (frame->duid!=5 && frame->duid!=10))return;
    for(unsigned i=0;i<9;++i) {
        uint8_t payload[11];int16_t pcm[160];unsigned errors;
        if(!p25_rx_voice(frame->frame,i,payload,&errors))return;
        uint32_t start=c->clock_us();c->decode(payload,pcm);
        uint32_t elapsed=c->clock_us()-start;r->decode_us+=elapsed;
        if(elapsed>r->max_decode_us)r->max_decode_us=elapsed;
        ++r->voices;r->corrected+=errors;
        for(unsigned j=0;j<160;++j) {
            uint16_t x=(uint16_t)pcm[j];
            r->pcm_hash=(r->pcm_hash^(x&255))*16777619u;
            r->pcm_hash=(r->pcm_hash^(x>>8))*16777619u;
        }
    }
}
void p25_receive_bench_profile(const uint8_t *be16,size_t samples,uint16_t nac,
    uint32_t (*clock_us)(void),void (*decode)(const uint8_t *,int16_t *),
    void (*yield_block)(void),p25_receive_result *r,int profile) {
    p25_demod demod;p25_demod_init(&demod);memset(r,0,sizeof *r);
    if(profile)demod.clock_us=clock_us;
    r->pcm_hash=2166136261u;r->state_bytes=sizeof demod;
    bench_context context={r,clock_us,decode,nac};
    uint32_t start=clock_us(),block=start;
    for(size_t i=0;i<samples+32;++i) {
        int16_t value=i<samples ? (int16_t)((unsigned)be16[2*i]*256+be16[2*i+1]) : 0;
        p25_demod_push(&demod,value,receive,&context);
        if((i+1)%256==0 || i==samples+31) {
            uint32_t now=clock_us(),elapsed=now-block;
            r->active_us+=elapsed;
            if(elapsed>r->max_block_us)r->max_block_us=elapsed;
            if(yield_block)yield_block();
            block=clock_us();
        }
    }
    r->elapsed_us=clock_us()-start;
    r->fir_us=demod.fir_us;r->sync_us=demod.sync_us;r->fec_us=demod.fec_us;
    r->symbol_us=demod.symbol_us;r->sync_tests=demod.sync_tests;
    r->fec_candidates=demod.fec_candidates;r->fec_skipped=demod.fec_skipped;
}

void p25_receive_bench(const uint8_t *be16,size_t samples,uint16_t nac,
    uint32_t (*clock_us)(void),void (*decode)(const uint8_t *,int16_t *),
    void (*yield_block)(void),p25_receive_result *r) {
    p25_receive_bench_profile(be16,samples,nac,clock_us,decode,yield_block,r,0);
}
