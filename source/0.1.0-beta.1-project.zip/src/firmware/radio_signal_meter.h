// SPDX-License-Identifier: GPL-3.0-or-later
// RF strength only: sync, accepted calls and audio are separate indications.
#ifndef RADIO_SIGNAL_METER_H
#define RADIO_SIGNAL_METER_H

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

typedef enum {
    RADIO_SIGNAL_OFF, RADIO_SIGNAL_P25, RADIO_SIGNAL_FM, RADIO_SIGNAL_DMR
} radio_signal_mode;

#define RADIO_SIGNAL_DMR_PERIOD_US 25000u
#define RADIO_SIGNAL_DMR_HOLD_US 120000u
#define RADIO_SIGNAL_PERIOD_US 250000u
#define RADIO_SIGNAL_STALE_US 1500000u
#define RADIO_SIGNAL_SAMPLES 5u

typedef struct {
    uint32_t hz, due_us;
    uint32_t sampled_us[RADIO_SIGNAL_SAMPLES];
    int16_t dbm[RADIO_SIGNAL_SAMPLES];
    uint8_t next, count, mode;
} radio_signal_meter;

// Call whenever the active receive context is selected, before due/read. OFF
// clears even an unchanged context so a later restart cannot reuse old values.
static inline void radio_signal_configure(radio_signal_meter *m,
        radio_signal_mode mode,uint32_t hz,uint32_t now) {
    if(mode==RADIO_SIGNAL_OFF || !hz)mode=RADIO_SIGNAL_OFF;
    if(m->mode!=(uint8_t)mode || m->hz!=hz || mode==RADIO_SIGNAL_OFF) {
        memset(m,0,sizeof *m);m->mode=(uint8_t)mode;m->hz=hz;m->due_us=now;
    }
}

static inline bool radio_signal_due(const radio_signal_meter *m,uint32_t now) {
    return m->mode!=RADIO_SIGNAL_OFF && (int32_t)(now-m->due_us)>=0;
}

// Samples must be board-reported dBm, without a guessed offset. Zero means an
// unknown/uninitialized level, not a full-strength signal. Invalid samples
// clear the display rather than keeping a plausible value indefinitely.
static inline void radio_signal_sample(radio_signal_meter *m,uint32_t now,int16_t dbm) {
    uint32_t period=m->mode==RADIO_SIGNAL_DMR ? RADIO_SIGNAL_DMR_PERIOD_US : RADIO_SIGNAL_PERIOD_US;
    m->due_us=now+period;
    if(m->mode==RADIO_SIGNAL_OFF || dbm < -160 || dbm >= 0) {
        m->count=m->next=0;return;
    }
    unsigned at=m->mode==RADIO_SIGNAL_DMR ? m->next : 0u;
    m->dbm[at]=dbm;m->sampled_us[at]=now;
    if(m->mode==RADIO_SIGNAL_DMR) {
        m->next=(uint8_t)((at+1u)%RADIO_SIGNAL_SAMPLES);
        if(m->count<RADIO_SIGNAL_SAMPLES)++m->count;
    } else m->count=1;
}

static inline bool radio_signal_read(const radio_signal_meter *m,uint32_t now,int16_t *dbm) {
    if(m->mode==RADIO_SIGNAL_OFF || !m->count)return false;
    uint32_t age=m->mode==RADIO_SIGNAL_DMR ? RADIO_SIGNAL_DMR_HOLD_US : RADIO_SIGNAL_STALE_US;
    bool found=false;int16_t peak=-160;
    for(unsigned i=0;i<m->count;++i) {
        if(now-m->sampled_us[i]>=age)continue;
        if(!found || m->dbm[i]>peak)peak=m->dbm[i];
        found=true;
    }
    if(found && dbm)*dbm=peak;
    return found;
}

// Preserve the unified UI's existing five-bar scale. This is an approximate
// strength display, not an absolute calibrated S-meter or proof of DMR sync.
static inline uint8_t radio_signal_bars(int16_t dbm) {
    return dbm>=-80 ? 5 : dbm>=-90 ? 4 : dbm>=-100 ? 3 : dbm>=-110 ? 2 : dbm>=-125 ? 1 : 0;
}
#endif
