// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_TEST_TONE_H
#define P25_TEST_TONE_H
#include <stdint.h>
// 8-kHz phase-continuous oscillator. Constant divisions; no floating point.
// 64-point sine table with linear interpolation, amplitude 2000.
static inline void p25_tone_frame(int16_t pcm[160],uint32_t *phase,unsigned hz) {
    static const int16_t sine[65]={0,196,390,581,765,943,1111,1269,1414,1546,1663,1764,1848,1914,1962,1990,2000,1990,1962,1914,1848,1764,1663,1546,1414,1269,1111,943,765,581,390,196,0,-196,-390,-581,-765,-943,-1111,-1269,-1414,-1546,-1663,-1764,-1848,-1914,-1962,-1990,-2000,-1990,-1962,-1914,-1848,-1764,-1663,-1546,-1414,-1269,-1111,-943,-765,-581,-390,-196,0};
    for(unsigned i=0;i<160;++i) {
        uint32_t scaled=*phase*64u,index=scaled/8000u,part=scaled%8000u;
        pcm[i]=(int16_t)(sine[index]+((int32_t)(sine[index+1]-sine[index])*(int32_t)part)/8000);
        *phase=(*phase+hz)%8000u;
    }
}
#endif
