// Project-owned diagnostics for the generated native DMR audio/codec hosts.
#ifndef RADIO_DMR_METRICS_H
#define RADIO_DMR_METRICS_H

#include <stdint.h>

// Task wall time, including preemption. total_us/calls saturate rather than wrap;
// saturated bit 0 means calls, bit 1 means total_us. A mean is total_us / calls
// only while saturated is zero. Codec costs are measured in task context;
// the PCM-read interrupt records only its arrival cadence and sample transfer.
typedef struct {
    uint32_t calls, total_us, max_us, saturated;
} radio_dmr_cost_t;

typedef struct {
    radio_dmr_cost_t service, callback;
    uint32_t service_gap_max_us, callback_gap_max_us;
    uint32_t blocks, overruns, underruns;
    // Dedicated PCM speaker counters are cumulative since boot. Submitted and
    // consumed count samples; queue_max (excluding the pending hardware half)
    // and discarded also use samples. These measure our software handoff,
    // not an undocumented hardware underrun flag.
    uint32_t output_submitted, output_consumed, output_irqs;
    uint32_t output_irq_gap_max_us, output_queue_max;
    uint32_t output_overflows, output_starvations, output_restarts;
    uint32_t output_drains, output_discarded, output_timeouts;
} radio_dmr_audio_diag_t;

typedef struct {
    radio_dmr_cost_t reset, encode, decode;
    uint32_t reset_rejected, encode_rejected, decode_rejected;
} radio_dmr_vocoder_diag_t;

// Native RX pipeline snapshot: IRQ arrival, slot-engine burst classification,
// queue pressure and deferred delivery admission. Counters wrap naturally and
// follow the native engine's initialization/reset lifetime. Values do not prove
// that the call filters admitted a call or that AMBE audio was decoded.
typedef struct {
    uint32_t sys_ints, ts_rx_ints, ts_tx_ints, ticks;
    uint32_t rx_voice, rx_lc_header, rx_terminator;
    uint32_t rx_crc_err, rx_unusable, late_entry, ev_overflow;
    uint32_t last_rx_type_info, last_sys_list, last_l2_status;
    uint8_t active, callback_bound, deferred_closed, deferred_active;
    uint8_t last_cc;
    int8_t last_ts;
} radio_dmr_rx_diag_t;

// Native slot-engine TX counters. These wrap naturally and share the engine's
// initialization/reset lifetime; they are distinct from call-stack events,
// source silence substitutions and the AMBE producer queue's dropped frames.
typedef struct {
    uint32_t tx_bursts, tx_underruns, tx_rejected, tx_done, event_overflows;
} radio_dmr_native_tx_diag_t;

static inline void radio_dmr_cost_record(radio_dmr_cost_t *cost, uint32_t us)
{
    if (cost->calls != UINT32_MAX) ++cost->calls;
    else cost->saturated |= 1u;
    if (us > UINT32_MAX - cost->total_us) {
        cost->total_us = UINT32_MAX;
        cost->saturated |= 2u;
    } else cost->total_us += us;
    if (us > cost->max_us) cost->max_us = us;
}

// Task-context snapshots only; calling these does not clear a measurement. Audio timing is
// cumulative since boot, excluding stopped-stream idle from gaps; use before and
// after snapshots for a call. PCM counts follow the existing native stats/reset
// API. Codec diagnostics reset on ownership resume and survive TX/RX stream
// restarts and individual frame/reset calls.
void hrc_audio_pcm_diag(radio_dmr_audio_diag_t *out);
// Task-context native DMR TX gate. Abort closes speaker admission immediately
// and invalidates in-flight callback publication. Resume follows RF unkeying;
// it permits new RX output without restoring any discarded samples.
void hrc_audio_pcm_output_abort(void);
void hrc_audio_pcm_output_resume(void);
void hrc_vocoder_diag(radio_dmr_vocoder_diag_t *out);
// A short IRQ-protected copy only: no modem I/O, reset or queue consumption.
void hrc_dmr_rx_diag(radio_dmr_rx_diag_t *out);
void hrc_dmr_tx_diag(radio_dmr_native_tx_diag_t *out);

#endif
