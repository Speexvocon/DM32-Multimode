// SPDX-License-Identifier: GPL-3.0-or-later
// Slow board services keep their native sampling cadence, independent of the
// fast RF/controller loop. Missed periods never trigger catch-up samples.
#ifndef RADIO_SERVICE_SCHEDULE_H
#define RADIO_SERVICE_SCHEDULE_H
#include <stdbool.h>
#include <stdint.h>

#define RADIO_CONTROL_PRIORITY 4u
#define RADIO_INPUT_PERIOD_US 10000u
#define RADIO_POWER_PERIOD_US 100000u

static inline bool radio_service_due(uint32_t *last_us,uint32_t now_us,uint32_t period_us) {
    if((uint32_t)(now_us-*last_us)<period_us)return false;
    *last_us=now_us;
    return true;
}
#endif
