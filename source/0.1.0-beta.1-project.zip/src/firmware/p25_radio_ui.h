// SPDX-License-Identifier: GPL-3.0-or-later
// Shared home-screen drawing, in gfx safe-area coordinates. No I/O or radio state.
#ifndef P25_RADIO_UI_H
#define P25_RADIO_UI_H

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "ui/gfx.h"

// The DM32's 240 x 320 panel has a 220 x 310 safe area. These disjoint bands
// allow status, received identities and hints to change without redrawing VFO.
enum {
    P25_UI_HEADER_Y=0, P25_UI_HEADER_H=36,
    P25_UI_CALL_Y=112, P25_UI_CALL_H=148,
    P25_UI_HINT_Y=260, P25_UI_HINT_H=50
};

typedef struct {
    uint32_t display_hz, receive_hz, tx_frequency;
    uint32_t tx_nac, tx_group, tx_source;
    uint16_t rx_nac;
    uint32_t rx_group;
    uint32_t rx_source;
    uint8_t battery_pct, rssi_bars;
    uint8_t phase; // 0: waiting, 1: valid frame sync, 2: recent clear voice.
    bool split, battery_low, rssi_valid;
    bool rx_active, rx_group_valid, rx_source_valid;
    bool tx_active, rx_muted, debug_active;
    bool mode_fm,mode_dmr,wide_fm,locked,scanning,private_call;
    uint8_t squelch,cc,ts;
    uint16_t tone;
    const char *state, *hint, *filter, *channel_label;
} p25_ui_view;

// Eight shared solids and four fixed antialiasing tones. Filling the twelve
// usable palette entries before text keeps partial and full redraws identical.
#define P25_UI_BG     RGB565(8,16,28)
#define P25_UI_PANEL  RGB565(16,30,44)
#define P25_UI_LINE   RGB565(40,56,70)
#define P25_UI_FG     RGB565(240,248,255)
#define P25_UI_MUTED  RGB565(152,176,196)
#define P25_UI_CYAN   RGB565(64,212,232)
#define P25_UI_GREEN  RGB565(64,240,112)
#define P25_UI_AMBER  RGB565(255,196,72)

static inline void p25_ui_palette(void) {
    static const color_t colors[]={P25_UI_BG,P25_UI_PANEL,P25_UI_LINE,P25_UI_FG,
        P25_UI_MUTED,P25_UI_CYAN,P25_UI_GREEN,P25_UI_AMBER,
        RGB565(56,68,80),RGB565(104,124,136),RGB565(88,92,96),RGB565(160,172,176)};
    // gfx reserves four palette slots from antialiasing. Seeding twelve
    // colors therefore makes all blended edges choose from this fixed set.
    // Full-screen callers cover the seed pixels with their header. Never
    // call on a partial refresh: that would dirty the first screen row.
    for(unsigned i=0;i<sizeof colors/sizeof colors[0];++i) gfx_pixel((int)i,0,colors[i]);
}

static inline void p25_ui_text(const font_t *font,int x,int y,int width,
                               const char *text,color_t color) {
    char fitted[48];
    gfx_text_fit(font,text ? text : "",width,fitted,sizeof fitted);
    gfx_text(font,x,y,fitted,color);
}

static inline void p25_ui_header(const p25_ui_view *v) {
    unsigned phase=v->phase>2u ? 0u : v->phase;
    const char *label=v->tx_active ? "TX" : phase==2u ? (v->mode_fm ? "RX" : "VOICE") : phase==1u ? "SYNC" : "WAIT";
    color_t sync=v->tx_active ? P25_UI_AMBER : phase ? P25_UI_GREEN : P25_UI_MUTED;
    uint8_t battery=v->battery_pct>100u ? 100u : v->battery_pct;
    uint8_t bars=v->rssi_valid ? (v->rssi_bars>5u ? 5u : v->rssi_bars) : 0u;
    gfx_fill(0,P25_UI_HEADER_Y,gfx_width(),P25_UI_HEADER_H,P25_UI_BG);
    gfx_text(&font_8x16,4,10,v->mode_fm ? "FM" : v->mode_dmr ? "DMR" : "P25",P25_UI_CYAN);
    gfx_round_fill(42,8,52,20,P25_UI_PANEL);
    gfx_text(&font_8x16,42+(52-gfx_text_width(&font_8x16,label))/2,10,label,sync);
    gfx_icon_bars(108,10,36,18,5,bars,P25_UI_FG,P25_UI_LINE);
    gfx_icon_battery(170,10,44,18,battery,P25_UI_MUTED,
                     v->battery_low ? P25_UI_AMBER : P25_UI_GREEN);
    gfx_hline(0,35,gfx_width(),P25_UI_LINE);
}

static inline void p25_ui_call(const p25_ui_view *v) {
    char line[32];
    bool receiving=v->rx_active && !v->tx_active;
    color_t accent=v->tx_active || (receiving && v->rx_muted) ? P25_UI_AMBER
                   : receiving ? P25_UI_GREEN : P25_UI_CYAN;
    gfx_fill(0,P25_UI_CALL_Y,gfx_width(),P25_UI_CALL_H,P25_UI_BG);
    gfx_round_fill(0,114,gfx_width(),140,P25_UI_PANEL);
    gfx_fill(0,124,3,116,accent);
    gfx_text(&font_6x12,10,122,v->tx_active ? "TRANSMITTING" : receiving ? (v->mode_fm ? "FM AUDIO" : "RX CALL")
        : v->mode_fm ? "ANALOG CHANNEL" : "TX TARGET",accent);

    if(v->mode_fm) {
        gfx_text(&font_12x24,10,143,v->wide_fm ? "WIDE FM" : "NARROW FM",P25_UI_FG);
        snprintf(line,sizeof line,"SQUELCH %u",v->squelch);
        gfx_text(&font_12x24,10,176,line,P25_UI_FG);
        unsigned type=v->tone>>14,value=v->tone&0x3fffu;
        if(!type)snprintf(line,sizeof line,"%s TONE OFF",v->tx_active ? "TX" : "RX");
        else if(type==1)snprintf(line,sizeof line,"%s CTCSS %u.%u Hz",v->tx_active ? "TX" : "RX",value/10u,value%10u);
        else snprintf(line,sizeof line,"%s DCS %03o %s",v->tx_active ? "TX" : "RX",value,type==3 ? "INV" : "NORM");
        gfx_text(&font_6x12,10,208,line,P25_UI_MUTED);
        p25_ui_text(&font_8x16,10,230,gfx_width()-20,v->state,accent);return;
    }

    if(receiving && !v->rx_group_valid) snprintf(line,sizeof line,"TG -----");
    else snprintf(line,sizeof line,"%s %lu",v->mode_dmr && v->private_call ? "TO" : "TG",(unsigned long)(receiving ? v->rx_group : v->tx_group));
    gfx_text(&font_12x24,10,143,line,P25_UI_FG);
    if(receiving && !v->rx_source_valid) snprintf(line,sizeof line,"ID --------");
    else snprintf(line,sizeof line,"ID %lu",(unsigned long)(receiving ? v->rx_source : v->tx_source));
    gfx_text(&font_12x24,10,176,line,P25_UI_FG);

    if(v->mode_dmr)snprintf(line,sizeof line,"%s CC %u TS%u",receiving ? "RX" : "TX",v->cc,v->ts);
    else snprintf(line,sizeof line,"%s NAC %03lX",receiving ? "RX" : "TX",
                  (unsigned long)((receiving ? v->rx_nac : v->tx_nac)&0xfffu));
    gfx_text(&font_6x12,10,208,line,P25_UI_MUTED);
    p25_ui_text(&font_6x12,140,208,gfx_width()-150,v->filter,P25_UI_MUTED);
    p25_ui_text(&font_8x16,10,230,gfx_width()-20,v->state,accent);
}

static inline void p25_ui_hint(const p25_ui_view *v) {
    color_t diagnostic=v->debug_active ? P25_UI_AMBER : P25_UI_MUTED;
    gfx_fill(0,P25_UI_HINT_Y,gfx_width(),P25_UI_HINT_H,P25_UI_BG);
    gfx_hline(0,260,gfx_width(),P25_UI_LINE);
    p25_ui_text(&font_8x16,4,268,gfx_width()-8,v->hint,P25_UI_FG);
    gfx_text(&font_6x12,4,294,"OK MENU",P25_UI_MUTED);
    gfx_text(&font_6x12,65,294,"P1 V/M",P25_UI_MUTED);
    gfx_text(&font_6x12,119,294,"P2 INFO",P25_UI_MUTED);
    if(v->locked)gfx_text(&font_6x12,185,294,"L",P25_UI_AMBER);
    gfx_rect(201,291,15,17,diagnostic);
    gfx_text(&font_6x12,206,294,"D",diagnostic);
}

static inline void p25_ui_channel(const p25_ui_view *v) {
    char line[32];
    gfx_fill(0,P25_UI_HEADER_H,gfx_width(),P25_UI_CALL_Y-P25_UI_HEADER_H,P25_UI_BG);
    p25_ui_text(&font_6x12,4,43,160,v->channel_label && *v->channel_label ? v->channel_label : "VFO A",P25_UI_MUTED);
    gfx_text(&font_6x12,v->split ? 180 : 168,43,v->split ? "SPLIT" : "SIMPLEX",P25_UI_MUTED);
    if(v->display_hz) snprintf(line,sizeof line,"%lu.%06lu",
        (unsigned long)(v->display_hz/1000000u),(unsigned long)(v->display_hz%1000000u));
    else snprintf(line,sizeof line,"---.------");
    gfx_text(&font_12x24,4,61,line,P25_UI_FG);
    gfx_text(&font_6x12,132,72,"MHz",P25_UI_MUTED);
    if(v->split) {
        uint32_t other_hz=v->tx_active ? v->receive_hz : v->tx_frequency;
        snprintf(line,sizeof line,"%s %lu.%06lu MHz",v->tx_active ? "RX" : "TX",
            (unsigned long)(other_hz/1000000u),(unsigned long)(other_hz%1000000u));
    }
    else snprintf(line,sizeof line,"RX / TX SIMPLEX");
    gfx_text(&font_6x12,4,92,line,P25_UI_MUTED);
}

static inline void p25_ui_home(const p25_ui_view *v) {
    gfx_clear(P25_UI_BG);
    p25_ui_palette();
    p25_ui_header(v);
    p25_ui_channel(v);
    p25_ui_call(v);
    p25_ui_hint(v);
}

#endif
