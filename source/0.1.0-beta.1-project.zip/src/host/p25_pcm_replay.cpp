// SPDX-License-Identifier: GPL-3.0-or-later
// Decode retained consecutive IMBE payloads from a known HDU-started call.
#include "imbe_bench.h"
#include <cstdio>
#include <cstdint>
int main(int argc,char **argv) {
    if(argc!=3)return 2;
    FILE *input=fopen(argv[1],"rb"),*output=fopen(argv[2],"wb");
    if(!input || !output)return 2;
    imbe_bench_init();uint8_t bits[11];uint32_t hash=2166136261u,frames=0;
    for(;;) {
        size_t n=fread(bits,1,11,input);
        if(!n)break;
        if(n!=11)return 3;
        int16_t pcm[160];imbe_bench_decode_pcm(bits,pcm);
        for(unsigned i=0;i<160;++i) {
            uint16_t x=(uint16_t)pcm[i];uint8_t bytes[2]={(uint8_t)x,(uint8_t)(x>>8)};
            hash=(hash^bytes[0])*16777619u;hash=(hash^bytes[1])*16777619u;
            if(fwrite(bytes,1,2,output)!=2)return 3;
        }
        ++frames;
    }
    if(ferror(input) || fclose(output))return 3;
    fclose(input);printf("frames=%lu hash=%08lx\n",(unsigned long)frames,(unsigned long)hash);
    return 0;
}
