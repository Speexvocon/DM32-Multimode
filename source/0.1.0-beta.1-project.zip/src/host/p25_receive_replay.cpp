// SPDX-License-Identifier: GPL-3.0-or-later
#include <cstdio>
#include <cstdlib>
#include "imbe_bench.h"
extern "C" {
#include "p25_receive_bench.h"
}
static uint32_t clock_us(void) {return 0;}
int main(int argc,char **argv) {
    if(argc!=2 && argc!=3)return 2;
    FILE *in=fopen(argv[1],"rb");if(!in)return 3;
    fseek(in,0,SEEK_END);long size=ftell(in);rewind(in);
    if(size<0 || size%2)return 4;
    auto *bytes=static_cast<uint8_t *>(malloc(size ? size : 1));if(!bytes)return 5;
    if(fread(bytes,1,size,in)!=static_cast<size_t>(size))return 6;
    fclose(in);imbe_bench_init();p25_receive_result r;
    p25_receive_bench_profile(bytes,size/2,0x293,clock_us,imbe_bench_decode_pcm,nullptr,&r,argc==3);free(bytes);
    printf("units=%u voices=%u corrected=%u hash=%08x state_bytes=%u\n",r.units,r.voices,r.corrected,r.pcm_hash,r.state_bytes);
}
