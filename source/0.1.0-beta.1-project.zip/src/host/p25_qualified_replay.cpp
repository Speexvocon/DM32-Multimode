// SPDX-License-Identifier: GPL-3.0-or-later
// Offline replay of demod_frame_probe's complete, already-framed records.
// No sample timing, queue scheduling or RF-performance claim is made here.
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <new>
#include "imbe_bench.h"
#include "imbe_vocoder_impl.h"
extern "C" {
#include "p25_rx.h"
#include "p25_receive_policy.h"
#include "p25_voice_policy.h"
}

struct replay {
    p25_receive_policy call{};
    p25_voice_policy quality{};
    int16_t last_good[160]{};
    uint32_t now=0,hash=2166136261u;
    unsigned units=0,hdu=0,ldu=0,terminators=0,selected_out=0,metadata_bad=0;
    unsigned unqualified=0,encrypted=0,unsupported=0,voices=0,codec_calls=0;
    unsigned repeated=0,muted=0,corrected=0,codec_resets=0,policy_resets=0,discards=0,ends=0;
    void reset_voice() {
        imbe_bench_init();++codec_resets;
        p25_voice_policy_init(&quality);std::memset(last_good,0,sizeof last_good);
    }
    bool write_pcm(FILE *out,const int16_t pcm[160]) {
        uint8_t bytes[320];
        for(unsigned n=0;n<160;++n) {
            auto value=static_cast<uint16_t>(pcm[n]);
            bytes[2*n]=static_cast<uint8_t>(value);
            bytes[2*n+1]=static_cast<uint8_t>(value>>8);
        }
        for(uint8_t value:bytes)hash=(hash^value)*16777619u;
        return std::fwrite(bytes,1,sizeof bytes,out)==sizeof bytes;
    }
    bool unit(const uint8_t record[219],FILE *out,bool prom,uint16_t selected) {
        const uint16_t nac=static_cast<uint16_t>((unsigned(record[0])<<8)|record[1]);
        const uint8_t duid=record[2],*frame=record+3;
        now+=duid==0 ? 82500u : duid==3 ? 15000u : duid==15 ? 45000u : 180000u;
        ++units;
        if(!prom && nac!=selected) {++selected_out;return true;}
        p25_call_metadata metadata;
        const bool valid=p25_call_decode(frame,duid,&metadata);
        const p25_receive_event event=p25_receive_update(&call,nac,duid,&metadata,valid,now);
        if(event.discard)++discards;
        // Output is synchronous: previously emitted PCM cannot be withdrawn.
        // Production event.discard also drops PCM still waiting in its queue.
        if(event.reset) {++policy_resets;reset_voice();}
        if(duid==3 || duid==15) {
            ++terminators;
            if(event.end) {++ends;p25_voice_policy_init(&quality);std::memset(last_good,0,sizeof last_good);}
            return true;
        }
        if(!valid)++metadata_bad;
        if(duid==0)++hdu;
        if(duid!=5 && duid!=10)return true;
        ++ldu;
        if(!event.voice) {
            if(call.state==P25_RX_ENCRYPTED)++encrypted;
            else if(call.state==P25_RX_UNSUPPORTED)++unsupported;
            else ++unqualified;
            return true;
        }
        for(unsigned n=0;n<9;++n) {
            uint8_t bits[11];int16_t pcm[160];p25_voice_quality errors;
            if(!p25_rx_voice_quality(frame,n,bits,&errors))return false;
            const bool had_good=quality.have_good;
            const p25_voice_action action=p25_voice_policy_frame(&quality,bits,errors.e0,errors.et);
            if(action==P25_VOICE_ACCEPT) {
                imbe_bench_decode_pcm(bits,pcm);++codec_calls;
                std::memcpy(last_good,pcm,sizeof pcm);
            } else if(action==P25_VOICE_REPEAT) {
                std::memcpy(pcm,last_good,sizeof pcm);++repeated;
            } else {
                std::memset(pcm,0,sizeof pcm);std::memset(last_good,0,sizeof last_good);
                if(had_good) {imbe_bench_init();++codec_resets;}
                ++muted;
            }
            ++voices;corrected+=errors.et;
            if(!write_pcm(out,pcm))return false;
        }
        return true;
    }
    void report() const {
        std::printf("{\"units\":%u,\"hdu\":%u,\"ldu\":%u,\"terminators\":%u,"
            "\"selection_rejected\":%u,\"metadata_bad\":%u,\"unqualified_units\":%u,"
            "\"encrypted_units\":%u,\"unsupported_units\":%u,\"voice_frames\":%u,"
            "\"codec_calls\":%u,\"repeated\":%u,\"muted\":%u,\"corrected\":%u,"
            "\"codec_resets\":%u,\"policy_resets\":%u,\"discards\":%u,\"ends\":%u,"
            "\"hash\":\"%08lx\",\"synthetic_duration_us\":%lu,\"final_class\":%u}\n",
            units,hdu,ldu,terminators,selected_out,metadata_bad,unqualified,encrypted,
            unsupported,voices,codec_calls,repeated,muted,corrected,codec_resets,
            policy_resets,discards,ends,static_cast<unsigned long>(hash),
            static_cast<unsigned long>(now),static_cast<unsigned>(call.state));
    }
};

// Independent direct-nostar path. A test supplies its expected reset/decode/
// concealment history, rather than reusing receive-policy decisions. Records
// are twelve bytes: 'R' reset, 'D'+11-byte IMBE, 'P' PCM repeat, 'M' zero PCM.
// The pinned codec's file-static synthesis PRNG survives reconstruction, so
// constructor and decode history are necessary for waveform equality.
static int reference_replay(const char *input,const char *output) {
    FILE *in=std::fopen(input,"rb");if(!in)return 3;
    FILE *out=std::fopen(output,"wb");if(!out) {std::fclose(in);return 3;}
    alignas(imbe_vocoder_impl) unsigned char storage[sizeof(imbe_vocoder_impl)];
    imbe_vocoder_impl *codec=nullptr;int16_t last[160]={0};
    replay result;uint8_t record[12];int error=0;
    for(;;) {
        const size_t count=std::fread(record,1,sizeof record,in);
        if(!count) {if(std::ferror(in))error=4;break;}
        if(count!=sizeof record) {error=4;break;}
        if(record[0]=='R') {
            if(codec)codec->~imbe_vocoder_impl();
            codec=new (storage) imbe_vocoder_impl();++result.codec_resets;
            std::memset(last,0,sizeof last);continue;
        }
        if(!codec) {error=6;break;}
        int16_t pcm[160];
        if(record[0]=='D') {
            codec->decode_4400(pcm,record+1);++result.codec_calls;
            std::memcpy(last,pcm,sizeof pcm);
        } else if(record[0]=='P') {std::memcpy(pcm,last,sizeof pcm);++result.repeated;}
        else if(record[0]=='M') {
            std::memset(pcm,0,sizeof pcm);std::memset(last,0,sizeof last);++result.muted;
        } else {error=6;break;}
        ++result.voices;
        if(!result.write_pcm(out,pcm)) {error=5;break;}
    }
    if(codec)codec->~imbe_vocoder_impl();
    if(std::fclose(in))error=4;
    if(std::fclose(out))error=5;
    if(!error)result.report();
    return error;
}

int main(int argc,char **argv) {
    if(argc==4 && !std::strcmp(argv[1],"--reference"))return reference_replay(argv[2],argv[3]);
    if(argc!=3 && argc!=4) {
        std::fprintf(stderr,"usage: %s input.frames output.s16le [NAC_hex|PROM]\n"
            "       %s --reference expected.plan output.s16le\n",argv[0],argv[0]);return 2;
    }
    bool prom=false;uint16_t selected=0x293;
    if(argc==4) {
        if(!std::strcmp(argv[3],"PROM"))prom=true;
        else {
            char *end=nullptr;unsigned long value=std::strtoul(argv[3],&end,16);
            if(!*argv[3] || *end || value>0xfff) return 2;
            selected=static_cast<uint16_t>(value);
        }
    }
    FILE *in=std::fopen(argv[1],"rb");if(!in)return 3;
    FILE *out=std::fopen(argv[2],"wb");if(!out) {std::fclose(in);return 3;}
    replay state;state.reset_voice();uint8_t record[219];int error=0;
    for(;;) {
        const size_t count=std::fread(record,1,sizeof record,in);
        if(!count) {if(std::ferror(in))error=4;break;}
        if(count!=sizeof record) {error=4;break;}
        if(!state.unit(record,out,prom,selected)) {error=5;break;}
    }
    if(std::fclose(in))error=4;
    if(std::fclose(out))error=5;
    if(error) {std::fprintf(stderr,"qualified replay failed: %d\n",error);return error;}
    state.report();return 0;
}
