// Host-only P25 test-vector validation; uses pinned OP25 and nostar GPL sources.
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <fstream>
#include <iterator>
#include <vector>
#include "imbe.h"
#include "imbe_vocoder.h"
#include "op25_imbe_frame.h"

int main(int argc, char** argv) {
    if (argc != 3) return 1;
    std::ifstream input(argv[1], std::ios::binary);
    std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(input)), {});
    if (bytes.size() != 432) return 2;
    std::ofstream output(argv[2], std::ios::binary);
    if (!output) return 3;
    imbe_vocoder decoder;
    unsigned frames=0, errors=0;
    for (int repeat=0; repeat<28; ++repeat) {
        for (int ldu=0; ldu<2; ++ldu) {
            bit_vector bits(1728);
            for (int b=0; b<1728; ++b)
                bits[b] = (bytes[ldu*216+b/8] >> (7-b%8)) & 1;
            for (unsigned f=0; f<9; ++f) {
                voice_codeword cw(144), rebuilt(144);
                imbe_deinterleave(bits, cw, f);
                uint32_t u[8]={}, e0=0, et=0;
                imbe_header_decode(cw,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7],e0,et);
                errors += et;
                imbe_header_encode(rebuilt,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
                if (rebuilt != cw) return 4;
                packed_codeword packed;
                imbe_pack(packed,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
                if (packed.size() != 11) return 5;
                int16_t pcm[160];
                decoder.decode_4400(pcm, packed.data());
                for (int16_t sample:pcm) {
                    uint16_t v=static_cast<uint16_t>(sample);
                    output.put(static_cast<char>(v & 255));
                    output.put(static_cast<char>(v >> 8));
                }
                ++frames;
            }
        }
    }
    if (!output || errors) return 6;
    std::printf("{\"voice_frames\":%u,\"corrected_bits\":%u,\"codeword_reencode_exact\":true}\n",frames,errors);
}
