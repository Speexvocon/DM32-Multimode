// SPDX-License-Identifier: GPL-3.0-or-later
// Lab replay only: input must be known-clear bench dibits, not arbitrary encrypted traffic.
#include <cstdio>
#include <cstdint>
#include "imbe_vocoder_impl.h"
extern "C" {
#include "p25_rx.h"
}
int main(int argc,char **argv) {
 if(argc!=3) return 2;
 FILE *in=fopen(argv[1],"rb"),*out=fopen(argv[2],"wb");if(!in||!out)return 3;
 p25_rx rx;p25_rx_init(&rx);imbe_vocoder_impl decoder;unsigned voices=0,errors=0;
 int b;while((b=fgetc(in))!=EOF) if(p25_rx_push(&rx,(uint8_t)b) && rx.nac==0x293 && (rx.duid==5||rx.duid==10)) {
  for(unsigned f=0;f<9;++f) {
   uint8_t payload[11];unsigned corrected;int16_t pcm[160];
   if(!p25_rx_voice(rx.frame,f,payload,&corrected))return 4;
   decoder.decode_4400(pcm,payload);errors+=corrected;++voices;
   if(fwrite(pcm,sizeof pcm,1,out)!=1)return 5;
  }
 }
 fclose(in);fclose(out);
 printf("frames=%u syncs=%u bad_nid=%u voice_frames=%u corrected_voice_bits=%u\n",rx.frames,rx.syncs,rx.bad_nid,voices,errors);
 return voices?0:6;
}
