# Logical CPS protocol, version 2

This API programs the custom unified DM32 P25/DMR/FM firmware's settings. It contains no address-based reads/writes, calibration operations, firmware update or transmit command. The primary client is the [browser CPS](../integrations/web-cps/README.md). The earlier CHIRP module used the same logical API and remains as historical integration code.

## Transport and identity

Normal application boot, 115200 baud, 8 data bits, no parity, one stop bit. Every command and reply is printable ASCII ending CRLF, at most **120 bytes including CRLF**. There is one bounded reply per command; there is no automatic write retry. Transactions, CRCs and record hex strings are emitted as uppercase hexadecimal. Indices and revisions are unsigned decimal. A transaction ID is exactly eight hexadecimal digits; the driver chooses a nonzero random 32-bit ID.

The unified firmware advertises version 2 with the same bounded geometry:

```text
CPS HELLO
CPS HELLO DM32P25 2 32 2 <revision> <CRC32>
```

The updated browser also accepts protocol 1 for existing P25/FM radios. It pins the protocol for the connection, validates V1 records under V1 rules and refuses a DMR upload before BEGIN. Previous clients that accept only protocol 1 reject the unified firmware at HELLO. Model identity remains DM32P25 for continuity; it does not select the RF mode.

The firmware refuses CPS while PTT is held, transmit/preparation is active or an incompatible job owns the radio. Opening a CPS session pauses receive monitoring. Read sessions expire after three idle seconds; staged transactions abort after 60 idle seconds. COMMIT/ABORT close the transaction. The normal held-PTT boot guard and transmit permissions remain radio policy. HELLO during an active staged transaction is rejected rather than mixing the active revision with a staged checksum.

## Commands

| Request | Successful reply | Effect |
|---|---|---|
| `CPS HELLO` | `CPS HELLO DM32P25 2 32 2 rev crc` | Identify and obtain the active snapshot revision/CRC |
| `CPS GET i` | `CPS DATA i hex64` | Read one active 32-byte record, `i=0..34` |
| `CPS BEGIN tid rev` | `CPS OK BEGIN tid` | Check the active revision and stage a full copy of the active settings |
| `CPS PUT tid i hex64` | `CPS OK PUT tid i` | Validate one record and change only the staged snapshot |
| `CPS COMMIT tid crc` | `CPS OK COMMIT tid newrev crc` | Validate the whole snapshot and checksum, durably publish it atomically, then apply it |
| `CPS ABORT tid` | `CPS OK ABORT tid` | Discard staging; active settings remain unchanged |

Errors have the form `CPS ERR CODE`; the driver treats every such reply as a failure. BUSY/PTT errors grant no permission to bypass the radio state. Bad identity/version/geometry stops the host before BEGIN. BEGIN rejects a stale revision. Invalid records, transaction IDs, CRCs and references to empty selected memories cannot commit.

The client downloads all 35 records between two matching HELLO responses and verifies the CRC. Upload also checks the original download revision/CRC against HELLO, sends all 35 staged records, then sends COMMIT once. An unchanged upload performs no write. After COMMIT it verifies the acknowledgement and a new HELLO. A missing/invalid commit acknowledgement is uncertain because the radio may have committed; the host never repeats COMMIT and requires a fresh download.

## Canonical payload and checksum

The logical payload is exactly **1120 bytes**: 35 records × 32 bytes in index order. Indices 0–31 are memories 1–32, index 32 is VFO A, 33 is VFO B and 34 is global settings. All integer fields are little endian. CRC is standard CRC-32/IEEE, polynomial `0xEDB88320`, initial `0xFFFFFFFF`, final XOR `0xFFFFFFFF`, over these 1120 bytes only. Flash-bank metadata, legacy preference records, CHIRP's image header and CHIRP metadata are excluded.

Empty channel/VFO records are all zero. An occupied record uses the following layout:

| Offset | Size | Field |
|---|---|---|
| 0 | 4 | Receive frequency in Hz |
| 4 | 4 | Transmit frequency in Hz; retained even for receive-only profiles |
| 8 | 2 | P25 NAC, 0–0xFFF |
| 10 | 2 | P25 transmit talkgroup, 1–65535 |
| 12 | 1 | Flags below |
| 13 | 1 | Scan membership bits 0–3; remaining bits zero |
| 14 | 12 | Printable ASCII name, zero padded; no nonzero byte after a zero |
| 26 | 2 | FM transmit tone word |
| 28 | 2 | FM receive tone word |
| 30 | 1 | FM squelch, 0–9 |
| 31 | 1 | Reserved, zero |

Flags: bit 0 occupied; bit 1 FM; bits 2–3 receive filter; bit 4 receive only; bit 5 wide FM; bit 6 DMR (V2 only); bit 7 zero. FM and DMR bits are mutually exclusive. With neither mode bit set, the channel is P25. Wide mode is valid only for FM. Both tone words must be zero for P25 and DMR.

P25/FM retain their exact V1 byte layout above. DMR replaces bytes 8–11 with:

| Offset | Size | DMR field |
|---|---|---|
| 8 | 3 | Destination ID, little endian, 1–0xFFFFFF |
| 11 | 1 | Bits 0–3 color code (0–15); bit 4 timeslot (0=1, 1=2); bit 5 private call (0=group); bit 6 repeater/hotspot framing (0=direct); bit 7 zero |
| 26–29 | 4 | Unused, zero |
| 30 | 1 | Canonical unused squelch value, 5 |
| 31 | 1 | Reserved, zero |

DMR source ID uses the existing global 24-bit ID. Direct/repeater framing is explicit and is not derived from equal RX/TX frequencies. A simplex hotspot may require repeater framing.

Filter bits are `0=NAC/all talkgroups`, `1=PROM`, `2=NAC+TG`, `3=invalid` for P25. For DMR they mean `0=configured CC/all destinations`, `1=any CC/all destinations on the selected timeslot`, `2=configured CC+destination`. DMR PROM does not monitor both timeslots. PROM does not enable encrypted voice decoding.

Tone words use their top two bits for type: `0=none`, `1=CTCSS`, `2=DCS`, `3=inverse DCS`. None requires value zero. CTCSS's low 14 bits are tenths of Hz, 600–2600 inclusive. DCS's low bits are the 9-bit code value, 1–511: the familiar octal code `023` is stored as decimal 19. CHIRP converts its octal-looking decimal representation automatically.

Storage validates frequencies structurally from 100 to 520 MHz; the driver advertises the DM32 board's 136–174 and 400–480 MHz ranges. Radio tuning and transmit permission also enforce board bands. This storage envelope does not grant out-of-band operation.

The global record is:

| Offset | Size | Field |
|---|---|---|
| 0 | 4 | Shared digital source/radio ID, 1–0xFFFFFF |
| 4 | 1 | P25 microphone gain, 0–42 dB; analog FM uses its native gain |
| 5 | 2 | Screen timeout, 0–600 seconds; zero always on |
| 7 | 2 | Keypad light timeout, 0–600 seconds; zero always on |
| 9 | 1 | Active VFO, 0=A / 1=B |
| 10 | 1 | A selection, 0=VFO A / 1–32=memory |
| 11 | 1 | B selection, 0=VFO B / 1–32=memory |
| 12 | 1 | Active scan list, 0–3 |
| 13 | 1 | Owner TX inhibit, 0–1 |
| 14–31 | 18 | Reserved, zero |

Selected memory references must point to occupied records. An unconfigured VFO may be zero. Active A/B selection uses one RF chain; it does not imply simultaneous reception. These light timeouts do not change the existing 30-second RF hard limit.

## Persistence and verification scope

Storage reads V1 and V2 bank snapshots without writing. A deliberate save or upload writes V2 records to the inactive bank, preserving the original snapshot until the new bank header is durable. Every selected data record must match its bank version; mixed-version/torn data cannot publish a partial snapshot. Unknown future versions disable writes. Older firmware may read a prior V1 bank or retained V1–V3 legacy profile read-only; that fallback is not the latest DMR database.

Staging may write the inactive settings bank, but the active bank remains authoritative until the complete snapshot's commit is durable. Aborted, interrupted and bad-CRC transactions must recover the previous whole snapshot after restart. The firmware owns bank layout, fallback and protected-region enforcement; none are exposed as CHIRP EEPROM addresses.

The browser's complete JSON codeplug wraps the canonical payload in a versioned
`DM32P25-CPS` envelope, version 2, with CRC and optional origin revision/CRC. Version 1 files import under strict V1 validation; P25/FM canonical bytes remain unchanged. A V1 envelope cannot contain a DMR record. File origin
metadata never qualifies a write; the connected client must first read the radio.
The earlier CHIRP `.img` format prefixes the logical payload with `DM32P25\0`,
protocol LE32 and payload length LE32, then uses CHIRP's metadata trailer. Neither
format is a stock firmware/codeplug dump, and the logical API has no raw-flash
capability.

Browser codec/transport tests and a bridge into the actual C parser/storage
exercise this API without hardware. Earlier CHIRP core/C-parser tests and a
real read-only CH340 download also passed. Physical browser GUI/read/write
qualification remains separate; simulated tests do not establish a hardware
upload pass. CHIRP qualification is no longer the primary workstream.
