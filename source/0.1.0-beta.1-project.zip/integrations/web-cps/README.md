# DM32 unified browser CPS

This is the primary programming interface for the custom DM32 P25/DMR/FM firmware.
The owner selected the RadioFoundry-style browser editor instead of continuing
CHIRP integration. The existing CHIRP module and its historical download evidence
remain in the repository; they are not required to use this editor.

## Start locally

From the repository root:

```powershell
python scripts/serve-web-cps.py
```

Open **http://127.0.0.1:8765/** in Chrome or Edge. The server listens on loopback
and serves this folder only. It has no serial, firmware-write or upload API;
Web Serial connects directly from the browser after you click Connect. Localhost
is a secure context for Web Serial. Nothing is sent to a remote service and no
additional JavaScript packages or CDN are needed.

The editor works offline with a sample codeplug or saved JSON file. It supports the installed `87203bd` P25/FM application through protocol 1 and the unified candidate through protocol 2. Protocol 1 cannot accept DMR channels; an attempted DMR upload is refused before a transaction starts. Editing the new DMR fields does not establish RF qualification or install firmware.

## Program the radio

1. Power on normally, release PTT, connect the programming cable and close other
   applications using COM8. The radio remains on its normal application firmware.
2. Click **Connect** and select the programming cable. This identifies the custom
   firmware; it does not grant permission to overwrite settings.
3. Click **Read radio**. This obtains a complete revision/CRC-qualified snapshot.
   Save a codeplug file before changing it.
4. Edit channels, VFO A/B, scan lists or radio settings. To apply an offline file,
   read the radio first, then open the file; file metadata alone never qualifies
   a write. Editing, importing and loading a sample never write the radio.
5. Review **Problems** and resolve errors. Click **Review & write**, review the
   proposed changes, then explicitly start the transfer. The firmware stages the
   complete snapshot and publishes it after validation and CRC verification.
6. After a first real upload, read the configuration back and confirm the values
   survive a normal power-off/restart. Browser and simulated-parser checks alone
   do not establish a hardware upload pass.

The firmware pauses reception and PTT during programming. An idle read link
expires after three seconds; abandoned staging expires after 60 seconds.
If the radio changed since the read, the write is refused. If a commit reply is
lost, the outcome is uncertain: reconnect and read again before another write.
The client never repeats a commit automatically.

## Current fields

- 32 named memories, two selectable VFO contexts and four overlapping scan lists.
- P25, DMR, narrow FM and wide FM, independent RX/TX frequencies and receive-only. DMR requires the unified V2 firmware.
- P25 NAC, transmit talkgroup and PROM/NAC/NAC+TG filtering per channel.
- DMR 24-bit destination, group/private calls, color code, timeslot and direct/repeater framing. The global source ID is shared by both digital modes.
- DMR CC/all destinations, CC+destination or PROM on the selected timeslot. PROM does not monitor both slots or decode encrypted voice.
- Independent analog RX/TX CTCSS or normal/inverse DCS and squelch.
- Radio ID, P25 microphone gain, active A/B selections, scan list, owner TX inhibit
  and independent screen/keypad-light timeouts.

Names hold 12 printable ASCII characters. Frequencies are entered as MHz, NACs
as three hexadecimal digits, CTCSS in Hz and DCS in octal. Adjustable microphone
gain applies to P25; analog FM retains its native gain. A/B share one RF receiver.
DMR controls are specific to the unified candidate; native DMR RF/audio and mixed-mode switching need hardware qualification before they can be described as validated. Named zones,
contact/alias tables and multi-talkgroup allowlists require a later configuration
schema and firmware iteration.

## Files, compatibility and provenance

The complete `.json` codeplug file uses a version-2 `DM32P25-CPS` envelope with
all 35 canonical records, CRC and origin metadata. Import validates it before
using it. Version-1 P25/FM files import with their payload bytes unchanged; unknown future versions are refused. Origin metadata from a file cannot substitute for reading the connected
radio. Undo/redo operates on the working draft, not the device.

This is a P25-aware adaptation of RadioFoundry's editor approach, with our existing
logical transport and atomic storage. RadioFoundry's stock web editor, its binary
codeplug files and qdmr transport are not interchangeable with this firmware.
See [upstream provenance](UPSTREAM.md) and the
[logical protocol specification](../../docs/CPS_PROTOCOL.md). The protocol
has no program-flash, bootloader, calibration, raw-address or transmit commands.
Backup, firmware installation and recovery remain separate tools.

## Checks

```powershell
./scripts/test-web-cps.ps1
```

This builds the real application parser/store behind the existing host HAL,
then runs the browser codec/client through both fake serial streams and that
actual C implementation. The bridge never opens a serial port. It checks mixed
P25/DMR/FM fields, atomic reboot retention, revision/CRC guards and uncertain commit
handling. Pure JavaScript tests can also run with `node --test` inside this folder;
the actual-C bridge cases require the library built by the PowerShell script.

First physical browser read/write and FM/mixed-scan observations remain separate
from offline and browser preview checks. Extended RF soak/repeat qualification is
still deferred at the owner's request.

Optional desktop-browser checks, using an already installed Chrome or Edge:

```powershell
# Leave the local server running in another terminal.
python scripts/serve-web-cps.py
# In the second terminal, from the repository root:
node tests/web_cps_browser.mjs
```

This launches its own hidden headless browser and injects a simulated Web Serial
peer before loading the editor. It never opens a real programming cable. It
checks local file round trips, form edits, reviewed uploads, stale revisions and
lost commit acknowledgements, and captures desktop/mobile screenshots under
`build/web-cps-browser-qa`. Set `CHROME_PATH` if the installed browser is not found
automatically; no browser package is downloaded. `CPS_URL` may select another
loopback server address.
