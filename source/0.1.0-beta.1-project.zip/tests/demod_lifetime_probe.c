// SPDX-License-Identifier: GPL-3.0-or-later
// Host-only adapter; the demodulator and parser are compiled without substitutes.
#include "p25_demod.h"
#include <stdint.h>
#include <string.h>

enum { MAX_WIRE_BYTES=32768, RESULT_WORDS=13 };
static p25_demod state[2], saved;
static uint32_t result[RESULT_WORDS], fake_time;
static uint8_t wire[MAX_WIRE_BYTES];
static unsigned wire_length, seen_tdu;
static uint32_t clock_us(void) { return ++fake_time; }
static void reset_output(void) {
    memset(result,0,sizeof result);wire_length=0;seen_tdu=0;
    result[7]=2166136261u;
}
static void frame(const p25_rx *rx,void *context) {
    (void)context;
    unsigned size=rx->duid==0?99:rx->duid==3?18:216;
    ++result[0];
    if(rx->duid==0)++result[1];
    else if(rx->duid==5)++result[2];
    else if(rx->duid==10)++result[3];
    else if(rx->duid==3){++result[4];seen_tdu=1;}
    else ++result[12];
    if(wire_length+size>sizeof wire){++result[12];return;}
    memcpy(wire+wire_length,rx->frame,size);wire_length+=size;
    for(unsigned i=0;i<size;++i)result[7]=(result[7]^rx->frame[i])*16777619u;
}
static void initialize_state(p25_demod *demod) {
    p25_demod_init(demod);demod->clock_us=clock_us;
}
void lifetime_initialize(void) {
    initialize_state(&state[0]);initialize_state(&state[1]);fake_time=0;
}
// ticks, frames, acquisitions, sync tests, and stage profiling counters.
static void counters(const p25_demod *demod,uint64_t *out) {
    out[0]=demod->ticks;out[1]=demod->frames;out[2]=demod->acquisitions;
    out[3]=demod->sync_tests;out[4]=demod->fir_us;out[5]=demod->sync_us;
    out[6]=demod->fec_us;out[7]=demod->symbol_us;
}
static void process(p25_demod *demod,const int16_t *input,unsigned idle,
                    unsigned total,uint32_t *out,uint64_t *before,uint64_t *after) {
    reset_output();
    for(unsigned i=0;i<idle;++i)p25_demod_push(demod,input[i],frame,0);
    unsigned idle_units=result[0];
    reset_output();counters(demod,before);
    unsigned acquisitions=demod->acquisitions,bad_nid=0;
    for(unsigned i=0;i<10;++i)bad_nid+=demod->lane[i].rx.bad_nid;
    for(unsigned i=idle;i<total;++i)p25_demod_push(demod,input[i],frame,0);
    counters(demod,after);
    result[5]=demod->acquisitions-acquisitions;
    unsigned final_bad=0;
    for(unsigned i=0;i<10;++i)final_bad+=demod->lane[i].rx.bad_nid;
    result[6]=final_bad-bad_nid;result[8]=wire_length;
    result[9]=idle_units;result[10]=demod->clock_us==clock_us;
    result[11]=demod->pending_ticks;
    memcpy(out,result,sizeof result);
}
void lifetime_segment(unsigned fresh,const int16_t *input,unsigned idle,
                      unsigned total,uint32_t *out,uint64_t *before,uint64_t *after) {
    p25_demod *demod=&state[fresh?1:0];
    if(fresh)initialize_state(demod);
    process(demod,input,idle,total,out,before,after);
}
unsigned lifetime_copy_wire(uint8_t *out) {
    memcpy(out,wire,wire_length);return wire_length;
}
// Decode the current output only for a second check against the pinned source
// payload. Count bits here rather than weakening full-wire comparison silently.
unsigned lifetime_copy_payloads(uint8_t *out,unsigned capacity,unsigned *corrections) {
    unsigned offset=0,length=0;*corrections=0;
    while(offset<wire_length) {
        unsigned duid=wire[offset+7]&15;
        if(duid==5 || duid==10) {
            for(unsigned voice=0;voice<9;++voice) {
                unsigned corrected=0;
                if(length+11>capacity)return 0;
                if(!p25_rx_voice(wire+offset,voice,out+length,&corrected))return 0;
                length+=11;*corrections+=corrected;
            }
        }
        offset+=duid==0?99:duid==3?18:216;
    }
    return length;
}
unsigned lifetime_prime(const int16_t *input,unsigned total) {
    initialize_state(&saved);reset_output();
    unsigned used=0;
    while(used<total && !seen_tdu)p25_demod_push(&saved,input[used++],frame,0);
    return seen_tdu && result[0]==30 && result[4]==1 ? used : 0;
}
void lifetime_malformed_prime(const int16_t *input,unsigned total,uint32_t *out,
                             uint64_t *before,uint64_t *after) {
    initialize_state(&saved);
    process(&saved,input,0,total,out,before,after);
}
void lifetime_boundary(unsigned fresh,const int16_t *input,unsigned total,
                       uint32_t *out,uint64_t *before,uint64_t *after) {
    if(fresh)initialize_state(&state[1]);else state[1]=saved;
    process(&state[1],input,0,total,out,before,after);
}
