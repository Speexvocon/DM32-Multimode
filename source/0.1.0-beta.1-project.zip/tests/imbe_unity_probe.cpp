// SPDX-License-Identifier: GPL-3.0-or-later
#include "imbe_vocoder_impl.h"
#include <stdio.h>
static imbe_vocoder_impl codec;
int main(int argc,char **argv) {
    if (argc!=3) return 1;
    FILE *in=fopen(argv[1],"rb"), *out=fopen(argv[2],"wb");
    if (!in || !out) return 2;
    int16_t pcm[160];
    for (;;) {
        size_t count=fread(pcm,sizeof(pcm[0]),160,in);
        if (!count) break;
        if (count!=160) return 3;
        uint8_t payload[11]; codec.encode_4400(pcm,payload);
        if (fwrite(payload,1,11,out)!=11) return 4;
    }
    int error=ferror(in); fclose(in);
    return fclose(out)!=0 || error ? 5 : 0;
}
