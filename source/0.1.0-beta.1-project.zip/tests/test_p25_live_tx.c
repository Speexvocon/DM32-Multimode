// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_live_tx.h"
#include "p25_test_vectors.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static uint8_t unit[216], out[36];
static uint8_t expected(unsigned n,unsigned pairs,unsigned extra) {
    if(n<P25_TEST_PREAMBLE_BYTES+extra) return 0x77;
    n-=P25_TEST_PREAMBLE_BYTES+extra; if(n<99) return p25_test_hdu[n];
    n-=99; if(n<pairs*432) return (uint8_t)((n/216)*17+n%216);
    n-=pairs*432; if(n<18) return p25_test_tdu[n];
    return 0x77;
}
int main(void) {
    // Every physical byte alignment: continuous producer, repeated bank wraps,
    // frame crossings and timer wrap. Check the entire stream, including the
    // final physical block, so no inserted fill can hide between HDU/LDU/TDU.
    for(unsigned extra=0;extra<=LIVE_STARTUP_EXTRA_MAX_BYTES;++extra) {
    for(unsigned pairs=1;pairs<=84;++pairs) {
        p25_live_tx s; p25_live_tx_init(&s);
        assert(s.startup_extra==0);
        assert(p25_live_tx_set_startup_extra(&s,extra));
        assert(!p25_live_tx_set_startup_extra(&s,LIVE_STARTUP_EXTRA_MAX_BYTES+1));
        assert(!p25_live_tx_set_startup_extra(&s,~0u));
        assert(s.startup_extra==extra);
        unsigned next=0,bytes=0; uint32_t now=0xffff0000u;
        while(s.count<2) {
            for(unsigned j=0;j<216;++j) unit[j]=(uint8_t)(next*17+j);
            assert(p25_live_tx_push(&s,unit)); ++next;
        }
        if(next==pairs*2) assert(p25_live_tx_finish(&s));
        assert(p25_live_tx_start(&s,now)); assert(!p25_live_tx_start(&s,now));
        assert(!p25_live_tx_set_startup_extra(&s,(extra+1)%36));
        while(s.timing.state!=P25_TX_DRAINING) {
            if(next<pairs*2 && s.count<3) {
                for(unsigned j=0;j<216;++j) unit[j]=(uint8_t)(next*17+j);
                assert(p25_live_tx_push(&s,unit)); ++next;
                if(next==pairs*2) assert(p25_live_tx_finish(&s));
            }
            assert(p25_live_tx_boundary(&s,now,out));
            for(unsigned j=0;j<36;++j) assert(out[j]==expected(bytes++,pairs,extra));
            assert(!p25_live_tx_set_startup_extra(&s,(extra+1)%36));
            assert(!p25_live_tx_boundary(&s,now+100,out)); now+=30000;
        }
        assert(s.consumed==pairs*2 && !s.count && !s.underruns);
        assert(s.header_pos==P25_TEST_PREAMBLE_BYTES+extra+99);
        assert(s.terminator_pos==18);
        assert(bytes==((339+extra+pairs*432+18+35)/36)*36);
        assert(s.timing.blocks==bytes/36 && s.timing.offset==bytes);
        assert(!p25_live_tx_boundary(&s,now,out));
        p25_test_tx_poll_limit(&s.timing,s.timing.drain_until_us-1,true,LIVE_RF_MAX_US);
        assert(s.timing.state==P25_TX_DRAINING);
        p25_test_tx_poll_limit(&s.timing,s.timing.drain_until_us,true,LIVE_RF_MAX_US);
        assert(s.timing.state==P25_TX_DONE);
        assert(!p25_live_tx_set_startup_extra(&s,0));
    }
    }
    p25_live_tx s; p25_live_tx_init(&s);
    assert(!p25_live_tx_start(&s,0) && !p25_live_tx_finish(&s));
    assert(p25_live_tx_push(&s,unit)); assert(!p25_live_tx_finish(&s));
    for(unsigned i=1;i<LIVE_BANKS;++i) assert(p25_live_tx_push(&s,unit));
    assert(!p25_live_tx_push(&s,unit));
    assert(p25_live_tx_start(&s,0));
    unsigned n=0; while(p25_live_tx_boundary(&s,n++*30000u,out)) {}
    assert(s.underruns==1 && s.timing.state==P25_TX_ABORTED);
    assert(!p25_live_tx_boundary(&s,n*30000u,out));
    assert(!p25_live_tx_set_startup_extra(&s,0));
    p25_live_tx_init(&s); assert(p25_live_tx_push(&s,unit)); assert(p25_live_tx_push(&s,unit));
    assert(p25_live_tx_start(&s,0)); assert(p25_live_tx_boundary(&s,1000,out));
    assert(!p25_live_tx_boundary(&s,35000,out) && s.timing.reason==P25_TX_LATE);
    p25_live_tx_init(&s); assert(p25_live_tx_push(&s,unit)); assert(p25_live_tx_push(&s,unit));
    assert(p25_live_tx_start(&s,0));
    assert(!p25_live_tx_boundary(&s,P25_TX_STALL_US,out) && s.timing.reason==P25_TX_STALLED);
    p25_live_tx_init(&s); assert(p25_live_tx_push(&s,unit)); assert(p25_live_tx_push(&s,unit));
    assert(p25_live_tx_start(&s,0xffff0000u));
    assert(!p25_live_tx_boundary(&s,0xffff0000u+LIVE_RF_MAX_US,out));
    assert(s.timing.reason==P25_TX_TIMEOUT);
    // PTT release remains authoritative before the first block, in the body,
    // and during final drain, including the longest allowed startup fill.
    for(unsigned phase=0;phase<3;++phase) {
        p25_live_tx_init(&s);
        assert(p25_live_tx_set_startup_extra(&s,LIVE_STARTUP_EXTRA_MAX_BYTES));
        assert(p25_live_tx_push(&s,unit)); assert(p25_live_tx_push(&s,unit));
        assert(p25_live_tx_finish(&s)); assert(p25_live_tx_start(&s,0));
        uint32_t now=0;
        if(phase==1) { assert(p25_live_tx_boundary(&s,now,out)); now+=30000; }
        if(phase==2) while(s.timing.state!=P25_TX_DRAINING) {
            assert(p25_live_tx_boundary(&s,now,out)); now+=30000;
        }
        p25_test_tx_poll_limit(&s.timing,now,false,LIVE_RF_MAX_US);
        assert(s.timing.state==P25_TX_ABORTED && s.timing.reason==P25_TX_RELEASED);
        assert(!p25_live_tx_boundary(&s,now,out));
    }
    puts("Live TX: all 36 startup alignments, exact unit/tail bytes, bank wrap, LDU pairs, timer wrap, release, drain, timeout, duplicates, late/missing IRQ and underrun passed");
}
