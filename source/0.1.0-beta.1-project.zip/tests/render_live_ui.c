// SPDX-License-Identifier: GPL-3.0-or-later
// Actual live UI rendered with upstream fonts and framebuffer.
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Renderer-only MMIO model; never access the target's analog registers.
static volatile uint32_t render_dac_power=1u<<1;
#define DAC_PD_CTRL render_dac_power
#define DAC_B_OFF (1u<<1)
void hrc_dac_b_power(bool on);
#include "../src/firmware/dm32_p25_live.c"
#include "radio_dmr_stub.h"
void board_rf_safe(void) { render_dac_power|=DAC_B_OFF; }
void hrc_dac_b_power(bool on) {
    if(on)render_dac_power&=~DAC_B_OFF;
    else render_dac_power|=DAC_B_OFF;
}
void board_init(void) { abort(); }
uint32_t hrc_irq_save(void) { return 0; }
void hrc_irq_restore(uint32_t state) { (void)state; }
void hrc_irq_enable(uint8_t irq,bool on) { (void)irq;(void)on; }
void vTaskDelete(TaskHandle_t h) { (void)h; abort(); }
BaseType_t xTaskCreate(TaskFunction_t fn,const char *const name,configSTACK_DEPTH_TYPE depth,
    void *const arg,UBaseType_t priority,TaskHandle_t *const handle) { abort(); }
static uint16_t battery(void) { return 8000; }
static uint8_t battery_percent(void) { return 88; }
static const hal_power_t power={.battery_mv=battery,.battery_pct=battery_percent};
static const band_t render_bands[]={
    {.lo_hz=136000000,.hi_hz=174000000,.tx=true},
    {.lo_hz=400000000,.hi_hz=480000000,.tx=true}
};
const board_t board={.power=&power,.bands=render_bands,.band_count=2};
const char *bf_cal_source(void) { return "factory"; }
uint32_t hrc_micros(void) {return 1000000u;}
uint32_t hal_millis(void) {return 1000u;}
static bool badge_only,hint_only;
static unsigned hint_flushes;
static void flush(const void *fb,const uint16_t *palette,uint16_t y0,uint16_t y1) {
    assert(y0<y1 && y1<=320); // HAL uses y0 inclusive / y1 exclusive.
    if(badge_only)assert(y1<=5+P25_UI_HEADER_H);
    if(hint_only) {assert(y0>=5+P25_UI_HINT_Y && y1<=5+310);++hint_flushes;}
    (void)fb;(void)palette;(void)y0;(void)y1;
}
static const char *fixture_names[]={
    "unset-channel","edit-frequency-partial","edit-frequency-complete","listening-ptt-ready",
    "tx-prepare","menu-tx-permission","diagnostics","diagnostics-pass","tx-fault",
    "listening-tx-inhibited","split-maximum-identifiers","menu-nac","edit-nac","edit-source-id",
    "split-tx-prepare","listening","menu-bench","rx-sync","diagnostic-local-tone",
    "diagnostic-synthetic-tone","diagnostic-replay","menu-mic-gain","edit-mic-gain",
    "rx-voice","tx-voice","tx-drain","rx-restore","rx-paused","rx-fault",
    "ptt-release-required","preferences-pending","preferences-read-only","preferences-save-failed",
    "bench-stopped","diagnostic-fixed-rf","menu-resume-radio","prom-listening","prom-sync",
    "prom-voice","menu-filter-nac","menu-filter-prom","hint-release-to-ready","hint-release-to-inhibited",
    "rx-call-identity","rx-encrypted","rx-unsupported","rx-metadata-wait","rx-metadata-bad",
    "view-idle-maximum-target","view-receiving-maximum-identifiers","view-encrypted",
    "view-blocked","view-transmitting","view-split","view-empty-battery","view-long-hint",
    "named-memory-maximum-name","vfo-b","menu-root-bottom","menu-root-memories",
    "menu-channel-mode","menu-channel-fm","menu-channel-rx-only","menu-memory-vfo",
    "menu-memory-other-vfo","menu-memory-save","menu-memory-recall","menu-scan-start",
    "menu-scan-list-four","menu-scan-membership","menu-display-600-seconds","menu-display-always-on",
    "menu-display-keypad-lock","menu-fm-bandwidth","menu-fm-bottom","edit-memory-save-32",
    "edit-memory-recall-01","edit-screen-timeout-600","edit-keypad-timeout-600","edit-fm-ctcss-2600",
    "edit-fm-dcs-0777","edit-fm-squelch-9","keypad-locked","scan-searching",
    "scan-holding-p25","fm-narrow-listening","fm-wide-dcs-inverted","fm-receiving-ctcss",
    "fm-transmitting-dcs","scan-holding-fm","programming-paused","rx-talkgroup-filtered",
    "fm-tone-off","empty-scan-list","memory-saved","unconfigured-vfo-b",
    "view-fm-narrow","view-fm-wide","view-fm-receiving","view-fm-transmitting",
    "view-keypad-locked","view-scanning","view-talkgroup-filtered","view-memory-maximum-name",
    "dmr-24bit-destination","dmr-cc15-ts2","dmr-private-call","dmr-encrypted-muted",
    "dmr-prom-reception","dmr-tx-voice","dmr-automatic-rx-return","dmr-prom-other-color-code"
};
// GFX_FIT_TRACE observes the real gfx implementation before clipping. Checking
// only the exported image would hide out-of-bounds text that gfx silently clips.
// A background fill invalidates old labels, so legitimate partial redraws do not
// count as overlapping text. All dimensions are in the 220x310 safe viewport.
typedef struct {int x,y,w,h;char text[128];} text_box;
static text_box text_boxes[128];
static unsigned text_count,layout_errors,text_draws,fitted_texts,fixture_number;
static bool large_max_group_seen,large_max_source_seen,large_editor_seen,split_receive_seen;
static FILE *layout_log;
static bool intersects(int x,int y,int w,int h,const text_box *b) {
    return x<b->x+b->w && b->x<x+w && y<b->y+b->h && b->y<y+h;
}
static void layout_error(const char *kind,int x,int y,int w,int h,const char *text) {
    ++layout_errors;
    fprintf(layout_log,"%u\t%s\t%d\t%d\t%d\t%d\t%s\n",fixture_number,kind,x,y,w,h,text ? text : "");
    fprintf(stderr,"UI layout %s: fixture %u [%d,%d %dx%d] %s\n",kind,fixture_number,x,y,w,h,text ? text : "");
}
void gfx_fit_trace(const char *src,const char *out) {
    (void)src;(void)out;++fitted_texts;
}
void gfx_draw_trace(gfx_trace_kind_t kind,int x,int y,int w,int h,const int clip[4],const char *s) {
    if(kind==GFX_TRACE_CLEAR) {text_count=0;return;}
    if(kind==GFX_TRACE_FILL) {
        for(unsigned n=0;n<text_count;) {
            if(intersects(x,y,w,h,&text_boxes[n]))text_boxes[n]=text_boxes[--text_count];
            else ++n;
        }
        return;
    }
    if(kind!=GFX_TRACE_TEXT || !s || !*s)return;
    ++text_draws;
    if(!strcmp(s,"TG 65535") && w==12*8 && h==24)large_max_group_seen=true;
    if(!strcmp(s,"ID 16777215") && w==12*11 && h==24)large_max_source_seen=true;
    if(!strcmp(s,"16777215") && w==12*8 && h==24)large_editor_seen=true;
    if(!strcmp(s,"RX 440.075000 MHz"))split_receive_seen=true;
    if(x<0 || y<0 || x+w>gfx_width() || y+h>gfx_height())
        layout_error("outside-safe-area",x,y,w,h,s);
    if(x<clip[0] || y<clip[1] || x+w>clip[2] || y+h>clip[3])
        layout_error("clipped-text",x,y,w,h,s);
    for(unsigned n=0;n<text_count;++n) {
        if(intersects(x,y,w,h,&text_boxes[n])) {
            char detail[280];snprintf(detail,sizeof detail,"%s / %s",text_boxes[n].text,s);
            layout_error("text-overlap",x,y,w,h,detail);
        }
    }
    assert(text_count<sizeof text_boxes/sizeof text_boxes[0]);
    text_box *box=&text_boxes[text_count++];
    *box=(text_box){.x=x,.y=y,.w=w,.h=h};
    snprintf(box->text,sizeof box->text,"%s",s);
}
static p25_ui_view view_fixture(unsigned n) {
    p25_ui_view v={.display_hz=145700000,.receive_hz=145700000,.tx_frequency=440075000,
        .tx_nac=0xfff,.tx_group=65535,.tx_source=16777215,
        .rx_nac=0x293,.rx_group=65535,.rx_source=16777215,
        .battery_pct=88,.rssi_bars=4,.rssi_valid=true,
        .state="LISTENING",.hint="",.filter="PROM",.channel_label="VFO A"};
    if(n==1 || n==2 || n==3) {
        v.rx_active=true;v.phase=n==1 ? 2 : 1;
        v.rx_group_valid=v.rx_source_valid=n==1;
        v.state=n==1 ? "CLEAR VOICE" : n==2 ? "ENCRYPTED / MUTED" : "BAD METADATA / MUTED";
        v.rx_muted=n!=1;
    }
    if(n==4) {v.tx_active=true;v.state="TRANSMITTING";v.hint="Release PTT to finish";}
    if(n==5) {v.split=true;v.rssi_valid=false;v.battery_pct=100;}
    if(n==6) {v.battery_low=true;v.battery_pct=0;v.state="BATTERY LOW";v.hint="Charge battery";}
    if(n==7) {v.debug_active=true;v.hint="RELEASE PTT before using radio";}
    if(n>=8 && n<=11) {
        v.mode_fm=true;v.squelch=9;v.wide_fm=n==9;
        v.state="FM listening";v.tone=(uint16_t)(0x4000u|2600u);
        if(n==9)v.tone=(uint16_t)(0xc000u|0777u);
        if(n==10) {v.rx_active=true;v.phase=2;v.state="Receiving FM";}
        if(n==11) {v.tx_active=true;v.state="Voice call";v.hint="Release PTT to finish";v.tone=(uint16_t)(0x8000u|0023u);}
    }
    if(n==12) {v.locked=true;v.hint="Locked / hold OK + *";}
    if(n==13) {v.scanning=true;v.state="Scanning";}
    if(n==14) {v.rx_active=true;v.rx_muted=true;v.phase=1;v.state="Talkgroup filtered";v.filter="NAC+TG";}
    if(n==15)v.channel_label="B M32 LONGEST NAME";
    if(n>=16 && n<=23) {
        v.mode_dmr=true;v.cc=15;v.ts=2;v.tx_group=v.rx_group=16777215u;
        v.filter="CC+TG";v.state="DMR listening";
        if(n==17)v.state="DMR CC15 / TS2";
        if(n==18) {v.private_call=true;v.rx_active=v.rx_group_valid=v.rx_source_valid=true;v.phase=2;v.state="Private voice";}
        if(n==19) {v.rx_active=v.rx_muted=v.rx_group_valid=v.rx_source_valid=true;v.phase=1;v.state="Encrypted / muted";}
        if(n==20 || n==23) {v.rx_active=v.rx_group_valid=v.rx_source_valid=true;v.phase=2;v.filter="PROM";v.state="DMR voice";if(n==23)v.cc=0;}
        if(n==21) {v.tx_active=true;v.split=true;v.display_hz=v.tx_frequency;v.state="DMR transmitting";v.hint="Release PTT to finish";}
        if(n==22) {v.split=true;v.state="DMR listening";v.hint="";}
    }
    return v;
}
static void partial_redraw_equivalence(void) {
    // Independently compare expanded RGB565, including the real 4-bpp palette:
    // adding a green/amber label must not recolor static VFO pixels through a
    // reused palette slot. An indexed framebuffer-only memcmp would miss that.
    static uint8_t incremental[240*320*2],full[240*320*2];
    for(unsigned n=0;n<24;++n)for(unsigned reverse=0;reverse<2;++reverse) {
        fixture_number=n<8 ? 48+n : 88+n;
        p25_ui_view before=view_fixture(reverse ? n : 0),after=view_fixture(reverse ? 0 : n);
        if(n<16) {
            after.display_hz=before.display_hz;after.tx_frequency=before.tx_frequency;
            after.split=before.split; // Existing P25 badges do not replace this band.
            after.channel_label=before.channel_label;
        }
        p25_ui_home(&before);
        p25_ui_header(&after);if(n>=16)p25_ui_channel(&after);p25_ui_call(&after);p25_ui_hint(&after);
        gfx_read_rgb565(0,incremental,sizeof incremental);
        p25_ui_home(&after);gfx_read_rgb565(0,full,sizeof full);
        if(memcmp(incremental,full,sizeof full))
            layout_error("partial-full-pixel-mismatch",0,0,240,320,"Header/call/hint redraw differs from complete home");
    }
}
static void fixture_reset(void) {
    radio_dmr_stub_reset();assert(radio_codec_bind_dmr(&rx_storage,sizeof rx_storage));
    memset(&digital_dmr,0,sizeof digital_dmr);native_irq_owned=false;
    memset(&control,0,sizeof control);control.nac=0x293;control.talkgroup=10;control.source_id=1234567;
    frequency=control.tx_frequency=440075000;control.state=RADIO_RX_IDLE;
    owner_tx_inhibit=false;rx_promiscuous=false;normal_mode=true;ptt_release_required=false;
    ptt_release_seen=false;ptt_release_since=0;
    control.inhibit=false;control.tx_enabled=true;session_enabled=false;armed=false;
    field=EDIT_RX;editing=false;menu_open=false;menu_item=0;menu_page=MENU_ROOT;digit_count=0;
    edit_from_menu=diag_from_menu=false;
    memset(frequency_digits,0,sizeof frequency_digits);
    rx_lab=rx_checked=false;rx_pass=true;rx_job=rx_sampling=false;
    rx_reason="not_run";reason="idle";
    mon_enabled=true;mon_running=mon_failed=mon_used=false;mon_reason="receiving";
    mon_local_tone=mon_output_tone=mon_replay=false;mon_audio_enabled=true;mon_pcm_backend=true;
    mon_have_sync=mon_badge_sync=false;mon_badge_phase=0;mon_sync_us=mon_voice_us=0;
    memset(&rx_storage,0,sizeof rx_storage);
    call_active=hardware_running=pa_started=audio_on=prepared=false;
    tx_fixed=false;tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;
    memset(&live,0,sizeof live);memset(&pcmq,0,sizeof pcmq);
    memset(&pref_store,0,sizeof pref_store);pref_store.have=pref_store.writable=true;pref_store.seq=4;
    pref_state="saved";pref_dirty=false;mic_gain_db=22;pref_saved=pref_current();
    ui_battery_mv=8000;ui_battery_pct=88;ui_battery_valid=true;
    ui_rssi_bars=4;ui_rssi_dbm=-90;ui_rssi_valid=true;ui_signal_us=1000000u;
    memset(&ui_strength,0,sizeof ui_strength);
    ui_battery_due=2000000u;ui_rssi_due=1250000u;ui_meter_max_us=ui_header_shown=0;
    // Every scene owns a local feature context. No prior mode, memory selector,
    // CPS session, lock or scan state may leak into another rendered fixture.
    memset(&channel_store,0,sizeof channel_store);memset(channel_record,0,sizeof channel_record);
    memset(global_record,0,sizeof global_record);memset(&analog_fm,0,sizeof analog_fm);
    memset(&channel_scan,0,sizeof channel_scan);radio_ux_init(&radio_lights,1000000u);
    features_ready=true;rx_tg_filter=cps_active=cps_link=false;cps_transaction=cps_activity_us=0;
    light_keys=lock_mask=lock_select_mask=0;light_screen_level=light_key_level=255;
    pref_put(global_record,1234567);global_record[4]=22;
    feature_put16(global_record+5,60);feature_put16(global_record+7,15);
    pref_put(channel_record,frequency);pref_put(channel_record+4,control.tx_frequency);
    feature_put16(channel_record+8,0x293);feature_put16(channel_record+10,10);
    channel_record[12]=P25_CS_OCCUPIED;channel_record[30]=5;
    snprintf(channel_label,sizeof channel_label,"VFO A");
    memcpy(channel_saved,channel_record,32);memcpy(global_saved,global_record,32);
}
static void fixture_profile(bool fm,bool wide,unsigned pane,unsigned memory,const char *name) {
    global_record[9]=(uint8_t)pane;global_record[10+pane]=(uint8_t)memory;
    channel_record[12]=(uint8_t)(P25_CS_OCCUPIED|(fm ? P25_CS_FM : 0)|(wide ? P25_CS_WIDE : 0));
    memset(channel_record+14,0,12);size_t n=strlen(name);if(n>12)n=12;
    memcpy(channel_record+14,name,n);feature_apply();
}
static void fixture_menu(ui_menu page,unsigned item) {
    menu_open=true;menu_page=page;menu_item=item;control.state=RADIO_RX_PAUSED;
}
static void fixture_editor(edit_field edit,const char *digits) {
    editing=true;field=edit;digit_count=(unsigned)strlen(digits);
    memcpy(frequency_digits,digits,digit_count);control.state=RADIO_RX_PAUSED;
}
static bool text_visible(const char *text) {
    for(unsigned i=0;i<text_count;++i)if(!strcmp(text_boxes[i].text,text))return true;
    return false;
}
int main(int argc,char **argv) {
    assert(argc==2 || (argc==3 && !strcmp(argv[2],"--view-only")));
    const unsigned first=argc==3 ? 48 : 0;
    const hal_display_t panel={.width=240,.height=320,.bpp=4,.inset_left=10,.inset_right=10,
        .inset_top=5,.inset_bottom=5,.flush_indexed=flush};
    display_ok=gfx_init(&panel);assert(display_ok);
    assert(gfx_width()==220 && gfx_height()==310 && gfx_bpp()==4);
    char index_path[512];snprintf(index_path,sizeof index_path,"%s/cases.tsv",argv[1]);
    FILE *index=fopen(index_path,"w");assert(index);
    char trace_path[512];snprintf(trace_path,sizeof trace_path,"%s/layout-issues.tsv",argv[1]);
    layout_log=fopen(trace_path,"w");assert(layout_log);
    fprintf(layout_log,"fixture\tissue\tx\ty\twidth\theight\ttext\n");
    unsigned rendered=0;
    for (unsigned n=first;n<sizeof fixture_names/sizeof fixture_names[0];++n) {
        bool pure_view=(n>=48 && n<56) || n>=96;
        if(argc==3 && !pure_view)continue;
        ++rendered;
        fixture_number=n;text_count=0;
        large_max_group_seen=large_max_source_seen=large_editor_seen=false;
        split_receive_seen=false;
        fixture_reset();
        if(n==0) {frequency=control.tx_frequency=0;control.state=RADIO_RX_UNAVAILABLE;mon_enabled=false;pref_state="defaults";pref_store.have=false;}
        if(n==1 || n==2) {editing=true;digit_count=n==1 ? 3 : 7;memcpy(frequency_digits,"4400750",7);control.state=RADIO_RX_PAUSED;}
        if(n==3) {owner_tx_inhibit=control.inhibit=false;control.tx_enabled=true;}
        if(n==4) {control.state=RADIO_TX_PREPARE;owner_tx_inhibit=control.inhibit=false;control.tx_enabled=true;}
        if(n==5) {menu_open=true;menu_item=3;control.state=RADIO_RX_PAUSED;}
        if(n==6 || n==7) {rx_lab=true;rx_checked=n==7;control.state=RADIO_RX_PAUSED;}
        if(n==8) {control.state=RADIO_FAULT;control.tx_enabled=false;session_enabled=false;reason="pcm_stalled";}
        if(n==9) {owner_tx_inhibit=control.inhibit=true;control.tx_enabled=false;reason="tx_inhibited";}
        if(n==10) {control.split=true;control.tx_frequency=445075000;control.nac=0xfff;control.talkgroup=65535;control.source_id=16777215;}
        if(n==11) {menu_open=true;menu_page=MENU_CHANNEL;menu_item=3;control.state=RADIO_RX_PAUSED;}
        if(n==12) {editing=true;field=EDIT_NAC;digit_count=3;memcpy(frequency_digits,"2AF",3);}
        if(n==13) {editing=true;field=EDIT_ID;digit_count=8;memcpy(frequency_digits,"16777215",8);}
        if(n==14) {control.split=true;control.tx_frequency=445075000;control.state=RADIO_TX_PREPARE;owner_tx_inhibit=control.inhibit=false;control.tx_enabled=true;}
        if(n==16) {menu_open=true;menu_page=MENU_DIAGNOSTICS;menu_item=2;control.state=RADIO_RX_PAUSED;}
        if(n==17) control.state=RADIO_RX_SYNC;
        if(n==18 || n==19 || n==20) {
            normal_mode=false;mon_local_tone=n==18;mon_output_tone=n==19;mon_replay=n==20;
            control.inhibit=true;control.tx_enabled=false;
            mon_reason=n==18 ? "local_delay" : n==20 ? "replay_delay" : "receiving";
        }
        if(n==21) {menu_open=true;menu_page=MENU_VOICE;menu_item=2;}
        if(n==22) {editing=true;field=EDIT_MIC;digit_count=2;memcpy(frequency_digits,"22",2);}
        if(n==23) control.state=RADIO_RX_VOICE;
        if(n==24 || n==25) {control.state=n==24 ? RADIO_TX_VOICE : RADIO_TX_DRAIN;owner_tx_inhibit=control.inhibit=false;control.tx_enabled=true;}
        if(n==26) {control.state=RADIO_RX_RESTORE;mon_reason="transmit";}
        if(n==27) {control.state=RADIO_RX_PAUSED;mon_reason="paused";}
        if(n==28) {mon_enabled=false;mon_failed=mon_used=true;mon_reason="queue_or_input_fault";control.state=RADIO_FAULT;control.tx_enabled=false;}
        if(n==29) {owner_tx_inhibit=control.inhibit=false;control.tx_enabled=true;ptt_release_required=true;}
        if(n==30) {pref_state="pending";pref_dirty=true;mic_gain_db=23;}
        if(n==31) {pref_store.writable=false;pref_state="read_only";}
        if(n==32) {pref_state="save_failed";pref_dirty=true;mic_gain_db=23;}
        if(n==33) {normal_mode=mon_enabled=false;control.inhibit=true;control.tx_enabled=false;control.state=RADIO_RX_PAUSED;mon_reason="cancelled";}
        if(n==34) {normal_mode=mon_enabled=false;tx_fixed=true;control.inhibit=false;control.tx_enabled=session_enabled=true;control.state=RADIO_RX_PAUSED;}
        if(n==35) {normal_mode=mon_enabled=false;control.inhibit=true;control.tx_enabled=false;menu_open=true;menu_page=MENU_DIAGNOSTICS;menu_item=2;control.state=RADIO_RX_PAUSED;}
        if(n==36 || n==37 || n==38) {
            rx_promiscuous=true;
            control.state=n==38 ? RADIO_RX_VOICE : n==37 ? RADIO_RX_SYNC : RADIO_RX_IDLE;
        }
        if(n==39 || n==40) {rx_promiscuous=n==40;menu_open=true;menu_item=2;control.state=RADIO_RX_PAUSED;}
        if(n==41 || n==42) {
            ptt_release_required=true;
            if(n==42) {owner_tx_inhibit=control.inhibit=true;control.tx_enabled=false;}
        }
        if(n>=43 && n<48) {
            monitor.call.active=true;monitor.call.nac=0x2a3;
            monitor.call.group_valid=monitor.call.source_valid=true;
            monitor.call.group=65535;monitor.call.source=16777215;
            monitor.call.state=n==43 ? P25_RX_CLEAR : n==44 ? P25_RX_ENCRYPTED
                : n==45 ? P25_RX_UNSUPPORTED : n==46 ? P25_RX_WAIT_METADATA : P25_RX_BAD_METADATA;
            if(n!=43)monitor.call.group_valid=monitor.call.source_valid=false;
            control.state=n==43 ? RADIO_RX_VOICE : RADIO_RX_SYNC;
        }
        switch(n) {
        case 56:
            fixture_profile(false,false,1,32,"LONGEST NAME");
            control.talkgroup=65535;control.source_id=16777215;break;
        case 57:fixture_profile(false,false,1,0,"");break;
        case 58:fixture_menu(MENU_ROOT,7);break;
        case 59:fixture_menu(MENU_ROOT,5);break;
        case 60:fixture_menu(MENU_CHANNEL,4);break;
        case 61:fixture_profile(true,false,0,0,"");fixture_menu(MENU_CHANNEL,5);break;
        case 62:channel_record[12]|=P25_CS_RX_ONLY;fixture_menu(MENU_CHANNEL,6);break;
        case 63:fixture_menu(MENU_MEMORY,0);break;
        case 64:fixture_profile(false,false,1,0,"");fixture_menu(MENU_MEMORY,1);break;
        case 65:fixture_menu(MENU_MEMORY,2);break;
        case 66:fixture_menu(MENU_MEMORY,3);break;
        case 67:fixture_menu(MENU_SCAN,0);break;
        case 68:global_record[12]=3;fixture_menu(MENU_SCAN,1);break;
        case 69:global_record[12]=3;channel_record[13]=8;fixture_menu(MENU_SCAN,2);break;
        case 70:radio_lights.screen_seconds=radio_lights.keypad_seconds=600;fixture_menu(MENU_DISPLAY,0);break;
        case 71:radio_lights.screen_seconds=radio_lights.keypad_seconds=0;fixture_menu(MENU_DISPLAY,1);break;
        case 72:fixture_menu(MENU_DISPLAY,2);break;
        case 73:
            fixture_profile(true,false,0,0,"");feature_put16(channel_record+26,0x4000u|670u);
            fixture_menu(MENU_FM,0);break;
        case 74:
            fixture_profile(true,true,0,0,"");feature_put16(channel_record+26,0x8000u|0023u);
            feature_put16(channel_record+28,0xc000u|0777u);fixture_menu(MENU_FM,5);break;
        case 75:fixture_editor(EDIT_MEMORY,"32");break;
        case 76:fixture_editor(EDIT_RECALL,"01");break;
        case 77:radio_lights.screen_seconds=600;fixture_editor(EDIT_SCREEN,"600");break;
        case 78:radio_lights.keypad_seconds=600;fixture_editor(EDIT_LIGHT,"600");break;
        case 79:
            fixture_profile(true,false,0,0,"");feature_put16(channel_record+26,0x4000u|1000u);
            fixture_editor(EDIT_TXTONE,"2600");break;
        case 80:
            fixture_profile(true,false,0,0,"");feature_put16(channel_record+28,0xc000u|0023u);
            fixture_editor(EDIT_RXTONE,"0777");break;
        case 81:fixture_profile(true,false,0,0,"");channel_record[30]=9;fixture_editor(EDIT_SQL,"9");break;
        case 82:radio_lights.locked=true;break;
        case 83:case 84:case 89:
            fixture_profile(n==89,false,1,32,"LONGEST NAME");
            channel_scan=(radio_scan){.cursor=31,.list=3,.running=true,.holding=n!=83};
            snprintf(channel_label,sizeof channel_label,"SCAN 4 / M32");
            if(n==84) {
                mon_have_sync=true;mon_sync_us=mon_voice_us=1000000u;
                monitor.call.active=true;monitor.call.state=P25_RX_CLEAR;monitor.call.nac=0x293;
                monitor.call.group_valid=monitor.call.source_valid=true;
                monitor.call.group=65535;monitor.call.source=16777215;control.state=RADIO_RX_VOICE;
            } else if(n==89) {analog_fm.running=analog_fm.audio_open=analog_fm.have_status=true;}
            break;
        case 85:case 86:case 87:case 88:case 92:
            fixture_profile(true,n==86 || n==88,0,0,"");analog_fm.running=true;
            if(n==85 || n==87)feature_put16(channel_record+28,0x4000u|2600u);
            if(n==86)feature_put16(channel_record+28,0xc000u|0777u);
            if(n==87)analog_fm.audio_open=analog_fm.have_status=true;
            if(n==88) {feature_put16(channel_record+26,0x8000u|0023u);control.state=RADIO_TX_VOICE;analog_fm.transmitting=true;}
            break;
        case 90:cps_link=true;break;
        case 91:
            rx_tg_filter=true;monitor.call.active=true;monitor.call.state=P25_RX_CLEAR;
            monitor.call.nac=0x293;monitor.call.group_valid=monitor.call.source_valid=true;
            monitor.call.group=1;monitor.call.source=16777215;control.state=RADIO_RX_SYNC;break;
        case 93:reason="empty_scan_list";break;
        case 94:reason="memory_saved";break;
        case 95:
            memset(channel_record,0,32);global_record[9]=1;feature_apply();
            mon_enabled=false;control.state=RADIO_RX_UNAVAILABLE;break;
        default:break;
        }
        // Populate the same fresh RF-strength cache used by the live view.
        // feature_apply deliberately clears old channel measurements.
        radio_signal_configure(&ui_strength,feature_fm() ? RADIO_SIGNAL_FM
            : RADIO_SIGNAL_P25,frequency,hrc_micros());
        radio_signal_sample(&ui_strength,hrc_micros(),-90);
        ui_rssi_valid=true;ui_rssi_dbm=-90;ui_rssi_bars=4;
        if(!pref_dirty && pref_store.have)pref_saved=pref_current();
        if(pure_view) {
            p25_ui_view view=view_fixture(n<56 ? n-48 : n-88);
            gfx_frame_begin();p25_ui_home(&view);gfx_flush();
        } else if((n>=43 && n<48) || n==84 || n==91) {
            // A running receiver uses the same view snapshot and call band.
            // Render that snapshot directly because screen() correctly refuses
            // full redraws while the real audio/recorder tasks are running.
            mon_running=true;p25_ui_view view=ui_view(n==43 || n==84 ? 2u : 1u);
            gfx_frame_begin();p25_ui_home(&view);gfx_flush();mon_running=false;
        } else screen("HOME");
        if(n==17 || n==23 || n==37 || n==38 || (n>=43 && n<48)) {
            mon_running=true;badge_only=true;gfx_frame_begin();
            mon_badge(n>=43 ? (n==43 ? 2 : 1) : n==17 || n==37 ? 1 : 2);
            gfx_flush();badge_only=false;mon_running=false;
        }
        if(n==41 || n==42) {
            ptt_release_required=false;mon_running=true;hint_only=true;hint_flushes=0;
            home_hint_refresh();assert(hint_flushes==1);hint_only=false;mon_running=false;
        }
        if(n==10 || n==43 || n==48 || n==49)
            assert(large_max_group_seen && large_max_source_seen);
        if(n==13)assert(large_editor_seen);
        if(n==14)assert(split_receive_seen);
        if(n==56)assert(text_visible("B M32 LONGEST NAME") && large_max_group_seen && large_max_source_seen);
        if(n==57 || n==95)assert(text_visible("VFO B"));
        if(n==58)assert(text_visible("Display & keys"));
        if(n==74)assert(text_visible("RX tone code") && !text_visible("Bandwidth"));
        if(n==77 || n==78)assert(text_visible("600"));
        if(n==79)assert(text_visible("2600"));
        if(n==80)assert(text_visible("0777"));
        if(n==82)assert(text_visible("Locked / hold OK + *") && text_visible("L"));
        if(n==85 || n==87 || n==92)assert(text_visible("NARROW FM"));
        if(n==86 || n==88)assert(text_visible("WIDE FM"));
        if(n==87 || n==89)assert(!ui_view(0).rx_muted); // FM never inherits stale P25 classification.
        if(n>=104) {
            assert(text_visible("DMR") && text_visible(n==106 ? "TO 16777215" : "TG 16777215"));
            if(n==105 || n==109 || n==110)assert(text_visible("TX CC 15 TS2"));
            if(n==107)assert(text_visible("Encrypted / muted"));
            if(n==108 || n==111)assert(text_visible("PROM"));
            if(n==110)assert(text_visible("DMR listening") && !text_visible("TRANSMITTING"));
        }
        char path[512];snprintf(path,sizeof path,"%s/live-%u.ppm",argv[1],n);
        fprintf(index,"live-%u.ppm\t%s\n",n,fixture_names[n]);
        FILE *file=fopen(path,"wb");assert(file);
        fprintf(file,"P6\n240 320\n255\n");
        for (unsigned y=0;y<320;++y) {
            uint8_t row[480];gfx_read_rgb565(y*480,row,sizeof row);
            for (unsigned x=0;x<240;++x) {
                unsigned rgb=row[x*2]|(unsigned)row[x*2+1]<<8;
                fputc((int)(((rgb>>11)&31)*255/31),file);
                fputc((int)(((rgb>>5)&63)*255/63),file);
                fputc((int)((rgb&31)*255/31),file);
            }
        }
        assert(!fclose(file));
    }
    partial_redraw_equivalence();
    assert(!fclose(index));
    assert(!fclose(layout_log));
    char report_path[512];snprintf(report_path,sizeof report_path,"%s/layout-report.json",argv[1]);
    FILE *report=fopen(report_path,"w");assert(report);
    fprintf(report,"{\"panel\":[240,320],\"safe_area\":[220,310],\"bpp\":4,\"fixtures\":%u,\"partial_redraw_cases\":48,\"large_maximum_ids_checked\":true,\"dmr_24bit_ids_and_context_checked\":true,\"new_feature_context_isolated\":true,\"text_draws\":%u,\"fitted_texts\":%u,\"layout_errors\":%u}\n",
        rendered,text_draws,fitted_texts,layout_errors);
    assert(!fclose(report));
    printf("Rendered %u unified radio states with actual fonts/4-bpp framebuffer; %u layout errors\n",
        rendered,layout_errors);
    return layout_errors ? 1 : 0;
}
