// SPDX-License-Identifier: GPL-3.0-or-later
// Actual application parser + actual atomic storage, using the established
// host-only HAL model. No serial device, MMIO or production source substitution.
#pragma GCC diagnostic push
// C implicitly returns zero only for the literal name "main". This included
// test entry is never called; all its real HAL helpers remain in this TU.
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main unused_live_adapter_main
#include "test_live_adapter.c"
#undef main
#pragma GCC diagnostic pop

#ifdef _WIN32
#define CPS_EXPORT __declspec(dllexport)
#else
#define CPS_EXPORT __attribute__((visibility("default")))
#endif

static void cps_boot(void) {
    reset();pref_flash_forbidden=false;preferences_restore();
    normal_mode=true;display_ok=false;mock_ptt_high=true;
    ptt_release_required=false;pref_dirty=false;
    assert(features_ready && !cps_active && !channel_store.staging);
}
CPS_EXPORT int cps_test_initialize(void) {
    pref_flash_forbidden=false;memset(pref_flash_mem,255,sizeof pref_flash_mem);
    p25_preferences legacy={440075000,440075000,0x293,10,1234567,0,22,0,0};
    pref_pack(pref_flash_mem,&legacy,7);cps_boot();return 1;
}
CPS_EXPORT int cps_test_reboot(void) {cps_boot();return 1;}
CPS_EXPORT int cps_test_command(const char *input,int down,int raw_released,char *reply,unsigned cap) {
    if(!input || !reply || !cap || strlen(input)>=sizeof command || strchr(input,'\n') || strchr(input,'\r'))return -1;
    output_n=0;output[0]=0;mock_ptt_high=raw_released!=0;
    issue(input,down!=0);
    assert(!rf_keys && !pa_keys && !hardware_running && !audio_on && !call_active);
    if(output_n>=cap)return -2;
    memcpy(reply,output,output_n);reply[output_n]=0;return (int)output_n;
}
CPS_EXPORT int cps_test_copy_active(uint8_t *out,unsigned cap) {
    if(cap<1120)return 0;
    for(unsigned k=0;k<35;++k)if(!p25_cs_read(&channel_store,k,out+k*32))return 0;
    return 1120;
}
CPS_EXPORT int cps_test_record_valid(unsigned key,const uint8_t *record) {
    return p25_cs_record_valid(key,record);
}
CPS_EXPORT unsigned cps_test_revision(void) {return channel_store.revision;}

static const char *cps(const char *input) {
    static char reply[8192];int size=cps_test_command(input,0,1,reply,sizeof reply);
    assert(size>0 && (unsigned)size<120);return reply;
}
static void cps_ack(const char *input,const char *expected) {
    const char *reply=cps(input);
    if(strcmp(reply,expected))fprintf(stderr,"CPS request: %s\nExpected: %sActual: %s",input,expected,reply);
    assert(!strcmp(reply,expected));
}
static void cps_put(unsigned key,const uint8_t *record) {
    char line[120],expected[64];int n=snprintf(line,sizeof line,"CPS PUT 11223344 %u ",key);
    for(unsigned i=0;i<32;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02X",record[i]);
    snprintf(expected,sizeof expected,"CPS OK PUT 11223344 %u\r\n",key);cps_ack(line,expected);
}
int main(void) {
    assert(cps_test_initialize());
    uint8_t original[1120],current[1120],changed[32];
    assert(cps_test_copy_active(original,sizeof original)==1120);
    unsigned revision=cps_test_revision();uint32_t crc=pref_crc(original,sizeof original);
    char line[120],expected[120];
    snprintf(expected,sizeof expected,"CPS HELLO DM32P25 2 32 2 %u %08X\r\n",revision,crc);
    cps_ack("CPS HELLO",expected);
    // Every wire record is the exact canonical bytes consumed by CHIRP.
    for(unsigned k=0;k<35;++k) {
        snprintf(line,sizeof line,"CPS GET %u",k);
        const char *reply=cps(line);unsigned key;char hex[65],extra;
        assert(sscanf(reply,"CPS DATA %u %64s %c",&key,hex,&extra)==2 && key==k);
        assert(feature_hex(hex,changed,32) && !memcmp(changed,original+k*32,32));
    }
    // A read-only session relinquishes ownership after its bounded idle time.
    normal_model model={0};
    now+=3000000u;normal_step(&model,false);
    assert(!cps_link && !cps_active && !channel_store.staging);
    const char *bad_begin[]={"CPS BEGIN 00000000 7","CPS BEGIN 1234567 7",
        "CPS BEGIN 11223344 -1","CPS BEGIN 11223344 4294967296"};
    for(unsigned i=0;i<sizeof bad_begin/sizeof bad_begin[0];++i) {
        assert(strstr(cps(bad_begin[i]),"CPS ERR "));
        assert(!channel_store.staging);
    }
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision+1u);
    assert(strstr(cps(line),"CPS ERR "));
    assert(!channel_store.staging);
    // Both debounced and physical held PTT reject even a read/handshake.
    char reply[128];
    assert(cps_test_command("CPS HELLO",1,1,reply,sizeof reply)>0 && strstr(reply,"CPS ERR BUSY"));
    assert(cps_test_command("CPS HELLO",0,0,reply,sizeof reply)>0 && strstr(reply,"CPS ERR BUSY"));
    mock_ptt_high=true;
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");
    for(unsigned tick=0;tick<10;++tick)normal_step(&model,true);
    for(unsigned tick=0;tick<10;++tick)normal_step(&model,false);
    assert(cps_active && channel_store.staging && !mon_running && !analog_fm.running);
    assert(!rf_keys && !pa_keys && !call_active && !hardware_running);
    cps_ack("CPS HELLO","CPS ERR TRANSACTION\r\n");
    memcpy(changed,original+32*32,32); // Copy valid VFO into memory 1.
    memset(changed+14,0,12);memcpy(changed+14,"CHIRP TEST",10);
    cps_put(0,changed);
    assert(cps_test_copy_active(current,sizeof current)==1120 && !memcmp(current,original,sizeof current));
    cps_ack("CPS COMMIT 11223344 00000000","CPS ERR COMMIT\r\n");
    assert(cps_test_copy_active(current,sizeof current)==1120 && !memcmp(current,original,sizeof current));
    assert(cps_test_reboot()); // Interrupted stage/bad CRC leaves old whole image.
    assert(cps_test_copy_active(current,sizeof current)==1120 && !memcmp(current,original,sizeof current));
    // A direct BEGIN also arms the staging timeout, even without prior HELLO.
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(0,changed);
    now+=60000000u;normal_step(&model,false);
    assert(!cps_active && !cps_link && !channel_store.staging);
    assert(cps_test_copy_active(current,sizeof current)==1120 && !memcmp(current,original,sizeof current));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(0,changed);
    cps_ack("CPS ABORT 11223344","CPS OK ABORT 11223344\r\n");
    assert(cps_test_reboot());
    assert(cps_test_copy_active(current,sizeof current)==1120 && !memcmp(current,original,sizeof current));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(0,changed);
    memcpy(current,original,sizeof current);memcpy(current,changed,32);
    crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+1u,crc);
    cps_ack(line,expected);
    assert(cps_test_reboot());
    assert(cps_test_copy_active(original,sizeof original)==1120 && !memcmp(current,original,sizeof current));
    assert(cps_test_revision()==revision+1u);
    // The V2 transaction retains the existing P25 profile while adding a
    // full24-bit private DMR destination and all per-channel modem options.
    memcpy(current,original,sizeof current);memcpy(changed,original+32*32,32);
    assert(radio_channel_set_mode(changed,RADIO_CHANNEL_DMR));
    assert(radio_channel_set_destination(changed,0xffffff) && radio_channel_set_color_code(changed,15) && radio_channel_set_timeslot(changed,2));
    radio_channel_set_private(changed,true);radio_channel_set_repeater(changed,true);changed[12]|=P25_CS_PROM;
    assert(p25_cs_record_valid(1,changed) && !p25_cs_record_valid_version(1,1,changed));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision+1u);cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(1,changed);
    memcpy(current+32,changed,32);crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+2u,crc);cps_ack(line,expected);
    assert(cps_test_reboot());assert(cps_test_copy_active(original,sizeof original)==1120 && !memcmp(current,original,sizeof current));
    puts("CPS adapter: actual parser/records/CRC/revision/PTT, aborted and reset staging, atomic committed reboot passed");
    return 0;
}
