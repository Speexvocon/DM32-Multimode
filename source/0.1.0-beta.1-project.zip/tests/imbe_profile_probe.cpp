// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
extern "C" void imbe_profile_mark(unsigned stage) {
    static unsigned expected;
    assert(stage==expected);
    expected=(expected+1)%8;
}
