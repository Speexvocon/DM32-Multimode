// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_test_tone.h"
#include <assert.h>
#include <math.h>
#include <string.h>
int main(void) {
    const unsigned frequencies[]={997,1000,1011};
    for(unsigned f=0;f<3;++f) {
        uint32_t phase=0;int16_t pcm[160],first[160];
        for(unsigned frame=0;frame<300;++frame) {
            p25_tone_frame(pcm,&phase,frequencies[f]);
            for(unsigned i=0;i<160;++i) {
                double expected=2000*sin(2*3.14159265358979323846*frequencies[f]*(frame*160+i)/8000);
                assert(fabs(pcm[i]-expected)<4.0);
            }
            if(!frame) {
                memcpy(first,pcm,sizeof first);
                assert((memcmp(pcm,pcm+32,64)==0)==(frequencies[f]==1000));
            }
            if(frame==1)assert((memcmp(first,pcm,sizeof first)==0)==(frequencies[f]==1000));
        }
        assert(phase==0); // Exactly six seconds; no frame/chunk phase reset or drift.
    }
    return 0;
}
