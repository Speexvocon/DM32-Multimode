"""Line RPC for browser-client tests against the real C parser; no hardware I/O."""
import ctypes
import json
from pathlib import Path
import sys


def main():
    library = ctypes.CDLL(str(Path(sys.argv[1]).resolve()))
    library.cps_test_command.argtypes = (ctypes.c_char_p, ctypes.c_int, ctypes.c_int,
                                        ctypes.c_void_p, ctypes.c_uint)
    library.cps_test_copy_active.argtypes = (ctypes.c_void_p, ctypes.c_uint)
    library.cps_test_revision.restype = ctypes.c_uint
    assert library.cps_test_initialize() == 1
    for line in sys.stdin:
        try:
            request = json.loads(line)
            action = request['action']
            if action == 'command':
                command = request['command']
                if not isinstance(command, str) or not command.startswith('CPS '):
                    raise ValueError('Only logical CPS commands are permitted in this bridge')
                output = ctypes.create_string_buffer(8192)
                count = library.cps_test_command(command.encode('ascii'), int(request.get('ptt', False)),
                                                 int(request.get('rawReleased', True)), output, len(output))
                if count <= 0:
                    raise ValueError('C parser refused the request framing')
                result = {'reply': output.raw[:count].decode('ascii')}
            elif action == 'reboot':
                assert library.cps_test_reboot() == 1
                result = {'revision': library.cps_test_revision()}
            elif action == 'active':
                payload = (ctypes.c_ubyte * 1120)()
                assert library.cps_test_copy_active(payload, len(payload)) == 1120
                result = {'payload': bytes(payload).hex(), 'revision': library.cps_test_revision()}
            elif action == 'validate':
                raw = bytes.fromhex(request['record'])
                if len(raw) != 32:
                    raise ValueError('A logical record has exactly 32 bytes')
                payload = (ctypes.c_ubyte * 32).from_buffer_copy(raw)
                library.cps_test_record_valid.argtypes = (ctypes.c_uint, ctypes.c_void_p)
                result = {'valid': bool(library.cps_test_record_valid(request['key'], payload))}
            else:
                raise ValueError('Unknown test action')
            print(json.dumps(result), flush=True)
        except Exception as error:
            print(json.dumps({'error': str(error)}), flush=True)


if __name__ == '__main__':
    main()
