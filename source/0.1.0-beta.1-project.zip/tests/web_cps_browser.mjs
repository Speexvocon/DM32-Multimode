// SPDX-License-Identifier: GPL-3.0-or-later
// Optional real-browser UI smoke test. All Web Serial access is replaced with
// the simulated fixture before the application loads. No real port is opened.
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { importFile } from '../integrations/web-cps/model.js';

const output = path.resolve('build/web-cps-browser-qa');
await fs.mkdir(output, { recursive: true });
const appUrl = new URL(process.env.CPS_URL || 'http://127.0.0.1:8765/');
assert(['127.0.0.1', 'localhost', '[::1]'].includes(appUrl.hostname), 'CPS_URL must be local loopback');
await fetch(appUrl).catch(error => { throw new Error('Start python scripts/serve-web-cps.py before running this optional browser test.', { cause: error }); });
const candidates = [process.env.CHROME_PATH,
  process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Google/Chrome/Application/chrome.exe'),
  process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Google/Chrome/Application/chrome.exe'),
  process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft/Edge/Application/msedge.exe'),
  '/usr/bin/google-chrome', '/usr/bin/chromium'].filter(Boolean);
let chromePath;
for (const candidate of candidates) { try { await fs.access(candidate); chromePath = candidate; break; } catch { /* Next installed browser. */ } }
if (!chromePath) throw new Error('No installed Chromium browser found. Set CHROME_PATH to Chrome or Edge; this test does not install a browser.');
const profile = path.join(output, `chrome-profile-${process.pid}-${Date.now()}`);
await fs.mkdir(profile, { recursive: true });
const chrome = spawn(chromePath, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--disable-background-networking',
  '--no-first-run', '--no-default-browser-check', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'],
  { windowsHide: true, stdio: 'ignore' });
let launchError;
chrome.on('error', error => { launchError = error; });
let debugPort;
for (let i = 0; i < 100; i++) {
  if (launchError) throw launchError;
  try { debugPort = Number((await fs.readFile(path.join(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]); break; } catch { await new Promise(resolve => setTimeout(resolve, 100)); }
}
if (!debugPort) { chrome.kill(); throw new Error('The isolated headless browser did not start within 10 seconds.'); }
const targets = await (await fetch(`http://127.0.0.1:${debugPort}/json/list`)).json();
const target = targets.find(target => target.type === 'page');
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
let id = 0;
const pending = new Map(), errors = [], results = [], consoleErrors = [];
ws.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  if (message.id) {
    const request = pending.get(message.id);
    if (!request) return;
    pending.delete(message.id); clearTimeout(request.timer);
    message.error ? request.reject(new Error(message.error.message)) : request.resolve(message.result);
  } else if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails);
  else if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') consoleErrors.push(message.params);
});
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const key = ++id;
    const timer = setTimeout(() => { pending.delete(key); reject(new Error(`CDP timed out: ${method}`)); }, 12000);
    pending.set(key, { resolve, reject, timer });
    ws.send(JSON.stringify({ id: key, method, params }));
  });
}
async function evaluate(fn, ...args) {
  const result = await send('Runtime.evaluate', { expression: `(${fn.toString()})(...${JSON.stringify(args)})`, awaitPromise: true, returnByValue: true });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
  return result.result.value;
}
async function wait(fn, label) {
  const end = Date.now() + 8000;
  while (Date.now() < end) {
    if (await evaluate(fn)) return;
    await new Promise(resolve => setTimeout(resolve, 80));
  }
  throw new Error(`Timed out waiting for ${label}`);
}
async function click(text) {
  if (text === 'Connect radio') assert.equal(await evaluate(() => window.__cpsPeer?.simulated === true &&
    Object.hasOwn(navigator, 'serial') && navigator.serial.requestPort.toString().includes('peer.requestCount')), true,
  'The simulated serial API must replace native Web Serial before any Connect action');
  const found = await evaluate(text => {
    const button = [...document.querySelectorAll('dialog[open] button,button')].find(button => button.textContent.trim() === text && !button.disabled);
    if (!button) return false;
    button.click(); return true;
  }, text);
  assert(found, `Enabled button ${text}`);
}
async function byLabel(label, value, selector = 'input,select') {
  const found = await evaluate((label, value, selector) => {
    const scope = document.querySelector('dialog[open]') || document;
    const container = [...scope.querySelectorAll('label.field')].find(field => !field.closest('[hidden]') && field.firstElementChild?.textContent.trim() === label);
    const input = container?.querySelector(selector);
    if (!input) return false;
    input.value = value;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }, label, value, selector);
  assert(found, `Field ${label}`);
}
async function screenshot(name, width = 1440, height = 1000) {
  await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: width < 600 });
  const image = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  await fs.writeFile(path.join(output, name), Buffer.from(image.data, 'base64'));
}
async function chooseFile(file) {
  const { root } = await send('DOM.getDocument');
  const { nodeId } = await send('DOM.querySelector', { nodeId: root.nodeId, selector: 'input[type=file]' });
  await send('DOM.setFileInputFiles', { nodeId, files: [file] });
}
async function test(name, fn) {
  await fn(); results.push({ name, pass: true }); console.log(`PASS ${name}`);
}

try {
  await send('Page.enable'); await send('Runtime.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  const fixture = await fs.readFile('integrations/web-cps/tests/browser_serial_fixture.js', 'utf8');
  await send('Page.addScriptToEvaluateOnNewDocument', { source: fixture });
  await send('Page.navigate', { url: appUrl.href });
  await wait(() => document.querySelector('h1')?.textContent === 'Channels' && window.__cpsPeer, 'editor startup');
  await evaluate(async () => await window.__cpsPeer.ready);
  await test('offline startup: 32 memories, write disabled, fixture installed before app', async () => {
    assert.equal(await evaluate(() => document.querySelectorAll('#channel-rows tr').length), 32);
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
    assert.equal(await evaluate(() => window.__cpsPeer.requestCount), 0);
    assert.equal(await evaluate(() => { const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); while (walker.nextNode()) if (walker.currentNode.textContent.trim() === 'null') return true; return false; }), false);
    await screenshot('01-offline.png');
  });
  await test('sample and inline edits have no serial side effects; undo/redo', async () => {
    await click('Load example');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'P25 SIMPLEX');
    await evaluate(() => { const input = document.querySelector('[aria-label="Memory 1 name"]'); input.value = 'MY LOCAL'; input.dispatchEvent(new Event('change', { bubbles: true })); });
    await click('Undo'); assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'P25 SIMPLEX');
    await click('Redo'); assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'MY LOCAL');
    assert.equal(await evaluate(() => window.__cpsPeer.commands.length), 0);
    await screenshot('02-channels.png');
  });
  await test('P25 detail form includes transmit frequency, NAC, talkgroup, filter and lists', async () => {
    await evaluate(() => document.querySelector('[aria-label="Edit memory 1 details"]').click());
    await byLabel('Transmit frequency · MHz', '145.600000');
    await byLabel('NAC · hexadecimal', '2A3');
    await byLabel('Transmit talkgroup', '123');
    await byLabel('Receive filter', 'NAC+TG');
    await screenshot('03-channel-details.png');
    await click('Apply channel');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 NAC"]').value), '2A3');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 transmit talkgroup"]').value), '123');
  });
  await test('DMR editor uses CC, 24-bit destination, slot and framing without P25 or FM controls', async () => {
    await evaluate(() => document.querySelector('[aria-label="Edit memory 3 details"]').click());
    await byLabel('Mode', 'DMR');
    await byLabel('Destination ID', '16777215');await byLabel('Color code', '15');
    await byLabel('Timeslot', '2');await byLabel('Call type', 'private');
    await byLabel('Operation', 'repeater');await byLabel('Receive filter', 'PROM');
    assert.equal(await evaluate(() => [...document.querySelectorAll('dialog section:not([hidden]) h3')].map(x => x.textContent).join(',')), 'DMR call settings');
    assert.equal(await evaluate(() => document.querySelector('dialog').textContent.includes('does not monitor both slots')), true);
    await screenshot('11-dmr-channel-details.png');await click('Apply channel');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 3 destination ID"]').value), '16777215');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 3 color code"]').value), '15');
    assert.equal(await evaluate(() => window.__cpsPeer.commands.length), 0);
  });
  await test('VFO, scan, global settings and responsive layout', async () => {
    await click('VFO A / B2');
    await screenshot('04-vfos.png');
    await click('Scan lists4');
    await screenshot('05-scan-lists.png');
    await click('Radio settings');
    await byLabel('Source / radio ID', '1234567');
    await byLabel('P25 microphone gain · dB', '22');
    await byLabel('Screen backlight · seconds', '90');
    await byLabel('Keypad light · seconds', '20');
    await screenshot('06-radio-settings.png');
    await screenshot('07-mobile-settings.png', 390, 844);
    assert.equal(await evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  });
  await test('connect alone cannot write; explicit read establishes baseline', async () => {
    await click('Connect radio');
    await wait(() => document.querySelector('.connection-title')?.textContent.includes('DM32 connected'), 'fake connection');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 0);
    await click('Read radio');
    await click('Replace working copy');
    await wait(() => document.body.textContent.includes('Read complete.'), 'radio read');
    await click('Channels2');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'P25 TEST');
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 0);
  });
  await test('review presents readable old/new channel and global values, preserving tones across bandwidth changes', async () => {
    await evaluate(() => document.querySelector('[aria-label="Edit memory 1 details"]').click());
    await byLabel('Receive frequency · MHz', '145.725000');
    await byLabel('Transmit frequency · MHz', '145.725000');
    await byLabel('NAC · hexadecimal', '2A3');
    await byLabel('Transmit talkgroup', '123');
    await byLabel('Receive filter', 'PROM');
    await evaluate(() => [...document.querySelectorAll('dialog .inline-options input')].forEach((input, i) => { input.checked = i === 1 || i === 3; }));
    await click('Apply channel');
    await evaluate(() => document.querySelector('[aria-label="Edit memory 2 details"]').click());
    await byLabel('Transmit tone', '123.0', 'input');
    await byLabel('Mode', 'FM');
    assert.equal(await evaluate(() => [...document.querySelectorAll('dialog label.field')].find(label => label.firstElementChild?.textContent === 'Transmit tone').querySelector('input').value), '123.0');
    await byLabel('Receive tone', 'dcs', 'select');
    await byLabel('Squelch', '7');
    await click('Apply channel');
    await click('Radio settings');
    await byLabel('Source / radio ID', '3166362');
    await byLabel('P25 microphone gain · dB', '24');
    await byLabel('Screen backlight · seconds', '0');
    await byLabel('Keypad light · seconds', '30');
    await byLabel('Active VFO context', '1');
    await byLabel('Context A uses', '2');
    await byLabel('Selected scan list', '2');
    await evaluate(() => { const input = [...document.querySelectorAll('label.check-label')].find(label => label.textContent === 'Inhibit all transmission').querySelector('input'); input.checked = true; input.dispatchEvent(new Event('change', { bubbles: true })); });
    await click('Review & write');
    const review = await evaluate(() => document.querySelector('dialog').textContent);
    for (const expected of ['RX frequency: 145.700000 MHz → 145.725000 MHz', 'NAC: 293 → 2A3',
      'Talkgroup: 10 → 123', 'Scan membership: List 1, List 3 → List 2, List 4',
      'TX tone: 88.5 Hz CTCSS → 123.0 Hz CTCSS', 'RX tone: 023 DCS inverted → 023 DCS',
      'Squelch: Level 4 → Level 7', '22 dB → 24 dB', '60 seconds → Always on',
      'Context A → Context B', 'Memory 01 · P25 TEST → Memory 02 · FM TEST', 'List 1 → List 3', 'PTT enabled → Inhibited'])
      assert(review.includes(expected), `Review includes ${expected}`);
    await screenshot('10-readable-full-review.png');
    await click('Cancel');
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 0);
    await click('Read radio'); await click('Replace working copy');
    await wait(() => document.body.textContent.includes('Read complete.'), 'restore fixture baseline');
    await click('Channels2');
  });
  await test('explicit review/cancel does not write; reviewed commit updates the radio baseline', async () => {
    await evaluate(() => { const input = document.querySelector('[aria-label="Memory 1 name"]'); input.value = 'CPS ROUNDTRP'; input.dispatchEvent(new Event('change', { bubbles: true })); });
    await click('Review & write');
    assert.equal(await evaluate(() => document.querySelector('dialog')?.textContent.includes('Memory 1')), true);
    await screenshot('08-review-write.png');
    await click('Cancel'); assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 0);
    await click('Review & write'); await click('Write to radio');
    await wait(() => document.body.textContent.includes('Write verified.'), 'verified commit');
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 1);
    assert.equal(await evaluate(async () => { const model = await import('/model.js'); return model.decodePayload(window.__cpsPeer.payload).channels[0].name; }), 'CPS ROUNDTRP');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
  });
  await test('stale revision refuses commit, retains edits and invalidates upload baseline', async () => {
    await evaluate(() => { const input = document.querySelector('[aria-label="Memory 1 name"]'); input.value = 'STALE EDIT'; input.dispatchEvent(new Event('change', { bubbles: true })); window.__cpsPeer.bumpRevision(); });
    await click('Review & write'); await click('Write to radio');
    await wait(() => document.body.textContent.includes('Upload stopped:'), 'stale refusal');
    assert.equal(await evaluate(() => document.querySelector('.notice.error').textContent.includes('commit may')), false);
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 1);
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'STALE EDIT');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
  });
  await test('disconnect retains working copy and clears baseline', async () => {
    await click('Disconnect');
    await wait(() => document.querySelector('.connection-title')?.textContent.includes('Work on your codeplug'), 'disconnect');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'STALE EDIT');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
  });
  await test('Save file downloads and reopens a complete local codeplug without a serial write', async () => {
    const downloads = path.join(output, `downloads-${Date.now()}`);
    await fs.mkdir(downloads, { recursive: true });
    await send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: downloads });
    await click('Save file');
    let files;
    for (let i = 0; i < 30; i++) {
      files = (await fs.readdir(downloads)).filter(name => name.endsWith('.json'));
      if (files.length) break;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    assert.equal(files.length, 1);
    const saved = importFile(await fs.readFile(path.join(downloads, files[0]), 'utf8'));
    assert.equal(saved.model.channels[0].name, 'STALE EDIT');
    assert.equal(saved.model.channels[1].rxTone.type, 'dcs-inv');
    assert.equal(saved.model.channels[1].rxTone.value, 0o23);
    assert.equal(saved.model.settings.sourceId, 1234567);
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 1);
  });
  const importedPath = path.join(output, 'import-with-untrusted-origin.dm32.json');
  const importedText = await evaluate(async () => {
    const api = await import('/model.js');
    const model = api.decodePayload(window.__cpsPeer.payload);
    model.channels[0].name = 'FILE PROFILE';
    model.settings.screenSeconds = 123;
    return api.exportFile(model, { revision: 999, crc: 123 });
  });
  await fs.writeFile(importedPath, importedText);
  await test('offline Open preserves full data but file origin cannot authorize an upload', async () => {
    await chooseFile(importedPath);
    await wait(() => document.body.textContent.includes('Codeplug opened locally.'), 'offline import');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'FILE PROFILE');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 1);
    await click('Connect radio');
    await wait(() => document.querySelector('.connection-title')?.textContent.includes('DM32 connected'), 'reconnect');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
  });
  await test('Open after a real read keeps the actual radio baseline, not the imported origin', async () => {
    await click('Read radio');
    await wait(() => document.body.textContent.includes('Read complete.'), 'new read');
    await chooseFile(importedPath);
    await wait(() => document.body.textContent.includes('Codeplug opened locally.'), 'import after read');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), false);
    await click('Review & write');
    assert.equal(await evaluate(() => document.querySelector('dialog')?.textContent.includes('radio revision 999')), false);
    await click('Write to radio');
    await wait(() => document.body.textContent.includes('Write verified.'), 'file upload');
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 2);
    assert.equal(await evaluate(async () => (await import('/model.js')).decodePayload(window.__cpsPeer.payload).settings.screenSeconds), 123);
  });
  await test('uncertain COMMIT is never repeated, blocks all edits while busy, retains draft and requires a fresh read', async () => {
    await evaluate(() => { const input = document.querySelector('[aria-label="Memory 1 name"]'); input.value = 'UNCERTAIN'; input.dispatchEvent(new Event('change', { bubbles: true })); window.__cpsPeer.dropCommitReply = true; });
    const commitBefore = await evaluate(() => window.__cpsPeer.commands.filter(command => command.startsWith('CPS COMMIT ')).length);
    await click('Review & write'); await click('Write to radio');
    await wait(() => window.__cpsPeer.commitCount === 3 && document.querySelector('.progress-label'), 'applied commit with missing acknowledgement');
    assert.equal(await evaluate(() => [...document.querySelectorAll('#app button,#app input,#app select')].every(control => control.disabled)), true);
    await wait(() => document.body.textContent.includes('Upload stopped:'), 'uncertain commit timeout');
    assert.equal(await evaluate(() => document.querySelector('.notice.error').textContent.includes('commit may have completed')), true);
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'UNCERTAIN');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
    assert.equal(await evaluate(() => window.__cpsPeer.commands.filter(command => command.startsWith('CPS COMMIT ')).length), commitBefore + 1);
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].some(b => b.textContent.trim() === 'Disconnect' && !b.disabled)), true);
    await screenshot('09-uncertain-upload.png');
    await click('Disconnect');
    await evaluate(() => { window.__cpsPeer.dropCommitReply = false; });
    await click('Connect radio');
    await wait(() => document.querySelector('.connection-title')?.textContent.includes('DM32 connected'), 'reconnect after uncertainty');
    assert.equal(await evaluate(() => [...document.querySelectorAll('button')].find(b => b.textContent.trim() === 'Review & write').disabled), true);
    await click('Read radio'); await click('Replace working copy');
    await wait(() => document.body.textContent.includes('Read complete.'), 'fresh read resolves uncertainty');
    assert.equal(await evaluate(() => document.querySelector('[aria-label="Memory 1 name"]').value), 'UNCERTAIN');
    assert.equal(await evaluate(() => window.__cpsPeer.commitCount), 3);
    await click('Disconnect');
  });
  assert.deepEqual(errors, [], 'No uncaught browser exceptions');
  assert.deepEqual(consoleErrors, [], 'No console errors');
  const sourceHashes = {};
  for (const source of ['index.html', 'styles.css', 'app.js', 'model.js', 'transport.js', 'vendor/undo.js', 'tests/browser_serial_fixture.js'])
    sourceHashes[source] = createHash('sha256').update(await fs.readFile(path.join('integrations/web-cps', source))).digest('hex');
  await fs.writeFile(path.join(output, 'report.json'), JSON.stringify({ pass: true, browser: await send('Browser.getVersion'), simulatedSerialOnly: true,
    tests: results, sourceHashes, uncaughtExceptions: errors, consoleErrors, at: new Date().toISOString() }, null, 2));
} catch (error) {
  await fs.writeFile(path.join(output, 'report.json'), JSON.stringify({ pass: false, simulatedSerialOnly: true, tests: results,
    error: error.stack, uncaughtExceptions: errors, consoleErrors, at: new Date().toISOString() }, null, 2));
  throw error;
} finally {
  try { await send('Browser.close'); } catch { /* The process can already be gone. */ }
  ws.close();
  if (chrome.exitCode === null) chrome.kill();
}
