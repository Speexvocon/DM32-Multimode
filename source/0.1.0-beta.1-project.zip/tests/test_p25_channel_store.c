// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "p25_channel_store.h"

static uint8_t memory[32768],snapshot[32768];
static int write_budget=-1,erase_budget=-1,read_budget=-1;
static unsigned writes,erases,reads;
static bool rd(uint32_t addr,void *out,uint32_t bytes) {
    assert(addr>=0x711000 && addr+bytes<=0x719000);++reads;
    if(!read_budget)return false;
    if(read_budget>0)--read_budget;
    memcpy(out,memory+addr-0x711000,bytes);return true;
}
static bool wr(uint32_t addr,const void *in,uint32_t bytes) {
    assert(addr>=0x711000 && addr+bytes<=0x719000);++writes;
    const uint8_t *p=in;
    for(unsigned i=0;i<bytes;++i) {
        if(!write_budget)return false;
        if(write_budget>0)--write_budget;
        uint8_t *dst=memory+addr-0x711000+i;
        assert((*dst&p[i])==p[i]);*dst&=p[i];
    }
    return true;
}
static bool erase(uint32_t addr) {
    assert(addr>=0x711000 && addr<0x719000 && !(addr%4096));++erases;
    for(unsigned i=0;i<4096;++i) {
        if(!erase_budget)return false;
        if(erase_budget>0)--erase_budget;
        memory[addr-0x711000+i]=255;
    }
    return true;
}
static const hal_flash_map_t map={.settings_addr=0x711000,.settings_size=32768};
static const hal_flash_t flash={.size=0x1000000,.erase_size=4096,.read=rd,.write=wr,.erase=erase,.map=&map};
static const p25_preferences old={145700000,145700000,0x293,10,1234567,0,22,0,1};
static const uint8_t v3[64]={
 0x50,0x32,0x35,0x50,0x03,0x00,0x00,0x00,
 0x09,0x00,0x00,0x00,0xa0,0x34,0xaf,0x08,
 0xa0,0x34,0xaf,0x08,0x93,0x02,0x00,0x00,
 0x0a,0x00,0x00,0x00,0x87,0xd6,0x12,0x00,
 0x00,0x00,0x00,0x00,0x16,0x00,0x00,0x00,
 0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
 0x8e,0x84,0xa5,0x0c,0x00,0x00,0x00,0x00,
};
static void fresh(void) {
    memset(memory,255,sizeof memory);write_budget=erase_budget=read_budget=-1;
    writes=erases=reads=0;
}
static void old_slot(unsigned slot,uint32_t sequence) {
    p25_preferences p=old;pref_pack(memory+64*slot,&p,sequence);
}
static void get(p25_cs_store *s,unsigned key,uint8_t *r) {assert(p25_cs_read(s,key,r));}
static void finish(p25_cs_store *s) {
    uint32_t crc;assert(p25_cs_stage_crc(s,&crc));assert(p25_cs_commit(s,crc));
}
static void named(uint8_t *r,const char *name) {
    memset(r,0,32);pref_put(r,440075000);pref_put(r+4,445075000);
    p25_cs_put16(r+8,0x293);p25_cs_put16(r+10,10);
    r[12]=P25_CS_OCCUPIED|P25_CS_TG_FILTER;r[13]=15;r[30]=5;
    memcpy(r+14,name,strlen(name));assert(p25_cs_record_valid(0,r));
}
static void test_defaults_and_legacy(void) {
    p25_cs_store s;uint8_t r[32],before[64];p25_preferences legacy;
    fresh();assert(p25_cs_open(&s,&flash) && s.writable && !s.have_active && !s.have_legacy);
    get(&s,P25_CS_VFO_A,r);assert(p25_cs_zero(r,32));
    get(&s,P25_CS_GLOBAL,r);assert(pref_get(r)==1 && r[4]==11 && p25_cs_get16(r+5)==60 && p25_cs_get16(r+7)==15);
    assert(!writes && !erases && !s.revision);
    assert(p25_cs_begin(&s,0));finish(&s);
    assert(p25_cs_open(&s,&flash) && s.have_active && s.revision==1);
    for(unsigned version=1;version<=3;++version) {
        fresh();memcpy(memory+511*64,v3,64);pref_put(memory+511*64+4,version);
        pref_put(memory+511*64+56,pref_crc(memory+511*64,56));memcpy(before,memory+511*64,64);
        assert(p25_cs_open(&s,&flash) && s.writable && s.have_legacy && !s.have_active && s.revision==9);
        get(&s,P25_CS_VFO_A,r);assert(pref_get(r)==145700000 && p25_cs_get16(r+10)==10);
        assert(((r[12]>>2)&3u)==(version==3 ? 1u : 0u));
        get(&s,P25_CS_GLOBAL,r);assert(pref_get(r)==1234567 && r[4]==22 && !r[13]);
        if(version==3) {uint32_t crc;assert(p25_cs_stage_crc(&s,&crc) && crc==0x9b783528u);}
        assert(!writes && !erases && !memcmp(before,memory+511*64,64));
        assert(p25_cs_begin(&s,9));finish(&s);
        assert(s.active_bank==0 && s.revision==10 && !memcmp(before,memory+511*64,64));
        assert(!memcmp(before,memory+64,64));
        p25_pref_store downgrade;
        assert(pref_load(&downgrade,&flash,&legacy) && !downgrade.writable && legacy.id==1234567 && legacy.tg==10);
    }
}
static void test_record_semantics(void) {
    uint8_t r[32],bad[32];named(r,"REPEATER");
    assert(p25_cs_record_valid(31,r) && p25_cs_record_valid(P25_CS_VFO_B,r));
    assert(!p25_cs_record_valid(35,r));
    for(unsigned i=0;i<32;++i) {
        memset(bad,0,32);bad[i]=1;
        // An unoccupied record may not hide settings or noncanonical bytes.
        if(i!=12)assert(!p25_cs_record_valid(0,bad));
    }
    memcpy(bad,r,32);bad[12]|=0x80;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[12]|=12;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[13]=16;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[14]=0;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[14]=127;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[30]=10;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[31]=1;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[12]|=P25_CS_WIDE;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);p25_cs_put16(bad+26,0x4000|670);assert(!p25_cs_record_valid(0,bad));
    bad[12]|=P25_CS_FM|P25_CS_WIDE;assert(p25_cs_record_valid(0,bad));
    p25_cs_put16(bad+26,0x4000|599);assert(!p25_cs_record_valid(0,bad));
    p25_cs_put16(bad+26,0x4000|2600);p25_cs_put16(bad+28,0xc000|511);assert(p25_cs_record_valid(0,bad));
    p25_cs_put16(bad+28,0xc000|512);assert(!p25_cs_record_valid(0,bad));
    p25_cs_store s;fresh();assert(p25_cs_open(&s,&flash));get(&s,P25_CS_GLOBAL,r);
    assert(p25_cs_record_valid(P25_CS_GLOBAL,r));
    for(unsigned i=14;i<32;++i) {memcpy(bad,r,32);bad[i]=1;assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));}
    memcpy(bad,r,32);p25_cs_put16(bad+5,601);assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
    memcpy(bad,r,32);p25_cs_put16(bad+7,601);assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
    memcpy(bad,r,32);bad[9]=2;assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
    memcpy(bad,r,32);bad[10]=33;assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
}
static void test_dmr_helpers_and_semantics(void) {
    uint8_t r[32],common[32],bad[32];named(r,"DMR MEMORY");memcpy(common,r,32);
    assert(radio_channel_set_mode(r,RADIO_CHANNEL_DMR) && radio_channel_get_mode(r)==RADIO_CHANNEL_DMR);
    assert(!memcmp(r,common,8) && !memcmp(r+13,common+13,13) && (r[12]&P25_CS_OCCUPIED));
    assert(radio_channel_get_destination(r)==1 && radio_channel_get_color_code(r)==1 && radio_channel_get_timeslot(r)==1);
    assert(!radio_channel_get_private(r) && !radio_channel_get_repeater(r));
    assert(p25_cs_record_valid(0,r) && !p25_cs_record_valid_version(1,0,r));
    assert(!radio_channel_set_destination(r,0) && !radio_channel_set_destination(r,0x1000000));
    assert(!radio_channel_set_color_code(r,16) && !radio_channel_set_timeslot(r,0) && !radio_channel_set_timeslot(r,3));
    for(unsigned cc=0;cc<16;++cc)for(unsigned ts=1;ts<=2;++ts)for(unsigned kind=0;kind<4;++kind) {
        assert(radio_channel_set_destination(r,0xffffff) && radio_channel_set_color_code(r,cc) && radio_channel_set_timeslot(r,ts));
        radio_channel_set_private(r,(kind&1)!=0);radio_channel_set_repeater(r,(kind&2)!=0);
        assert(radio_channel_get_destination(r)==0xffffff && radio_channel_get_color_code(r)==cc && radio_channel_get_timeslot(r)==ts);
        assert(radio_channel_get_private(r)==((kind&1)!=0) && radio_channel_get_repeater(r)==((kind&2)!=0));
        assert(p25_cs_record_valid(33,r));
    }
    for(unsigned filter=0;filter<3;++filter){r[12]=(uint8_t)((r[12]&~12u)|(filter<<2));assert(p25_cs_record_valid(0,r));}
    r[12]&=(uint8_t)~12u;
    for(unsigned flag=2;flag<=128;flag<<=1)if(flag!=4 && flag!=8 && flag!=16 && flag!=64) {
        memcpy(bad,r,32);bad[12]|=(uint8_t)flag;assert(!p25_cs_record_valid(0,bad));
    }
    memcpy(bad,r,32);bad[11]|=128;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[26]=1;assert(!p25_cs_record_valid(0,bad));
    assert(radio_channel_set_mode(r,RADIO_CHANNEL_P25));
    assert(p25_cs_get16(r+8)==0x293 && radio_channel_get_destination(r)==1 && p25_cs_record_valid(0,r));
    assert(!radio_channel_set_color_code(r,1) && !radio_channel_set_timeslot(r,1));
    assert(radio_channel_set_mode(r,RADIO_CHANNEL_FM) && p25_cs_record_valid(0,r));
}
static void make_v1_banks(void) {
    for(unsigned offset=0;offset<sizeof memory;offset+=64)if(pref_get(memory+offset)==P25_CS_MAGIC) {
        memory[offset+4]=1;pref_put(memory+offset+56,pref_crc(memory+offset,56));
    }
}
static void test_v1_snapshot_migration_and_mixed_versions(void) {
    p25_cs_store s,boot;uint8_t old_records[1120],read[32],dmr[32];uint32_t before_crc,after_crc;
    fresh();memcpy(memory+500*64,v3,64);assert(p25_cs_open(&s,&flash));assert(p25_cs_begin(&s,s.revision));
    named(read,"P25 KEPT");assert(p25_cs_stage_write(&s,0,read));read[12]|=P25_CS_FM;
    p25_cs_put16(read+26,0x4000|885);assert(p25_cs_stage_write(&s,1,read));finish(&s);make_v1_banks();
    unsigned w=writes,e=erases;assert(p25_cs_open(&s,&flash) && s.active_version==1 && s.writable && writes==w && erases==e);
    for(unsigned k=0;k<35;++k)get(&s,k,old_records+k*32);
    assert(p25_cs_stage_crc(&s,&before_crc));memcpy(snapshot,memory,sizeof memory);
    // A V2 transaction must recover either the untouched V1 snapshot or the
    // entire committed V2 image, including when erase/program is interrupted.
    const int cuts[]={0,1,59,60,63,64,65,127,128,200,511,512,1023,2047,2303,2367,2368};
    for(unsigned i=0;i<sizeof cuts/sizeof cuts[0];++i) {
        memcpy(memory,snapshot,sizeof memory);assert(p25_cs_open(&s,&flash));write_budget=cuts[i];
        bool done=p25_cs_begin(&s,s.revision);named(dmr,"DMR NEW");assert(radio_channel_set_mode(dmr,RADIO_CHANNEL_DMR));
        assert(radio_channel_set_destination(dmr,0x123456));
        if(done)done=p25_cs_stage_write(&s,2,dmr) && p25_cs_stage_crc(&s,&after_crc) && p25_cs_commit(&s,after_crc);
        write_budget=-1;assert(p25_cs_open(&boot,&flash) && (!done || boot.writable) && boot.active_version==(done ? 2 : 1));
        for(unsigned k=0;k<35;++k){get(&boot,k,read);assert(!memcmp(read,done && k==2 ? dmr : old_records+k*32,32));}
    }
    memcpy(memory,snapshot,sizeof memory);assert(p25_cs_open(&s,&flash));assert(p25_cs_begin(&s,s.revision));finish(&s);
    assert(p25_cs_open(&boot,&flash) && boot.active_version==2 && boot.writable && p25_cs_stage_crc(&boot,&after_crc) && before_crc==after_crc);
    // A committed record from another supported version cannot satisfy a V2
    // bank header, even if its payload, record CRC and bank payload CRC agree.
    unsigned slot=boot.active_bank*16384+boot.active_slot[0]*64;memory[slot+4]=1;pref_put(memory+slot+56,pref_crc(memory+slot,56));
    assert(p25_cs_open(&s,&flash) && s.active_version==1 && s.writable);
    for(unsigned k=0;k<35;++k){get(&s,k,read);assert(!memcmp(read,old_records+k*32,32));}
}
static void test_transactions_and_crc(void) {
    p25_cs_store s,boot;uint8_t r[32],global[32],read[32];uint32_t crc;
    fresh();memcpy(memory+200*64,v3,64);assert(p25_cs_open(&s,&flash));
    assert(!p25_cs_begin(&s,8) && !writes && !erases);
    assert(p25_cs_begin(&s,9) && !p25_cs_begin(&s,9));named(r,"LOCAL");
    assert(p25_cs_stage_write(&s,0,r));get(&s,0,read);assert(p25_cs_zero(read,32));
    assert(p25_cs_stage_read(&s,0,read) && !memcmp(r,read,32));
    get(&s,P25_CS_GLOBAL,global);global[10]=1;global[11]=1;
    assert(p25_cs_stage_write(&s,P25_CS_GLOBAL,global));assert(p25_cs_stage_crc(&s,&crc));
    assert(!p25_cs_commit(&s,crc^1));assert(p25_cs_commit(&s,crc));
    assert(s.revision==10 && !s.staging && s.have_active);
    assert(p25_cs_open(&boot,&flash) && boot.revision==10 && boot.writable);
    get(&boot,0,read);assert(!memcmp(r,read,32));get(&boot,P25_CS_GLOBAL,read);assert(!memcmp(global,read,32));
    // Standard CRC oracle from an independent straightforward bit implementation.
    uint32_t independent=0xffffffffu;
    for(unsigned k=0;k<35;++k) {get(&boot,k,read);for(unsigned i=0;i<32;++i) {
        independent^=read[i];for(unsigned bit=0;bit<8;++bit)independent=(independent&1u) ? (independent>>1)^0xedb88320u : independent>>1;
    }}
    assert((independent^0xffffffffu)==crc);
    assert(p25_cs_begin(&boot,10));memset(r,0,32);assert(p25_cs_stage_write(&boot,0,r));
    assert(p25_cs_stage_crc(&boot,&crc) && !p25_cs_commit(&boot,crc)); // selected empty memory
    global[10]=global[11]=0;assert(p25_cs_stage_write(&boot,P25_CS_GLOBAL,global));finish(&boot);
    assert(boot.revision==11);get(&boot,0,read);assert(p25_cs_zero(read,32));
    // Stage changes are never visible after abort/restart, including a full copy.
    assert(p25_cs_begin(&boot,11));named(r,"ABORTED");assert(p25_cs_stage_write(&boot,1,r));
    p25_cs_abort(&boot);assert(p25_cs_open(&s,&flash) && s.revision==11);get(&s,1,read);assert(p25_cs_zero(read,32));
    // Fill all channels/VFOs, retain independent selected panes and global fields.
    assert(p25_cs_begin(&s,11));
    for(unsigned k=0;k<34;++k) {named(r,"TWELVE CHARS");p25_cs_put16(r+10,(uint16_t)(k+1));assert(p25_cs_stage_write(&s,k,r));}
    get(&s,34,global);global[9]=1;global[10]=32;global[11]=1;global[12]=3;global[13]=1;
    p25_cs_put16(global+5,600);p25_cs_put16(global+7,0);assert(p25_cs_stage_write(&s,34,global));finish(&s);
    assert(p25_cs_open(&boot,&flash) && boot.revision==12);
    for(unsigned k=0;k<34;++k) {get(&boot,k,read);assert(p25_cs_get16(read+10)==k+1 && !memcmp(read+14,"TWELVE CHARS",12));}
    get(&boot,34,read);assert(!memcmp(read,global,32));
}
static void test_unknown_geometry_and_bounds(void) {
    p25_cs_store s;uint8_t r[32];fresh();memcpy(memory,v3,64);memory[32704]=0;
    assert(p25_cs_open(&s,&flash) && s.have_legacy && !s.writable);
    assert(!p25_cs_begin(&s,s.revision) && !writes && !erases);get(&s,32,r);assert(pref_get(r)==145700000);
    fresh();memcpy(memory,v3,64);old_slot(300,10);pref_put(memory+300*64+4,99);
    assert(p25_cs_open(&s,&flash) && !s.writable && s.have_legacy);
    hal_flash_t wrong=flash;wrong.erase_size=8192;unsigned before=reads;
    assert(!p25_cs_open(&s,&wrong) && !s.writable && reads==before);
    hal_flash_map_t other=map;other.settings_addr=0x710000;wrong=flash;wrong.map=&other;
    assert(!p25_cs_open(&s,&wrong) && reads==before);
    // An I/O error must not make a committed bank look absent/writable.
    for(int cut=0;cut<5;++cut) {
        read_budget=cut;assert(!p25_cs_open(&s,&flash) && !s.writable);read_budget=-1;
        assert(!p25_cs_read(&s,34,r));
    }
    fresh();assert(p25_cs_open(&s,&flash));assert(p25_cs_begin(&s,0));
    named(r,"EXHAUST");for(unsigned i=2;i<256;++i)assert(p25_cs_stage_write(&s,0,r));
    assert(!p25_cs_stage_write(&s,0,r));uint32_t crc;assert(p25_cs_stage_crc(&s,&crc) && !p25_cs_commit(&s,crc));
    p25_cs_abort(&s);assert(p25_cs_open(&s,&flash) && !s.have_active);
}
static void test_migration_power_cuts(void) {
    uint8_t r[32],kept[64];p25_cs_store s,boot;unsigned attempts=0;
    // The latest V3 profile can occupy either half of a completely full ring.
    for(unsigned half=0;half<2;++half) {
        fresh();for(unsigned i=0;i<512;++i)old_slot(i,i+1);
        unsigned latest=half ? 511 : 0;old_slot(latest,1000);memcpy(kept,memory+latest*64,64);
        memcpy(snapshot,memory,sizeof memory);
        for(int cut=0;cut<=2368;++cut) {
            memcpy(memory,snapshot,sizeof memory);write_budget=-1;assert(p25_cs_open(&s,&flash));
            write_budget=cut;
            bool done=p25_cs_begin(&s,1000);
            uint32_t crc;if(done)done=p25_cs_stage_crc(&s,&crc) && p25_cs_commit(&s,crc);
            write_budget=-1;assert(p25_cs_open(&boot,&flash));get(&boot,32,r);
            assert(pref_get(r)==145700000 && p25_cs_get16(r+10)==10 && !memcmp(kept,memory+latest*64,64));
            assert(boot.have_active==done && boot.revision==(done ? 1001u : 1000u));++attempts;
        }
        const int cuts[]={0,1,63,64,4095,4096,8193,12289,16383,16384};
        for(unsigned i=0;i<sizeof cuts/sizeof cuts[0];++i) {
            memcpy(memory,snapshot,sizeof memory);erase_budget=-1;assert(p25_cs_open(&s,&flash));
            erase_budget=cuts[i];bool began=p25_cs_begin(&s,1000);erase_budget=-1;
            assert(began==(cuts[i]==16384));assert(p25_cs_open(&boot,&flash));get(&boot,32,r);
            assert(pref_get(r)==145700000 && !boot.have_active && !memcmp(kept,memory+latest*64,64));++attempts;
        }
    }
    printf("Migration power-cut cases: %u\n",attempts);
}
static void test_update_power_cuts_and_corruption(void) {
    p25_cs_store s,boot;uint8_t r[32],before[32];uint32_t crc;
    fresh();memcpy(memory+500*64,v3,64);assert(p25_cs_open(&s,&flash));
    assert(p25_cs_begin(&s,9));named(r,"ORIGINAL");assert(p25_cs_stage_write(&s,0,r));finish(&s);
    get(&s,0,before);memcpy(snapshot,memory,sizeof memory);
    for(int cut=0;cut<=2368;++cut) {
        memcpy(memory,snapshot,sizeof memory);write_budget=-1;assert(p25_cs_open(&s,&flash));
        write_budget=cut;bool done=p25_cs_begin(&s,10);named(r,"UPDATED");
        if(done)done=p25_cs_stage_write(&s,0,r) && p25_cs_stage_crc(&s,&crc) && p25_cs_commit(&s,crc);
        write_budget=-1;assert(p25_cs_open(&boot,&flash));get(&boot,0,r);
        assert(!memcmp(r+14,done ? "UPDATED" : "ORIGINAL",done ? 7 : 8));
        assert(boot.revision==(done ? 11u : 10u));
    }
    memcpy(memory,snapshot,sizeof memory);assert(p25_cs_open(&s,&flash));
    assert(p25_cs_begin(&s,10));named(r,"UPDATED");assert(p25_cs_stage_write(&s,0,r));finish(&s);
    // Damaged new header/payload falls back to the complete prior bank.
    unsigned header=s.active_bank*16384;memory[header+12]^=1;
    assert(p25_cs_open(&boot,&flash) && boot.revision==10);get(&boot,0,r);assert(!memcmp(r,before,32));
    memory[header+12]^=1;unsigned record=header+s.active_slot[0]*64;memory[record+8]^=1;
    assert(p25_cs_open(&boot,&flash) && boot.revision==10);get(&boot,0,r);assert(!memcmp(r,before,32));
    // Repeated bank alternation retains the original V3 fallback byte-for-byte.
    memcpy(memory,snapshot,sizeof memory);assert(p25_cs_open(&s,&flash));
    for(unsigned n=0;n<50;++n) {
        assert(p25_cs_begin(&s,s.revision));named(r,"ROLLING");p25_cs_put16(r+10,(uint16_t)(100+n));
        assert(p25_cs_stage_write(&s,0,r));finish(&s);
        assert(p25_cs_open(&boot,&flash) && boot.revision==s.revision && boot.writable);
        assert(!memcmp(memory+s.active_bank*16384+64,v3,64));
        p25_pref_store downgrade;p25_preferences p;
        assert(pref_load(&downgrade,&flash,&p) && !downgrade.writable && p.tg==10 && p.prom_mode==1);
    }
    // Bank revisions use modular ordering, independently of the retained V3 sequence.
    unsigned active=s.active_bank*16384;
    pref_put(memory+active+8,UINT32_MAX);pref_put(memory+active+56,pref_crc(memory+active,56));
    // Make the older bank's revision one step older to model a normal wrap.
    unsigned previous=(s.active_bank^1u)*16384;
    pref_put(memory+previous+8,UINT32_MAX-1u);pref_put(memory+previous+56,pref_crc(memory+previous,56));
    assert(p25_cs_open(&s,&flash) && s.revision==UINT32_MAX);
    assert(p25_cs_begin(&s,UINT32_MAX));finish(&s);
    assert(p25_cs_open(&boot,&flash) && !boot.revision && boot.writable);
    // A future bank/record version remains readable through the prior valid
    // snapshot, but forbids erase/program even with a recognized older bank.
    memory[boot.active_bank*16384+4]=3;
    assert(p25_cs_open(&s,&flash) && !s.writable && s.revision==UINT32_MAX);
    unsigned w=writes,e=erases;assert(!p25_cs_begin(&s,s.revision) && writes==w && erases==e);
}
int main(void) {
    test_defaults_and_legacy();test_record_semantics();test_dmr_helpers_and_semantics();test_v1_snapshot_migration_and_mixed_versions();test_transactions_and_crc();
    test_unknown_geometry_and_bounds();test_migration_power_cuts();test_update_power_cuts_and_corruption();
    printf("Atomic channel store passed: 35 canonical records, dual banks, legacy fallback, revision/CRC/selection gates; sizeof=%zu\n",sizeof(p25_cs_store));
}
