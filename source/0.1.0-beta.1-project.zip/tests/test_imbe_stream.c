// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "imbe_stream.h"
static void source(unsigned frame,int16_t *pcm) {
    for (unsigned i=0;i<160;++i) pcm[i]=(int16_t)frame;
}
static imbe_stream_t run_at(uint32_t start,unsigned duration,unsigned spike,unsigned spike_frame) {
    imbe_stream_t s; stream_init(&s,start);
    uint32_t now=start;
    while (s.active) {
        stream_advance(&s,now,source);
        if (stream_can_encode(&s)) {
            int16_t pcm[160]; uint8_t payload[11];
            stream_pop(&s,pcm);
            assert(pcm[0]==(s.encoded<STREAM_SPEECH_FRAMES ? (int16_t)s.encoded : 0));
            memset(payload,(int)s.encoded,sizeof payload);
            now+=s.encoded==spike_frame ? spike : duration;
            stream_advance(&s,now,source);
            stream_commit(&s,payload,now);
        }
        now+=1000;
        assert((uint32_t)(now-start)<90000000u);
    }
    return s;
}
static imbe_stream_t run(uint32_t start,unsigned duration,unsigned spike) {
    return run_at(start,duration,spike,201);
}
int main(void) {
    imbe_stream_t s=run(0,14000,24357);
    assert(s.done && !s.failed && s.consumed==STREAM_FRAMES && s.encoded==STREAM_FRAMES && s.captured==STREAM_FRAMES);
    assert(!s.overflows && !s.underruns && s.encoded_hash==s.consumed_hash && s.count==0);
    assert(s.high_water<=8 && s.startup_us>=180000);
    assert(s.startup_us>=180000+STREAM_RESERVE_US);
    imbe_stream_t wrap=run(0xffff0000u,14000,24357);
    assert(wrap.done && wrap.startup_us==s.startup_us && wrap.max_latency_us==s.max_latency_us);
    s=run(0,25000,25000);
    assert(s.failed && (s.underruns || s.overflows) && !s.done);
    s=run(0,200000,200000);
    assert(s.failed && s.overflows==1);
    // A bank's final frame completes 30 ms after its capture deadline.
    // Original one-bank startup misses this boundary; explicit reserve absorbs it.
    s=run_at(0,7000,30000,287);
#if STREAM_RESERVE_US
    assert(s.done && !s.underruns && !s.overflows);
#else
    assert(!s.done && s.underruns==1 && s.consumed==279);
#endif
    stream_init(&s,0); s.active=false; stream_advance(&s,1000000,source);
    assert(!s.captured && !s.done); // Cancellation does not manufacture completion.
    puts("Streaming queues: paced drain, spike, wrap, sustained overload, overflow and cancellation passed");
}
