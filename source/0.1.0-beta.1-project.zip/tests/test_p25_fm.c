// SPDX-License-Identifier: GPL-3.0-or-later
// Real FM adapter and mocked board ownership; no MMIO, serial or RF access.
#include <assert.h>
#include <stdio.h>
#include "p25_fm.h"

static char events[256];
static unsigned event_n,reads,keys,unkeys,volume_calls;
static bool keyed,analog,pcm,pcm_running,rx_ok=true,tx_ok=true;
static radio_status_t input={-80,255,false,true};
static uint32_t rx_hz,tx_hz;
static radio_bw_t rx_bw,tx_bw;
static subtone_t rx_tone,tx_tone;
static uint8_t tx_power,volume;
static radio_mode_t mode=RADIO_MODE_DMR;
static void event(char e) {assert(event_n+1<sizeof events);events[event_n++]=e;events[event_n]=0;}
static void set_mode(radio_mode_t m) {assert(!keyed && !analog && !pcm && !pcm_running);mode=m;event('F');}
static bool receive(uint32_t hz,radio_bw_t bw,const subtone_t *tone) {
    assert(mode==RADIO_MODE_FM && !keyed && !analog && !pcm && !pcm_running);
    rx_hz=hz;rx_bw=bw;rx_tone=*tone;event('R');return rx_ok;
}
static bool transmit(uint32_t hz,radio_bw_t bw,uint8_t power,const subtone_t *tone) {
    assert(mode==RADIO_MODE_FM && !analog && !pcm && !pcm_running);
    tx_hz=hz;tx_bw=bw;tx_tone=*tone;tx_power=power;keyed=true;++keys;event('T');return tx_ok;
}
static void tx_off(void) {keyed=false;++unkeys;event('U');}
static void audio(bool on) {assert(!on || (!keyed && !pcm && !pcm_running));analog=on;event(on ? 'A' : 'a');}
static void status(radio_status_t *s) {assert(!keyed);*s=input;++reads;}
static void set_volume(uint8_t v) {assert(v<=100);volume=v;++volume_calls;event('V');}
static void pcm_stop(void) {pcm_running=false;event('S');}
static void pcm_route(bool on) {assert(!on);pcm=on;event('P');}
static const hal_radio_t radio={.set_mode=set_mode,.rx=receive,.tx=transmit,.tx_off=tx_off,.audio=audio,.status=status};
static const hal_audio_t sound={.stop=pcm_stop,.speaker_pcm=pcm_route};
static p25_fm_config profile(void) {
    p25_fm_config c={.rx_hz=145700000,.tx_hz=145100000,.bandwidth=RADIO_BW_12K5,
        .rx_tone={TONE_NONE,0},.tx_tone={TONE_CTCSS,1000},.squelch=5,.volume=60,.power=0};return c;
}
static void reset(void) {
    event_n=reads=keys=unkeys=volume_calls=0;events[0]=0;
    keyed=analog=pcm=pcm_running=false;rx_ok=tx_ok=true;mode=RADIO_MODE_DMR;
    input=(radio_status_t){-80,255,false,true};
}
static void test_handoff_and_shutdown(void) {
    reset();p25_fm f={0};p25_fm_config c=profile();pcm=pcm_running=true;
    assert(p25_fm_start(&f,&radio,&sound,&c,0));
    assert(!strcmp(events,"aSPUFR") && f.running && f.owned && !f.transmitting);
    assert(rx_hz==145700000 && rx_bw==RADIO_BW_12K5 && rx_tone.type==TONE_NONE);
    assert(!keys && !analog && !pcm && !pcm_running && !volume_calls);
    unsigned n=event_n;assert(!p25_fm_start(&f,&radio,&sound,&c,1));assert(event_n==n);
    // Quiet/no-carrier does not open audio. A low-noise signal does, regardless
    // of DM32's permanently false HAL carrier flag.
    p25_fm_poll(&f,0);assert(reads==1 && !analog);
    input.noise=30;p25_fm_poll(&f,24999);assert(reads==1 && !analog);
    p25_fm_poll(&f,25000);assert(reads==2 && analog && f.carrier);
    assert(p25_fm_tx_begin(&f,30000));assert(keyed && !analog && !f.have_status);
    assert(tx_hz==145100000 && tx_bw==RADIO_BW_12K5 && !tx_power);
    assert(tx_tone.type==TONE_CTCSS && tx_tone.value==1000);
    n=keys;assert(!p25_fm_tx_begin(&f,30001) && keys==n);
    n=reads;p25_fm_poll(&f,40000);assert(reads==n && !analog);
    p25_fm_tx_end(&f,50000);assert(!keyed && f.running && !f.transmitting && !f.have_status);
    p25_fm_poll(&f,50000);assert(analog && reads==n+1);
    p25_fm_stop(&f);assert(!keyed && !analog && !pcm && !pcm_running && !f.owned && !f.running);
    // After handoff, a redundant FM stop must not shut down the new P25 owner.
    n=event_n;pcm=pcm_running=true;p25_fm_stop(&f);assert(event_n==n && pcm && pcm_running);
    pcm=pcm_running=false;
    assert(p25_fm_start(&f,&radio,&sound,&f.config,60000));assert(f.config.rx_hz==c.rx_hz);
    p25_fm_stop(&f);
}
static void test_noise_and_tone_squelch(void) {
    reset();p25_fm f={0};p25_fm_config c=profile();
    assert(p25_fm_start(&f,&radio,&sound,&c,0));
    // Level5 opens below52; once open it holds below55, then closes only after
    // two consecutive noisy readings. A good reading cancels pending closure.
    input.noise=52;p25_fm_poll(&f,0);assert(!analog);
    input.noise=51;p25_fm_poll(&f,25000);assert(analog);
    input.noise=54;p25_fm_poll(&f,50000);assert(analog && !f.close_count);
    input.noise=55;p25_fm_poll(&f,75000);assert(analog && f.close_count==1);
    input.noise=54;p25_fm_poll(&f,100000);assert(analog && !f.close_count);
    input.noise=55;p25_fm_poll(&f,125000);p25_fm_poll(&f,150000);assert(!analog);
    p25_fm_stop(&f);c.squelch=0;c.rx_tone=(subtone_t){TONE_DCS_INV,0023};
    assert(p25_fm_start(&f,&radio,&sound,&c,200000));assert(rx_tone.type==TONE_DCS_INV && rx_tone.value==0023);
    input.noise=255;input.tone_ok=false;p25_fm_poll(&f,200000);assert(!analog);
    input.tone_ok=true;p25_fm_poll(&f,225000);assert(!analog);
    p25_fm_poll(&f,250000);assert(analog && f.tone_ok);
    assert(p25_fm_tx_begin(&f,250001));p25_fm_tx_end(&f,250002);
    assert(!analog && !f.tone_ok);p25_fm_poll(&f,250002);assert(!analog);
    p25_fm_poll(&f,275002);assert(analog && f.tone_ok);
    input.tone_ok=false;
    for(unsigned i=1;i<=7;++i) {p25_fm_poll(&f,275002+i*25000);assert(analog && f.tone_ok);}
    p25_fm_poll(&f,475002);assert(!f.tone_ok && analog);
    p25_fm_poll(&f,500002);assert(!analog);
    p25_fm_stop(&f);c.rx_tone=(subtone_t){TONE_NONE,0};
    assert(p25_fm_start(&f,&radio,&sound,&c,525002));p25_fm_poll(&f,525002);assert(analog);
    p25_fm_stop(&f);
}
static void test_timeout_and_failures(void) {
    reset();p25_fm f={0};p25_fm_config c=profile();c.bandwidth=RADIO_BW_25K;
    uint32_t start=UINT32_MAX-10000u;
    assert(p25_fm_start(&f,&radio,&sound,&c,start));p25_fm_poll(&f,start);
    p25_fm_poll(&f,start+24999u);assert(reads==1);
    p25_fm_poll(&f,start+25000u);assert(reads==2 && rx_bw==RADIO_BW_25K);
    assert(p25_fm_tx_begin(&f,start));assert(tx_bw==RADIO_BW_25K);
    p25_fm_poll(&f,start+P25_FM_TX_MAX_US-1u);assert(keyed && !f.timed_out);
    p25_fm_poll(&f,start+P25_FM_TX_MAX_US);assert(!keyed && !f.transmitting && f.timed_out);
    // Polling never retriggers TX; only the controller's explicit fresh PTT can.
    unsigned n=keys;p25_fm_poll(&f,start+P25_FM_TX_MAX_US+1u);assert(keys==n);
    p25_fm_stop(&f);assert(!f.owned);
    reset();memset(&f,0,sizeof f);rx_ok=false;
    assert(!p25_fm_start(&f,&radio,&sound,&c,0));assert(f.failed && !f.owned && !keyed && !analog && !pcm);
    rx_ok=true;assert(p25_fm_start(&f,&radio,&sound,&c,0));tx_ok=false;
    assert(!p25_fm_tx_begin(&f,1));assert(f.failed && !f.owned && !keyed && !analog && !pcm);
    n=event_n;p25_fm_stop(&f);assert(event_n==n);
    // Missing hooks and invalid configuration fail before any ownership change.
    reset();memset(&f,0,sizeof f);hal_radio_t incomplete=radio;incomplete.status=NULL;
    assert(!p25_fm_start(&f,&incomplete,&sound,&c,0) && !event_n);
    p25_fm_config bad=c;bad.squelch=10;assert(!p25_fm_start(&f,&radio,&sound,&bad,0) && !event_n);
    bad=c;bad.bandwidth=(radio_bw_t)3;assert(!p25_fm_start(&f,&radio,&sound,&bad,0) && !event_n);
    bad=c;bad.volume=101;assert(!p25_fm_start(&f,&radio,&sound,&bad,0) && !event_n);
    bad=c;bad.tx_tone=(subtone_t){TONE_CTCSS,599};assert(!p25_fm_start(&f,&radio,&sound,&bad,0) && !event_n);
    bad=c;bad.rx_tone=(subtone_t){TONE_DCS,01000};assert(!p25_fm_start(&f,&radio,&sound,&bad,0) && !event_n);
    assert(!p25_fm_tx_begin(&f,0));p25_fm_tx_end(&f,0);p25_fm_poll(&f,0);assert(!event_n);
    hal_radio_t with_volume=radio;with_volume.volume=set_volume;
    assert(p25_fm_start(&f,&with_volume,&sound,&c,0) && volume_calls==1 && volume==60);
    p25_fm_stop(&f);
}
int main(void) {
    test_handoff_and_shutdown();test_noise_and_tone_squelch();test_timeout_and_failures();
    printf("FM HAL: routing ownership, squelch/tones, narrow/wide split TX, timeout/wrap and fail-closed shutdown passed; state %zu bytes\n",sizeof(p25_fm));
    return 0;
}
