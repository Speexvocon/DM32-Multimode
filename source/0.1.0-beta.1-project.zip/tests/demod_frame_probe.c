// SPDX-License-Identifier: GPL-3.0-or-later
// Identical harness for production and frozen demodulators: include control
// bytes and nonvoice units in the differential check, not just IMBE payloads.
#include "p25_demod.h"
#include <stdio.h>
static bool output_failed;
static void frame(const p25_rx *r,void *context) {
    FILE *out=context;
    const uint8_t header[3]={(uint8_t)(r->nac>>8),(uint8_t)r->nac,r->duid};
    if(fwrite(header,1,sizeof header,out)!=sizeof header ||
       fwrite(r->frame,1,sizeof r->frame,out)!=sizeof r->frame)output_failed=true;
}
int main(int argc,char **argv) {
    if(argc!=3)return 2;
    FILE *in=fopen(argv[1],"rb"),*out=fopen(argv[2],"wb");
    if(!in || !out) {if(in)fclose(in);if(out)fclose(out);return 3;}
    p25_demod d;p25_demod_init(&d);int a,b;
    while((a=fgetc(in))!=EOF) {
        b=fgetc(in);if(b==EOF) {fclose(in);fclose(out);return 4;}
        p25_demod_push(&d,(int16_t)((unsigned)a*256+(unsigned)b),frame,out);
    }
    bool input_failed=ferror(in)!=0;
    for(unsigned i=0;i<32;++i)p25_demod_push(&d,0,frame,out);
    fclose(in);int close_result=fclose(out);
    return input_failed || output_failed || close_result ? 5 : 0;
}
