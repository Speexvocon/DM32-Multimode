// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_demod.h"
#include <assert.h>
#include <string.h>
#include <limits.h>
#include "p25_demod_filter.h"
static unsigned frames;
static unsigned clock_reads;
static uint32_t rearm_clock(void) {return 100u*clock_reads++;}
static void output(const p25_rx *r,void *context) {(void)r;(void)context;++frames;}
int main(void) {
    // Guard the narrow multiply optimization against future coefficient edits.
    // Full-scale individual products must fit; accumulated sums need not.
    for(unsigned k=0;k<121;++k) {
        int64_t lo=(int64_t)p25_interp[k]*INT16_MIN;
        int64_t hi=(int64_t)p25_interp[k]*INT16_MAX;
        assert(lo>=INT32_MIN && lo<=INT32_MAX);
        assert(hi>=INT32_MIN && hi<=INT32_MAX);
    }
    p25_demod d;p25_demod_init(&d);
    for(unsigned i=0;i<16000;++i)p25_demod_push(&d,i&1 ? 32767 : -32768,output,0);
    assert(!frames);
    d.pending_ticks=2;d.pending_quality=999;d.lane[0].rx.symbols=200;
    p25_demod_gap(&d);
    assert(!d.pending_ticks && !d.lane[0].rx.symbols && !d.frames);
    for(unsigned i=0;i<16000;++i)p25_demod_push(&d,0,output,0);
    assert(!frames);
    // A discontinuity discards all partial units and timing state, then reinitializes deterministically.
    p25_demod initial;p25_demod_init(&initial);p25_demod_gap(&d);
    assert(!memcmp(&d,&initial,sizeof d));
    // Normal RX times only the rare hunt recovery, without per-symbol clocks.
    // Exercise full-scale ring wrap as well as repeated silent-hunt deadlines.
    struct {uint32_t before;p25_demod demod;uint32_t after;} guarded;
    guarded.before=0x1234abcdu;guarded.after=0x9876fedcu;
    p25_demod_init(&guarded.demod);guarded.demod.hunt_clock_us=rearm_clock;
    for(unsigned i=0;i<4799;++i)p25_demod_push(&guarded.demod,0,output,0);
    assert(!guarded.demod.hunt_rearms && !clock_reads);
    p25_demod_push(&guarded.demod,0,output,0);
    assert(guarded.demod.hunt_rearms==1 && clock_reads==2);
    assert(guarded.demod.hunt_us==100 && guarded.demod.hunt_max_us==100);
    assert(guarded.demod.hunt_clock_us==rearm_clock && !guarded.demod.clock_us);
    for(unsigned i=0;i<16000;++i)
        p25_demod_push(&guarded.demod,i&1 ? INT16_MAX : INT16_MIN,output,0);
    assert(guarded.demod.hunt_rearms==4 && clock_reads==8 && !frames);
    assert(guarded.demod.hunt_us==400 && guarded.demod.hunt_max_us==100);
    assert(guarded.before==0x1234abcdu && guarded.after==0x9876fedcu);
}
