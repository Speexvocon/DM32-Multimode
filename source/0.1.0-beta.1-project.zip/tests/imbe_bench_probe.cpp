// SPDX-License-Identifier: GPL-3.0-or-later
#include "imbe_bench.h"
#include <stdio.h>
int main(int argc,char **argv) {
    if (argc!=2) return 1;
    FILE *out=fopen(argv[1],"wb");
    if (!out) return 2;
    for (unsigned run=0;run<2;++run) {
        imbe_bench_init();
        uint32_t hash=2166136261u;
        for (unsigned frame=0;frame<IMBE_BENCH_FRAMES;++frame) {
            uint8_t payload[11]; imbe_bench_prepare(frame); imbe_bench_encode(payload);
            if (fwrite(payload,1,11,out)!=11) return 3;
            for (uint8_t b:payload) hash=(hash^b)*16777619u;
        }
        printf("run=%u state_bytes=%zu hash=%08x\n",run,imbe_bench_state_bytes(),hash);
    }
    return fclose(out)==0 ? 0 : 4;
}
