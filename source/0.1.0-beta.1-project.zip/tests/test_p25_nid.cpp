// SPDX-License-Identifier: GPL-3.0-or-later
// Independent BCH oracle: pinned OP25 bch.cc, plus polynomial long division
// rather than production's generator-matrix encoder. See UPSTREAMS.json.
extern "C" {
#include "p25_rx.h"
}
#include "bch.h"
#include <cassert>
#include <cstdio>
#include <cstring>

// Preserve the old parser allocation: nid_corrected occupies existing padding.
struct old_rx_layout {
    uint64_t shift;uint8_t frame[216],duid;
    uint16_t symbols,expected,nac;uint32_t syncs,frames,bad_nid,bad_input;
};
static_assert(sizeof(p25_rx)==sizeof(old_rx_layout),"NID diagnostics grew each demod lane");
static uint32_t random_state=0x293a;
static unsigned random_value() {return random_state=random_state*1664525u+1013904223u;}
static uint64_t encode(uint16_t data) {
    // OP25 bch.cc's bchG polynomial, coefficients 0..47. The separate bit is
    // the DUID parity bit, not a freely repairable 64th BCH coefficient.
    constexpr uint64_t generator=UINT64_C(0xcd930bdd3b2b);
    uint64_t systematic=uint64_t(data)<<47,remainder=systematic;
    for(int i=62;i>=47;--i)if((remainder>>i)&1)remainder^=generator<<(i-47);
    return ((systematic|remainder)<<1)|((data^(data>>1))&1);
}
static bool supported(unsigned duid) {return duid==0||duid==3||duid==5||duid==10||duid==15;}
static uint64_t damage(unsigned count) {
    uint64_t mask=0;
    while(count) {uint64_t bit=UINT64_C(1)<<(1+random_value()%63);if(!(mask&bit)) {mask|=bit;--count;}}
    return mask;
}
static void accepted(uint64_t wire,uint16_t data,unsigned errors) {
    uint16_t nac=0xffff;uint8_t duid=0xff;unsigned corrected=99;
    assert(p25_rx_nid_decode(wire,&nac,&duid,&corrected));
    assert(nac==(data>>4)&&duid==(data&15)&&corrected==errors);
}
static void rejected(uint64_t wire) {
    uint16_t nac=0xa55a;uint8_t duid=0xa5;unsigned corrected=0x55aa;
    assert(!p25_rx_nid_decode(wire,&nac,&duid,&corrected));
    assert(nac==0xa55a&&duid==0xa5&&corrected==0x55aa);
}
static void reference(uint64_t wire,uint16_t data,unsigned errors) {
    bit_vector bits(64);
    for(unsigned j=0;j<63;++j)bits[j]=(wire>>(j+1))&1;
    assert(bchDec(bits)==int(errors));
    uint64_t corrected=0;
    for(unsigned j=0;j<63;++j)if(bits[j])corrected|=UINT64_C(1)<<j;
    assert(corrected==(encode(data)>>1));
}
static unsigned frame_size(unsigned duid) {return duid==0?99:duid==3?18:duid==15?54:216;}
static void install_nid(uint8_t frame[216],uint64_t nid) {
    unsigned j=0;
    for(unsigned i=24;i<57;++i)if(i!=35) {
        unsigned shift=6-2*(i%4);uint8_t mask=uint8_t(3u<<shift);
        frame[i/4]=uint8_t((frame[i/4]&~mask)|(((nid>>(62-2*j++))&3)<<shift));
    }
}
int main() {
    const struct {uint16_t data;uint64_t nid;} literals[]={
        {0x2930,UINT64_C(0x29300f3b5df801c2)}, {0x2933,UINT64_C(0x29333977728ced6e)},
        {0x2935,UINT64_C(0x293555ef2c653437)}, {0x293a,UINT64_C(0x293aba93bec26a2b)},
        {0x293f,UINT64_C(0x293fe047cf5f5fde)}, {0xfff5,UINT64_C(0xfff54a571cc59417)},
        {0x000a,UINT64_C(0x000ab5a8e33a6be9)}, {0x2a35,UINT64_C(0x2a3527d6de5a6703)}
    };
    for(const auto &v:literals) {
        assert(encode(v.data)==v.nid);accepted(v.nid,v.data,0);reference(v.nid,v.data,0);
        for(unsigned bit=1;bit<64;++bit) {
            accepted(v.nid^(UINT64_C(1)<<bit),v.data,1);
            reference(v.nid^(UINT64_C(1)<<bit),v.data,1);
        }
        rejected(v.nid^1); // A parity error must not be hidden by BCH recovery.
    }
    // Every NAC and supported/unsupported DUID, rather than one fixed profile.
    for(unsigned data=0;data<65536;++data) {
        uint64_t nid=encode(uint16_t(data));
        if(supported(data&15)) {
            accepted(nid,uint16_t(data),0);
            accepted(nid^(UINT64_C(1)<<(1+data%63)),uint16_t(data),1);
            rejected(nid^1);
        } else {rejected(nid);rejected(nid^(UINT64_C(1)<<(1+data%63)));}
    }
    // Exhaust all two-bit BCH errors on a literal voice header.
    for(unsigned a=1;a<64;++a)for(unsigned b=a+1;b<64;++b)
        accepted(literals[2].nid^(UINT64_C(1)<<a)^(UINT64_C(1)<<b),0x2935,2);
    const unsigned duids[]={0,3,5,10,15};
    for(unsigned errors=2;errors<=11;++errors)for(unsigned trial=0;trial<2000;++trial) {
        uint16_t data=uint16_t(((random_value()&0xfff)<<4)|duids[trial%5]);
        uint64_t wire=encode(data)^damage(errors);
        reference(wire,data,errors);
        if(errors<=P25_NID_MAX_CORRECTED) {accepted(wire,data,errors);rejected(wire^1);}
        else rejected(wire); // OP25's BCH oracle recovers these, our policy refuses.
    }
    // Actual streaming parser canonicalizes accepted NID bits but preserves the
    // unprotected status dibit. It emits exactly the DUID's complete unit length.
    for(unsigned duid:duids)for(unsigned errors=0;errors<=4;++errors) {
        uint8_t canonical[216]={0x55,0x75,0xf5,0xff,0x77,0xff},wire[216];
        canonical[8]=3; // Physical status dibit at index 35.
        uint64_t nid=encode(uint16_t(0x2930|duid));install_nid(canonical,nid);
        std::memcpy(wire,canonical,sizeof wire);install_nid(wire,nid^damage(errors));
        p25_rx parser;p25_rx_init(&parser);unsigned frames=0,n=frame_size(duid);
        for(unsigned i=0;i<n*4;++i)if(p25_rx_push(&parser,(wire[i/4]>>(6-2*(i%4)))&3)) {
            assert(i==n*4-1);++frames;
        }
        assert(frames==1&&parser.nac==0x293&&parser.duid==duid&&parser.nid_corrected==errors);
        assert(!std::memcmp(parser.frame,canonical,n));
    }
    uint16_t nac;uint8_t duid;unsigned corrected;
    assert(!p25_rx_nid_decode(literals[0].nid,nullptr,&duid,&corrected));
    assert(!p25_rx_nid_decode(literals[0].nid,&nac,nullptr,&corrected));
    assert(!p25_rx_nid_decode(literals[0].nid,&nac,&duid,nullptr));
    std::puts("NID: literal/polynomial/OP25 BCH oracles; all NAC/DUIDs; 0..4 recovery, 5..11 refusal, parity/unsupported refusal and canonical streaming passed");
}
