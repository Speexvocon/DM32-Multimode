// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (c) 2026 DM32 P25 research contributors
// Execute the actual adapter with simulated MMIO and RF callbacks; no radio access.
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include "../src/firmware/dm32_p25_diag.c"

static uint32_t fake_us, rf_keys, pa_keys, safe_calls;
static uint32_t registers[0x600/4];
static uint8_t buffers[0x1000];
static bool timer_enabled[7], irq_enabled[64];
static char serial_output[4096];
static size_t serial_used;
static bool expected_tuning=true;
static bool calibration_valid=true;
static hrc7000_t fake_modem;
static jmp_buf task_exit;
static bool run_task;
static uint32_t next_boundary;
static size_t input_offset;
static unsigned display_frames;

uint32_t hrc_micros(void) { return fake_us; }
uint32_t hrc_irq_save(void) { return 0; }
void hrc_irq_restore(uint32_t state) { (void)state; }
void hrc_irq_enable(uint8_t source, bool on) { irq_enabled[source]=on; }
void hrc_irq_register(uint8_t source, void (*handler)(void)) { (void)source; (void)handler; }
void hrc_timer_stop(uint8_t timer) { timer_enabled[timer]=false; }
void hrc_timer_oneshot(uint8_t timer, uint32_t us) { assert(us>0); timer_enabled[timer]=true; }
void hrc_timer_ack(uint8_t timer) { (void)timer; }
void board_rf_safe(void) { ++safe_calls; }
bool bf_cal_valid(void) { return calibration_valid; }
const char *bf_cal_source(void) { return calibration_valid ? "mock" : "none"; }
void hrc7000_audio_bits(hrc7000_t *modem, uint32_t set, uint32_t clear)
{
    modem->audio_ctl=(modem->audio_ctl | set) & ~clear;
    hrc7000_wr(modem,C7_AUDIO_CONTROL,modem->audio_ctl);
}
static size_t mock_write(const uint8_t *data, size_t length)
{
    assert(serial_used+length<sizeof(serial_output));
    memcpy(serial_output+serial_used,data,length);
    serial_used+=length;
    serial_output[serial_used]=0;
    return length;
}
static uint16_t mock_battery(void) { return 8000; }
static void mock_mode(radio_mode_t mode) { (void)mode; }
static void mock_audio(bool on) { assert(!on); }
static bool mock_rx(uint32_t hz, radio_bw_t bw, const subtone_t *tone)
{ (void)hz; (void)bw; (void)tone; return expected_tuning; }
static bool mock_tx(uint32_t hz, radio_bw_t bw, uint8_t power, const subtone_t *tone)
{ (void)hz; (void)bw; (void)tone; assert(power==0); fake_us+=100000; return expected_tuning; }
static void mock_tx_off(void) {}
static void mock_led(uint8_t led, bool on) { (void)led; (void)on; }
static void mock_rf(bool on) { if(on) ++rf_keys; }
static void mock_pa(void) { ++pa_keys; }
static bool mock_start(void) { return true; }
static void mock_void(void) {}
static void mock_level(uint8_t level) { (void)level; }
static void mock_latch(bool on) { assert(on); }
static uint32_t mock_scan(void) { return run_task && fake_us>=50000 ? 1u : 0u; }
static size_t mock_read(uint8_t *data, size_t max)
{
    const char *line="ARM 440000000 1 0 ALLOW_RF\n";
    size_t left=strlen(line)-input_offset;
    if (left>max) left=max;
    memcpy(data,line+input_offset,left); input_offset+=left;
    return left;
}
static const hal_stream_t fake_port={.write=mock_write,.start=mock_start,.read=mock_read};
static const hal_power_t fake_power={.battery_mv=mock_battery,.led=mock_led,.switch_on=mock_start,.latch=mock_latch};
static const hal_radio_t fake_radio={.init=mock_void,.set_mode=mock_mode,.audio=mock_audio,.rx=mock_rx,.tx=mock_tx,.tx_off=mock_tx_off};
static const hal_input_t fake_input={.init=mock_void,.scan=mock_scan};
static const hal_display_t fake_display={.init=mock_void,.set_backlight=mock_level};
static const keymap_entry_t fake_keys[]={{.bit=0,.short_action=ACT_PTT}};
static const band_t fake_bands[]={{400000000,480000000,true}};
const board_t board={.host_port=&fake_port,.power=&fake_power,.radio=&fake_radio,.battery_critical_mv=6400,
    .bands=fake_bands,.band_count=1,.input=&fake_input,.display=&fake_display,.keymap=fake_keys,.keymap_len=1};
static const hrc_dmr_board_t fake_hooks={.rf_switch=mock_rf,.pa_on=mock_pa,.pa_delay_us=28000};

void board_init(void) {}
bool gfx_init(const hal_display_t *display) { (void)display; return true; }
void gfx_frame_begin(void) { assert(!hardware_running); ++display_frames; }
void gfx_clear(color_t color) { (void)color; }
int gfx_text(const font_t *font, int x, int y, const char *text, color_t color)
{
    (void)color;
    assert(x>=0 && y>=0 && x+(int)strlen(text)*font->w<=220 && y+font->h<=310);
    return x+(int)strlen(text)*font->w;
}
void gfx_fill(int x, int y, int w, int h, color_t color)
{ (void)color; assert(x>=0 && y>=0 && x+w<=220 && y+h<=310); }
void gfx_round_fill(int x, int y, int w, int h, color_t color) { gfx_fill(x,y,w,h,color); }
void gfx_hline(int x, int y, int w, color_t color) { gfx_fill(x,y,w,1,color); }
void gfx_flush(void) { assert(!hardware_running); fake_us+=20000; }
const font_t font_8x16={.w=8,.h=16}, font_6x12={.w=6,.h=12}, font_12x24={.w=12,.h=24};
void vTaskDelete(TaskHandle_t handle) { (void)handle; assert(false); }
BaseType_t xTaskCreate(TaskFunction_t fn, const char * const name, configSTACK_DEPTH_TYPE depth,
                      void * const parameter, UBaseType_t priority, TaskHandle_t * const handle)
{ (void)fn; (void)name; (void)depth; (void)parameter; (void)priority; (void)handle; return pdPASS; }
void vTaskDelay(TickType_t ticks)
{
    assert(run_task);
    fake_us += ticks*1000;
    if (hardware_running) {
        if (next_boundary==0) next_boundary=tx.started_us+10000;
        if ((int32_t)(fake_us-next_boundary)>=0) {
            isr_slot(); isr_slot(); next_boundary+=30000;
        }
        if (!pa_started) { isr_rftx(); isr_pa(); }
    }
    if (tx.state==P25_TX_DONE && !hardware_running) longjmp(task_exit,1);
    if (fake_us>15000000 || tx.state==P25_TX_ABORTED) longjmp(task_exit,2);
}

static void issue(const char *text, bool ptt)
{
    assert(strlen(text)<sizeof(command));
    strcpy(command,text);
    parse_command(ptt);
}
static void reset(void)
{
    memset(registers,0,sizeof(registers));
    memset(buffers,0,sizeof(buffers));
    memset(timer_enabled,0,sizeof(timer_enabled));
    memset(irq_enabled,0,sizeof(irq_enabled));
    memset(&fake_modem,0,sizeof(fake_modem));
    fake_modem.regs=registers; fake_modem.buf=buffers;
    fake_modem.audio_ctl=0xf0;
    registers[C7_RF_MODE/4]=0x03269860;
    armed=hardware_running=pa_started=rf_prepared=false;
    fake_us=rf_keys=pa_keys=safe_calls=0;
    serial_used=0; expected_tuning=calibration_valid=true;
    run_task=false; next_boundary=0; input_offset=0; ptt_mask=0; command_used=0; command_overflow=false;
    setup_failed=arm_expired=display_ok=false; display_frames=0;
    p25_test_tx_init(&tx);
    __wrap_hrc_dmr_board_init(&fake_modem,&fake_hooks);
}

int main(int argc, char **argv)
{
    assert(argc==2);
    reset();
    assert(!armed && !hardware_running && rf_keys==0 && pa_keys==0);
    issue("ARM 440000000 1 0 NO",false); assert(!armed);
    issue("ARM 440000000 1 0 ALLOW_RF",true); assert(!armed);
    issue("ARM 100000000 1 0 ALLOW_RF",false); assert(!armed);
    issue("ARM 440000000 12 0 ALLOW_RF",false); assert(!armed);
    issue("ARM 440000000 1 0 ALLOW_RF junk",false); assert(!armed);
    calibration_valid=false;
    issue("ARM 440000000 1 0 ALLOW_RF",false); assert(!armed);
    calibration_valid=true;
    issue("ARM 440000000 1 0 ALLOW_RF",false);
    assert(armed && !hardware_running && rf_keys==0 && pa_keys==0);
    assert(begin_transmission());
    assert(!armed && hardware_running && tx.started_us==fake_us);
    assert((registers[C7_AUDIO_CONTROL/4]&0xf0)==0);
    assert(registers[C7_WORK_MODE/4]==2 && registers[C7_LAYER2_CONTROL/4]==0x82);
    assert(timer_enabled[6] && irq_enabled[IRQ_MODEM_RF_TX]);
    isr_rftx(); assert(rf_keys==1 && timer_enabled[3] && pa_keys==0);
    isr_rftx(); assert(rf_keys==1);
    isr_pa(); assert(pa_keys==1 && !timer_enabled[3]);
    FILE *fixture=fopen(argv[1],"rb"); assert(fixture);
    unsigned bytes=0;
    for(unsigned block=0; block<346; ++block) {
        fake_us=tx.started_us+1000u+block*30000u;
        boundary();
        assert(registers[C7_LAYER2_TXRX_CTRL/4]==0x80);
        for(unsigned i=0;i<36;++i) {
            int expected=bytes<12453 ? fgetc(fixture) : 0x77;
            assert(buffers[i]==expected && buffers[0x24+i]==expected);
            ++bytes;
        }
        fake_us+=100;
        boundary();
        // Also on the final block: a duplicate IRQ must not cancel the send.
        assert(registers[C7_LAYER2_TXRX_CTRL/4]==0x80);
    }
    assert(fgetc(fixture)==EOF); fclose(fixture);
    assert(tx.state==P25_TX_DRAINING && tx.blocks==346);
    fake_us+=30000; boundary(); assert(registers[C7_LAYER2_TXRX_CTRL/4]==0);
    p25_test_tx_poll(&tx,tx.drain_until_us,true); assert(tx.state==P25_TX_DONE);
    stop_transmission(); assert(!hardware_running && !timer_enabled[6]);
    assert(registers[C7_RF_MODE/4]==0x03269860);

    reset(); issue("ARM 440000000 5 1 ALLOW_RF",false); assert(begin_transmission());
    assert(registers[C7_RF_MODE/4]==(0x03269860^0x80));
    memset(buffers,0,sizeof(buffers));
    fake_us+=1000; boundary(); assert(buffers[0]==0x77 && buffers[0x24]==0);
    fake_us+=30000; boundary(); assert(buffers[0x24]==0x77);
    isr_hard_stop(); assert(tx.reason==P25_TX_TIMEOUT && !hardware_running && safe_calls>0);
    unsigned before=pa_keys; isr_pa(); assert(pa_keys==before);
    assert(!irq_enabled[IRQ_MODEM_SYS] && !timer_enabled[6]);

    reset(); issue("ARM 440000000 1 0 ALLOW_RF",false); assert(begin_transmission());
    issue("STOP",false); assert(!hardware_running && tx.reason==P25_TX_CANCELLED);
    before=rf_keys; isr_rftx(); assert(rf_keys==before);
    stop_transmission();
    reset(); expected_tuning=false;
    issue("ARM 440000000 1 0 ALLOW_RF",false); assert(!begin_transmission());
    stop_transmission(); assert(registers[C7_RF_MODE/4]==0x03269860);
    // Run the real application loop, including a slow RF setup and held PTT.
    reset(); run_task=true;
    int exit_reason=setjmp(task_exit);
    if(exit_reason==0) diagnostic_task(NULL);
    assert(exit_reason==1 && tx.state==P25_TX_DONE && tx.blocks==346 && !armed);
    assert(rf_keys==1 && pa_keys==1 && !hardware_running);
    assert(display_frames>=3); // Armed, pre-TX and completed views; never flush during RF.
    puts("Actual diagnostic adapter: arming, MMIO stream, final IRQ, RF timeout, stop and setup failure checks passed");
    return 0;
}
