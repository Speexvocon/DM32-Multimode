"""Linked-arena evidence and isolated make wiring tests; no compiler/device needed."""
import importlib.util
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('imbe_build_analyzer', ROOT/'scripts/analyze-imbe-build.py')
analyzer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analyzer)


def evidence_elf(value=5736, borrowed=13776):
    raw = bytearray(320)
    struct.pack_into('<I', raw, 32, 128)
    struct.pack_into('<HH', raw, 46, 40, 3)
    struct.pack_into('<10I', raw, 168, 0, 1, 2, 0x03020000, 80, 8, 0, 0, 4, 0)
    struct.pack_into('<I', raw, 80, value)
    struct.pack_into('<I', raw, 84, borrowed)
    struct.pack_into('<10I', raw, 208, 0, 1, 6, 0x12000, 88, 32, 0, 0, 4, 0)
    return bytes(raw)


def shared_symbols():
    lines = ['00018000 00001668 b codec_workspace', '03020000 00000004 R imbe_codec_object_bytes',
             '03020004 00000004 R radio_codec_dmr_borrowed_bytes', f'00020000 {74476:08x} b rx_storage']
    for index, name in enumerate(('radio_codec_acquire', 'radio_codec_release', 'radio_codec_begin', 'radio_codec_end',
                                 'radio_codec_dmr_storage', 'hrc_vocoder_quiesce', 'hrc_vocoder_resume',
                                 'imbe_bench_release', 'radio_dmr_start', 'radio_dmr_stop', 'radio_dmr_poll',
                                 'hrc_dmr_deferred_drain', 'radio_codec_bind_dmr', 'radio_codec_unbind_dmr')):
        address = 0x12000 if name == 'hrc_dmr_deferred_drain' else 0x03021000+index*32
        lines.append(f'{address:08x} 00000020 T {name}')
    return '\n'.join(lines)


class ArenaEvidenceTests(unittest.TestCase):
    def test_overlay_evidence_preserves_receive_union_and_measured_p25_class_size(self):
        result = analyzer.codec_storage(evidence_elf(), shared_symbols(), True)
        self.assertEqual(result['workspace_bytes'], 5736)
        self.assertEqual(result['software_object_bytes'], 5736)
        self.assertTrue(result['duplicate_static_allocations_absent'])
        self.assertFalse(result['runtime_handoff_qualified'])
        self.assertEqual(sum(result['native_slices_bytes'].values()), result['native_borrowed_window']['bytes'])
        self.assertEqual(result['receive_capture_union']['bytes'], 74476)
        self.assertFalse(result['native_borrowed_window']['binding_execution_measured'])

    def test_standalone_retains_static_state_without_shared_requirements(self):
        self.assertEqual(analyzer.codec_storage(b'', '00058000 00002400 b _ZL5state', False),
                         {'kind':'standalone_static', 'workspace_bytes':9216, 'software_object_bytes':9216})

    def test_shared_rejects_every_duplicate_native_or_software_array(self):
        for name in ('_ZL5state', 'dec_state', 'enc_state', 'bitbuf', 'pcmbuf'):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'Duplicate live'):
                analyzer.codec_storage(evidence_elf(), shared_symbols()+f'\n0005c000 00000100 b {name}', True)

    def test_shared_size_alignment_and_handoff_evidence_are_required(self):
        for old, new in [('00001668', '000035d0'), ('00018000', '00018004'),
                         ('hrc_vocoder_quiesce', 'missing'), ('00000004 R imbe_codec_object_bytes', '00000008 R imbe_codec_object_bytes')]:
            with self.subTest(old=old), self.assertRaises(ValueError):
                analyzer.codec_storage(evidence_elf(), shared_symbols().replace(old, new), True)
        for value in (0, 5737, 0xffffffff):
            with self.assertRaisesRegex(ValueError, 'exceeds dedicated'):
                analyzer.codec_storage(evidence_elf(value), shared_symbols(), True)

    def test_overlay_rejects_reduced_capture_unaligned_or_overlapping_native_bind_window(self):
        for old, new in [(f'{74476:08x}', f'{74475:08x}'), ('00020000', '00020004'), ('00020000', '00018000')]:
            with self.subTest(new=new), self.assertRaises(ValueError):
                analyzer.codec_storage(evidence_elf(), shared_symbols().replace(old,new), True)
        with self.assertRaisesRegex(ValueError,'borrowed prefix'):
            analyzer.codec_storage(evidence_elf(borrowed=13768), shared_symbols(), True)

    def test_class_size_requires_unique_file_backed_elf_bytes(self):
        for offset, value in ((172, 8), (176, 0), (180, 0x03020004), (184, 255)):
            raw = bytearray(evidence_elf());struct.pack_into('<I', raw, offset, value)
            with self.assertRaises(ValueError):analyzer.codec_storage(bytes(raw), shared_symbols(), True)

    def test_deferred_dmr_drain_requires_executable_startup_ram(self):
        with self.assertRaisesRegex(ValueError, 'startup RAM'):
            analyzer.codec_storage(evidence_elf(), shared_symbols().replace('00012000', '03012000'), True)
        raw=bytearray(evidence_elf());struct.pack_into('<I', raw, 216, 2)
        with self.assertRaisesRegex(ValueError, 'startup RAM'):
            analyzer.codec_storage(bytes(raw), shared_symbols(), True)

    def test_linked_map_proves_generated_objects_and_excludes_discarded_pinned_sections(self):
        old=' .text.old\n 0x00000000 0x10 build/live/platform/hrc7000/vocoder.o\n'
        body=''.join(f' .text.{name}\n 0x03020000 0x20 build/live/multimode/{name}.o\n'
                     for name in ('vocoder', 'audio_pcm', 'dmr_glue', 'radio_dmr', 'codec_workspace'))
        report=analyzer.generated_live_objects(old+'Linker script and memory map\n'+body)
        self.assertEqual(report['dmr_glue']['linked_input_section_bytes'],32)
        with self.assertRaisesRegex(ValueError, 'Unreplaced'):
            analyzer.generated_live_objects('Linker script and memory map\n'+body+old)
        with self.assertRaisesRegex(ValueError, 'Missing linked'):
            analyzer.generated_live_objects('Linker script and memory map\n'+body.replace('/multimode/audio_pcm.o', '/other/audio_pcm.o'))


class MakeWiringTests(unittest.TestCase):
    def test_live_only_replaces_native_wrappers_and_keeps_glue_outside_codec_directory(self):
        make = shutil.which('make') or shutil.which('mingw32-make')
        if not make:self.skipTest('GNU make is unavailable')
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            (folder/'Makefile').write_text('BOARD:=dm32\nBUILD:=build/test\nTARGET:=$(BUILD)/radio\n'
                'OBJ:=$(BUILD)/platform/hrc7000/vocoder.o $(BUILD)/platform/hrc7000/audio_pcm.o $(BUILD)/platform/hrc7000/dmr_glue.o $(BUILD)/base.o\n'
                'audit:\n\t@echo OBJECTS=$(OBJ)\n\t@echo ARENA=$(BENCH_ARENA_FLAGS)\n\t@echo LINKFLAGS=$(LDFLAGS)\n')
            def inspect(live):
                return subprocess.check_output([make, '-n', '-f', str(ROOT/'src/firmware/radiofoundry-imbe-bench.mk'),
                    'audit', 'PROJECT_ROOT=/project', f'BENCH_LIVE_RF={int(live)}'], cwd=folder, text=True, stderr=subprocess.STDOUT)
            standalone = inspect(False);live = inspect(True)
        self.assertIn('build/test/platform/hrc7000/vocoder.o', standalone)
        self.assertNotIn('-DBENCH_SHARED_CODEC=1', standalone)
        self.assertNotIn('--undefined=imbe_codec_object_bytes', standalone)
        self.assertNotIn('build/test/platform/hrc7000/vocoder.o', live)
        self.assertNotIn('build/test/platform/hrc7000/audio_pcm.o', live)
        self.assertNotIn('build/test/platform/hrc7000/dmr_glue.o', live)
        for name in ('vocoder', 'audio_pcm', 'radio_dmr', 'codec_workspace', 'dmr_glue'):
            self.assertIn(f'build/test/multimode/{name}.o', live)
            self.assertNotIn(f'build/test/imbe/{name}.o', live)
        self.assertIn('-DBENCH_SHARED_CODEC=1', live)
        self.assertIn('-Wl,--undefined=imbe_codec_object_bytes', live)


if __name__ == '__main__':unittest.main()
