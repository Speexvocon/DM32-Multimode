// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (c) 2026 DM32 P25 research contributors
// Render the firmware's actual drawing code and fonts without radio access.
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "p25_diag_ui.h"

static void flush(const void *fb, const uint16_t *palette, uint16_t y0, uint16_t y1)
{ (void)fb; (void)palette; (void)y0; (void)y1; }

int main(int argc, char **argv)
{
    assert(argc==2);
    const hal_display_t display={.width=240,.height=320,.bpp=4,.inset_left=10,.inset_right=10,
        .inset_top=5,.inset_bottom=5,.flush_indexed=flush};
    assert(gfx_init(&display));
    const char *names[]={"idle", "armed", "transmitting", "complete", "late", "cal-missing", "expired", "low-battery"};
    for (unsigned i=0; i<sizeof names/sizeof names[0]; ++i) {
        p25_diag_view view={.battery_mv=8020,.critical_mv=6400,.calibration_valid=true,
                           .calibration="factory",.git="preview"};
        p25_test_tx_init(&view.tx);
        if(i>0) view.frequency=440000000;
        if(i==1) { view.armed=true; view.arm_seconds=27; }
        if(i==2) view.starting=true;
        if(i==3) { view.tx.state=P25_TX_DONE; view.tx.blocks=346; }
        if(i==4) { view.tx.state=P25_TX_ABORTED; view.tx.reason=P25_TX_LATE; view.tx.blocks=123; }
        if(i==5) { view.calibration_valid=false; view.calibration="none"; }
        if(i==6) view.arm_expired=true;
        if(i==7) { view.setup_failed=true; view.battery_mv=6200; }
        p25_diag_draw(&view);
        char path[512];
        (void)snprintf(path,sizeof path,"%s/%s.ppm",argv[1],names[i]);
        FILE *file=fopen(path,"wb"); assert(file!=NULL);
        fprintf(file,"P6\n240 320\n255\n");
        for(unsigned y=0;y<320;++y) {
            uint8_t row[480]; gfx_read_rgb565(y*480u,row,sizeof row);
            for(unsigned x=0;x<240;++x) {
                unsigned rgb=row[x*2u] | (unsigned)row[x*2u+1u]<<8;
                fputc((int)(((rgb>>11)&31u)*255u/31u),file);
                fputc((int)(((rgb>>5)&63u)*255u/63u),file);
                fputc((int)((rgb&31u)*255u/31u),file);
            }
        }
        assert(fclose(file)==0);
    }
    puts("Rendered eight diagnostic states with actual 4-bpp framebuffer and firmware fonts");
    return 0;
}
