// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (c) 2026 DM32 P25 research contributors
#ifndef DIAG_TEST_PLATFORM_H
#define DIAG_TEST_PLATFORM_H
#include <stdint.h>
#include <stdbool.h>
enum { IRQ_TIMER3=3, IRQ_TIMER4=4, IRQ_TIMER6=6, IRQ_PCM_RD=27, IRQ_MODEM_SYS=29, IRQ_MODEM_TS_TX=30,
       IRQ_MODEM_TS_RX=31, IRQ_MODEM_RF_TX=32, IRQ_MODEM_RF_RX=33 };
#define TIMER_PA 3
static inline void hrc_barrier(void) {}
uint32_t hrc_micros(void);
void hrc_pin_write(uint8_t pin, bool level);
bool hrc_pin_read(uint8_t pin);
uint32_t hrc_irq_save(void);
void hrc_irq_restore(uint32_t state);
void hrc_irq_enable(uint8_t source, bool enabled);
void hrc_irq_register(uint8_t source, void (*handler)(void));
void hrc_timer_stop(uint8_t timer);
void hrc_timer_periodic(uint8_t timer, uint32_t us);
void hrc_timer_oneshot(uint8_t timer, uint32_t us);
void hrc_timer_ack(uint8_t timer);
#endif
