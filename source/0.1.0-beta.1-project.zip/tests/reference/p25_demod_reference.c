// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_demod.h"
#include <string.h>
#include "p25_demod_filter.h"
static const uint8_t sync_bytes[6]={0x55,0x75,0xf5,0xff,0x77,0xff};
void p25_demod_init(p25_demod *d) {
    memset(d,0,sizeof *d);
    for(unsigned i=0;i<10;++i) {d->lane[i].next_q16=(uint64_t)(i+1)*65536;d->lane[i].period_q16=10*65536;}
}
void p25_demod_gap(p25_demod *d) {p25_demod_init(d);}
static bool acquire(p25_demod_lane *l) {
    int32_t sx=0,sy=0,sxy=0,syy=0;
    int64_t sxx=0;
    for(unsigned i=0;i<24;++i) {
        int32_t x=l->history[(l->index+i)%24]/16;
        unsigned b=(sync_bytes[i/4]>>(6-2*(i%4)))&3;
        int32_t y=b==1 ? 3 : -3;
        sx+=x;sy+=y;sxy+=x*y;syy+=y*y;sxx+=(int64_t)x*x;
    }
    int64_t xx=24*sxx-(int64_t)sx*sx;
    int32_t yy=24*syy-sy*sy,xy=24*sxy-sx*sy;
    if(xx<24000 || !yy) return false;
    int64_t numerator=(int64_t)xy*xy;
    int64_t scaled=numerator*1000,denominator=xx*yy;
    // floor(scaled/denominator) >= 900 iff scaled >= 900*denominator.
    // Most timing hypotheses fail sync: avoid software 64-bit division there.
    // With 24 int16 samples divided by 16, these products fit int64_t.
    if(scaled<900*denominator) return false;
    unsigned quality=(unsigned)(scaled/denominator);
    int32_t gain=(int32_t)((int64_t)xy*16/yy);
    if(gain>-100 && gain<100) return false;
    l->gain=gain;l->offset=(sx*16-gain*sy)/24;l->quality=quality;
    l->previous_symbol=0;
    p25_rx_gap(&l->rx);
    for(unsigned i=0;i<24;++i)
        p25_rx_push(&l->rx,(sync_bytes[i/4]>>(6-2*(i%4)))&3);
    return true;
}
static void symbol(p25_demod *d,p25_demod_lane *l,int16_t value) {
    l->history[l->index]=value;l->index=(l->index+1)%24;
    if(l->filled<24) ++l->filled;
    // Do not reinterpret voice data as a sync while a validated unit is in flight.
    if(!l->rx.symbols && l->filled==24 && acquire(l)) {++d->acquisitions;return;}
    if(!l->rx.symbols || !l->gain) return;
    int32_t x=value-l->offset,g=l->gain;
    if(g<0) {x=-x;g=-g;}
    uint8_t b=x< -2*g ? 3 : x<0 ? 2 : x<2*g ? 0 : 1;
    int32_t decision=b==3 ? -3 : b==2 ? -1 : b==0 ? 1 : 3;
    if(l->previous_symbol) {
        // Mueller and Muller timing error, normalized by the sync-derived gain.
        // Q16 loop gains 1/32 (phase), 1/4096 (rate), rate bounded to +/-2000 ppm.
        int32_t error=(int32_t)(((int64_t)l->previous_symbol*x-(int64_t)decision*l->previous_value)*65536/g);
        if(error>4*65536)error=4*65536;
        if(error< -4*65536)error= -4*65536;
        l->period_q16+=error/4096;
        if(l->period_q16>656671)l->period_q16=656671;
        if(l->period_q16<654049)l->period_q16=654049;
        l->next_q16+=(int64_t)(error/32);
    }
    l->previous_value=x;l->previous_symbol=decision;
    if(p25_rx_push(&l->rx,b)) {
        // Adjacent timing hypotheses complete the same unit within one symbol.
        // Prefer fewer FEC corrections, then the strongest sync fit. FEC cannot
        // prove integrity beyond its correction radius. Emit only one unit.
        unsigned errors=0;
        if(l->rx.duid==5 || l->rx.duid==10) {
            for(unsigned i=0;i<9;++i) {
                uint8_t payload[11];unsigned corrected;
                if(p25_rx_voice(l->rx.frame,i,payload,&corrected))errors+=corrected;
            }
        }
        if(!d->pending_ticks) {d->pending_ticks=11;d->pending_errors=~0u;}
        if(errors<d->pending_errors || (errors==d->pending_errors && l->quality>d->pending_quality)) {
            d->pending=l->rx;d->pending_quality=l->quality;d->pending_errors=errors;
        }
    }
}
static void interpolated(p25_demod *d,int16_t value,p25_demod_frame_fn emit,void *context) {
    if(d->pending_ticks && !--d->pending_ticks) {
        ++d->frames;emit(&d->pending,context);d->pending_quality=0;
    }
    uint64_t now=++d->ticks*65536;
    for(unsigned i=0;i<10;++i) {
        p25_demod_lane *l=&d->lane[i];
        if(l->next_q16<=now) {
            uint32_t back=(uint32_t)(now-l->next_q16);
            int32_t x=value+(int32_t)(((int64_t)d->previous-value)*back/65536);
            l->next_q16+=l->period_q16;
            symbol(d,l,(int16_t)x);
        }
    }
    d->previous=value;
}
void p25_demod_push(p25_demod *d,int16_t sample,p25_demod_frame_fn emit,void *context) {
    d->fir[d->fir_index]=sample;
    for(unsigned p=0;p<6;++p) {
        int64_t sum=0;
        for(unsigned k=p,j=0;k<121;k+=6,++j)
            // Each product fits int32 (max coefficient 32790), but the sum
            // can exceed INT32_MAX at full scale. Keep accumulation in int64.
            sum+=p25_interp[k]*(int32_t)d->fir[(d->fir_index+21-j)%21];
        int32_t x=(int32_t)(sum/32768);
        if(x>32767)x=32767;
        if(x< -32768)x=-32768;
        interpolated(d,(int16_t)x,emit,context);
    }
    d->fir_index=(d->fir_index+1)%21;
}
