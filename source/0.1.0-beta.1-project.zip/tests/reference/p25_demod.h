// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_DEMOD_H
#define P25_DEMOD_H
#include "p25_rx.h"
// Bounded 8-kHz discriminator input. Ten timing hypotheses at 48 kHz.
// Sync acquires polarity, DC and gain; decision-directed timing tracks each
// hypothesis between syncs. No whole-call search, heap, or floating point.
typedef struct {
    p25_rx rx;
    int16_t history[24];
    unsigned index, filled, quality;
    int32_t offset, gain;
    uint64_t next_q16;
    int32_t period_q16, previous_value, previous_symbol;
} p25_demod_lane;
typedef struct {
    p25_demod_lane lane[10];
    int16_t fir[21];
    unsigned fir_index, pending_ticks, pending_quality, pending_errors;
    p25_rx pending;
    uint32_t frames, acquisitions;
    uint64_t ticks;
    int16_t previous;
} p25_demod;
typedef void (*p25_demod_frame_fn)(const p25_rx *frame,void *context);
void p25_demod_init(p25_demod *d);
void p25_demod_gap(p25_demod *d);
void p25_demod_push(p25_demod *d,int16_t sample,p25_demod_frame_fn emit,void *context);
#endif
