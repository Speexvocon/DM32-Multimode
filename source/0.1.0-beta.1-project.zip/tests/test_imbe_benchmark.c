// SPDX-License-Identifier: GPL-3.0-or-later
// Execute the real application loop with a timed codec double and no radio HAL.
#include <assert.h>
#include <setjmp.h>
#define IMBE_STAGE_PROFILE 1
#include "../src/firmware/dm32_imbe_bench.c"
static uint32_t clock_us, safe_count, prepared;
static bool cancel_run;
static bool stream_run;
static size_t read_offset;
static jmp_buf end_task;
static char output[65536];
static size_t output_used;
uint32_t hrc_micros(void) { return clock_us; }
void board_rf_safe(void) { ++safe_count; }
void board_init(void) {}
bool imbe_bench_init(void) { clock_us+=1234;return true; }
void imbe_bench_prepare(uint32_t frame) {
    prepared=frame; clock_us+=100;
    if (frame==0) clock_us=0xffffff00u; // Encode duration crosses the 32-bit timer wrap.
}
void imbe_bench_encode(uint8_t payload[11]) {
    memset(payload,0,11);
    clock_us+=prepared==0 ? 15001 : prepared==1 ? 20001 : 1000;
}
size_t imbe_bench_state_bytes(void) { return 5736; }
void imbe_bench_source(unsigned frame,int16_t *out) { (void)frame; memset(out,0,320); }
void imbe_bench_encode_pcm(int16_t *input,uint8_t *out) { (void)input; memset(out,0,11); clock_us+=1000; }
static bool yes(void) { return true; }
static void nop(void) {}
static void backlight(uint8_t level) { (void)level; }
static void latch(bool on) { (void)on; assert(false); }
static size_t write_port(const uint8_t *data,size_t length) {
    assert(output_used+length<sizeof output);
    memcpy(output+output_used,data,length); output_used+=length; output[output_used]=0;
    clock_us+=1000; return length;
}
static size_t read_port(uint8_t *data,size_t capacity) {
    if (cancel_run && frames==7) { memcpy(data,"STOP\n",5); return 5; }
    const char *line=stream_run ? "STREAM\n" : "RUN\n";
    size_t n=strlen(line)-read_offset; if(n>capacity)n=capacity;
    memcpy(data,line+read_offset,n);read_offset+=n;return n;
}
static const hal_stream_t port={.start=yes,.read=read_port,.write=write_port};
static const hal_power_t power={.switch_on=yes,.latch=latch};
static const hal_display_t display={.init=nop,.set_backlight=backlight};
// Null radio/input/flash callbacks deliberately catch accidental access.
const board_t board={.host_port=&port,.power=&power,.display=&display};
bool gfx_init(const hal_display_t *d) { (void)d; return true; }
void gfx_frame_begin(void) {}
void gfx_clear(color_t c) { (void)c; }
int gfx_text(const font_t *f,int x,int y,const char *s,color_t c) {
    (void)c;assert(x>=0 && y>=0 && x+(int)strlen(s)*f->w<=220 && y+f->h<=310);return x;
}
void gfx_flush(void) { clock_us+=20000; }
const font_t font_8x16={.w=8,.h=16},font_6x12={.w=6,.h=12},font_12x24={.w=12,.h=24};
UBaseType_t uxTaskGetStackHighWaterMark(TaskHandle_t handle) { (void)handle;return 2048; }
void vTaskDelete(TaskHandle_t handle) { (void)handle;assert(false); }
BaseType_t xTaskCreate(TaskFunction_t fn,const char *const name,configSTACK_DEPTH_TYPE depth,
    void *const arg,UBaseType_t priority,TaskHandle_t *const handle) {
    (void)fn;(void)name;(void)arg;(void)priority;(void)handle;assert(depth==4096);return pdPASS;
}
void vTaskDelay(TickType_t ticks) {
    clock_us+=ticks*1000;
    assert(frames<=STREAM_FRAMES);
    if (!running && (frames==300 || (stream_run && !stream.active) || (cancel_run && frames==7))) longjmp(end_task,1);
}
static void reset(bool cancel) {
    clock_us=0xfffff000u;safe_count=0;cancel_run=cancel;read_offset=0;
    running=false;streaming=false;frames=0;used=0;overflow=false;output_used=0;
}
int main(void) {
    frames=100; clock_us=0xfffffff0u;
    imbe_profile_mark(0); clock_us+=32; imbe_profile_mark(1);
    assert(stage_count[1][0]==1 && stage_total[1][0]==32 && stage_max[1][0]==32);
    clock_us+=7; imbe_profile_mark(2);
    assert(stage_count[1][1]==1 && stage_total[1][1]==7);
    reset(false);
    if (!setjmp(end_task)) benchmark_task(NULL);
    assert(frames==300 && !running && safe_count>=302 && init_us==1234);
    assert(maximum[0]==20001 && budget_misses[0]==2 && misses[0]==1);
    assert(maximum[1]==1000 && maximum[2]==1000);
    assert(strstr(output,"rf=disabled") && strstr(output,"match=0"));
    reset(true);
    if (!setjmp(end_task)) benchmark_task(NULL);
    assert(frames==7 && !running && strstr(output,"OK STOP"));
    strcpy(command,"ARM 440075000 1 0 ALLOW_RF");parse();assert(!running);
    strcpy(command,"RUN");parse();assert(running && frames==0);
    assert(stage_count[1][0]==0 && stage_total[1][0]==0 && stage_max[1][0]==0);
    frames=17;parse();assert(frames==17); // RUN while running cannot reset statistics.
    strcpy(command,"STOP");parse();assert(!running);
    stream_run=true; reset(false);
    if (!setjmp(end_task)) benchmark_task(NULL);
    assert(stream.done && stream.consumed==STREAM_FRAMES && !stream.failed && !running);
    assert(strstr(output,"OK STREAM") && strstr(output,"STREAM_TIMING") && stream.encoded_hash==stream.consumed_hash);
    reset(true);
    if (!setjmp(end_task)) benchmark_task(NULL);
    assert(!running && !stream.active && !stream.done && frames==7);
    puts("Benchmark model: timing, wrap, cancellation, RUN gating, display bounds and absent RF callbacks passed");
}
