// SPDX-License-Identifier: GPL-3.0-or-later
#include "imbe_bench.h"
#include "imbe_bench_expected.h"
#include "imbe_stream.h"
#include <cassert>
#include <cstdio>
int main(int argc,char **argv) {
    assert(argc==3);
    FILE *pcm_file=fopen(argv[1],"wb"), *payload_file=fopen(argv[2],"wb");
    assert(pcm_file && payload_file);
    imbe_bench_init(); imbe_stream_t s; stream_init(&s,0xffff0000u);
    uint32_t now=s.start;
    while(s.active) {
        stream_advance(&s,now,imbe_bench_source);
        if(stream_can_encode(&s)) {
            int16_t input[160]; uint8_t payload[11];
            stream_pop(&s,input);
            assert(fwrite(input,2,160,pcm_file)==160);
            imbe_bench_encode_pcm(input,payload);
            assert(fwrite(payload,1,11,payload_file)==11);
            now+=s.encoded==201 ? 24357 : 14000;
            stream_advance(&s,now,imbe_bench_source);
            stream_commit(&s,payload,now);
        }
        now+=1000;
    }
    assert(s.done && !s.failed && s.speech_hash==IMBE_BENCH_EXPECTED);
    assert(s.encoded_hash==s.consumed_hash && s.consumed==STREAM_FRAMES && !s.count);
    assert(s.encoded_hash==IMBE_STREAM_EXPECTED);
    assert(fclose(pcm_file)==0 && fclose(payload_file)==0);
    puts("Real codec buffered path: speech hash and 3006-frame ordered drain match");
}
