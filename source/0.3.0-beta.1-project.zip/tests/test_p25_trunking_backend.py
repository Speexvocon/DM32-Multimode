# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline complete nominal backend lifecycle, independent OP25 wire oracle."""
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build/test-p25-trunking-backend'
BUILD.mkdir(parents=True, exist_ok=True)
BINARY = BUILD / ('backend.exe' if sys.platform == 'win32' else 'backend')
sources = ['p25_trunking_backend.c', 'p25_trunking_session.c', 'p25_trunking.c',
           'p25_trunking_access.c', 'p25_trunking_isp.c', 'p25_trunking_slot.c',
           'p25_trunking_preload.c', 'p25_tsdu.c', 'p25_rx.c']
subprocess.run(['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wshadow',
                '-pedantic', '-Isrc/firmware', 'tests/test_p25_trunking_backend.c',
                *['src/firmware/' + name for name in sources], '-o', str(BINARY)],
               cwd=ROOT, check=True, timeout=120)
spec = importlib.util.spec_from_file_location('backend_op25', ROOT / 'scripts/generate-p25-trunking-fixture.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
reference = oracle.load_reference()
rid, wacn, system, group, nac = 1234567, 0xABCDE, 0x123, 10, 0x293
responses = [
    (0x34, 1 << 60 | 5 << 56 | 0x2190 << 42 | 100 << 32 | 440075000 // 5),
    (0x3B, wacn << 36 | system << 24 | 0x1000 << 8),
    (0x3A, system << 40 | 1 << 32 | 2 << 24 | 0x1000 << 8),
    (0x2C, system << 48 | rid << 24 | rid),
    (0x28, 1 << 63 | group << 24 | rid),
    (0x00, 4 << 56 | 0x1001 << 40 | group << 24 | rid),
]
incoming, outgoing = BUILD / 'control.bin', BUILD / 'requests.bin'
incoming.write_bytes(b''.join(oracle.encode_tsdu(reference, nac, [item])[0] for item in responses))
subprocess.run([str(BINARY), str(incoming), str(outgoing)], cwd=ROOT, check=True, timeout=20)
expected = [(0x2C, wacn << 36 | system << 24 | rid),
            (0x28, system << 40 | group << 24 | rid),
            (0x00, group << 24 | rid),
            (0x2B, wacn << 36 | system << 24 | rid)]
assert outgoing.read_bytes() == b''.join(oracle.encode_tsdu(reference, nac, [item])[0] for item in expected)
print('Independent OP25 REGISTER/AFFILIATE/GROUP/DEREG vectors match; '
      'fresh RX epoch, grant/voice/return and explicit nominal-policy checks passed')
