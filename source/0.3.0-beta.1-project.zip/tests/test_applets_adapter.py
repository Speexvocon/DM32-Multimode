"""Actual radio main + installed sandbox applets + bounded flash/IRQ mocks.

Only [E00000,F00000) may receive applet writes. Settings and native metadata
are independent sentinels; compiler-generated packages use the real installer.
"""
from array import array
import importlib.util
from pathlib import Path
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build'/'applets-adapter'


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    loaded=importlib.util.module_from_spec(spec);sys.modules[name]=loaded;spec.loader.exec_module(loaded)
    return loaded


class AppletsAdapterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        BUILD.mkdir(parents=True,exist_ok=True)
        base=module('applets_adapter_base',ROOT/'tests/test_microapps_adapter.py')
        compiler=module('applets_adapter_compiler',ROOT/'scripts/dm32_applet.py')
        generator=module('applets_adapter_waveform',ROOT/'tests/test_same_demod.py')
        cls.counter=BUILD/'counter.dapp';cls.same=BUILD/'same-watch.dapp';cls.fixture=BUILD/'same.pcm'
        counter_source=(ROOT/'examples/applets/counter.dappsrc').read_text().replace('goto count','if r0 != 3 goto count\nend')
        cls.counter.write_bytes(compiler.compile_source(counter_source).data)
        cls.same.write_bytes(compiler.load_package(ROOT/'examples/applets/same-watch.dappsrc').data)
        signal=[]
        for payload in (generator.HEADER,generator.HEADER,b'NNNN',b'NNNN'):
            signal.extend(generator.waveform(payload,phase=.73,dc=3000,noise=500));signal.extend([3000]*8000)
        with cls.fixture.open('wb') as stream:array('h',signal).tofile(stream)
        prefix=(ROOT/'tests/test_live_adapter.c').read_text().split('static void reset(void) {',1)[0]
        prefix=prefix.replace('../src/firmware/','').replace(
            '../external/RadioFoundry/RadioFoundry/',base.UPSTREAM.as_posix()+'/')
        start=prefix.index('static size_t write_port(');end=prefix.index('static bool audio_start(',start)
        prefix=prefix[:start]+base.WRITE_MOCK+prefix[end:]
        helpers=base.ADAPTER_MAIN.split('static bool was_down,dirty;',1)[1].split('int main(int argc,char **argv) {',1)[0]
        source=BUILD/'applets-adapter.c'
        source.write_text(prefix+FLASH_MOCK+'\nstatic bool was_down,dirty;\n'+helpers+APPLET_MAIN,encoding='utf-8',newline='\n')
        cls.binary=BUILD/'applets-adapter.exe'
        base.run(['gcc','-std=gnu11','-O1','-Wall','-Wextra','-Werror',
            '-Wno-unused-parameter','-Wno-unused-function','-Wno-unused-variable',
            '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
            '-DBENCH_GIT="applets-adapter"','-DCONFIG_DMR=1',
            '-Itests/diag-stubs','-Itests','-Isrc/firmware','-Ifixtures/p25-1011',
            *base.INCLUDES,source,'tests/diag-stubs/radio_dmr_stub.c',
            'src/firmware/p25_demod.c','src/firmware/p25_rx.c','src/firmware/p25_tsdu.c','src/firmware/p25_trunking.c','src/firmware/p25_trunking_isp.c','src/firmware/p25_trunking_burst.c','src/firmware/p25_call.c',
            'src/firmware/p25_data.c','src/firmware/p25_live_tx.c','src/firmware/p25_live_frame.c',
            'src/firmware/p25_test_tx.c','src/firmware/radio_microapps.c','src/firmware/same_demod.c',
            'src/firmware/same_protocol.c','src/firmware/radio_applet_store.c',
            'src/firmware/radio_applet_vm.c','src/firmware/radio_applets.c',
            'src/firmware/radio_pcm_engine.c','src/firmware/radio_pcm_fm_tx.c','tests/diag-stubs/radio_pcm_stub.c',
            '-o',cls.binary])

    def case(self,name):
        result=subprocess.run([str(self.binary),name,str(self.counter),str(self.same),str(self.fixture)],
            cwd=ROOT,timeout=45,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stdout+'\n'+result.stderr)
        self.assertIn('applets adapter '+name+': PASS',result.stdout)

    def test_counter_end_restores_all_radio_modes(self):
        for mode in ('p25','fm','dmr'):
            with self.subTest(mode=mode):self.case(mode)
    def test_installed_same_script_receives_real_pcm_events(self):self.case('same')
    def test_cps_and_ptt_restore_and_block_rf(self):self.case('cps-ptt')
    def test_install_abort_timeout_and_back_keep_prior_revision(self):self.case('abort')
    def test_radio_apps_menu_launches_native_and_installed_apps(self):self.case('menus')
    def test_foreign_partition_is_read_only_without_metadata_writes(self):self.case('foreign')


FLASH_MOCK=r'''
static uint8_t settings_memory[32768],applet_memory[RADIO_APPLET_STORE_BYTES],native_metadata[4096];
static unsigned settings_writes,settings_erases,applet_writes,applet_erases;
static bool settings_read(uint32_t addr,void *data,uint32_t size) {
    if(addr>=RADIO_APPLET_STORE_BASE && addr<=RADIO_APPLET_STORE_BASE+RADIO_APPLET_STORE_BYTES
       && size<=RADIO_APPLET_STORE_BASE+RADIO_APPLET_STORE_BYTES-addr) {
        memcpy(data,applet_memory+addr-RADIO_APPLET_STORE_BASE,size);return true;
    }
    if(addr>=0xf00000u && addr+size<=0xf01000u) {memcpy(data,native_metadata+addr-0xf00000u,size);return true;}
    assert(addr>=0x711000u && addr+size<=0x719000u);
    memcpy(data,settings_memory+addr-0x711000u,size);return true;
}
static bool settings_write(uint32_t addr,const void *data,uint32_t size) {
    if(addr>=RADIO_APPLET_STORE_BASE && addr<RADIO_APPLET_STORE_BASE+RADIO_APPLET_STORE_BYTES
       && size<=RADIO_APPLET_STORE_BASE+RADIO_APPLET_STORE_BYTES-addr) {
        assert(applet_owns_radio && !same_running && !call_active && !hardware_running);++applet_writes;
        for(unsigned i=0;i<size;++i)applet_memory[addr-RADIO_APPLET_STORE_BASE+i]&=((const uint8_t *)data)[i];
        return true;
    }
    assert(!applet_owns_radio && addr>=0x711000u && addr+size<=0x719000u);++settings_writes;
    for(unsigned i=0;i<size;++i)settings_memory[addr-0x711000u+i]&=((const uint8_t *)data)[i];
    return true;
}
static bool settings_erase(uint32_t addr) {
    if(addr>=RADIO_APPLET_STORE_BASE && addr<RADIO_APPLET_STORE_BASE+RADIO_APPLET_STORE_BYTES) {
        assert(applet_owns_radio && !same_running && !call_active && !hardware_running && !(addr%4096u));
        ++applet_erases;memset(applet_memory+addr-RADIO_APPLET_STORE_BASE,255,4096);return true;
    }
    assert(!applet_owns_radio && addr>=0x711000u && addr<0x719000u && !(addr%4096u));
    ++settings_erases;memset(settings_memory+addr-0x711000u,255,4096);return true;
}
static const hal_flash_map_t settings_map={.settings_addr=0x711000u,.settings_size=32768u,
    .native_addr=0xf00000u,.native_size=0x100000u};
static const hal_flash_t pref_flash={.size=0x1000000u,.erase_size=4096u,.read=settings_read,
    .write=settings_write,.erase=settings_erase,.map=&settings_map};
'''


APPLET_MAIN=r'''
static void assert_native(void) {
    for(unsigned i=0;i<sizeof native_metadata;++i)assert(native_metadata[i]==0xa5u);
    assert_saved();assert_no_rf();
}
static void prepare_applet(radio_channel_mode_t mode_index) {
    memset(applet_memory,255,sizeof applet_memory);memset(native_metadata,0xa5,sizeof native_metadata);
    setup(mode_index);assert(applets.store.state==RADIO_APPLET_STORE_SCANNING);
    applet_writes=applet_erases=0;
}
static void applet_step(void) {tick(false);}
static void wait_reply(const char *reply) {
    unsigned count=0;
    while(!strstr(output,reply)) {
        applet_step();
        if(strstr(output,"APP ERROR")) {fprintf(stderr,"%s",output);assert(0);}
        assert(++count<7000u);
    }
}
static void applet_issue(const char *text) {strcpy(command,text);parse_command(false);}
static void normal_restored(void) {
    assert(!applet_owns_radio && !radio_applets_active(&applets) && !same_running && microapps.active==RADIO_MICROAPP_NONE);
    assert_restored();assert_native();
}
static void install_from_file(unsigned slot,const char *path) {
    uint8_t package[RADIO_APPLET_MAX_BYTES];FILE *stream=fopen(path,"rb");assert(stream);
    unsigned size=(unsigned)fread(package,1,sizeof package,stream);assert(!ferror(stream) && feof(stream));fclose(stream);
    char line[120],expected[64];uint32_t crc=radio_applet_store_crc(package,size);
    clear_uart();snprintf(line,sizeof line,"APP INSTALL BEGIN %u %u %lu",slot,size,(unsigned long)crc);
    applet_issue(line);wait_reply("APP OK INSTALL BEGIN");assert(applet_owns_radio);
    for(unsigned off=0;off<size;off+=32u) {
        unsigned n=size-off;if(n>32u)n=32u;
        int used=snprintf(line,sizeof line,"APP INSTALL DATA %u ",off);
        for(unsigned i=0;i<n;++i)used+=snprintf(line+used,sizeof line-(unsigned)used,"%02x",package[off+i]);
        clear_uart();applet_issue(line);snprintf(expected,sizeof expected,"APP OK INSTALL DATA %u",off+n);wait_reply(expected);
        if(!off) {
            unsigned writes=applet_writes;clear_uart();applet_issue(line);wait_reply(expected);assert(applet_writes==writes);
        }
    }
    clear_uart();applet_issue("APP INSTALL COMMIT");wait_reply("APP OK INSTALL COMMIT");
    assert(applets.store.slots[slot-1u].present && applet_writes && applet_erases);
    normal_restored();
}
static void run_slot(unsigned slot) {
    char line[32];snprintf(line,sizeof line,"APP RUN %u",slot);clear_uart();applet_issue(line);
    wait_reply("APP OK RUN");assert(applet_owns_radio && applets.running);assert_native();
}
static void test_counter(radio_channel_mode_t mode_index,const char *path) {
    prepare_applet(mode_index);install_from_file(1,path);run_slot(1);
    wait_reply("APP DONE");assert(strstr(output,"0\r\n") && strstr(output,"1\r\n") && strstr(output,"2\r\n"));
    normal_restored();assert(!strcmp(applets.vm.package.name,"Counter"));
}
static void test_same_script(const char *package,const char *pcm) {
    prepare_applet(RADIO_CHANNEL_DMR);install_from_file(2,package);run_slot(2);
    for(unsigned i=0;i<20u && !same_running;++i)applet_step();
    assert(same_running && tuned_rx==162550000u && tuned_bw==RADIO_BW_25K);
    FILE *stream=fopen(pcm,"rb");assert(stream);int16_t samples[RADIO_APP_AUDIO_SAMPLES];size_t n;
    while((n=fread(samples,sizeof samples[0],RADIO_APP_AUDIO_SAMPLES,stream))!=0) {
        feed_pcm(samples,(unsigned)n,false);applet_step();
    }
    assert(!ferror(stream));fclose(stream);
    for(unsigned i=0;i<30u;++i)applet_step();
    assert(same_rx.protocol.headers==2u && same_rx.protocol.confirmations==1u && same_rx.protocol.eoms==2u);
    assert(applets.running && strstr(applet_display,"RWT") && strstr(applet_display,"CONFIRMED"));
    assert(strstr(output,"SAME CONFIRMED ZCZC-WXR-RWT-018097+0030-3171200-KZZZ/NWS-"));
    assert_native();local_action(ACT_BACK,false);normal_restored();
}
static void test_cps_ptt(const char *path) {
    prepare_applet(RADIO_CHANNEL_P25);install_from_file(1,path);run_slot(1);
    for(unsigned i=0;i<10;++i)tick(true);
    assert(applets.running && ptt_release_required);assert_native();
    mock_ptt_high=true;scripted_keys=0;clear_uart();applet_issue("CPS HELLO");
    assert(cps_link && !applet_owns_radio && !radio_applets_active(&applets));
    assert(!strncmp(output,"CPS HELLO DM32P25",16) || !strncmp(output,"\r\nCPS HELLO DM32P25",18));
    assert(!strstr(output,"APP DONE") && !strstr(output,"Counter"));assert_native();
    cps_link=false;assert(normal_resume());for(unsigned i=0;i<60u;++i)tick(false);normal_restored();
}
static void test_abort(const char *path) {
    prepare_applet(RADIO_CHANNEL_FM);install_from_file(1,path);
    unsigned revision=applets.store.slots[0].revision;
    clear_uart();applet_issue("APP INSTALL BEGIN 1 128 0");wait_reply("APP OK INSTALL BEGIN");
    applet_issue("APP INSTALL DATA 0 44415050");
    clear_uart();applet_issue("APP INSTALL ABORT");wait_reply("APP OK INSTALL ABORT");normal_restored();
    assert(applets.store.slots[0].revision==revision);
    clear_uart();applet_issue("APP INSTALL BEGIN 1 128 0");wait_reply("APP OK INSTALL BEGIN");
    now+=31000000u;applet_step();
    assert(strstr(output,"timed out"));normal_restored();assert(applets.store.slots[0].revision==revision);
    clear_uart();applet_issue("APP INSTALL BEGIN 1 128 0");wait_reply("APP OK INSTALL BEGIN");
    mock_ptt_high=false;scripted_keys=ptt_mask;local_action(ACT_BACK,true);
    assert(ptt_release_required && !applet_owns_radio);tick(true);assert_native();
    for(unsigned i=0;i<60u;++i)tick(false);
    normal_restored();
    run_slot(1);wait_reply("APP DONE");normal_restored();
}
static void test_menus(const char *path) {
    prepare_applet(RADIO_CHANNEL_P25);install_from_file(1,path);
    local_action(ACT_SELECT,false);assert(menu_open && menu_page==MENU_ROOT);
    menu_item=4;local_action(ACT_SELECT,false);assert(menu_page==MENU_TOOLS);
    menu_item=2;local_action(ACT_SELECT,false);assert(menu_page==MENU_APPLETS && menu_count()>=9u);
    char label[40],detail[80];menu_row(1,label,sizeof label,detail,sizeof detail);
    assert(!strcmp(label,"Counter") && strstr(detail,"Slot 1"));
    menu_item=0;local_action(ACT_SELECT,false);assert(menu_page==MENU_SAME_CHANNELS && menu_count()==7u);
    menu_item=5;local_action(ACT_SELECT,false);assert(same_running && microapps.frequency_hz==162525000u);
    local_action(ACT_BACK,false);normal_restored();
    local_action(ACT_SELECT,false);menu_item=4;local_action(ACT_SELECT,false);
    menu_item=2;local_action(ACT_SELECT,false);menu_item=1;local_action(ACT_SELECT,false);
    assert(applet_owns_radio && applets.running);wait_reply("APP DONE");normal_restored();
}
static void test_foreign(const char *path) {
    prepare_applet(RADIO_CHANNEL_P25);applet_memory[0xabcde]=0x5au;
    clear_uart();applet_issue("APP STORE STATUS");wait_reply("APP OK STORE STATUS");
    assert(applets.store.state==RADIO_APPLET_STORE_FOREIGN && !applet_writes && !applet_erases);
    clear_uart();applet_issue("APP INSTALL BEGIN 1 128 0");
    for(unsigned i=0;i<10u && !strstr(output,"APP ERROR");++i)applet_step();
    assert(strstr(output,"foreign data") && !applet_writes && !applet_erases && applet_memory[0xabcde]==0x5au);
    normal_restored();
}
int main(int argc,char **argv) {
    assert(argc==5);
    if(!strcmp(argv[1],"p25"))test_counter(RADIO_CHANNEL_P25,argv[2]);
    else if(!strcmp(argv[1],"fm"))test_counter(RADIO_CHANNEL_FM,argv[2]);
    else if(!strcmp(argv[1],"dmr"))test_counter(RADIO_CHANNEL_DMR,argv[2]);
    else if(!strcmp(argv[1],"same"))test_same_script(argv[3],argv[4]);
    else if(!strcmp(argv[1],"cps-ptt"))test_cps_ptt(argv[2]);
    else if(!strcmp(argv[1],"abort"))test_abort(argv[2]);
    else if(!strcmp(argv[1],"menus"))test_menus(argv[2]);
    else if(!strcmp(argv[1],"foreign"))test_foreign(argv[2]);else assert(0);
    printf("applets adapter %s: PASS\n",argv[1]);return 0;
}
'''


if __name__=='__main__':unittest.main(verbosity=2)
