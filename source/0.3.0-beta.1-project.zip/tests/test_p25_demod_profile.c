// SPDX-License-Identifier: GPL-3.0-or-later
// Exercise actual symbol/parser boundaries, including rejected control blocks.
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../src/firmware/p25_demod.c"
#include "p25_data_fec.h"
static unsigned clock_calls;
static uint32_t clock_now;
static uint32_t rare_clock(void) {++clock_calls;clock_now+=7u;return clock_now;}
static uint8_t frame[90],blocks[3][12];
static size_t make(unsigned count) {
    memset(blocks,0,sizeof blocks);
    for(unsigned b=0;b<count;++b) {
        blocks[b][0]=(uint8_t)((b+1u==count?0x80u:0u)|0x3bu);
        blocks[b][2]=(uint8_t)(20u+b);
        uint16_t crc=p25_data_crc16(blocks[b],10);
        blocks[b][10]=(uint8_t)(crc>>8);blocks[b][11]=(uint8_t)crc;
    }
    size_t bytes=p25_tsdu_encode(frame,sizeof frame,0x293u,(const uint8_t (*)[12])blocks,count,3u);
    assert(bytes);return bytes;
}
static void feed(p25_demod *d,const uint8_t *p,unsigned first,unsigned end) {
    static const int16_t level[4]={1000,3000,-1000,-3000};
    for(unsigned i=first;i<end;++i)symbol(d,&d->lane[0],level[p25_data_get_dibit(p,i)]);
}
static void init(p25_demod *d,bool profile) {
    p25_demod_init(d);clock_calls=0;clock_now=UINT32_MAX-3u;
    d->rare_fec_clock_us=profile?rare_clock:NULL;
}
static bool zero_path(const uint8_t *p,unsigned block) {
    uint8_t received[98];unsigned state=0;
    for(unsigned i=0;i<98u;++i) {unsigned data=56u+block*98u+i;
        received[p25_data_interleave_index(i)]=(uint8_t)p25_data_get_dibit(p,data+data/35u);}
    for(unsigned i=0;i<49u;++i) {
        unsigned edge=p25_data_trellis_inverse[(received[2u*i]<<2)|received[2u*i+1u]];
        if((edge>>2)!=state)return false;
        state=edge&3u;
    }
    return state==0;
}
static void replace_block(unsigned block,const uint8_t data[12]) {
    uint8_t received[98];unsigned state=0;
    for(unsigned i=0;i<49u;++i) {
        unsigned next=i<48u?(data[i/4u]>>(6u-2u*(i%4u)))&3u:0u;
        unsigned pair=p25_data_trellis[state][next];state=next;
        received[2u*i]=(uint8_t)(pair>>2);received[2u*i+1]=(uint8_t)(pair&3u);
    }
    for(unsigned i=0;i<98u;++i) {
        unsigned ordinal=56u+block*98u+i,physical=ordinal+ordinal/35u;
        unsigned shift=6u-2u*(physical%4u);
        frame[physical/4u]=(uint8_t)((frame[physical/4u]&~(3u<<shift))
            |(received[p25_data_interleave_index(i)]<<shift));
    }
}
static void discard_frame(const p25_rx *r,void *context) {(void)r;(void)context;}
int main(void) {
    for(unsigned count=1;count<=3u;++count) {
        size_t bytes=make(count);p25_demod plain,profiled;init(&plain,false);
        feed(&plain,frame,0,(unsigned)bytes*4u);assert(!clock_calls);
        init(&profiled,true);
        unsigned prior=0;
        for(unsigned b=0;b<count;++b) {
            unsigned end=p25_tsdu_block_end_symbols(b);
            feed(&profiled,frame,prior,end-1u);assert(profiled.parser_fec_calls==b);
            feed(&profiled,frame,end-1u,end);assert(profiled.parser_fec_calls==b+1u);
            prior=end;
        }
        feed(&profiled,frame,prior,(unsigned)bytes*4u);
        assert(profiled.fec_candidates==1u&&profiled.parser_fec_calls==count);
        assert(profiled.parser_fec_us==count*7u&&profiled.parser_fec_max_us==7u);
        assert(profiled.fec_us==7u&&clock_calls==2u*(count+1u));
        assert(!profiled.fir_us&&!profiled.sync_us&&!profiled.symbol_us);
        assert(!memcmp(plain.pending.frame,profiled.pending.frame,sizeof plain.pending.frame));
        assert(plain.pending.frame_bytes==profiled.pending.frame_bytes
            &&plain.acquisitions==profiled.acquisitions&&plain.frames==profiled.frames
            &&plain.fec_candidates==profiled.fec_candidates&&plain.fec_skipped==profiled.fec_skipped);
        // A single channel bit requires nonzero-metric Viterbi, yet CRC and
        // payload recover. It must still be included in every parser scope.
        unsigned bit=56u+10u,physical=bit+bit/35u;
        frame[physical/4u]^=(uint8_t)(1u<<(6u-2u*(physical%4u)));
        assert(!zero_path(frame,0));p25_tsdu decoded;
        assert(p25_tsdu_decode(frame,bytes,&decoded)&&!memcmp(decoded.block,blocks,count*12u));
        init(&profiled,true);feed(&profiled,frame,0,(unsigned)bytes*4u);
        assert(profiled.parser_fec_calls==count&&profiled.fec_candidates==1u);
        assert(clock_calls==2u*(count+1u));
    }
    // An exact trellis codeword with damaged CRC is rejected by the parser,
    // before candidate arbitration. Its cost must not disappear from counters.
    size_t bytes=make(3);blocks[0][2]^=1u;replace_block(0,blocks[0]);
    assert(zero_path(frame,0));p25_tsdu decoded;assert(!p25_tsdu_decode(frame,bytes,&decoded));
    p25_demod d;init(&d,true);feed(&d,frame,0,158u);
    assert(d.parser_fec_calls==1u&&d.parser_fec_us==7u&&d.parser_fec_max_us==7u);
    assert(!d.fec_candidates&&d.lane[0].rx.bad_input==1u&&!d.lane[0].rx.frames&&clock_calls==2u);
    // Late entry has no qualified parser state; re-acquisition on a fresh sync
    // restores the same bounded scopes. Ordinary status slots add no clock calls.
    bytes=make(3);init(&d,true);feed(&d,frame,60u,100u);assert(!clock_calls);
    feed(&d,frame,0,(unsigned)bytes*4u);
    assert(d.parser_fec_calls==3u&&d.fec_candidates==1u&&clock_calls==8u);
    d.pending_ticks=0;feed(&d,frame,0,(unsigned)bytes*4u);
    assert(d.parser_fec_calls==6u&&d.fec_candidates==2u&&clock_calls==16u);
    assert(d.rare_fec_clock_us==rare_clock&&!d.clock_us);
    p25_demod_gap(&d);assert(!d.rare_fec_clock_us&&!d.parser_fec_calls&&!d.parser_fec_us&&!d.parser_fec_max_us);
    // Timestamp discontinuities retain the optional hook just like existing
    // clocks, but reset counters with the new epoch and do no symbol profiling.
    d.rare_fec_clock_us=rare_clock;unsigned before=clock_calls;
    assert(p25_demod_push_at(&d,0,0,1,discard_frame,NULL,NULL));
    assert(!p25_demod_push_at(&d,0,13,2,discard_frame,NULL,NULL));
    assert(d.rare_fec_clock_us==rare_clock&&!d.clock_us&&clock_calls==before);
    puts("Rare control FEC profiling: parser boundaries, correction, rejection, clock wrap and default path PASS");
    return 0;
}
