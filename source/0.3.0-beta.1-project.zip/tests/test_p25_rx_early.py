# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit pre-NID events without changing RXORIGIN1 or RXSTREAM32."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build/test-p25-rx-early'
BUILD.mkdir(parents=True, exist_ok=True)
BINARY = BUILD / ('early.exe' if sys.platform == 'win32' else 'early')
subprocess.run(['gcc', '-std=c11', '-O2', '-fstrict-aliasing', '-Wall', '-Wextra', '-Werror',
    '-Wshadow', '-Wstrict-aliasing=2', '-pedantic', '-Isrc/firmware', 'tests/test_p25_rx_early.c',
    'src/firmware/p25_rx_stream.c', '-o', str(BINARY)], cwd=ROOT, check=True, timeout=120)
subprocess.run([str(BINARY)], cwd=ROOT, check=True, timeout=20)
