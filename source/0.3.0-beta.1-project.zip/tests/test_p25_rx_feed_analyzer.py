# SPDX-License-Identifier: GPL-3.0-or-later
"""Strict lean-feed receipt tests; aggregates never become source/RF proof."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('rx_feed_analyzer', ROOT/'scripts/analyze-p25-rx-feed.py')
A = importlib.util.module_from_spec(spec)
spec.loader.exec_module(A)


def receipt(*, extended=False, latency=False, render=False):
    text = ('RXFEED schema=1 state=4 owned=1 frozen=1 limit=4096 produced=4096 consumed=4096 faults=0 guard_us=2000 max_age_us=16000 tracking_mask=1023 frames=9 statuses=40 early=3 queue_max_us=500 consumer_max_us=1000 clock=unqualified\n'
        'RXFEED_COST calls=256 total_us=200000 max_us=1200 yields=5 irq_calls=350 irq_us=25000 irq_max_us=100 parser_calls=20 parser_us=5000 arbitration_us=3000 pairs=3 pair_us=15000 pair_max_us=5500 status_age_us=40000 status_age_max_us=1800 early_age_us=2000 early_age_max_us=900 cpu_utilization_measured=0\n'
        'RXFEED_SOURCE epoch=7 read_calls=256 read_bytes=12288 max_read_us=40 source_queue_max_us=700 handoff_fault=0 fec_profiled=1 clock=unqualified\n'
        'RXFEED_END sample_origin_qualified=0 rf_dispatch_qualified=0\n')
    if extended:
        text=text.replace('handoff_fault=0', 'handoff_fault=0 handoff_reason=0 handoff_age_us=0 frame_high=2 status_high=3')
    if latency:
        text=text.replace('fec_profiled=1', 'controller_gap_us=22000 frame_apply_us=400 indicator_us=3000 fec_profiled=1')
    if render:
        text=text.replace('fec_profiled=1','view_us=200 paint_us=2800 fec_profiled=1')
    return text


class FeedAnalyzer(unittest.TestCase):
    def test_complete_counter_receipt_has_explicit_lesser_proof(self):
        result = A.parse_trace(receipt())
        self.assertTrue(result['lean_receipt_coherent'])
        self.assertEqual(result['worker_elapsed_us_per_chunk'], 781.25)
        self.assertEqual(result['paired_callback_delay_mean_us'], 5000)
        self.assertEqual(result['original_wire_text'], receipt())
        for key in ('source_integrity_independently_verified','source_samples_retained',
                    'decoder_stream_coherence_measured','clock_fit_performed',
                    'sample_origin_qualified','sample_rate_qualified','rf_dispatch_qualified',
                    'cpu_utilization_inferred'):
            self.assertIs(result[key], False)

    def test_structural_schema_key_and_unsigned_rejections(self):
        for old, new in (('schema=1','schema=2'),('state=4','state=7'),
                ('frames=9','frames=-1'),('frames=9','frames=09'),
                ('frames=9','frames=4294967296'),('owned=1','owned=2'),
                ('faults=0','faults=8192'),('tracking_mask=1023','tracking_mask=1024'),
                ('clock=unqualified','clock=qualified'),('guard_us=2000','guard_us=1999'),
                ('max_age_us=16000','max_age_us=16001'),('epoch=7','epoch=0'),
                ('frames=9','frames=9 unknown=0'),('frames=9','frames=9 frames=9'),
                (' frames=9',''),('cpu_utilization_measured=0','cpu_utilization_measured=1'),
                ('rf_dispatch_qualified=0','rf_dispatch_qualified=1')):
            with self.subTest(new=new), self.assertRaises(ValueError):
                A.parse_trace(receipt().replace(old,new))

    def test_counter_inconsistencies_rejected(self):
        for old,new in (('consumed=4096','consumed=4112'),('consumed=4096','consumed=4095'),
                ('limit=4096','limit=4097'),('calls=256 total_us','calls=255 total_us'),
                ('read_bytes=12288','read_bytes=36864'),('read_calls=256','read_calls=255'),
                ('max_us=1200','max_us=200001'),('pairs=3','pairs=4'),
                ('pairs=3 pair_us=15000 pair_max_us=5500','pairs=0 pair_us=15000 pair_max_us=5500')):
            with self.subTest(new=new), self.assertRaises(ValueError):
                A.parse_trace(receipt().replace(old,new))

    def test_fault_stale_and_handoff_remain_observed_failures(self):
        for old,new,reason in (('state=4','state=6','source_not_complete'),
                ('faults=0','faults=256','source_fault'),
                ('handoff_fault=0','handoff_fault=1','controller_handoff_fault'),
                ('consumer_max_us=1000','consumer_max_us=16001','freshness_cap_exceeded'),
                ('owned=1','owned=0','terminal_owner_not_retained')):
            result = A.parse_trace(receipt().replace(old,new))
            self.assertFalse(result['lean_receipt_coherent'])
            self.assertIn(reason,result['captures'][0]['issues'])

    def test_handoff_extension_normal_and_each_explicit_failure_reason(self):
        result = A.parse_trace(receipt(extended=True))
        self.assertTrue(result['lean_receipt_coherent'])
        observation = result['captures'][0]['handoff_observation']
        self.assertTrue(observation['reason_details_available'])
        self.assertEqual(observation['reason_names'], [])
        for mask in range(1,16):
            text = receipt(extended=True).replace('handoff_fault=0','handoff_fault=1')
            text = text.replace('handoff_reason=0','handoff_reason='+str(mask))
            text = text.replace('frame_high=2','frame_high=3').replace('status_high=3','status_high=15')
            if mask & 12:
                text = text.replace('handoff_age_us=0','handoff_age_us=20000')
                text = text.replace('consumer_max_us=1000','consumer_max_us=20000')
            with self.subTest(mask=mask):
                result = A.parse_trace(text)
                observation = result['captures'][0]['handoff_observation']
                self.assertFalse(result['lean_receipt_coherent'])
                self.assertEqual(observation['reason_mask'], mask)
                self.assertEqual(observation['reason_names'],[name for bit,name in A.HANDOFF_REASONS.items() if mask & bit])
                self.assertEqual(observation['max_rejected_stale_age_us'],20000 if mask & 12 else 0)

    def test_partial_inconsistent_or_unknown_handoff_extension_is_refused(self):
        normal = receipt(extended=True)
        for old,new in ((' handoff_reason=0',''),(' status_high=3',''),
                ('handoff_reason=0','handoff_reason=16'),('handoff_reason=0','handoff_reason=1'),
                ('frame_high=2','frame_high=4'),('status_high=3','status_high=16'),
                ('handoff_age_us=0','handoff_age_us=1'),('handoff_fault=0','handoff_fault=1'),
                ('frame_high=2','frame_high=10')):
            with self.subTest(new=new),self.assertRaises(ValueError):A.parse_trace(normal.replace(old,new))
        fault = normal.replace('handoff_fault=0','handoff_fault=1')
        for text in (fault.replace('handoff_reason=0','handoff_reason=1'),
                fault.replace('handoff_reason=0','handoff_reason=2'),
                fault.replace('handoff_reason=0','handoff_reason=4'),
                fault.replace('handoff_reason=0','handoff_reason=8'),
                fault.replace('handoff_reason=0','handoff_reason=4').replace('handoff_age_us=0','handoff_age_us=16000'),
                fault.replace('handoff_reason=0','handoff_reason=4').replace('handoff_age_us=0','handoff_age_us=20000')):
            with self.assertRaises(ValueError):A.parse_trace(text)

    def test_legacy_handoff_fault_remains_ambiguous_and_old_failure_is_preserved(self):
        result = A.parse_trace(receipt().replace('handoff_fault=0','handoff_fault=1'))
        observation = result['captures'][0]['handoff_observation']
        self.assertFalse(result['lean_receipt_coherent'])
        self.assertFalse(observation['reason_details_available'])
        self.assertIsNone(observation['reason_mask'])
        self.assertIsNone(observation['reason_names'])
        self.assertIsNone(observation['max_rejected_stale_age_us'])
        path = ROOT/'captures/sitesim-rx-feed-20261115T005743588000Z/rxfeed.private.log'
        if path.is_file():
            before = path.read_bytes();result = A.parse_trace(path.read_text())
            self.assertFalse(result['lean_receipt_coherent'])
            self.assertFalse(result['captures'][0]['handoff_observation']['reason_details_available'])
            self.assertEqual(path.read_bytes(),before)

    def test_controller_latency_extension_is_descriptive_and_all_or_none(self):
        text=receipt(extended=True,latency=True)
        result=A.parse_trace(text)
        self.assertTrue(result['lean_receipt_coherent'])
        timing=result['captures'][0]['controller_latency_observation']
        self.assertTrue(timing['details_available'])
        self.assertEqual(timing['max_controller_drain_entry_gap_us'],22000)
        self.assertEqual(timing['max_frame_apply_us'],400)
        self.assertEqual(timing['max_indicator_us'],3000)
        self.assertFalse(timing['isolated_cpu_time'])
        self.assertFalse(timing['wall_clock_budget_qualified'])
        legacy=A.parse_trace(receipt(extended=True))['captures'][0]['controller_latency_observation']
        self.assertFalse(legacy['details_available'])
        self.assertIsNone(legacy['max_indicator_us'])
        for field,value in (('controller_gap_us','22000'),('frame_apply_us','400'),('indicator_us','3000')):
            for replacement in ('',f' {field}=4294967296',f' {field}=01',f' {field}=-1'):
                with self.subTest(field=field,replacement=replacement),self.assertRaises(ValueError):
                    A.parse_trace(text.replace(f' {field}={value}',replacement))
        with self.assertRaises(ValueError):A.parse_trace(receipt(latency=True))

    def test_render_stages_require_complete_prior_extension_and_are_not_deadlines(self):
        text=receipt(extended=True,latency=True,render=True)
        timing=A.parse_trace(text)['captures'][0]['controller_latency_observation']
        self.assertTrue(timing['render_details_available'])
        self.assertEqual(timing['max_view_us'],200)
        self.assertEqual(timing['max_paint_us'],2800)
        for field,value in (('view_us','200'),('paint_us','2800')):
            with self.assertRaises(ValueError):A.parse_trace(text.replace(f' {field}={value}',''))
            with self.assertRaises(ValueError):A.parse_trace(text.replace(f'{field}={value}',f'{field}=4294967296'))
        for old in (receipt(),receipt(extended=True),receipt(extended=True,latency=True)):
            timing=A.parse_trace(old)['captures'][0]['controller_latency_observation']
            self.assertFalse(timing['render_details_available'])
            self.assertIsNone(timing['max_paint_us'])
        for text in (receipt(render=True),receipt(extended=True,render=True)):
            with self.assertRaises(ValueError):A.parse_trace(text)

    def test_rows_and_bounds_fail_closed(self):
        rows=receipt().splitlines()
        for text in ('\n'.join(rows[:3]), receipt()+receipt(), '\n'.join(reversed(rows)),
                receipt()+'\n', receipt().replace('RXFEED_COST','RXEARLY'),
                receipt().replace('frames=9','frames=9\x00'), receipt()+' '*8192):
            with self.assertRaises(ValueError):A.parse_trace(text)

    def test_actual_adapter_receipts_when_present(self):
        found = False
        paths = list((ROOT/'build/test-rx-feed-adapter').glob('native-feed-*.dump'))
        if (ROOT/'build/test-rx-feed-adapter/receipt.private.log').is_file():
            paths.append(ROOT/'build/test-rx-feed-adapter/receipt.private.log')
        for path in paths:
            found = True
            result = A.parse_trace(path.read_text())
            self.assertTrue(result['lean_receipt_coherent'], result)
        if not found:self.skipTest('Native adapter fixtures not generated yet')

    def test_cli_retains_input_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'build') as folder:
            path=Path(folder)/'receipt.log';target=Path(folder)/'analysis.json';path.write_text(receipt())
            before=path.read_bytes()
            subprocess.run([sys.executable,'-B',str(ROOT/'scripts/analyze-p25-rx-feed.py'),
                str(path),'--output',str(target)],check=True,capture_output=True)
            self.assertEqual(path.read_bytes(),before)
            self.assertTrue(json.loads(target.read_text())['lean_receipt_coherent'])
            result=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/analyze-p25-rx-feed.py'),
                str(path),'--output',str(path)],capture_output=True)
            self.assertNotEqual(result.returncode,0);self.assertEqual(path.read_bytes(),before)


if __name__ == '__main__':unittest.main(verbosity=2)
