// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx_progress.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

static unsigned checks;
#define CHECK(x) do {++checks;assert(x);} while(0)
typedef struct {
    p25_rx_progress *state;
    uint8_t ram[P25_RX_PROGRESS_RAM_BYTES];
    uint32_t now,end_delta;
    unsigned reads,clocks,max_offset,mutate_at,irq_at;
    bool flip_high;
} reader;
static void sample(reader *r,unsigned half,unsigned index,int value) {
    unsigned offset=half*512+2*index;
    r->ram[offset]=(uint8_t)((unsigned)value>>8);r->ram[offset+1]=(uint8_t)value;
}
static void fill(reader *r) {
    for(unsigned half=0;half<2;++half)for(unsigned index=0;index<256;++index)sample(r,half,index,(int)(1000+half*1000+index));
    sample(r,0,0,-32768);sample(r,1,255,-1);
}
static uint8_t read_byte(void *ctx,unsigned offset) {
    reader *r=ctx;CHECK(offset<P25_RX_PROGRESS_RAM_BYTES);if(offset>r->max_offset)r->max_offset=offset;
    ++r->reads;
    if(r->reads==r->mutate_at) {
        if(r->flip_high)r->ram[0]^=1;else sample(r,0,0,0x1234);
    }
    if(r->reads==r->irq_at)CHECK(p25_rx_progress_irq(r->state,2,r->now+1));
    return r->ram[offset];
}
static uint32_t clock_us(void *ctx) {reader *r=ctx;return r->now+((r->clocks++&1u) ? r->end_delta : 0);}
static p25_rx_progress_io io_for(reader *r) {return (p25_rx_progress_io){.context=r,.read_byte=read_byte,.clock_us=clock_us};}
static p25_rx_progress_config config(unsigned count) {return (p25_rx_progress_config){(uint16_t)count,250,1000000};}
static bool poll(p25_rx_progress *s,reader *r,uint32_t now) {r->now=now;p25_rx_progress_io io=io_for(r);return p25_rx_progress_poll(s,&io,now);}
static void start(p25_rx_progress *s,reader *r,void *storage,size_t bytes,unsigned count,uint32_t now) {
    p25_rx_progress_init(s);memset(r,0,sizeof *r);r->state=s;fill(r);p25_rx_progress_config c=config(count);
    CHECK(p25_rx_progress_start(s,storage,bytes,&c,now));
}
static void refusals_and_readonly(void) {
    p25_rx_progress s;reader r;unsigned char memory[400];memset(memory,0x5a,sizeof memory);
    p25_rx_progress_init(&s);p25_rx_progress before=s;p25_rx_progress_config c=config(2);
    CHECK(!p25_rx_progress_start(NULL,memory,sizeof memory,&c,0));
    CHECK(!p25_rx_progress_start(&s,NULL,sizeof memory,&c,0));CHECK(!p25_rx_progress_start(&s,memory,sizeof memory,NULL,0));
    for(unsigned failure=0;failure<7;++failure) {
        p25_rx_progress_config invalid=c;
        if(failure==0)invalid.rows=0;
        if(failure==1)invalid.rows=129;
        if(failure==2)invalid.cadence_us=249;
        if(failure==3)invalid.cadence_us=8001;
        if(failure==4)invalid.timeout_us=31999;
        if(failure==5)invalid.timeout_us=2000001;
        if(failure==6) {invalid.rows=128;invalid.cadence_us=8000;invalid.timeout_us=32000;}
        CHECK(!p25_rx_progress_start(&s,memory,sizeof memory,&invalid,0));CHECK(!memcmp(&s,&before,sizeof s));
    }
    CHECK(!p25_rx_progress_start(&s,memory,191,&c,0));
    CHECK(!p25_rx_progress_start(&s,&s,sizeof memory,&c,0));
    CHECK(!memcmp(&s,&before,sizeof s));for(unsigned i=0;i<sizeof memory;++i)CHECK(memory[i]==0x5a);
    start(&s,&r,memory+1,sizeof memory-2,2,1000); // Deliberately unaligned storage is legal.
    before=s;CHECK(!p25_rx_progress_start(&s,memory,sizeof memory,&c,1001));CHECK(!memcmp(&s,&before,sizeof s));
    CHECK(!poll(&s,&r,1100) && !r.reads && !r.clocks && s.state==P25_RX_PROGRESS_WAIT_IRQ);
    CHECK(!p25_rx_progress_irq(&s,0,1100) && s.invalid_irqs==1 && !s.valid_irqs);
    CHECK(!p25_rx_progress_irq(&s,3,1101) && s.invalid_irqs==2 && s.state==P25_RX_PROGRESS_WAIT_IRQ);
    CHECK(!poll(&s,&r,1200) && !r.reads);
    p25_rx_progress_cancel(&s);CHECK(s.state==P25_RX_PROGRESS_CANCELLED);
    CHECK(!poll(&s,&r,1300) && !p25_rx_progress_irq(&s,1,1300) && !r.reads && !r.clocks);
}
static void records_and_layout(void) {
    // This is the same declared type as monitor.pcm. The core must use only
    // character access, not create row-struct aliases into this array.
    int16_t borrowed[48][160];memset(borrowed,0x5a,sizeof borrowed);
    p25_rx_progress s;reader r;start(&s,&r,borrowed,sizeof borrowed,2,1000);
    CHECK(p25_rx_progress_irq(&s,1,1100));CHECK(poll(&s,&r,1100));
    CHECK(s.count==1 && r.reads==96 && r.clocks==2 && r.max_offset==1023);
    p25_rx_progress_row out,old;memset(&out,0xa5,sizeof out);old=out;
    CHECK(!p25_rx_progress_read(&s,0,&out) && !memcmp(&out,&old,sizeof out));
    CHECK(!poll(&s,&r,1349) && r.reads==96);CHECK(poll(&s,&r,1350));
    CHECK(s.state==P25_RX_PROGRESS_DONE && s.count==2 && r.reads==192 && r.clocks==4);
    CHECK(p25_rx_progress_read(&s,0,&out));
    CHECK(out.first[0]==-32768 && out.first[15]==-1 && !memcmp(out.first,out.second,sizeof out.first));
    for(unsigned half=0;half<2;++half)for(unsigned index=0;index<8;++index) {
        int expected=half==0 && index==0 ? -32768 : half==1 && index==7 ? -1 : 1000+(int)half*1000+p25_rx_progress_indices[index];
        CHECK(out.first[half*8+index]==expected);
    }
    CHECK(out.cpu_begin_us==1100 && out.cpu_end_us==1100 && out.irq_begin_us==1100 && out.irq_end_us==1100);
    CHECK(out.irq_count_begin==1 && out.irq_count_end==1 && out.half_begin==1 && out.half_end==1 && !out.flags);
    const unsigned char *wire=(const unsigned char*)borrowed;
    CHECK(wire[0]==0 && wire[1]==0x80 && wire[30]==0xff && wire[31]==0xff);
    CHECK(wire[64]==0x4c && wire[65]==4 && !wire[66] && !wire[67] && wire[80]==1 && wire[92]==1 && !wire[94]);
    for(unsigned i=2*96;i<sizeof borrowed;++i)CHECK(wire[i]==0x5a);
    CHECK(!p25_rx_progress_read(&s,UINT_MAX,&out) && !p25_rx_progress_read(&s,2,&out));
    unsigned reads=r.reads,clocks=r.clocks;CHECK(!poll(&s,&r,2000) && r.reads==reads && r.clocks==clocks);
    p25_rx_progress_cancel(&s);CHECK(s.state==P25_RX_PROGRESS_DONE);
}
static void changing_memory_and_irqs(void) {
    for(unsigned mode=0;mode<5;++mode) {
        unsigned char bytes[96];p25_rx_progress s;reader r;start(&s,&r,bytes,sizeof bytes,1,100);
        CHECK(p25_rx_progress_irq(&s,1,110));r.end_delta=2;
        if(mode==0)r.mutate_at=49;
        if(mode==1) {r.mutate_at=2;r.flip_high=true;}
        if(mode==2)r.irq_at=24;
        if(mode==3)s.irq_serial|=1u; // Bounded metadata observation detects an in-flight writer.
        if(mode==4) {CHECK(!p25_rx_progress_irq(&s,7,111));CHECK(p25_rx_progress_irq(&s,1,112));}
        CHECK(poll(&s,&r,112));p25_rx_progress_row out;CHECK(p25_rx_progress_read(&s,0,&out));
        if(mode==0)CHECK(out.changed_mask==1 && !out.torn_mask && (out.flags&P25_RX_PROGRESS_VALUES_CHANGED));
        if(mode==1)CHECK(out.torn_mask==1 && (out.flags&P25_RX_PROGRESS_WORD_TORN));
        if(mode==2)CHECK(out.irq_count_begin==1 && out.irq_count_end==2 && out.half_begin==1 && out.half_end==2
            && out.irq_begin_us==110 && out.irq_end_us==113 && (out.flags&P25_RX_PROGRESS_IRQ_DURING_READ));
        if(mode==3)CHECK(out.flags&P25_RX_PROGRESS_META_UNSTABLE);
        if(mode==4)CHECK(s.invalid_irqs==1 && s.sequence_errors==1 && (out.flags&P25_RX_PROGRESS_INVALID_IRQ)
            && (out.flags&P25_RX_PROGRESS_IRQ_SEQUENCE));
        CHECK(r.reads==96 && r.max_offset==1023);
    }
}
static void deadlines_and_wrap(void) {
    unsigned char bytes[192];p25_rx_progress s;reader r;start(&s,&r,bytes,sizeof bytes,2,UINT32_MAX-100u);
    CHECK(p25_rx_progress_irq(&s,1,UINT32_MAX-50u));CHECK(poll(&s,&r,UINT32_MAX-50u));
    CHECK(!poll(&s,&r,198));CHECK(poll(&s,&r,199));CHECK(s.state==P25_RX_PROGRESS_DONE);
    p25_rx_progress_row out;CHECK(p25_rx_progress_read(&s,1,&out));CHECK(out.cpu_begin_us==199 && !(out.flags&P25_RX_PROGRESS_CLOCK_ANOMALY));
    start(&s,&r,bytes,sizeof bytes,2,100);CHECK(!poll(&s,&r,1000100) && s.state==P25_RX_PROGRESS_TIMEOUT && !r.reads);
    start(&s,&r,bytes,sizeof bytes,2,100);CHECK(!p25_rx_progress_irq(&s,1,1000100) && s.state==P25_RX_PROGRESS_TIMEOUT);
    start(&s,&r,bytes,sizeof bytes,2,1000);CHECK(p25_rx_progress_irq(&s,1,1100));CHECK(poll(&s,&r,1200));
    CHECK(!poll(&s,&r,1199) && s.state==P25_RX_PROGRESS_CLOCK_ERROR && r.reads==96);
    start(&s,&r,bytes,sizeof bytes,2,1000);CHECK(p25_rx_progress_irq(&s,1,1100));
    CHECK(!p25_rx_progress_irq(&s,2,1099) && s.state==P25_RX_PROGRESS_CLOCK_ERROR && !r.reads);
    start(&s,&r,bytes,sizeof bytes,2,0);CHECK(p25_rx_progress_irq(&s,1,100));CHECK(poll(&s,&r,70000));
    CHECK(s.count==1 && s.missed_periods==279 && !poll(&s,&r,70000) && r.reads==96);
    p25_rx_progress_cancel(&s);CHECK(p25_rx_progress_read(&s,0,&out));CHECK(out.missed_periods==255 && (out.flags&P25_RX_PROGRESS_MISSED_CADENCE));
    start(&s,&r,bytes,sizeof bytes,1,0);CHECK(p25_rx_progress_irq(&s,1,100));r.end_delta=UINT32_MAX;
    CHECK(poll(&s,&r,100) && s.state==P25_RX_PROGRESS_CLOCK_ERROR);CHECK(p25_rx_progress_read(&s,0,&out));
    CHECK(out.flags&P25_RX_PROGRESS_CLOCK_ANOMALY);
    start(&s,&r,bytes,sizeof bytes,1,0);s.timeout_us=32000;CHECK(p25_rx_progress_irq(&s,1,100));r.end_delta=2;
    CHECK(poll(&s,&r,31999) && s.state==P25_RX_PROGRESS_TIMEOUT && s.count==1);
    start(&s,&r,bytes,sizeof bytes,1,0);CHECK(p25_rx_progress_irq(&s,1,100));
    p25_rx_progress_io bad=io_for(&r);bad.read_byte=NULL;CHECK(!p25_rx_progress_poll(&s,&bad,100) && !r.reads && !r.clocks);
}
static void finite_bounds(void) {
    unsigned char storage[P25_RX_PROGRESS_STORAGE_BYTES+2];memset(storage,0x5a,sizeof storage);
    p25_rx_progress s;reader r;start(&s,&r,storage+1,sizeof storage-2,128,0);s.timeout_us=32000;
    CHECK(p25_rx_progress_irq(&s,1,100));
    for(unsigned row=0;row<128;++row)CHECK(poll(&s,&r,100+row*250));
    CHECK(s.state==P25_RX_PROGRESS_DONE && s.count==128 && r.reads==128*96 && r.clocks==256);
    CHECK(storage[0]==0x5a && storage[sizeof storage-1]==0x5a);
    CHECK(!poll(&s,&r,31999) && r.reads==128*96);
}
int main(void) {
    CHECK(sizeof(p25_rx_progress_row)==96 && sizeof(p25_rx_progress)<=128);
    refusals_and_readonly();records_and_layout();changing_memory_and_irqs();deadlines_and_wrap();finite_bounds();
    printf("RX live-half progress: PASS (%u checks; state %uB; row %uB; finite storage %uB)\n",
        checks,(unsigned)sizeof(p25_rx_progress),(unsigned)sizeof(p25_rx_progress_row),(unsigned)P25_RX_PROGRESS_STORAGE_BYTES);
    return 0;
}
