# SPDX-License-Identifier: GPL-3.0-or-later
"""Native subscriber policy and independent complete OP25 wire exchange. No RF."""
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build/test-p25-trunking-access"
BUILD.mkdir(parents=True, exist_ok=True)
EXE = BUILD / ("policy.exe" if sys.platform == "win32" else "policy")
subprocess.run(["gcc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-Wshadow",
    "-pedantic", "-Isrc/firmware", "tests/test_p25_trunking_access.c",
    "src/firmware/p25_trunking_access.c", "src/firmware/p25_trunking_isp.c",
    "src/firmware/p25_tsdu.c", "src/firmware/p25_rx.c", "-o", str(EXE)],
    cwd=ROOT, check=True)

spec = importlib.util.spec_from_file_location("independent_trunking_fixture",
    ROOT / "scripts/generate-p25-trunking-fixture.py")
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
reference = fixture.load_reference()
rid, group, system, wacn, nac = 1234567, 10, 0x123, 0xABCDE, 0x293
# Independently encoded OSP registration, affiliation and own-source grant.
responses = [
    (0x2C, (system << 48) | (rid << 24) | rid),
    (0x28, (1 << 63) | (group << 24) | rid),
    (0x00, (0x85 << 56) | (0xA321 << 40) | (group << 24) | rid),
    # Same requester, different channel/options: must not replace the first.
    (0x00, (3 << 56) | (0xA322 << 40) | (group << 24) | rid),
]
inbound = BUILD / "responses.bin"
outbound = BUILD / "requests.bin"
security = BUILD / "unsupported.bin"
inbound.write_bytes(b"".join(fixture.encode_tsdu(reference, nac, [item])[0]
    for item in responses))
unsupported = []
for opcode in (0x2A, 0x2D, 0x32):
    # Own, foreign, then foreign addressed with own RID in the other field.
    for target, source in ((rid, 123), (rid+1, 123), (rid+1, rid)):
        argument = ((source << 24) | target) if opcode == 0x32 else ((target << 24) | source)
        unsupported.append((opcode, argument))
unsupported.extend(((0x31, 0), (0x2A, (1 << 48) | (rid << 24)),
                    (0x2A, (0xFFFFFF << 24) | 123)))
security.write_bytes(b"".join(fixture.encode_tsdu(reference, nac, [item])[0]
    for item in unsupported))
subprocess.run([str(EXE), str(inbound), str(outbound), str(security)], cwd=ROOT, check=True)
# ISP expected arguments mirror their named upstream factories, independently
# encoded by OP25 (CRC, BCH, trellis, interleave, status and pad included).
requests = [
    (0x2C, (wacn << 36) | (system << 24) | rid),
    (0x28, (system << 40) | (group << 24) | rid),
    (0x00, (group << 24) | rid),
]
expected = b"".join(fixture.encode_tsdu(reference, nac, [item])[0]
    for item in requests)
actual = outbound.read_bytes()
assert actual == expected, (actual.hex(), expected.hex())
print("OP25 encoded registration -> affiliation -> group grant exchange passed; "
      "all three native outbound ISP wire units match independently encoded references")
