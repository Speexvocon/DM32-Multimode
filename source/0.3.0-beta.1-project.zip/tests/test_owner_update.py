"""Routine update checks with synthetic packages and the pinned loader simulator."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import runpy
import struct
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/update-owner-firmware.py"
spec = importlib.util.spec_from_file_location("owner_update", SCRIPT)
UPDATE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(UPDATE)
UPSTREAM = ROOT / "external/RadioFoundry/RadioFoundry"
LOADER = runpy.run_path(str(UPSTREAM / "tools/serial_loader.py"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


class OwnerUpdateTests(unittest.TestCase):
    def setUp(self):
        (ROOT / "build").mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="test-owner-update-", dir=ROOT / "build")
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.live = self.directory / "live"
        self.live.mkdir()
        self.owner = self.directory / "original-program.bin"
        self.owner.write_bytes(b"synthetic original program; no data-flash file")
        self.commit = "a" * 40
        self.application = bytes(range(1, 129))
        elf = bytearray(64)
        elf[:6] = b"\x7fELF\x01\x01"
        struct.pack_into("<H", elf, 18, 252)
        struct.pack_into("<I", elf, 24, UPDATE.APP_BASE)
        self.products = {".bin": self.application, ".elf": bytes(elf), ".map": b"synthetic target map"}
        self.run = {"id": 12345, "head_sha": self.commit, "status": "completed", "conclusion": "success",
                    "path": ".github/workflows/dm32-firmware.yml"}
        self.write_metadata()
        self.write_products()

    def write_metadata(self):
        (self.directory / "github-run.json").write_text(json.dumps(self.run))
        (self.directory / "project-commit.txt").write_text(self.commit + "\n")
        (self.directory / "upstream-commit.txt").write_text(UPDATE.UPSTREAM_PIN + "\n")

    def write_products(self):
        sums = []
        for suffix, content in self.products.items():
            name = UPDATE.STEM + suffix
            (self.live / name).write_bytes(content)
            sums.append(digest(content) + "  /home/runner/work/build/live/" + name)
        # The artifact root contains a different benchmark with the same basename.
        # A quick update must select the live products, never this matching name.
        sums.insert(0, "0" * 64 + "  /home/runner/work/build/" + UPDATE.STEM + ".bin")
        (self.directory / "SHA256SUMS").write_text("\n".join(sums) + "\n")

    def synthetic_merge(self, application, owner):
        self.assertEqual(owner, self.owner.read_bytes())
        raw = application + b"\xff" * (UPDATE.CODEC_BASE - UPDATE.APP_BASE - len(application)) + b"synthetic codec slot"
        vendor = b"synthetic vendor header" + raw
        return raw, vendor, {"merged_sha256": digest(raw), "vendor_package_sha256": digest(vendor)}

    def prepare(self, directory=None, merge=None):
        with patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM), \
                patch.object(UPDATE, "owner_package", return_value={"merge_owner": merge or self.synthetic_merge}):
            return UPDATE.prepare_update(directory or self.directory, self.owner)

    def test_live_products_validate_offline_without_data_backup_or_radio_tools(self):
        with patch.object(UPDATE, "transfer", side_effect=AssertionError("no serial")):
            raw, report = self.prepare()
            direct_raw, direct_report = self.prepare(self.live)
        self.assertEqual(raw, direct_raw)
        self.assertEqual(report, direct_report)
        self.assertEqual(raw[:len(self.application)], self.application)
        self.assertEqual(report["source_commit"], self.commit)
        self.assertEqual(report["ci_run_id"], 12345)
        self.assertTrue(report["native_codec_included"])
        for name in ("fresh_backup_performed", "preservation_read_performed", "independent_readback_performed",
                     "transfer_completed", "hardware_access", "native_codec_written", "flash_write_started"):
            self.assertIs(report[name], False)
        self.assertFalse((self.directory / "data.bin").exists())

    def test_failed_or_mismatched_ci_refuses_before_native_merge(self):
        cases = ({"status": "in_progress"}, {"conclusion": "failure"}, {"head_sha": "b" * 40},
                 {"id": 0}, {"id": True}, {"path": ".github/workflows/unrelated.yml"})
        for changes in cases:
            with self.subTest(changes=changes):
                original = dict(self.run)
                self.run.update(changes)
                self.write_metadata()
                with self.assertRaises(ValueError):
                    self.prepare(merge=lambda *_: self.fail("invalid CI reached native merge"))
                self.run = original
                self.write_metadata()

    def test_missing_corrupt_and_duplicate_live_hashes_refuse_before_merge(self):
        sums = (self.directory / "SHA256SUMS").read_text()
        cases = [sums.replace(digest(self.application), "0" * 64),
                 "\n".join(line for line in sums.splitlines() if "/live/" + UPDATE.STEM + ".elf" not in line),
                 sums + sums.splitlines()[-1] + "\n"]
        for content in cases:
            with self.subTest(content=content[:70]):
                (self.directory / "SHA256SUMS").write_text(content)
                with self.assertRaises(ValueError):
                    self.prepare(merge=lambda *_: self.fail("invalid hashes reached native merge"))
        (self.directory / "SHA256SUMS").write_text(sums)
        (self.live / (UPDATE.STEM + ".bin")).write_bytes(b"changed after download")
        with self.assertRaises(ValueError):
            self.prepare(merge=lambda *_: self.fail("corrupt file reached native merge"))

    def test_wrong_elf_machine_entry_or_truncation_refuses_even_with_correct_hash(self):
        original = self.products[".elf"]
        bad_machine = bytearray(original)
        struct.pack_into("<H", bad_machine, 18, 40)
        bad_entry = bytearray(original)
        struct.pack_into("<I", bad_entry, 24, UPDATE.APP_BASE + 4)
        for content in (bytes(bad_machine), bytes(bad_entry), original[:27]):
            with self.subTest(length=len(content)):
                self.products[".elf"] = content
                self.write_products()
                with self.assertRaises(ValueError):
                    self.prepare(merge=lambda *_: self.fail("wrong ELF reached native merge"))

    def test_wrong_upstream_and_application_slot_overlap_refuse(self):
        (self.directory / "upstream-commit.txt").write_text("b" * 40)
        with self.assertRaises(ValueError):
            self.prepare()
        self.write_metadata()
        self.products[".bin"] = b"A" * (UPDATE.CODEC_BASE - UPDATE.APP_BASE + 1)
        self.write_products()
        with self.assertRaisesRegex(ValueError, "overlaps"):
            self.prepare(merge=lambda *_: self.fail("overlap reached native merge"))

    def test_real_native_engine_refuses_unrecognized_original_program(self):
        self.owner.write_bytes(b"\xa5" * 0x100000)
        with patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM):
            with self.assertRaisesRegex(ValueError, "Owner backup differs"):
                UPDATE.prepare_update(self.directory, self.owner)

    def test_codec_free_or_hash_inconsistent_merge_is_never_staged(self):
        def bare(application, owner):
            return application, application, {"merged_sha256": digest(application),
                                              "vendor_package_sha256": digest(application)}
        with self.assertRaisesRegex(ValueError, "codec is missing"):
            self.prepare(merge=bare)
        def changed(application, owner):
            raw, vendor, manifest = self.synthetic_merge(application, owner)
            manifest["merged_sha256"] = "0" * 64
            return raw, vendor, manifest
        with self.assertRaisesRegex(ValueError, "checksum mismatch"):
            self.prepare(merge=changed)

    def test_stage_uses_validated_bytes_after_source_changes_and_does_not_claim_readback(self):
        raw, report = self.prepare()
        (self.live / (UPDATE.STEM + ".bin")).write_bytes(b"later application")
        self.owner.write_bytes(b"later source")
        directory = UPDATE.stage_update(raw, report, root=self.directory)
        self.assertEqual((directory / "application-with-codec.bin").read_bytes(), raw)
        saved = json.loads((directory / "package.json").read_text())
        self.assertEqual(saved, report)
        self.assertIs(saved["independent_readback_performed"], False)
        self.assertIs(saved["hardware_access"], False)
        with self.assertRaisesRegex(ValueError, "changed before staging"):
            UPDATE.stage_update(raw + b"changed", report, root=self.directory)

    def test_upstream_tools_must_be_exact_and_clean(self):
        for responses in (("b" * 40, ""), (UPDATE.UPSTREAM_PIN, " M tools/serial_loader.py")):
            with patch.object(UPDATE.subprocess, "check_output", side_effect=responses):
                with self.assertRaisesRegex(ValueError, "tools have changed"):
                    UPDATE.checked_upstream()

    def test_default_main_is_offline_and_does_not_stage_open_or_read_radio(self):
        raw, report = self.prepare()
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "stage_update", side_effect=AssertionError("plan must not stage")), \
                patch.object(UPDATE, "transfer", side_effect=AssertionError("plan must not transfer")), \
                patch.object(UPDATE.runpy, "run_path", side_effect=AssertionError("plan must not load transport")), \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(UPDATE.main([str(self.directory), "--owner-backup", str(self.owner), "--port", "NOT_A_PORT"]), 0)
        plan = json.loads(output.getvalue())
        self.assertTrue(plan["plan_only"])
        self.assertFalse(plan["hardware_access"])
        self.assertFalse(plan["independent_readback_performed"])
        self.assertFalse(plan["native_codec_written"])
        self.assertFalse(plan["flash_write_started"])
        self.assertTrue(plan["native_codec_included"])

    def test_failed_execution_writes_failure_record_without_claiming_completed_transfer(self):
        raw, report = self.prepare()
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "ROOT", self.directory), \
                patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM), \
                patch.object(UPDATE.runpy, "run_path", return_value={}), \
                patch.object(UPDATE.sys.stdin, "isatty", return_value=True), \
                patch.object(UPDATE, "transfer", side_effect=RuntimeError("simulated NAK failure")), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, "NAK"):
                UPDATE.main([str(self.directory), "--owner-backup", str(self.owner), "--port", "COM99", "--execute"])
        records = list((self.directory / "build/owner-updates").glob("*/transfer.json"))
        self.assertEqual(len(records), 1)
        result = json.loads(records[0].read_text())
        self.assertFalse(result["transfer_completed"])
        self.assertFalse(result["independent_readback_performed"])
        self.assertFalse(result["fresh_backup_performed"])
        self.assertFalse(result["native_codec_written"])
        self.assertFalse(result["flash_write_started"])
        self.assertIn("NAK", result["error"])

    def test_failure_after_factory_erase_header_reports_uncertain_codec_without_retry(self):
        raw, report = self.prepare()
        def interrupted_transfer(image, port, library, *, log):
            self.assertEqual(image, raw)
            log("   bootloader found (BFUV32-V2)")
            log("   step 7: header sent, the radio erases the application area (up to about 15 s) ...")
            raise RuntimeError("simulated failure after erase header")
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "ROOT", self.directory), \
                patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM), \
                patch.object(UPDATE.runpy, "run_path", return_value={}), \
                patch.object(UPDATE.sys.stdin, "isatty", return_value=True), \
                patch.object(UPDATE, "transfer", side_effect=interrupted_transfer) as transfer, \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, "after erase header"):
                UPDATE.main([str(self.directory), "--owner-backup", str(self.owner), "--port", "COM99", "--execute"])
        self.assertEqual(transfer.call_count, 1)
        result = json.loads(next((self.directory / "build/owner-updates").glob("*/transfer.json")).read_text())
        self.assertFalse(result["transfer_completed"])
        self.assertTrue(result["flash_write_started"])
        self.assertIsNone(result["native_codec_written"])
        self.assertFalse(result["independent_readback_performed"])

    def test_execution_requires_explicit_port_and_physical_cue_terminal_before_staging(self):
        raw, report = self.prepare()
        for extra, terminal in (([], True), (["--port", "COM99"], False)):
            with self.subTest(extra=extra, terminal=terminal), \
                    patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                    patch.object(UPDATE.sys.stdin, "isatty", return_value=terminal), \
                    patch.object(UPDATE, "stage_update", side_effect=AssertionError("gate must precede staging")), \
                    patch.object(UPDATE, "transfer", side_effect=AssertionError("gate must precede port open")):
                with self.assertRaises(ValueError):
                    UPDATE.main([str(self.directory), "--owner-backup", str(self.owner), "--execute", *extra])

    def test_success_record_distinguishes_transfer_from_independent_radio_verification(self):
        raw, report = self.prepare()
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "ROOT", self.directory), \
                patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM), \
                patch.object(UPDATE.runpy, "run_path", return_value={"synthetic": True}), \
                patch.object(UPDATE.sys.stdin, "isatty", return_value=True), \
                patch.object(UPDATE, "transfer") as transfer, \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(UPDATE.main([str(self.directory), "--owner-backup", str(self.owner),
                                          "--port", "COM99", "--execute"]), 0)
        self.assertEqual(transfer.call_count, 1)
        self.assertEqual(transfer.call_args.args, (raw, "COM99", {"synthetic": True}))
        self.assertTrue(callable(transfer.call_args.kwargs["log"]))
        records = list((self.directory / "build/owner-updates").glob("*/transfer.json"))
        self.assertEqual(len(records), 1)
        result = json.loads(records[0].read_text())
        self.assertTrue(result["transfer_completed"])
        self.assertTrue(result["hardware_access"])
        self.assertTrue(result["native_codec_written"])
        self.assertTrue(result["flash_write_started"])
        self.assertFalse(result["independent_readback_performed"])
        self.assertFalse(result["preservation_read_performed"])
        self.assertFalse(result["fresh_backup_performed"])
        self.assertNotIn("error", result)
        self.assertEqual((records[0].parent / "application-with-codec.bin").read_bytes(), raw)

    def runtime_runner(self, calls, failure=None):
        def run(command, *, stdout, stderr, text, timeout, check):
            calls.append((command, dict(stderr=stderr, text=text, timeout=timeout, check=check)))
            path = Path(command[command.index("--write-app") + 1])
            image = path.read_bytes()
            size = len(image)
            sectors = (size + 4095) // 4096
            if failure == "span":
                size += 1
            if failure != "summary":
                stdout.write(f"{path}: {size} bytes, {sectors} sectors written, 0 unchanged, verified by CRC, 1 s\n")
            stdout.write("sha256 " + ("0" * 64 if failure == "sha" else digest(image)) + "\n")
            if failure != "reset":
                stdout.write("chip reset sent: the radio restarts into its firmware\n")
            return SimpleNamespace(returncode=1 if failure == "exit" else 0)
        return run

    def test_runtime_stage_contains_application_only_and_retains_codec_exclusion(self):
        raw, report = self.prepare()
        directory = UPDATE.stage_update(raw, report, root=self.directory, transport="runtime")
        self.assertEqual({p.name for p in directory.iterdir()}, {"application.bin", "package.json"})
        self.assertEqual((directory / "application.bin").read_bytes(), self.application)
        manifest = json.loads((directory / "package.json").read_text())
        self.assertEqual(manifest["payload_bytes"], len(self.application))
        self.assertEqual(manifest["payload_sha256"], digest(self.application))
        self.assertEqual(manifest["transport"], "runtime")
        self.assertFalse(manifest["native_codec_written"])
        self.assertNotIn("transport", report, "staging must not mutate the caller's preparation report")
        for invalid in (0, True, UPDATE.CODEC_BASE - UPDATE.APP_BASE + 1):
            changed = {**report, "application_bytes": invalid}
            with self.subTest(size=invalid), self.assertRaises(ValueError):
                UPDATE.runtime_application(raw, changed)

    def test_runtime_uses_one_exact_stub_command_and_sector_crc_evidence(self):
        raw, report = self.prepare()
        directory = UPDATE.stage_update(raw, report, root=self.directory, transport="runtime")
        calls = []
        with patch.object(UPDATE, "transfer", side_effect=AssertionError("no factory fallback")):
            result = UPDATE.transfer_runtime(directory, report, "COM99", UPSTREAM,
                runner=self.runtime_runner(calls), log=lambda _: None)
        self.assertEqual(len(calls), 1)
        command, options = calls[0]
        self.assertEqual(command, [sys.executable, "-u", str(UPSTREAM / "stub/stubtool.py"), "COM99",
            "--rfoundry-enter", "--write-app", str(directory / "application.bin"),
            "--boot", "reset", "--done-led", "none"])
        forbidden = {"--force", "--replace-stage", "--progmem", "--q128", "--verify-progmem", "--verify-q128",
                     "--write-q128", "--attach", "--slow-cable"}
        self.assertTrue(forbidden.isdisjoint(command))
        self.assertIs(options["check"], False)
        self.assertTrue(result["runtime_sector_crc_verified"])
        self.assertFalse(result["native_codec_written"])
        self.assertFalse(result["independent_readback_performed"])
        self.assertTrue(result["flash_write_started"])
        self.assertEqual((result["payload_bytes"], result["payload_sha256"]),
                         (len(self.application), digest(self.application)))

    def test_runtime_staged_tampering_refuses_before_child_process(self):
        raw, report = self.prepare()
        for target in ("application.bin", "package.json"):
            directory = UPDATE.stage_update(raw, report, root=self.directory, transport="runtime")
            if target == "application.bin":
                (directory / target).write_bytes(self.application + b"later edit")
            else:
                manifest = json.loads((directory / target).read_text())
                manifest["payload_bytes"] += 1
                (directory / target).write_text(json.dumps(manifest))
            with self.subTest(target=target), self.assertRaises(ValueError):
                UPDATE.transfer_runtime(directory, report, "COM99", UPSTREAM,
                    runner=lambda *a, **k: self.fail("tampered bytes must not reach the runtime tool"), log=lambda _: None)
            self.assertFalse((directory / "runtime-transfer.log").exists())

    def test_runtime_bad_exit_or_missing_matching_crc_sha_reset_fails_without_fallback(self):
        raw, report = self.prepare()
        for failure in ("exit", "summary", "sha", "span", "reset"):
            directory = UPDATE.stage_update(raw, report, root=self.directory, transport="runtime")
            calls = []
            with self.subTest(failure=failure), \
                    patch.object(UPDATE, "transfer", side_effect=AssertionError("no factory fallback")):
                with self.assertRaises(ValueError):
                    UPDATE.transfer_runtime(directory, report, "COM99", UPSTREAM,
                        runner=self.runtime_runner(calls, failure), log=lambda _: None)
            self.assertEqual(len(calls), 1)
            self.assertTrue((directory / "runtime-transfer.log").is_file())

    def test_runtime_main_has_no_tty_requirement_and_records_crc_not_full_readback(self):
        raw, report = self.prepare()
        calls = []
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "ROOT", self.directory), \
                patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM), \
                patch.object(UPDATE.subprocess, "run", side_effect=self.runtime_runner(calls)), \
                patch.object(UPDATE.runpy, "run_path", side_effect=AssertionError("runtime must not load factory transport")), \
                patch.object(UPDATE.sys.stdin, "isatty", side_effect=AssertionError("runtime needs no physical cue")), \
                patch.object(UPDATE, "transfer", side_effect=AssertionError("no factory fallback")), \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(UPDATE.main([str(self.directory), "--owner-backup", str(self.owner), "--port", "COM99",
                                          "--transport", "runtime", "--execute"]), 0)
        self.assertEqual(len(calls), 1)
        record = next((self.directory / "build/owner-updates").glob("*/transfer.json"))
        result = json.loads(record.read_text())
        self.assertEqual(result["transport"], "runtime")
        self.assertTrue(result["transfer_completed"])
        self.assertTrue(result["runtime_sector_crc_verified"])
        for name in ("independent_readback_performed", "preservation_read_performed", "fresh_backup_performed", "native_codec_written"):
            self.assertFalse(result[name])
        self.assertFalse((record.parent / "application-with-codec.bin").exists())

    def test_runtime_default_plan_and_failed_execution_never_fall_back_to_factory(self):
        raw, report = self.prepare()
        arguments = [str(self.directory), "--owner-backup", str(self.owner), "--port", "COM99", "--transport", "runtime"]
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "stage_update", side_effect=AssertionError("offline plan must not stage")), \
                patch.object(UPDATE.subprocess, "run", side_effect=AssertionError("offline plan must not spawn")), \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(UPDATE.main(arguments), 0)
        plan = json.loads(output.getvalue())
        self.assertTrue(plan["plan_only"])
        self.assertEqual(plan["transport"], "runtime")
        self.assertFalse(plan["native_codec_written"])
        self.assertFalse(plan["flash_write_started"])
        calls = []
        with patch.object(UPDATE, "prepare_update", return_value=(raw, report)), \
                patch.object(UPDATE, "ROOT", self.directory), \
                patch.object(UPDATE, "checked_upstream", return_value=UPSTREAM), \
                patch.object(UPDATE.subprocess, "run", side_effect=self.runtime_runner(calls, "exit")), \
                patch.object(UPDATE, "transfer", side_effect=AssertionError("no factory fallback")), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(ValueError, "Runtime transfer failed"):
                UPDATE.main(arguments + ["--execute"])
        result = json.loads(next((self.directory / "build/owner-updates").glob("*/transfer.json")).read_text())
        self.assertFalse(result["transfer_completed"])
        self.assertFalse(result["runtime_sector_crc_verified"])
        self.assertFalse(result["independent_readback_performed"])
        self.assertFalse(result["native_codec_written"])
        self.assertIsNone(result["flash_write_started"])
        self.assertIn("Runtime transfer failed", result["error"])
        self.assertEqual(len(calls), 1)


class FactoryTransferTests(unittest.TestCase):
    def bench(self, fault=None):
        fake_base = LOADER["FakeBootloader"]
        class Cable(fake_base):
            def __init__(self):
                super().__init__(LOADER["MODELS"]["dm32"], corrupt=(2,) if fault == "transient" else (), erase_reads=0)
                self.close_count = 0
                if fault == "model":
                    self.magic = bytes([self.magic[0] ^ 1]) + self.magic[1:]
            def close(self):
                self.close_count += 1
            def write(self, data):
                if fault == "permanent_nak" and self.state == 9 and len(data) >= 1028:
                    data = bytearray(data)
                    data[10] ^= 0x40
                return super().write(data)
        cable = Cable()
        library = dict(LOADER)
        library["find_port"] = lambda port: port
        library["SerialPort"] = lambda port: cable
        actual_flasher = LOADER["Flasher"]
        library["Flasher"] = lambda port, **kwargs: actual_flasher(
            port, step_timeout=0.005, erase_timeout=0.02, retries=1, **kwargs)
        return cable, library

    def test_actual_protocol_ack_retry_and_short_tail_complete_then_close(self):
        cable, library = self.bench("transient")
        raw = bytes(range(1, 256)) * 13  # Four blocks, final block shorter than 1 KiB.
        cues = []
        logs = []
        UPDATE.transfer(raw, "COM99", library, ready=cues.append, log=logs.append)
        self.assertEqual(len(cues), 1)
        self.assertEqual(cable.image(), raw)
        self.assertTrue(cable.done)
        self.assertEqual(cable.naks, 1)
        self.assertEqual(cable.errors, [])
        self.assertEqual(cable.close_count, 1)
        self.assertEqual(len(cable.blocks), 4)
        self.assertIn("Transfer: 100%", logs)

    def test_wrong_model_refuses_before_erase_and_always_closes(self):
        cable, library = self.bench("model")
        with self.assertRaises(LOADER["FlashError"]):
            UPDATE.transfer(b"valid nonblank application", "COM99", library, ready=lambda _: None, log=lambda _: None)
        self.assertIsNone(cable.header)
        self.assertEqual(cable.blocks, [])
        self.assertFalse(cable.done)
        self.assertEqual(cable.close_count, 1)

    def test_permanent_data_nak_fails_after_bounded_retry_and_closes(self):
        cable, library = self.bench("permanent_nak")
        with self.assertRaisesRegex(LOADER["FlashError"], "NAK.*2 tries"):
            UPDATE.transfer(b"valid nonblank application", "COM99", library, ready=lambda _: None, log=lambda _: None)
        self.assertEqual(cable.naks, 2)
        self.assertFalse(cable.done)
        self.assertEqual(cable.close_count, 1)

    def test_cancel_at_physical_cue_or_invalid_image_never_opens_port(self):
        library = dict(LOADER)
        library["find_port"] = lambda port: port
        library["SerialPort"] = lambda _: self.fail("port must stay closed")
        with self.assertRaises(KeyboardInterrupt):
            UPDATE.transfer(b"valid nonblank application", "COM99", library,
                            ready=lambda _: (_ for _ in ()).throw(KeyboardInterrupt()), log=lambda _: None)
        with self.assertRaises(LOADER["FlashError"]):
            UPDATE.transfer(b"\xff" * 16, "COM99", library,
                            ready=lambda _: self.fail("invalid image must not prompt"), log=lambda _: None)


if __name__ == "__main__":
    unittest.main()
