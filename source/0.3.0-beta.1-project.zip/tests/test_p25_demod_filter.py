# SPDX-License-Identifier: GPL-3.0-or-later
"""Full-scale convolution equivalence and signed-overflow trapping, no RF."""
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-demod-filter'
BUILD.mkdir(parents=True,exist_ok=True)
BINARY=BUILD/('filter.exe' if sys.platform=='win32' else 'filter')
subprocess.run(['gcc','-std=c11','-O2','-ftrapv','-Wall','-Wextra','-Werror','-Wshadow',
    '-pedantic','-Isrc/firmware','tests/test_p25_demod_filter.c','-o',str(BINARY)],cwd=ROOT,check=True)
subprocess.run([str(BINARY)],cwd=ROOT,check=True,timeout=30)
