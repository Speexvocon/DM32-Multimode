"""Host-only capability transport tests: no serial device or radio access."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import re
import struct
import sys
import tempfile
import unittest
from unittest import mock
import zlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('capability', ROOT/'scripts/hrc7000-capability.py')
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)


def make_elf(image):
    header = struct.pack('<16sHHIIIIIHHHHHH', b'\x7fELF\x01\x01\x01'+bytes(9),
                         2, 252, 1, cap.ENTRY, 52, 0x200, 0, 52, 32, 1, 40, 2, 0)
    segment = struct.pack('<8I', 1, 0x100, cap.ENTRY, cap.ENTRY, len(image), len(image), 5, 4)
    data = bytearray(0x250);data[:52] = header;data[52:84] = segment
    data[0x100:0x100+len(image)] = image
    data[0x228:0x250] = struct.pack('<10I', 0, 1, 6, cap.ENTRY, 0x100, len(image), 0, 0, 4, 0)
    return bytes(data)


def write_bundle(directory):
    image = bytes.fromhex('00500050005000500050005000500050')
    elf = make_elf(image)
    manifest = dict(schema=cap.SCHEMA, build_id=cap.BUILD_ID, entry=cap.ENTRY,
                    ram_start=cap.ENTRY, ram_end=cap.RAM_END, args_address=cap.ARGS_ADDRESS,
                    image=dict(file='probe.bin', bytes=len(image), sha256=cap.digest(image)),
                    elf=dict(file='probe.elf', bytes=len(elf), sha256=cap.digest(elf)),
                    source_commit='a'*40, allowed_modes=[0, 1, 2, 3], stub_source_sha256=cap.STUB_SHA256,
                    ranges={**{k:list(v) for k, v in cap.FIXED_RANGES.items()},
                            'image':[cap.ENTRY, cap.ENTRY+len(image)], 'bss':[0x45000, 0x45004]})
    (directory/'probe.bin').write_bytes(image);(directory/'probe.elf').write_bytes(elf)
    path = directory/'manifest.json';path.write_text(json.dumps(manifest))
    return path


def result_records(mode):
    result = [dict(id=1, status=0, value=0x23456789, aux=0, vector=0, epc=0, epsr=0, reserved=0),
              dict(id=2, status=1, value=0, aux=0, vector=4, epc=cap.ENTRY+4, epsr=0x80000000, reserved=0),
              dict(id=3, status=1, value=0x47505231, aux=0, vector=4, epc=cap.ENTRY+4, epsr=0x80000000, reserved=0)]
    if mode >= 2:
        result += [dict(id=i, status=0, value=0x80300000+i, aux=0, vector=0, epc=0, epsr=0, reserved=0)
                   for i in range(16, 32)]
    if mode == 3:
        result += [dict(id=i, status=0, value=value, aux=0, vector=0, epc=0, epsr=0, reserved=0)
                   for i, value in ((64, 0x3fc00000), (65, 0x40700000), (66, 0x40400000), (67, 0xbf400000))]
    return result if mode else result[:1]


def packet(nonce=123, mode=1, records=None, header=None):
    records = result_records(mode) if records is None else records
    fields = dict(nonce=nonce, build_id=cap.BUILD_ID, mode=mode,
                  total_bytes=cap.HEADER.size+len(records)*cap.RECORD.size+4,
                  record_count=len(records), fatal=0, guard_mask=cap.GUARDS if mode else 9,
                  initial_psr=0x80000100, initial_vbr=0x30000, initial_sp=0x37f00,
                  cpuid_words=16 if mode >= 2 else 0)
    if header:
        fields.update(header)
    body = cap.HEADER.pack(cap.RESULT_MAGIC, *(fields[k] for k in cap.HEADER_NAMES))
    body += b''.join(cap.RECORD.pack(*(r[k] for k in cap.RECORD_NAMES)) for r in records)
    return body+struct.pack('<I', zlib.crc32(body))


class FakePort:
    def __init__(self):
        self.buffer = bytearray();self.timeout = 0.02;self.closed = False
        self.now = 0.;self.reads = [];self.fragment = 7

    def read(self, count):
        self.reads.append(count);self.now += 0.01
        count = min(count, self.fragment)
        data = bytes(self.buffer[:count]);del self.buffer[:count]
        return data

    def close(self):
        self.closed = True


class FakeRadio:
    def __init__(self, port):
        self.port = port;self.ops = [];self.memory = {};self.configured = None
        self.uart_hz = 24000000;self.hello_count = 0;self.bad_readback = False
        self.result_change = lambda raw: raw;self.fail_return = 0
        self.v6 = dict(load=0x10000, board=1, flags=0, run=0x30000, image=0x2000,
                       bss_end=0x33000, stack_lo=0x34000, stack_top=0x38000, stack_used=128)

    def start(self, **kwargs):
        self.ops.append(('start', kwargs))

    def configure(self, board):
        self.ops.append(('configure', board));self.configured = board

    def hello(self, retries):
        self.ops.append(('hello', retries));self.hello_count += 1
        if self.hello_count > 1 and self.fail_return:
            self.fail_return -= 1;raise OSError('Simulated late monitor reply')
        return 7, 1032

    def poke(self, address, data):
        self.ops.append(('poke', address, bytes(data)))
        self.memory.update({address+i:b for i, b in enumerate(data)})

    def peek(self, address, count):
        self.ops.append(('peek', address, count))
        data = bytes(self.memory[address+i] for i in range(count))
        return bytes([data[0]^1])+data[1:] if self.bad_readback else data

    def jump(self, address):
        self.ops.append(('call', address))
        args = bytes(self.memory[cap.ARGS_ADDRESS+i] for i in range(64))
        nonce, mode = struct.unpack_from('<2I', args, 8)
        self.port.buffer.extend(self.result_change(packet(nonce, mode)))


class CapabilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name);self.path = write_bundle(self.directory)
        self.bundle = cap.load_manifest(self.path)

    def save_manifest(self, value):
        self.path.write_text(json.dumps(value))

    def execute_fake(self, mode=1, configure=lambda radio: None):
        port = FakePort();radio = FakeRadio(port);configure(radio)
        with mock.patch.object(cap.time, 'sleep'):
            result = cap.execute(self.bundle, mode, 'FAKE', 123, wait=10, timeout=5,
                                 radio_factory=lambda p: radio, port_factory=lambda name: port,
                                 clock=lambda: port.now)
        return result, radio, port

    def test_abi_matches_shared_header(self):
        header = (ROOT/'research/examples/hrc7000-capability-probe/probe_protocol.h').read_text()
        expected = {'CAP_BUILD_ID':cap.BUILD_ID, 'CAP_ENTRY':cap.ENTRY, 'CAP_LIMIT':cap.RAM_END,
                    'CAP_ARGS_ADDRESS':cap.ARGS_ADDRESS, 'CAP_MAX_RECORDS':cap.MAX_RECORDS,
                    'CAP_PACKET_MAX':cap.PACKET_MAX, 'CAP_REQUIRED_GUARDS':cap.GUARDS,
                    'CAP_MODE_SMOKE':0}
        for name, value in expected.items():
            match = re.search(r'^#define '+name+r' (0x[0-9a-fA-F]+|[0-9]+)u', header, re.M)
            self.assertIsNotNone(match, name);self.assertEqual(int(match.group(1), 0), value)
        self.assertEqual(cap.HEADER.size, 52);self.assertEqual(cap.RECORD.size, 32)
        args = cap.make_args(123, 2, 24000000)
        self.assertEqual(len(args), 64);self.assertEqual(args[:8], cap.ARGS_MAGIC)
        self.assertEqual(args[28:60], bytes(32))
        self.assertEqual(zlib.crc32(args[:-4]), int.from_bytes(args[-4:], 'little'))

    def test_default_is_dry_without_serial_or_stub_import(self):
        output = io.StringIO()
        with mock.patch.object(cap, 'load_stub', side_effect=AssertionError('stub imported')), \
             mock.patch.dict(sys.modules, {'serial':None}), contextlib.redirect_stdout(output):
            cap.main(['--manifest', str(self.path)])
        result = json.loads(output.getvalue())
        self.assertTrue(result['dry_run']);self.assertFalse(result['serial_opened'])
        self.assertEqual(result['mode'], 0)

    def test_execute_requires_explicit_port(self):
        with mock.patch.object(cap, 'load_stub', side_effect=AssertionError('stub imported')), \
             contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            cap.main(['--manifest', str(self.path), '--execute'])

    def test_manifest_unknown_schema_fields_hashes_and_fixed_ranges_refused(self):
        original = json.loads(self.path.read_text())
        changes = [lambda m:m.update(schema='unknown'), lambda m:m.update(extra=1),
                   lambda m:m.update(entry=0x30000), lambda m:m.update(build_id=1),
                   lambda m:m.update(allowed_modes=[3]), lambda m:m.update(source_commit='dirty'),
                   lambda m:m.update(stub_source_sha256='0'*64),
                   lambda m:m['image'].update(file='../probe.bin'),
                   lambda m:m['image'].update(sha256='0'*64),
                   lambda m:m['ranges'].update(image=[0x40000, 0x44804]),
                   lambda m:m['ranges'].update(args=[0x44000, 0x44040]),
                   lambda m:m['ranges'].update(bss=[0x45000, 0x46004]),
                   lambda m:m['ranges'].update(context=[0x44800, 0x44900])]
        for change in changes:
            value = copy.deepcopy(original);change(value);self.save_manifest(value)
            with self.subTest(manifest=value), self.assertRaises(cap.ProbeError):
                cap.load_manifest(self.path)

    def test_binary_tampering_and_elf_flash_addresses_refused(self):
        path = self.directory/'probe.bin';original = path.read_bytes();path.write_bytes(bytes(len(original)))
        with self.assertRaises(cap.ProbeError):cap.load_manifest(self.path)
        path.write_bytes(original)
        elfpath = self.directory/'probe.elf';elf = bytearray(elfpath.read_bytes())
        struct.pack_into('<I', elf, 52+8, 0x0300c000);struct.pack_into('<I', elf, 52+12, 0x0300c000)
        elfpath.write_bytes(elf);manifest = json.loads(self.path.read_text())
        manifest['elf']['sha256'] = cap.digest(elf);self.save_manifest(manifest)
        with self.assertRaises(cap.ProbeError):cap.load_manifest(self.path)

    def test_successful_execution_permits_only_ram_upload_readback_and_one_call(self):
        for mode in (0, 1, 2, 3):
            result, radio, port = self.execute_fake(mode)
            self.assertTrue(result['monitor_returned']);self.assertTrue(port.closed)
            self.assertEqual([op for op in radio.ops if op[0] == 'call'], [('call', cap.ENTRY)])
            self.assertEqual(radio.ops[0], ('start', {'wait':10, 'slow':True}))
            self.assertEqual(radio.ops[1], ('configure', 'dm32'))
            self.assertTrue(all(op[0] in ('start', 'configure', 'hello', 'poke', 'peek', 'call') for op in radio.ops))
            for op in radio.ops:
                if op[0] == 'poke':
                    address, data = op[1:]
                    self.assertTrue(cap.ENTRY <= address < address+len(data) <= cap.ENTRY+16 or
                                    address == cap.ARGS_ADDRESS and len(data) == 64)
            if mode == 3:
                self.assertTrue(all(r['classification'] == 'expected_result_current_configuration'
                                    for r in result['result']['records'][-4:]))

    def test_smoke_does_not_claim_or_accept_exception_guard_results(self):
        parsed = cap.parse_packet(packet(mode=0), 123, 0, cap.ENTRY+16)
        self.assertEqual([r['id'] for r in parsed['records']], [1])
        self.assertEqual(parsed['header']['guard_mask'], 9)
        self.assertEqual(parsed['header']['cpuid_words'], 0)
        for raw in (packet(mode=0, records=result_records(1)),
                    packet(mode=0, header={'guard_mask':cap.GUARDS}),
                    packet(mode=0, header={'cpuid_words':1})):
            with self.assertRaises(cap.ProbeError):cap.parse_packet(raw, 123, 0, cap.ENTRY+16)

    def test_monitor_overlap_and_readback_failure_prevent_call(self):
        for name, change in [('overlap', lambda r:r.v6.update(run=0x40000, image=0x1000,
                        bss_end=0x42000, stack_lo=0x43000, stack_top=0x48000)),
                             ('readback', lambda r:setattr(r, 'bad_readback', True))]:
            port = FakePort();radio = FakeRadio(port);change(radio)
            with self.subTest(case=name), mock.patch.object(cap.time, 'sleep'), self.assertRaises(cap.ProbeError):
                cap.execute(self.bundle, 1, 'FAKE', 123, radio_factory=lambda p:radio,
                            port_factory=lambda n:port, clock=lambda:port.now)
            self.assertFalse(any(op[0] == 'call' for op in radio.ops));self.assertTrue(port.closed)
            if name == 'overlap':self.assertFalse(any(op[0] == 'poke' for op in radio.ops))

    def test_artifact_changed_after_dry_run_refused_before_serial(self):
        (self.directory/'probe.bin').write_bytes(bytes(16))
        with self.assertRaises(cap.ProbeError):
            cap.execute(self.bundle, 1, 'FAKE', 123, port_factory=lambda n:self.fail('port opened'),
                        radio_factory=lambda p:self.fail('radio created'))

    def test_result_header_crc_and_record_failures(self):
        cases = []
        bad = bytearray(packet());bad[-1] ^= 1;cases.append(bytes(bad))
        bad = bytearray(packet());bad[0] ^= 1;cases.append(bytes(bad))
        for header in ({'nonce':124}, {'mode':2}, {'build_id':1}, {'record_count':49},
                       {'total_bytes':0xffffffff}, {'guard_mask':15}, {'fatal':1},
                       {'cpuid_words':1}, {'initial_sp':0x14030000}, {'initial_vbr':1},
                       {'initial_psr':0x140}, {'initial_psr':0x80000140}, {'initial_sp':0x37f02}):
            cases.append(packet(header=header))
        for change in (lambda r:r[0].update(value=0), lambda r:r[0].update(id=2),
                       lambda r:r[0].update(status=3), lambda r:r[0].update(reserved=1),
                       lambda r:r[1].update(vector=30), lambda r:r[1].update(epc=0x30000),
                       lambda r:r[2].update(value=0), lambda r:r[0].update(epc=cap.ENTRY)):
            records = result_records(1);change(records);cases.append(packet(records=records))
        for raw in cases:
            with self.subTest(packet=raw.hex()), self.assertRaises(cap.ProbeError):
                cap.parse_packet(raw, 123, 1, cap.ENTRY+16)

    def test_cpuid_stops_at_fault_and_count_is_successful_reads(self):
        records = result_records(2)
        for record in records[8:]:
            record.update(status=2, value=0)
        records[8].update(status=1, vector=5, epc=cap.ENTRY+8, epsr=0x80000000)
        result = cap.parse_packet(packet(mode=2, records=records, header={'cpuid_words':5}), 123, 2, cap.ENTRY+16)
        self.assertEqual(result['header']['cpuid_words'], 5)
        records[9].update(status=0)
        with self.assertRaises(cap.ProbeError):
            cap.parse_packet(packet(mode=2, records=records, header={'cpuid_words':6}), 123, 2, cap.ENTRY+16)

    def test_fpu_fault_and_wrong_result_are_distinct_from_absence(self):
        records = result_records(3);records[-3]['value'] = 0
        result = cap.parse_packet(packet(mode=3, records=records), 123, 3, cap.ENTRY+16)
        self.assertEqual(result['records'][-3]['classification'], 'wrong_result')
        records = result_records(3)
        records[-4].update(status=1, value=0, vector=30, epc=cap.ENTRY+8, epsr=0x80000000)
        for record in records[-3:]:record.update(status=2, value=0)
        result = cap.parse_packet(packet(mode=3, records=records), 123, 3, cap.ENTRY+16)
        self.assertEqual(result['records'][-4]['classification'], 'unavailable_current_configuration')
        self.assertIn('do not establish', result['scope'])
        records = result_records(3);records[-4]['value'] = 0
        for record in records[-3:]:record.update(status=2, value=0)
        result = cap.parse_packet(packet(mode=3, records=records), 123, 3, cap.ENTRY+16)
        self.assertEqual(result['records'][-4]['classification'], 'wrong_result')
        self.assertTrue(all(r['classification'] == 'not_tested_after_transfer_wrong_result'
                            for r in result['records'][-3:]))

    def test_non_boot_clock_refused_before_call(self):
        port = FakePort();radio = FakeRadio(port);radio.uart_hz = 84000000
        with self.assertRaises(cap.ProbeError):
            cap.execute(self.bundle, 1, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now)
        self.assertFalse(any(op[0] == 'call' for op in radio.ops));self.assertTrue(port.closed)

    def test_bad_packet_still_checks_monitor_return_without_another_call(self):
        port = FakePort();radio = FakeRadio(port)
        radio.result_change = lambda raw:raw[:-1]+bytes([raw[-1]^1])
        with mock.patch.object(cap.time, 'sleep'), self.assertRaises(cap.ProbeError) as error:
            cap.execute(self.bundle, 1, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now)
        self.assertTrue(error.exception.monitor_returned)
        self.assertEqual(radio.hello_count, 2)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)

    def test_monitor_stack_headroom_and_actual_entry_stack_bounds(self):
        port = FakePort();radio = FakeRadio(port);radio.v6['stack_used'] = 0x4000-64
        with self.assertRaisesRegex(cap.ProbeError, 'headroom'):
            cap.execute(self.bundle, 0, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now)
        self.assertFalse(any(op[0] == 'poke' for op in radio.ops));self.assertTrue(port.closed)
        port = FakePort();radio = FakeRadio(port)
        radio.result_change = lambda raw:packet(mode=0, header={'initial_sp':0x34040})
        with mock.patch.object(cap.time, 'sleep'), self.assertRaisesRegex(cap.ProbeError, 'entry stack') as error:
            cap.execute(self.bundle, 0, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now)
        self.assertTrue(error.exception.monitor_returned);self.assertTrue(port.closed)

    def test_four_byte_monitor_entry_stack_is_valid(self):
        result = cap.parse_packet(packet(mode=0, header={'initial_sp':0x37c34}), 123, 0, cap.ENTRY+16)
        self.assertEqual(result['header']['initial_sp'], 0x37c34)
        port = FakePort();radio = FakeRadio(port)
        radio.result_change = lambda raw:packet(mode=0, header={'initial_sp':0x37c34})
        with mock.patch.object(cap.time, 'sleep'):
            result = cap.execute(self.bundle, 0, 'FAKE', 123, radio_factory=lambda p:radio,
                                 port_factory=lambda n:port, clock=lambda:port.now)
        self.assertTrue(result['monitor_returned']);self.assertFalse(result['resume_monitor'])

    def test_fatal_zero_record_packet_preserves_complete_crc_and_monitor_return(self):
        fatal = packet(mode=0, records=[], header={'fatal':1, 'guard_mask':0, 'initial_sp':0x37c34})
        self.assertEqual(len(fatal), 56)
        port = FakePort();port.buffer.extend(fatal);reader = cap.BoundedReader(port, 5, lambda:port.now)
        self.assertEqual(cap.read_packet(reader, 123, 0), fatal)
        with self.assertRaisesRegex(cap.ProbeError, 'guards failed'):
            cap.parse_packet(fatal, 123, 0, cap.ENTRY+16)
        with self.assertRaises(cap.ProbeError):
            cap.parse_header(packet(mode=0, records=[])[:52], 123, 0)
        port = FakePort();radio = FakeRadio(port);radio.result_change = lambda raw:fatal
        with mock.patch.object(cap.time, 'sleep'), self.assertRaises(cap.ProbeError) as error:
            cap.execute(self.bundle, 0, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now)
        self.assertEqual(error.exception.raw_hex, fatal.hex())
        self.assertTrue(error.exception.monitor_returned)

    def test_resume_monitor_uses_only_known_rate_hello_configure_and_one_call(self):
        port = FakePort();radio = FakeRadio(port)
        with mock.patch.object(cap.time, 'sleep'):
            result = cap.execute(self.bundle, 0, 'FAKE', 123, radio_factory=lambda p:radio,
                                 port_factory=lambda n:port, clock=lambda:port.now, resume_monitor=True)
        self.assertTrue(result['resume_monitor']);self.assertTrue(result['monitor_returned'])
        self.assertEqual(radio.ops[:3], [('hello',0), ('configure','dm32'), ('hello',0)])
        self.assertFalse(any(op[0] == 'start' for op in radio.ops))
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        port = FakePort();radio = FakeRadio(port)
        radio.hello = mock.Mock(side_effect=OSError('No pinned monitor'))
        with self.assertRaises(OSError):
            cap.execute(self.bundle, 0, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now, resume_monitor=True)
        self.assertTrue(port.closed);self.assertFalse(radio.ops)

    def test_fragmented_uart_and_timeout_preserve_bounded_raw_evidence(self):
        port = FakePort();port.buffer.extend(packet());reader = cap.BoundedReader(port, 5, lambda:port.now)
        self.assertEqual(cap.read_packet(reader, 123, 1), packet())
        self.assertLessEqual(max(port.reads), cap.PACKET_MAX)
        port = FakePort();port.buffer.extend(packet()[:30]);reader = cap.BoundedReader(port, 0.1, lambda:port.now)
        with self.assertRaisesRegex(cap.ProbeError, 'timed out'):cap.read_packet(reader, 123, 1)
        self.assertEqual(reader.raw, packet()[:30]);self.assertLessEqual(port.now, 0.12)
        port = FakePort();port.buffer.extend(packet(header={'total_bytes':0xffffffff}))
        reader = cap.BoundedReader(port, 5, lambda:port.now)
        with self.assertRaises(cap.ProbeError):cap.read_packet(reader, 123, 1)
        self.assertEqual(len(reader.raw), cap.HEADER.size)

    def test_return_hello_retry_never_reexecutes_probe(self):
        result, radio, _ = self.execute_fake(configure=lambda r:setattr(r, 'fail_return', 1))
        self.assertTrue(result['monitor_returned']);self.assertEqual(radio.hello_count, 3)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        port = FakePort();radio = FakeRadio(port);radio.fail_return = 2
        with mock.patch.object(cap.time, 'sleep'), self.assertRaises(OSError) as error:
            cap.execute(self.bundle, 1, 'FAKE', 123, radio_factory=lambda p:radio,
                        port_factory=lambda n:port, clock=lambda:port.now)
        self.assertEqual(error.exception.raw_hex, packet().hex());self.assertTrue(port.closed)


if __name__ == '__main__':
    unittest.main()
