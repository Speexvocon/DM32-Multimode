"""Compare complete generated channel templates against pinned OP25."""
from pathlib import Path
import ctypes as c
import importlib.util
import random
import subprocess
import unittest
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('channel_reference',ROOT/'scripts/generate-p25-channel.py')
ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
class Frames(c.Structure):
    _fields_=[('hdu',c.c_uint8*99),('ldu1',c.c_uint8*216),('ldu2',c.c_uint8*216),('tdu',c.c_uint8*18)]
class ChannelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        out=ROOT/'build/channel';out.mkdir(parents=True,exist_ok=True)
        dll=out/'channel.dll'
        subprocess.run(['gcc','-std=c11','-O2','-shared','-Wall','-Wextra','-Werror','-fPIC','-Isrc/firmware','-Ifixtures/p25-1011','src/firmware/p25_live_frame.c','-o',str(dll)],cwd=ROOT,check=True)
        cls.lib=c.CDLL(str(dll));cls.build=cls.lib.p25_channel_build
        cls.build.argtypes=[c.POINTER(Frames),c.c_uint32,c.c_uint32,c.c_uint32];cls.build.restype=c.c_bool
        cls.build_call=cls.lib.p25_channel_build_call
        cls.build_call.argtypes=[c.POINTER(Frames),c.c_uint32,c.c_uint32,c.c_uint32,c.c_bool,c.c_uint32]
        cls.build_call.restype=c.c_bool
        cls.build_options=cls.lib.p25_channel_build_group_options
        cls.build_options.argtypes=[c.POINTER(Frames),c.c_uint32,c.c_uint32,c.c_uint32,c.c_uint8]
        cls.build_options.restype=c.c_bool
        cls.craft=ref.reference()
    def test_full_frames(self):
        rng=random.Random(4321)
        cases=[(0x293,1,1),(0,0,0),(4095,65535,16777215)]
        for field,width in enumerate((12,16,24)):
            for bit in range(width):
                case=[0x293,1,1];case[field]^=1<<bit;cases.append(tuple(case))
        cases += [(rng.randrange(4096),rng.randrange(65536),rng.randrange(16777216)) for _ in range(300)]
        for args in cases:
            out=Frames();self.assertTrue(self.build(c.byref(out),*args))
            self.assertEqual(bytes(out),ref.call(self.craft,*args),args)
    def test_invalid_no_partial_output(self):
        out=Frames();c.memset(c.byref(out),0x5a,c.sizeof(out));before=bytes(out)
        for args in ((4096,1,1),(0x293,65536,1),(0x293,1,16777216)):
            self.assertFalse(self.build(c.byref(out),*args));self.assertEqual(bytes(out),before)
        self.assertFalse(self.build(None,0x293,1,1))
    def test_individual_full_frames(self):
        # Independent pinned encoder checks the entire HDU/LDU1/LDU2/TDU,
        # including destination high bits, RS parity and status dibit placement.
        rng=random.Random(0x1d1d)
        cases=[(0x293,10,1234567,1),(0,0,0,0xffffff),(4095,65535,16777215,0x10000)]
        for bit in range(24):cases.append((0x293,10,1234567,1<<bit))
        cases += [(rng.randrange(4096),rng.randrange(65536),rng.randrange(16777216),
                   rng.randrange(1,16777216)) for _ in range(300)]
        for nac,tg,src,dest in cases:
            out=Frames();self.assertTrue(self.build_call(c.byref(out),nac,tg,src,True,dest))
            self.assertEqual(bytes(out),ref.call(self.craft,nac,tg,src,True,dest),(nac,tg,src,dest))
            group=Frames();self.assertTrue(self.build_call(c.byref(group),nac,tg,src,False,dest))
            self.assertEqual(bytes(group),ref.call(self.craft,nac,tg,src))
    def test_individual_invalid_no_partial_output(self):
        out=Frames();c.memset(c.byref(out),0x5a,c.sizeof(out));before=bytes(out)
        for args in ((4096,1,1,True,1),(0x293,65536,1,True,1),
                     (0x293,1,16777216,True,1),(0x293,1,1,True,16777216),
                     (0x293,1,1,True,0),(0x293,1,1,False,16777216)):
            self.assertFalse(self.build_call(c.byref(out),*args));self.assertEqual(bytes(out),before)
        self.assertFalse(self.build_call(None,0x293,1,1,True,1))
    def test_group_grant_options_against_independent_encoder(self):
        rng=random.Random(0x1001)
        for options in (*range(8),*range(0x80,0x88)):
            cases=[(0x293,1,0x123456),(0,0,0),(4095,65535,16777215),
                   (rng.randrange(4096),rng.randrange(65536),rng.randrange(16777216))]
            for nac,tg,source in cases:
                out=Frames();self.assertTrue(self.build_options(c.byref(out),nac,tg,source,options))
                self.assertEqual(bytes(out),ref.call(self.craft,nac,tg,source,service_options=options),
                                 (nac,tg,source,options))
    def test_group_grant_options_invalid_output_is_unchanged(self):
        out=Frames();c.memset(c.byref(out),0x5a,c.sizeof(out));before=bytes(out)
        for options in range(256):
            if options&~0x87:
                self.assertFalse(self.build_options(c.byref(out),0x293,1,1,options))
                self.assertEqual(bytes(out),before)
        for nac,tg,source in ((4096,1,1),(0x293,65536,1),(0x293,1,16777216)):
            self.assertFalse(self.build_options(c.byref(out),nac,tg,source,4))
            self.assertEqual(bytes(out),before)
        self.assertFalse(self.build_options(None,0x293,1,1,4))
if __name__=='__main__':unittest.main()
