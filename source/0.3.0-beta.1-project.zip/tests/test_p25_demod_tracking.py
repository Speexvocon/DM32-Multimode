# SPDX-License-Identifier: GPL-3.0-or-later
"""Opt-in control-lane tracking, bounded fallback and pinned OP25 waveforms."""
import ast
import ctypes as C
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-demod-tracking'
BUILD.mkdir(parents=True,exist_ok=True)
REF=ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx'
PINS={'p25craft.py':'27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9',
      'op25_c4fm_mod.py':'b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef'}
for name,digest in PINS.items():
    assert hashlib.sha256((REF/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==digest
spec=importlib.util.spec_from_file_location('tracking_op25',REF/'p25craft.py')
op=importlib.util.module_from_spec(spec);old=Path.cwd();os.chdir(BUILD)
try:spec.loader.exec_module(op)
finally:os.chdir(old)
op.outfile.close();op.text_out=lambda *_:None;generated=[]
op.print_spec=lambda dibits:generated.append(list(dibits))
nodes=[n for n in ast.parse((REF/'op25_c4fm_mod.py').read_bytes()).body
       if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'transfer_function_tx','c4fm_taps'}]
scope=dict(np=np,pi=math.pi,sin=math.sin,cos=math.cos,
           _def_symbol_rate=4800,_def_output_sample_rate=48000,_def_span=13)
exec(compile(ast.Module(body=nodes,type_ignores=[]),'pinned-op25-c4fm','exec'),scope)
taps=scope['c4fm_taps']().generate();tx_delay=(len(taps)-1)//2


def wire(nac=0x293,voice=False,bad_nid=False,bad_crc=False,count=1):
    generated.clear()
    if voice:op.construct_ldu1(nac,2,0,0,0,0,0,0,1,0,1)
    else:op.construct_tsdu3(nac,2,count,0,[0x3b]*count,[0x000abcde12300001]*count)
    dibits=generated[0]
    for index in range(35,len(dibits),36):dibits[index]=3 if index==35 else 2
    if bad_nid:dibits[24]^=3;dibits[25]^=3;dibits[56]^=1
    if bad_crc:
        block=op.construct_tsbk(1,0,0x3b,0,0x000abcde12300001)^1
        encoded=op.data_interleave(op.trellis_1_2_encode(op.split_dibits(block,48)))
        for i,value in enumerate(encoded):
            logical=56+i;dibits[logical+logical//35]=value
    return bytes(sum(dibits[i+j]<<(6-2*j) for j in range(4)) for i in range(0,len(dibits),4))


def waveform(frames,phase=0,polarity=1,ppm=0,gain=1.,dc=0.,jump=None,fade=None):
    air=b'\x77'*72+b''.join(frames)
    dibits=np.array([(value>>shift)&3 for value in air for shift in (6,4,2,0)])
    impulses=np.zeros(len(dibits)*10);impulses[::10]=np.array([1,3,-1,-3])[dibits]
    shaped=np.convolve(impulses,taps)*60000*polarity*gain
    positions=np.arange(phase,len(shaped)-8,6*(1+ppm/1000000))
    if jump:
        boundary,offset=jump;positions[positions>=boundary]+=offset
    pcm=np.interp(positions,np.arange(len(shaped)),shaped)+dc
    if fade:
        start,end,scale=fade;pcm[(positions>=start)&(positions<end)]*=scale
    return np.concatenate((np.clip(np.rint(pcm),-32768,32767).astype('<i2'),np.zeros(64,dtype='<i2')))


# Count only real symbol() entries in a test-only source copy. Production gets
# no counter, clock hook, capture buffer or static state for this measurement.
source=(ROOT/'src/firmware/p25_demod.c').read_text()
anchor='static void symbol(p25_demod *d,p25_demod_lane *l,int16_t value) {'
assert source.count(anchor)==1
instrumented=BUILD/'demod-counted.c'
instrumented.write_text(source.replace(anchor,anchor+'\n    ++test_symbol_visits;'),encoding='utf-8',newline='\n')
library=BUILD/('tracking.dll' if sys.platform=='win32' else 'tracking.so')
command=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-shared']
if sys.platform!='win32':command+=['-fPIC']
command+=['-DP25_TRACK_DEMOD_SOURCE="'+instrumented.as_posix()+'"','-Isrc/firmware',
          'tests/test_p25_demod_tracking.c','src/firmware/p25_rx.c','src/firmware/p25_tsdu.c','-o',str(library)]
subprocess.run(command,cwd=ROOT,check=True,timeout=120)
lib=C.CDLL(str(library));U32,U64=C.c_uint,C.c_uint64
lib.p25_tracking_units.restype=U32
state_bytes=lib.p25_tracking_units()
lib.p25_tracking_run.argtypes=[C.POINTER(C.c_int16),U32,U32,U32,C.POINTER(C.c_ubyte),
                             C.POINTER(U64),C.POINTER(C.c_uint16),C.POINTER(U32)]
lib.p25_tracking_run.restype=U32


def run(pcm,mode=1,change_at=0):
    frames=(C.c_ubyte*(128*520))();events=(U64*(2048*8))();masks=(C.c_uint16*len(pcm))();stats=(U32*16)()
    assert lib.p25_tracking_run(pcm.ctypes.data_as(C.POINTER(C.c_int16)),len(pcm),mode,change_at,
                               frames,events,masks,stats)==state_bytes
    output=[bytes(frames[i*520:(i+1)*520]) for i in range(stats[0])]
    statuses=[tuple(events[i*8:(i+1)*8]) for i in range(stats[3])]
    return output,statuses,np.array(masks),tuple(stats)


clean=wire();results=[]
for phase in range(6):
    for polarity in (1,-1):
        pcm=waveform([clean]*32,phase,polarity)
        baseline,_,_,old_stats=run(pcm,mode=0)
        tracked,statuses,masks,stats=run(pcm)
        assert tracked==baseline and len(tracked)==32,(phase,polarity,len(tracked),len(baseline))
        assert stats[5]>=1 and stats[1]<old_stats[1]*.5 and np.any(masks!=1023),stats
        assert all(int(mask).bit_count() in (3,10) for mask in masks)
        results.append(dict(case=f'phase{phase}_polarity{polarity}',frames=len(tracked),
            symbol_visits_full=old_stats[1],symbol_visits_tracking=stats[1],locks=stats[5],fallbacks=stats[6]))
print('PASS: 12 phase/polarity cases,32 exact control frames each; real symbol-stage count below half of full10')

for ppm in (-1900,-750,750,1900):
    pcm=waveform([clean]*40,ppm=ppm)
    baseline,_,_,old_stats=run(pcm,mode=0);tracked,_,masks,stats=run(pcm)
    assert tracked==baseline and len(tracked)>=38,(ppm,len(tracked),len(baseline),stats)
    results.append(dict(case=f'ppm{ppm}',frames=len(tracked),symbol_visits_full=old_stats[1],
        symbol_visits_tracking=stats[1],locks=stats[5],fallbacks=stats[6]))
for gain,dc in ((.04,0),(.2,-9000),(.6,14000),(1.8,0)):
    pcm=waveform([clean]*32,gain=gain,dc=dc)
    baseline,_,_,_=run(pcm,mode=0);tracked,_,_,stats=run(pcm)
    assert tracked==baseline and len(tracked)>=30,(gain,dc,len(tracked),len(baseline),stats)
print('PASS: weak/DC-offset and +/-1900ppm waveform cases retain exact complete control output')

# Loss conditions are allowed to change a damaged unit's recovery. Require
# fallback and prompt relock, and compare the recovered clean suffix exactly.
for name,bad in (('NID',wire(bad_nid=True)),('CRC',wire(bad_crc=True)),
                 ('NAC',wire(nac=0x2a3)),('voice',wire(voice=True))):
    pcm=waveform([clean]*6+[bad]+[clean]*12)
    baseline,_,_,_=run(pcm,mode=0);tracked,_,masks,stats=run(pcm)
    assert stats[6]>=1 and stats[5]>=2,(name,stats)
    assert tracked==baseline,(name,len(tracked),len(baseline))
    results.append(dict(case=name,baseline_frames=len(baseline),frames=len(tracked),
                        locks=stats[5],fallbacks=stats[6]))
boundary=72*4*10+8*1800+tx_delay
for name,options in (('phase_jump',dict(jump=(boundary,5))),
                     ('deep_fade',dict(fade=(boundary,boundary+3600,.001))),
                     ('long_silence',dict(fade=(boundary,boundary+9600,0)))):
    pcm=waveform([clean]*36,**options)
    baseline,_,_,_=run(pcm,mode=0);tracked,_,masks,stats=run(pcm)
    if name!='deep_fade':assert stats[6]>=1 and stats[5]>=2,(name,stats)
    # A missed sync provides no bad-NID/CRC notification. In that case the
    # approved150ms stale cap plus one maximum75ms TSDU bounds fresh reacquire.
    # Six one-block units are that conservative225ms window, not a promise of
    # equal damage recovery. A short fade can recover identically without loss.
    assert tracked[-8:]==baseline[-8:] and len(tracked)>=len(baseline)-6,(name,len(tracked),len(baseline),stats)
    if tracked!=baseline:assert stats[6]>=1,(name,stats)
    end=options.get('fade',(boundary,boundary,0))[1]
    deadline=int((end+7200+3600+tx_delay)/6)
    assert np.any(masks[int(end/6):deadline]!=1023),(name,stats)
    results.append(dict(case=name,baseline_frames=len(baseline),frames=len(tracked),
                        locks=stats[5],fallbacks=stats[6],
                        lost_units_vs_full10=len(baseline)-len(tracked),
                        nominal_input_ms_from_damage_end_to_relock=
                        (stats[8]-end/6)*.125 if stats[8]>=end/6 else None,
                        worst_case_reacquire_bound_ms=225,rf_timing_qualified=False))
print('PASS: damaged NID/CRC,foreign NAC,voice DUID,phase jump,fade/silence fall back and recover a clean suffix')

pcm=waveform([clean]*32);change_at=int((72*4*10+8*1800+tx_delay)/6)
baseline,_,_,_=run(pcm,mode=0)
for mode in (2,3,4,5):
    tracked,_,masks,stats=run(pcm,mode=mode,change_at=change_at)
    assert np.all(masks[change_at:]==1023) and not stats[9],(mode,stats)
    assert tracked[-8:]==baseline[-8:]
    assert stats[4]==(1 if mode in (3,4) else 0),(mode,stats)
late,_,masks,stats=run(pcm,mode=6,change_at=change_at)
assert late==baseline and np.all(masks[:change_at]==1023) and stats[9]&1
# Independently learned clocks can converge while their phase labels differ.
# Late enabling must leave full10 running if the new winner is outside the
# retained status lane's neighborhood; it must not retarget that global lane.
if not np.any(masks[change_at:]!=1023):assert stats[9]==1 and stats[5]==0
report=dict(schema='p25-demod-control-tracking-test-v1',default_enabled=False,demod_state_bytes=state_bytes,
            static_state_growth_bytes=0,qualification=False,results=results)
(BUILD/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: disable,gap,epoch/reset clear tracking; late opt-in waits for native CRC; state {state_bytes} bytes; report.json saved')
