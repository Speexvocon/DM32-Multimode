// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking.h"
#include "p25_data_fec.h"
#include "p25_rx.h"
#include "p25_tsdu.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void block(uint8_t out[12],unsigned op,uint64_t arg) {
    memset(out,0,12);out[0]=(uint8_t)(0x80u|op);
    for(unsigned i=0;i<8;++i)out[9-i]=(uint8_t)(arg>>(8*i));
    uint16_t crc=p25_data_crc16(out,10);out[10]=(uint8_t)(crc>>8);out[11]=(uint8_t)crc;
}
static void crc_refresh(uint8_t out[12]) {
    uint16_t crc=p25_data_crc16(out,10);out[10]=(uint8_t)(crc>>8);out[11]=(uint8_t)crc;
}
static void plan(p25_trunking *t,unsigned op,unsigned identifier,uint32_t base,unsigned spacing) {
    uint8_t p[12];block(p,op,((uint64_t)identifier<<60)|((uint64_t)spacing<<32)|(base/5u));
    assert(p25_trunking_consume(t,0x293,p,0)==P25_TRUNKING_BANDPLAN);
}
static void configure(p25_trunking *t) {
    assert(p25_trunking_init(t,430100000,400000000,480000000,0x293));
    plan(t,0x34,1,430100000,100);
}
static uint64_t grant_arg(unsigned options,unsigned ch,unsigned group,unsigned source) {
    return ((uint64_t)options<<56)|((uint64_t)ch<<40)|((uint64_t)group<<24)|source;
}
static void subscriber_control_map(void) {
    p25_trunking t,before;uint8_t p[12];uint32_t rx=0,tx=0;
    assert(p25_trunking_init(&t,440075000,400000000,480000000,P25_TRUNKING_NAC_ANY));
    block(p,0x3b,(UINT64_C(0xabcde)<<36)|(UINT64_C(0x123)<<24)|(UINT64_C(0x1000)<<8));
    assert(p25_trunking_consume_control(&t,0x293,p,10)==P25_TRUNKING_SITE);
    assert(t.wacn==0xabcde && t.system_id==0x123 && t.have_network && t.last_control_ms==10);
    block(p,0x3a,(UINT64_C(0x123)<<40)|(UINT64_C(1)<<32)|(UINT64_C(2)<<24)|(UINT64_C(0x1000)<<8));
    assert(p25_trunking_consume_control(&t,0x293,p,20)==P25_TRUNKING_SITE);
    assert(t.have_site && t.rfss==1 && t.site==2 && t.last_control_ms==20);
    block(p,0x34,(UINT64_C(1)<<60)|(UINT64_C(5)<<56)|(UINT64_C(0x2190)<<42)
          |(UINT64_C(100)<<32)|(UINT64_C(440075000)/5u));
    assert(p25_trunking_consume_control(&t,0x293,p,30)==P25_TRUNKING_BANDPLAN);
    assert(p25_trunking_channel_pair(&t,0x1001,0,false,&rx,&tx));
    assert(rx==440087500 && tx==445087500);
    // Own-unit and foreign-unit grants and both update formats are map no-ops:
    // no pending retune, voice metadata, freshness refresh or counter increment.
    static const unsigned opcodes[]={0,0,2,3};
    const uint64_t args[]={grant_arg(0,0x1001,10,1234567),grant_arg(0,0x1001,10,7654321),
        (UINT64_C(0x1001)<<48)|(UINT64_C(10)<<32)|(UINT64_C(0x1002)<<16)|100u,
        (UINT64_C(0x1001)<<32)|(UINT64_C(0x1002)<<16)|10u};
    for(unsigned i=0;i<4u;++i) {
        block(p,opcodes[i],args[i]);before=t;
        assert(p25_trunking_consume_control(&t,0x293,p,100u+i)==P25_TRUNKING_IGNORED);
        assert(!memcmp(&t,&before,sizeof t));
    }
    // Offset changes still learn; subscriber map never consumes the grant.
    block(p,0x34,(UINT64_C(1)<<60)|(UINT64_C(5)<<56)|(UINT64_C(0x0190)<<42)
          |(UINT64_C(100)<<32)|(UINT64_C(440075000)/5u));
    assert(p25_trunking_consume_control(&t,0x293,p,40)==P25_TRUNKING_BANDPLAN);
    assert(p25_trunking_channel_pair(&t,0x1001,0,false,&rx,&tx) && tx==435087500);
    before=t;p[10]^=1u;
    assert(p25_trunking_consume_control(&t,0x293,p,41)==P25_TRUNKING_IGNORED && !memcmp(&t,&before,sizeof t));
    p[10]^=1u;
    assert(p25_trunking_consume_control(&t,0x294,p,41)==P25_TRUNKING_IGNORED && !memcmp(&t,&before,sizeof t));
    p[0]|=0x40u;crc_refresh(p);
    assert(p25_trunking_consume_control(&t,0x293,p,41)==P25_TRUNKING_IGNORED && !memcmp(&t,&before,sizeof t));
    p[0]&=0xbfu;p[1]=0x90u;crc_refresh(p);
    assert(p25_trunking_consume_control(&t,0x293,p,41)==P25_TRUNKING_IGNORED && !memcmp(&t,&before,sizeof t));
    for(unsigned invalid=0;invalid<3u;++invalid) {
        block(p,0x34,(UINT64_C(1)<<60)|(UINT64_C(5)<<56)|(UINT64_C(0x2190)<<42)
              |(UINT64_C(100)<<32)|(UINT64_C(440075000)/5u));
        assert(p25_trunking_consume_control(&t,0x293,p,42)==P25_TRUNKING_BANDPLAN && t.band[1].valid);
        uint64_t argument=(UINT64_C(1)<<60);
        if(invalid!=0u)argument|=UINT64_C(100)<<32;
        if(invalid==0u)argument|=UINT64_C(440075000)/5u; // zero spacing
        if(invalid==2u)argument|=UINT64_C(0xffffffff); // overflowing base; otherwise zero base
        block(p,0x34,argument);
        assert(p25_trunking_consume_control(&t,0x293,p,43)==P25_TRUNKING_UNSUPPORTED);
        assert(!t.band[1].valid && !t.pending_hz && !t.grants);
    }
    block(p,0x3b,(UINT64_C(0xabcdf)<<36)|(UINT64_C(0x123)<<24));
    assert(p25_trunking_consume_control(&t,0x293,p,50)==P25_TRUNKING_SITE);
    assert(!t.band[1].valid && !t.pending_hz && !t.grants && t.receiver_hz==t.control_hz);
    p25_trunking_stop(&t);before=t;
    assert(p25_trunking_consume_control(&t,0x293,p,51)==P25_TRUNKING_IGNORED && !memcmp(&t,&before,sizeof t));
    puts("Subscriber control map: validated site/network/signed offsets learn; grants never retune or mutate voice state");
}
static void uplink_maps(void) {
    p25_trunking t;uint8_t p[12];uint32_t rx=123,tx=456;
    // Independently specified IDEN_UP/VU wire fields: offset starts at arg bit
    // 42. VU uses spacing units/sign bit13; standard uses250kHz/sign bit8.
    static const struct {unsigned op,raw;int32_t offset;} cases[]={
        {0x34,0x2190,5000000},{0x34,0x0190,-5000000},
        {0x34,0x2000,0},{0x34,0,0},
        {0x3d,0x114,5000000},{0x3d,0x014,-5000000},
        {0x3d,0x100,0},{0x3d,0,0}};
    for(unsigned i=0;i<sizeof cases/sizeof *cases;++i) {
        assert(p25_trunking_init(&t,440075000,400000000,480000000,0x293));
        uint64_t bandwidth=cases[i].op==0x34u ? UINT64_C(5)<<56 : UINT64_C(100)<<51;
        block(p,cases[i].op,(UINT64_C(1)<<60)|bandwidth|((uint64_t)cases[i].raw<<42)
              |(UINT64_C(100)<<32)|(UINT64_C(440075000)/5u));
        assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_BANDPLAN);
        assert(t.band[1].tx_offset_hz==cases[i].offset);
        assert(p25_trunking_channel_pair(&t,0x1001,0,false,&rx,&tx));
        assert(rx==440087500 && tx==(uint32_t)((int64_t)rx+cases[i].offset));
    }
    // Explicit channel-R is a direct channel identity, not another application
    // of the uplink offset. Unknown either side preserves both outputs.
    plan(&t,0x34,2,445075000,100);t.band[2].tx_offset_hz=15000000;t.band[2].tx_valid=true;
    assert(p25_trunking_channel_pair(&t,0x1001,0x2001,true,&rx,&tx));
    assert(rx==440087500 && tx==445087500);
    uint32_t previous_rx=rx,previous_tx=tx;
    assert(!p25_trunking_channel_pair(&t,0x1001,0x3001,true,&rx,&tx));
    assert(rx==previous_rx && tx==previous_tx);
    assert(!p25_trunking_channel_pair(&t,0x3001,0x2001,true,&rx,&tx));
    assert(rx==previous_rx && tx==previous_tx);
    assert(!p25_trunking_channel_pair(&t,0x1001,0,false,&rx,&rx));
    assert(!p25_trunking_channel_pair(&t,0x1001,0,false,NULL,&tx));
    assert(!p25_trunking_input_frequency(NULL,0x1001,&tx));
    // RX remains permissive for unknown bandwidths; TX maps do not certify
    // reserved metadata or a narrower modulation profile as phase1 C4FM.
    for(unsigned bandwidth=0;bandwidth<16u;++bandwidth) {
        block(p,0x34,(UINT64_C(1)<<60)|((uint64_t)bandwidth<<56)
              |(UINT64_C(100)<<32)|(UINT64_C(440075000)/5u));
        assert(p25_trunking_consume(&t,0x293,p,2)==P25_TRUNKING_BANDPLAN);
        assert(p25_trunking_frequency(&t,0x1001,&rx));tx=456;
        assert(p25_trunking_input_frequency(&t,0x1001,&tx)==(bandwidth==5u));
        if(bandwidth!=5u)assert(tx==456);
    }
    t.band[1].tx_valid=true;
    // Known downlink does not imply an in-band input, and signed arithmetic
    // must reject underflow/overflow rather than wrapping a transmitter target.
    t.band[1].tx_offset_hz=63750000;tx=456;
    assert(!p25_trunking_input_frequency(&t,0x1001,&tx) && tx==456);
    assert(p25_trunking_init(&t,5,1,UINT32_MAX,0x293));
    plan(&t,0x34,1,5,100);t.band[1].tx_offset_hz=-5000000;t.band[1].tx_valid=true;
    assert(!p25_trunking_input_frequency(&t,0x1000,&tx) && tx==456);
    plan(&t,0x3d,1,UINT32_MAX,100);t.band[1].tx_offset_hz=5000000;t.band[1].tx_valid=true;
    assert(!p25_trunking_input_frequency(&t,0x1000,&tx) && tx==456);
    puts("Trunk input maps: signed VU/standard offsets, explicit pairs, bounds and unchanged refusal outputs passed");
}
static void independent_fixture(const char *path) {
    FILE *file=fopen(path,"rb");assert(file);p25_rx rx;p25_rx_init(&rx);
    p25_trunking t,subscriber;assert(p25_trunking_init(&t,430100000,400000000,480000000,0x293));
    assert(p25_trunking_init(&subscriber,430100000,400000000,480000000,0x293));
    unsigned frames=0;int byte;
    while((byte=fgetc(file))!=EOF)for(unsigned d=0;d<4;++d)
        if(p25_rx_push(&rx,(uint8_t)((byte>>(6-2*d))&3))) {
            p25_tsdu value;assert(p25_tsdu_decode(rx.frame,rx.frame_bytes,&value));
            for(unsigned i=0;i<value.count;++i) {
                p25_trunking before=subscriber;
                p25_trunking_event event=p25_trunking_consume_control(&subscriber,value.nac,value.block[i],frames*100u);
                if((value.block[i][0]&0x3fu)<=3u) {
                    assert(event==P25_TRUNKING_IGNORED && !memcmp(&subscriber,&before,sizeof before));
                }
                p25_trunking_consume(&t,value.nac,value.block[i],frames*100u);
            }
            ++frames;
            if(t.pending_hz) {
                assert(t.pending_hz==430112500&&t.group==1);
                p25_trunking_tune_result(&t,true,frames*100u);
                assert(p25_trunking_voice(&t,0x293,1,frames*100u+1));
                p25_trunking_end(&t,frames*100u+2);
                p25_trunking_tune_result(&t,true,frames*100u+3);
            }
        }
    fclose(file);
    assert(frames==3&&t.grants==2&&t.receiver_hz==t.control_hz);
    assert(t.wacn==0xabcde&&t.system_id==0x123&&t.rfss==1&&t.site==1);
    assert(subscriber.wacn==t.wacn && subscriber.system_id==t.system_id);
    assert(subscriber.rfss==t.rfss && subscriber.site==t.site && subscriber.band[1].valid);
    assert(!subscriber.pending_hz && !subscriber.grants && subscriber.receiver_hz==subscriber.control_hz);
    puts("Independent OP25 control stream: site/band plan -> grant -> voice -> control return passed");
}
int main(int argc,char **argv) {
    subscriber_control_map();
    uplink_maps();
    p25_trunking t,before;uint8_t p[12];uint32_t hz=123;uint16_t groups[]={10,100};
    configure(&t);assert(sizeof t<=512u);
    assert(p25_trunking_frequency(&t,0x1001,&hz)&&hz==430112500);
    assert(!p25_trunking_frequency(&t,0x2001,&hz)&&hz==430112500);
    assert(p25_trunking_set_groups(&t,groups,2));
    before=t;assert(!p25_trunking_set_groups(&t,NULL,1)&&!memcmp(&t,&before,sizeof t));
    block(p,0,grant_arg(0,0x1001,1,123));
    assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_IGNORED);
    block(p,0,grant_arg(0,0x1001,10,123));before=t;
    assert(p25_trunking_consume(&t,0x294,p,1)==P25_TRUNKING_IGNORED&&!memcmp(&t,&before,sizeof t));
    p[4]^=1;assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_IGNORED);p[4]^=1;
    p[0]|=0x40;crc_refresh(p);assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_IGNORED);
    p[0]&=0xbfu;p[1]=0x90;crc_refresh(p);assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_IGNORED);
    block(p,0,grant_arg(0x40,0x1001,10,123));assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_IGNORED);
    block(p,0,grant_arg(0,0x1001,10,123));
    assert(p25_trunking_consume(&t,0x293,p,10)==P25_TRUNKING_GRANT);
    assert(t.phase==P25_TRUNKING_CONTROL&&t.receiver_hz==430100000&&t.group==10&&t.source==123);
    assert(p25_trunking_tune_request(&t,&hz)&&hz==430112500);
    assert(!p25_trunking_voice(&t,0x293,10,10));
    p25_trunking_tune_result(&t,true,20);assert(t.phase==P25_TRUNKING_VOICE);
    assert(!p25_trunking_tune_request(&t,&hz));
    assert(!p25_trunking_voice(&t,0x293,11,100));
    assert(p25_trunking_voice(&t,0x293,10,100));
    p25_trunking_poll(&t,1099);assert(!t.pending_hz);
    p25_trunking_poll(&t,1100);assert(p25_trunking_tune_request(&t,&hz)&&hz==430100000);
    p25_trunking_tune_result(&t,true,1110);assert(t.phase==P25_TRUNKING_CONTROL&&t.group==0);
    // Explicit grants use channel-T for the downlink; update has two targets.
    block(p,3,((uint64_t)0x1001<<32)|((uint64_t)0x2fff<<16)|10);
    assert(p25_trunking_consume(&t,0x293,p,1200)==P25_TRUNKING_GRANT);
    p25_trunking_tune_result(&t,true,1201);p25_trunking_end(&t,1202);
    assert(t.pending_hz==t.control_hz);p25_trunking_tune_result(&t,true,1203);
    block(p,2,((uint64_t)0x1001<<48)|((uint64_t)999<<32)|((uint64_t)0x1002<<16)|100);
    assert(p25_trunking_consume(&t,0x293,p,1300)==P25_TRUNKING_GRANT&&t.pending_hz==430125000);
    p25_trunking_tune_result(&t,true,1301);
    p25_trunking_poll(&t,2800);assert(!t.pending_hz);
    p25_trunking_poll(&t,2801);assert(t.pending_hz==t.control_hz);p25_trunking_tune_result(&t,true,2802);
    // Switching an identifier to TDMA or invalid data erases stale FDMA maps.
    block(p,0x33,UINT64_C(1)<<60);assert(p25_trunking_consume(&t,0x293,p,3000)==P25_TRUNKING_UNSUPPORTED);
    assert(!p25_trunking_frequency(&t,0x1001,&hz));
    plan(&t,0x3d,1,430100000,100);
    block(p,0x34,(UINT64_C(1)<<60)|UINT64_C(0xffffffff));
    assert(p25_trunking_consume(&t,0x293,p,3001)==P25_TRUNKING_IGNORED&&!t.band[1].valid);
    // Receiver bounds and overflow are checked before a request can be issued.
    plan(&t,0x34,1,479987500,100);
    assert(!p25_trunking_frequency(&t,0x1fff,&hz));
    assert(p25_trunking_init(&t,146000000,144000000,148000000,0x293));
    plan(&t,0x34,1,136000000,100);
    assert(p25_trunking_frequency(&t,0x1320,&hz)&&hz==146000000);
    // Reusing a NAC on another system/site must not reuse its old identifiers.
    configure(&t);block(p,0x3b,(UINT64_C(0xabcde)<<36)|(UINT64_C(0x123)<<24));
    assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_SITE&&t.band[1].valid);
    block(p,0x3b,(UINT64_C(0xabcdf)<<36)|(UINT64_C(0x123)<<24));
    assert(p25_trunking_consume(&t,0x293,p,2)==P25_TRUNKING_SITE&&!t.band[1].valid);
    // Tune errors fail closed, and deadlines work across the millisecond wrap.
    configure(&t);block(p,0,grant_arg(0,0x1001,10,123));
    assert(p25_trunking_consume(&t,0x293,p,UINT32_MAX-100u)==P25_TRUNKING_GRANT);
    p25_trunking_poll(&t,1398);assert(t.phase!=P25_TRUNKING_STOPPED);
    p25_trunking_poll(&t,1399);assert(t.phase==P25_TRUNKING_STOPPED&&t.tune_failures==1);
    configure(&t);assert(p25_trunking_consume(&t,0x293,p,1)==P25_TRUNKING_GRANT);
    p25_trunking_tune_result(&t,false,2);assert(t.phase==P25_TRUNKING_STOPPED&&!t.pending_hz);
    // An unfiltered receiver learns one NAC, then refuses another site's frames.
    assert(p25_trunking_init(&t,430100000,400000000,480000000,P25_TRUNKING_NAC_ANY));
    plan(&t,0x34,1,430100000,100);assert(t.have_nac&&t.learned_nac==0x293);
    before=t;assert(p25_trunking_consume(&t,0x294,p,1)==P25_TRUNKING_IGNORED&&!memcmp(&t,&before,sizeof t));
    printf("P25 trunk following: band plans, filtered grants, ephemeral tuning, end/loss recovery, range/format refusal and wrap-safe deadlines passed (%zu state bytes)\n",sizeof t);
    if(argc>1)independent_fixture(argv[1]);
}
