"""Offline NRFB metadata, reservation and actual slot-validator checks.

Only synthetic native windows are used; the tests contain no proprietary codec.
"""
from copy import deepcopy
import hashlib
import importlib.util
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import zlib

ROOT = Path(__file__).resolve().parents[1]


def module(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / file)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


CODEC = module("dm32_codec_contracts", "dm32-codec-contracts.py")
MEMORY = module("dm32_codec_memory", "generate-dm32-codec-memory.py")
UPSTREAM = ROOT / "external/RadioFoundry/RadioFoundry"
sha = lambda data: hashlib.sha256(data).hexdigest()


def synthetic():
    raw = deepcopy(CODEC.nrfb_contract())
    profile = CODEC.nrfb_profile()
    code = bytearray((i * 17 + 31) & 255 for i in range(profile["code"][1]))
    struct.pack_into("<2I", code, 0, 0x152514D8, 0x74C776CD)
    for ref in raw["self_refs"]:
        struct.pack_into("<I", code, int(ref["off"], 0), int(ref["value"], 0))
    tables = bytes((i * 7 + 29) & 255 for i in range(profile["tables"][1]))
    raw["code"]["sha256"] = profile["code_sha256"] = sha(code)
    raw["table_windows"][0]["sha256"] = profile["tables_sha256"] = sha(tables)
    profile["tables_head_crc"] = zlib.crc32(tables[:64])
    program = bytearray(b"\xFF" * CODEC.PROGRAM_BYTES)
    cstart = profile["code"][0] - 0x03000000
    tstart = profile["tables"][0] - 0x03000000
    program[cstart:cstart + len(code)] = code
    program[tstart:tstart + len(tables)] = tables
    return raw, profile, bytes(program), bytes(code), tables


class CodecContractTest(unittest.TestCase):
    def test_published_map_identity_shape_and_boundaries(self):
        self.assertEqual(sha(CODEC.MAP_PATH.read_bytes()), CODEC.MAP_SHA256)
        m = CODEC.nrfb_contract()
        p = CODEC.nrfb_profile()
        self.assertEqual(m["profile"], "dm32-nrfb-050")
        self.assertIsNone(m["stock"]["sha256"])
        self.assertEqual(p["tag"], 50)
        self.assertEqual(p["code"], (0x030C72D8, 83456, 0x16CDC))
        self.assertEqual(p["tables"], (0x03072810, 12152, 0x18000EC0))
        self.assertEqual(p["tables"][2] + p["tables"][1], 0x18003E38)
        self.assertEqual([int(r["off"], 0) for r in m["self_refs"]], [0x1AD4, 0x1AD8, 0x2E8C])
        self.assertFalse(m["outside_refs"])
        tool = CODEC.native_tools()
        normalized = tool["codecmap"].normalize(m)
        self.assertEqual(normalized["table_windows"][0]["run"], 0x18000EC0)

    def test_memory_overlay_is_exact_opt_in_and_changes_only_modem_ceiling(self):
        original = (UPSTREAM / "boards/dm32/memory.ld").read_text().replace("\r\n", "\n")
        self.assertEqual(MEMORY.generate(original), original)
        changed = MEMORY.generate(original, experimental_rf_b=True)
        self.assertEqual(changed.split("\n", 1)[1], original.replace(
            "__codec_tab_hi = 0x18003E28;", "__codec_tab_hi = 0x18003E38;"))
        for name in ("__codec_run_lo", "__codec_run_hi", "__codec_slot", "__codec_slot_end"):
            pattern = re.escape(name) + r"\s*=\s*(0x[0-9A-Fa-f]+);"
            self.assertEqual(re.search(pattern, original).group(1), re.search(pattern, changed).group(1))
        with self.assertRaisesRegex(ValueError, "upstream pin"):
            MEMORY.generate(original + "\n", experimental_rf_b=True)

    def test_metadata_and_tools_fail_closed_if_changed(self):
        with patch.object(CODEC, "MAP_PATH") as path:
            path.read_bytes.return_value = b"{}"
            with self.assertRaisesRegex(ValueError, "exact reviewed"):
                CODEC.nrfb_contract()
        classic = CODEC.native_tools()
        engineering = CODEC.native_tools(experimental_rf_b=True)
        again = CODEC.native_tools()
        self.assertEqual(classic["BOARDS"]["dm32"]["tables"][1], 0x18003E28)
        self.assertEqual(engineering["BOARDS"]["dm32"]["tables"][1], 0x18003E38)
        self.assertEqual(again["BOARDS"]["dm32"]["tables"][1], 0x18003E28)

    def test_production_unknown_and_truncated_dumps_are_rejected(self):
        for blob in (b"", b"\0" * (CODEC.PROGRAM_BYTES - 1), b"\0" * (CODEC.PROGRAM_BYTES + 1)):
            with self.assertRaisesRegex(ValueError, "complete 1 MiB"):
                CODEC.inspect_nrfb_program(blob)
        with self.assertRaisesRegex(Exception, "unsupported stock file"):
            CODEC.inspect_nrfb_program(b"\xFF" * CODEC.PROGRAM_BYTES)
        with self.assertRaisesRegex(ValueError, "explicit experimental"):
            CODEC.experimental_nrfb_slot(b"")
        _, _, program, _, _ = synthetic()
        with self.assertRaisesRegex(Exception, "unsupported stock file"):
            CODEC.inspect_nrfb_program(program)

    def synthetic_slot(self):
        # Replace only immutable fingerprints in an isolated test context. All
        # extraction, relocation, CRC and slot code is the real pinned tool.
        m, profile, program, code, tables = synthetic()
        with patch.object(CODEC, "nrfb_profile", return_value=profile), \
                patch.object(CODEC, "nrfb_contract", return_value=m), \
                patch.object(CODEC, "CODE_SHA256", profile["code_sha256"]), \
                patch.object(CODEC, "TABLE_SHA256", profile["tables_sha256"]):
            found, actual_code, actual_tables = CODEC.inspect_nrfb_program(program)
            self.assertEqual((actual_code, actual_tables), (code, tables))
            tool = CODEC.native_tools()
            normalized = tool["codecmap"].normalize(m)
            with self.assertRaisesRegex(Exception, "reserved modem SRAM"):
                tool["slot_bytes"](found, code, tables, maps={m["profile"]: normalized})
            slot, report = CODEC.experimental_nrfb_slot(program, experimental_rf_b=True)
        self.assertFalse(report["hardware_qualified"])
        self.assertFalse(report["installation_supported"])
        self.assertEqual(len(slot), 95748)
        header = struct.unpack_from("<19I", slot)
        self.assertEqual(header[3], len(code))
        self.assertEqual(header[7], 0x18000EC0)
        self.assertEqual(header[15], 50)
        self.assertEqual(slot[header[2]:header[2] + len(code)], code)
        self.assertEqual(slot[header[5]:header[5] + len(tables)], tables)
        for start in (profile["code"][0] - 0x03000000 + 100,
                      profile["tables"][0] - 0x03000000 + 100):
            damaged = bytearray(program)
            damaged[start] ^= 1
            with patch.object(CODEC, "nrfb_profile", return_value=profile), \
                    self.assertRaisesRegex(Exception, "unsupported stock file"):
                CODEC.inspect_nrfb_program(bytes(damaged))
        return slot

    def test_experimental_slot_preserves_synthetic_windows_with_exact_relocations(self):
        self.synthetic_slot()

    def test_actual_firmware_validator_accepts_only_expanded_window_and_intact_slot(self):
        cc = shutil.which("gcc") or shutil.which("cc")
        if not cc:
            self.skipTest("host C compiler unavailable")
        slot = self.synthetic_slot()
        with tempfile.TemporaryDirectory() as temp:
            d = Path(temp)
            (d / "slot.bin").write_bytes(slot)
            (d / "test.c").write_text(r'''
#include "codec_slot.h"
#include <assert.h>
#include <stdio.h>
int main(int argc, char **argv) {
    assert(argc==2);
    uint8_t slot[95748]; FILE *f=fopen(argv[1],"rb"); assert(f);
    assert(fread(slot,1,sizeof slot,f)==sizeof slot);fclose(f);
    codec_windows_t win={0x43A00,0x58000,0x18000E48,0x18003E28};uint32_t run=0;
    assert(!codec_slot_check(slot,sizeof slot,&win,&run));
    win.tab_hi=0x18003E38;
    assert(codec_slot_check(slot,sizeof slot,&win,&run) && run==0x43A00);
    assert(!codec_slot_check(slot,sizeof slot-1,&win,&run));
    codec_slot_t head;memcpy(&head,slot,sizeof head);head.tab_ram++;
    memcpy(slot,&head,sizeof head);assert(!codec_slot_check(slot,sizeof slot,&win,&run));
    head.tab_ram--;memcpy(slot,&head,sizeof head);
    slot[128+100]^=1;assert(!codec_slot_check(slot,sizeof slot,&win,&run));
    return 0;
}
''')
            exe = d / "check.exe"
            subprocess.run([cc, "-std=c11", "-Wall", "-Wextra", "-Werror", "-I",
                            str(UPSTREAM / "platform/hrc7000"), str(d / "test.c"), "-o", str(exe)],
                           check=True, capture_output=True)
            subprocess.run([str(exe), str(d / "slot.bin")], check=True, capture_output=True)


if __name__ == "__main__":
    unittest.main()
