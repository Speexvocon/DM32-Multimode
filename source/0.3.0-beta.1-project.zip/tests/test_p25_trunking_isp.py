# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline ISP/OSP fields and padded CAI bytes against independent pinned OP25.

These tests do not validate RF slot timing, burst tails, PA or access scheduling.
"""
import ctypes as C
import importlib.util
import os
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build/test-p25-trunking-isp"
BUILD.mkdir(parents=True, exist_ok=True)
LIB = BUILD / ("p25_trunking_isp.dll" if sys.platform == "win32" else "p25_trunking_isp.so")
command = ["gcc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-Wshadow", "-shared"]
if sys.platform != "win32":
    command.append("-fPIC")
subprocess.run(command + ["-Isrc/firmware", "src/firmware/p25_rx.c", "src/firmware/p25_tsdu.c",
    "src/firmware/p25_trunking_isp.c", "tests/test_p25_trunking_isp_bridge.c", "-o", str(LIB)],
    cwd=ROOT, check=True)
lib = C.CDLL(str(LIB))
Byte = C.c_uint8
Block = Byte * 12
lib.p25_isp_test_build.argtypes = [C.c_uint, C.POINTER(Byte), C.c_uint32, C.c_uint16,
    C.c_uint16, C.c_uint32, Byte]
lib.p25_isp_test_build.restype = C.c_bool
lib.p25_osp_test_parse.argtypes = [C.POINTER(Byte), C.POINTER(C.c_uint32)]
lib.p25_osp_test_parse.restype = C.c_bool
lib.p25_osp_test_frame.argtypes = [C.POINTER(Byte), C.c_size_t, C.POINTER(C.c_uint32)]
lib.p25_osp_test_frame.restype = C.c_bool
lib.p25_tsdu_encode.argtypes = [C.POINTER(Byte), C.c_size_t, C.c_uint16,
    C.POINTER(Block), C.c_uint, Byte]
lib.p25_tsdu_encode.restype = C.c_size_t

spec = importlib.util.spec_from_file_location("p25craft_isp",
    ROOT / "external/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py")
op = importlib.util.module_from_spec(spec)
previous = Path.cwd()
os.chdir(BUILD)
try:
    spec.loader.exec_module(op)
finally:
    os.chdir(previous)
if op.outfile:
    op.outfile.close()
op.text_out = lambda *_: None
frames = []
op.print_spec = lambda syms: frames.append(bytes(
    sum(syms[i+j] << (6-j*2) for j in range(4)) for i in range(0, len(syms), 4)))


def buffer(wire):
    return (Byte * len(wire)).from_buffer_copy(wire)


def block(opcode, argument, last=True, protected=False, mfid=0):
    return op.construct_tsbk(last, protected, opcode, mfid, argument).to_bytes(12, "big")


def encode_native(blocks, nac=0x293, status=2, capacity=90, expected=True):
    supplied = (Block * len(blocks))(*(Block.from_buffer_copy(b) for b in blocks))
    out = (Byte * 96)(*[0xA5] * 96)
    before = bytes(out)
    size = lib.p25_tsdu_encode(out, capacity, nac, supplied, len(blocks), status)
    assert bool(size) == expected
    if not size:
        assert bytes(out) == before, "Encoder refusal changed output"
    else:
        assert bytes(out[size:]) == before[size:], "Encoder wrote beyond its result"
    return bytes(out[:size])


def encode_reference(blocks, nac=0x293, status=2):
    syms = op.start_packet(nac, 7)
    for b in blocks:
        syms.extend(op.data_interleave(op.trellis_1_2_encode(op.split_dibits(int.from_bytes(b, "big"), 48))))
    frames.clear()
    op.print_spec(op.insert_status(syms, (status,) * ((56 + len(blocks)*98 + 34)//35)))
    return frames[0]


def build(kind, wacn=0xABCDE, system=0x123, group=0x1234, rid=0x123456, options=4, expected=True):
    out = Block(*[0xA5]*12)
    before = bytes(out)
    ok = lib.p25_isp_test_build(kind, out, wacn, system, group, rid, options)
    assert ok == expected, (kind, wacn, system, group, rid, options)
    if not ok:
        assert bytes(out) == before, "Request refusal changed output"
    return bytes(out)


def parse(b, expected=True):
    out = (C.c_uint32 * 20)(*[0xA5A5A5A5]*20)
    before = bytes(out)
    assert lib.p25_osp_test_parse(buffer(b), out) == expected
    if not expected:
        assert bytes(out) == before, "OSP refusal changed output"
    return list(out)


def parse_frame(b):
    wire = encode_reference([b], status=3)
    out = (C.c_uint32 * 20)()
    assert lib.p25_osp_test_frame(buffer(wire), len(wire), out)
    return list(out)


rng = random.Random(0x1A5B293)
for count in (1, 2, 3):
    for status in range(4):
        for _ in range(20):
            nac = rng.randrange(4096)
            blocks = [block(rng.randrange(64), rng.getrandbits(64), i == count-1,
                            bool(rng.randrange(2)), rng.randrange(256)) for i in range(count)]
            assert encode_native(blocks, nac, status) == encode_reference(blocks, nac, status)
            for capacity in (0, len(encode_reference(blocks, nac, status))-1):
                encode_native(blocks, nac, status, capacity, False)

# Independent OP25 named request factories supply field orientation and FEC.
named = [op.construct_u_reg_req, op.construct_grp_aff_req, op.construct_grp_v_req, op.construct_u_dereg_req]
original_options = op.construct_svcopt
for _ in range(100):
    wacn, system = rng.randrange(1, 1 << 20), rng.randrange(1, 1 << 12)
    group, rid, nac = rng.randrange(1, 1 << 16), rng.randrange(1, 1 << 24), rng.randrange(4096)
    for kind in range(4):
        native = build(kind, wacn, system, group, rid)
        frames.clear()
        if kind in (0, 3):
            named[kind](nac, 2, wacn, system, rid)
        elif kind == 1:
            named[kind](nac, 2, system, group, rid)
        else:
            # OP25's example defaults to encrypted voice; explicitly choose its
            # clear service option while preserving the named field factory.
            op.construct_svcopt = lambda e, p, d, m, r, pr: original_options(e, 0, d, m, r, pr)
            try:
                named[kind](nac, 2, group, rid)
            finally:
                op.construct_svcopt = original_options
        assert encode_native([native], nac) == frames[0]

for kind in range(4):
    for rid in (0, 1 << 24, 0xFFFFFFFF):
        build(kind, rid=rid, expected=False)
    build(kind, wacn=1, system=1, group=1, rid=1)
    build(kind, wacn=0xFFFFF, system=0xFFF, group=0xFFFF, rid=0xFFFFFF)
for kind in (0, 3):
    for wacn in (0, 1 << 20, 0xFFFFFFFF):
        build(kind, wacn=wacn, expected=False)
for kind in (0, 1, 3):
    for system in (0, 0x1000, 0xFFFF):
        build(kind, system=system, expected=False)
for kind in (1, 2):
    build(kind, group=0, expected=False)
for options in range(256):
    b = build(2, options=options, expected=(options & ~0x87) == 0)
    if options & ~0x87 == 0:
        assert b == block(0, (options << 56) | (0x1234 << 24) | 0x123456)
for kind in range(4):
    assert not lib.p25_isp_test_build(kind, None, 1, 1, 1, 1, 4)

good = build(0)
for count in (1, 2, 3):
    blocks = [block(0x3B, rng.getrandbits(64), i == count-1) for i in range(count)]
    for b in range(count):
        bad = list(blocks)
        wrong = bytearray(bad[b]); wrong[10] ^= 1; bad[b] = bytes(wrong)
        encode_native(bad, expected=False)
        bad = list(blocks)
        wrong = bytearray(bad[b]); wrong[0] ^= 0x80
        # Recompute CRC so LB alone is the reason for refusal.
        bad[b] = block(wrong[0] & 0x3F, int.from_bytes(wrong[2:10], "big"), bool(wrong[0] & 0x80))
        encode_native(bad, expected=False)
encode_native([], expected=False)
encode_native([good]*4, expected=False)
encode_native([good], nac=4096, expected=False)
encode_native([good], status=4, expected=False)
assert lib.p25_tsdu_encode(None, 90, 0x293, (Block*1)(Block.from_buffer_copy(good)), 1, 2) == 0
assert lib.p25_tsdu_encode((Byte*90)(), 90, 0x293, None, 1, 2) == 0
# All NAC header codewords, independent OP25 BCH; status must stay exactly 10.
for nac in range(4096):
    wire = encode_native([good], nac)
    bits = [(wire[i//4] >> (6-2*(i%4))) & 3 for i in range(len(wire)*4)]
    nid = 0
    for i in range(24, 57):
        if i != 35:
            nid = (nid << 2) | bits[i]
    assert nid == op.bch_64_16_23_encode((nac << 4) | 7)
    assert all(bits[i] == 2 for i in range(35, len(bits), 36))

# OSP fields are checked against OP25 tk_p25's independent bit orientation.
for _ in range(200):
    rid, assigned = rng.randrange(1, 1 << 24), rng.randrange(1, 1 << 24)
    group, channel, system = rng.randrange(1, 1 << 16), rng.randrange(1 << 16), rng.randrange(1, 1 << 12)
    options, response, announcement = rng.randrange(256), rng.randrange(4), rng.randrange(1 << 16)
    grant = parse(block(0, options << 56 | channel << 40 | group << 24 | rid))
    assert grant[:12] == [1, 0, 0, options, 0, 0, group, 0, channel, rid, 0, 0]
    assert grant[15] == bool(options & 0x40)
    reg = parse(block(0x2C, response << 60 | system << 48 | assigned << 24 | rid))
    assert reg[0] == 2 and reg[4:6] == [response, system] and reg[9:12] == [0, rid, assigned]
    global_ = rng.randrange(2)
    aff = parse(block(0x28, global_ << 63 | response << 56 | announcement << 40 | group << 24 | rid))
    assert aff[0] == 3 and aff[4] == response and aff[6:8] == [group, announcement] and aff[10] == rid and aff[14] == global_
    for opcode, type_ in ((0x20, 4), (0x21, 5), (0x27, 6)):
        service = rng.randrange(64)
        reason = 0 if opcode == 0x20 else rng.randrange(1, 256)
        for additional in (0, 1):
            arg = additional << 63 | service << 56 | reason << 48 | (assigned << 24 if additional else 0) | rid
            event = parse(block(opcode, arg))
            assert event[0] == type_ and event[2] == service and event[4] == reason and event[10] == rid
            assert event[9] == (assigned if additional else 0) and event[12] == additional
    # Extended ACK body is network/system, not an additional radio address.
    event = parse(block(0x20, 0xC0 << 56 | rng.getrandbits(32) << 24 | rid))
    assert event[0] == 4 and event[9] == 0 and event[10] == rid and event[12:14] == [1, 1]

for opcode in (0x2A, 0x2D, 0x31, 0x32):
    assert parse(block(opcode, 0))[0:2] == [7, opcode]
for opcode in (0x2A, 0x2D):
    # Primary command layouts: target precedes the source (not the final24).
    for target in (1, 0x123456, 0x654321, 0xFFFFFF):
        event = parse_frame(block(opcode, target << 24 | 0xFFFFFC))
        assert event[0] == 7 and event[9:11] == [0xFFFFFC, target]
        assert parse_frame(block(opcode, 0xFFFFFC << 24 | target))[10] == 0xFFFFFC
    # Reserved/unknown formatting cannot be qualified as a foreign address.
    assert parse_frame(block(opcode, 1 << 48 | 0x654321 << 24 | 0x123456))[10] == 0
for target in (1, 0x123456, 0x654321, 0xFFFFFF):
    assert parse_frame(block(0x32, 0xA1B2C3D4 << 24 | target))[10] == target
    assert parse_frame(block(0x32, 1 << 56 | target))[10] == 0
# 0x31 authentication demand is qualified only as unsupported here: its
# reviewed AMBT layout cannot be invented from a single TSBK's last24 bits.
assert parse_frame(block(0x31, 0x123456 << 24 | 0x654321))[10] == 0
for opcode in (0x02, 0x03, 0x04, 0x2B, 0x33, 0x34, 0x3B, 0x3D):
    parse(block(opcode, rng.getrandbits(64)), False)
valid = [block(0, 4 << 56 | 0x1234 << 24 | 0x123456),
         block(0x2C, 0x123 << 48 | 0x123456 << 24 | 0x123456),
         block(0x28, 0x1234 << 24 | 0x123456), block(0x20, 0x123456),
         block(0x21, 1 << 48 | 0x123456), block(0x27, 1 << 48 | 0x123456)]
for b in valid:
    for bit in range(96):
        bad = bytearray(b); bad[bit//8] ^= 1 << (bit%8)
        parse(bad, False)
    parse(block(b[0] & 0x3F, int.from_bytes(b[2:10], "big"), protected=True), False)
    parse(block(b[0] & 0x3F, int.from_bytes(b[2:10], "big"), mfid=0x90), False)
    # LB is framing, not a direction or authorization marker.
    assert parse(block(b[0] & 0x3F, int.from_bytes(b[2:10], "big"), last=False))[0] == parse(b)[0]
for opcode, arg in ((0, 1), (0, 1 << 24), (0x2C, 1 << 62 | 1 << 48 | 1),
                    (0x28, 1 << 62 | 1 << 24 | 1), (0x20, 1 << 62 | 1),
                    (0x20, 1 << 48 | 1), (0x21, 1), (0x27, 1 << 62 | 1 << 48 | 1)):
    parse(block(opcode, arg), False)
assert not lib.p25_osp_test_parse(None, (C.c_uint32*20)())
print("PASS: 240 padded CAI vectors, 400 named OP25 requests, all 4096 NACs, bounded/refusal contracts and addressed OSP responses; RF slot timing untested")
