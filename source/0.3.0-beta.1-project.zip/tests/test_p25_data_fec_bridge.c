// SPDX-License-Identifier: GPL-3.0-or-later
// Count actual fallback iterations without adding firmware diagnostic hooks.
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
static unsigned metric_steps;
static void *measured_copy(void *destination,const void *source,size_t bytes) {
    if(bytes==4u*sizeof(uint16_t))++metric_steps;
    return memcpy(destination,source,bytes);
}
#define memcpy measured_copy
#include "p25_data_fec.h"
#undef memcpy

bool p25_test_data_decode(const uint8_t *frame,size_t bytes,unsigned block,
                          uint8_t out[12],unsigned *branches) {
    metric_steps=0;
    bool result=p25_data_decode_block(frame,bytes,block,out);
    *branches=metric_steps*16u;
    return result;
}
unsigned p25_test_data_inverse(unsigned symbol) {
    return symbol<16u ? p25_data_trellis_inverse[symbol] : 256u;
}
