# SPDX-License-Identifier: GPL-3.0-or-later
"""Pure burst geometry and independent OP25316-bit rendering; opens no radio."""
import ctypes as C
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-trunking-burst'
BUILD.mkdir(parents=True,exist_ok=True)
binary=BUILD/('burst.exe' if sys.platform=='win32' else 'burst')
common=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-Isrc/firmware']
subprocess.run(common+['src/firmware/p25_trunking_burst.c','tests/test_p25_trunking_burst.c','-o',str(binary)],cwd=ROOT,check=True)
subprocess.run([str(binary)],cwd=ROOT,check=True)
library=BUILD/('burst.dll' if sys.platform=='win32' else 'burst.so')
subprocess.run(common+['-shared',*(['-fPIC'] if sys.platform!='win32' else []),
    'src/firmware/p25_trunking_burst.c','-o',str(library)],cwd=ROOT,check=True)
lib=C.CDLL(str(library))

class Config(C.Structure):
    _fields_=[('lead_bytes',C.c_uint16),('packet_after_rf_us',C.c_uint32),
        ('pa_lead_us',C.c_uint16),('end_trim_us',C.c_int16)]
class Plan(C.Structure):
    _fields_=[('lead_bytes',C.c_uint16),('valid_bits',C.c_uint16),('prefix_bytes',C.c_uint16),
        ('transport_bytes',C.c_uint16),('packet_after_rf_us',C.c_uint32),
        ('pa_after_rf_us',C.c_uint32),('cut_after_rf_us',C.c_uint32)]
lib.p25_trunking_burst_plan_make.argtypes=[C.POINTER(Plan),C.POINTER(Config)]
lib.p25_trunking_burst_plan_make.restype=C.c_bool
lib.p25_trunking_burst_render.argtypes=[C.POINTER(Plan),C.POINTER(C.c_uint8),C.c_uint,C.POINTER(C.c_uint8)]
lib.p25_trunking_burst_render.restype=C.c_bool
spec=importlib.util.spec_from_file_location('burst_independent_fixture',ROOT/'scripts/generate-p25-access-fixture.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
files,metadata=fixture.make_fixture(radio_id=0x123456)
prefix=files['registration-prefix.bin']
wire=files['registration.bin']
assert metadata['prefix']['valid_bits']==316

for lead in range(72,241):
    plan=Plan();config=Config(lead,170000,1000,-125)
    assert lib.p25_trunking_burst_plan_make(C.byref(plan),C.byref(config))
    for low in range(16):
        # The unused container nibble is not CAI. Rendering must disregard it.
        supplied=prefix[:39]+bytes(((prefix[39]&0xF0)|low,))
        input_=(C.c_uint8*40).from_buffer_copy(supplied)
        rendered=bytearray()
        for index in range(plan.transport_bytes//36):
            block=(C.c_uint8*36)()
            assert lib.p25_trunking_burst_render(C.byref(plan),input_,index,block)
            rendered.extend(block)
        assert bytes(input_)==supplied
        expected=b'\x77'*lead+prefix[:39]+bytes(((prefix[39]&0xF0)|7,))
        expected+=b'\x77'*(plan.transport_bytes-len(expected))
        assert rendered==expected
        # Exactly316 CAI bits match independent OP25, including the partial
        # last byte. All subsequent bits are deliberate transport fill.
        bits=lambda data:[(byte>>(7-i))&1 for byte in data for i in range(8)]
        assert bits(rendered)[lead*8:lead*8+316]==bits(wire)[:316]
        tail=min(5,len(rendered)-(lead+40))
        assert rendered[lead+40:lead+40+tail]==b'\x77'*tail
        if tail:
            assert rendered[lead+40:lead+40+tail]!=wire[40:40+tail]
assert Plan.cut_after_rf_us.offset==16 and C.sizeof(Plan)==20
print('PASS:169 lead lengths x16 unused nibbles preserve exactly316 independent OP25 bits and exclude45-byte protocol padding')
