# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent canonical RXSTREAM fixtures, corruption checks; no device access."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("p25_rx_stream_analyzer", ROOT / "scripts/analyze-p25-rx-stream.py")
analysis = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(analysis)
U32 = 0xFFFFFFFF


def half(index=0, *, origin=100000, first=None, irq_count=None, early=240,
         tail=16, checked=16, mismatch=0, flags=8192, published=0xFFF00001,
         completed=None, interval=32000, max_read=40, max_queue=140,
         delivery_age=32500):
    """Pack from the documented wire layout, independently of analyzer constants."""
    return struct.pack("<Q5I6H2I", index * 256 if first is None else first,
                       origin & U32, (origin + interval) & U32,
                       published, published if completed is None else completed,
                       index + 1 if irq_count is None else irq_count,
                       early, tail, checked, mismatch, flags, max_read,
                       max_queue, (origin + delivery_age) & U32)


def marker(tick=600, *, origin=100000, cpu=None, stream=7, epoch=1, nac=0x293,
           status=3, lane=0, qualified=1, selected=1, age=1500, reserved=(0, 0, 0)):
    return struct.pack("<QIIIH6BI", tick,
                       (origin + round(tick * 125 / 6) + age) & U32 if cpu is None else cpu,
                       stream, epoch, nac, status, lane, qualified, selected,
                       *reserved)


def capture(halves=None, markers=None, *, origin=100000, state="complete", samples=512,
            produced=None, consumed=None, verified=None, guard=500, stream=7,
            faults=0, dump=1, extra=""):
    halves = halves if halves is not None else [half(0, origin=origin), half(1, origin=origin + 32000)]
    markers = markers if markers is not None else [marker(tick, origin=origin) for tick in (600, 960, 1320, 1680, 2040)]
    produced = samples if produced is None else produced
    consumed = samples if consumed is None else consumed
    verified = samples if verified is None else verified
    header = (f"RXSTREAM state={state} samples={samples} produced={produced} consumed={consumed} "
              f"verified={verified} halves={len(halves)} markers={len(markers)} guard_us={guard} "
              f"stream_epoch={stream} faults={faults} half_bytes=48 marker_bytes=32 "
              f"service=timer500 clock=recorder_unqualified dump={dump}{extra}")
    rows = ([f"RXSTREAM_HALF index={index} data={data.hex()}" for index, data in enumerate(halves)]
            + [f"RXSTREAM_MARK index={index} data={data.hex()}" for index, data in enumerate(markers)]) if dump else []
    return "\r\n".join([header, *rows, f"RXSTREAM_END halves={len(halves)} markers={len(markers)} state={state}"]) + "\r\n"


def workers(calls=32, total=32000, maximum=1800, yields=0):
    return (f" worker_calls={calls} worker_total_us={total} "
            f"worker_max_us={maximum} worker_yields={yields}")


class StreamAnalysisTests(unittest.TestCase):
    def test_contiguous_hash_matched_stream_reports_observed_cpu_limits_only(self):
        result = analysis.parse_trace(capture())
        self.assertTrue(result["all_streams_coherent"])
        item = result["captures"][0]
        self.assertEqual(item["halves"][1]["first_sample"], 256)
        self.assertEqual(item["halves"][0]["published_hash"], "fff00001")
        self.assertEqual(item["cpu_observations"]["max_single_read_us_per_half"]["max"], 40)
        self.assertEqual(item["cpu_observations"]["max_read_end_to_consumer_queue_us_per_half"]["max"], 140)
        self.assertEqual(item["cpu_observations"]["final_chunk_delivery_after_completion_irq_us"]["min"], 500)
        self.assertEqual(item["cpu_observations"]["max_recorded_single_read_fraction_of_nominal_chunk"], .02)
        self.assertEqual(item["cpu_observations"]["cpu_elapsed_vs_nominal_duration_ppm"], 0)
        self.assertTrue(item["cpu_observations"]["not_cpu_utilization"])
        self.assertEqual(item["marker_observations"]["status_spacing_ticks"]["median"], 360)
        self.assertEqual(item["marker_observations"]["irq_relative_nominal_status_age_us"]["min"], 1500)
        for key in ("sample_clock_qualified", "sample_origin_qualified", "sample_rate_qualified",
                    "first_air_constant_qualified", "rf_timing_qualified", "automatic_access_qualified",
                    "hashes_independently_recomputed"):
            self.assertIs(result[key], False)
        self.assertIn("unknown recorder/IRQ latency", result["limitations"])
        old_worker = item["worker_elapsed_observations"]
        self.assertFalse(old_worker["available"])
        self.assertNotIn("average_elapsed_us_per_chunk_attempt", old_worker)

    def test_optional_worker_counters_report_elapsed_not_pure_cpu(self):
        result = analysis.parse_trace(capture(extra=" units=16" + workers(yields=7)))
        item = result["captures"][0]["worker_elapsed_observations"]
        self.assertTrue(result["all_streams_coherent"])
        self.assertTrue(item["available"])
        self.assertEqual(item["chunk_attempts"], 32)
        self.assertEqual(item["total_elapsed_us"], 32000)
        self.assertEqual(item["average_elapsed_us_per_chunk_attempt"], 1000)
        self.assertEqual(item["max_elapsed_us_per_chunk_attempt"], 1800)
        self.assertEqual(item["budget_yields_with_backlog"], 7)
        self.assertEqual(item["average_fraction_of_nominal_chunk_period"], .5)
        self.assertEqual(item["max_fraction_of_nominal_chunk_period"], .9)
        self.assertTrue(item["includes_interrupt_preemption"])
        self.assertTrue(item["excludes_service_wait_and_yield"])
        self.assertFalse(item["pure_cpu_time"])
        self.assertFalse(result["automatic_access_qualified"])

    def test_worker_counter_group_is_all_four_or_none(self):
        pairs = ("worker_calls=32", "worker_total_us=32000", "worker_max_us=1800", "worker_yields=0")
        for selected in range(1, 15):
            extra = " " + " ".join(value for bit, value in enumerate(pairs) if selected & (1 << bit))
            with self.subTest(extra=extra), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(extra=extra))
        for extra in (workers() + " worker_calls=32", workers() + " worker_ticks=123",
                      workers().replace("worker_calls=32", "worker_calls=4294967296"),
                      workers().replace("worker_total_us=32000", "worker_total_us=-1")):
            with self.subTest(extra=extra), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(extra=extra))

    def test_worker_zero_attempts_have_no_average_or_max_measurement(self):
        text = capture([], [], state="fault", faults=16, produced=0, consumed=0, verified=0,
                       extra=workers(0, 0, 0, 0))
        result = analysis.parse_trace(text)
        item = result["captures"][0]["worker_elapsed_observations"]
        self.assertTrue(item["available"])
        self.assertEqual(item["total_elapsed_us"], 0)
        self.assertIsNone(item["average_elapsed_us_per_chunk_attempt"])
        self.assertIsNone(item["max_elapsed_us_per_chunk_attempt"])
        self.assertIsNone(item["average_fraction_of_nominal_chunk_period"])
        self.assertIsNone(item["max_fraction_of_nominal_chunk_period"])
        self.assertFalse(result["all_streams_coherent"])

    def test_worker_calls_must_match_stopped_consumption(self):
        for calls in (0, 31, 33):
            with self.subTest(calls=calls), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(extra=workers(calls, 0, 0)))
        # A popped chunk interrupted by a producer fault is still one attempt.
        row = half(early=16, tail=0, checked=0, flags=2 | 2048, interval=-100000,
                   max_queue=0, delivery_age=2500)
        text = capture([row], [], state="fault", faults=2, produced=16, consumed=16, verified=0,
                       extra=workers(1, 4500, 4500))
        result = analysis.parse_trace(text)
        item = result["captures"][0]["worker_elapsed_observations"]
        self.assertEqual(item["average_elapsed_us_per_chunk_attempt"], 4500)
        self.assertEqual(item["average_fraction_of_nominal_chunk_period"], 2.25)
        self.assertIn("part of its chunk", item["scope"])
        self.assertFalse(result["all_streams_coherent"])
        with self.assertRaises(analysis.StreamError):
            analysis.parse_trace(text.replace("worker_calls=1", "worker_calls=0"))

    def test_active_worker_status_may_have_only_one_outstanding_chunk(self):
        for state in ("recording", "draining"):
            for calls in (31, 32):
                result = analysis.parse_trace(capture(dump=0, state=state, extra=workers(calls, 0, 0)) + capture())
                self.assertEqual(result["status_snapshots"][0]["worker_calls"], calls)
            for calls in (30, 33):
                with self.subTest(state=state, calls=calls), self.assertRaises(analysis.StreamError):
                    analysis.parse_trace(capture(dump=0, state=state, extra=workers(calls, 0, 0)) + capture())

    def test_worker_total_max_yield_and_zero_counter_consistency(self):
        for extra in (workers(32, 1799, 1800), workers(32, 57601, 1800),
                      workers(32, 1, 0), workers(32, 32000, 1800, 33)):
            with self.subTest(extra=extra), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(extra=extra))

    def test_elapsed_budget_can_yield_after_each_costly_chunk(self):
        result = analysis.parse_trace(capture(extra=workers(32, 32000, 1800, 32)))
        self.assertEqual(result['captures'][0]['worker_elapsed_observations']['budget_yields_with_backlog'], 32)

    def test_no_yield_without_worker_attempt(self):
        text = capture([], [], state='fault', faults=16, produced=0, consumed=0, verified=0,
                       extra=workers(0, 0, 0, 1))
        with self.assertRaises(analysis.StreamError):
            analysis.parse_trace(text)
        for extra in (workers(0, 1, 0), workers(0, 0, 1), workers(0, 0, 0, 1)):
            with self.subTest(extra=extra), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture([], [], state="fault", produced=0, consumed=0, verified=0,
                                             extra=extra))
        # Zero elapsed measurements are permitted for a coarse/offline mock clock.
        result = analysis.parse_trace(capture(extra=workers(32, 0, 0)))
        self.assertEqual(result["captures"][0]["worker_elapsed_observations"]["average_elapsed_us_per_chunk_attempt"], 0)

    def test_old_and_worker_instrumented_captures_can_share_one_log(self):
        result = analysis.parse_trace(capture() + capture(extra=workers()))
        self.assertEqual([item["worker_elapsed_observations"]["available"] for item in result["captures"]],
                         [False, True])
        self.assertTrue(result["all_streams_coherent"])

    def test_uint32_cpu_wrap_including_exact_zero_irq_and_delivery(self):
        origin = U32 - 31999  # Completion of half0 is exactly zero.
        result = analysis.parse_trace(capture(origin=origin))
        self.assertTrue(result["all_streams_coherent"])
        self.assertEqual(result["captures"][0]["halves"][0]["completion_irq_us"], 0)
        self.assertEqual(result["captures"][0]["halves"][0]["irq_interval_us"], 32000)
        origin = U32 - 32499  # Last delivery of half0 is exactly zero.
        result = analysis.parse_trace(capture(origin=origin))
        self.assertEqual(result["captures"][0]["halves"][0]["last_delivery_us"], 0)
        self.assertTrue(result["all_streams_coherent"])

    def test_status_and_dump_are_distinguished_even_when_stopped(self):
        result = analysis.parse_trace(capture(dump=0) + capture(dump=0, state="recording") + capture())
        self.assertEqual(len(result["status_snapshots"]), 2)
        self.assertEqual(len(result["captures"]), 1)
        for bad in (capture(dump=0), capture().replace(" dump=1", ""), capture().replace("dump=1", "dump=0")):
            with self.subTest(bad=bad[:150]), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(bad)

    def test_nominal_rate_difference_is_descriptive_not_rate_qualification(self):
        rows = [half(0, interval=32050, delivery_age=32550),
                half(1, origin=132050, interval=32050, delivery_age=32550)]
        result = analysis.parse_trace(capture(rows, []))
        observations = result["captures"][0]["cpu_observations"]
        self.assertEqual(observations["cpu_minus_nominal_duration_us"], 100)
        self.assertEqual(observations["cpu_elapsed_vs_nominal_duration_ppm"], 1562.5)
        self.assertFalse(result["sample_rate_qualified"])

    def test_status_spacing_tolerance_and_loss_reselection_segmentation(self):
        events = [marker(600), marker(957), marker(1320),
                  marker(1500, status=0, qualified=0), marker(2400),
                  marker(2600, status=0, qualified=0, epoch=2, lane=9),
                  marker(2750, epoch=2, lane=9)]
        result = analysis.parse_trace(capture(markers=events))
        self.assertTrue(result["all_streams_coherent"])
        spacing = result["captures"][0]["marker_observations"]["status_spacing_ticks"]
        self.assertEqual((spacing["count"], spacing["min"], spacing["max"]), (2, 357, 363))

    def test_unqualified_lane255_loss_has_no_status_authority(self):
        events = [marker(600), marker(900, status=0, lane=255, selected=0, qualified=0),
                  marker(1500, epoch=2)]
        result = analysis.parse_trace(capture(markers=events))
        self.assertTrue(result["all_streams_coherent"])
        self.assertIsNone(result["captures"][0]["marker_observations"]["status_spacing_ticks"])

    def test_missing_status_or_out_of_tolerance_is_explicitly_unsuccessful(self):
        for delta in (356, 364, 720):
            result = analysis.parse_trace(capture(markers=[marker(600), marker(600 + delta)]))
            self.assertFalse(result["all_streams_coherent"])
            issue = result["captures"][0]["marker_observations"]["issues"][0]
            self.assertEqual(issue["spacing_ticks"], delta)

    def test_callback_order_and_status_sample_order_are_separate(self):
        # NID validation backdates a first status; callback order still advances.
        events = [marker(1000, status=0, qualified=0, cpu=130000),
                  marker(900, cpu=130010), marker(1260, cpu=130020)]
        self.assertTrue(analysis.parse_trace(capture(markers=events))["all_streams_coherent"])
        for events in ([marker(600), marker(600)], [marker(960), marker(600, cpu=125000)],
                       [marker(600, cpu=130000), marker(960, cpu=129999)]):
            with self.subTest(events=events), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(markers=events))

    def test_negative_nominal_age_is_preserved_not_hidden_by_fixed_offset(self):
        result = analysis.parse_trace(capture(markers=[marker(600, age=-50)]))
        self.assertEqual(result["captures"][0]["markers"][0]["nominal_status_age_us"], -50)
        self.assertFalse(result["first_air_constant_qualified"])

    def test_epoch_and_lane_identity_are_strict(self):
        events = ([marker(600, stream=8)], [marker(600, epoch=2), marker(960, epoch=1)],
                  [marker(600), marker(960, lane=1)], [marker(600), marker(960, nac=0x123)],
                  [marker(600, lane=10)], [marker(600, lane=255)],
                  [marker(600, selected=0)], [marker(600, status=4)],
                  [marker(600, nac=0x1000)], [marker(600, selected=2)])
        for markers in events:
            with self.subTest(markers=markers), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(markers=markers))
        hidden_change = [marker(600), marker(900, status=0, lane=255, selected=0, qualified=0),
                         marker(1500, lane=1)]
        with self.assertRaises(analysis.StreamError):
            analysis.parse_trace(capture(markers=hidden_change))

    def test_samples_must_end_on_advertised_consumed_range(self):
        for tick in (512 * 6, (1 << 64) - 1):
            with self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(markers=[marker(tick, cpu=150000)]))

    def test_ordinals_irqs_hashes_and_contiguous_epoch_are_strict(self):
        rows = ([half(first=16), half(1, origin=132000)],
                [half(irq_count=2), half(1, origin=132000)],
                [half(), half(1, origin=132001)],
                [half(completed=0xFFF00002), half(1, origin=132000)],
                [half(interval=0), half(1, origin=132000)],
                [half(interval=29999), half(1, origin=129999)],
                [half(interval=34001, delivery_age=34500), half(1, origin=134001)],
                [half(max_read=32000), half(1, origin=132000)],
                [half(interval=U32), half(1, origin=132000)])
        for halves in rows:
            with self.subTest(halves=halves), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(halves))

    def test_queue_and_tail_delivery_cannot_precede_readable_half(self):
        rows = ([half(max_queue=32501), half(1, origin=132000)],
                [half(delivery_age=31999), half(1, origin=132000)],
                [half(delivery_age=90000), half(1, origin=132000)])
        for halves in rows:
            with self.subTest(halves=halves), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(halves))

    def test_incomplete_and_faulted_traces_never_pass(self):
        bad_half = half(early=16, tail=0, checked=0, mismatch=1,
                        flags=512, completed=0x12345678)
        cases = (capture(state="cancelled"), capture(faults=16),
                 capture([bad_half], [], state="fault", produced=16, consumed=16, verified=0),
                 capture(consumed=496, markers=[]),
                 capture([half(), half(1, origin=132000, checked=15, flags=2048)], verified=496),
                 capture([half()], [], samples=512, produced=256, consumed=256, verified=256))
        for text in cases:
            with self.subTest(text=text[:150]):
                result = analysis.parse_trace(text)
                self.assertFalse(result["all_streams_coherent"])
                self.assertTrue(result["captures"][0]["issues"])

    def test_aggregate_counters_must_reconcile_with_binary_ledger(self):
        for text in (capture(verified=496), capture(consumed=496, produced=496, verified=496),
                     capture([half()], [], produced=512)):
            with self.subTest(text=text[:160]), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(text)

    def test_first_comparison_failure_and_inherited_flag_are_valid_fault_evidence(self):
        rows = [half(checked=0, mismatch=1, flags=512 | 2048),
                half(1, origin=132000, interval=-132000, early=0, tail=0,
                     checked=0, flags=512 | 2048, max_queue=0, delivery_age=-132000)]
        report = analysis.parse_trace(capture(rows, [], state="fault", faults=512,
                                              produced=256, consumed=256, verified=0))
        self.assertFalse(report["all_streams_coherent"])
        halves = report["captures"][0]["halves"]
        self.assertEqual(halves[0]["verified_chunks"], 0)
        self.assertEqual(halves[0]["mismatch_chunks"], 1)
        self.assertEqual(halves[1]["mismatch_chunks"], 0)
        self.assertIn("mismatch", halves[1]["issues"])

    def test_verified_and_undelivered_half_remains_visible_on_terminal_fault(self):
        row = half(max_queue=0, delivery_age=-100000)
        report = analysis.parse_trace(capture([row], [], state="fault", faults=4096,
                                              produced=256, consumed=0, verified=256))
        self.assertFalse(report["all_streams_coherent"])
        item = report["captures"][0]
        self.assertFalse(item["halves"][0]["final_chunk_delivered"])
        self.assertIsNone(item["halves"][0]["last_delivery_after_origin_us"])
        self.assertIsNone(item["cpu_observations"]["max_read_end_to_consumer_queue_us_per_half"])

    def test_masks_and_counter_consistency(self):
        for data in (half(flags=16384), half(flags=8192, mismatch=1, checked=15),
                     half(early=239, tail=16), half(early=256, tail=16),
                     half(checked=15), half(mismatch=1, checked=16, flags=512)):
            with self.subTest(data=data.hex()), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture([data, half(1, origin=132000)]))

    def test_marker_reserved_bytes_are_not_silently_reinterpreted(self):
        for reserved in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
            with self.subTest(reserved=reserved), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(capture(markers=[marker(reserved=reserved)]))

    def test_header_masks_geometry_bounds_and_qualification_are_strict(self):
        text = capture()
        replacements = (("samples=512", "samples=0"), ("samples=512", "samples=257"),
                        ("samples=512", "samples=16640"), ("produced=512", "produced=528"),
                        ("consumed=512", "consumed=513"), ("verified=512", "verified=528"),
                        ("guard_us=500", "guard_us=8001"), ("faults=0", "faults=16384"),
                        ("faults=0", "faults=8192"),
                        ("half_bytes=48", "half_bytes=49"), ("marker_bytes=32", "marker_bytes=31"),
                        ("service=timer500", "service=task"), ("recorder_unqualified", "qualified"),
                        ("state=complete", "state=recording"), ("dump=1", "dump=2"),
                        ("state=complete", "state=clock_error"),
                        ("guard_us=500", "guard_us=0500"), ("guard_us=500", "guard_us=-1"),
                        ("stream_epoch=7", "stream_epoch=4294967296"))
        for old, new in replacements:
            with self.subTest(new=new), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(text.replace(old, new))

    def test_duplicate_missing_reordered_and_truncated_records(self):
        lines = capture().splitlines()
        cases = ("\n".join(lines[:-1]), "\n".join(lines[:2] + lines[3:]),
                 "\n".join(lines[:2] + [lines[1]] + lines[2:]),
                 "\n".join([lines[0], lines[3], lines[1], lines[2], *lines[4:]]),
                 capture().replace("RXSTREAM_MARK index=0", "RXSTREAM_MARK index=1"),
                 capture().replace("RXSTREAM_HALF index=1", "RXSTREAM_HALF index=64"),
                 capture().replace("RXSTREAM_END halves=2", "RXSTREAM_END halves=1"),
                 capture().replace("data=", "data=z", 1),
                 capture().replace("data=", "data=0", 1))
        for text in cases:
            with self.subTest(text=text[:150]), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(text)

    def test_unknown_duplicate_nested_and_unbounded_input(self):
        text = capture()
        cases = (text.replace("guard_us=500", "guard_us=500 guard_us=500"),
                 text.replace("RXSTREAM_MARK", "RXSTREAM_BOGUS"),
                 text.splitlines()[0] + "\n" + text,
                 text + "\0", "x" * (analysis.MAX_INPUT_BYTES + 1),
                 text.replace("dump=1", "dump=1 authorized=1"),
                 "no capture", "RXSTREAM", "RXSTREAM_END halves=0 markers=0 state=complete")
        for bad in cases:
            with self.subTest(bad=bad[:150]), self.assertRaises(analysis.StreamError):
                analysis.parse_trace(bad)

    def test_multiple_captures_log_prefix_and_unrelated_output(self):
        prefixed = "\n".join("[12:34.5] " + line for line in capture().splitlines())
        unrelated = ("OK\nnotRXSTREAM\nTRUNK RXSTREAM START 16384 500\n"
                     "OK TRUNK RXSTREAM START finite receive-only; recorder clock unqualified\n"
                     "[12:34.5] ERR TRUNK RXSTREAM DUMP requires a stopped capture\n")
        result = analysis.parse_trace(unrelated + prefixed + "\n" + capture(guard=8000))
        self.assertEqual(len(result["captures"]), 2)
        self.assertTrue(result["all_streams_coherent"])

    def test_cli_exit_status_and_json_output(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "capture.log", Path(folder) / "report.json"
            source.write_text(capture(), encoding="utf-8")
            self.assertEqual(analysis.main([str(source), "--output", str(output)]), 0)
            self.assertFalse(json.loads(output.read_text())["automatic_access_qualified"])
            source.write_text(capture(faults=16), encoding="utf-8")
            with redirect_stdout(io.StringIO()):
                self.assertEqual(analysis.main([str(source)]), 1)
            source.write_text("RXSTREAM", encoding="utf-8")
            with redirect_stderr(io.StringIO()) as errors:
                self.assertEqual(analysis.main([str(source)]), 2)
            self.assertIn("failed", errors.getvalue())
            source.write_bytes(b"\xff")
            with redirect_stderr(io.StringIO()):
                self.assertEqual(analysis.main([str(source)]), 2)


if __name__ == "__main__":
    unittest.main()
