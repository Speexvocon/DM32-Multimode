// SPDX-License-Identifier: GPL-3.0-or-later
// Exact recorder behavior and IO order against the frozen original core.
#include "p25_rx_stream.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

bool reference_p25_rx_stream_start(p25_rx_stream *,void *,size_t,void *,size_t,unsigned,unsigned,uint32_t,uint32_t);
void reference_p25_rx_stream_irq(p25_rx_stream *,unsigned,uint32_t);
bool reference_p25_rx_stream_step(p25_rx_stream *,const p25_rx_progress_io *,uint32_t);
bool reference_p25_rx_stream_pop(p25_rx_stream *,p25_rx_stream_chunk *,uint32_t);
void reference_p25_rx_stream_finalize(p25_rx_stream *);

typedef struct {
    p25_rx_stream stream;
    unsigned char ring[8192],ledger[15360],window[1024];
    uint32_t now;
    unsigned reads,pending_calls,pend_at,mutate_at;
    unsigned io_events[104],io_event_count;
    bool pending;
} fixture;
static uint32_t random_state=0x12532000u;
static uint32_t random_word(void) {
    random_state^=random_state<<13;random_state^=random_state>>17;random_state^=random_state<<5;
    return random_state;
}
static void io_event(fixture *f,unsigned value) {
    assert(f->io_event_count<sizeof f->io_events/sizeof *f->io_events);
    f->io_events[f->io_event_count++]=value;
}
static uint8_t read_byte(void *context,unsigned offset) {
    fixture *f=context;assert(offset<sizeof f->window);io_event(f,0x10000000u|offset);
    ++f->reads;++f->now;
    if(f->pend_at&&f->reads==f->pend_at)f->pending=true;
    if(f->mutate_at&&f->reads==f->mutate_at)f->window[offset]^=0x40u;
    return f->window[offset];
}
static uint32_t clock_us(void *context) {
    fixture *f=context;io_event(f,0x20000000u);return f->now;
}
static bool pending(void *context) {
    fixture *f=context;io_event(f,0x30000000u|(unsigned)f->pending);
    ++f->pending_calls;return f->pending;
}
static p25_rx_progress_io io_for(fixture *f) {
    p25_rx_progress_io io={f,read_byte,clock_us,pending};return io;
}
static uint64_t comparisons,matched_io_events;
static void equal(fixture *a,fixture *b) {
    p25_rx_stream x=a->stream,y=b->stream;
    x.ring=y.ring=x.ledger=y.ledger=NULL;
    // The frozen source predates explicitly tagged marker storage. Normalize
    // only these new metadata bytes; all original state, arena bytes and exact
    // IO callback order remain compared below.
    // Bounded-state fixtures copy the production starting state to both cores;
    // the untouched reference otherwise leaves its added metadata at zero.
    assert((!x.marker_bytes||x.marker_bytes==32u)&&!x.marker_schema
        &&y.marker_bytes==32u&&!y.marker_schema);
    x.marker_bytes=y.marker_bytes=0;x.marker_schema=y.marker_schema=0;
    assert(!memcmp(&x,&y,sizeof x));
    assert(!memcmp(a->ring,b->ring,sizeof a->ring));
    assert(!memcmp(a->ledger,b->ledger,sizeof a->ledger));
    assert(!memcmp(a->window,b->window,sizeof a->window));
    assert(a->reads==b->reads&&a->now==b->now&&a->pending==b->pending);
    assert(b->pending_calls==a->pending_calls);
    assert(a->io_event_count==b->io_event_count);
    assert(!memcmp(a->io_events,b->io_events,a->io_event_count*sizeof *a->io_events));
    ++comparisons;
}
static void start(fixture *a,fixture *b,unsigned samples,unsigned guard,uint32_t now) {
    memset(a,0,sizeof *a);memset(b,0,sizeof *b);a->now=b->now=now;
    assert(reference_p25_rx_stream_start(&a->stream,a->ring,sizeof a->ring,a->ledger,sizeof a->ledger,samples,guard,17,now));
    assert(p25_rx_stream_start(&b->stream,b->ring,sizeof b->ring,b->ledger,sizeof b->ledger,samples,guard,17,now));
    equal(a,b);
}
static bool step(fixture *a,fixture *b,uint32_t now) {
    a->now=b->now=now;
    a->io_event_count=b->io_event_count=0;
    unsigned calls_a=a->pending_calls,calls_b=b->pending_calls;
    p25_rx_progress_io ia=io_for(a),ib=io_for(b);
    bool x=reference_p25_rx_stream_step(&a->stream,&ia,now),y=p25_rx_stream_step(&b->stream,&ib,now);
    assert(x==y);equal(a,b);
    unsigned delta_a=a->pending_calls-calls_a,delta_b=b->pending_calls-calls_b;
    assert(delta_a==delta_b);matched_io_events+=a->io_event_count;
    return y;
}
static void irq(fixture *a,fixture *b,unsigned half,uint32_t now) {
    reference_p25_rx_stream_irq(&a->stream,half,now);p25_rx_stream_irq(&b->stream,half,now);equal(a,b);
}
static void consume(fixture *a,fixture *b) {
    for(;;) {
        p25_rx_stream_chunk x,y;memset(&x,0x55,sizeof x);memset(&y,0x55,sizeof y);
        bool ra=reference_p25_rx_stream_pop(&a->stream,&x,a->now),rb=p25_rx_stream_pop(&b->stream,&y,b->now);
        assert(ra==rb&&!memcmp(&x,&y,sizeof x));equal(a,b);if(!ra)return;
    }
}
static void fill(fixture *a,fixture *b,unsigned index,unsigned count) {
    unsigned half=index%2u?1u:2u;
    for(unsigned i=0;i<count;++i) {
        uint16_t value=(uint16_t)((index*256u+i)*173u+0x1213u);unsigned off=(half-1u)*512u+i*2u;
        a->window[off]=b->window[off]=(uint8_t)(value>>8);
        a->window[off+1u]=b->window[off+1u]=(uint8_t)value;
    }
}
static void complete(unsigned samples,unsigned guard,uint32_t origin) {
    fixture a,b;start(&a,&b,samples,guard,origin);irq(&a,&b,1u,origin);
    unsigned completed=0;
    for(uint32_t tick=500u;tick<(samples/256u+2u)*32000u&&p25_rx_stream_active(&b.stream);tick+=500u) {
        a.now=b.now=origin+tick;
        if(tick/32000u>completed) {
            fill(&a,&b,completed,256u);completed=tick/32000u;
            irq(&a,&b,completed%2u?2u:1u,origin+tick);
        }
        if(completed<samples/256u)fill(&a,&b,completed,tick%32000u/125u);
        (void)step(&a,&b,origin+tick);
        if(!(tick%4000u))consume(&a,&b);
    }
    assert(b.stream.state==P25_RX_STREAM_DRAINING);consume(&a,&b);
    reference_p25_rx_stream_finalize(&a.stream);p25_rx_stream_finalize(&b.stream);equal(&a,&b);
    assert(b.stream.state==P25_RX_STREAM_COMPLETE&&b.stream.produced==samples&&b.stream.verified==samples);
}
static void bounded_states(void) {
    fixture a,b;
    for(unsigned n=0;n<150000u;++n) {
        unsigned samples=(1u+random_word()%64u)*256u,guard=random_word()%8001u;
        uint32_t now=random_word();start(&a,&b,samples,guard,now);
        unsigned completed=random_word()%(samples/256u+1u);
        p25_rx_stream s=b.stream;
        s.state=P25_RX_STREAM_RUNNING;s.irq_count=completed+1u;s.completed_halves=(uint16_t)completed;
        s.halves=(uint16_t)(completed+1u);if(s.halves>s.limit_halves)s.halves=s.limit_halves;
        s.last_half=(uint8_t)(1u+random_word()%2u);s.irq_serial=random_word();
        s.last_irq_us=now-random_word()%35001u;
        s.produced=(random_word()%(samples/16u+1u))*16u;
        s.verified=(random_word()%(samples/16u+1u))*16u;
        s.consumed=(random_word()%(samples/16u+1u))*16u;
        if(n%7u==0)s.irq_count+=2u; // Suspect metadata must retain the original gate.
        if(n%11u==0) {s.have_step=true;s.last_step_us=now+1u;}
        if(n%13u==0)s.armed_us=now-4000001u;
        if(n%17u==0)s.state=P25_RX_STREAM_WAIT;
        b.stream=s;a.stream=s;a.stream.ring=a.ring;a.stream.ledger=a.ledger;
        for(unsigned i=0;i<sizeof a.window;++i)a.window[i]=b.window[i]=(uint8_t)random_word();
        // Valid ring tags permit either a real comparison or an identical
        // metadata refusal. Offsets remain bounded, even for incoherent states.
        for(unsigned i=0;i<128u;++i) {
            unsigned char *x=a.ring+i*64u,*y=b.ring+i*64u;
            uint64_t ordinal=(uint64_t)i*16u;
            for(unsigned byte=0;byte<8u;++byte)x[32u+byte]=y[32u+byte]=(uint8_t)(ordinal>>(8u*byte));
            x[60]=y[60]=s.last_half;
        }
        a.pending=b.pending=(random_word()%3u)==0;
        if(n%19u==0)a.pend_at=b.pend_at=1u+random_word()%96u;
        if(n%23u==0)a.mutate_at=b.mutate_at=1u+random_word()%96u;
        (void)step(&a,&b,now);
    }
}
static void stale_and_pending_boundaries(void) {
    fixture a,b;
    const unsigned ages[]={0,3999,4000,31999,32000,33999,34000,UINT32_MAX};
    for(unsigned p=0;p<2u;++p)for(unsigned odd=0;odd<2u;++odd)
    for(unsigned n=0;n<sizeof ages/sizeof *ages;++n) {
        start(&a,&b,256u,2000u,UINT32_MAX-1000u);irq(&a,&b,1u,UINT32_MAX-1000u);
        a.pending=b.pending=p!=0;a.stream.irq_serial|=odd;b.stream.irq_serial|=odd;
        (void)step(&a,&b,(UINT32_MAX-1000u)+ages[n]);
    }
}
int main(void) {
    for(unsigned guard=0;guard<=8000u;guard+=2000u) {
        complete(16384u,guard,1000u);complete(256u,guard,UINT32_MAX-10000u);
    }
    bounded_states();stale_and_pending_boundaries();assert(matched_io_events>100000u);
    printf("RX stream frozen differential: %llu byte/state checks, %llu exact IO callbacks PASS\n",
        (unsigned long long)comparisons,(unsigned long long)matched_io_events);return 0;
}
