"""Host-only clock-probe allowlist, proof, restoration and failure tests."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import re
import struct
import sys
import tempfile
import unittest
from unittest import mock
import zlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('clock_probe', ROOT/'scripts/hrc7000-clock.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
spec = importlib.util.spec_from_file_location('clock_test_helpers', ROOT/'tests/test_hrc7000_capability.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def snapshot():
    return {**probe.COLD_CLOCKS, 'UART_LCR': 3, 'UART_IER': 0x80, 'UART_MCR': 0,
            'CACHE_REGION': 0, 'TIMER2_LOAD': 0xffffffff, 'TIMER2_CTRL': 5, 'APLL': 0x85040eb2}


def records(mode, values=None):
    values = snapshot() if values is None else values
    pairs = [(values['CTRL'], values['BPLL']), (values['DIV'], values['USB_SDIO']),
             (values['FLASH_DIV'], values['QUAD']), (values['CACHE_CTRL'], values['CACHE_REGION']),
             (values['UART_LCR'], values['UART_IER']), (values['TIMER2_LOAD'], values['TIMER2_CTRL']),
             (0x60, 6), (values['GATES'], values['APLL'])]
    entries = [(1, 0x23456789, 0)]+[(10+i, *pair) for i, pair in enumerate(pairs)]
    if mode:
        entries += [(20, 600000, probe.LOOP_HASH), (21, 300000, probe.LOOP_HASH),
                    (22, 600000, probe.LOOP_HASH), (23, values['CTRL'] & ~8, values['CTRL'])]
        entries += [(30+i, *pair) for i, pair in enumerate(pairs)]
        entries[-2] = (36, 0x61, 7)  # Volatile UART status is allowed to change.
    return [dict(id=identifier, status=0, value=value, aux=aux, vector=0, epc=0, epsr=0, reserved=0)
            for identifier, value, aux in entries]


def packet(nonce=123, mode=0, recs=None, header=None):
    recs = records(mode) if recs is None else recs
    fields = dict(nonce=nonce, build_id=probe.BUILD_ID, mode=mode,
                  total_bytes=probe.HEADER.size+len(recs)*probe.RECORD.size+4,
                  record_count=len(recs), fatal=0, guard_mask=31,
                  initial_psr=0x80000100, initial_vbr=0x30000, initial_sp=0x37b00, cpuid_words=0)
    if header:
        fields.update(header)
    body = probe.HEADER.pack(probe.MAGIC, *(fields[key] for key in probe.transport.HEADER_NAMES))
    body += b''.join(probe.RECORD.pack(*(record[key] for key in probe.transport.RECORD_NAMES)) for record in recs)
    return body+struct.pack('<I', zlib.crc32(body))


class FakeRadio:
    def __init__(self, port):
        self.port = port
        self.ops, self.memory = [], {}
        self.v6 = {key: value for key, value in probe.MONITOR.items() if key not in ('protocol', 'max_payload')}
        self.v6['stack_used'] = 164
        self.configured = None
        self.uart_hz = None
        self.registers = snapshot()
        self.samples = [24000000]*6
        self.hello_count = 0
        self.bad_readback = False
        self.fail_return = False
        self.modify_records = lambda records: records
        self.modify_raw = lambda raw: raw
        self.after_call = lambda: None

    def hello(self, retries):
        self.ops.append(('hello', retries))
        self.hello_count += 1
        if self.hello_count > 1 and self.fail_return:
            raise OSError('Monitor return failed')
        return 7, 1032

    def configure(self, board):
        self.ops.append(('configure', board))
        if board is not None:
            raise AssertionError('Only existing profile adoption is permitted')
        self.configured = {'id': 1}

    def timer_hz(self, span):
        self.ops.append(('timer_hz', span))
        return self.samples.pop(0)

    def peek(self, address, count):
        self.ops.append(('peek', address, count))
        if count > 512:
            raise AssertionError('Read exceeds approved 512-byte transfer')
        for key, register in {**probe.CLOCK_REGISTERS, **probe.UART_REGISTERS, **probe.OTHER_REGISTERS}.items():
            if address == register:
                if count != 4:
                    raise AssertionError('MMIO reads must be exact words')
                return self.registers[key].to_bytes(4, 'little')
        raw = bytes(self.memory[address+i] for i in range(count))
        return bytes([raw[0] ^ 1])+raw[1:] if self.bad_readback else raw

    def poke(self, address, data):
        if len(data) > 512:
            raise AssertionError('Write exceeds approved 512-byte transfer')
        self.ops.append(('poke', address, data))
        self.memory.update({address+i: byte for i, byte in enumerate(data)})

    def jump(self, address):
        self.ops.append(('call', address))
        args = bytes(self.memory[probe.ARGS+i] for i in range(64))
        nonce, mode = struct.unpack_from('<2I', args, 8)
        result = packet(nonce, mode, self.modify_records(records(mode, self.registers)))
        self.port.buffer.extend(self.modify_raw(result))
        self.after_call()


class ClockTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.image = bytes.fromhex('00500050')*300  # Three bounded transfers.
        elf = self.make_elf(self.image)
        self.manifest = dict(schema=probe.SCHEMA, build_id=probe.BUILD_ID, entry=probe.ENTRY,
            ram_start=probe.ENTRY, ram_end=probe.RAM_END, args_address=probe.ARGS,
            allowed_modes=[0, 1], stub_source_sha256=probe.transport.STUB_SHA256,
            source_commit='a'*40,
            image=dict(file='probe.bin', bytes=len(self.image), sha256=probe.digest(self.image)),
            elf=dict(file='probe.elf', bytes=len(elf), sha256=probe.digest(elf)),
            ranges={**copy.deepcopy(probe.FIXED), 'image':[probe.ENTRY, probe.ENTRY+len(self.image)],
                    'bss':[0x45000, 0x45004]})
        (self.directory/'probe.bin').write_bytes(self.image)
        (self.directory/'probe.elf').write_bytes(elf)
        self.path = self.directory/'manifest.json'
        self.save()
        self.bundle = probe.load_bundle(self.path)

    @staticmethod
    def make_elf(image):
        # One exact executable LOAD and an allocated image section, no external dependencies.
        section_offset = (0x100+len(image)+0x3f) & ~0x3f
        header = struct.pack('<16sHHIIIIIHHHHHH', b'\x7fELF\x01\x01\x01'+bytes(9),
                             2, 252, 1, probe.ENTRY, 52, section_offset, 0, 52, 32, 1, 40, 2, 0)
        segment = struct.pack('<8I', 1, 0x100, probe.ENTRY, probe.ENTRY, len(image), len(image), 5, 4)
        result = bytearray(section_offset+80)
        result[:52], result[52:84] = header, segment
        result[0x100:0x100+len(image)] = image
        result[section_offset+40:section_offset+80] = struct.pack('<10I', 0, 1, 6, probe.ENTRY, 0x100,
                                                               len(image), 0, 0, 4, 0)
        return bytes(result)

    def save(self):
        self.path.write_text(json.dumps(self.manifest))

    @contextlib.contextmanager
    def transport(self):
        reader = probe.transport.BoundedReader
        with mock.patch.object(probe.transport.time, 'sleep'), \
             mock.patch.object(probe.transport, 'BoundedReader',
                               side_effect=lambda port, timeout: reader(port, timeout, clock=lambda: port.now)):
            yield

    def run_fake(self, mode=0, proof=None, radio=None, port=None, **kwargs):
        port = helpers.FakePort() if port is None else port
        radio = FakeRadio(port) if radio is None else radio
        with self.transport():
            result = probe.execute(self.bundle, mode, 'FAKE', 123+mode, resume=True,
                                   radio_factory=lambda port: radio, port_factory=lambda name: port,
                                   proof=proof, **kwargs)
        return result, radio, port

    def smoke(self):
        result, radio, port = self.run_fake()
        return {'schema': probe.SCHEMA, 'dry_run': False, 'manifest': self.manifest, **result}, radio, port

    def assert_no_call(self, radio):
        self.assertFalse(any(operation[0] == 'call' for operation in radio.ops))

    def test_argument_layout_crc_and_nonce_bounds(self):
        raw = probe.make_args(123, 1)
        self.assertEqual(len(raw), 64)
        self.assertEqual(raw[:8], probe.ARG_MAGIC)
        self.assertEqual(struct.unpack_from('<5I', raw, 8), (123, 1, 24000000, 0x14030000, probe.BUILD_ID))
        self.assertEqual(raw[28:60], bytes(32))
        self.assertEqual(zlib.crc32(raw[:60]), struct.unpack_from('<I', raw, 60)[0])
        for nonce, mode in ((0, 0), (True, 0), (1, True), (1, 2), (0x100000000, 0)):
            with self.assertRaises(probe.ProbeError):
                probe.make_args(nonce, mode)

    def test_protocol_matches_target_header(self):
        header = (ROOT/'research/examples/hrc7000-clock-probe/probe_protocol.h').read_text()
        expected = {'CKP_BUILD_ID': probe.BUILD_ID, 'CKP_ENTRY': probe.ENTRY, 'CKP_ARGS': probe.ARGS,
                    'CKP_MAX_RECORDS': probe.MAX_RECORDS, 'CKP_LOOP_HASH': probe.LOOP_HASH,
                    'CKP_CTRL_OSC': probe.COLD_CLOCKS['CTRL'], 'CKP_CTRL_PLL': probe.COLD_CLOCKS['CTRL'] & ~8,
                    'CKP_BPLL': probe.COLD_CLOCKS['BPLL'], 'CKP_DIV': probe.COLD_CLOCKS['DIV']}
        for name, value in expected.items():
            match = re.search(r'^#define '+name+r' (0x[0-9a-fA-F]+|[0-9]+)u', header, re.M)
            self.assertIsNotNone(match, name)
            self.assertEqual(int(match.group(1), 0), value)
        self.assertEqual(probe.HEADER.size, 52)
        self.assertEqual(probe.RECORD.size, 32)
        oracle = 0x12345678
        for index in range(20000):
            oracle ^= (oracle << 5) & 0xffffffff
            oracle = (oracle+(index ^ 0x9e3779b9)) & 0xffffffff
        self.assertEqual(oracle, probe.LOOP_HASH)

    def test_manifest_hash_ranges_modes_and_extra_fields_refused(self):
        mutations = [lambda m: m.update(allowed_modes=[0, 1, 2]),
                     lambda m: m.update(allowed_modes=[False, True]),
                     lambda m: m.update(entry=0x10000), lambda m: m.update(clock=120000000),
                     lambda m: m['ranges'].update(scratch=[0x44000, 0x44080]),
                     lambda m: m['ranges'].update(stack=[0x46000, 0x47000]),
                     lambda m: m['image'].update(sha256='0'*64)]
        original = copy.deepcopy(self.manifest)
        for mutate in mutations:
            self.manifest = copy.deepcopy(original)
            mutate(self.manifest)
            self.save()
            with self.assertRaises(probe.ProbeError):
                probe.load_bundle(self.path)

    def test_smoke_only_writes_image_and_arguments_in_verified_chunks(self):
        result, radio, port = self.run_fake()
        self.assertTrue(result['monitor_returned'])
        self.assertTrue(port.closed)
        self.assertEqual([op for op in radio.ops if op[0] == 'call'], [('call', probe.ENTRY)])
        self.assertEqual([op for op in radio.ops if op[0] == 'configure'], [('configure', None)])
        writes = [op for op in radio.ops if op[0] == 'poke']
        self.assertEqual([len(op[2]) for op in writes], [512, 512, 176, 64])
        self.assertTrue(all(probe.ENTRY <= address < probe.ENTRY+len(self.image) or address == probe.ARGS
                            for _, address, _ in writes))
        self.assertEqual(result['clock_before'], result['clock_after'])
        self.assertEqual(result['host_mmio_write_operations_requested'], 0)
        self.assertEqual([op for op in radio.ops if op[0] == 'timer_hz'], [('timer_hz', 0.5)]*6)
        forbidden = {0x14030000, 0x14030014, 0x14000020}
        self.assertFalse(any(op[0] == 'peek' and op[1] in forbidden for op in radio.ops))

    def test_roundtrip_requires_exact_smoke_cookie_and_image(self):
        proof, old_radio, _ = self.smoke()
        port = helpers.FakePort()
        radio = FakeRadio(port)
        radio.memory = dict(old_radio.memory)
        result, radio, port = self.run_fake(1, proof, radio, port)
        self.assertTrue(result['monitor_returned'])
        self.assertEqual(result['clock_workload']['workload_hash'], probe.LOOP_HASH)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        self.assertTrue(port.closed)

    def test_stale_cookie_or_changed_image_refuses_before_write(self):
        proof, prior, _ = self.smoke()
        for address in (probe.ARGS, probe.ENTRY):
            port = helpers.FakePort()
            radio = FakeRadio(port)
            radio.memory = dict(prior.memory)
            radio.memory[address] ^= 1
            with self.assertRaises(probe.ProbeError):
                self.run_fake(1, proof, radio, port)
            self.assert_no_call(radio)
            self.assertFalse(any(op[0] == 'poke' for op in radio.ops))
            self.assertTrue(port.closed)

    def test_invalid_smoke_proofs_refuse_before_port_open(self):
        proof, _, _ = self.smoke()
        mutations = [lambda p: p.update(mode=True), lambda p: p.update(dry_run=True),
                     lambda p: p.update(monitor_returned=False), lambda p: p.update(raw_sha256='0'*64),
                     lambda p: p['manifest'].update(source_commit='b'*40),
                     lambda p: p['clock_after'].update(UART_IER=1),
                     lambda p: p.update(apb_hz_before=[84000000]*3)]
        for mutate in mutations:
            changed = copy.deepcopy(proof)
            mutate(changed)
            factory = mock.Mock()
            with self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 1, 'FAKE', 55, resume=True, proof=changed,
                              radio_factory=mock.Mock(), port_factory=factory)
            factory.assert_not_called()

    def test_explicit_resume_and_bounded_timeout_required_before_open(self):
        for changes in ({'resume':False}, {'timeout':31}, {'timeout':float('nan')}, {'mode':True}):
            options = dict(mode=0, name='FAKE', nonce=123, resume=True)
            options.update(changes)
            factory = mock.Mock()
            with self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, **options, radio_factory=mock.Mock(), port_factory=factory)
            factory.assert_not_called()

    def test_wrong_monitor_refused_before_profile_or_ram_writes(self):
        for key, value in (('board', 0), ('flags', 1), ('load', 0x44000), ('image', 8000),
                           ('stack_used', 4096), ('run', 0x31000)):
            port = helpers.FakePort()
            radio = FakeRadio(port)
            radio.v6[key] = value
            with self.assertRaises(probe.ProbeError):
                self.run_fake(radio=radio, port=port)
            self.assertFalse(any(op[0] in ('configure', 'poke', 'call') for op in radio.ops))
            self.assertTrue(port.closed)

    def test_wrong_cold_clock_or_fast_apb_refused_before_poke(self):
        for key in (*probe.COLD_CLOCKS, 'UART_LCR', 'UART_IER', 'TIMER2_LOAD', 'TIMER2_CTRL', 'APLL'):
            port = helpers.FakePort()
            radio = FakeRadio(port)
            radio.registers[key] ^= 0x40000000 if key == 'APLL' else 1
            with self.assertRaises(probe.ProbeError):
                self.run_fake(radio=radio, port=port)
            self.assert_no_call(radio)
            self.assertFalse(any(op[0] == 'poke' for op in radio.ops))
        for sample in (84000000, float('nan'), True, 0):
            port = helpers.FakePort()
            radio = FakeRadio(port)
            radio.samples[1] = sample
            with self.assertRaises(probe.ProbeError):
                self.run_fake(radio=radio, port=port)
            self.assert_no_call(radio)
            self.assertTrue(port.closed)

    def test_dlab_refuses_before_reading_ier(self):
        port = helpers.FakePort()
        radio = FakeRadio(port)
        radio.registers['UART_LCR'] |= 0x80
        with self.assertRaises(probe.ProbeError):
            self.run_fake(radio=radio, port=port)
        self.assertFalse(any(op[:2] == ('peek', probe.UART_REGISTERS['UART_IER']) for op in radio.ops))
        self.assert_no_call(radio)

    def test_measured_cold_uart_ier_80_required_and_zero_refused(self):
        probe.require_cold(snapshot())
        port = helpers.FakePort()
        radio = FakeRadio(port)
        radio.registers['UART_IER'] = 0
        with self.assertRaisesRegex(probe.ProbeError, 'preconditions'):
            self.run_fake(radio=radio, port=port)
        self.assertFalse(any(op[0] in ('poke', 'call') for op in radio.ops))
        self.assertTrue(port.closed)

    def test_readback_failure_refuses_call_and_closes(self):
        port = helpers.FakePort()
        radio = FakeRadio(port)
        radio.bad_readback = True
        with self.assertRaisesRegex(probe.ProbeError, 'readback'):
            self.run_fake(radio=radio, port=port)
        self.assert_no_call(radio)
        self.assertTrue(port.closed)

    def test_packet_crc_session_guards_count_ids_faults_refused(self):
        samples = [packet(mode=1, header={'nonce':42}), packet(mode=1, header={'fatal':1}),
                   packet(mode=1, header={'guard_mask':30}), packet(mode=1, header={'cpuid_words':1}),
                   packet(mode=1, header={'initial_psr':0x80000040}),
                   packet(mode=1, header={'record_count':25, 'total_bytes':856})]
        for field, value in (('id', 99), ('reserved', 1), ('status', 3), ('vector', 4)):
            recs = records(1)
            recs[1][field] = value
            samples.append(packet(mode=1, recs=recs))
        changed = bytearray(packet(mode=1))
        changed[-1] ^= 1
        samples.append(bytes(changed))
        for raw in samples:
            with self.assertRaises(probe.ProbeError):
                probe.parse_packet(raw, 123, 1, probe.ENTRY+len(self.image))

    def test_roundtrip_hash_restored_configuration_and_source_refused(self):
        for identifier, field in ((20, 'aux'), (21, 'value'), (23, 'value'),
                                  (23, 'aux'), (30, 'value'), (34, 'aux'), (37, 'aux')):
            recs = records(1)
            next(record for record in recs if record['id'] == identifier)[field] ^= 1 if identifier != 21 else 300000
            with self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=1, recs=recs), 123, 1, probe.ENTRY+len(self.image))
        # LSR/USR values legitimately differ across the transition.
        parsed = probe.parse_packet(packet(mode=1), 123, 1, probe.ENTRY+len(self.image))
        self.assertEqual(len(parsed['records']), 21)

    def test_result_failure_records_partial_raw_and_never_retries_call(self):
        port = helpers.FakePort()
        radio = FakeRadio(port)
        radio.modify_raw = lambda raw: raw[:-1]+bytes([raw[-1] ^ 1])
        with self.assertRaises(probe.ProbeError) as context:
            self.run_fake(radio=radio, port=port)
        error = context.exception
        self.assertTrue(error.monitor_returned)
        self.assertTrue(error.raw_hex)
        self.assertEqual(error.call_operations_requested, 1)
        self.assertEqual(error.clock_before, error.clock_after)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        self.assertTrue(port.closed)

    def test_guarded_target_fault_context_is_captured_and_fatal(self):
        recs = records(1)[:10]
        recs[-1].update(status=3, vector=4, epc=probe.ENTRY+4, epsr=0x80000000)
        with self.assertRaises(probe.ProbeError) as context:
            probe.parse_packet(packet(mode=1, recs=recs, header={'fatal':2}), 123, 1,
                               probe.ENTRY+len(self.image))
        self.assertEqual(context.exception.target_result['records'][-1]['epc'], probe.ENTRY+4)
        recs[-1]['epc'] = 0x03010000
        with self.assertRaisesRegex(probe.ProbeError, 'outside'):
            probe.parse_packet(packet(mode=1, recs=recs, header={'fatal':2}), 123, 1,
                               probe.ENTRY+len(self.image))

    def test_restoration_mismatch_or_no_hello_is_error_with_no_recovery_writes(self):
        for failure in ('clock', 'uart', 'apb', 'monitor'):
            port = helpers.FakePort()
            radio = FakeRadio(port)
            if failure == 'clock':
                radio.after_call = lambda: radio.registers.update(CTRL=0xc0000004)
            elif failure == 'uart':
                radio.after_call = lambda: radio.registers.update(UART_MCR=1)
            elif failure == 'apb':
                radio.samples[4] = 60000000
            else:
                radio.fail_return = True
            with self.assertRaises((probe.ProbeError, OSError)):
                self.run_fake(radio=radio, port=port)
            self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
            self.assertEqual(sum(op[0] == 'poke' for op in radio.ops), 4)
            self.assertTrue(port.closed)

    def test_timeout_is_bounded_and_does_not_recall(self):
        port = helpers.FakePort()
        radio = FakeRadio(port)
        radio.modify_raw = lambda raw: raw[:8]
        with self.assertRaisesRegex(probe.ProbeError, 'timed out') as context:
            self.run_fake(radio=radio, port=port, timeout=0.1)
        self.assertEqual(context.exception.raw_hex, probe.MAGIC.hex())
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        self.assertTrue(port.closed)

    def test_exact_write_whitelist_refuses_mmio_and_partial_spans(self):
        radio = FakeRadio(helpers.FakePort())
        allowed = {(probe.ENTRY, probe.ENTRY+len(self.image)), (probe.ARGS, probe.ARGS+64)}
        for address, raw in ((0x11000004, bytes(4)), (probe.ENTRY+4, self.image[4:]),
                              (probe.ARGS, bytes(65)), (probe.ARGS, b'')):
            with self.assertRaises(probe.ProbeError):
                probe.write_verified(radio, address, raw, allowed)
        self.assertFalse(radio.ops)

    def test_cli_dry_run_never_loads_serial_transport(self):
        with mock.patch.object(sys, 'argv', ['hrc7000-clock.py', '--manifest', str(self.path)]), \
             mock.patch.object(probe.transport, 'load_stub') as loader, contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(probe.main(), 0)
        loader.assert_not_called()
        report = json.loads(output.getvalue())
        self.assertTrue(report['dry_run'])
        self.assertFalse(report['serial_opened'])

    def test_cli_missing_resume_fails_without_serial(self):
        with mock.patch.object(sys, 'argv', ['hrc7000-clock.py', '--manifest', str(self.path), '--execute', '--port', 'FAKE']), \
             mock.patch.object(probe.transport, 'load_stub') as loader, contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(probe.main(), 1)
        loader.assert_not_called()
        self.assertFalse(json.loads(output.getvalue())['serial_opened'])


if __name__ == '__main__':
    unittest.main()
