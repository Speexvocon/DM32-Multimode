# SPDX-License-Identifier: GPL-3.0-or-later
"""Postdecode-only opaque-payload matching fixtures; no DSP or devices."""
import copy
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


M = load("origin_match_test", ROOT / "scripts/match-p25-rx-origin.py")
F = load("origin_wire_fixtures", ROOT / "tests/test_p25_rx_origin_analyzer.py")


def paired_reports(units=3, blocks=1, *, initial_loss=False, partial_first=False,
                   epoch_change_at=None, shared_payload=False):
    events, frames = [], []
    tick, epoch = 600, 1
    if initial_loss:
        events.append(F.fault(1, cpu=100000))
    for index in range(units):
        if index == epoch_change_at:
            epoch += 1
        values = [3] + [2] * (M.COUNTS[blocks] - 1)
        ticks = [tick + 360 * j for j in range(len(values))]
        for j, (stamp, value) in enumerate(zip(ticks, values)):
            if partial_first and index == 0 and j == 0:
                continue
            events.append(F.event(tick=stamp, ordinal=stamp // 6 + 8,
                                  status=value, lane_epoch=epoch))
        ordinal = ticks[-1] // 6 + 24
        payload = [bytes([0x80 if j == blocks - 1 else 0, j, 0, 0,
                          0 if shared_payload else index, 97, 98, 99, 100, 101, 102, 103])
                   for j in range(blocks)]
        for j, data in enumerate(payload):
            events.append(F.unit(ordinal=ordinal, lane_epoch=epoch,
                                 descriptor=(blocks << 4) | j, data=data))
        first_end = 10000 + 50 * ticks[0]
        start = first_end - 36 * 500
        last_logical = 56 + blocks * 98 - 1
        prefix = start + (last_logical + last_logical // 35 + 1) * 500
        frames.append(dict(sync_start_raw_sample=start, crc_prefix_end_raw_sample=prefix,
            samples_per_symbol_48k=10.0, nac="293", duid=7,
            acquisition_uses_expected_payload=False, crc_qualified=True,
            payload_blocks=[data.hex() for data in payload], native_crc_block_count=blocks,
            crc_identity_hypotheses=1, crc_payload_hypotheses=1, partial_payload_ambiguous=False,
            crc_prefix_envelope_complete=True, full_padded_unit_observed=True,
            status_symbols=[dict(physical_dibit=35 + 36 * j, value=value,
                end_raw_sample=10000 + 50 * stamp, nid_qualified=True,
                crc_unit_qualified=True, status_bits_protected=False)
                for j, (stamp, value) in enumerate(zip(ticks, values))]))
        tick += len(values) * 360
    rx = M.origin.parse_trace(F.capture(events, samples=8192))
    iq = dict(capture_sha256="b" * 64, analyzer_sha256="c" * 64,
        input_samples=frames[-1]["status_symbols"][-1]["end_raw_sample"] + 10000,
        no_cu8_rail_clipping_observed=True,
        profile=dict(input_rate_hz=2400000, output_rate_hz=48000, center_hz=440575000,
            channels_hz={"control": 440075000, "uplink": 441075000}, decimation_numerator=1,
            decimation_denominator=50, fir_taps=2001, fir_delay_raw_samples=1000,
            discriminator_midpoint_raw_samples=25, matched_average_samples_48k=10,
            demod_center_raw_formula="(index+5)*50-1000", nco_uses_global_input_index=True),
        channels=dict(control=dict(candidate_limit_reached=False, frames=frames), uplink=dict(frames=[])))
    return rx, iq


class OriginMatchingTests(unittest.TestCase):
    def test_unique_opaque_identity_pairs_statuses_and_fits_only_informationally(self):
        rx, iq = paired_reports()
        result = M.match_reports(rx, iq)
        self.assertEqual(result["matched_unit_count"], 3)
        self.assertEqual(result["paired_status_count"], 15)
        fit = result["segment_fits"][0]["fit"]
        self.assertTrue(fit["available"])
        self.assertAlmostEqual(fit["raw_sample_A"], 10000)
        self.assertAlmostEqual(fit["raw_samples_per_rx_tick_B"], 50)
        self.assertLess(fit["residual_max_abs_raw_samples"], 1e-8)
        for key in M.FLAGS:
            self.assertIs(result[key], False)
            self.assertIs(fit[key], False)
        self.assertFalse(result["expected_payload_used_for_acquisition"])
        self.assertTrue(all(not row["unit_tick_used_as_air_end"] for row in result["matched_units"]))
        self.assertIn("rx_callback_cpu_us", result["matched_units"][0]["pairs"][0])
        self.assertNotEqual(result["matched_units"][0]["pairs"][-1]["rx_original_status_tick"],
                            rx["captures"][0]["event_observations"]["native_units"][0]["delivery_input_ordinal"] * 6)

    def test_geometry_for_one_two_and_three_crc_blocks(self):
        for blocks, count in ((1, 5), (2, 8), (3, 10)):
            with self.subTest(blocks=blocks):
                rx, iq = paired_reports(blocks=blocks)
                result = M.match_reports(rx, iq)
                self.assertEqual(result["matched_unit_count"], 3)
                self.assertEqual(result["paired_status_count"], count * 3)

    def test_incomplete_first_unit_is_refused_without_poisoning_later_groups(self):
        rx, iq = paired_reports(units=4, initial_loss=True, partial_first=True)
        result = M.match_reports(rx, iq)
        self.assertEqual(result["matched_unit_count"], 3)
        self.assertIn("incomplete_or_excess_rx_status_group", result["refused_units"][0]["reasons"])
        self.assertEqual(result["segment_fits"][0]["rx_segment"], 1)
        self.assertFalse(rx["all_streams_coherent"])
        self.assertTrue(rx["all_producers_coherent"])

    def test_fits_do_not_cross_epoch_segments_to_reach_minimum_count(self):
        rx, iq = paired_reports(units=4, epoch_change_at=2)
        result = M.match_reports(rx, iq)
        self.assertEqual(result["matched_unit_count"], 4)
        self.assertEqual(len(result["segment_fits"]), 2)
        self.assertTrue(all(not row["fit"]["available"] for row in result["segment_fits"]))

    def test_fewer_than_three_units_cannot_fit_even_with_many_pairs(self):
        rx, iq = paired_reports(units=2, blocks=3)
        result = M.match_reports(rx, iq)
        self.assertEqual(result["paired_status_count"], 20)
        self.assertFalse(result["segment_fits"][0]["fit"]["available"])

    def test_duplicate_payload_in_either_dataset_is_refused_without_timing_selection(self):
        rx, iq = paired_reports(shared_payload=True)
        result = M.match_reports(rx, iq)
        self.assertEqual(result["matched_unit_count"], 0)
        self.assertTrue(all("opaque_native_payload_identity_not_one_to_one" in row["reasons"]
                            for row in result["refused_units"]))
        rx, iq = paired_reports()
        duplicate = copy.deepcopy(iq["channels"]["control"]["frames"][0])
        delta = iq["input_samples"]
        duplicate["sync_start_raw_sample"] += delta
        duplicate["crc_prefix_end_raw_sample"] += delta
        for status in duplicate["status_symbols"]: status["end_raw_sample"] += delta
        iq["input_samples"] += delta
        iq["channels"]["control"]["frames"].append(duplicate)
        result = M.match_reports(rx, iq)
        self.assertEqual(result["matched_unit_count"], 2)
        self.assertIn("opaque_native_payload_identity_not_one_to_one", result["refused_units"][0]["reasons"])

    def test_native_crc_and_full_padded_local_power_are_required(self):
        for field, value in (("crc_prefix_envelope_complete", False),
                             ("full_padded_unit_observed", False),
                             ("payload_ambiguous", True),
                             ("crc_identity_hypotheses", 2)):
            rx, iq = paired_reports()
            iq["channels"]["control"]["frames"][0][field] = value
            result = M.match_reports(rx, iq)
            self.assertEqual(result["matched_unit_count"], 2)
        rx, iq = paired_reports()
        iq["channels"]["control"]["frames"][0]["crc_qualified"] = False
        result = M.match_reports(rx, iq)
        self.assertIn("no_independently_decoded_iq_identity", result["refused_units"][0]["reasons"])

    def test_missing_or_different_status_is_not_filled_by_a_template(self):
        rx, iq = paired_reports()
        iq["channels"]["control"]["frames"][0]["status_symbols"].pop()
        self.assertEqual(M.match_reports(rx, iq)["matched_unit_count"], 2)
        rx, iq = paired_reports()
        iq["channels"]["control"]["frames"][0]["status_symbols"][0]["value"] = 1
        self.assertIn("received_status_values_disagree", M.match_reports(rx, iq)["refused_units"][0]["reasons"])

    def test_native_origin_evidence_is_revalidated_not_trusted(self):
        for mutate in (lambda r: r.update(all_producers_coherent=False),
                       lambda r: r.update(schema="other"),
                       lambda r: r["captures"][0]["events"][0].update(index=999),
                       lambda r: r["captures"][0]["events"][0].update(segment_index=999),
                       lambda r: r["captures"][0]["halves"][0].update(published_hash="00000000"),
                       lambda r: r["captures"][0]["header"].update(carrier_hz=440087500),
                       lambda r: r["captures"][0]["header"].update(extra=1)):
            rx, iq = paired_reports(); mutate(rx)
            with self.assertRaises((M.MatchError, M.origin.OriginError)): M.match_reports(rx, iq)

    def test_iq_profile_coverage_bounds_and_indices_are_strict(self):
        mutations = [lambda r: r.update(schema="other"),
                     lambda r: r["profile"].update(center_hz=441575000),
                     lambda r: r.update(no_cu8_rail_clipping_observed=False),
                     lambda r: r["channels"]["control"].update(candidate_limit_reached=True),
                     lambda r: r["channels"]["control"]["frames"][0].update(acquisition_uses_expected_payload=True),
                     lambda r: r["channels"]["control"]["frames"][0]["status_symbols"][1].update(physical_dibit=35),
                     lambda r: r["channels"]["control"]["frames"][0]["status_symbols"][0].update(end_raw_sample=1),
                     lambda r: r["channels"]["control"]["frames"][0]["status_symbols"][0].update(extra=1),
                     lambda r: r["profile"].update(nco_uses_global_input_index=1),
                     lambda r: r["channels"]["control"]["frames"][0].update(native_crc_block_count=True),
                     lambda r: r["channels"]["control"]["frames"][0].update(crc_identity_hypotheses=True),
                     lambda r: r["channels"]["control"]["frames"][0].update(samples_per_symbol_48k=float("nan"))]
        for mutate in mutations:
            rx, iq = paired_reports(); mutate(iq)
            with self.assertRaises(M.MatchError): M.match_reports(rx, iq)

    def test_cli_provenance_refusal_and_duplicate_json_keys(self):
        rx, iq = paired_reports()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory); a, b, out = path / "origin.json", path / "iq.json", path / "result.json"
            a.write_text(json.dumps(rx)); b.write_text(json.dumps(iq))
            self.assertEqual(M.main([str(a), str(b), "--output", str(out)]), 0)
            result = json.loads(out.read_text())
            self.assertEqual(result["input_json_provenance"]["origin"]["bytes"], a.stat().st_size)
            self.assertEqual(len(result["input_json_provenance"]["matcher_sha256"]), 64)
            b.write_text('{"a":1,"a":2}')
            with redirect_stderr(io.StringIO()): self.assertEqual(M.main([str(a), str(b)]), 2)
            b.write_text('{"value":NaN}')
            with redirect_stderr(io.StringIO()): self.assertEqual(M.main([str(a), str(b)]), 2)
            a.write_text(json.dumps(paired_reports(shared_payload=True)[0]))
            b.write_text(json.dumps(paired_reports(shared_payload=True)[1]))
            with redirect_stdout(io.StringIO()): self.assertEqual(M.main([str(a), str(b)]), 1)


if __name__ == "__main__":
    unittest.main()
