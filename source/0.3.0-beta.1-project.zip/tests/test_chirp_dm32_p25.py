#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline CHIRP integration tests using pinned official CHIRP, never serial.

Prepare dependency with the commands in integrations/chirp/README.md. No wx UI,
stock radio driver, EEPROM fixture or target hardware is needed.
"""
import argparse
import ctypes
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CHIRP_COMMIT = "d3d4d51971b65bab60ab3cfa5839300309d2add4"
parser = argparse.ArgumentParser()
parser.add_argument("--chirp-source", type=Path, default=ROOT / "external/chirp")
parser.add_argument("--adapter-library", type=Path,
                    help="Required real firmware parser/storage bridge built by scripts/test-chirp.ps1")
options, unittest_args = parser.parse_known_args()
source = options.chirp_source.resolve()
if not (source / "chirp/chirp_common.py").is_file():
    raise SystemExit("Pinned official CHIRP source missing; see integrations/chirp/README.md")
head = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
if head != CHIRP_COMMIT:
    raise SystemExit("CHIRP checkout is not the qualified pinned commit " + CHIRP_COMMIT)
source_hashes = {}
for name in ("chirp/chirp_common.py", "chirp/settings.py", "chirp/memmap.py", "chirp/directory.py"):
    expected = subprocess.check_output(["git", "-C", str(source), "show", "HEAD:" + name])
    actual = (source / name).read_bytes().replace(b"\r\n", b"\n")
    if actual != expected:
        raise SystemExit("Modified CHIRP dependency: " + name)
    source_hashes[name] = hashlib.sha256(expected).hexdigest()
sys.path.insert(0, str(source))
from chirp import chirp_common, errors, memmap  # noqa: E402

spec = importlib.util.spec_from_file_location("dm32_p25", ROOT / "integrations/chirp/dm32_p25.py")
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


def channel(rx=145700000, tx=None, name="LOCAL P25", flags=1, nac=0x293, tg=10, scans=1):
    raw = bytearray(32)
    struct.pack_into("<IIHHBB", raw, 0, rx, rx if tx is None else tx, nac, tg, flags, scans)
    raw[14:14 + len(name)] = name.encode("ascii")
    raw[30] = 5
    return bytes(raw)


def payload():
    raw = bytearray(driver.PAYLOAD_SIZE)
    raw[:32] = channel(name="MAXIMUM P25", nac=0xFFF, tg=65535)
    raw[32:64] = channel(440075000, 445075000, "REPEATER", flags=1 | 4, scans=15)
    raw[32 * 32:33 * 32] = channel(name="VFO A")
    raw[33 * 32:34 * 32] = channel(440075000, name="VFO B")
    global_record = bytearray(32)
    struct.pack_into("<IBHH", global_record, 0, 1234567, 22, 60, 15)
    raw[34 * 32:] = global_record
    return bytes(raw)


class FakePipe:
    """Logical CPS peer: records traffic and exposes the atomic publish point."""
    def __init__(self, data=None):
        self.active = payload() if data is None else data
        self.revision = 7
        self.timeout = None
        self.pending = bytearray()
        self.requests = []
        self.stage = self.transaction = None
        self.snapshots = []
        self.put_error = None
        self.busy = False
        self.commit_drop_reply = False
        self.override = None
        self.read_calls = 0

    def reset_input_buffer(self):
        self.pending.clear()

    def write(self, request):
        assert len(request) <= driver.MAX_LINE
        assert request.endswith(b"\r\n")
        text = request[:-2].decode("ascii")
        self.requests.append(text)
        parts = text.split(" ")
        response = self.handle(parts)
        if self.override:
            response = self.override(text, response)
        self.pending.extend(response if isinstance(response, bytes) else (response + "\r\n").encode("ascii"))
        return len(request)

    def handle(self, parts):
        if parts == ["CPS", "HELLO"]:
            return "CPS HELLO DM32P25 1 32 2 %d %08X" % (self.revision, driver._crc(self.active))
        if parts[:2] == ["CPS", "GET"]:
            index = int(parts[2])
            return "CPS DATA %d %s" % (index, driver._record(self.active, index).hex().upper())
        if self.busy:
            return "CPS ERR BUSY"
        if parts[:2] == ["CPS", "BEGIN"]:
            if int(parts[3]) != self.revision:
                return "CPS ERR STALE"
            self.transaction = parts[2]
            self.stage = bytearray(self.active)
            return "CPS OK BEGIN " + self.transaction
        if len(parts) < 3 or self.stage is None or parts[2] != self.transaction:
            return "CPS ERR TRANSACTION"
        if parts[1] == "PUT":
            index = int(parts[3])
            self.snapshots.append(self.active)
            if index == self.put_error:
                return "CPS ERR BUSY"
            self.stage[index * 32:(index + 1) * 32] = bytes.fromhex(parts[4])
            return "CPS OK PUT %s %d" % (self.transaction, index)
        if parts[1] == "COMMIT":
            checksum = driver._crc(self.stage)
            if checksum != int(parts[3], 16):
                return "CPS ERR CRC"
            driver.validate_payload(self.stage)
            self.active = bytes(self.stage)
            self.revision = (self.revision + 1) & 0xFFFFFFFF
            self.stage = None
            if self.commit_drop_reply:
                return b""
            return "CPS OK COMMIT %s %d %08X" % (self.transaction, self.revision, checksum)
        if parts[1] == "ABORT":
            self.stage = None
            return "CPS OK ABORT " + self.transaction
        return "CPS ERR SYNTAX"

    def read(self, size):
        assert size == 1
        self.read_calls += 1
        if not self.pending:
            return b""
        return bytes([self.pending.pop(0)])


def radio(peer=None):
    peer = FakePipe() if peer is None else peer
    result = driver.DM32P25Radio(peer)
    result.status_fn = lambda status: None
    result.sync_in()
    return result, peer


def changed_radio():
    result, peer = radio()
    memory = result.get_memory(1)
    memory.name = "EDITED P25"
    result.set_memory(memory)
    return result, peer


class IntegrationTests(unittest.TestCase):
    def test_features_use_native_p25_and_special_vfos(self):
        features = driver.DM32P25Radio(None).get_features()
        self.assertIn("P25", chirp_common.MODES)
        self.assertEqual(features.valid_modes, ["P25", "FM", "NFM"])
        self.assertEqual(features.memory_bounds, (1, 32))
        self.assertEqual(features.valid_special_chans, ["VFO A", "VFO B"])

    def test_read_is_snapshot_and_checksum_qualified(self):
        result, peer = radio()
        self.assertEqual(result._payload(), payload())
        self.assertEqual(peer.requests.count("CPS HELLO"), 2)
        self.assertEqual(len(peer.requests), 37)
        self.assertFalse(any("BEGIN" in request for request in peer.requests))

    def test_max_p25_fields_roundtrip_without_read_mutation(self):
        result, _ = radio()
        before = result._mmap.get_packed()
        memory = result.get_memory(1)
        self.assertEqual(memory.mode, "P25")
        self.assertEqual(str(memory.extra["nac"].value), "FFF")
        self.assertEqual(int(memory.extra["talkgroup"].value), 65535)
        result.get_settings()
        self.assertEqual(result._mmap.get_packed(), before)
        result.set_memory(memory)
        self.assertEqual(result._mmap.get_packed(), before)

    def test_fm_cross_tones_inverse_dcs_and_bandwidth(self):
        result, _ = radio()
        memory = result.get_memory(2)
        memory.mode, memory.tmode, memory.cross_mode = "NFM", "Cross", "Tone->DTCS"
        memory.rtone, memory.rx_dtcs, memory.dtcs_polarity = 88.5, 23, "NR"
        result.set_memory(memory)
        raw = result._get_record(1)
        self.assertEqual(struct.unpack_from("<HH", raw, 26), (0x4000 | 885, 0xC000 | 19))
        reloaded = result.get_memory(2)
        self.assertEqual((reloaded.cross_mode, reloaded.rtone, reloaded.rx_dtcs, reloaded.dtcs_polarity),
                         ("Tone->DTCS", 88.5, 23, "NR"))
        reloaded.mode = "FM"
        result.set_memory(reloaded)
        self.assertTrue(result._get_record(1)[12] & 0x20)

    def test_p25_rejects_analog_tones(self):
        result, _ = radio()
        memory = result.get_memory(1)
        memory.tmode, memory.rtone = "Tone", 88.5
        with self.assertRaises(errors.InvalidDataError):
            result.set_memory(memory)

    def test_full_length_ascii_name_and_filter_roundtrip(self):
        result, _ = radio()
        memory = result.get_memory(1)
        memory.name = "CHIRP-12CHAR"
        memory.extra["nac"].value = "2a3"
        memory.extra["filter"].value = "NAC + TG"
        result.set_memory(memory)
        self.assertEqual(result._get_record(0)[14:26], b"CHIRP-12CHAR")
        loaded = result.get_memory(1)
        self.assertEqual(loaded.name, memory.name)
        self.assertEqual(str(loaded.extra["nac"].value), "2A3")
        self.assertEqual(str(loaded.extra["filter"].value), "NAC + TG")

    def test_rx_only_and_odd_split(self):
        result, _ = radio()
        memory = result.get_memory(2)
        self.assertEqual((memory.duplex, memory.offset), ("split", 445075000))
        memory.duplex, memory.offset = "+", 5000000
        result.set_memory(memory)
        self.assertEqual(result.get_memory(2).offset, 445075000)
        memory.duplex = "off"
        result.set_memory(memory)
        self.assertEqual(result.get_memory(2).duplex, "off")

    def test_empty_memories_are_canonical_zeros(self):
        result, _ = radio()
        memory = result.get_memory(2)
        memory.empty = True
        result.set_memory(memory)
        self.assertEqual(result._get_record(1), bytes(32))
        self.assertTrue(result.get_memory(2).empty)

    def test_special_vfos(self):
        result, _ = radio()
        self.assertEqual(result.get_memory("VFO A").number, -1)
        self.assertEqual(result.get_memory(-2).extd_number, "VFO B")
        memory = result.get_memory("VFO B")
        memory.freq, memory.duplex = 441000000, ""
        result.set_memory(memory)
        self.assertEqual(result.get_memory("VFO B").freq, 441000000)

    def test_four_overlapping_scan_banks_and_extras(self):
        result, _ = radio()
        model = result.get_bank_model()
        memory = result.get_memory(1)
        self.assertEqual(len(model.get_memory_mappings(memory)), 1)
        model.add_memory_to_mapping(memory, model.get_mappings()[3])
        self.assertEqual([b.get_index() for b in model.get_memory_mappings(memory)], [0, 3])
        memory = result.get_memory(1)
        self.assertTrue(bool(memory.extra["scan3"].value))
        model.remove_memory_from_mapping(memory, model.get_mappings()[0])
        self.assertEqual(result._get_record(0)[13], 8)

    def test_settings_roundtrip_global_and_vfo_selection(self):
        result, _ = radio()
        settings = result.get_settings()
        settings["general"]["source_id"].value = 0xFFFFFF
        settings["general"]["mic_db"].value = 42
        settings["general"]["screen_sec"].value = 600
        settings["general"]["keypad_sec"].value = 0
        settings["general"]["tx_inhibit"].value = True
        settings["vfo"]["active_vfo"].value = "B"
        settings["vfo"]["selected_b"].value = "Memory 2"
        result.set_settings(settings)
        raw = result._get_record(34)
        self.assertEqual(struct.unpack_from("<IBHH", raw), (0xFFFFFF, 42, 600, 0))
        self.assertEqual(raw[9:14], bytes([1, 0, 2, 0, 1]))

    def test_saved_chirp_image_preserves_origin_metadata(self):
        result, _ = radio()
        with tempfile.TemporaryDirectory() as temporary:
            path = str(Path(temporary) / "profile.img")
            result.save(path)
            loaded = driver.DM32P25Radio(path)
        self.assertEqual(loaded._payload(), result._payload())
        self.assertEqual(loaded._metadata["dm32p25_revision"], 7)

    def test_atomic_upload_publishes_only_at_single_commit(self):
        result, peer = changed_radio()
        before = peer.active
        result.sync_out()
        self.assertEqual(peer.snapshots, [before] * 35)
        self.assertEqual(peer.active, result._payload())
        self.assertEqual(sum(request.startswith("CPS COMMIT ") for request in peer.requests), 1)
        self.assertEqual(peer.revision, 8)
        self.assertEqual(peer.requests[-1], "CPS HELLO")

    def test_unchanged_upload_does_not_write(self):
        result, peer = radio()
        peer.requests.clear()
        result.sync_out()
        self.assertEqual(peer.requests, ["CPS HELLO"])

    def test_wrong_identity_and_versions_refuse_without_writes(self):
        for replacement in ("STOCK-DM32", "DM32P25 2", "DM32P25 1 99"):
            peer = FakePipe()
            peer.override = lambda text, response: response.replace("DM32P25 1 32", replacement)
            result = driver.DM32P25Radio(peer)
            with self.subTest(replacement=replacement), self.assertRaises(errors.RadioError):
                result.sync_in()
            self.assertEqual(peer.requests, ["CPS HELLO"])

    def test_stale_upload_refuses_before_begin(self):
        result, peer = changed_radio()
        peer.revision += 1
        with self.assertRaisesRegex(errors.RadioError, "Stale"):
            result.sync_out()
        self.assertFalse(any(request.startswith("CPS BEGIN") for request in peer.requests))

    def test_busy_ptt_refuses_begin(self):
        result, peer = changed_radio()
        peer.busy = True
        with self.assertRaisesRegex(errors.RadioError, "BUSY"):
            result.sync_out()
        self.assertFalse(any(request.startswith("CPS PUT") for request in peer.requests))

    def test_ptt_during_staging_aborts_without_commit(self):
        result, peer = changed_radio()
        before = peer.active
        peer.put_error = 9
        with self.assertRaisesRegex(errors.RadioError, "BUSY"):
            result.sync_out()
        self.assertEqual(peer.active, before)
        self.assertIsNone(peer.stage)
        self.assertFalse(any(request.startswith("CPS COMMIT") for request in peer.requests))
        self.assertTrue(peer.requests[-1].startswith("CPS ABORT "))

    def test_bad_download_checksum(self):
        peer = FakePipe()
        peer.override = lambda text, response: re.sub(r" [0-9A-F]{8}$", " 00000000", response) if text == "CPS HELLO" else response
        with self.assertRaisesRegex(errors.RadioError, "checksum"):
            radio(peer)

    def test_changed_download_revision(self):
        peer = FakePipe()
        def mutate(text, response):
            if text == "CPS GET 34":
                peer.revision += 1
            return response
        peer.override = mutate
        with self.assertRaisesRegex(errors.RadioError, "changed"):
            radio(peer)

    def test_malformed_and_overlong_lines_are_bounded(self):
        for malformed in (b"X" * 121, b"CPS HELLO truncated", b"\xff\n", b""):
            peer = FakePipe()
            peer.override = lambda text, response: malformed
            with self.subTest(malformed=malformed[:16]), self.assertRaises(errors.RadioError):
                radio(peer)
            self.assertLessEqual(peer.read_calls, driver.MAX_LINE)
            self.assertEqual(peer.requests, ["CPS HELLO"])

    def test_commit_ack_loss_is_not_retried(self):
        result, peer = changed_radio()
        peer.commit_drop_reply = True
        with self.assertRaises(errors.RadioError):
            result.sync_out()
        self.assertEqual(peer.active, result._payload())
        self.assertEqual(sum(request.startswith("CPS COMMIT") for request in peer.requests), 1)
        with self.assertRaisesRegex(errors.RadioError, "Stale"):
            result.sync_out()

    def test_wrong_put_ack_aborts(self):
        result, peer = changed_radio()
        before = peer.active
        peer.override = lambda text, response: response + " WRONG" if text.startswith("CPS PUT") else response
        with self.assertRaisesRegex(errors.RadioError, "PUT"):
            result.sync_out()
        self.assertEqual(peer.active, before)
        self.assertFalse(any(request.startswith("CPS COMMIT") for request in peer.requests))

    def test_selected_empty_channel_rejected_before_serial(self):
        result, peer = changed_radio()
        settings = result.get_settings()
        settings["vfo"]["selected_a"].value = "Memory 32"
        result.set_settings(settings)
        peer.requests.clear()
        with self.assertRaisesRegex(errors.InvalidDataError, "empty"):
            result.sync_out()
        self.assertEqual(peer.requests, [])

    def test_invalid_channel_bytes_and_global_fields(self):
        mutations = [(31, 1), (12, 0xC1), (12, 13), (13, 16), (30, 10),
                     (14, 1), (14, 0), (26, 1), (34 * 32 + 14, 1)]
        for index, value in mutations:
            data = bytearray(payload())
            data[index] = value
            with self.subTest(index=index, value=value), self.assertRaises(errors.InvalidDataError):
                driver.validate_payload(data)

    def test_stock_or_wrong_size_images_refused(self):
        for raw in (bytes(1136), driver.IMAGE_HEADER + payload()[:-1], b"STOCK-DM32" + payload()):
            with self.assertRaises(errors.InvalidDataError):
                driver.DM32P25Radio(memmap.MemoryMapBytes(raw))

    def test_requests_are_only_bounded_cps_operations(self):
        result, peer = changed_radio()
        result.sync_out()
        for request in peer.requests:
            self.assertLessEqual(len(request.encode("ascii")) + 2, 120)
            self.assertRegex(request, r"^CPS (HELLO|GET|BEGIN|PUT|COMMIT|ABORT)( |$)")


class ActualFirmwarePipe:
    """Byte transport adapter around the unmodified production C command path."""
    def __init__(self, library):
        self.library = library
        self.pending = bytearray()
        self.timeout = None
        self.requests = []
        self.down = 0
        self.raw_released = 1
        assert self.library.cps_test_initialize() == 1

    def reset_input_buffer(self):
        self.pending.clear()

    def command(self, command):
        output = ctypes.create_string_buffer(8192)
        count = self.library.cps_test_command(command.encode("ascii"), self.down,
                                              self.raw_released, output, len(output))
        if count < 0:
            raise AssertionError("C parser bridge rejected test input")
        return output.raw[:count]

    def write(self, request):
        assert request.endswith(b"\r\n") and len(request) <= 120
        command = request[:-2].decode("ascii")
        self.requests.append(command)
        self.pending.extend(self.command(command))
        return len(request)

    def read(self, count):
        assert count == 1
        return bytes([self.pending.pop(0)]) if self.pending else b""

    def snapshot(self):
        out = (ctypes.c_ubyte * 1120)()
        assert self.library.cps_test_copy_active(out, len(out)) == len(out)
        return bytes(out)


class ActualFirmwareTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.library = ctypes.CDLL(str(options.adapter_library.resolve()))
        cls.library.cps_test_command.argtypes = (ctypes.c_char_p, ctypes.c_int, ctypes.c_int,
                                                 ctypes.c_void_p, ctypes.c_uint)
        cls.library.cps_test_copy_active.argtypes = (ctypes.c_void_p, ctypes.c_uint)
        cls.library.cps_test_record_valid.argtypes = (ctypes.c_uint, ctypes.c_void_p)

    def setUp(self):
        self.peer = ActualFirmwarePipe(self.library)
        self.radio = driver.DM32P25Radio(self.peer)
        self.radio.status_fn = lambda status: None
        self.radio.sync_in()

    def test_real_download_matches_canonical_storage_and_crc(self):
        self.assertEqual(self.radio._payload(), self.peer.snapshot())
        self.assertEqual(driver._crc(self.peer.snapshot()), self.radio._metadata["dm32p25_download_crc"])

    def test_real_chirp_upload_and_power_cycle(self):
        memory = chirp_common.Memory(1, name="CHIRP P25")
        memory.freq, memory.mode, memory.duplex = 440075000, "P25", ""
        self.radio.set_memory(memory)
        memory = chirp_common.Memory(2, name="CHIRP FM")
        memory.freq, memory.mode, memory.duplex = 433500000, "NFM", ""
        memory.tmode, memory.cross_mode = "Cross", "Tone->DTCS"
        memory.rtone, memory.rx_dtcs, memory.dtcs_polarity = 88.5, 23, "NR"
        self.radio.set_memory(memory)
        settings = self.radio.get_settings()
        settings["general"]["source_id"].value = 16777215
        settings["general"]["mic_db"].value = 24
        settings["general"]["screen_sec"].value = 600
        settings["general"]["keypad_sec"].value = 0
        settings["vfo"]["selected_a"].value = "Memory 1"
        self.radio.set_settings(settings)
        expected = self.radio._payload()
        self.radio.sync_out()
        self.assertEqual(self.peer.snapshot(), expected)
        self.assertEqual(self.library.cps_test_reboot(), 1)
        self.radio.sync_in()
        self.assertEqual(self.radio._payload(), expected)
        self.assertEqual(self.radio.get_memory(2).rx_dtcs, 23)

    def test_real_interrupted_staging_and_abort_keep_old_snapshot(self):
        before = self.peer.snapshot()
        revision = self.radio._metadata["dm32p25_revision"]
        self.assertEqual(self.peer.command("CPS BEGIN 11223344 %d" % revision), b"CPS OK BEGIN 11223344\r\n")
        record = channel(440075000, name="STAGED ONLY")
        self.assertEqual(self.peer.command("CPS PUT 11223344 0 " + record.hex().upper()), b"CPS OK PUT 11223344 0\r\n")
        self.assertEqual(self.peer.snapshot(), before)
        self.assertEqual(self.library.cps_test_reboot(), 1)
        self.assertEqual(self.peer.snapshot(), before)
        self.radio.sync_in()
        revision = self.radio._metadata["dm32p25_revision"]
        self.peer.command("CPS BEGIN 11223344 %d" % revision)
        self.peer.command("CPS PUT 11223344 0 " + record.hex().upper())
        self.assertEqual(self.peer.command("CPS ABORT 11223344"), b"CPS OK ABORT 11223344\r\n")
        self.assertEqual(self.peer.snapshot(), before)

    def test_real_ptt_and_wrong_revision_refuse(self):
        before = self.peer.snapshot()
        for down, raw in ((1, 1), (0, 0)):
            self.peer.down, self.peer.raw_released = down, raw
            with self.assertRaisesRegex(errors.RadioError, "BUSY"):
                self.radio.sync_in()
        self.peer.down, self.peer.raw_released = 0, 1
        revision = self.radio._metadata["dm32p25_revision"]
        self.assertTrue(self.peer.command("CPS BEGIN 11223344 %d" % (revision + 1)).startswith(b"CPS ERR "))
        self.assertEqual(self.peer.snapshot(), before)

    def test_python_and_real_c_record_validation_agree(self):
        baseline = payload()
        cases = [(0, driver._record(baseline, 0)), (32, bytes(32)),
                 (34, driver._record(baseline, 34))]
        # Exhaustive one-byte mutations at every field boundary are independent
        # host/C implementations of the canonical contract, not two Python peers.
        for key in (0, 34):
            for offset in range(32):
                for value in (0, 1, 15, 63, 127, 255):
                    record = bytearray(driver._record(baseline, key))
                    record[offset] = value
                    cases.append((key, bytes(record)))
        for key, record in cases:
            c_bytes = (ctypes.c_ubyte * 32).from_buffer_copy(record)
            c_valid = bool(self.library.cps_test_record_valid(key, c_bytes))
            try:
                driver._validate_record(record, key)
                py_valid = True
            except errors.InvalidDataError:
                py_valid = False
            self.assertEqual(c_valid, py_valid, (key, record.hex()))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(IntegrationTests)
    if options.adapter_library:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(ActualFirmwareTests))
    result = unittest.TextTestRunner(verbosity=2 if "-v" in unittest_args else 1).run(suite)
    output = ROOT / "build/chirp-validation"
    output.mkdir(parents=True, exist_ok=True)
    (output / "report.json").write_text(json.dumps({
        "chirp_repository": "https://github.com/kk7ds/chirp.git",
        "chirp_commit": CHIRP_COMMIT, "canonical_lf_source_sha256": source_hashes,
        "driver_sha256": hashlib.sha256((ROOT / "integrations/chirp/dm32_p25.py").read_bytes()).hexdigest(),
        "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "actual_firmware_parser_storage": bool(options.adapter_library),
        "firmware_sources_sha256": {
            name: hashlib.sha256((ROOT / name).read_bytes().replace(b"\r\n", b"\n")).hexdigest()
            for name in ("src/firmware/dm32_p25_live.c", "src/firmware/p25_radio_features.h",
                         "src/firmware/p25_channel_store.h", "tests/test_cps_adapter.c")
        } if options.adapter_library else {},
        "adapter_library_sha256": hashlib.sha256(options.adapter_library.read_bytes()).hexdigest()
        if options.adapter_library else None,
        "hardware_used": False, "serial_ports_opened": False,
    }, indent=2) + "\n")
    raise SystemExit(not result.wasSuccessful())
