// SPDX-License-Identifier: GPL-3.0-or-later
// Actual generated gfx and a receiving panel model; no display hardware.
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "cooperative-gfx.c"

enum {TEST_W=40,TEST_H=40};
static color_t test_panel[TEST_H][TEST_W];
static unsigned test_calls,test_rows,test_hits[TEST_H];
static hal_display_t test_display;
const uint8_t *font_glyph(const font_t *f,uint8_t c,int *top,int *rows)
{(void)f;(void)c;*top=*rows=0;return NULL;}
static void test_transfer(const void *fb,const color_t *palette,uint16_t y0,uint16_t y1)
{
    assert(fb==gfx_framebuffer()&&y0<y1&&y1<=TEST_H);
    ++test_calls;test_rows+=y1-y0;
    for(unsigned y=y0;y<y1;++y) {
        ++test_hits[y];
        for(unsigned x=0;x<TEST_W;++x) {
            if(test_display.bpp==16)test_panel[y][x]=((const color_t *)fb)[y*TEST_W+x];
            else if(test_display.bpp==1)test_panel[y][x]=(((const uint8_t *)fb)[y*5u+x/8u]>>(7u-(x&7u)))&1u;
            else {uint8_t v=((const uint8_t *)fb)[y*20u+x/2u];
                assert(palette);test_panel[y][x]=palette[(v>>((x&1u)?0u:4u))&15u];}
        }
    }
}
static void test_plain(const void *fb,uint16_t y0,uint16_t y1) {test_transfer(fb,NULL,y0,y1);}
static void test_indexed(const void *fb,const color_t *palette,uint16_t y0,uint16_t y1)
{test_transfer(fb,palette,y0,y1);}
static void test_equal(void)
{
    for(unsigned y=0;y<TEST_H;++y)for(unsigned x=0;x<TEST_W;++x)
        assert(test_panel[y][x]==gfx_get_pixel((int)x,(int)y));
}
static void test_setup(unsigned depth)
{
    test_display=(hal_display_t){.width=TEST_W,.height=TEST_H,.bpp=(uint8_t)depth,
        .flush=test_plain,.flush_indexed=test_indexed};
    assert(gfx_init(&test_display));assert(!radio_gfx_deferred()&&!radio_gfx_pending());
    memset(test_hits,0,sizeof test_hits);test_calls=test_rows=0;
    memset(test_panel,0xa5,sizeof test_panel);
    gfx_clear(0);gfx_frame_begin();gfx_flush();
    assert(test_rows==TEST_H&&test_calls==1u);test_equal();
    uint32_t frame;assert(gfx_frame_idle(&frame));
#if CONFIG_NET_WEBCTL
    gfx_rows_take(0,TEST_H-1);assert(gfx_row_next(0)==-1);
#endif
    test_calls=test_rows=0;
}
static void test_drain(unsigned rows,unsigned scans)
{
    unsigned steps=0;
    while(radio_gfx_pending()) {
        unsigned before_rows=test_rows,before_calls=test_calls;
        bool pending=radio_gfx_step(rows,scans);
        assert(pending==radio_gfx_pending());
        assert(test_rows-before_rows<=rows&&test_rows-before_rows<=scans);
        assert(test_calls-before_calls<=rows);
        assert(++steps<TEST_H*5u);
    }
    uint32_t frame;assert(gfx_frame_idle(&frame));test_equal();
}
static void test_depth(unsigned depth)
{
    test_setup(depth);
    gfx_frame_begin();gfx_pixel(3,7,0xf800);gfx_flush();
    assert(test_calls==1u&&test_rows==1u);test_equal();
    test_calls=test_rows=0;gfx_flush();assert(!test_calls&&!test_rows);
#if CONFIG_NET_WEBCTL
    gfx_rows_take(0,TEST_H-1);
#endif
    radio_gfx_defer(true);assert(radio_gfx_deferred());
    gfx_frame_begin();gfx_invalidate();gfx_flush();
    assert(radio_gfx_pending()&&!test_calls&&!test_rows);
    uint32_t frame;assert(!gfx_frame_idle(&frame));
    unsigned cursor=radio_gfx_cursor;
    assert(radio_gfx_step(0,8)&&radio_gfx_step(2,0));
    assert(radio_gfx_cursor==cursor&&!test_calls&&!test_rows);
    assert(radio_gfx_step(2,8));assert(test_calls==2u&&test_rows==2u&&radio_gfx_cursor==2u);
#if CONFIG_NET_WEBCTL
    assert(gfx_row_next(0)==0&&gfx_row_next(2)==-1);
#endif
    test_drain(2,8);
    // A no-change frame still scans in bounded pieces; no row is transferred.
    test_calls=test_rows=0;gfx_frame_begin();gfx_flush();
    assert(radio_gfx_step(2,8)&&radio_gfx_cursor==8u&&!test_calls);
    assert(radio_gfx_step(2,8)&&radio_gfx_cursor==16u&&!test_calls);
    test_drain(2,8);assert(!test_rows);
    // Deferred flush without begin must still report pending, rather than the
    // old equal frame counters incorrectly advertising a completed panel.
    gfx_flush();assert(!gfx_frame_idle(&frame));test_drain(2,8);
    // Hashes for unsent changed rows remain the previously transferred hash.
    uint32_t old=row_hash[31];gfx_pixel(2,31,0x07e0);gfx_frame_begin();gfx_flush();
    assert(radio_gfx_step(1,8));assert(row_hash[31]==old&&hash_row(31)!=old);
    test_drain(1,3);assert(row_hash[31]==hash_row(31));
    // Redraw both behind and ahead of a partly sent pass. Do not restart the
    // cursor indefinitely: finish forward work, then scan latest content again.
    gfx_clear(0);gfx_invalidate();gfx_frame_begin();gfx_flush();
    assert(radio_gfx_step(2,8)&&radio_gfx_cursor==2u);
    gfx_pixel(0,0,0xffff);gfx_pixel(1,30,0xffff);gfx_frame_begin();gfx_flush();
    assert(radio_gfx_cursor==2u&&!gfx_frame_idle(&frame));test_drain(2,8);
    // An in-flight invalidation cannot be cleared after only its later rows.
    gfx_invalidate();gfx_frame_begin();gfx_flush();assert(radio_gfx_step(2,8));
    unsigned first_hits=test_hits[0];gfx_invalidate();test_drain(2,8);
    assert(test_hits[0]>first_hits);
    // Policy switches do no bus work; explicit blocking fallback synchronizes
    // pending forced rows and retires the queue with one ordinary full flush.
    gfx_invalidate();gfx_frame_begin();gfx_flush();assert(radio_gfx_step(2,8));
    unsigned count=test_rows;radio_gfx_defer(false);
    assert(!radio_gfx_deferred()&&radio_gfx_pending()&&test_rows==count);
    gfx_flush();assert(!radio_gfx_pending()&&test_rows==count+TEST_H);
    assert(gfx_frame_idle(&frame));test_equal();
    // Reinitialization cancels old display work and restores blocking policy.
    radio_gfx_defer(true);gfx_frame_begin();gfx_flush();assert(radio_gfx_pending());
    assert(gfx_init(&test_display));assert(!radio_gfx_pending()&&!radio_gfx_deferred());
    gfx_clear(0);gfx_flush();test_equal();
    puts(depth==1?"cooperative mono PASS":depth==4?"cooperative indexed PASS":"cooperative RGB565 PASS");
}
#if GFX_INDEXED
static void test_palette_inflight(void)
{
    test_setup(4);radio_gfx_defer(true);
    gfx_clear(0xf800);gfx_frame_begin();gfx_flush();assert(radio_gfx_step(4,8));
    assert(test_panel[0][0]==0xf800&&radio_gfx_cursor==4u);
    uint32_t before_hash=hash_row(0);unsigned before_hits=test_hits[0];
    // Same framebuffer indexes, new RGB565 meaning. Every earlier row needs
    // another actual transfer, even though all row hashes remain unchanged.
    gfx_clear(0x001f);gfx_frame_begin();gfx_flush();assert(hash_row(0)==before_hash);
    test_drain(2,8);assert(test_hits[0]>before_hits);
    for(unsigned y=0;y<TEST_H;++y)for(unsigned x=0;x<TEST_W;++x)assert(test_panel[y][x]==0x001f);
    puts("cooperative palette mutation PASS");
}
#endif
int main(void)
{
    test_depth(1);test_depth(16);
#if GFX_INDEXED
    test_depth(4);test_palette_inflight();
#endif
    test_display.bpp=3;assert(!gfx_init(&test_display));
    gfx_flush();assert(!radio_gfx_pending()&&!radio_gfx_step(2,8));
    puts("cooperative bounded rows/scan, coalescing, hashes, frames and fallback PASS");return 0;
}
