"""Portable C VM, malformed packages, cooperative fuel and independent CRC fixture."""
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
import zlib

ROOT=Path(__file__).resolve().parents[1]


class AppletVMTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.binary=ROOT/'build'/'applets'/'applet-vm-test.exe'
        cls.binary.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Wshadow','-Werror','-pedantic',
                        '-Isrc/firmware','tests/test_applet_vm.c','src/firmware/radio_applet_vm.c',
                        '-o',str(cls.binary)],cwd=ROOT,check=True)

    def test_validation_services_and_execution_limits(self):
        result=subprocess.run([str(self.binary)],cwd=ROOT,check=True,capture_output=True,text=True)
        self.assertIn('checks passed',result.stdout)

    def test_independent_package_crc_and_little_endian_contract(self):
        # Literal offsets refer to the string pool, not arbitrary VM memory.
        code=struct.pack('<BBHI',8,0,5,0)+struct.pack('<BBHI',0,0,0,0)
        header=bytearray(64)
        struct.pack_into('<4sHHIIIHHII',header,0,b'DAPP',1,64,85,2,64,2,0,80,5)
        header[32:38]=b'Python'
        package=header+code+b'Hello'
        struct.pack_into('<I',package,60,zlib.crc32(package[:60]+package[64:]))
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'fixture.dapp'
            path.write_bytes(package)
            result=subprocess.run([str(self.binary),str(path)],cwd=ROOT,check=True,
                                  capture_output=True,text=True)
            self.assertEqual(result.stdout.strip(),'valid:Python:2:2')
            package[-1]^=1
            path.write_bytes(package)
            result=subprocess.run([str(self.binary),str(path)],cwd=ROOT,capture_output=True,text=True)
            self.assertEqual(result.returncode,2)
            self.assertEqual(result.stdout.strip(),'invalid:crc')


if __name__=='__main__':unittest.main()
