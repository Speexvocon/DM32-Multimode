"""Native text-service fixture shared by DMR backend and pacing tests."""
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RF = ROOT / "external/RadioFoundry/RadioFoundry"
DATA_CONFIG = (
    "#define CONFIG_DMR_DATA_CORE 1\n#define CONFIG_DMR_SMS 1\n#define CONFIG_DMR_TMS 1\n"
    "#define CONFIG_DMR_CONFIRMED 1\n#define CONFIG_DMR_UDP_COMPRESS 1\n"
    "#define CONFIG_DMR_ARS 0\n#define CONFIG_DMR_LRRP 0\n#define CONFIG_DMR_SIGNALING 0\n"
    "#define CONFIG_DMR_EMERGENCY 0\n#define CONFIG_ZONE_SHARE 0\n#define CONFIG_CRASH_REPORT 0\n"
    "#define CONFIG_DMR_CONTROL_STATION 0\n#define CONFIG_DMR_DATA_TX_GUARD_MS 250\n"
    "#define RFOUNDRY_CPU_RAM\n"
)


def prepare_service(build):
    spec = importlib.util.spec_from_file_location("dmr_message_service", ROOT / "scripts/generate-dmr-message-service.py")
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    generated = build / "dmrDataService.c"
    generated.write_text(generator.generate((RF / "core/dmr/dmrDataService.c").read_text()))
    return generator, generated
