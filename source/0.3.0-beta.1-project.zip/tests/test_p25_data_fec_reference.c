// SPDX-License-Identifier: GPL-3.0-or-later
// Frozen pre-shortcut decoder; the Python runner verifies its source hash.
#include "reference/p25_data_fec_viterbi.h"
bool p25_test_frozen_decode(const uint8_t *frame,size_t bytes,unsigned block,
                            uint8_t out[12]) {
    return p25_data_decode_block(frame,bytes,block,out);
}
