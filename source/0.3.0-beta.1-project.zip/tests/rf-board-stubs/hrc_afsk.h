/* CONFIG_APRS is disabled in the board integration harness. */
