/* Host board boundary: the generated board and real FD6818 driver run unchanged. */
#ifndef TEST_RF_BOARD_DM32_H
#define TEST_RF_BOARD_DM32_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "hal_radio.h"
#include "cal/baofeng/baofeng_cal.h"
#include "modem/hrc7000/hrc7000.h"
typedef struct {
    void (*rf_switch)(bool tx);
    void (*pa_on)(void);
    uint32_t pa_delay_us;
} hrc_dmr_board_t;
typedef struct {
    uint16_t rssi_raw, noise_raw, fm_noise;
    uint32_t fd_writes;
} dm32_radio_diag_t;
extern const hal_radio_t dm32_radio;
void dm32_speaker_pcm(bool on);
void dm32_radio_diag(dm32_radio_diag_t *d);
void hrc_dmr_board_init(hrc7000_t *modem, const hrc_dmr_board_t *hooks);
void hrc_dmr_enter(void);
void hrc_dmr_leave(void);
void hrc_audio_pcm_attach(hrc7000_t *modem, void (*speaker)(bool));
bool board_in_band(uint32_t hz, bool tx);
#endif
