# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent pinned OP25 CAI PDU factory comparisons and strict app parsing."""
import ctypes as C
import importlib.util
from pathlib import Path
import random
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build'/'test-p25-data'
BUILD.mkdir(parents=True,exist_ok=True)
LIB=BUILD/('p25_data.dll' if sys.platform=='win32' else 'p25_data.so')
compile_args=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-shared']
if sys.platform!='win32':compile_args.append('-fPIC')
subprocess.run(compile_args+['-Isrc/firmware','src/firmware/p25_data.c','src/firmware/p25_rx.c','src/firmware/p25_tsdu.c',
 'src/firmware/p25_demod.c','tests/test_p25_data_bridge.c','-o',str(LIB)],cwd=ROOT,check=True)
lib=C.CDLL(str(LIB));Byte=C.c_uint8;Buffer=Byte*512
class Message(C.Structure):
 _fields_=[('source',C.c_uint32),('destination',C.c_uint32),('sequence',Byte),
           ('acknowledgment',C.c_bool),('ack_requested',C.c_bool),('text',C.c_char*81)]
lib.p25_data_build_tms.argtypes=[C.POINTER(Byte),C.c_size_t,C.c_uint16,C.c_uint32,C.c_uint32,Byte,C.c_char_p]
lib.p25_data_build_tms.restype=C.c_size_t
lib.p25_data_parse_tms.argtypes=[C.POINTER(Byte),C.c_size_t,C.POINTER(Message)]
lib.p25_data_parse_tms.restype=C.c_bool
lib.p25_data_header_symbols.argtypes=[C.POINTER(Byte),C.c_size_t]
lib.p25_data_header_symbols.restype=C.c_uint
lib.p25_data_test_rx.argtypes=[C.POINTER(Byte),C.c_uint,C.POINTER(Byte),C.c_uint]
lib.p25_data_test_rx.restype=C.c_uint
spec=importlib.util.spec_from_file_location('p25craft',ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py')
op=importlib.util.module_from_spec(spec)
# The reference module opens its default p25.out at import; contain that test
# artifact in build rather than leaving generated files in the source tree.
old_cwd=Path.cwd();os.chdir(BUILD)
try:spec.loader.exec_module(op)
finally:os.chdir(old_cwd)
if op.outfile:op.outfile.close()
op.text_out=lambda *_:None
frames=[]
op.print_spec=lambda symbols:frames.append(bytes(sum(symbols[i+j]<<(6-j*2) for j in range(4)) for i in range(0,len(symbols),4)))

def unpack(frame):
 # OP25 independent decoder: strip status and reverse its published interleave
 # table, then match the clean 4-state trellis path. CRC is rebuilt by factory.
 syms=[(v>>(6-i*2))&3 for v in frame for i in range(4)]
 data=[v for i,v in enumerate(syms) if i%36!=35]
 raw=[]
 for b in range((len(data)-56)//98):
  inter=data[56+b*98:56+(b+1)*98];decoded=[None]*98
  indices=op.data_interleave(list(range(98)))
  for n,i in enumerate(indices):decoded[i]=inter[n]
  vals=[];state=0
  for i in range(49):
   pair=decoded[i*2:i*2+2]
   table=(((0,2),(3,0),(0,1),(3,3)),((3,2),(0,0),(3,1),(0,3)),((2,1),(1,3),(2,2),(1,0)),((1,1),(2,3),(1,2),(2,0)))
   value=table[state].index(tuple(pair));vals.append(value);state=value
  assert vals[-1]==0
  raw.append(bytes(sum(vals[i+j]<<(6-2*j) for j in range(4)) for i in range(0,48,4)))
 return raw

def factory(nac,packet,source,io=0,destination=None,sap=4,mfid=0,dho=0):
 frames.clear();op.construct_updu(nac,1,int.from_bytes(packet,'big'),len(packet),io,sap,mfid,destination if io else source,dho)
 return frames[0]

def parse(frame,expected=True):
 out=Message();out.source=0xdeadbeef
 good=lib.p25_data_parse_tms((Byte*len(frame)).from_buffer_copy(frame),len(frame),C.byref(out))
 assert good==expected,(good,expected,frame.hex())
 if not good:assert out.source==0xdeadbeef
 return out

rng=random.Random(0x251025)
for count in range(1,81):
 src=rng.randrange(1,0x1000000);dst=rng.randrange(1,0x1000000);nac=rng.randrange(4096);seq=rng.randrange(256)
 text=''.join(chr(rng.randrange(32,127)) for _ in range(count)).encode()
 frame=Buffer();n=lib.p25_data_build_tms(frame,512,nac,src,dst,seq,text);assert 0<n<=512
 wire=bytes(frame[:n]);raw=unpack(wire);packet=b''.join(raw[1:]);padded=packet[:-4-raw[0][7]] if raw[0][7] else packet[:-4]
 assert wire==factory(nac,padded,src),count
 out=parse(wire);assert (out.source,out.destination,out.sequence,out.text)==(src,dst,seq&31,text)
 assert not out.acknowledgment and not out.ack_requested
 assert lib.p25_data_header_symbols(frame,n)==n*4
 captured=Buffer();assert lib.p25_data_test_rx(frame,n,captured,512)==n and bytes(captured[:n])==wire
 # A single hard bit in each header/data block is repaired by Viterbi.
 if count in (1,40,80):
  for block in range(len(raw)):
   damaged=bytearray(wire);symbol=56+98*block+7;physical=symbol+symbol//35
   damaged[physical//4]^=1<<(6-2*(physical%4));assert parse(damaged).text==text

frame=Buffer();n=lib.p25_data_build_tms(frame,512,0x293,1,2,3,b'HELLO');wire=bytes(frame[:n])
raw=unpack(wire);payload=b''.join(raw[1:]);payload=payload[:int.from_bytes(payload[2:4],'big')]
for length in range(n):parse(wire[:length],False)
parse(wire+b'\0',False)
# Integrity failures, malformed headers and unsupported CAI payload profiles.
for offset in (0,6,12,40,len(wire)-20):
 damaged=bytearray(wire);damaged[offset]^=0xff;parse(damaged,False)
for sap,mfid,dho in ((0,0,0),(4,0x90,0),(4,0,1)):
 parse(factory(0x293,payload,1,sap=sap,mfid=mfid,dho=dho),False)
def sum16(data):
 if len(data)%2:data+=b'\0'
 total=sum(int.from_bytes(data[i:i+2],'big') for i in range(0,len(data),2))
 while total>>16:total=(total&65535)+(total>>16)
 return (~total)&65535
def repair(p):
 p=bytearray(p);p[10:12]=b'\0\0';p[10:12]=sum16(bytes(p[:20])).to_bytes(2,'big')
 p[26:28]=b'\0\0';pseudo=bytes(p[12:20])+bytes([0,17])+bytes(p[24:26])+bytes(p[20:])
 p[26:28]=(sum16(pseudo) or 65535).to_bytes(2,'big');return p
for offset,value in ((0,0x46),(6,0x20),(6,0x80),(8,0),(9,6),(20,1),(22,1),(28,1),(30,0x90),(31,2),(33,5),(35,1)):
 bad=bytearray(payload);bad[offset]=value;parse(factory(0x293,repair(bad),1),False)
for offset in (10,26):
 bad=bytearray(payload);bad[offset]^=1;parse(factory(0x293,bad,1),False)
# FNE outbound asymmetric LLID is accepted only when it matches destination.
assert parse(factory(0x293,payload,1,io=1,destination=2)).text==b'HELLO'
parse(factory(0x293,payload,1,io=1,destination=3),False)
# Reject empty, oversized, non-printable and out-of-range requests atomically.
for args in ((0x1000,1,2,b'X'),(0x293,0,2,b'X'),(0x293,1,0,b'X'),(0x293,0x1000000,2,b'X'),(0x293,1,2,b''),(0x293,1,2,b'X'*81),(0x293,1,2,b'\n')):
 before=bytes([0xa5])*512;f=Buffer.from_buffer_copy(before)
 assert lib.p25_data_build_tms(f,512,*args[:3],0,args[3])==0 and bytes(f)==before
assert lib.p25_data_build_tms(frame,1,0x293,1,2,0,b'HELLO')==0
print('P25 messaging: 80 complete independent OP25 wire comparisons; bounded framer, FEC repair, integrity/app rejection and addressing checks passed')
