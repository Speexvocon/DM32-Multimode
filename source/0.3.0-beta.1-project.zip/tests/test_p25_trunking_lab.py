#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact lab catalog and rejection tests; no timing or RF qualification."""
from pathlib import Path
import importlib.util
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/trunking-lab-test'

class LabProfiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        BUILD.mkdir(parents=True,exist_ok=True)
        cls.binary=BUILD/'profiles.exe'
        subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Isrc/firmware',
                        'tests/test_p25_trunking_lab.c','-o',str(cls.binary)],
                       cwd=ROOT,check=True,capture_output=True,text=True,timeout=60)
        spec=importlib.util.spec_from_file_location('lab_catalog_cross_test',ROOT/'scripts/p25-trunking-lab.py')
        cls.catalog=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.catalog)

    def test_whitelist_nac_parse_frozen_owner_and_mixed_tuple_refusals(self):
        result=subprocess.run([str(self.binary)],check=True,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.stdout.strip(),'P25 immutable lab profiles: PASS')

    def test_exact_catalog(self):
        result=subprocess.run([str(self.binary),'--catalog'],check=True,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.stdout.splitlines(),[
            '0 LEGACY5M 440075000 445075000 440087500 445087500 659 703710 291',
            '1 COMMONIQ1M 440075000 441075000 440087500 441087500 659 703710 291'])
        lab=self.catalog
        host=[' '.join(map(str,(*p,lab.NAC,lab.WACN,lab.SYSTEM))) for p in lab.PROFILES]
        self.assertEqual(result.stdout.splitlines(),host)

    def test_host_records_are_immutable_and_only_canonical_records_or_exact_names_resolve(self):
        lab=self.catalog
        self.assertIs(lab.get(),lab.LEGACY5M)
        for p in lab.PROFILES:
            self.assertIs(lab.get(p.name),p)
            self.assertIs(lab.get(p),p)
            with self.assertRaises(AttributeError):p.control_tx_hz=123
            for forged in (p._replace(control_tx_hz=442075000),p._replace()):
                with self.assertRaises(ValueError):lab.get(forged)
        for name in ('legacy5m','COMMONIQ1M ','','440075000/441075000',0,1,True,None):
            with self.subTest(name=name),self.assertRaises(ValueError):lab.get(name)

if __name__=='__main__':unittest.main(verbosity=2)
