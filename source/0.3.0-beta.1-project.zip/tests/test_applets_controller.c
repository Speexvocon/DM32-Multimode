// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_applets.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static struct {uint32_t before;uint8_t data[RADIO_APPLET_STORE_BYTES];uint32_t after;} memory;
static radio_applets controller;
static uint32_t clock_ms,erases,writes,reads;
static bool hardware_owned,hardware_busy,output_queued;
static unsigned acquisitions,releases,outputs,displayed;
static char log_lines[256][160];
static unsigned log_count;
static uint32_t channel_profile[4]={145700000u,0x293u,98638u,1234567u};
static uint8_t package_bytes[256];
static uint32_t package_size;

static bool range(uint32_t off,uint32_t n) {return off<=sizeof memory.data && n<=sizeof memory.data-off;}
static bool read_memory(void *context,uint32_t off,void *out,uint32_t n) {
 assert(context==&memory && range(off,n));++reads;memcpy(out,memory.data+off,n);return true;
}
static bool write_memory(void *context,uint32_t off,const void *data,uint32_t n) {
 assert(context==&memory && range(off,n) && n);++writes;
 const uint8_t *p=data;for(uint32_t i=0;i<n;++i)assert((memory.data[off+i]&p[i])==p[i]);
 for(uint32_t i=0;i<n;++i)memory.data[off+i]&=p[i];
 return true;
}
static bool erase_memory(void *context,uint32_t off) {
 assert(context==&memory && !(off%4096u) && range(off,4096));++erases;memset(memory.data+off,255,4096);return true;
}
static void emit(void *context,const char *line) {
 assert(context==&clock_ms && strlen(line)<sizeof log_lines[0]);
 if(log_count<256u)strcpy(log_lines[log_count++],line);
 ++outputs;
}
static bool acquire(void *context) {
 assert(context==&clock_ms);if(hardware_busy || hardware_owned)return false;
 hardware_owned=true;++acquisitions;return true;
}
static void release(void *context) {
 assert(context==&clock_ms && hardware_owned);hardware_owned=false;++releases;
 assert(channel_profile[0]==145700000u && channel_profile[1]==0x293u && channel_profile[2]==98638u && channel_profile[3]==1234567u);
}
static uint32_t millis(void *context) {assert(context==&clock_ms);return clock_ms;}
static bool output_pending(void *context) {assert(context==&clock_ms);return output_queued;}
static bool service_emit(void *context,const char *line) {emit(context,line);return true;}
static bool service_display(void *context,const char *line) {++displayed;emit(context,line);return true;}
static bool service_start_same(void *context,uint32_t hz) {assert(context==&clock_ms && hz==162550000u);return true;}
static bool service_same_last(void *context) {emit(context,"SAME last");return true;}
static bool service_display_same(void *context) {return service_display(context,"SAME display");}
static bool service_get(void *context,unsigned field,uint32_t *value) {assert(context==&clock_ms);*value=field;return true;}
static const radio_applet_store_io io={&memory,RADIO_APPLET_STORE_BYTES,4096,read_memory,write_memory,erase_memory};
static const radio_applets_hal hal={acquire,release,emit,output_pending,millis,
 {service_start_same,service_same_last,service_display,service_display_same,service_emit,service_get}};

static void guard(void) {assert(memory.before==0x13579bdfu && memory.after==0x2468ace0u);}
static void reopen(void) {
 hardware_owned=hardware_busy=output_queued=false;log_count=0;
 radio_applets_init(&controller,&io,&hal,&clock_ms);guard();
}
static void fresh(void) {
 memset(memory.data,255,sizeof memory.data);memory.before=0x13579bdfu;memory.after=0x2468ace0u;
 erases=writes=reads=clock_ms=0;acquisitions=releases=outputs=displayed=0;reopen();
 assert(controller.store.state==RADIO_APPLET_STORE_SCANNING && !reads && !writes && !erases);
}
static bool contains(const char *needle) {
 for(unsigned i=0;i<log_count;++i)if(strstr(log_lines[i],needle))return true;
 return false;
}
static void command(const char *line) {assert(radio_applets_command(&controller,line));guard();}
static void poll(void) {radio_applets_poll(&controller);guard();}
static void until(const char *line) {
 for(unsigned i=0;i<5000u && !contains(line);++i)poll();
 if(!contains(line)) {for(unsigned i=0;i<log_count;++i)fprintf(stderr,"%s\n",log_lines[i]);}
 assert(contains(line));
}
static void put16(uint8_t *p,unsigned value) {p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8);}
static void put32(uint8_t *p,uint32_t value) {for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(value>>(8u*i));}
static void instruction(unsigned i,unsigned op,unsigned a,unsigned b,uint32_t imm) {
 uint8_t *p=package_bytes+64u+i*8u;p[0]=(uint8_t)op;p[1]=(uint8_t)a;put16(p+2,b);put32(p+4,imm);
}
static void reseal(void) {
 uint8_t without_crc[252];memcpy(without_crc,package_bytes,60);memcpy(without_crc+60,package_bytes+64,package_size-64u);
 put32(package_bytes+60,radio_applet_store_crc(without_crc,package_size-4u));
}
static void make_package(void) {
 memset(package_bytes,0,sizeof package_bytes);memcpy(package_bytes,"DAPP",4);put16(package_bytes+4,1);put16(package_bytes+6,64);
 package_size=119;put32(package_bytes+8,package_size);put32(package_bytes+12,RADIO_APPLET_CAP_SERIAL|RADIO_APPLET_CAP_DISPLAY);
 put32(package_bytes+16,64);put16(package_bytes+20,5);put32(package_bytes+24,104);put32(package_bytes+28,15);
 memcpy(package_bytes+32,"Controller",10);
 instruction(0,RADIO_APPLET_DISPLAY_LITERAL,0,6,0);instruction(1,RADIO_APPLET_EMIT_LITERAL,0,5,6);
 instruction(2,RADIO_APPLET_WAIT,0,0,100);instruction(3,RADIO_APPLET_EMIT_LITERAL,0,4,11);
 memcpy(package_bytes+104,"AppletHelloDone",15);reseal();
}
static void install_begin(unsigned slot,uint32_t crc) {
 char line[96];snprintf(line,sizeof line,"APP INSTALL BEGIN %u %lu %lu",slot,(unsigned long)package_size,(unsigned long)crc);
 command(line);until("APP OK INSTALL BEGIN");assert(hardware_owned);
 assert(controller.store.state==RADIO_APPLET_STORE_WRITING && !controller.begin_pending);
}
static void data_chunk(uint32_t off,uint32_t n) {
 char line[119];unsigned pos=(unsigned)snprintf(line,sizeof line,"APP INSTALL DATA %lu ",(unsigned long)off);
 for(uint32_t i=0;i<n;++i) {snprintf(line+pos,sizeof line-pos,"%02x",package_bytes[off+i]);pos+=2;}
 command(line);
}
static void install_data(void) {
 for(uint32_t off=0;off<package_size;) {
  uint32_t n=package_size-off;if(n>32u)n=32u;data_chunk(off,n);off+=n;
 }
 assert(controller.store.written==package_size);
}
static void install(unsigned slot) {
 log_count=0;install_begin(slot,radio_applet_store_crc(package_bytes,package_size));install_data();
 command("APP INSTALL COMMIT");until("APP OK INSTALL COMMIT");assert(!hardware_owned);
}
static void scan(void) {command("APP STORE STATUS");until("APP OK STORE STATUS");assert(!hardware_owned);}

static void test_install_run_and_deferred_restore(void) {
 fresh();make_package();
 char begin[96];snprintf(begin,sizeof begin,"APP INSTALL BEGIN 1 %lu %lu",(unsigned long)package_size,
    (unsigned long)radio_applet_store_crc(package_bytes,package_size));command(begin);
 assert(hardware_owned && !contains("APP OK INSTALL BEGIN") && !erases);
 for(unsigned i=0;i<4000u;++i)poll();
 assert(!erases && !contains("APP OK INSTALL BEGIN"));
 until("APP OK INSTALL BEGIN");assert(erases==16u && writes==1u);
 data_chunk(32,32);assert(!controller.store.written && contains("APP ERROR offset"));
 data_chunk(0,32);assert(controller.store.written==32u);uint32_t before=writes;
 data_chunk(0,32);assert(controller.store.written==32u && writes==before);
 package_bytes[0]^=1;data_chunk(0,32);package_bytes[0]^=1;assert(contains("APP ERROR offset or data conflict"));
 for(uint32_t off=32;off<package_size;) {uint32_t n=package_size-off;if(n>32)n=32;data_chunk(off,n);off+=n;}
 command("APP INSTALL COMMIT");assert(controller.store.state==RADIO_APPLET_STORE_VERIFYING);
 until("APP OK INSTALL COMMIT");assert(!hardware_owned && controller.store.slots[0].present && controller.store.slots[0].revision==1u);
 log_count=0;command("APP RUN 1");assert(contains("APP OK RUN 1") && hardware_owned);
 poll();assert(contains("Hello") && contains("Applet") && displayed==1u && controller.vm.state==RADIO_APPLET_WAITING);
 clock_ms=99;poll();assert(!contains("Done"));
 output_queued=true;clock_ms=100;poll();assert(contains("Done") && hardware_owned && !contains("APP DONE"));
 clock_ms=500;poll();assert(hardware_owned);
 output_queued=false;poll();assert(!hardware_owned && contains("APP DONE"));
 assert(acquisitions==releases);
 char name[32],detail[64];radio_applets_slot_label(&controller,1,name,sizeof name,detail,sizeof detail);
 assert(!strcmp(name,"Controller") && strstr(detail,"119 bytes"));
 reopen();scan();assert(controller.store.slots[0].present && controller.store.slots[0].revision==1);
}
static void test_failed_updates_keep_prior_package(void) {
 fresh();make_package();install(1);uint32_t old_revision=controller.store.slots[0].revision;
 log_count=0;install_begin(1,radio_applet_store_crc(package_bytes,package_size)^1u);install_data();command("APP INSTALL COMMIT");
 until("APP ERROR applet storage operation failed");assert(!hardware_owned && controller.store.slots[0].revision==old_revision);
 reopen();scan();assert(controller.store.slots[0].present && controller.store.slots[0].revision==old_revision);
 make_package();package_bytes[64]=255;reseal();log_count=0;
 install_begin(1,radio_applet_store_crc(package_bytes,package_size));install_data();command("APP INSTALL COMMIT");
 until("APP ERROR applet storage operation failed");reopen();scan();assert(controller.store.slots[0].revision==old_revision);
 make_package();put32(package_bytes+12,16u);reseal();log_count=0;
 install_begin(2,radio_applet_store_crc(package_bytes,package_size));install_data();command("APP INSTALL COMMIT");
 until("APP ERROR applet storage operation failed");reopen();scan();assert(!controller.store.slots[1].present && controller.store.slots[0].present);
 make_package();log_count=0;install_begin(1,radio_applet_store_crc(package_bytes,package_size));data_chunk(0,32);
 command("APP INSTALL COMMIT");assert(!hardware_owned && contains("APP ERROR incomplete install"));
 assert(controller.store.slots[0].revision==old_revision);
}
static void test_busy_stop_timeout_and_input_bounds(void) {
 fresh();make_package();install(1);log_count=0;command("APP RUN 1");poll();
 command("APP INSTALL BEGIN 2 119 0");assert(contains("APP ERROR stop current app or radio busy") && controller.running);
 command("APP STOP");assert(!hardware_owned && contains("APP STOPPED"));
 hardware_busy=true;log_count=0;command("APP RUN 1");assert(!hardware_owned && contains("radio busy"));hardware_busy=false;
 log_count=0;command("APP RUN 1");poll();radio_applets_stop(&controller);assert(!hardware_owned && !controller.running); // CPS takeover.
 make_package();log_count=0;install_begin(1,radio_applet_store_crc(package_bytes,package_size));
 clock_ms+=30001;poll();assert(!hardware_owned && contains("install timed out"));
 log_count=0;install_begin(1,radio_applet_store_crc(package_bytes,package_size));
 command("APP INSTALL DATA 0 0");assert(!controller.store.written && contains("invalid data chunk"));
 command("APP INSTALL DATA 0 gg");assert(!controller.store.written && contains("invalid hex"));
 command("APP INSTALL DATA 4294967296 aa");assert(!controller.store.written);
 char long_line[130];memset(long_line,'X',sizeof long_line);memcpy(long_line,"APP INSTALL ",12);long_line[129]=0;
 uint32_t saved_writes=writes;assert(!radio_applets_command(&controller,long_line));assert(writes==saved_writes);
 command("APP INSTALL ABORT");assert(!hardware_owned);
}
static void test_foreign_data_no_erase(void) {
 fresh();make_package();memory.data[0x81234u]=0x17;uint32_t old=radio_applet_store_crc(memory.data,sizeof memory.data);
 log_count=0;
 char begin[96];snprintf(begin,sizeof begin,"APP INSTALL BEGIN 1 %lu %lu",(unsigned long)package_size,
     (unsigned long)radio_applet_store_crc(package_bytes,package_size));command(begin);
 until("APP ERROR foreign data");assert(!writes && !erases && !hardware_owned);
 assert(radio_applet_store_crc(memory.data,sizeof memory.data)==old && memory.data[0x81234u]==0x17);
}
static void test_atomic_delete_and_power_restart(void) {
 fresh();make_package();install(1);log_count=0;command("APP REMOVE 1");poll();
 assert(controller.store.slots[0].present);radio_applets_stop(&controller);reopen();scan();assert(controller.store.slots[0].present);
 log_count=0;command("APP REMOVE 1");until("APP OK REMOVE 1");assert(!hardware_owned && !controller.store.slots[0].present);
 assert(controller.store.slots[0].committed && controller.store.slots[0].revision==2u);
 reopen();scan();assert(!controller.store.slots[0].present && controller.store.slots[0].revision==2u);
 log_count=0;command("APP RUN 1");assert(!hardware_owned && contains("APP ERROR empty applet slot"));
}
int main(void) {
 test_install_run_and_deferred_restore();test_failed_updates_keep_prior_package();
 test_busy_stop_timeout_and_input_bounds();test_foreign_data_no_erase();test_atomic_delete_and_power_restart();
 guard();puts("applet controller integration passed");return 0;
}
