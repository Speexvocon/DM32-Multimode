// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_burst.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

_Static_assert(sizeof(p25_trunking_burst_plan)<=24u,"Burst plan unexpectedly grew");
static void reject(const p25_trunking_burst_config *config) {
    p25_trunking_burst_plan out,before;memset(&out,0xa5,sizeof out);memcpy(&before,&out,sizeof out);
    assert(!p25_trunking_burst_plan_make(&out,config));assert(!memcmp(&out,&before,sizeof out));
}
static void reject_render(const p25_trunking_burst_plan *plan,const uint8_t *prefix,unsigned index) {
    uint8_t out[36],before[36];memset(out,0xa5,sizeof out);memcpy(before,out,sizeof out);
    assert(!p25_trunking_burst_render(plan,prefix,index,out));assert(!memcmp(out,before,sizeof out));
}
int main(void) {
    p25_trunking_burst_config config={.lead_bytes=72,.packet_after_rf_us=30000,.pa_lead_us=2000,.end_trim_us=-2000};
    p25_trunking_burst_plan plan;
    assert(P25_TRUNK_BURST_NOMINAL_US==(316u*1000000u+9599u)/9600u);
    assert(p25_trunking_burst_plan_make(&plan,&config));
    assert(plan.pa_after_rf_us==28000 && plan.cut_after_rf_us==60917 && plan.transport_bytes==144);
    uint8_t prefix[40],saved[40];for(unsigned i=0;i<40;++i)prefix[i]=(uint8_t)(i+0x10u);
    memcpy(saved,prefix,sizeof prefix);
    for(unsigned lead=72;lead<=240;++lead) {
        config.lead_bytes=(uint16_t)lead;
        assert(p25_trunking_burst_plan_make(&plan,&config));
        assert(plan.valid_bits==316 && plan.prefix_bytes==40 && plan.transport_bytes<=288);
        assert(plan.transport_bytes==((lead+40u+35u)/36u)*36u);
        uint8_t all[288];
        for(unsigned block=0;block<plan.transport_bytes/36u;++block)
            assert(p25_trunking_burst_render(&plan,prefix,block,all+block*36u));
        for(unsigned i=0;i<lead;++i)assert(all[i]==0x77);
        assert(!memcmp(all+lead,prefix,39));assert(all[lead+39]==((prefix[39]&0xf0u)|7u));
        for(unsigned i=lead+40;i<plan.transport_bytes;++i)assert(all[i]==0x77);
        assert(!memcmp(prefix,saved,sizeof prefix));
        reject_render(&plan,prefix,plan.transport_bytes/36u);reject_render(&plan,prefix,UINT_MAX);
    }
    for(unsigned lead=72;lead<=240;lead+=168)for(unsigned packet=30000;packet<=220000;packet+=190000)
        for(unsigned pa=0;pa<=2000;pa+=2000)for(int trim=-2000;trim<=2000;trim+=2000) {
            config=(p25_trunking_burst_config){.lead_bytes=(uint16_t)lead,.packet_after_rf_us=packet,
                .pa_lead_us=(uint16_t)pa,.end_trim_us=(int16_t)trim};
            assert(p25_trunking_burst_plan_make(&plan,&config));
            assert(plan.pa_after_rf_us==packet-pa && plan.cut_after_rf_us==(uint32_t)((int64_t)packet+32917+trim));
            assert(plan.cut_after_rf_us<=260000 && plan.cut_after_rf_us>plan.pa_after_rf_us);
        }
    assert(!p25_trunking_burst_plan_make(NULL,&config));reject(NULL);
    for(unsigned bad=0;bad<10;++bad) {
        p25_trunking_burst_config value=config;
        if(bad==0)value.lead_bytes=71;
        if(bad==1)value.lead_bytes=241;
        if(bad==2)value.packet_after_rf_us=29999;
        if(bad==3)value.packet_after_rf_us=220001;
        if(bad==4)value.packet_after_rf_us=UINT32_MAX;
        if(bad==5)value.pa_lead_us=2001;
        if(bad==6)value.pa_lead_us=UINT16_MAX;
        if(bad==7)value.end_trim_us=-2001;
        if(bad==8)value.end_trim_us=2001;
        if(bad==9)value.lead_bytes=UINT16_MAX;
        reject(&value);
    }
    assert(p25_trunking_burst_plan_make(&plan,&config));
    reject_render(NULL,prefix,0);reject_render(&plan,NULL,0);
    assert(!p25_trunking_burst_render(&plan,prefix,0,NULL));
    for(unsigned bad=0;bad<8;++bad) {
        p25_trunking_burst_plan value=plan;
        if(bad==0)value.valid_bits=320;
        if(bad==1)value.prefix_bytes=45;
        if(bad==2)value.transport_bytes=0;
        if(bad==3)value.transport_bytes++;
        if(bad==4)value.lead_bytes=0;
        if(bad==5)value.pa_after_rf_us=value.packet_after_rf_us+1;
        if(bad==6)value.cut_after_rf_us=UINT32_MAX;
        if(bad==7)value.cut_after_rf_us=value.pa_after_rf_us;
        reject_render(&value,prefix,0);
    }
    puts("PASS: bounded316-bit lab burst geometry, duration, complete36-byte rendering and refusal contracts; no RF timing qualification");
    return 0;
}
