// SPDX-License-Identifier: GPL-3.0-or-later
// Actual application parser + actual atomic storage, using the established
// host-only HAL model. No serial device, MMIO or production source substitution.
#pragma GCC diagnostic push
// C implicitly returns zero only for the literal name "main". This included
// test entry is never called; all its real HAL helpers remain in this TU.
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main unused_live_adapter_main
#include "test_live_adapter.c"
#undef main
#pragma GCC diagnostic pop

#ifdef _WIN32
#define CPS_EXPORT __declspec(dllexport)
#else
#define CPS_EXPORT __attribute__((visibility("default")))
#endif

enum { CPS_PAYLOAD_BYTES=P25_CS_RECORDS*P25_CS_RECORD_BYTES };

static void cps_boot(void) {
    reset();memset(&mailbox,0,sizeof mailbox);memset(&message_stage,0,sizeof message_stage);
    pref_flash_forbidden=false;preferences_restore();
    normal_mode=true;display_ok=false;mock_ptt_high=true;
    ptt_release_required=false;pref_dirty=false;
    assert(features_ready && !cps_active && !channel_store.staging);
}
CPS_EXPORT int cps_test_initialize(void) {
    pref_flash_forbidden=false;memset(pref_flash_mem,255,sizeof pref_flash_mem);
    p25_preferences legacy={440075000,440075000,0x293,10,1234567,0,22,0,0};
    pref_pack(pref_flash_mem,&legacy,7);cps_boot();return 1;
}
CPS_EXPORT int cps_test_reboot(void) {cps_boot();return 1;}
CPS_EXPORT int cps_test_command(const char *input,int down,int raw_released,char *reply,unsigned cap) {
    if(!input || !reply || !cap || strlen(input)>=sizeof command || strchr(input,'\n') || strchr(input,'\r'))return -1;
    output_n=0;output[0]=0;mock_ptt_high=raw_released!=0;
    issue(input,down!=0);
    assert(!rf_keys && !pa_keys && !hardware_running && !audio_on && !call_active);
    if(output_n>=cap)return -2;
    memcpy(reply,output,output_n);reply[output_n]=0;return (int)output_n;
}
CPS_EXPORT int cps_test_copy_active(uint8_t *out,unsigned cap) {
    if(cap<CPS_PAYLOAD_BYTES)return 0;
    for(unsigned k=0;k<P25_CS_RECORDS;++k)if(!p25_cs_read(&channel_store,k,out+k*32))return 0;
    return CPS_PAYLOAD_BYTES;
}
CPS_EXPORT int cps_test_record_valid(unsigned key,const uint8_t *record) {
    return p25_cs_record_valid(key,record);
}
CPS_EXPORT int cps_test_record_valid_version(unsigned version,unsigned key,const uint8_t *record) {
    return p25_cs_record_valid_version(version,key,record);
}
CPS_EXPORT unsigned cps_test_record_count(void) {return P25_CS_RECORDS;}
CPS_EXPORT unsigned cps_test_payload_bytes(void) {return CPS_PAYLOAD_BYTES;}
CPS_EXPORT int cps_test_copy_legacy(uint8_t *out,unsigned cap) {
    if(cap<35u*32u || channel_store.active_version>=4u)return 0;
    for(unsigned key=0;key<35u;++key)if(!p25_cs_old_read(&channel_store,key,out+key*32u))return 0;
    return 35u*32u;
}
CPS_EXPORT unsigned cps_test_revision(void) {return channel_store.revision;}
// Host-only setup for mailbox/serial end-to-end tests. Never runs the TX worker.
CPS_EXPORT int cps_test_mail_fixture(void) {
    memset(&mailbox,0,sizeof mailbox);memset(&message_stage,0,sizeof message_stage);
    control.inhibit=false;control.tx_enabled=true;owner_tx_inhibit=false;
    ptt_release_required=false;mock_ptt_high=true;
    radio_message m={.protocol=RADIO_PROTOCOL_DMR,.kind=RADIO_CALL_INDIVIDUAL,
        .source=123456,.destination=control.source_id,.token=0};
    memcpy(m.text,"<img src=x> literal received text and a second chunk",52);
    radio_mail_item *item=radio_mail_insert(&mailbox,&m,RADIO_MAIL_RECEIVED,2,12345);
    if(item)item->truncated=true;
    return item && message_tx_permission();
}
CPS_EXPORT int cps_test_mail_state(unsigned id,unsigned state) {
    radio_mail_item *item=radio_mail_find(&mailbox,id);
    if(!item || state>RADIO_MAIL_RECEIVED)return 0;
    radio_mail_set(&mailbox,item,state,RADIO_MAIL_ERROR_NONE);return 1;
}


static const char *cps(const char *input) {
    static char reply[8192];int size=cps_test_command(input,0,1,reply,sizeof reply);
    assert(size>0 && (unsigned)size<120);return reply;
}
static void cps_ack(const char *input,const char *expected) {
    const char *reply=cps(input);
    if(strcmp(reply,expected))fprintf(stderr,"CPS request: %s\nExpected: %sActual: %s",input,expected,reply);
    assert(!strcmp(reply,expected));
}
static void cps_put(unsigned key,const uint8_t *record) {
    char line[120],expected[64];int n=snprintf(line,sizeof line,"CPS PUT 11223344 %u ",key);
    for(unsigned i=0;i<32;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02X",record[i]);
    snprintf(expected,sizeof expected,"CPS OK PUT 11223344 %u\r\n",key);cps_ack(line,expected);
}
int main(void) {
    assert(cps_test_initialize());
    uint8_t original[CPS_PAYLOAD_BYTES],current[CPS_PAYLOAD_BYTES],changed[32],functions[32];
    assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES);
    unsigned revision=cps_test_revision();uint32_t crc=pref_crc(original,sizeof original);
    char line[120],expected[120];
    snprintf(expected,sizeof expected,"CPS HELLO DM32P25 %u %u 2 %u %08X\r\n",P25_CS_VERSION,P25_CS_CHANNELS,revision,crc);
    cps_ack("CPS HELLO",expected);
    // Every wire record is the exact canonical bytes consumed by the CPS.
    for(unsigned k=0;k<P25_CS_RECORDS;++k) {
        snprintf(line,sizeof line,"CPS GET %u",k);
        const char *reply=cps(line);unsigned key;char hex[65],extra;
        assert(sscanf(reply,"CPS DATA %u %64s %c",&key,hex,&extra)==2 && key==k);
        assert(feature_hex(hex,changed,32) && !memcmp(changed,original+k*32,32));
    }
    // A read-only session relinquishes ownership after its bounded idle time.
    normal_model model={0};
    now+=3000000u;normal_step(&model,false);
    assert(!cps_link && !cps_active && !channel_store.staging);
    const char *bad_begin[]={"CPS BEGIN 00000000 7","CPS BEGIN 1234567 7",
        "CPS BEGIN 11223344 -1","CPS BEGIN 11223344 4294967296"};
    for(unsigned i=0;i<sizeof bad_begin/sizeof bad_begin[0];++i) {
        assert(strstr(cps(bad_begin[i]),"CPS ERR "));
        assert(!channel_store.staging);
    }
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision+1u);
    assert(strstr(cps(line),"CPS ERR "));
    assert(!channel_store.staging);
    // Both debounced and physical held PTT reject even a read/handshake.
    char reply[128];
    assert(cps_test_command("CPS HELLO",1,1,reply,sizeof reply)>0 && strstr(reply,"CPS ERR BUSY"));
    assert(cps_test_command("CPS HELLO",0,0,reply,sizeof reply)>0 && strstr(reply,"CPS ERR BUSY"));
    mock_ptt_high=true;
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");
    for(unsigned tick=0;tick<10;++tick)normal_step(&model,true);
    for(unsigned tick=0;tick<10;++tick)normal_step(&model,false);
    assert(cps_active && channel_store.staging && !mon_running && !analog_fm.running);
    assert(!rf_keys && !pa_keys && !call_active && !hardware_running);
    cps_ack("CPS HELLO","CPS ERR TRANSACTION\r\n");
    memcpy(changed,original+P25_CS_VFO_A*32,32); // Copy valid VFO into memory 1.
    memset(changed+14,0,12);memcpy(changed+14,"CHIRP TEST",10);
    cps_put(0,changed);
    assert(cps_test_copy_active(current,sizeof current)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    cps_ack("CPS COMMIT 11223344 00000000","CPS ERR COMMIT\r\n");
    assert(cps_test_copy_active(current,sizeof current)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    assert(cps_test_reboot()); // Interrupted stage/bad CRC leaves old whole image.
    assert(cps_test_copy_active(current,sizeof current)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    // A direct BEGIN also arms the staging timeout, even without prior HELLO.
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(0,changed);
    now+=60000000u;normal_step(&model,false);
    assert(!cps_active && !cps_link && !channel_store.staging);
    assert(cps_test_copy_active(current,sizeof current)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(0,changed);
    cps_ack("CPS ABORT 11223344","CPS OK ABORT 11223344\r\n");
    assert(cps_test_reboot());
    assert(cps_test_copy_active(current,sizeof current)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);
    cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(0,changed);
    memcpy(current,original,sizeof current);memcpy(current,changed,32);
    crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+1u,crc);
    cps_ack(line,expected);
    assert(cps_test_reboot());
    assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    assert(cps_test_revision()==revision+1u);
    // The expanded transaction retains the existing P25 profile while adding a
    // full24-bit private DMR destination, channel power and global functions.
    memcpy(current,original,sizeof current);memcpy(changed,original+P25_CS_VFO_A*32,32);
    assert(radio_channel_set_mode(changed,RADIO_CHANNEL_DMR));
    assert(radio_channel_set_destination(changed,0xffffff) && radio_channel_set_color_code(changed,15) && radio_channel_set_timeslot(changed,2));
    radio_channel_set_private(changed,true);radio_channel_set_repeater(changed,true);changed[12]|=P25_CS_PROM;
    assert(radio_functions_set_power(changed,8));
    assert(p25_cs_record_valid(1,changed) && !p25_cs_record_valid_version(1,1,changed));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision+1u);cps_ack(line,"CPS OK BEGIN 11223344\r\n");cps_put(1,changed);
    memcpy(current+32,changed,32);memcpy(functions,current+P25_CS_GLOBAL*32,32);
    assert(radio_functions_set_tot_seconds(functions,600) && radio_functions_set_broadcast_khz(functions,65000));
    assert(radio_functions_set_action(functions,RADIO_FUNCTION_P1,RADIO_FUNCTION_SCAN));
    assert(radio_functions_set_action(functions,RADIO_FUNCTION_P2,RADIO_FUNCTION_NONE));
    assert(radio_functions_set_action(functions,RADIO_FUNCTION_SK1,RADIO_FUNCTION_BROADCAST));
    assert(radio_functions_set_action(functions,RADIO_FUNCTION_SK2,RADIO_FUNCTION_POWER));
    cps_put(P25_CS_GLOBAL,functions);memcpy(current+P25_CS_GLOBAL*32,functions,32);crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+2u,crc);cps_ack(line,expected);
    assert(cps_test_reboot());assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    assert(channel_store.active_version==P25_CS_VERSION && radio_functions_get_power(original+32)==8);
    assert(radio_functions_get_tot_seconds(original+P25_CS_GLOBAL*32)==600 && radio_functions_get_broadcast_khz(original+P25_CS_GLOBAL*32)==65000);
    assert(radio_functions_get_action(original+P25_CS_GLOBAL*32,RADIO_FUNCTION_P1)==RADIO_FUNCTION_SCAN);
    // A correct transport CRC cannot publish a selection of an empty CH256.
    revision=cps_test_revision();memcpy(current,original,sizeof current);
    memcpy(functions,current+P25_CS_GLOBAL*32,32);functions[10]=0;functions[24]=1;
    memcpy(current+P25_CS_GLOBAL*32,functions,32);
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);cps_ack(line,"CPS OK BEGIN 11223344\r\n");
    cps_put(P25_CS_GLOBAL,functions);crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);cps_ack(line,"CPS ERR COMMIT\r\n");
    cps_ack("CPS ABORT 11223344","CPS OK ABORT 11223344\r\n");
    assert(cps_test_copy_active(current,sizeof current)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));

    // CH256, zone membership, independent TG-list records and the 16-bit
    // selected-memory extension travel through the actual line parser.
    uint8_t zone[32]={0},members[32]={0},list[32]={0},groups[32]={0},empty[32]={0};
    memcpy(changed,original+P25_CS_VFO_A*32,32);memset(changed+14,0,12);memcpy(changed+14,"HIGH MEMORY",11);
    changed[13]=0;
    memcpy(zone,"HIGH ZONE",9);members[31]=0x80;
    memcpy(list,"P25 GROUPS",10);list[12]=1;list[13]=2;
    p25_cs_put16(list+14,256);p25_cs_put16(list+16,256);
    p25_cs_put16(list+18,1000);p25_cs_put16(list+20,2000);list[22]=3;
    p25_cs_put16(groups,10);p25_cs_put16(groups+2,100);p25_cs_put16(groups+4,1000);
    memcpy(functions,original+P25_CS_GLOBAL*32,32);functions[10]=0;functions[24]=1;functions[26]=1;
    memcpy(current,original,sizeof current);
    const unsigned keys[]={255,P25_CS_ZONE_BASE,P25_CS_ZONE_BASE+1,P25_CS_SCAN_BASE,
        P25_CS_SCAN_BASE+1,P25_CS_SCAN_BASE+2,P25_CS_GLOBAL};
    const uint8_t *values[]={changed,zone,members,list,empty,groups,functions};
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);cps_ack(line,"CPS OK BEGIN 11223344\r\n");
    for(unsigned i=0;i<sizeof keys/sizeof keys[0];++i) {
        cps_put(keys[i],values[i]);memcpy(current+keys[i]*32,values[i],32);
    }
    crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+1u,crc);cps_ack(line,expected);
    assert(cps_test_reboot() && feature_memory()==256);
    assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    assert(!rf_keys && !pa_keys && !call_active && !hardware_running);
    // V5 directory and individual P25 addressing survive the real parser and reboot.
    revision=cps_test_revision();memcpy(current,original,sizeof current);
    uint8_t alias[32]={0};alias[0]=P25_CS_CONTACT_OCCUPIED|P25_CS_CONTACT_BOTH;
    alias[1]=0x56;alias[2]=0x34;alias[3]=0x12;memcpy(alias+4,"CALLSIGN",8);
    memcpy(changed,original,32);radio_channel_set_private(changed,true);
    assert(radio_channel_set_destination(changed,0x123456));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);cps_ack(line,"CPS OK BEGIN 11223344\r\n");
    cps_put(0,changed);cps_put(P25_CS_CONTACT_BASE+95,alias);
    memcpy(current,changed,32);memcpy(current+(P25_CS_CONTACT_BASE+95)*32,alias,32);crc=pref_crc(current,sizeof current);
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+1u,crc);cps_ack(line,expected);
    assert(cps_test_reboot());assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES && !memcmp(current,original,sizeof current));
    assert(radio_channel_get_private(original) && radio_channel_get_destination(original)==0x123456);
    assert(p25_cs_contact_match(original+(P25_CS_CONTACT_BASE+95)*32,P25_CS_CONTACT_DMR,false,0x123456));
    unsigned before_revision=cps_test_revision();
    cps_ack("CPS SERVICES","CPS SERVICES 1 heard=32 contacts=96 p25_unit=1 dmr_unit=1 p25_text=110 dmr_text=111\r\n");
    assert(cps_test_revision()==before_revision && !rf_keys && !pa_keys);
    // A small selection journal is part of the effective logical GLOBAL:
    // HELLO CRC, GET, export and unchanged-record carry-forward must agree.
    revision=cps_test_revision();memcpy(functions,original+P25_CS_GLOBAL*32,32);
    functions[9]^=1u;
    unsigned selection_writes=pref_flash_writes,selection_erases=pref_flash_erases;
    assert(p25_cs_save_selection(&channel_store,functions));
    assert(cps_test_revision()==revision&&pref_flash_erases==selection_erases
        &&pref_flash_writes==selection_writes+3u);
    assert(cps_test_reboot()&&channel_store.writable);
    memcpy(current,original,sizeof current);memcpy(current+P25_CS_GLOBAL*32,functions,32);
    assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES&&!memcmp(current,original,sizeof current));
    crc=pref_crc(current,sizeof current);
    snprintf(expected,sizeof expected,"CPS HELLO DM32P25 %u %u 2 %u %08X\r\n",P25_CS_VERSION,P25_CS_CHANNELS,revision,crc);
    cps_ack("CPS HELLO",expected);
    snprintf(line,sizeof line,"CPS GET %u",P25_CS_GLOBAL);
    unsigned journal_key;char journal_hex[65],journal_extra;
    assert(sscanf(cps(line),"CPS DATA %u %64s %c",&journal_key,journal_hex,&journal_extra)==2
        &&journal_key==P25_CS_GLOBAL&&feature_hex(journal_hex,changed,32)&&!memcmp(changed,functions,32));
    snprintf(line,sizeof line,"CPS BEGIN 11223344 %u",revision);cps_ack(line,"CPS OK BEGIN 11223344\r\n");
    snprintf(line,sizeof line,"CPS COMMIT 11223344 %08X",crc);
    snprintf(expected,sizeof expected,"CPS OK COMMIT 11223344 %u %08X\r\n",revision+1u,crc);cps_ack(line,expected);
    assert(cps_test_reboot()&&channel_store.writable&&!channel_store.selection_valid);
    assert(cps_test_copy_active(original,sizeof original)==CPS_PAYLOAD_BYTES&&!memcmp(current,original,sizeof current));
    puts("CPS adapter: expanded geometry, selection journal/CRC/export, reference/PTT gates and atomic reboot passed");
    return 0;
}
