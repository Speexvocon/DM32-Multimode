# SPDX-License-Identifier: GPL-3.0-or-later
"""Receive-only pre-NID observer through native demod/CRC and pinned OP25 C4FM."""
import ast
import ctypes as C
import hashlib
import importlib.util
import math
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build/test-p25-demod-early'
BUILD.mkdir(parents=True, exist_ok=True)
REF = ROOT / 'external/boatbod/op25/op25/gr-op25_repeater/apps/tx'
PINS = {'p25craft.py': '27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9',
        'op25_c4fm_mod.py': 'b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef'}


def pinned(name):
    data = (REF / name).read_bytes().replace(b'\r\n', b'\n')
    assert hashlib.sha256(data).hexdigest() == PINS[name], name
    return data


pinned('p25craft.py')
spec = importlib.util.spec_from_file_location('early_op25', REF / 'p25craft.py')
op = importlib.util.module_from_spec(spec)
old_cwd = Path.cwd()
os.chdir(BUILD)
try:
    spec.loader.exec_module(op)
finally:
    os.chdir(old_cwd)
op.outfile.close()
op.text_out = lambda *_: None
generated = []
op.print_spec = lambda dibits: generated.append(list(dibits))
nodes = [n for n in ast.parse(pinned('op25_c4fm_mod.py')).body
         if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in {'transfer_function_tx', 'c4fm_taps'}]
assert len(nodes) == 2
scope = dict(np=np, pi=math.pi, sin=math.sin, cos=math.cos,
             _def_symbol_rate=4800, _def_output_sample_rate=48000, _def_span=13)
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'pinned-op25-c4fm', 'exec'), scope)
taps = scope['c4fm_taps']().generate()
tx_delay = (len(taps) - 1) // 2


def wire(nac=0x293, voice=False, bad_nid=False):
    generated.clear()
    if voice:
        op.construct_ldu1(nac, 2, 0, 0, 0, 0, 0, 0, 1, 0, 1)
    else:
        op.construct_tsdu3(nac, 2, 1, 0, [0x3b], [0x000abcde12300001])
    dibits = generated[0]
    for index in range(35, len(dibits), 36):
        dibits[index] = 3 if index == 35 else 2
    if bad_nid:
        dibits[24] ^= 3
        dibits[25] ^= 3
        dibits[56] ^= 1
    return bytes(sum(dibits[i+j] << (6-2*j) for j in range(4)) for i in range(0, len(dibits), 4))


def waveform(frames, phase=0, polarity=1):
    air = b'\x77' * 72 + b''.join(frames)
    dibits = np.array([(v >> shift) & 3 for v in air for shift in (6, 4, 2, 0)])
    impulses = np.zeros(len(dibits) * 10)
    impulses[::10] = np.array([1, 3, -1, -3])[dibits]
    high = np.convolve(impulses, taps) * 60000 * polarity
    pcm = np.clip(np.rint(high[phase::6]), -32768, 32767).astype(np.int16)
    return np.concatenate((pcm, np.zeros(32, dtype=np.int16)))


library = BUILD / ('early.dll' if sys.platform == 'win32' else 'early.so')
command = ['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wshadow', '-shared']
if sys.platform != 'win32':
    command += ['-fPIC']
command += ['-Isrc/firmware', 'tests/test_p25_demod_early.c', 'src/firmware/p25_rx.c',
            'src/firmware/p25_tsdu.c', '-o', str(library)]
subprocess.run(command, cwd=ROOT, check=True, timeout=120)
lib = C.CDLL(str(library))
U8, U32, U64 = C.c_uint8, C.c_uint, C.c_uint64
lib.p25_early_units.argtypes = [C.POINTER(U8), C.POINTER(U8), C.POINTER(U8), U32]
lib.p25_early_units.restype = U32
lib.p25_early_run.argtypes = [C.POINTER(C.c_int16), U32, U64, U32, U32,
                            C.POINTER(U64), C.POINTER(U64), C.POINTER(U32)]
lib.p25_early_run.restype = U32
clean, foreign, voice = wire(), wire(nac=0x2a3), wire(voice=True)
u8 = lambda data: (U8 * len(data)).from_buffer_copy(data)
state_bytes = lib.p25_early_units(u8(clean), u8(foreign), u8(voice), len(voice))
ORIGIN = 1000000


def run(pcm, phase=0, mode=1, change_at=0):
    regular, early_events, stats = (U64 * (9 * 256))(), (U64 * (9 * 256))(), (U32 * 7)()
    assert lib.p25_early_run(pcm.ctypes.data_as(C.POINTER(C.c_int16)), len(pcm),
        ORIGIN + phase, mode, change_at, regular, early_events, stats) == state_bytes
    rows = lambda values, count: [tuple(values[i*9:(i+1)*9]) for i in range(count)]
    return rows(regular, stats[3]), rows(early_events, stats[4]), tuple(stats)


for phase in range(6):
    for polarity in (1, -1):
        pcm = waveform([clean] * 12, phase, polarity)
        ordinary, no_early, off = run(pcm, phase, 0)
        regular, early_events, on = run(pcm, phase)
        null_regular, null_early, null = run(pcm, phase, 2)
        assert ordinary == regular == null_regular and not no_early and not null_early
        assert off[:4] == on[:4] == null[:4] and off[5:] == on[5:] == null[5:]
        assert on[0] == 12 and len(early_events) == 11
        first_statuses = [row for row in regular if row[6] == 0x703 and row[4] == 3]
        assert len(first_statuses) == len(early_events)
        for index, (raw, qualified) in enumerate(zip(early_events, first_statuses), 1):
            expected = ORIGIN + (72 * 4 + index * 180 + 35) * 10 + tx_delay + 5
            assert raw[:6] == qualified[:6] and raw[6] == 0x701
            assert abs(raw[0] - expected) <= 3 and qualified[7] > raw[7]
            assert 204 <= qualified[8] - raw[8] <= 216  # 21 symbols, input quantization.
        one_regular, one_early, one = run(pcm, phase, 3, early_events[0][7])
        assert one_regular == ordinary and one_early == early_events[:1] and one[5:] == off[5:]
print('PASS: 12 OP25 phase/polarity cases; exact ordinary frames/state/statuses with witness on/off; 21-symbol early delivery; per-push opt-in')

for middle in (foreign, voice, wire(bad_nid=True)):
    pcm = waveform([clean] * 6 + [middle] + [clean] * 5)
    ordinary, _, off = run(pcm, mode=0)
    regular, early_events, on = run(pcm)
    assert ordinary == regular and off[:4] == on[:4] and off[5:] == on[5:]
    low = ORIGIN + (72 * 4 + 6 * 180) * 10 + tx_delay
    raw = [row for row in early_events if low <= row[0] < low + 600]
    assert len(raw) == 1 and raw[0][3] == 0x293 and raw[0][6] == 0x701
    assert any(low <= row[0] < low + 700 and row[4] == 0 and not row[6] & 2 for row in regular)
    assert not any(low <= row[0] < low + 700 and row[6] & 2 for row in regular)
    if middle == foreign:
        following = [row for row in early_events if low + 1800 <= row[0] < low + 2400]
        assert len(following) == 1 and following[0][3] == 0x2a3 and following[0][6] == 0x701
pcm = waveform([clean] * 12)
regular, early_events, stats = run(pcm, mode=4)
assert not regular and not early_events and stats[5] == 255 and stats[0] == 12
change_at = (72 * 4 * 10 + 6 * 1800 + tx_delay) // 6
for mode in (5, 6):
    regular, early_events, stats = run(pcm, mode=mode, change_at=change_at)
    assert stats[2] == 1 and early_events
    cut = ORIGIN + change_at * 6
    before = [row for row in early_events if row[0] < cut]
    after = [row for row in early_events if row[0] > cut]
    assert before and after and after[0][2] > before[-1][2]
    assert all(row[1] == (12 if mode == 6 else 11) for row in after)
print(f'PASS: inherited CRC context, new NAC, voice DUID, failed/recovered NID, loss/gap/epoch/reset, no early-only selection; demod state unchanged {state_bytes} bytes')
