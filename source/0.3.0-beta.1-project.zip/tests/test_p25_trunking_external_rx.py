"""Split receiver transport, native packet qualification and source isolation; no RF."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import test_hotspot_p25_access as ACCESS

TOOL = ACCESS.TOOL
RX = TOOL.EXTERNAL_RX
SESSION = "1234567890abcdef1234567890abcdef"
SECONDARY = ACCESS.VERSION.decode()
RID, TG = 0x123456, 10


class ExternalReceiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames, cls.metadata = TOOL.CC.GENERATOR.make_fixture(
            control_frequency=440075000, voice_frequency=440087500, repetitions=1)
        cls.site = TOOL.site_only_frame(cls.frames, cls.metadata)
        folder = TOOL.ROOT / "build/test-p25-external-rx"
        folder.mkdir(parents=True, exist_ok=True)
        library = folder / ("decoder.dll" if sys.platform == "win32" else "decoder.so")
        command = ["gcc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-shared"]
        if sys.platform != "win32":
            command.append("-fPIC")
        subprocess.run(command + ["-Isrc/firmware", "src/firmware/p25_rx.c", "src/firmware/p25_tsdu.c",
                                   "-o", str(library)], cwd=TOOL.ROOT, check=True)
        cls.decoder = TOOL.NativeDecoder(library)
        cls.reference = TOOL.CC.GENERATOR.load_reference()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name).resolve() / "receive.ndjson"
        self.path.touch()
        self.clock, self.wall = ACCESS.Clock(), ACCESS.Clock()
        self.wall.value = 1700000000.0
        self.feed = RX.FileFeed(self.path, SESSION, clock=self.clock, wall_clock=self.wall)

    def row(self, sequence=1, wire=None, **changes):
        row = dict(schema=RX.SCHEMA, session_id=SESSION, source_id=RX.SOURCE_ID,
                   receive_frequency_hz=445075000,
                   modem_description=RX.MODEM_DESCRIPTION, source_sequence=sequence,
                   source_received_monotonic=10.0 + sequence / 10,
                   received_epoch=1600000000.0 + sequence / 10,
                   forwarded_epoch=self.wall(), wire_hex=(wire or TOOL.MODEM.packet(0x32)).hex())
        row.update(changes)
        return row

    def append(self, *rows):
        with self.path.open("ab") as stream:
            for row in rows:
                stream.write((json.dumps(row) + "\n").encode())

    def wire(self, opcode, argument, *, nac=0x293):
        frame, _ = TOOL.CC.GENERATOR.encode_tsdu(self.reference, nac, [(opcode, argument)])
        return TOOL.MODEM.packet(0x30, b"\1" + frame)

    def reset(self, duid=3, *, flag=1, rssi=False):
        payload = bytearray(216)
        payload[7] = duid
        return TOOL.MODEM.packet(0x31, bytes((flag,)) + bytes(payload) + (b"\0\0" if rssi else b""))

    def actor(self, *, rearm="loss", attach=True):
        options = (dict(attach_call=True, max_responses=3, attach_options=0) if attach else
                   dict(registration_acceptance_only=True, affiliation="timeout", voice="timeout", max_responses=1))
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
                                  registration_rearm=rearm, **options)
        actor.arm(self.clock())
        return actor

    def test_partial_lines_and_exact_duplicates_are_incremental_and_idempotent(self):
        row = self.row()
        encoded = (json.dumps(row) + "\n").encode()
        self.path.write_bytes(encoded[:80])
        self.assertEqual(self.feed.poll(), [])
        with self.path.open("ab") as stream:
            stream.write(encoded[80:])
        events = self.feed.poll()
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].wire, TOOL.MODEM.packet(0x32))
        self.assertEqual(events[0].received_at, self.clock())
        self.append(row, self.row(2))
        self.assertEqual([event.sequence for event in self.feed.poll()], [2])
        self.assertEqual(self.feed.summary()["duplicates"], 1)
        self.assertFalse(self.feed.summary()["rf_timing_measured"])

    def test_primary_clock_is_diagnostic_while_secondary_delivery_must_be_fresh(self):
        self.append(self.row(received_epoch=-500000000.0, source_received_monotonic=0.001))
        self.assertEqual(len(self.feed.poll()), 1)
        for delta in (-2.01, 0.051):
            row = self.row(2, forwarded_epoch=self.wall() + delta)
            with self.subTest(delta=delta), self.assertRaises(ValueError):
                self.feed._event(row)

    def test_source_session_identity_clock_and_wire_are_checked(self):
        changes = (dict(schema="other"), dict(session_id="a" * 32), dict(source_id="secondary-192.0.2.11"),
                   dict(receive_frequency_hz=440075000), dict(receive_frequency_hz=445075000.0),
                   dict(receive_frequency_hz=None),
                   dict(modem_description=SECONDARY), dict(source_sequence=True), dict(source_sequence=0),
                   dict(source_sequence=2), dict(received_epoch=float("nan")),
                   dict(source_received_monotonic=True), dict(forwarded_epoch=float("inf")),
                   dict(wire_hex="e00332FF"), dict(wire_hex="e00330"),
                   dict(wire_hex=TOOL.MODEM.packet(1, bytes(10)).hex()), dict(wire_hex="e00432"))
        for change in changes:
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.feed._event(self.row(**change))
        first = self.row()
        self.assertIsNotNone(self.feed._event(first))
        self.assertIsNone(self.feed._event(first))
        with self.assertRaises(ValueError):
            self.feed._event(self.row(wire=self.reset()))
        with self.assertRaises(ValueError):
            self.feed._event(self.row(3))
        with self.assertRaises(ValueError):
            self.feed._event(self.row(2, source_received_monotonic=1))

    def test_new_empty_regular_file_and_finite_input_bounds_are_enforced(self):
        self.path.write_bytes(b"old\n")
        with self.assertRaises(ValueError):
            RX.FileFeed(self.path, SESSION)
        self.path.write_bytes(b"x" * (RX.MAX_LINE + 1))
        with self.assertRaises(ValueError):
            self.feed.poll()
        self.path.write_bytes(b"")
        with self.assertRaises(RuntimeError):
            self.feed.poll()
        replacement = self.path.with_suffix(".new")
        replacement.touch()
        replacement.replace(self.path)
        with self.assertRaises(RuntimeError):
            self.feed.poll()

    def test_native_attach_chain_uses_only_primary_events_but_keeps_secondary_raw(self):
        actor = self.actor(rearm="reviewed-reset-or-loss")
        records = []
        link = TOOL.CaptureLink(ACCESS.Serial(self.clock), self.site, records.append,
                                clock=self.clock, sleep=self.clock.sleep,
                                responder=actor, external_receive=self.feed)
        self.assertEqual(link.version(), SECONDARY)
        self.assertEqual(actor.modem_description, RX.MODEM_DESCRIPTION)
        sequence = 0
        for opcode, argument, stage in (
                (0x2C, 0xABCDE << 36 | 0x123 << 24 | RID, "registration"),
                (0x28, 0x123 << 40 | TG << 24 | RID, "affiliation"),
                (0x00, TG << 24 | RID, "voice")):
            request = self.wire(opcode, argument)
            # A valid matching request and reset from the CC modem cannot drive
            # the external responder or release its pending primary response.
            link.dispatcher.feed(request + self.reset())
            link.drain()
            self.assertEqual(actor.requests_matched, sequence // 2)
            self.append(self.row(sequence + 1, request), self.row(sequence + 2, self.reset()))
            sequence += 2
            link.drain()
            response = actor.next_response(self.clock(), self.clock())
            self.assertIsNotNone(response)
            self.assertEqual(response.stage, stage)
            link.send_response(response)
            actor.sent(response, self.clock())
            self.clock.value += 0.1
        self.assertTrue(actor.summary()["exchange_complete"])
        self.assertEqual((actor.responses_sent, actor.grants_sent), (3, 1))
        self.assertEqual(actor.summary()["receive_source_id"], RX.SOURCE_ID)
        self.assertTrue(any(row.get("source_id") == "secondary-192.0.2.11"
                            and row["responder_input"] is False for row in records))
        primary = [row for row in records if row.get("responder_input")]
        self.assertEqual(len(primary), 6)
        self.assertTrue(all(row["external_receive"]["modem_description"] == RX.MODEM_DESCRIPTION for row in primary))
        resets = [row["modem_receiver_reset"] for row in primary if "modem_receiver_reset" in row]
        self.assertEqual(len(resets), 3)
        self.assertTrue(all(row["source_commit"] == "7e16099" and not row["air_validated"] for row in resets))
        analysis = TOOL.analyse(records, self.decoder)
        self.assertEqual(len(analysis["events"]), len(records))
        self.assertEqual(sum(row.get("responder_input", False) and "candidate_isp" in row
                             for row in analysis["events"]), 3)

    def test_primary_reset_never_rearms_secondary_or_reverse(self):
        request = self.wire(0x2C, 0xABCDE << 36 | 0x123 << 24 | RID)
        external = self.actor(rearm="reviewed-reset-or-loss", attach=False)
        external.bind_external_receiver(RX.MODEM_DESCRIPTION)
        primary_request = self.feed._event(self.row(1, request))
        primary_reset = self.feed._event(self.row(2, self.reset()))
        external.observe(primary_request)
        with self.assertRaises(RuntimeError):
            external.observe(TOOL.MODEM.Event(2, self.clock(), self.reset()))
        external.observe(primary_reset)
        self.assertIsNotNone(external.next_response(self.clock(), self.clock()))
        self.assertIsNone(TOOL.MODEM.receiver_framing_reset(primary_reset, RX.MODEM_DESCRIPTION))
        self.assertIsNone(RX.receiver_framing_reset(TOOL.MODEM.Event(2, self.clock(), self.reset()), SECONDARY))
        self.assertIsNone(RX.receiver_framing_reset(primary_reset, SECONDARY))
        local = self.actor(rearm="reviewed-reset-or-loss", attach=False)
        local.bind_modem(SECONDARY)
        local.observe(TOOL.MODEM.Event(1, self.clock(), request))
        with self.assertRaises(RuntimeError):
            local.observe(primary_reset)
        self.assertIsNone(local.next_response(self.clock(), self.clock()))
        local.observe(TOOL.MODEM.Event(2, self.clock(), self.reset()))
        self.assertIsNotNone(local.next_response(self.clock(), self.clock()))
        with self.assertRaises(RuntimeError):
            external.bind_modem(SECONDARY)

    def test_reviewed_reset_requires_explicit_policy_and_exact_own_envelope(self):
        actor = self.actor(attach=False)
        actor.bind_external_receiver(RX.MODEM_DESCRIPTION)
        actor.observe(self.feed._event(self.row(1, self.wire(0x2C, 0xABCDE << 36 | 0x123 << 24 | RID))))
        reset = self.feed._event(self.row(2, self.reset()))
        actor.observe(reset)
        self.assertIsNone(actor.next_response(self.clock(), self.clock()))
        actor.observe(self.feed._event(self.row(3)))
        self.assertIsNotNone(actor.next_response(self.clock(), self.clock()))
        for duid, flag, rssi, expected in ((3, 0, False, True), (15, 1, True, True),
                                           (5, 1, False, False), (3, 2, False, False)):
            event = RX.ReceiveEvent(1, self.clock(), self.reset(duid, flag=flag, rssi=rssi), self.row())
            self.assertEqual(RX.receiver_framing_reset(event, RX.MODEM_DESCRIPTION) is not None, expected)

    def test_bad_native_crc_or_wrong_identity_does_not_queue_response(self):
        for bad in (False, True):
            actor = self.actor(attach=False)
            actor.bind_external_receiver(RX.MODEM_DESCRIPTION)
            wire = self.wire(0x2C, 0xABCDE << 36 | 0x123 << 24 | (RID + 1))
            if bad:
                wire = TOOL.MODEM.packet(0x30, b"\1" + bytes(45))
            event = RX.ReceiveEvent(1, self.clock(), wire, self.row())
            actor.observe(event)
            self.assertEqual(actor.requests_matched, 0)
            self.assertIsNone(actor.pending)

    def test_rejected_header_own_reset_clears_busy_without_authorizing_response(self):
        for rearm in ("loss", "reviewed-reset-or-loss"):
            for bad in (False, True):
                with self.subTest(rearm=rearm, bad_crc=bad):
                    # Keep each source feed independent and contiguous.
                    source = RX.FileFeed(self.path, SESSION, clock=self.clock, wall_clock=self.wall)
                    actor = self.actor(rearm=rearm)
                    actor.bind_external_receiver(RX.MODEM_DESCRIPTION)
                    rejected = (TOOL.MODEM.packet(0x30, b"\1" + bytes(45)) if bad else
                                self.wire(0x2C, 0xABCDE << 36 | 0x123 << 24 | (RID + 1)))
                    actor.observe(source._event(self.row(1, rejected)))
                    self.assertTrue(actor.rx_busy)
                    self.assertIsNone(actor.pending)
                    # The secondary's reset cannot release a primary header.
                    with self.assertRaises(RuntimeError):
                        actor.observe(TOOL.MODEM.Event(2, self.clock(), self.reset()))
                    self.assertTrue(actor.rx_busy)
                    actor.observe(source._event(self.row(2, self.reset())))
                    self.assertFalse(actor.rx_busy)
                    self.assertIsNone(actor.header_at)
                    self.assertIsNone(actor.rearm_evidence_sequence)
                    self.assertIsNone(actor.next_response(self.clock() + 1.5, self.clock() + 1.5))
                    self.assertEqual((actor.requests_matched, actor.responses_sent, actor.grants_sent), (0, 0, 0))
                    request = self.wire(0x2C, 0xABCDE << 36 | 0x123 << 24 | RID)
                    actor.observe(source._event(self.row(3, request)))
                    actor.observe(source._event(self.row(4)))
                    response = actor.next_response(self.clock(), self.clock())
                    self.assertIsNotNone(response)
                    self.assertEqual(response.stage, "registration")
                    self.assertEqual(actor.requests_matched, 1)


if __name__ == "__main__":
    unittest.main()
