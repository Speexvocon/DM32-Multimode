// SPDX-License-Identifier: GPL-3.0-or-later
// Canonical schema2 bytes and schema-isolated borrowed storage; no RF/clock.
#define main borrowed_stream_test_main
#include "test_p25_rx_stream.c"
#undef main
#include "p25_rx_early.h"
_Static_assert(P25_RX_STREAM_EARLY_MARK_BYTES==P25_RX_EARLY_EVENT_BYTES
    &&P25_RX_STREAM_EARLY_MAX_SAMPLES==P25_RX_EARLY_MAX_SAMPLES,"Early encoder/storage bounds differ");
static p25_rx_origin_event event(void) {
    p25_rx_origin_event e={.event_tick=0x1234u,.cpu_us=0x10203040u,
        .stream_epoch=0x50607080u,.lane_epoch=0x90abcdefu,
        .read_begin_us=0x10202ff0u,.read_end_us=0x10203000u,
        .origin_irq_us=0x101fb000u,.origin_irq_count=4u,
        .delivery_input_ordinal=798u,.chunk_first_sample=784u,.nac=0x293u,
        .type=P25_RX_EARLY_STATUS,.duid=7u,.status=0u,.lane=9u,
        .evidence=P25_RX_ORIGIN_SELECTED};return e;
}
static void refused(p25_rx_origin_event e) {
    unsigned char out[64],before[64];memset(out,0xa5,sizeof out);memcpy(before,out,sizeof out);
    p25_rx_origin_event original=e;
    assert(!p25_rx_early_encode(out,&e)&&!memcmp(before,out,sizeof out)&&!memcmp(&original,&e,sizeof e));
}
static void encoding(void) {
    unsigned char expected[64]={
        0x34,0x12,0,0,0,0,0,0, 0x40,0x30,0x20,0x10, 0x80,0x70,0x60,0x50,
        0xef,0xcd,0xab,0x90, 0xf0,0x2f,0x20,0x10, 0,0x30,0x20,0x10, 0,0xb0,0x1f,0x10,
        4,0,0,0, 0x10,3,0x93,2, 4,7,0,9, 0,0,1,0,
        0,0,0,0,0,0,0,0,0,0,0,0, 0x1e,3,0,0};
    unsigned char out[64],base[64];p25_rx_origin_event e=event();
    for(unsigned status=0;status<=3u;++status) {
        e.status=(uint8_t)status;expected[42]=(unsigned char)status;
        assert(p25_rx_early_encode(out,&e)&&!memcmp(out,expected,sizeof out));
        assert(!p25_rx_origin_encode(base,&e)); // Existing schema1 never accepts type4.
    }
    union {p25_rx_origin_event event;unsigned char bytes[64];} alias;
    alias.event=e;assert(p25_rx_early_encode(alias.bytes,&alias.event)&&!memcmp(alias.bytes,expected,64));
    assert(!p25_rx_early_encode(NULL,&e)&&!p25_rx_early_encode(out,NULL));
    e=event();e.read_begin_us=UINT32_MAX-7u;e.read_end_us=2;e.cpu_us=19;
    assert(p25_rx_early_encode(out,&e)&&out[20]==248u&&out[24]==2u&&out[8]==19u);

    // Ordinary schema2 events remain byte-for-byte canonical schema1 within
    // the tighter source bound; the wrapper cannot admit ordinary STATUS0.
    e=event();e.type=P25_RX_ORIGIN_STATUS;e.status=3;e.evidence=3;
    assert(p25_rx_origin_encode(base,&e)&&p25_rx_early_encode(out,&e)&&!memcmp(base,out,64));
    e.status=0;refused(e);
    e=event();e.type=P25_RX_ORIGIN_UNIT;e.status=0;e.lane=255;e.evidence=4;
    e.block_descriptor=0x10;e.event_tick=(uint64_t)e.delivery_input_ordinal*6u;
    for(unsigned i=0;i<12u;++i)e.data[i]=(uint8_t)(0x80u+i);
    for(unsigned count=1;count<=3u;++count)for(unsigned index=0;index<count;++index) {
        e.block_descriptor=(uint8_t)(count<<4|index);
        assert(p25_rx_origin_encode(base,&e)&&p25_rx_early_encode(out,&e)&&!memcmp(base,out,64));
    }
    // All ordinary nonfault records, not just EARLY, share the4096 bound.
    for(unsigned kind=1;kind<=4u;++kind) {
        if(kind==3u)continue;
        e=event();e.type=(uint8_t)kind;e.status=1;
        if(kind==2u) {e.status=0;e.lane=255;e.evidence=4;e.block_descriptor=0x10;}
        e.chunk_first_sample=4080;e.delivery_input_ordinal=4095;e.origin_irq_count=16;
        e.event_tick=4095u*6u;assert(p25_rx_early_encode(out,&e));
        e.chunk_first_sample=4096;e.delivery_input_ordinal=4096;e.origin_irq_count=17;
        e.event_tick=4096u*6u;refused(e);
        if(kind!=4u)assert(p25_rx_origin_encode(base,&e));
    }
    e=(p25_rx_origin_event){.type=P25_RX_ORIGIN_FAULT,.lane=255,.cpu_us=UINT32_MAX,
        .stream_epoch=31,.lane_epoch=42,.data={P25_RX_ORIGIN_CONTEXT_LOST}};
    for(unsigned reason=1;reason<=6u;++reason) {e.data[0]=(uint8_t)reason;
        assert(p25_rx_origin_encode(base,&e)&&p25_rx_early_encode(out,&e)&&!memcmp(base,out,64));}
}
static void encoding_refusals(void) {
    p25_rx_origin_event e;
#define BAD(member,value) do {e=event();e.member=(value);refused(e);} while(0)
    BAD(type,0);BAD(type,5);BAD(status,4);BAD(evidence,0);BAD(evidence,2);BAD(evidence,3);BAD(evidence,5);
    BAD(lane,10);BAD(lane,255);BAD(duid,5);BAD(nac,0x1000);BAD(source_flags,1);BAD(block_descriptor,0x10);
    BAD(data[0],1);BAD(data[11],1);BAD(chunk_first_sample,785);BAD(chunk_first_sample,4096);
    BAD(delivery_input_ordinal,783);BAD(delivery_input_ordinal,800);BAD(delivery_input_ordinal,4096);
    BAD(origin_irq_count,3);BAD(event_tick,798u*6u+1u);
    BAD(read_end_us,0x10202fefu);BAD(cpu_us,0x10202fffu);
#undef BAD
}
static void storage(void) {
    struct {unsigned char before[16],ring[8192],middle[16],ledger[15360],after[16];} memory;
    p25_rx_stream s={0};memset(&memory,0xa5,sizeof memory);
    assert(p25_rx_stream_early_start(&s,memory.ring,8192,memory.ledger,15360,4096,2000,17,UINT32_MAX-7u));
    assert(s.marker_bytes==64&&s.marker_schema==2&&s.limit_halves==16);
    unsigned char bytes[64],old[32]={0};p25_rx_origin_event e=event();assert(p25_rx_early_encode(bytes,&e));
    assert(!p25_rx_stream_early_marker(&s,bytes));
    p25_rx_stream_irq(&s,1,UINT32_MAX-7u);
    assert(!p25_rx_stream_marker(&s,old)&&!p25_rx_stream_origin_marker(&s,bytes)&&!s.markers);
    unsigned char halves[3072],retained[12288];memcpy(halves,memory.ledger,sizeof halves);
    for(unsigned i=0;i<192u;++i) {bytes[8]=(unsigned char)i;
        assert(p25_rx_stream_early_marker(&s,bytes)&&!memcmp(memory.ledger+3072u+i*64u,bytes,64));}
    assert(!memcmp(halves,memory.ledger,sizeof halves));memcpy(retained,memory.ledger+3072u,sizeof retained);
    s.state=P25_RX_STREAM_DRAINING;
    assert(!p25_rx_stream_early_marker(&s,bytes)&&s.state==P25_RX_STREAM_FAULT
        &&(s.faults&P25_RX_STREAM_RING_FULL)&&s.markers==192);
    assert(!memcmp(retained,memory.ledger+3072u,sizeof retained)&&!p25_rx_stream_early_marker(&s,bytes));
    assert(memory.before[0]==0xa5&&memory.middle[15]==0xa5&&memory.after[0]==0xa5);
    for(unsigned schema=0;schema<=2u;++schema) {
        s.state=P25_RX_STREAM_CANCELLED;
        bool okay=schema==0?p25_rx_stream_start(&s,memory.ring,8192,memory.ledger,15360,16384,2000,19,0)
            :schema==1?p25_rx_stream_origin_start(&s,memory.ring,8192,memory.ledger,15360,8192,2000,19,0)
            :p25_rx_stream_early_start(&s,memory.ring,8192,memory.ledger,15360,4096,2000,19,0);
        assert(okay&&s.marker_schema==schema);p25_rx_stream_irq(&s,1,0);
        p25_rx_stream before=s;unsigned char ledger[15360];memcpy(ledger,memory.ledger,sizeof ledger);
        if(schema!=0)assert(!p25_rx_stream_marker(&s,old));
        if(schema!=1)assert(!p25_rx_stream_origin_marker(&s,bytes));
        if(schema!=2)assert(!p25_rx_stream_early_marker(&s,bytes));
        assert(!memcmp(&before,&s,sizeof s)&&!memcmp(ledger,memory.ledger,sizeof ledger));
        assert(!p25_rx_stream_early_start(&s,memory.ring,8192,memory.ledger,15360,4096,2000,19,0));
        assert(!memcmp(&before,&s,sizeof s)&&!memcmp(ledger,memory.ledger,sizeof ledger));
    }
    s.state=P25_RX_STREAM_CANCELLED;p25_rx_stream before=s;
    for(unsigned samples=4097;samples<=8192;samples+=255) {
        assert(!p25_rx_stream_early_start(&s,memory.ring,8192,memory.ledger,15360,samples,2000,19,0));
        assert(!memcmp(&before,&s,sizeof s));}
}
static void early_clock_wrap(void) {
    fixture f;memset(&f,0,sizeof f);uint32_t origin=UINT32_MAX-10000u;
    f.now=f.origin=origin;
    assert(p25_rx_stream_early_start(&f.stream,f.ring,8192,f.ledger,15360,4096,2000,17,origin));
    p25_rx_stream_irq(&f.stream,1,origin);p25_rx_progress_io io=io_for(&f);unsigned completed=0;
    for(unsigned tick=500;p25_rx_stream_active(&f.stream);tick+=500u) {
        assert(tick<600000u);f.now=origin+tick;
        if(tick/32000u>completed) {fill(&f,completed,256);completed=tick/32000u;
            p25_rx_stream_irq(&f.stream,completed%2u?2u:1u,f.now);}
        if(completed<16u)fill(&f,completed,tick%32000u/125u);
        (void)p25_rx_stream_step(&f.stream,&io,f.now);consume(&f);
    }
    consume(&f);p25_rx_stream_finalize(&f.stream);
    assert(f.stream.state==P25_RX_STREAM_COMPLETE&&f.stream.verified==4096&&!f.stream.faults);
    assert(f.stream.marker_bytes==64&&f.stream.marker_schema==2);
    for(unsigned index=0;index<16u;++index) {p25_rx_stream_half half;
        assert(p25_rx_stream_half_read(&f.stream,index,&half)&&half.verified_chunks==16
            &&half.origin_irq_us==origin+index*32000u);}
}
int main(void) {
    encoding();encoding_refusals();storage();early_clock_wrap();
    puts("RX early canonical64 type4,4096 bound, schema isolation and borrowed storage: PASS");return 0;
}
