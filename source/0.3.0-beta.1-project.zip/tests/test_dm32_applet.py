"""Offline compiler/package checks and fake-serial transactional upload tests."""
from collections import deque
import contextlib
import importlib.util
import io
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import zlib

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('dm32_applet',ROOT/'scripts/dm32_applet.py')
applet=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=applet;SPEC.loader.exec_module(applet)
CLI_SPEC=importlib.util.spec_from_file_location('dm32_applet_cli',ROOT/'scripts/dm32-applet.py')
cli=importlib.util.module_from_spec(CLI_SPEC);CLI_SPEC.loader.exec_module(cli)


def repair_crc(data):
    data=bytearray(data);struct.pack_into('<I',data,60,zlib.crc32(data[:60]+data[64:])&0xffffffff);return bytes(data)


class FakePort:
    def __init__(self,**kwargs):
        self.options=kwargs;self.dtr=True;self.rts=True;self.port=None;self.opened=False;self.closed=False
        self.writes=[];self.responses=deque();self.image=bytearray();self.expected_size=0;self.upload_crc=0
        self.committed=False;self.aborted=False;self.foreign=False;self.error_offset=None
        self.drop_offset=None;self.dropped_ack=False;self.short_write=False
    def open(self):
        assert self.dtr is False and self.rts is False and self.port=='FAKE';self.opened=True
    def close(self):self.closed=True
    def reply(self,line):self.responses.append((line+'\r\n').encode('ascii'))
    def write(self,data):
        self.writes.append(data)
        if self.short_write:return len(data)-1
        line=data.decode('ascii').rstrip('\n');parts=line.split()
        if line=='APP STORE STATUS':
            self.reply('APP STORE slots=8 bank_bytes=65536 partition_bytes=1048576 max_package=32768')
            for slot in range(1,9):self.reply(f'APP SLOT {slot} EMPTY')
            self.reply('APP OK STORE STATUS')
        elif parts[:3]==['APP','INSTALL','BEGIN']:
            if self.foreign:self.reply('APP ERROR foreign partition; not modified')
            else:
                self.expected_size=int(parts[4]);self.upload_crc=int(parts[5]);self.image.clear()
                self.reply('BOOT incidental line');self.reply('APP EVENT unrelated')
                self.reply('APP OK INSTALL BEGIN')
        elif parts[:3]==['APP','INSTALL','DATA']:
            offset=int(parts[3]);chunk=bytes.fromhex(parts[4])
            if self.error_offset is not None and offset>=self.error_offset:self.reply('APP ERROR data readback failed')
            else:
                if offset<len(self.image):assert self.image[offset:offset+len(chunk)]==chunk
                else:assert offset==len(self.image);self.image.extend(chunk)
                if offset==self.drop_offset and not self.dropped_ack:self.dropped_ack=True
                else:self.reply(f'APP OK INSTALL DATA {offset+len(chunk)}')
        elif line=='APP INSTALL COMMIT':
            assert len(self.image)==self.expected_size and zlib.crc32(self.image)&0xffffffff==self.upload_crc
            applet.validate_package(self.image);self.committed=True;self.reply('APP OK INSTALL COMMIT')
        elif line=='APP INSTALL ABORT':self.aborted=True;self.reply('APP OK INSTALL ABORT')
        elif parts[:2]==['APP','RUN']:self.reply('APP OK RUN '+parts[2])
        elif parts[:2]==['APP','REMOVE']:self.reply('APP OK REMOVE '+parts[2])
        elif line=='APP STOP':self.reply('APP STOPPED; normal radio operation restored')
        else:raise AssertionError('Unexpected command: '+line)
        return len(data)
    def readline(self,size):
        if not self.responses:return b''
        line=self.responses.popleft()
        if len(line)>size:self.responses.appendleft(line[size:]);return line[:size]
        return line


class Clock:
    def __init__(self):self.now=0
    def __call__(self):self.now+=.01;return self.now


class AppletCompilerTest(unittest.TestCase):
    def test_example_packages_are_canonical_and_small(self):
        for source in sorted((ROOT/'examples/applets').glob('*.dappsrc')):
            with self.subTest(source=source.name):
                package=applet.load_package(source)
                self.assertEqual(applet.validate_package(package.data),package)
                self.assertLess(len(package.data),1024)
                self.assertEqual(package.data[:8],b'DAPP\x01\0@\0')
                self.assertEqual(package.crc32,zlib.crc32(package.data[:60]+package.data[64:])&0xffffffff)
                self.assertNotEqual(package.crc32,zlib.crc32(package.data)&0xffffffff)

    def test_all_operations_labels_and_literal_deduplication(self):
        source='''name "Instruction test"
caps same serial display key
title "Repeated text"
print "Repeated text"
set r7 4294967295
add r7 0x1
same 162400000
await confirmed 1000 r2
await any 2000 r3
get r0 event
get r1 key
get r2 uptime_ms
get r3 headers
get r4 event_sequence
if r0 == 0 goto finish
if r1 != 1 goto finish
print r7
last
show same
yield
wait 60000
goto finish
finish:
end
'''
        package=applet.compile_source(source)
        self.assertEqual(package.capabilities,15)
        self.assertEqual(package.strings_size,len('Repeated text'))
        instructions=[applet.INSTRUCTION.unpack_from(package.data,64+i*8) for i in range(package.code_count)]
        self.assertEqual(instructions[4],(10,0,0,162400000))
        self.assertEqual(instructions[5],(15,2,2,1000))
        self.assertEqual(instructions[6],(15,3,15,2000))
        self.assertEqual(instructions[12],(3,0,20,0))
        self.assertEqual(instructions[13],(4,1,20,1))
        self.assertEqual(instructions[19],(5,0,20,0))
        self.assertEqual(instructions[20],(0,0,0,0))
        none=applet.compile_source('name "Clock"\ncaps none\nget r0 uptime_ms\nend')
        self.assertEqual(none.capabilities,0)

    def test_invalid_source_has_no_implicit_permissions(self):
        bad=['print "missing declarations"','name "X"\ncaps tx\nend',
            'name "X"\ncaps none\nsame 162550000','name "X"\ncaps same\nprint "serial"',
            'name "X"\ncaps serial\ntitle "screen"','name "X"\ncaps serial\nget r0 key',
            'name "X"\ncaps same\nawait any 1000','name "X"\ncaps same\nawait key 1000',
            'name "X"\ncaps none\nget r0 headers','name "X"\ncaps none\nset r8 1',
            'name "X"\ncaps none\nset r0 -1','name "X"\ncaps none\nset r0 4294967296',
            'name "X"\ncaps none\nwait 0','name "X"\ncaps none\nwait 60001',
            'name "X"\ncaps same\nsame 162412500','name "X"\ncaps same\nsame 162.550',
            'name "X"\ncaps none\ngoto absent','name "X"\ncaps none\ngoto finish\nfinish:',
            'name "X"\ncaps none\nloop:\nyield\nloop:\nend','name "X"\nname "Y"\ncaps none\nend',
            'name "X"\ncaps none none\nend','name "X"\ncaps none\nwrite 0x1234 1',
            'name "X"\ncaps serial\nprint ""','name "X"\ncaps serial\nprint "unterminated',
            'name "X"\ncaps none\nend\ncaps serial','name "X"\ncaps none\nget r0 unknown',
            'name "'+'A'*24+'"\ncaps none\nend','name "Unicode \u2603"\ncaps none\nend',
            'name "X"\ncaps serial\nprint "'+'A'*96+'"','name "X"\ncaps none']
        for source in bad:
            with self.subTest(source=source):
                with self.assertRaises(applet.AppletError):applet.compile_source(source)

    def test_source_and_package_limits(self):
        with self.assertRaises(applet.AppletError):applet.compile_source('x'*262145)
        source='name "Large"\ncaps serial\n'+'\n'.join('print "'+f'{index:04d}'+'X'*91+'"' for index in range(400))
        with self.assertRaisesRegex(applet.AppletError,'exceeds'):applet.compile_source(source)
        with self.assertRaises(applet.AppletError):applet.validate_package(b'DAPP')
        with self.assertRaises(applet.AppletError):applet.validate_package(bytes(32769))

    def test_tampered_headers_operands_caps_and_strings_are_rejected(self):
        source='name "Validation"\ncaps same serial display key\nprint "Literal"\nset r0 1\nawait any 1\ngoto done\ndone:\nend'
        valid=applet.compile_source(source).data
        mutations=[]
        def mutate(offset,encoded):
            data=bytearray(valid);data[offset:offset+len(encoded)]=encoded;mutations.append(repair_crc(data))
        mutate(0,b'FAIL');mutate(4,b'\x02\0');mutate(6,b'\x20\0');mutate(8,struct.pack('<I',len(valid)+1))
        mutate(12,struct.pack('<I',0x100));mutate(16,struct.pack('<I',72));mutate(20,b'\0\0')
        mutate(22,b'\xff\xff');mutate(24,struct.pack('<I',80));mutate(56,b'\x01\0\0\0')
        mutate(32,b'\0');mutate(55,b'X');mutate(64,b'\xff');mutate(65,b'\x01')
        mutate(66,b'\xff\xff');mutate(68,struct.pack('<I',0xffffffff));mutate(73,b'\x08')
        mutate(74,b'\x01\0');mutate(82,b'\0\0');mutate(84,b'\0\0\0\0')
        mutate(90,b'\xff\xff');mutate(12,b'\0\0\0\0');mutate(len(valid)-1,b'\x1b')
        corrupt=bytearray(valid);corrupt[-1]^=1;mutations.append(bytes(corrupt))
        for index,data in enumerate(mutations):
            with self.subTest(index=index):
                with self.assertRaises(applet.AppletError):applet.validate_package(data)

    def test_offline_cli_and_invalid_install_never_open_port(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)/'counter.dappsrc';target=Path(directory)/'counter.dapp'
            source.write_text('name "Test"\ncaps serial\nprint "Hello"\nend',encoding='utf-8')
            with patch.object(cli,'open_port',side_effect=AssertionError('port accessed')):
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(cli.main(['compile',str(source),'-o',str(target)]),0)
                    self.assertEqual(cli.main(['inspect',str(target)]),0)
                target.write_bytes(b'invalid binary\0')
                with contextlib.redirect_stderr(io.StringIO()):self.assertEqual(cli.main(['install',str(target),'--slot','1']),1)


class AppletSerialTest(unittest.TestCase):
    def setUp(self):
        self.package=applet.compile_source('name "Upload Test"\ncaps serial\nprint "Hello"\nend')
        self.port=FakePort();self.lines=[];self.client=applet.AppletClient(self.port,self.lines.append,Clock())

    def test_open_keeps_control_lines_low_and_has_no_automatic_commands(self):
        port=applet.open_port('FAKE',types.SimpleNamespace(Serial=FakePort))
        self.assertTrue(port.opened);self.assertEqual(port.writes,[])
        self.assertEqual(port.options,{'port':None,'baudrate':115200,'timeout':.1,'write_timeout':2})

    def test_install_chunks_crc_and_preserves_async_lines(self):
        self.client.install(2,self.package)
        self.assertTrue(self.port.committed);self.assertFalse(self.port.aborted)
        self.assertEqual(self.port.image,self.package.data)
        self.assertIn('BOOT incidental line',self.lines);self.assertIn('APP EVENT unrelated',self.lines)
        chunks=[line.decode().split() for line in self.port.writes if line.startswith(b'APP INSTALL DATA ')]
        self.assertTrue(chunks);self.assertTrue(all(1<=len(bytes.fromhex(words[4]))<=32 for words in chunks))
        self.assertFalse(any(b'FORMAT' in line or line.startswith(b'APP RUN') for line in self.port.writes))

    def test_lost_data_ack_retries_same_offset_idempotently(self):
        self.port.drop_offset=32;self.client.install(1,self.package)
        duplicates=[line for line in self.port.writes if line.startswith(b'APP INSTALL DATA 32 ')]
        self.assertEqual(len(duplicates),2);self.assertEqual(duplicates[0],duplicates[1])
        self.assertTrue(self.port.committed);self.assertEqual(self.port.image,self.package.data)

    def test_error_ack_aborts_and_never_commits(self):
        for foreign in (False,True):
            with self.subTest(foreign=foreign):
                port=FakePort();port.foreign=foreign;port.error_offset=32
                client=applet.AppletClient(port,clock=Clock())
                with self.assertRaises(applet.ProtocolError):client.install(1,self.package)
                self.assertTrue(port.aborted);self.assertFalse(port.committed)
                self.assertNotIn(b'APP INSTALL COMMIT\n',port.writes)

    def test_invalid_package_or_slot_has_no_serial_side_effect(self):
        for slot,package in ((0,self.package),(9,self.package),(True,self.package),(1,b'DAPP')):
            with self.subTest(slot=slot):
                with self.assertRaises(ValueError):self.client.install(slot,package)
        self.assertEqual(self.port.writes,[])

    def test_bounded_response_lines_and_terminal_control_sanitization(self):
        self.port.responses.append(b'X'*2048+b'\n')
        self.port.responses.append(b'\x1b[31mUntrusted\n')
        self.client.store_status()
        self.assertIn('[Oversized serial line discarded]',self.lines)
        self.assertIn('?[31mUntrusted',self.lines)
        self.assertIn('APP SLOT 8 EMPTY',self.lines)
        self.assertLessEqual(len(self.client.pending),512)

    def test_explicit_run_remove_stop_and_list_only(self):
        self.client.store_status();self.client.run(3);self.client.remove(4);self.client.stop()
        self.assertEqual(self.port.writes,[b'APP STORE STATUS\n',b'APP RUN 3\n',
            b'APP STORE STATUS\n',b'APP REMOVE 4\n',b'APP STOP\n'])

    def test_remove_from_fresh_boot_checks_storage_before_mutation(self):
        self.client.remove(2)
        self.assertEqual(self.port.writes,[b'APP STORE STATUS\n',b'APP REMOVE 2\n'])
        self.assertIn('APP SLOT 8 EMPTY',self.lines)
        self.port.writes.clear()
        with self.assertRaises(ValueError):self.client.remove(0)
        self.assertEqual(self.port.writes,[])

    def test_missing_reply_and_incomplete_write_abort(self):
        class SilentPort(FakePort):
            def write(self,data):self.writes.append(data);return len(data)
        port=SilentPort();client=applet.AppletClient(port,clock=Clock())
        with self.assertRaises(TimeoutError):client.install(1,self.package)
        self.assertEqual(port.writes[-1],b'APP INSTALL ABORT\n')
        self.port.short_write=True
        with self.assertRaises(applet.ProtocolError):self.client.install(1,self.package)
        self.assertEqual(self.port.writes[-1],b'APP INSTALL ABORT\n')


if __name__=='__main__':unittest.main(verbosity=2)
