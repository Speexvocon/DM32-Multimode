// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_isp.h"
#include "p25_tsdu.h"
#include <string.h>

bool p25_isp_test_build(unsigned kind,uint8_t out[12],uint32_t wacn,uint16_t system,
                        uint16_t group,uint32_t rid,uint8_t options) {
    switch(kind) {
    case 0:return p25_trunking_isp_register(out,wacn,system,rid);
    case 1:return p25_trunking_isp_affiliate(out,system,group,rid);
    case 2:return p25_trunking_isp_group_request(out,group,rid,options);
    case 3:return p25_trunking_isp_deregister(out,wacn,system,rid);
    default:return false;
    }
}
// Stable integer bridge independent of the host C ABI's struct padding.
bool p25_osp_test_parse(const uint8_t block[12],uint32_t out[20]) {
    p25_trunking_osp value,before;memset(&value,0xa5,sizeof value);before=value;
    if(!p25_trunking_osp_parse(block,&value)) {
        // Report an internal contract failure distinctly from normal refusal.
        if(memcmp(&value,&before,sizeof value))out[19]=0xbad;
        return false;
    }
    uint32_t fields[20]={value.type,value.opcode,value.service,value.options,
        value.response,value.system,value.group,value.announcement,value.channel,
        value.source,value.target,value.assigned,value.additional,value.extended,
        value.global,value.encrypted};
    memcpy(out,fields,sizeof fields);return true;
}
bool p25_osp_test_frame(const uint8_t *frame,size_t bytes,uint32_t out[20]) {
    p25_tsdu decoded;
    return p25_tsdu_decode(frame,bytes,&decoded) && decoded.count==1u &&
           p25_osp_test_parse(decoded.block[0],out);
}
