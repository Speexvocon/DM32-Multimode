"""Host-only refusal/allowlist tests for the native RAM probe. No hardware I/O."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest import mock
import zlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('native_probe', ROOT/'scripts/native-synthesis-probe.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
spec = importlib.util.spec_from_file_location('native_fixture', ROOT/'scripts/native-synthesis-fixture.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
spec = importlib.util.spec_from_file_location('capability_helpers', ROOT/'tests/test_hrc7000_capability.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def frame_ticks(frames):
    arrays = [[base+i*step for i in range(frames)]+[0]*(64-frames)
              for base, step in ((100, 1), (1000, 10), (50, 1), (2000, 20))]
    return struct.pack('<256I', *(value for array in arrays for value in array))


def records(mode, pcm=None, frames=2, fixture_crc=0):
    samples = 160*frames if mode in (3, 4, 5) else (640 if mode == 2 else 80)
    pcm = bytes(samples*2) if pcm is None else pcm
    values = [dict(id=1, status=0, value=0x23456789, aux=0, vector=0, epc=0, epsr=0, reserved=0)]
    if mode:
        amplitudes = bytearray(136)
        struct.pack_into('<9h', amplitudes, 0, *[64 << i for i in range(9)])
        struct.pack_into('<h', amplitudes, 132, -6)
        flags = struct.pack('<56h', *([1]*37+[0]*19))
        extra = [(10, zlib.crc32(amplitudes), 0xfffffffa),
                 (11, zlib.crc32(flags), 37), (12, 0, 0)]
        if mode in (3, 4, 5):
            values_pcm = struct.unpack('<'+str(samples)+'h', pcm)
            extra += [(20, frames, fixture_crc), (21, frames*2, samples),
                      (22, max(abs(x) for x in values_pcm), sum(x != 0 for x in values_pcm)),
                      (23, sum(x in (-32768, 32767) for x in values_pcm), sum(x == 0 for x in values_pcm)),
                      (24, 1000000, 20000), (25, 60000000 if mode == 5 else 24000000, 2)]
            if mode in (4, 5):
                native_core = [1000+i*10 for i in range(frames)]
                software_core = [2000+i*20 for i in range(frames)]
                extra[-2] = (24, sum(native_core), max(native_core))
        elif mode == 2:
            first_crc = zlib.crc32(pcm)
            extra += [(16, 0, 0), (17, 0, 0), (18, 8, 640),
                      (19, first_crc, first_crc)]
        else:
            extra += [(13, 0, 0), (14, 0, 0)]
        extra += [(15, zlib.crc32(pcm), samples)]
        if mode in (4, 5):
            extra += [(31, frames, samples), (32, extra[5][1], extra[5][2]),
                      (33, extra[6][1], extra[6][2]),
                      (34, sum(software_core), max(software_core)),
                      (35, zlib.crc32(pcm), samples), (28, zlib.crc32(frame_ticks(frames)), 1024)]
        for identifier, value, aux in extra:
            values.append(dict(id=identifier, status=0, value=value, aux=aux,
                               vector=0, epc=0, epsr=0, reserved=0))
    return values


def packet(nonce=123, mode=0, recs=None, header=None, pcm=None):
    recs = records(mode, pcm) if recs is None else recs
    fields = dict(nonce=nonce, build_id=probe.BUILD_ID, mode=mode,
                  total_bytes=probe.HEADER.size+len(recs)*probe.RECORD.size+4,
                  record_count=len(recs), fatal=0, guard_mask=0x1f,
                  initial_psr=0x80000100, initial_vbr=0x30000, initial_sp=0x37f00, cpuid_words=0)
    if header:
        fields.update(header)
    body = probe.HEADER.pack(probe.MAGIC, *(fields[k] for k in probe.transport.HEADER_NAMES))
    body += b''.join(probe.RECORD.pack(*(r[k] for k in probe.transport.RECORD_NAMES)) for r in recs)
    return body+struct.pack('<I', zlib.crc32(body))


class FakePort(helpers.FakePort):
    def __init__(self):
        super().__init__()
        self.closes = 0

    def close(self):
        self.closes += 1
        super().close()


class FakeRadio(helpers.FakeRadio):
    def __init__(self, port):
        super().__init__(port)
        self.pcm = struct.pack('<80h', *range(-40, 40))
        self.unvoiced_pcm = struct.pack('<640h', *[(i % 160 - 80)*17 for i in range(640)])
        self.mixed_pcm = None
        self.mixed_pcm_override = None
        stack_guard = struct.pack('<II', 0xc0def00d, 0x13579bdf)
        self.stack_image = stack_guard+bytes([0xa5])*(8192-16)+stack_guard
        self.noise_seed = 0x1c9c  # 724 LCG draws: 84 init + eight 80-sample calls.
        self.record_change = lambda values:values
        self.jump_error = None
        self.clock_registers = {**probe.clock_guard.COLD_CLOCKS, 'UART_LCR':3, 'UART_IER':0x80,
                                'UART_MCR':0, 'CACHE_REGION':0, 'TIMER2_LOAD':0xffffffff,
                                'TIMER2_CTRL':5, 'APLL':0x85040eb2}
        self.apb_samples = [24000000]*6
        self.after_call = lambda:None

    def configure(self, board):
        super().configure(board)
        if board is None:
            self.configured = {'id':1}

    def timer_hz(self, span):
        self.ops.append(('timer_hz', span))
        return self.apb_samples.pop(0)

    def peek(self, address, count):
        if count > 512:
            raise AssertionError('RAM reads must remain within the 512-byte transfer budget')
        for key, register in {**probe.clock_guard.CLOCK_REGISTERS, **probe.clock_guard.UART_REGISTERS,
                              **probe.clock_guard.OTHER_REGISTERS}.items():
            if address == register:
                self.ops.append(('peek', address, count))
                if count != 4:
                    raise AssertionError('Clock MMIO must be read as a single exact word')
                return self.clock_registers[key].to_bytes(4, 'little')
        return super().peek(address, count)

    def jump(self, address):
        self.ops.append(('call', address))
        if self.jump_error:
            raise self.jump_error
        args = bytes(self.memory[probe.ARGS+i] for i in range(64))
        nonce, mode = struct.unpack_from('<2I', args, 8)
        start = probe.NATIVE['buffers']['pcm'][0]
        frames, fixture_crc = 2, 0
        if mode in (3, 4, 5):
            address = fixture.INPUT_START
            fixture_header = bytes(self.memory[address+i] for i in range(64))
            frames, fixture_crc = struct.unpack_from('<I', fixture_header, 12)[0], struct.unpack_from('<I', fixture_header, 24)[0]
            self.mixed_pcm = self.mixed_pcm_override if self.mixed_pcm_override is not None else struct.pack(
                '<'+str(160*frames)+'h', *[(i % 257-128)*31 for i in range(160*frames)])
            start, pcm = fixture.PCM_START, self.mixed_pcm
            self.memory.update({0x46000+i:b for i, b in enumerate(self.stack_image)})
            if mode in (4, 5):
                self.memory.update({0x55800+i:b for i, b in enumerate(frame_ticks(frames))})
        else:
            pcm = self.unvoiced_pcm if mode == 2 else self.pcm
        self.memory.update({start+i:b for i, b in enumerate(pcm)})
        if mode == 2:
            seed = probe.NATIVE['buffers']['state'][0]+0x648
            self.memory.update({seed+i:b for i, b in enumerate(struct.pack('<H', self.noise_seed))})
        recs = self.record_change(records(mode, pcm, frames, fixture_crc))
        initial_sp = min(0x37f00, self.v6['stack_top']-128)
        self.port.buffer.extend(self.result_change(packet(nonce, mode, recs=recs, header={'initial_sp':initial_sp})))
        self.after_call()


class NativeProbeTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        # Synthetic bytes, never the user's sealed backup or factory codec.
        self.source = bytes(range(256))*4096
        self.native = copy.deepcopy(probe.NATIVE)
        self.native['program_sha256'] = probe.digest(self.source)
        for key in ('code', 'tables'):
            item = self.native[key]
            offset = item['flash']-0x03000000
            item['sha256'] = probe.digest(self.source[offset:offset+item['bytes']])
        for patch in (mock.patch.object(probe, 'SOURCE_SHA', probe.digest(self.source)),
                      mock.patch.object(probe, 'NATIVE', self.native)):
            patch.start()
            self.addCleanup(patch.stop)
        image = bytes.fromhex('00500050005000500050005000500050')
        elf = helpers.make_elf(image)
        self.manifest = dict(schema=probe.SCHEMA, build_id=probe.BUILD_ID, entry=probe.ENTRY,
            ram_start=probe.ENTRY, ram_end=0x48000, args_address=probe.ARGS,
            image=dict(file='probe.bin', bytes=len(image), sha256=probe.digest(image)),
            elf=dict(file='probe.elf', bytes=len(elf), sha256=probe.digest(elf)),
            source_commit='a'*40, allowed_modes=[0, 1, 2, 3, 4, 5], stub_source_sha256=probe.transport.STUB_SHA256,
            ranges={**copy.deepcopy(probe.FIXED), 'image':[probe.ENTRY, probe.ENTRY+len(image)],
                    'bss':[0x45000, 0x45004]}, native=self.native,
            mixed={'input':[fixture.INPUT_START, fixture.INPUT_END], 'pcm':[fixture.PCM_START, fixture.PCM_END],
                   'max_frames':64, 'frame_bytes':248, 'header_bytes':64},
            benchmark={'frame_ticks':[0x55800, 0x55c00], 'max_frames':64, 'frame_bytes':248, 'algorithm_id':1})
        (self.directory/'probe.bin').write_bytes(image)
        (self.directory/'probe.elf').write_bytes(elf)
        self.backup = self.directory/'synthetic-program.bin'
        self.backup.write_bytes(self.source)
        self.path = self.directory/'manifest.json'
        self.save(self.manifest)
        self.bundle = probe.load_bundle(self.path, self.backup)

    def save(self, manifest):
        self.path.write_text(json.dumps(manifest))

    @contextlib.contextmanager
    def fake_transport(self):
        reader = probe.transport.BoundedReader
        with mock.patch.object(probe.transport.time, 'sleep'), \
             mock.patch.object(probe.transport, 'BoundedReader',
                 side_effect=lambda port, timeout: reader(port, timeout, clock=lambda:port.now)):
            yield

    def run_fake(self, mode=0, radio=None, port=None, nonce=123, resume=False, proof=None, fixture_blob=None):
        port = port or FakePort()
        radio = radio or FakeRadio(port)
        with self.fake_transport():
            result = probe.execute(self.bundle, mode, 'FAKE', nonce, resume=resume, wait=10,
                                   radio_factory=lambda p:radio, port_factory=lambda n:port, proof=proof,
                                   fixture=fixture_blob)
        return result, radio, port

    def make_fixture(self, frames=2, start_frame=0, benchmark=False):
        reference = self.directory/'reference.jsonl'
        values = [dict(frame=i, payload=(bytes([i%256])*11).hex(),
                       fundamental_phase_increment_q32=53687091, harmonics=37,
                       amplitudes=list(range(1, 38)), voicing=[j%2 for j in range(37)])
                  for i in range(128)]
        reference.write_text(''.join(json.dumps(value)+'\n' for value in values))
        return fixture.pack_fixture(reference, start_frame, frames, benchmark=benchmark)

    def make_smoke_proof(self):
        result, radio, port = self.run_fake()
        proof = dict(schema=probe.SCHEMA, dry_run=False, manifest=self.bundle['manifest'], **result)
        path = self.directory/'smoke.json'
        path.write_text(json.dumps(proof))
        return probe.smoke_proof(path, self.bundle), radio, port, path

    def make_pll_peer(self):
        port = FakePort();radio = FakeRadio(port)
        radio.v6 = {key:value for key, value in probe.clock_guard.MONITOR.items()
                    if key not in ('protocol', 'max_payload')}
        radio.v6['stack_used'] = 164
        result, radio, _ = self.run_fake(0, radio, port)
        proof = dict(schema=probe.SCHEMA, dry_run=False, manifest=self.bundle['manifest'], **result)
        port = FakePort();other = FakeRadio(port)
        other.v6 = radio.v6.copy()
        other.memory = radio.memory.copy()
        return proof, other, port

    def test_args_crc_reserved_fields_and_bad_inputs(self):
        raw = probe.make_args(123, 1, 24000000)
        self.assertEqual(len(raw), 64)
        self.assertEqual(raw[:8], probe.ARG_MAGIC)
        self.assertEqual(struct.unpack_from('<5I', raw, 8), (123, 1, 24000000, 0x14030000, probe.BUILD_ID))
        self.assertEqual(raw[28:60], bytes(32))
        self.assertEqual(zlib.crc32(raw[:-4]), struct.unpack_from('<I', raw, 60)[0])
        for nonce, mode, clock in ((0, 0, 24000000), (True, 0, 24000000), (123, True, 24000000),
                                   (123, 6, 24000000), (123, 0, 84000000)):
            with self.subTest(values=(nonce, mode, clock)), self.assertRaises(probe.ProbeError):
                probe.make_args(nonce, mode, clock)
        self.assertEqual(struct.unpack_from('<I', probe.make_args(123, 2, 24000000), 12)[0], 2)
        self.assertEqual(struct.unpack_from('<I', probe.make_args(123, 3, 24000000), 12)[0], 3)
        self.assertEqual(struct.unpack_from('<I', probe.make_args(123, 4, 24000000), 12)[0], 4)
        self.assertEqual(struct.unpack_from('<I', probe.make_args(123, 5, 24000000), 12)[0], 5)

    def test_default_main_is_dry_and_never_imports_serial_or_stub(self):
        output = io.StringIO()
        args = ['native-synthesis-probe.py', '--manifest', str(self.path), '--backup', str(self.backup)]
        with mock.patch.object(sys, 'argv', args), mock.patch.dict(sys.modules, {'serial':None}), \
             mock.patch.object(probe.transport, 'load_stub', side_effect=AssertionError('stub imported')), \
             contextlib.redirect_stdout(output):
            probe.main()
        result = json.loads(output.getvalue())
        self.assertTrue(result['dry_run'])
        self.assertFalse(result['serial_opened'])
        self.assertFalse(result['firmware_changed'])

    def test_manifest_schema_layout_native_addresses_and_artifact_guards(self):
        mutations = [lambda m:m.update(schema='unknown'), lambda m:m.update(extra=1),
            lambda m:m.update(entry=0x0300c000), lambda m:m.update(allowed_modes=[1]),
            lambda m:m.update(source_commit='dirty'), lambda m:m.update(stub_source_sha256='0'*64),
            lambda m:m['image'].update(file='../probe.bin'), lambda m:m['image'].update(sha256='0'*64),
            lambda m:m['elf'].update(sha256='0'*64), lambda m:m['ranges'].update(args=[0x44804, 0x44844]),
            lambda m:m['ranges'].update(bss=[0x45000, 0x46004]),
            lambda m:m['ranges'].update(context=[0x44800, 0x44900]),
            lambda m:m['native']['code'].update(address=0x0300c000),
            lambda m:m['native']['tables'].update(sha256='0'*64),
            lambda m:m['native']['buffers'].update(state=[0x10000, 0x11000]),
            lambda m:m['mixed'].update(input=[0x0300c000, 0x0300fe40]),
            lambda m:m['mixed'].update(pcm=[0x48020, 0x4d020]),
            lambda m:m['mixed'].update(max_frames=65),
            lambda m:m['mixed'].update(header_bytes=60),
            lambda m:m['benchmark'].update(frame_ticks=[0x40000, 0x40400]),
            lambda m:m['benchmark'].update(max_frames=65)]
        for mutate in mutations:
            candidate = copy.deepcopy(self.manifest)
            mutate(candidate)
            self.save(candidate)
            with self.subTest(manifest=candidate), self.assertRaises(probe.ProbeError):
                probe.load_bundle(self.path, self.backup)

    def test_backup_code_table_and_stub_hashes_are_checked(self):
        self.backup.write_bytes(self.source[:-1])
        with self.assertRaisesRegex(probe.ProbeError, 'backup'):
            probe.load_bundle(self.path, self.backup)
        for key in ('code', 'tables'):
            changed = bytearray(self.source)
            changed[self.native[key]['flash']-0x03000000] ^= 1
            self.backup.write_bytes(changed)
            # Permit only this synthetic whole-file hash to isolate the native
            # carve hash check. Production constants never change in the runner.
            with self.subTest(window=key), mock.patch.object(probe, 'SOURCE_SHA', probe.digest(changed)), \
                 self.assertRaisesRegex(probe.ProbeError, 'Native '+key+' hash'):
                probe.load_bundle(self.path, self.backup)
        self.backup.write_bytes(self.source)
        with mock.patch.object(probe.transport, 'stub_digest', return_value='0'*64), \
             self.assertRaisesRegex(probe.ProbeError, 'loader source'):
            probe.load_bundle(self.path, self.backup)

    def test_changed_artifact_revalidated_before_opening_port(self):
        (self.directory/'probe.bin').write_bytes(bytes(16))
        with self.assertRaises(probe.ProbeError):
            probe.execute(self.bundle, 0, 'FAKE', 123,
                          radio_factory=lambda p:self.fail('radio created'),
                          port_factory=lambda n:self.fail('port opened'))

    def test_write_allowlist_rejects_subspan_flash_and_wrong_object_size(self):
        port = FakePort()
        radio = FakeRadio(port)
        allowed = {(probe.ENTRY, probe.ENTRY+16)}
        for address, data in ((0x0300c000, bytes(16)), (probe.ENTRY, bytes(12)),
                              (probe.ENTRY+4, bytes(12)), (0x14000000, bytes(16))):
            with self.subTest(address=address), self.assertRaises(probe.ProbeError):
                probe.write_verified(radio, address, data, 8, allowed)
        self.assertEqual(radio.ops, [])

    def test_smoke_exactly_one_call_and_port_closed_without_codec_writes(self):
        result, radio, port = self.run_fake()
        self.assertTrue(result['monitor_returned'])
        self.assertEqual(port.closes, 1)
        self.assertEqual([x for x in radio.ops if x[0] == 'call'], [('call', probe.ENTRY)])
        self.assertTrue(all(x[0] in ('start', 'configure', 'hello', 'poke', 'peek', 'call') for x in radio.ops))
        writes = [x for x in radio.ops if x[0] == 'poke']
        self.assertEqual([(x[1], len(x[2])) for x in writes], [(probe.ENTRY, 16), (probe.ARGS, 64)])

    def test_native_requires_smoke_resume_and_live_session_cookie(self):
        for mode in (1, 2, 3, 4, 5):
            for resume, proof in ((False, None), (True, None), (False, {})):
                with self.subTest(mode=mode, resume=resume), self.assertRaises(probe.ProbeError):
                    probe.execute(self.bundle, mode, 'FAKE', 456, resume=resume, proof=proof,
                                  port_factory=lambda n:self.fail('port opened'), radio_factory=lambda p:None)
        proof, radio, _, _ = self.make_smoke_proof()
        for change in ('cookie', 'footprint'):
            port = FakePort()
            other = FakeRadio(port)
            other.memory = radio.memory.copy()
            if change == 'cookie':
                other.memory[probe.ARGS+8] ^= 1
            else:
                other.v6['image'] += 4
            with self.subTest(case=change), self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 1, 'FAKE', 456, resume=True, proof=proof,
                              port_factory=lambda n:port, radio_factory=lambda p:other)
            self.assertFalse(any(x[0] in ('call', 'poke', 'start') for x in other.ops))
            self.assertEqual(port.closes, 1)

    def test_native_only_uploads_exact_codec_tables_image_args_then_one_call(self):
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort()
        radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        result, radio, port = self.run_fake(1, radio, port, 456, True, proof)
        self.assertFalse(result['audio_qualified'])
        self.assertTrue(result['monitor_returned'])
        self.assertEqual(result['pcm_hex'], radio.pcm.hex())
        self.assertEqual(port.closes, 1)
        self.assertEqual([x for x in radio.ops if x[0] == 'call'], [('call', probe.ENTRY)])
        self.assertFalse(any(x[0] == 'start' for x in radio.ops))
        self.assertTrue(all(x[0] in ('configure', 'hello', 'poke', 'peek', 'call') for x in radio.ops))
        approved = [(probe.ENTRY, probe.ENTRY+16), (probe.ARGS, probe.ARGS+64)] + [
            (self.native[k]['address'], self.native[k]['address']+self.native[k]['bytes']) for k in ('code', 'tables')]
        for op in radio.ops:
            if op[0] == 'poke':
                self.assertTrue(any(lo <= op[1] < op[1]+len(op[2]) <= hi for lo, hi in approved), op)
        for key in ('code', 'tables'):
            item = self.native[key]
            actual = bytes(radio.memory[item['address']+i] for i in range(item['bytes']))
            self.assertEqual(probe.digest(actual), item['sha256'])

    def test_native_ram_readback_mismatch_prevents_call_and_pcm_mismatch_refuses_result(self):
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        for stage in ('code', 'pcm'):
            port = FakePort();radio = FakeRadio(port)
            radio.memory = smoke_radio.memory.copy()
            original_peek = radio.peek
            bad_address = self.native['code']['address'] if stage == 'code' else self.native['buffers']['pcm'][0]
            def corrupt(address, count):
                value = original_peek(address, count)
                return bytes([value[0]^1])+value[1:] if address == bad_address else value
            with self.subTest(stage=stage), mock.patch.object(radio, 'peek', side_effect=corrupt), \
                 self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 1, 'FAKE', 456, resume=True, proof=proof,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertEqual(sum(x[0] == 'call' for x in radio.ops), int(stage == 'pcm'))
            self.assertEqual(port.closes, 1)
            if stage == 'code':
                self.assertEqual(sum(x[0] == 'poke' for x in radio.ops), 1)

    def test_unvoiced_downloads_640_samples_in_three_bounded_chunks(self):
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        result, radio, port = self.run_fake(2, radio, port, 456, True, proof)
        self.assertTrue(result['monitor_returned'])
        self.assertFalse(result['audio_qualified'])
        self.assertEqual(result['pcm_hex'], radio.unvoiced_pcm.hex())
        self.assertEqual(result['pcm']['samples'], 640)
        self.assertEqual(len(result['pcm']['block_rms_80_samples']), 8)
        self.assertEqual(result['pcm']['nonzero_samples'], 636)
        self.assertEqual(result['pcm']['clipped_samples'], 0)
        repeat = result['result']['records'][7]
        self.assertEqual((repeat['value'], repeat['aux']),
                         (zlib.crc32(radio.unvoiced_pcm),)*2)
        start = self.native['buffers']['pcm'][0]
        pcm_reads = [op for op in radio.ops if op[0] == 'peek' and start <= op[1] < start+1280]
        self.assertEqual(pcm_reads, [('peek', start, 512), ('peek', start+512, 512),
                                     ('peek', start+1024, 256)])
        seed_address = self.native['buffers']['state'][0]+0x648
        self.assertEqual([op for op in radio.ops if op[0] == 'peek' and op[1] == seed_address],
                         [('peek', seed_address, 2)])
        observations = result['unvoiced_observations']
        self.assertTrue(observations['repeat_crc_identical'])
        self.assertEqual(observations['noise_seed_actual'], 0x1c9c)
        self.assertEqual(observations['noise_seed_expected'], 0x1c9c)
        self.assertTrue(observations['noise_seed_matches_80_draws_per_call'])
        self.assertEqual([op for op in radio.ops if op[0] == 'call'], [('call', probe.ENTRY)])
        self.assertFalse(any(op[0] == 'start' for op in radio.ops))
        self.assertEqual(port.closes, 1)

    def test_unvoiced_controls_repeat_and_seed_differences_are_observations(self):
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        def diagnostic_differences(recs):
            recs[4].update(value=123, aux=7)
            recs[5].update(value=456, aux=9)
            recs[7]['value'] ^= 1
            return recs
        radio.record_change = diagnostic_differences
        radio.noise_seed = 0x1234
        result, _, port = self.run_fake(2, radio, port, 456, True, proof)
        observations = result['unvoiced_observations']
        self.assertEqual(observations['zero_amplitude_control_peak'], 123)
        self.assertEqual(observations['zero_amplitude_control_nonzeros'], 7)
        self.assertEqual(observations['voiced_flags_control_peak'], 456)
        self.assertEqual(observations['voiced_flags_control_nonzeros'], 9)
        self.assertFalse(observations['repeat_crc_identical'])
        self.assertFalse(observations['noise_seed_matches_80_draws_per_call'])
        self.assertEqual(observations['noise_seed_actual'], 0x1234)
        self.assertFalse(result['audio_qualified'])
        self.assertEqual(port.closes, 1)

    def test_unvoiced_structural_counts_guards_and_faults_are_fatal(self):
        changes = [('block count', lambda recs:recs[6].update(value=7)),
                   ('active sample count', lambda recs:recs[6].update(aux=639)),
                   ('PCM count', lambda recs:recs[-1].update(aux=80)),
                   ('oversized PCM count', lambda recs:recs[-1].update(aux=0xffffffff)),
                   ('control ID', lambda recs:recs[4].update(id=17)),
                   ('control status', lambda recs:recs[4].update(status=4)),
                   ('repeat fault', lambda recs:recs[7].update(vector=4, epc=0x1b552)),
                   ('amplitude oracle', lambda recs:recs[1].update(value=0))]
        for name, change in changes:
            recs = records(2);change(recs)
            with self.subTest(case=name), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=2, recs=recs), 123, 2)
        for header in ({'fatal':2}, {'guard_mask':15}, {'record_count':17}, {'mode':1}):
            with self.subTest(header=header), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=2, header=header), 123, 2)
        for recs in (records(2)[:-1], records(2)+records(2)[-1:]):
            with self.subTest(count=len(recs)), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=2, recs=recs), 123, 2)

    def test_unvoiced_pcm_and_seed_readback_failures_refuse_without_second_call(self):
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        pcm_start = self.native['buffers']['pcm'][0]
        seed_start = self.native['buffers']['state'][0]+0x648
        for failure in ('middle PCM corrupt', 'last PCM short', 'seed short'):
            port = FakePort();radio = FakeRadio(port)
            radio.memory = smoke_radio.memory.copy()
            original_peek = radio.peek
            def corrupt(address, count):
                value = original_peek(address, count)
                if failure == 'middle PCM corrupt' and address == pcm_start+512:
                    return bytes([value[0]^1])+value[1:]
                if failure == 'last PCM short' and address == pcm_start+1024:
                    return value[:-1]
                if failure == 'seed short' and address == seed_start:
                    return value[:1]
                return value
            with self.subTest(failure=failure), mock.patch.object(radio, 'peek', side_effect=corrupt), \
                 self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 2, 'FAKE', 456, resume=True, proof=proof,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
            self.assertEqual(port.closes, 1)

    def test_unvoiced_dry_cli_and_unknown_modes_do_not_open_serial(self):
        output = io.StringIO()
        args = ['native-synthesis-probe.py', '--manifest', str(self.path), '--backup', str(self.backup),
                '--mode', 'unvoiced']
        with mock.patch.object(sys, 'argv', args), mock.patch.dict(sys.modules, {'serial':None}), \
             mock.patch.object(probe, 'execute', side_effect=AssertionError('execute called')), \
             contextlib.redirect_stdout(output):
            probe.main()
        result = json.loads(output.getvalue())
        self.assertTrue(result['dry_run'])
        self.assertFalse(result['serial_opened'])
        self.assertEqual(result['hardware_mode'], 'unvoiced')
        for mode in (6, -1, True, '2'):
            with self.subTest(mode=mode), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, mode, 'FAKE', 456,
                              port_factory=lambda n:self.fail('port opened'), radio_factory=lambda p:None)

    def test_mixed_fixture_packer_is_deterministic_and_preserves_exact_parameters(self):
        raw, manifest = self.make_fixture(64, 40)
        output = self.directory/'speech.bin'
        second, saved = fixture.pack_fixture(self.directory/'reference.jsonl', output_path=output)
        self.assertEqual(raw, second)
        self.assertEqual(output.read_bytes(), raw)
        self.assertEqual(json.loads(output.with_suffix('.manifest.json').read_text()), saved)
        self.assertEqual(len(raw), 64+64*248)
        self.assertEqual(raw[:8], b'NVSIMv1\0')
        self.assertEqual(struct.unpack_from('<6I', raw, 8),
                         (1, 64, 248, 64*248, zlib.crc32(raw[64:]), 0))
        self.assertEqual(raw[32:60], bytes(28))
        self.assertEqual(struct.unpack_from('<I', raw, 60)[0], zlib.crc32(raw[:60]))
        parameter = raw[64:200]
        self.assertEqual(struct.unpack_from('<hhhhIhh', parameter), (1, 255, 37, 0, 1, 6554, 0))
        self.assertEqual(struct.unpack_from('<56h', parameter, 16), tuple(list(range(1, 38))+[0]*19))
        self.assertEqual(struct.unpack_from('<Ihh', parameter, 128), (0, -2, 0))
        self.assertEqual(struct.unpack_from('<56h', raw, 200), tuple([i%2 for i in range(37)]+[0]*19))
        self.assertEqual(manifest['start_frame'], 40)
        self.assertEqual(manifest['frames'], 64)
        self.assertEqual(manifest['source']['sha256'], probe.digest((self.directory/'reference.jsonl').read_bytes()))
        self.assertEqual(manifest['selected_imbe_sha256'], probe.digest(b''.join(bytes([i])*11 for i in range(40, 104))))
        self.assertEqual(manifest['blob']['sha256'], probe.digest(raw))
        self.assertEqual(manifest['blob']['payload_crc32'], zlib.crc32(raw[64:]))
        self.assertEqual(manifest['gain_power'], 0)
        self.assertEqual(manifest['parameter_pointer'], 0)
        self.assertFalse(manifest['hardware_access'])
        self.assertFalse(manifest['audio_qualified'])

    def test_mixed_fixture_refuses_header_crc_size_and_unsafe_parameters(self):
        raw, _ = self.make_fixture()
        def sealed_change(offset, format_string, value):
            changed = bytearray(raw)
            struct.pack_into(format_string, changed, offset, value)
            struct.pack_into('<I', changed, 24, zlib.crc32(changed[64:]))
            struct.pack_into('<I', changed, 60, zlib.crc32(changed[:60]))
            return bytes(changed)
        mutations = [(8, '<I', 2), (12, '<I', 0), (12, '<I', 65), (16, '<I', 249),
                     (20, '<I', 0xffffffff), (28, '<I', 1), (32, '<I', 1),
                     (64, '<h', 2), (66, '<h', 3), (68, '<h', 8), (68, '<h', 57),
                     (70, '<h', 1), (72, '<I', 0), (76, '<h', 0), (76, '<h', -1),
                     (78, '<h', 1), (80, '<h', -1), (80+37*2, '<h', 1),
                     (192, '<I', fixture.INPUT_START), (196, '<h', -1), (198, '<h', 1),
                     (200, '<h', 2), (200+37*2, '<h', 1)]
        for values in mutations:
            with self.subTest(mutation=values), self.assertRaises(ValueError):
                fixture.validate_blob(sealed_change(*values))
        invalid = [raw[:-1], raw+b'\0', raw[:60]+bytes(4)+raw[64:],
                   raw[:64]+bytes([raw[64]^1])+raw[65:], bytearray(raw), bytes(fixture.MAX_INPUT_BYTES+1)]
        for changed in invalid:
            with self.subTest(length=len(changed)), self.assertRaises(ValueError):
                fixture.validate_blob(changed)

    def test_mixed_fixture_reference_bounds_and_overwrite_refusals(self):
        self.make_fixture()
        reference = self.directory/'reference.jsonl'
        for start, count in ((-1, 2), (0, 0), (0, 65), (True, 2), (0, True), (127, 2)):
            with self.subTest(start=start, count=count), self.assertRaises(ValueError):
                fixture.pack_fixture(reference, start, count)
        original = reference.read_bytes()
        with self.assertRaises(ValueError):
            fixture.pack_fixture(reference, 0, 2, reference)
        self.assertEqual(reference.read_bytes(), original)
        values = [json.loads(line) for line in reference.read_text().splitlines()]
        for mutate in (lambda a:a[1].update(frame=7), lambda a:a[0].update(frame=False),
                       lambda a:a[0].update(amplitudes=[1]*36), lambda a:a[0].update(voicing=[2]*37)):
            changed = copy.deepcopy(values);mutate(changed)
            reference.write_text(''.join(json.dumps(value)+'\n' for value in changed))
            with self.subTest(change=changed[0]), self.assertRaises(ValueError):
                fixture.pack_fixture(reference, 0, 2)
        reference.write_text('{broken JSON}\n')
        with self.assertRaises(ValueError):
            fixture.pack_fixture(reference, 0, 1)

    def test_mixed_downloads_maximum_pcm_with_bounded_reads_and_fixed_input_write(self):
        raw, _ = self.make_fixture(64)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        result, radio, port = self.run_fake(3, radio, port, 456, True, proof, raw)
        self.assertTrue(result['monitor_returned'])
        self.assertFalse(result['audio_qualified'])
        self.assertEqual(result['pcm_hex'], radio.mixed_pcm.hex())
        self.assertEqual(result['pcm']['samples'], 10240)
        self.assertEqual(len(result['pcm']['block_rms_80_samples']), 128)
        reads = [op for op in radio.ops if op[0] == 'peek' and fixture.PCM_START <= op[1] < fixture.PCM_END]
        self.assertEqual(reads, [('peek', fixture.PCM_START+i, 512) for i in range(0, 20480, 512)])
        writes = [op for op in radio.ops if op[0] == 'poke' and fixture.INPUT_START <= op[1] < fixture.INPUT_END]
        self.assertTrue(all(0 < len(op[2]) <= 512 for op in writes))
        self.assertEqual(b''.join(op[2] for op in writes), raw)
        self.assertTrue(all(op[1] == fixture.INPUT_START+sum(len(x[2]) for x in writes[:i])
                            for i, op in enumerate(writes)))
        self.assertEqual([op for op in radio.ops if op[0] == 'call'], [('call', probe.ENTRY)])
        self.assertEqual(port.closes, 1)

    def test_mixed_short_fixture_is_zero_padded_in_exact_approved_input_object(self):
        raw, _ = self.make_fixture(3)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        result, radio, port = self.run_fake(3, radio, port, 456, True, proof, raw)
        self.assertEqual(result['pcm']['samples'], 480)
        writes = [op for op in radio.ops if op[0] == 'poke' and fixture.INPUT_START <= op[1] < fixture.INPUT_END]
        self.assertEqual(b''.join(op[2] for op in writes), raw+bytes(fixture.MAX_INPUT_BYTES-len(raw)))
        reads = [op for op in radio.ops if op[0] == 'peek' and fixture.PCM_START <= op[1] < fixture.PCM_END]
        self.assertEqual(reads, [('peek', fixture.PCM_START, 512), ('peek', fixture.PCM_START+512, 448)])
        self.assertEqual(port.closes, 1)

    def test_mixed_fixture_is_validated_before_opening_serial(self):
        raw, _ = self.make_fixture()
        proof, _, _, _ = self.make_smoke_proof()
        for bad in (None, raw[:-1], raw+b'\0', bytes(fixture.MAX_INPUT_BYTES+1), bytearray(raw)):
            with self.subTest(fixture_type=type(bad).__name__), self.assertRaises((probe.ProbeError, ValueError)):
                probe.execute(self.bundle, 3, 'FAKE', 456, resume=True, proof=proof, fixture=bad,
                              radio_factory=lambda p:self.fail('radio created'),
                              port_factory=lambda n:self.fail('port opened'))

    def test_mixed_packet_counts_crc_faults_and_reserved_fields_are_fatal(self):
        raw, _ = self.make_fixture(2)
        crc = fixture.validate_blob(raw)['payload_crc32']
        recs = records(3, fixture_crc=crc)
        probe.parse_packet(packet(mode=3, recs=recs), 123, 3, frames=2, fixture_crc=crc)
        for index, field, value in ((4, 'value', 65), (4, 'aux', crc^1), (5, 'value', 3),
                                    (5, 'aux', 319), (10, 'aux', 0xffffffff), (9, 'aux', 1),
                                    (7, 'status', 1), (6, 'vector', 4), (8, 'reserved', 1)):
            changed = copy.deepcopy(recs);changed[index][field] = value
            with self.subTest(index=index, field=field), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=3, recs=changed), 123, 3, frames=2, fixture_crc=crc)
        for fields in ({}, {'frames':0, 'fixture_crc':crc}, {'frames':65, 'fixture_crc':crc},
                       {'frames':True, 'fixture_crc':crc}, {'frames':2, 'fixture_crc':-1}):
            with self.subTest(fields=fields), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=3, recs=recs), 123, 3, **fields)

    def test_mixed_input_readback_and_pcm_corruption_never_repeat_call(self):
        raw, _ = self.make_fixture(3)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        for stage in ('input', 'PCM'):
            port = FakePort();radio = FakeRadio(port)
            radio.memory = smoke_radio.memory.copy()
            original_peek = radio.peek
            bad_address = fixture.INPUT_START+512 if stage == 'input' else fixture.PCM_START+512
            def corrupt(address, count):
                value = original_peek(address, count)
                return bytes([value[0]^1])+value[1:] if address == bad_address else value
            with self.subTest(stage=stage), mock.patch.object(radio, 'peek', side_effect=corrupt), \
                 self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 3, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertEqual(sum(op[0] == 'call' for op in radio.ops), int(stage == 'PCM'))
            self.assertEqual(port.closes, 1)

    def test_mixed_clipping_is_observational_and_unavailable_timer_is_explicit(self):
        raw, _ = self.make_fixture(2)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        radio.mixed_pcm_override = struct.pack('<320h', *([-32768, 32767]*6+[100]*308))
        def observations(recs):
            recs[8].update(value=0, aux=0)
            recs[9].update(value=0, aux=2)
            return recs
        radio.record_change = observations
        result, _, _ = self.run_fake(3, radio, port, 456, True, proof, raw)
        self.assertEqual(result['mixed_observations']['clipped_samples'], 12)
        self.assertEqual(result['mixed_observations']['peak'], 32768)
        self.assertFalse(result['audio_qualified'])
        self.assertEqual(result['timing']['clock_hz'], 0)
        self.assertIsNone(result['timing']['mean_frame_us'])
        self.assertIsNone(result['timing']['max_half_us'])
        self.assertFalse(result['timing']['cpu_cycles_measured'])
        self.assertEqual(port.closes, 1)

    def test_mixed_false_sample_observations_are_refused_against_downloaded_pcm(self):
        raw, _ = self.make_fixture(2)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        for field in ('peak', 'nonzero', 'clipped'):
            port = FakePort();radio = FakeRadio(port)
            radio.memory = smoke_radio.memory.copy()
            def false_observation(recs):
                if field == 'peak':
                    recs[6]['value'] += 1
                elif field == 'nonzero':
                    recs[6]['aux'] -= 1;recs[7]['aux'] += 1
                else:
                    recs[7]['value'] += 1
                return recs
            radio.record_change = false_observation
            with self.subTest(field=field), self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 3, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
            self.assertEqual(port.closes, 1)

    def test_mixed_cli_validates_fixture_in_dry_run_without_stub_or_serial(self):
        raw, _ = self.make_fixture(3)
        blob_path = self.directory/'mixed.bin';blob_path.write_bytes(raw)
        args = ['native-synthesis-probe.py', '--manifest', str(self.path), '--backup', str(self.backup),
                '--mode', 'mixed', '--fixture', str(blob_path)]
        output = io.StringIO()
        with mock.patch.object(sys, 'argv', args), mock.patch.dict(sys.modules, {'serial':None}), \
             mock.patch.object(probe.transport, 'load_stub', side_effect=AssertionError('stub imported')), \
             contextlib.redirect_stdout(output):
            probe.main()
        result = json.loads(output.getvalue())
        self.assertTrue(result['dry_run'])
        self.assertFalse(result['serial_opened'])
        self.assertEqual(result['hardware_mode'], 'mixed')
        self.assertEqual(result['mixed_fixture']['sha256'], probe.digest(raw))
        self.assertEqual(result['mixed_fixture']['frames'], 3)
        blob_path.write_bytes(raw[:-1])
        with mock.patch.object(sys, 'argv', args), self.assertRaises((probe.ProbeError, ValueError)), \
             mock.patch.object(probe.transport, 'load_stub', side_effect=AssertionError('stub imported')):
            probe.main()

    def test_painted_stack_reads_only_fixed_reservation_in_sixteen_bounded_chunks(self):
        radio = FakeRadio(FakePort())
        radio.memory.update({0x46000+i:b for i, b in enumerate(radio.stack_image)})
        result = probe.read_painted_stack(radio)
        self.assertEqual(radio.ops, [('peek', 0x46000+i, 512) for i in range(0, 8192, 512)])
        self.assertEqual(result['reservation_bytes'], 8192)
        self.assertEqual(result['observed_write_depth_bytes'], 0)
        self.assertIsNone(result['lowest_changed_address'])
        self.assertTrue(result['outer_guards_passed'])
        self.assertEqual(result['sha256'], probe.digest(radio.stack_image))
        self.assertIn('not an exact peak-SP', result['limitation'])

    def test_painted_stack_reports_first_changed_byte_with_holes_and_boundary_bytes(self):
        for offsets, expected_depth in (([8192-9], 1), ([8], 8176), ([1024, 8192-9], 7160),
                                         ([512], 7672), ([8192-10, 8192-9], 2)):
            radio = FakeRadio(FakePort())
            image = bytearray(radio.stack_image)
            for offset in offsets:
                image[offset] = 0
            radio.memory.update({0x46000+i:b for i, b in enumerate(image)})
            with self.subTest(offsets=offsets):
                result = probe.read_painted_stack(radio)
                self.assertEqual(result['observed_write_depth_bytes'], expected_depth)
                self.assertEqual(result['lowest_changed_address'], 0x46000+min(offsets))
                self.assertEqual(result['sha256'], probe.digest(image))
                self.assertTrue(result['outer_guards_passed'])

    def test_painted_stack_rejects_both_canaries_and_short_or_oversized_readback(self):
        for offset in (0, 4, 7, 8192-8, 8192-4, 8192-1):
            radio = FakeRadio(FakePort())
            image = bytearray(radio.stack_image);image[offset] ^= 1
            radio.memory.update({0x46000+i:b for i, b in enumerate(image)})
            with self.subTest(offset=offset), self.assertRaises(probe.ProbeError):
                probe.read_painted_stack(radio)
        for change in ('short', 'oversized'):
            radio = FakeRadio(FakePort())
            radio.memory.update({0x46000+i:b for i, b in enumerate(radio.stack_image)})
            peek = radio.peek
            def wrong_length(address, count):
                data = peek(address, count)
                if address == 0x46400:
                    return data[:-1] if change == 'short' else data+b'\0'
                return data
            with self.subTest(change=change), mock.patch.object(radio, 'peek', side_effect=wrong_length), \
                 self.assertRaises(probe.ProbeError):
                probe.read_painted_stack(radio)

    def test_mixed_stack_guard_failure_is_fatal_after_exactly_one_call(self):
        raw, _ = self.make_fixture(2)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        radio.stack_image = bytes([radio.stack_image[0]^1])+radio.stack_image[1:]
        with self.fake_transport(), self.assertRaises(probe.ProbeError) as error:
            probe.execute(self.bundle, 3, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                          radio_factory=lambda p:radio, port_factory=lambda n:port)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        self.assertTrue(error.exception.monitor_returned)
        self.assertEqual(port.closes, 1)

    def test_compare_fixture_retains_original_q32_and_matches_legacy_native_inputs(self):
        legacy, _ = self.make_fixture(64, 40)
        raw, manifest = self.make_fixture(64, 40, benchmark=True)
        info = fixture.validate_benchmark_blob(raw)
        self.assertEqual(raw[:8], b'NVSCMv1\0')
        self.assertEqual(struct.unpack_from('<I4h', raw, 64), (53687091, 37, 19, 28339, 9))
        self.assertEqual(struct.unpack_from('<56h', raw, 76), tuple(list(range(1, 38))+[0]*19))
        self.assertEqual(struct.unpack_from('<56h', raw, 188), tuple([i%2 for i in range(37)]+[0]*19))
        self.assertEqual(raw[300:312], bytes(12))
        self.assertEqual(fixture.benchmark_to_legacy(raw), legacy)
        self.assertEqual(info['native_legacy_sha256'], probe.digest(legacy))
        self.assertEqual(info['native_legacy_payload_crc32'], zlib.crc32(legacy[64:]))
        self.assertTrue(manifest['benchmark'])
        for blob, validator in ((raw, fixture.validate_blob), (legacy, fixture.validate_benchmark_blob)):
            with self.subTest(magic=blob[:8]), self.assertRaises(ValueError):
                validator(blob)

    def test_compare_fixture_reciprocals_match_independent_long_division_for_all_harmonics(self):
        self.make_fixture()
        reference = self.directory/'reference.jsonl'
        values = [dict(frame=i, payload='00'*11, fundamental_phase_increment_q32=0x20000,
                       harmonics=count, amplitudes=[1]*count, voicing=[i%2]*count)
                  for i, count in enumerate(range(9, 57))]
        reference.write_text(''.join(json.dumps(value)+'\n' for value in values))
        raw, _ = fixture.pack_benchmark_fixture(reference, 0, 48)
        for index, count in enumerate(range(9, 57)):
            normalized, shift = count, 0
            while normalized < 0x4000:
                normalized *= 2;shift += 1
            if normalized == 0x4000:
                quotient = 32767
            else:
                remainder, quotient = 0x4000, 0
                for _ in range(15):
                    remainder *= 2;quotient *= 2
                    if remainder >= normalized:
                        remainder -= normalized;quotient += 1
            with self.subTest(harmonics=count):
                self.assertEqual(struct.unpack_from('<hh', raw, 64+index*248+8), (quotient, shift))

    def test_compare_fixture_refuses_frequency_reciprocal_voicing_and_reserved_hazards(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        def changed(offset, fmt, value):
            blob = bytearray(raw);struct.pack_into(fmt, blob, 64+offset, value)
            struct.pack_into('<I', blob, 24, zlib.crc32(blob[64:]))
            struct.pack_into('<I', blob, 60, zlib.crc32(blob[:60]))
            return bytes(blob)
        mutations = [(0, '<I', 0x1ffff), (0, '<I', 0xffffffff//75+1),
                     (0, '<I', 0xffffffff//75), (4, '<h', 8), (4, '<h', 57),
                     (6, '<h', 18), (8, '<h', 28338), (10, '<h', 10),
                     (12, '<h', -1), (12+37*2, '<h', 1),
                     (124, '<h', 2), (124+37*2, '<h', 1), (236, '<I', 0x48020)]
        for case in mutations:
            with self.subTest(case=case), self.assertRaises(ValueError):
                fixture.validate_benchmark_blob(changed(*case))
        for value in (None, True, 1, 'yes'):
            with self.subTest(selector=value), self.assertRaises(ValueError):
                if value is True:
                    fixture.validate_blob(raw)  # A benchmark must never pass the default native-only parser.
                else:
                    fixture.validate_blob(raw, benchmark=value)

    def test_compare_downloads_software_pcm_and_four_timing_arrays_with_one_call(self):
        raw, _ = self.make_fixture(64, benchmark=True)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        port = FakePort();radio = FakeRadio(port)
        radio.memory = smoke_radio.memory.copy()
        result, radio, port = self.run_fake(4, radio, port, 456, True, proof, raw)
        self.assertEqual(result['pcm_hex'], radio.mixed_pcm.hex())
        self.assertEqual(result['pcm']['samples'], 10240)
        timing_reads = [op for op in radio.ops if op[0] == 'peek' and 0x55800 <= op[1] < 0x55c00]
        self.assertEqual(timing_reads, [('peek', 0x55800, 512), ('peek', 0x55a00, 512)])
        self.assertEqual(result['benchmark']['native_core_speedup_ratio'], 2)
        self.assertAlmostEqual(result['benchmark']['native_core']['mean_us'], 1315/24)
        self.assertAlmostEqual(result['benchmark']['native_core']['p95_us'], 1600/24)
        self.assertAlmostEqual(result['benchmark']['native_core']['max_us'], 1630/24)
        self.assertEqual(result['benchmark']['native_bridge']['ticks'], list(range(100, 164)))
        self.assertEqual([op for op in radio.ops if op[0] == 'call'], [('call', probe.ENTRY)])
        self.assertFalse(result['benchmark']['cpu_cycles_measured'])
        self.assertFalse(result['benchmark']['production_decode_budget_measured'])
        self.assertFalse(result['audio_qualified'])
        self.assertEqual(port.closes, 1)

    def test_compare_pll_requires_cold_clock_then_restores_and_preserves_benchmark_math(self):
        raw, _ = self.make_fixture(64, benchmark=True)
        proof, radio, port = self.make_pll_peer()
        result, radio, port = self.run_fake(5, radio, port, 456, True, proof, raw)
        self.assertTrue(result['clock_restored'])
        self.assertEqual(result['clock_before'], result['clock_after'])
        self.assertEqual(result['apb_hz_before'], [24000000]*3)
        self.assertEqual(result['apb_hz_after'], [24000000]*3)
        self.assertEqual(result['selected_clock']['apb_hz'], 60000000)
        self.assertFalse(result['selected_clock']['direct_frequency_measurement'])
        self.assertFalse(result['selected_clock']['production_performance_measured'])
        self.assertIn('Register-derived', result['benchmark']['clock_basis'])
        self.assertFalse(result['benchmark']['selected_clock_directly_measured'])
        self.assertEqual(result['benchmark']['native_core_speedup_ratio'], 2)
        self.assertAlmostEqual(result['benchmark']['native_core']['mean_us'], 1315/60)
        self.assertAlmostEqual(result['benchmark']['software_core']['max_us'], 3260/60)
        self.assertIn('max_frame_us', result['timing'])
        self.assertNotIn('max_half_us', result['timing'])
        self.assertEqual(result['pcm_hex'], radio.mixed_pcm.hex())
        self.assertEqual(result['pcm']['samples'], 10240)
        self.assertEqual([op for op in radio.ops if op[0] == 'call'], [('call', probe.ENTRY)])
        self.assertEqual([op for op in radio.ops if op[0] == 'configure'], [('configure', None)])
        self.assertEqual([op for op in radio.ops if op[0] == 'timer_hz'], [('timer_hz', 0.5)]*6)
        self.assertTrue(all(op[1] < 0x58000 or 0x18000eb0 <= op[1] < 0x18003e28
                            for op in radio.ops if op[0] == 'poke'))
        forbidden_reads = {0x14030000, 0x14030014, 0x14000020}
        self.assertFalse(any(op[0] == 'peek' and op[1] in forbidden_reads for op in radio.ops))
        self.assertEqual(port.closes, 1)

    def test_compare_pll_wrong_clock_uart_timer_or_monitor_refuses_before_any_poke(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        changes = [('CTRL', lambda r:r.clock_registers.update(CTRL=0xc0000004)),
                   ('DIV', lambda r:r.clock_registers.update(DIV=2)),
                   ('UART', lambda r:r.clock_registers.update(UART_IER=0)),
                   ('APLL', lambda r:r.clock_registers.update(APLL=0x45040eb2)),
                   ('timer', lambda r:r.clock_registers.update(TIMER2_CTRL=7)),
                   ('APB', lambda r:r.apb_samples.__setitem__(1, 60000000)),
                   ('monitor', lambda r:r.v6.update(board=0))]
        for name, change in changes:
            proof, radio, port = self.make_pll_peer()
            change(radio)
            with self.subTest(case=name), self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 5, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertFalse(any(op[0] in ('poke', 'call', 'start') for op in radio.ops))
            self.assertEqual(port.closes, 1)

    def test_compare_pll_live_smoke_image_is_required_before_codec_upload(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        for address in (probe.ARGS+8, probe.ENTRY):
            proof, radio, port = self.make_pll_peer()
            radio.memory[address] ^= 1
            with self.subTest(address=address), self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 5, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertFalse(any(op[0] in ('poke', 'call') for op in radio.ops))
            self.assertEqual(port.closes, 1)

    def test_compare_pll_clock_record_is_exactly_60m_and_old_modes_reject_it(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        crc = fixture.validate_benchmark_blob(raw)['payload_crc32']
        parsed = probe.parse_packet(packet(mode=5, recs=records(5, fixture_crc=crc)),
                                    123, 5, frames=2, fixture_crc=crc)
        self.assertEqual(parsed['records'][9]['value'], 60000000)
        for mode, clock in ((5, 0), (5, 24000000), (5, 84000000), (4, 60000000), (3, 60000000)):
            recs = records(mode, fixture_crc=crc)
            recs[9]['value'] = clock
            with self.subTest(mode=mode, clock=clock), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=mode, recs=recs), 123, mode, frames=2, fixture_crc=crc)

    def test_compare_pll_fault_checks_clock_restoration_without_recalling_target(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        for failure in ('target fault', 'CRC', 'truncated', 'CALL transport'):
            proof, radio, port = self.make_pll_peer()
            if failure == 'target fault':
                def fault(recs):
                    recs[8].update(status=3, vector=4, epc=0x40020, epsr=0x80000000)
                    return recs
                radio.record_change = fault
            elif failure == 'CRC':
                radio.result_change = lambda raw:raw[:-1]+bytes([raw[-1]^1])
            elif failure == 'truncated':
                radio.result_change = lambda raw:raw[:10]
            else:
                radio.jump_error = OSError('CALL transport lost')
            with self.subTest(case=failure), self.fake_transport(), self.assertRaises((probe.ProbeError, OSError)) as context:
                probe.execute(self.bundle, 5, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            error = context.exception
            self.assertTrue(error.monitor_returned)
            self.assertTrue(error.clock_restored)
            self.assertEqual(error.clock_before, error.clock_after)
            self.assertEqual(error.apb_hz_after, [24000000]*3)
            self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
            self.assertEqual(port.closes, 1)

    def test_compare_pll_returning_monitor_with_changed_clock_is_fatal(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        proof, radio, port = self.make_pll_peer()
        radio.after_call = lambda:radio.clock_registers.update(CTRL=0xc0000004)
        with self.fake_transport(), self.assertRaises(probe.ProbeError) as context:
            probe.execute(self.bundle, 5, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                          radio_factory=lambda p:radio, port_factory=lambda n:port)
        self.assertTrue(context.exception.monitor_returned)
        self.assertFalse(context.exception.clock_restored)
        self.assertEqual(context.exception.clock_after['CTRL'], 0xc0000004)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        self.assertEqual(port.closes, 1)

    def test_compare_pll_cli_validates_both_golden_references_in_dry_run(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        info = fixture.validate_benchmark_blob(raw)
        blob = self.directory/'compare-pll.bin';blob.write_bytes(raw)
        software = self.directory/'pll-software.pcm';software.write_bytes(bytes(640))
        native = self.directory/'pll-native.json'
        native.write_text(json.dumps(dict(mode=3, monitor_returned=True, manifest={'native':self.native},
            mixed_fixture={'sha256':info['native_legacy_sha256']}, pcm_hex=bytes(640).hex(),
            pcm={'sha256':probe.digest(bytes(640))}, result={'records':[{'value':zlib.crc32(bytes(640))}]})))
        arguments = ['native-synthesis-probe.py', '--manifest', str(self.path), '--backup', str(self.backup),
                     '--mode', 'compare-pll', '--fixture', str(blob), '--software-reference', str(software),
                     '--native-reference', str(native)]
        output = io.StringIO()
        with mock.patch.object(sys, 'argv', arguments), mock.patch.dict(sys.modules, {'serial':None}), \
             mock.patch.object(probe, 'execute', side_effect=AssertionError('execute called')), \
             contextlib.redirect_stdout(output):
            probe.main()
        report = json.loads(output.getvalue())
        self.assertTrue(report['dry_run'])
        self.assertFalse(report['serial_opened'])
        self.assertEqual(report['hardware_mode'], 'compare-pll')
        software.write_bytes(bytes(638))
        with mock.patch.object(sys, 'argv', arguments), mock.patch.object(probe, 'execute') as execute, \
             self.assertRaisesRegex(probe.ProbeError, 'reference PCM size'):
            probe.main()
        execute.assert_not_called()

    def test_compare_timing_arrays_require_exact_crc_tails_totals_and_whole_frame_maxima(self):
        ticks = frame_ticks(3);recs = records(4, frames=3)
        valid = probe.benchmark_timings(ticks, 3, recs)
        self.assertAlmostEqual(valid['native_core']['median_us'], 1010/24)
        bad_records = [(8, 'value', recs[8]['value']+1), (8, 'aux', recs[8]['aux']-1),
                       (14, 'value', recs[14]['value']+1), (14, 'aux', recs[14]['aux']-1),
                       (16, 'value', recs[16]['value']^1)]
        for index, field, value in bad_records:
            changed = copy.deepcopy(recs);changed[index][field] = value
            with self.subTest(index=index, field=field), self.assertRaises(probe.ProbeError):
                probe.benchmark_timings(ticks, 3, changed)
        tail = bytearray(ticks);struct.pack_into('<I', tail, 3*4, 1)
        changed = copy.deepcopy(recs);changed[16]['value'] = zlib.crc32(tail)
        with self.assertRaises(probe.ProbeError):
            probe.benchmark_timings(bytes(tail), 3, changed)
        for malformed, count in ((ticks[:-1], 3), (ticks+b'\0', 3), (ticks, 0), (ticks, 65), (ticks, True)):
            with self.subTest(length=len(malformed), frames=count), self.assertRaises(probe.ProbeError):
                probe.benchmark_timings(malformed, count, recs)

    def test_compare_packet_counts_source_and_timing_lengths_are_fatal(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        crc = fixture.validate_benchmark_blob(raw)['payload_crc32']
        recs = records(4, fixture_crc=crc)
        probe.parse_packet(packet(mode=4, recs=recs), 123, 4, frames=2, fixture_crc=crc)
        mutations = [(4, 'aux', crc^1), (5, 'value', 2), (10, 'aux', 319),
                     (11, 'value', 4), (11, 'aux', 319), (15, 'aux', 0xffffffff),
                     (16, 'aux', 1023), (14, 'status', 4)]
        for index, field, value in mutations:
            changed = copy.deepcopy(recs);changed[index][field] = value
            with self.subTest(index=index, field=field), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=4, recs=changed), 123, 4, frames=2, fixture_crc=crc)

    def test_compare_wrong_fixture_and_corrupted_timing_readback_are_refused(self):
        raw, _ = self.make_fixture(3, benchmark=True)
        legacy = fixture.benchmark_to_legacy(raw)
        proof, smoke_radio, _, _ = self.make_smoke_proof()
        with self.assertRaises((probe.ProbeError, ValueError)):
            probe.execute(self.bundle, 4, 'FAKE', 456, resume=True, proof=proof, fixture=legacy,
                          radio_factory=lambda p:self.fail('radio created'),
                          port_factory=lambda n:self.fail('port opened'))
        port = FakePort();radio = FakeRadio(port);radio.memory = smoke_radio.memory.copy()
        original = radio.peek
        def corrupt(address, count):
            value = original(address, count)
            return value[:-1] if address == 0x55a00 else value
        with mock.patch.object(radio, 'peek', side_effect=corrupt), self.fake_transport(), self.assertRaises(probe.ProbeError):
            probe.execute(self.bundle, 4, 'FAKE', 456, resume=True, proof=proof, fixture=raw,
                          radio_factory=lambda p:radio, port_factory=lambda n:port)
        self.assertEqual(sum(op[0] == 'call' for op in radio.ops), 1)
        self.assertEqual(port.closes, 1)

    def test_compare_unavailable_clock_has_no_elapsed_or_speedup_claim(self):
        ticks = bytes(1024);recs = records(4, frames=3)
        recs[8].update(value=0, aux=0);recs[9].update(value=0, aux=2)
        recs[14].update(value=0, aux=0);recs[16]['value'] = zlib.crc32(ticks)
        result = probe.benchmark_timings(ticks, 3, recs)
        self.assertIsNone(result['native_core_speedup_ratio'])
        self.assertIsNone(result['native_including_bridge_speedup_ratio'])
        self.assertIsNone(result['native_core']['mean_us'])
        self.assertIsNone(result['software_core']['max_us'])
        nonzero = bytearray(ticks);struct.pack_into('<I', nonzero, 0, 1)
        recs[16]['value'] = zlib.crc32(nonzero)
        with self.assertRaises(probe.ProbeError):
            probe.benchmark_timings(bytes(nonzero), 3, recs)

    def test_compare_cli_references_are_bounded_and_bound_to_legacy_fixture_before_execute(self):
        raw, _ = self.make_fixture(2, benchmark=True)
        info = fixture.validate_benchmark_blob(raw)
        blob_path = self.directory/'compare.bin';blob_path.write_bytes(raw)
        software = self.directory/'software.pcm';software.write_bytes(bytes(640))
        native = self.directory/'native.json'
        previous = dict(mode=3, monitor_returned=True, manifest={'native':self.native},
                        mixed_fixture={'sha256':info['native_legacy_sha256']},
                        pcm_hex=bytes(640).hex(), pcm={'sha256':probe.digest(bytes(640))},
                        result={'records':[{'value':zlib.crc32(bytes(640))}]})
        native.write_text(json.dumps(previous))
        args = ['native-synthesis-probe.py', '--manifest', str(self.path), '--backup', str(self.backup),
                '--mode', 'compare', '--fixture', str(blob_path), '--software-reference', str(software),
                '--native-reference', str(native)]
        output = io.StringIO()
        with mock.patch.object(sys, 'argv', args), mock.patch.dict(sys.modules, {'serial':None}), \
             mock.patch.object(probe, 'execute', side_effect=AssertionError('execute called')), \
             contextlib.redirect_stdout(output):
            probe.main()
        self.assertTrue(json.loads(output.getvalue())['dry_run'])
        for kind in ('software length', 'native fixture', 'native PCM'):
            software.write_bytes(bytes(640));changed = copy.deepcopy(previous)
            if kind == 'software length':
                software.write_bytes(bytes(638))
            elif kind == 'native fixture':
                changed['mixed_fixture']['sha256'] = '0'*64
            else:
                changed['pcm_hex'] = bytes(638).hex()
            native.write_text(json.dumps(changed))
            with self.subTest(kind=kind), mock.patch.object(sys, 'argv', args), \
                 mock.patch.object(probe, 'execute', side_effect=AssertionError('execute called')), \
                 self.assertRaises(probe.ProbeError):
                probe.main()

    def test_monitor_overlap_readback_and_clock_mismatch_prevent_call(self):
        changes = [('monitor-overlap', lambda r:r.v6.update(run=0x40000, image=0x1000, bss_end=0x42000, stack_lo=0x43000, stack_top=0x48000)),
                   ('native-code-overlap', lambda r:r.v6.update(load=0x16d00)),
                   ('readback', lambda r:setattr(r, 'bad_readback', True)),
                   ('clock', lambda r:setattr(r, 'uart_hz', 84000000)),
                   ('headroom', lambda r:r.v6.update(stack_used=0x4000-64))]
        for name, change in changes:
            port, radio = FakePort(), None
            radio = FakeRadio(port)
            change(radio)
            with self.subTest(case=name), self.fake_transport(), self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle, 0, 'FAKE', 123,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertFalse(any(x[0] == 'call' for x in radio.ops))
            self.assertEqual(port.closes, 1)
            if name in ('monitor-overlap', 'native-code-overlap', 'headroom'):
                self.assertFalse(any(x[0] == 'poke' for x in radio.ops))

    def test_packet_crc_nonce_build_mode_faults_and_oracle_mismatch_refused(self):
        invalid = []
        damaged = bytearray(packet());damaged[-1] ^= 1;invalid.append(bytes(damaged))
        damaged = bytearray(packet());damaged[0] ^= 1;invalid.append(bytes(damaged))
        for header in ({'nonce':1}, {'build_id':0}, {'mode':1}, {'record_count':17},
                       {'total_bytes':0xffffffff}, {'fatal':1}, {'guard_mask':15},
                       {'cpuid_words':1}, {'initial_vbr':1}, {'initial_psr':0x80000140},
                       {'initial_sp':0x37f01}, {'initial_sp':0x14000000}):
            invalid.append(packet(header=header))
        for change in (lambda r:r[0].update(status=3), lambda r:r[0].update(vector=4),
                       lambda r:r[0].update(value=0), lambda r:r[0].update(reserved=1)):
            recs = records(0);change(recs);invalid.append(packet(recs=recs))
        for raw in invalid:
            with self.subTest(packet=raw.hex()), self.assertRaises(probe.ProbeError):
                probe.parse_packet(raw, 123, 0)
        for index, field in ((1, 'value'), (1, 'aux'), (2, 'value'), (2, 'aux'), (6, 'aux')):
            recs = records(1);recs[index][field] ^= 1
            with self.subTest(index=index, field=field), self.assertRaises(probe.ProbeError):
                probe.parse_packet(packet(mode=1, recs=recs), 123, 1)

    def test_result_failure_or_call_transport_error_never_retries_call(self):
        for kind in ('crc', 'fault', 'call-error', 'truncated'):
            port = FakePort();radio = FakeRadio(port)
            if kind == 'crc':
                radio.result_change = lambda raw:raw[:-1]+bytes([raw[-1]^1])
            elif kind == 'fault':
                radio.result_change = lambda raw:packet(header={'fatal':1})
            elif kind == 'truncated':
                radio.result_change = lambda raw:raw[:10]
            else:
                radio.jump_error = OSError('Call reply lost')
            with self.subTest(kind=kind), self.fake_transport(), self.assertRaises((probe.ProbeError, OSError)) as error:
                probe.execute(self.bundle, 0, 'FAKE', 123,
                              radio_factory=lambda p:radio, port_factory=lambda n:port)
            self.assertEqual(sum(x[0] == 'call' for x in radio.ops), 1)
            self.assertTrue(error.exception.monitor_returned)
            self.assertEqual(port.closes, 1)

    def test_entry_stack_outside_verified_monitor_reservation_is_refused(self):
        port = FakePort();radio = FakeRadio(port)
        radio.result_change = lambda raw:packet(header={'initial_sp':0x34040})
        with self.fake_transport(), self.assertRaisesRegex(probe.ProbeError, 'monitor reservation'):
            probe.execute(self.bundle, 0, 'FAKE', 123,
                          radio_factory=lambda p:radio, port_factory=lambda n:port)
        self.assertEqual(sum(x[0] == 'call' for x in radio.ops), 1)
        self.assertEqual(port.closes, 1)

    def test_caller_supplied_proof_is_revalidated_before_opening_serial(self):
        proof, _, _, _ = self.make_smoke_proof()
        proof['raw_sha256'] = '0'*64
        with self.assertRaises(probe.ProbeError):
            probe.execute(self.bundle, 1, 'FAKE', 456, resume=True, proof=proof,
                          port_factory=lambda n:self.fail('port opened'), radio_factory=lambda p:None)

    def test_smoke_report_rejects_changed_manifest_session_crc_and_failure(self):
        proof, _, _, path = self.make_smoke_proof()
        mutations = [lambda p:p.update(dry_run=True), lambda p:p.update(mode=1),
            lambda p:p.update(monitor_returned=False), lambda p:p.update(error='fault'),
            lambda p:p.update(nonce=456), lambda p:p.update(raw_sha256='0'*64),
            lambda p:p['manifest'].update(source_commit='b'*40),
            lambda p:p.update(raw_hex=packet(123, 0, header={'fatal':1}).hex(),
                              raw_sha256=probe.digest(packet(123, 0, header={'fatal':1})))]
        for mutate in mutations:
            candidate = copy.deepcopy(proof);mutate(candidate);path.write_text(json.dumps(candidate))
            with self.subTest(proof=candidate), self.assertRaises(probe.ProbeError):
                probe.smoke_proof(path, self.bundle)


if __name__ == '__main__':
    unittest.main()
