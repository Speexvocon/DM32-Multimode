# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact trellis shortcut against the hash-pinned original Viterbi decoder.

No RF or radio access. Cover clean codewords, every one-bit channel mutation,
random damage and ties, forced endpoints, all data block positions, byte bounds,
output guards, and CRC-invalid but perfectly encoded application payloads.
"""
import ctypes as C
import hashlib
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'tests/reference/p25_data_fec_viterbi.h'
assert hashlib.sha256(FROZEN.read_bytes().replace(b'\r\n', b'\n')).hexdigest() == (
    'c4aa454c663401df24853c92d306323de38e38b581b2d5a7f7c46860443d6fc8'
), 'Frozen original Viterbi reference changed'
BUILD = ROOT / 'build/test-p25-data-fec'
BUILD.mkdir(parents=True, exist_ok=True)
LIBRARY = BUILD / ('data_fec.dll' if sys.platform == 'win32' else 'data_fec.so')
command = ['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wshadow', '-shared']
if sys.platform != 'win32':
    command.append('-fPIC')
command += ['-Isrc/firmware', 'tests/test_p25_data_fec_bridge.c',
            'tests/test_p25_data_fec_reference.c', 'src/firmware/p25_rx.c',
            'src/firmware/p25_tsdu.c', '-o', str(LIBRARY)]
subprocess.run(command, cwd=ROOT, check=True, timeout=120)
lib = C.CDLL(str(LIBRARY))
Byte = C.c_uint8
Pointer = C.POINTER(Byte)
lib.p25_test_data_decode.argtypes = [Pointer, C.c_size_t, C.c_uint, Pointer, C.POINTER(C.c_uint)]
lib.p25_test_data_decode.restype = C.c_bool
lib.p25_test_frozen_decode.argtypes = [Pointer, C.c_size_t, C.c_uint, Pointer]
lib.p25_test_frozen_decode.restype = C.c_bool
lib.p25_test_data_inverse.argtypes = [C.c_uint]
lib.p25_test_data_inverse.restype = C.c_uint
lib.p25_tsdu_encode.argtypes = [Pointer, C.c_size_t, C.c_uint16, C.POINTER(Byte * 12),
                              C.c_uint, Byte]
lib.p25_tsdu_encode.restype = C.c_size_t


class Tsdu(C.Structure):
    _fields_ = [('nac', C.c_uint16), ('count', Byte), ('block', (Byte * 12) * 3)]


lib.p25_tsdu_decode.argtypes = [Pointer, C.c_size_t, C.POINTER(Tsdu)]
lib.p25_tsdu_decode.restype = C.c_bool

# P25 rate-1/2 encoder edges, written independently as pairs of dibits.
PAIRS = (((0, 2), (3, 0), (0, 1), (3, 3)),
         ((3, 2), (0, 0), (3, 1), (0, 3)),
         ((2, 1), (1, 3), (2, 2), (1, 0)),
         ((1, 1), (2, 3), (1, 2), (2, 0)))
EDGES = tuple(tuple((a << 2) | b for a, b in row) for row in PAIRS)
assert sorted(value for row in EDGES for value in row) == list(range(16))
for previous, row in enumerate(EDGES):
    for following, value in enumerate(row):
        assert lib.p25_test_data_inverse(value) == (previous << 2) | following


def encode(payload, start=0, tail=0):
    assert len(payload) == 12
    values = [(value >> shift) & 3 for value in payload for shift in (6, 4, 2, 0)] + [tail]
    result = []
    for value in values:
        result.append(EDGES[start][value])
        start = value
    return result


def interleave_index(index):
    pair, bit = divmod(index, 2)
    if pair < 13:
        return pair * 8 + bit
    pair -= 13
    return (pair // 12 + 1) * 2 + (pair % 12) * 8 + bit


def packed(symbols, block=0, length=None, original=None):
    received = [dibit for value in symbols for dibit in (value >> 2, value & 3)]
    last = 56 + block * 98 + 97
    minimum = (last + last // 35) // 4 + 1
    if length is None:
        length = minimum
    result = bytearray(original if original is not None else b'\xa5' * length)
    assert len(result) == length and length >= minimum
    for index in range(98):
        data = 56 + block * 98 + index
        physical = data + data // 35
        shift = 6 - 2 * (physical % 4)
        result[physical // 4] = ((result[physical // 4] & ~(3 << shift)) |
                                 received[interleave_index(index)] << shift)
    return bytes(result)


comparisons = clean = fallback = failures = 0


def compare(frame, block=0, expected=None, expected_branches=None):
    global comparisons, clean, fallback, failures
    wire = (Byte * len(frame)).from_buffer_copy(frame)
    before = b'\x37' + b'\xa5' * 12 + b'\xe9'
    actual = (Byte * 14).from_buffer_copy(before)
    reference = (Byte * 14).from_buffer_copy(before)
    out = C.cast(C.byref(actual, 1), Pointer)
    old_out = C.cast(C.byref(reference, 1), Pointer)
    branches = C.c_uint(12345)
    success = bool(lib.p25_test_data_decode(wire, len(frame), block, out, C.byref(branches)))
    old_success = bool(lib.p25_test_frozen_decode(wire, len(frame), block, old_out))
    assert (success, bytes(actual)) == (old_success, bytes(reference)), (
        block, frame.hex(), success, old_success, bytes(actual).hex(), bytes(reference).hex())
    assert actual[0] == before[0] and actual[13] == before[13], 'Output guard damaged'
    assert branches.value in (0, 784), branches.value
    if expected is not None:
        assert success and bytes(actual)[1:13] == expected
    if expected_branches is not None:
        assert branches.value == expected_branches, (branches.value, expected_branches)
    if not success:
        failures += 1
        assert bytes(actual) == before, 'Failure changed output'
    if branches.value:
        fallback += 1
    elif success:
        clean += 1
    comparisons += 1
    return success


rng = random.Random(0x25C1EA)
payloads = [bytes(12), bytes([255]) * 12, bytes(range(12)), bytes([0xAA, 0x55]) * 6]
payloads += [rng.randbytes(12) for _ in range(60)]

# Every legal header/data block position, with unrelated prefix/status bytes.
for block in range(19):
    for payload in payloads:
        compare(packed(encode(payload), block), block, payload, 0)

# Every one of 196 transmitted coded bits, at both ends of the block range.
for block in (0, 1, 2, 18):
    payload = rng.randbytes(12)
    original = encode(payload)
    for bit in range(196):
        damaged = original.copy()
        damaged[bit // 4] ^= 1 << (3 - bit % 4)
        compare(packed(damaged, block), block, expected_branches=784)

# Forced start and zero tail are part of the exact-path proof; neither may be
# inferred from an otherwise valid sequence. Original Viterbi remains authority.
for payload in payloads[:8]:
    for state in (1, 2, 3):
        compare(packed(encode(payload, start=state)), expected_branches=784)
        compare(packed(encode(payload, tail=state)), expected_branches=784)

# Random multiple-bit errors, arbitrary hard decisions, repeated ties, and
# the old metric>16 refusal. Compare output bytes even when decoding fails.
for trial in range(1200):
    block = rng.randrange(19)
    symbols = encode(rng.randbytes(12))
    for bit in rng.sample(range(196), rng.randrange(2, 81)):
        symbols[bit // 4] ^= 1 << (3 - bit % 4)
    compare(packed(symbols, block), block)
for trial in range(400):
    block = rng.randrange(19)
    compare(packed([rng.randrange(16) for _ in range(49)], block), block,
            expected_branches=784)
for value in range(16):
    compare(packed([value] * 49))

# All truncation boundaries at all legal positions; no partial output. Padded
# frames also behave identically, and nonzero status dibits are not trellis data.
for block in range(19):
    payload = rng.randbytes(12)
    wire = packed(encode(payload), block)
    for length in range(len(wire)):
        compare(wire[:length], block, expected_branches=0)
    for length in (len(wire), 512):
        compare(packed(encode(payload), block, length), block, payload, 0)


def crc16(payload):
    crc = 0
    for value in payload:
        for shift in range(7, -1, -1):
            feedback = ((crc >> 15) ^ (value >> shift)) & 1
            crc = (crc << 1) & 0xFFFF
            if feedback:
                crc ^= 0x1021
    return crc ^ 0xFFFF


# A clean trellis word does not authorize a control block: leave all application
# CRC validation unchanged, including unchanged output on a refused envelope.
block = bytearray.fromhex('b4001000640000a0a4fe0000')
block[-2:] = crc16(block[:10]).to_bytes(2, 'big')
native_block = (Byte * 12).from_buffer_copy(block)
wire = (Byte * 90)()
length = lib.p25_tsdu_encode(wire, 90, 0x293, C.pointer(native_block), 1, 2)
assert length == 45
valid = bytes(wire[:length])
value = Tsdu()
assert lib.p25_tsdu_decode((Byte * length).from_buffer_copy(valid), length, C.byref(value))
assert value.nac == 0x293 and value.count == 1 and bytes(value.block[0]) == bytes(block)
block[3] ^= 1  # Encodable payload with a deliberately invalid unchanged CRC.
invalid = packed(encode(block), length=length, original=valid)
compare(invalid, expected=bytes(block), expected_branches=0)
C.memset(C.byref(value), 0xA5, C.sizeof(value))
before = bytes(value)
assert not lib.p25_tsdu_decode((Byte * length).from_buffer_copy(invalid), length, C.byref(value))
assert bytes(value) == before, 'CRC refusal changed application output'
assert clean >= 1200 and fallback >= 2000 and failures > 400
print(f'PASS clean trellis: {comparisons} frozen-reference comparisons; '
      f'{clean} exact paths, {fallback} Viterbi fallbacks, {failures} refusals. '
      'Clean path: 49 exact transitions, zero Viterbi branch metrics; original: 784 metrics/block. '
      'This is operation evidence, not processor timing.')
