# SPDX-License-Identifier: GPL-3.0-or-later
"""Canonical RXEARLY wire, source provenance and non-retroactive pairing tests."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

A = load(ROOT / "scripts/analyze-p25-rx-early.py", "rx_early_test_parser")
F = load(ROOT / "tests/test_p25_rx_origin_analyzer.py", "rx_early_origin_fixtures")


def early(**changes):
    options = dict(kind=4, evidence=1)
    options.update(changes)
    return F.event(**options)


def capture(events=None, **changes):
    if events is None:
        events = [early(), F.event(tick=600, ordinal=150)]
    return F.capture(events, **changes).replace("RXORIGIN", "RXEARLY").replace(
        "schema=1", "schema=1 early=prev_crc")


class EarlyAnalysisTests(unittest.TestCase):
    def refuses(self, text):
        with self.assertRaises(A.EarlyError):
            A.parse_trace(text)

    def test_exact64_byte_wire_is_preserved_and_early_never_qualifies(self):
        wire = early()
        self.assertEqual(len(wire), 64)
        self.assertEqual(wire[40:48], bytes([4,7,3,0,0,0,1,0]))
        text = capture()
        result = A.parse_trace(text)
        self.assertEqual(result["schema"], "p25-rx-early-analysis-v1")
        self.assertEqual(result["original_wire_text"], text)
        self.assertTrue(result["all_streams_coherent"])
        self.assertTrue(result["all_producers_coherent"])
        cap = result["captures"][0]
        self.assertEqual(cap["events"][0]["wire_hex"], wire.hex())
        self.assertEqual(cap["halves"][0]["wire_hex"], F.half(0).hex())
        row = cap["events"][0]
        self.assertEqual((row["type"], row["status"], row["evidence"]), (4,3,1))
        self.assertTrue(row["selected"])
        for key in ("qualified", "current_nid_qualified", "mapping_eligible",
                    "retroactively_qualified", "early_status_qualified", "early_rf_match_qualified"):
            self.assertIs(row[key], False)
        for key in A.FLAGS:
            self.assertIs(result[key], False)
        self.assertFalse(result["external_rf_matching_performed"])
        self.assertFalse(result["early_qualification_inferred"])

    def test_raw_status00_is_unqualified_not_loss_and_can_remain_unpaired(self):
        for status in range(4):
            value = A.parse_trace(capture([early(status=status)]))
            self.assertTrue(value["all_streams_coherent"])
            cap = value["captures"][0]
            row = cap["events"][0]
            self.assertEqual(row["status"], status)
            self.assertEqual(bytes.fromhex(row["wire_hex"])[42], status)
            self.assertEqual(row["type"], A.EARLY)
            self.assertFalse(row["qualified"])
            observation = cap["event_observations"]
            self.assertEqual(observation["event_type_counts"], {4:1})
            self.assertEqual(observation["early_pair_observations"]["unpaired_event_indices"], [0])
            self.assertIsNone(observation["qualified_status_spacing_ticks"])
            self.assertEqual(observation["native_units"], [])

    def test_later_current_nid_pair_is_descriptive_with_inherited_nac_separate(self):
        value = A.parse_trace(capture([early(), F.event(tick=600, ordinal=150)]))
        observation = value["captures"][0]["event_observations"]
        pair = observation["early_pair_observations"]["pairs"][0]
        self.assertEqual((pair["early_event_index"], pair["qualified_event_index"]), (0,1))
        self.assertEqual((pair["inherited_nac"], pair["current_nid_nac"]), (0x293,0x293))
        self.assertTrue(pair["inherited_nac_matches_current_nid"])
        self.assertEqual(pair["delivery_input_ordinal_delta"], 30)
        self.assertEqual(pair["nominal_input_delay_us"], 3750)
        rows = value["captures"][0]["events"]
        self.assertEqual(pair["callback_delay_us"], rows[1]["cpu_us"]-rows[0]["cpu_us"])
        self.assertFalse(pair["early_was_qualified_at_delivery"])
        self.assertFalse(pair["retroactive_qualification"])
        self.assertFalse(rows[0]["qualified"])
        self.assertTrue(rows[1]["qualified"])

    def test_current_nac_conflict_stays_unpaired_and_preserves_both_observations(self):
        value = A.parse_trace(capture([early(nac=0x123), F.event(tick=600, ordinal=150)]))
        cap = value["captures"][0]
        pairs = cap["event_observations"]["early_pair_observations"]
        self.assertEqual(pairs["paired_count"], 0)
        self.assertEqual(pairs["unpaired_event_indices"], [0])
        self.assertEqual(len(pairs["unpaired_nac_conflicts"]), 1)
        self.assertEqual(cap["events"][0]["later_pair_state"], "current_nac_conflict")
        self.assertFalse(cap["events"][0]["qualified"])
        self.assertTrue(cap["events"][1]["qualified"])

    def test_early_does_not_reset_or_enter_qualified_status_cadence(self):
        events = [F.event(tick=240, ordinal=80), early(tick=600, ordinal=120),
                  F.event(tick=600, ordinal=150)]
        observation = A.parse_trace(capture(events))["captures"][0]["event_observations"]
        spacing = observation["qualified_status_spacing_ticks"]
        self.assertEqual((spacing["count"], spacing["min"], spacing["max"]), (1,360,360))
        self.assertEqual(len(observation["early_status_observations"]), 1)
        self.assertEqual(observation["early_pair_observations"]["paired_count"], 1)

    def test_fault_or_epoch_change_blocks_pairing_and_never_erases_early(self):
        cases = [
            [early(), F.fault(reason=1,cpu=125000), F.event(tick=600, ordinal=300)],
            [early(), F.event(tick=600, ordinal=300, lane_epoch=2)],
        ]
        for events in cases:
            result = A.parse_trace(capture(events))
            self.assertTrue(result["all_producers_coherent"])
            self.assertFalse(result["all_streams_coherent"])
            cap = result["captures"][0]
            pair = cap["event_observations"]["early_pair_observations"]
            self.assertEqual(pair["paired_count"], 0)
            self.assertEqual(cap["events"][0]["type"], 4)
            self.assertFalse(cap["events"][0]["qualified"])
            self.assertGreater(len(cap["event_observations"]["segments"]), 1)

    def test_bad_current_nid_or_no_later_status_leaves_early_unqualified(self):
        for events in ([early()], [early(), F.unit()],
                       [early(), F.event(tick=600, ordinal=150, evidence=1)]):
            cap = A.parse_trace(capture(events))["captures"][0]
            pairs = cap["event_observations"]["early_pair_observations"]
            self.assertEqual(pairs["paired_count"], 0)
            self.assertFalse(cap["events"][0]["qualified"])
            self.assertIsNone(cap["events"][0]["later_qualified_event_index"])

    def test_pair_requires_same_tick_lane_status_and_observation_order(self):
        for later in (F.event(tick=601,ordinal=150), F.event(tick=600,ordinal=150,lane=1),
                      F.event(tick=600,ordinal=150,status=2)):
            pairs = A.parse_trace(capture([early(),later]))["captures"][0]["event_observations"]["early_pair_observations"]
            self.assertEqual(pairs["paired_count"], 0)
        cap = A.parse_trace(capture([F.event(tick=600,ordinal=120),early(tick=600,ordinal=150)]))["captures"][0]
        self.assertEqual(cap["event_observations"]["early_pair_observations"]["paired_count"], 0)

    def test_ambiguous_duplicate_early_is_retained_but_not_paired(self):
        result = A.parse_trace(capture([early(),early(),F.event(tick=600,ordinal=150)]))
        self.assertTrue(result["all_producers_coherent"])
        self.assertFalse(result["all_streams_coherent"])
        pairs = result["captures"][0]["event_observations"]["early_pair_observations"]
        self.assertEqual(pairs["pairs"], [])
        self.assertEqual(pairs["ambiguous_event_indices"], [0,1])

    def test_source_validation_is_not_weakened_by_early_adapter(self):
        changes = [dict(chunk=8),dict(chunk=113),dict(ordinal=128,chunk=112),
                   dict(irq_count=2),dict(irq_origin=132000),dict(source_flags=1),
                   dict(stream=8),dict(nac=4096),dict(tick=721),
                   dict(read_begin=120000,read_end=119999),
                   dict(read_begin=120000,read_end=120081),
                   dict(read_begin=120000,read_end=120080,cpu=120079)]
        for change in changes:
            with self.subTest(change=change): self.refuses(capture([early(**change)]))

    def test_early_evidence_duid_lane_descriptor_and_payload_are_strict(self):
        changes = [dict(kind=5),dict(duid=5),dict(status=4),dict(lane=10),dict(lane=255),
                   dict(evidence=0),dict(evidence=2),dict(evidence=3),dict(evidence=5),
                   dict(descriptor=0x10),dict(data=b"x"*12)]
        for change in changes:
            with self.subTest(change=change): self.refuses(capture([early(**change)]))
        self.refuses(capture([F.event(status=0)])) # legacy STATUS00 still invalid

    def test_original_types_and_native_unit_block_guards_stay_strict(self):
        result = A.parse_trace(capture([F.event(),F.unit()]))
        self.assertTrue(result["all_streams_coherent"])
        self.assertEqual(result["captures"][0]["event_observations"]["early_status_observations"], [])
        for row in (F.unit(evidence=7),F.unit(descriptor=0x11),F.fault(evidence=1)):
            self.refuses(capture([row]))
        first = F.unit(descriptor=0x20)
        cap = A.parse_trace(capture([first,early(ordinal=241,tick=600)]))["captures"][0]
        self.assertFalse(cap["coherent"])
        self.assertFalse(cap["event_observations"]["native_units"][0]["match_eligible"])

    def test_header_schema_bounds_unknown_and_missing_fields_are_strict(self):
        base = capture()
        for text in (base.replace("early=prev_crc", "early=current"),
                     base.replace(" early=prev_crc", ""),
                     base.replace("early=prev_crc", "early=prev_crc early=prev_crc"),
                     base.replace("schema=1", "schema=2"),
                     base.replace("guard_us=2000", "guard_us=2000 alien=1"),
                     base.replace("event_bytes=64", "event_bytes=32"),
                     base.replace("marker_capacity=192", "marker_capacity=384"),
                     base.replace("carrier_hz=440075000", "carrier_hz=440087500")):
            self.refuses(text)
        self.assertTrue(A.parse_trace(capture([],samples=4096))["all_producers_coherent"])
        self.refuses(capture([],samples=4352))
        self.refuses(capture([F.fault()]*193,state="fault",faults=4096))

    def test_half_checks_order_truncation_and_original_wire_family_remain_strict(self):
        self.refuses(capture(halves=[F.half(0,completed=1),F.half(1)]))
        base = capture()
        for text in (base[:base.index("RXEARLY_END")],
                     base.replace("RXEARLY_EVENT index=1", "RXEARLY_EVENT index=0"),
                     base.replace("RXEARLY_EVENT index=0 data=", "RXEARLY_EVENT index=0 data=f"),
                     base.replace("RXEARLY_EVENT", "RXORIGIN_EVENT")):
            self.refuses(text)
        with self.assertRaises(A.origin.OriginError): A.origin.parse_trace(base)
        self.refuses(F.capture())

    def test_uint32_cpu_wrap_does_not_change_early_pair_semantics(self):
        start = F.U32-12000
        value = A.parse_trace(capture([early(origin=start),F.event(tick=600,ordinal=150,origin=start)],origin=start))
        pair = value["captures"][0]["event_observations"]["early_pair_observations"]["pairs"][0]
        self.assertGreater(pair["callback_delay_us"], 0)
        self.assertFalse(pair["retroactive_qualification"])

    def test_cli_valid_fault_and_refusal_exit_codes_without_hardware(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder)/"early.log", Path(folder)/"early.json"
            source.write_text(capture(),encoding="utf-8")
            self.assertEqual(A.main([str(source),"--output",str(output)]),0)
            self.assertFalse(json.loads(output.read_text())["early_qualification_inferred"])
            source.write_text(capture([F.fault()],state="fault",faults=16),encoding="utf-8")
            self.assertEqual(A.main([str(source),"--output",str(output)]),1)
            source.write_text("RXEARLY broken",encoding="utf-8")
            with redirect_stderr(io.StringIO()): self.assertEqual(A.main([str(source)]),2)


if __name__ == "__main__":
    unittest.main()
