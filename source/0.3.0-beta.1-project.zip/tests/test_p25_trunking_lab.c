// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "p25_trunking_lab.h"

int main(int argc,char **argv) {
    assert(P25_TRUNK_LAB_LEGACY5M==0u && P25_TRUNK_LAB_PROFILE_COUNT==2u);
    const uint32_t expected[2][4]={{440075000u,445075000u,440087500u,445087500u},
                                 {440075000u,441075000u,440087500u,441087500u}};
    for(unsigned id=0;id<256u;++id) {
        const p25_trunking_lab_profile *p=p25_trunking_lab_get(id);
        if(id>=2u) {
            assert(!p && !strcmp(p25_trunking_lab_name(id),"INVALID"));
            assert(!p25_trunking_lab_matches(id,440075000u,445075000u,0x293u));continue;
        }
        assert(p && p->control_rx_hz==expected[id][0] && p->control_tx_hz==expected[id][1]);
        assert(p->voice_rx_hz==expected[id][2] && p->voice_tx_hz==expected[id][3]);
        uint8_t parsed=255;assert(p25_trunking_lab_parse(p25_trunking_lab_name(id),&parsed) && parsed==id);
        for(unsigned nac=0;nac<4096u;++nac)
            assert(p25_trunking_lab_matches(id,p->control_rx_hz,p->control_tx_hz,(uint16_t)nac)==(nac==0x293u));
        for(unsigned selected=0;selected<256u;++selected)
            assert(p25_trunking_lab_frozen_matches(selected,id,p->control_rx_hz,p->control_tx_hz,0x293u)==(selected==id));
        assert(!p25_trunking_lab_matches(id,p->control_tx_hz,p->control_rx_hz,0x293u));
        assert(!p25_trunking_lab_matches(id,p->voice_rx_hz,p->voice_tx_hz,0x293u));
        assert(!p25_trunking_lab_matches(id,p->control_rx_hz+1u,p->control_tx_hz,0x293u));
        assert(!p25_trunking_lab_matches(id,p->control_rx_hz,p->control_tx_hz-1u,0x293u));
        assert(!p25_trunking_lab_matches(id,p->control_rx_hz,expected[1u-id][1],0x293u));
    }
    const char *invalid[]={"","legacy5m","COMMONIQ1M "," LEGACY5M","440075000/441075000","INVALID"};
    for(unsigned i=0;i<sizeof invalid/sizeof *invalid;++i) {
        uint8_t id=77;assert(!p25_trunking_lab_parse(invalid[i],&id) && id==77);
    }
    uint8_t id=99;assert(!p25_trunking_lab_parse(NULL,&id) && id==99);
    assert(!p25_trunking_lab_parse("LEGACY5M",NULL));
    if(argc==2 && !strcmp(argv[1],"--catalog")) {
        for(unsigned i=0;i<2u;++i) {
            const p25_trunking_lab_profile *p=p25_trunking_lab_get(i);
            printf("%u %s %lu %lu %lu %lu %u %u %u\n",i,p25_trunking_lab_name(i),
                (unsigned long)p->control_rx_hz,(unsigned long)p->control_tx_hz,
                (unsigned long)p->voice_rx_hz,(unsigned long)p->voice_tx_hz,
                P25_TRUNK_LAB_NAC,P25_TRUNK_LAB_WACN,P25_TRUNK_LAB_SYSTEM);
        }
    } else puts("P25 immutable lab profiles: PASS");
    return 0;
}
