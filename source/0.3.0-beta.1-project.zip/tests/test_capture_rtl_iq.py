"""Finite RTL-SDR callback and ownership failures, without loading USB/DLLs."""
import ctypes as c
from contextlib import redirect_stdout
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('capture_rtl_iq', ROOT/'scripts/capture-rtl-iq.py')
capture = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(capture)
POINTER = 0x123456789ABC  # Deliberately cannot fit an int-sized device handle.


class Function:
    def __init__(self, action):
        self.action = action
        self.calls = []

    def __call__(self, *arguments):
        self.calls.append(arguments)
        return self.action(*arguments)


class Library:
    def __init__(self, *, read_code=0, read_error=None, callback_null=False,
                 setup_code=0, open_code=0, cancel_code=0, cancel_error=None,
                 close_error=None, short=False):
        self.read_code = read_code
        self.read_error = read_error
        self.callback_null = callback_null
        self.setup_code = setup_code
        self.open_code = open_code
        self.cancel_code = cancel_code
        self.cancel_error = cancel_error
        self.close_error = close_error
        self.short = short
        self.functions = {}
        self.callback_count = 0
        self.settings = dict(center_freq=440575000, sample_rate=8, tuner_gain=99,
            tuner_type=5, direct_sampling=0, offset_tuning=0, freq_correction=0)

    def __getattr__(self, name):
        if name not in self.functions:
            self.functions[name] = Function(lambda *arguments: self.call(name, *arguments))
        return self.functions[name]

    def call(self, name, *arguments):
        if name == 'rtlsdr_open':
            if not self.open_code:
                arguments[0]._obj.value = POINTER
            return self.open_code
        assert isinstance(arguments[0], c.c_void_p)
        assert arguments[0].value == POINTER
        if name == 'rtlsdr_close':
            if self.close_error is not None:
                raise self.close_error
            return 0
        if name == 'rtlsdr_cancel_async':
            if self.cancel_error is not None:
                raise self.cancel_error
            return self.cancel_code
        if name == 'rtlsdr_set_sample_rate':
            return self.setup_code
        if name.startswith('rtlsdr_get_'):
            return self.settings[name[len('rtlsdr_get_'):]]
        if name == 'rtlsdr_read_async':
            _, callback, context, buffers, length = arguments
            assert (context, buffers, length) == (None, 16, 262144)
            if self.read_error is not None:
                raise self.read_error
            if self.callback_null:
                self.callback_count += 1
                callback(c.POINTER(c.c_ubyte)(), 8, None)
            values = bytes(range(28))
            boundaries = ((0, 8),) if self.short else ((0, 4), (4, 12), (12, 20), (20, 28))
            for begin, end in boundaries:
                buffer = (c.c_ubyte*(end-begin)).from_buffer_copy(values[begin:end])
                self.callback_count += 1
                callback(buffer, end-begin, None)
            return self.read_code
        return 0

    def count(self, name):
        return len(self.functions.get(name, Function(None)).calls)


class CaptureTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        dll = self.root/'research/tools/rtl-sdr-20261018/native/librtlsdr.dll'
        dll.parent.mkdir(parents=True)
        dll.write_bytes(b'offline mock, never loaded')
        self.output = self.root/'capture.cu8'
        self.cookie = mock.Mock()

    def run_capture(self, lib, *, load_error=None):
        arguments = ['capture-rtl-iq.py', '--frequency', '440575000', '--rate', '8',
            '--seconds', '1', '--gain', '9.9', '--output', str(self.output)]
        with mock.patch.object(capture, 'ROOT', self.root), \
             mock.patch.object(capture.sys, 'argv', arguments), \
             mock.patch.object(capture.os, 'add_dll_directory', create=True, return_value=self.cookie), \
             mock.patch.object(capture.c, 'CDLL', side_effect=load_error, return_value=lib), \
             redirect_stdout(io.StringIO()):
            capture.main()

    def assert_no_output(self):
        self.assertFalse(self.output.exists())
        self.assertFalse(self.output.with_suffix('.cu8.json').exists())

    def test_complete_capture_preserves_settings_samples_and_closes_once(self):
        lib = Library()
        self.run_capture(lib)
        data = bytes(range(4, 20))
        self.assertEqual(self.output.read_bytes(), data)
        metadata = json.loads(self.output.with_suffix('.cu8.json').read_text())
        self.assertEqual(metadata['sha256'], hashlib.sha256(data).hexdigest())
        self.assertEqual((metadata['bytes'], metadata['samples'], metadata['complete']), (16, 8, True))
        self.assertEqual(metadata['device_readback'], lib.settings)
        self.assertEqual((metadata['center_hz'], metadata['gain_requested_db']), (440575000, 9.9))
        self.assertEqual(lib.count('rtlsdr_read_async'), 1)
        self.assertEqual(lib.callback_count, 4)  # Final extra callback must not cancel twice.
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 1)
        self.cookie.close.assert_called_once_with()

    def test_all_native_calls_have_explicit_pointer_width_and_return_abi(self):
        lib = Library()
        capture.configure_library(lib)
        self.assertEqual(lib.rtlsdr_open.argtypes, [c.POINTER(c.c_void_p), c.c_uint32])
        self.assertEqual(lib.rtlsdr_read_async.argtypes,
            [c.c_void_p, capture.CALLBACK, c.c_void_p, c.c_uint32, c.c_uint32])
        unsigned = {'rtlsdr_get_sample_rate', 'rtlsdr_get_center_freq'}
        for name, function in lib.functions.items():
            self.assertEqual(function.restype, c.c_uint32 if name in unsigned else c.c_int, name)
            if name != 'rtlsdr_open':
                self.assertEqual(function.argtypes[0], c.c_void_p, name)
        for name in ('sample_rate', 'center_freq'):
            self.assertEqual(getattr(lib, 'rtlsdr_set_'+name).argtypes[1], c.c_uint32)

    def test_failed_async_return_keeps_original_error_and_skips_unsafe_close(self):
        # Even a fully filled buffer must not become a completed output on error.
        lib = Library(read_code=-5, close_error=OSError('access violation writing 0x24'))
        with self.assertRaisesRegex(RuntimeError, '^RTL-SDR error -5$') as caught:
            self.run_capture(lib)
        self.assertIn('close skipped', '\n'.join(caught.exception.__notes__))
        self.assertEqual(lib.count('rtlsdr_read_async'), 1)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 0)
        self.cookie.close.assert_called_once_with()
        self.assert_no_output()

    def test_native_async_exception_keeps_identity_and_cancels_once(self):
        primary = OSError('native async exception')
        lib = Library(read_error=primary)
        with self.assertRaises(OSError) as caught:
            self.run_capture(lib)
        self.assertIs(caught.exception, primary)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 0)
        self.assert_no_output()

    def test_failed_cleanup_cancel_and_cookie_do_not_mask_primary(self):
        lib = Library(read_error=OSError('primary native read'), cancel_error=OSError('cancel failure'))
        self.cookie.close.side_effect = OSError('cookie failure')
        with self.assertRaisesRegex(OSError, '^primary native read$') as caught:
            self.run_capture(lib)
        notes = '\n'.join(caught.exception.__notes__)
        self.assertIn('cancel failure', notes)
        self.assertIn('cookie failure', notes)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 0)
        self.cookie.close.assert_called_once_with()
        self.assert_no_output()

    def test_cleanup_base_exceptions_cannot_replace_an_existing_primary(self):
        for action in ('cancel', 'cookie', 'close'):
            for exception_type in (KeyboardInterrupt, SystemExit):
                with self.subTest(action=action, exception_type=exception_type):
                    self.cookie.reset_mock(side_effect=True)
                    secondary = exception_type('secondary cleanup interruption')
                    if action == 'close':
                        # Clean native return followed by incomplete-read error still
                        # owns a safely closable device, unlike a failed native read.
                        lib = Library(short=True, close_error=secondary)
                        expected = 'Incomplete capture: 4/16 bytes'
                    else:
                        lib = Library(read_error=RuntimeError('primary read failure'),
                            cancel_error=secondary if action == 'cancel' else None)
                        expected = 'primary read failure'
                        if action == 'cookie':
                            self.cookie.close.side_effect = secondary
                    with self.assertRaisesRegex(RuntimeError, expected) as caught:
                        self.run_capture(lib)
                    self.assertIn(exception_type.__name__+': secondary cleanup interruption',
                        '\n'.join(caught.exception.__notes__))
                    self.assertEqual(lib.count('rtlsdr_close'), int(action == 'close'))
                    self.assertEqual(lib.count('rtlsdr_cancel_async'), int(action != 'close'))
                    self.cookie.close.assert_called_once_with()
                    self.assert_no_output()

    def test_cleanup_base_exception_without_primary_is_raised(self):
        for action in ('cancel', 'cookie', 'close'):
            for exception_type in (KeyboardInterrupt, SystemExit):
                with self.subTest(action=action, exception_type=exception_type):
                    self.cookie.reset_mock(side_effect=True)
                    for path in (self.output, self.output.with_suffix('.cu8.json')):
                        path.unlink(missing_ok=True)
                    error = exception_type('cleanup interruption without primary')
                    lib = Library(cancel_error=error if action == 'cancel' else None,
                        close_error=error if action == 'close' else None)
                    if action == 'cookie':
                        self.cookie.close.side_effect = error
                    with self.assertRaises(exception_type) as caught:
                        self.run_capture(lib)
                    self.assertIs(caught.exception, error)
                    self.assertEqual(lib.count('rtlsdr_close'), 1)
                    self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
                    self.cookie.close.assert_called_once_with()
                    if action == 'cancel':
                        self.assert_no_output()

    def test_callback_exception_surfaces_and_further_callbacks_are_ignored(self):
        lib = Library(callback_null=True)
        with self.assertRaisesRegex(ValueError, 'NULL pointer access'):
            self.run_capture(lib)
        self.assertEqual(lib.callback_count, 5)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 1)  # Native read returned cleanly.
        self.assert_no_output()

    def test_callback_exception_precedes_secondary_native_read_error(self):
        lib = Library(callback_null=True, read_code=-5)
        with self.assertRaisesRegex(ValueError, 'NULL pointer access') as caught:
            self.run_capture(lib)
        self.assertIn('async read also returned -5', '\n'.join(caught.exception.__notes__))
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 0)
        self.assert_no_output()

    def test_callback_keyboard_interrupt_is_not_discarded_by_ctypes(self):
        lib = Library()
        error = KeyboardInterrupt('interrupted inside callback')
        with mock.patch.object(capture.c, 'memmove', side_effect=error), \
             self.assertRaises(KeyboardInterrupt) as caught:
            self.run_capture(lib)
        self.assertIs(caught.exception, error)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 1)
        self.assert_no_output()

    def test_callback_cancel_error_is_reported_before_output_without_retry(self):
        lib = Library(cancel_code=-6)
        with self.assertRaisesRegex(RuntimeError, '^RTL-SDR error -6$'):
            self.run_capture(lib)
        self.assertEqual(lib.callback_count, 4)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 1)
        self.assertEqual(lib.count('rtlsdr_close'), 1)
        self.assert_no_output()

    def test_incomplete_clean_read_closes_and_never_writes_output(self):
        lib = Library(short=True)
        with self.assertRaisesRegex(RuntimeError, 'Incomplete capture: 4/16 bytes'):
            self.run_capture(lib)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 0)
        self.assertEqual(lib.count('rtlsdr_close'), 1)
        self.assert_no_output()

    def test_setup_failure_closes_once_and_retains_primary_despite_close_av(self):
        lib = Library(setup_code=-4, close_error=OSError('access violation writing 0x24'))
        with self.assertRaisesRegex(RuntimeError, '^RTL-SDR error -4$') as caught:
            self.run_capture(lib)
        self.assertIn('access violation', '\n'.join(caught.exception.__notes__))
        self.assertEqual(lib.count('rtlsdr_read_async'), 0)
        self.assertEqual(lib.count('rtlsdr_cancel_async'), 0)
        self.assertEqual(lib.count('rtlsdr_close'), 1)
        self.cookie.close.assert_called_once_with()
        self.assert_no_output()

    def test_open_or_library_failure_releases_search_cookie_without_closing_unowned_device(self):
        for failure in ('open', 'load'):
            with self.subTest(failure=failure):
                self.cookie.reset_mock()
                lib = Library(open_code=-1)
                error = OSError('DLL load failure') if failure == 'load' else None
                with self.assertRaises((RuntimeError, OSError)):
                    self.run_capture(lib, load_error=error)
                self.assertEqual(lib.count('rtlsdr_close'), 0)
                self.assertEqual(lib.count('rtlsdr_cancel_async'), 0)
                self.cookie.close.assert_called_once_with()
                self.assert_no_output()

    def test_close_failure_without_primary_is_not_suppressed(self):
        error = OSError('normal close failed')
        lib = Library(close_error=error)
        with self.assertRaises(OSError) as caught:
            self.run_capture(lib)
        self.assertIs(caught.exception, error)
        self.assertEqual(lib.count('rtlsdr_close'), 1)
        self.cookie.close.assert_called_once_with()


if __name__ == '__main__':
    unittest.main()
