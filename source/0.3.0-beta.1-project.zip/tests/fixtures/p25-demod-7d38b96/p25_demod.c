// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_demod.h"
#include <string.h>
#include "p25_demod_filter.h"
#include "p25_demod_math.h"
#include "p25_tsdu.h"
static const uint8_t sync_bytes[6]={0x55,0x75,0xf5,0xff,0x77,0xff};
void p25_demod_init(p25_demod *d) {
    memset(d,0,sizeof *d);
    d->selected_lane=UINT8_MAX;d->pending_lane=UINT8_MAX;
    for(unsigned i=0;i<10;++i) {d->lane[i].next_q16=(int32_t)(i+1)*65536;d->lane[i].period_q16=10*65536;}
}
void p25_demod_gap(p25_demod *d) {p25_demod_init(d);}
static void status_event(p25_demod *d,uint64_t tick,uint8_t status,bool qualified) {
    if(!d->status_emit)return;
    p25_demod_status event={.sample_tick=tick,.stream_epoch=d->stream_epoch,
        .lane_epoch=d->lane_epoch,.nac=d->selected_nac,.duid=7u,
        .status=status,.lane=d->selected_lane,.selected=d->selected_lane<10u,
        .qualified=qualified};
    d->status_emit(&event,d->status_context);
}
static void status_lost(p25_demod *d) {
    if(d->selected_lane<10u)status_event(d,d->decision_valid?d->decision_tick:d->input_tick,0,false);
    d->selected_lane=UINT8_MAX;d->selected_nac=0;d->selected_qualified=false;
    d->first_status_pending=false;
}
static void status_select(p25_demod *d) {
    if(!d->status_emit || !d->have_input_time || d->pending_errors ||
       d->pending.duid!=7u || d->pending_lane>=10u)return;
    if(d->selected_lane<10u && d->selected_nac==d->pending.nac)return;
    status_lost(d);
    // Epoch rollover is explicit loss, never reuse of an old lane identity.
    if(d->lane_epoch==UINT32_MAX)return;
    ++d->lane_epoch;d->selected_lane=d->pending_lane;d->selected_nac=d->pending.nac;
    status_event(d,d->decision_valid?d->decision_tick:d->input_tick,0,false);
}
static bool acquire(p25_demod_lane *l) {
    static const int8_t sign[24]={1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,-1,-1};
    int32_t sx=l->sum,sxy=0;
    const int16_t *history=&l->history[l->index];
    for(unsigned i=0;i<24;++i)sxy+=sign[i]*history[i];
    sxy*=3;
    const int32_t sy=-6,yy=5148;
    int64_t xx=24*(int64_t)l->sum_squares-(int64_t)sx*sx;
    int32_t xy=24*sxy-sx*sy;
    if(xx<24000 || !yy) return false;
    int64_t numerator=(int64_t)xy*xy;
    int64_t scaled=numerator*1000,denominator=xx*yy;
    // floor(scaled/denominator) >= 900 iff scaled >= 900*denominator.
    // Most timing hypotheses fail sync: avoid software 64-bit division there.
    // With 24 int16 samples divided by 16, these products fit int64_t.
    if(scaled<900*denominator) return false;
    unsigned quality=(unsigned)(scaled/denominator);
    int32_t gain=(int32_t)((int64_t)xy*16/yy);
    if(gain>-100 && gain<100) return false;
    l->gain=gain;l->offset=(sx*16-gain*sy)/24;l->quality=quality;
    l->previous_symbol=0;
    p25_rx_gap(&l->rx);
    for(unsigned i=0;i<24;++i)
        p25_rx_push(&l->rx,(sync_bytes[i/4]>>(6-2*(i%4)))&3);
    return true;
}
static void symbol(p25_demod *d,p25_demod_lane *l,int16_t value) {
    int32_t old=l->history[l->index], fresh=value/16;
    l->sum+=fresh-old;l->sum_squares+=fresh*fresh-old*old;
    l->history[l->index]=l->history[l->index+24]=(int16_t)fresh;if(++l->index==24)l->index=0;
    if(l->filled<24) ++l->filled;
    // Do not reinterpret voice data as a sync while a validated unit is in flight.
    if(!l->rx.symbols && l->filled==24) {
        uint32_t start=d->clock_us ? d->clock_us() : 0;
        ++d->sync_tests;bool found=acquire(l);
        if(d->clock_us)d->sync_us+=d->clock_us()-start;
        if(found) {
            if(d->selected_lane==(unsigned)(l-d->lane)) {
                d->selected_qualified=false;d->first_status_pending=false;
            }
            ++d->acquisitions;return;
        }
    }
    if(!l->rx.symbols || !l->gain) return;
    int32_t x=value-l->offset,g=l->gain;
    if(g<0) {x=-x;g=-g;}
    uint8_t b=x< -2*g ? 3 : x<0 ? 2 : x<2*g ? 0 : 1;
    int32_t decision=b==3 ? -3 : b==2 ? -1 : b==0 ? 1 : 3;
    if(l->previous_symbol) {
        // Mueller and Muller timing error, normalized by the sync-derived gain.
        // Q16 loop gains 1/32 (phase), 1/4096 (rate), rate bounded to +/-2000 ppm.
        int32_t delta=l->previous_symbol*x-decision*l->previous_value;
        int32_t error=p25_timing_error(delta,g);
        l->period_q16+=error/4096;
        if(l->period_q16>656671)l->period_q16=656671;
        if(l->period_q16<654049)l->period_q16=654049;
        l->next_q16+=error/32;
    }
    l->previous_value=x;l->previous_symbol=decision;
    unsigned position=l->rx.symbols;
    bool parser_fec=false;
    if(d->rare_fec_clock_us&&l->rx.duid==7u&&!l->rx.expected) {
        for(unsigned block=0;block<P25_TSDU_MAX_BLOCKS;++block)
            if(position+1u==p25_tsdu_block_end_symbols(block))parser_fec=true;
    }
    uint32_t parser_begin=parser_fec?d->rare_fec_clock_us():0u;
    bool complete=p25_rx_push(&l->rx,b);
    if(parser_fec) {
        uint32_t elapsed=d->rare_fec_clock_us()-parser_begin;
        ++d->parser_fec_calls;d->parser_fec_us+=elapsed;
        if(elapsed>d->parser_fec_max_us)d->parser_fec_max_us=elapsed;
    }
    if(d->status_emit && d->selected_lane==(unsigned)(l-d->lane)) {
        if(!d->decision_valid)status_lost(d);
        else if(position==35u) {
            d->first_status_tick=d->decision_tick;d->first_status=b;d->first_status_pending=true;
        } else if(position==56u) {
            if(!l->rx.symbols || l->rx.duid!=7u || l->rx.nac!=d->selected_nac)status_lost(d);
            else {
                d->selected_qualified=true;
                if(d->first_status_pending)status_event(d,d->first_status_tick,d->first_status,true);
                d->first_status_pending=false;
            }
        } else if(position>56u && position%36u==35u && d->selected_qualified)
            status_event(d,d->decision_tick,b,true);
        if(!complete && !l->rx.symbols)status_lost(d);
    }
    if(complete) {
        // Adjacent timing hypotheses complete the same unit within one symbol.
        // Prefer TSDU integrity or fewer voice FEC corrections, then the
        // strongest sync fit. Voice FEC cannot prove integrity beyond its
        // correction radius. Emit only one unit.
        // A zero-error winner cannot be beaten by a weaker sync fit.
        // Identical frame bytes also have identical FEC scores.
        if(d->pending_ticks && ((d->pending_errors==0 && l->quality<=d->pending_quality)
            || (l->rx.duid==d->pending.duid && !memcmp(l->rx.frame,d->pending.frame,sizeof l->rx.frame)))) {
            ++d->fec_skipped;
            if(l->quality>d->pending_quality) {d->pending=l->rx;d->pending_quality=l->quality;d->pending_lane=(uint8_t)(l-d->lane);}
            return;
        }
        uint32_t (*fec_clock)(void)=d->clock_us?d->clock_us:d->rare_fec_clock_us;
        uint32_t fec_start=fec_clock?fec_clock():0;
        ++d->fec_candidates;
        unsigned errors=0;
        if(l->rx.duid==5 || l->rx.duid==10) {
            for(unsigned i=0;i<9;++i) {
                uint8_t payload[11];unsigned corrected;
                if(p25_rx_voice(l->rx.frame,i,payload,&corrected))errors+=corrected;
                // Corrections cannot decrease as more codewords are scored.
                // Once this candidate exceeds the pending winner it cannot
                // win, even with a stronger sync fit. Equal scores must keep
                // running because the sync-quality tie-break still matters.
                if(d->pending_ticks && errors>d->pending_errors)break;
            }
        } else if(l->rx.duid==7) {
            // A good sync/NID does not establish that a control block is
            // intact. Giving an invalid TSDU a zero score lets its stronger
            // sync suppress a CRC-valid adjacent timing lane in the fast
            // path above. Only a complete, CRC-valid envelope scores zero.
            p25_tsdu control;
            errors=p25_tsdu_decode(l->rx.frame,l->rx.frame_bytes,&control)?0u:1u;
        }
        if(fec_clock)d->fec_us+=fec_clock()-fec_start;
        if(!d->pending_ticks) {d->pending_ticks=11;d->pending_errors=~0u;}
        if(errors<d->pending_errors || (errors==d->pending_errors && l->quality>d->pending_quality)) {
            d->pending=l->rx;d->pending_quality=l->quality;d->pending_errors=errors;
            d->pending_lane=(uint8_t)(l-d->lane);
        }
    }
}
static void hunting_history(p25_demod *d,int16_t value) {
    d->hunt_history[d->hunt_index]=value/16;
    if(++d->hunt_index==240)d->hunt_index=0;
    if(d->hunt_filled<240)++d->hunt_filled;
}
static void hunting_rearm(p25_demod *d) {
    // Independent learned clocks can converge during a call and then leave
    // no useful sampling-phase diversity for the next transmitter. Rearm
    // every 600 ms without an emitted unit, including long malformed hunts.
    // False sync/NID attempts must not refresh this deadline.
    if(d->idle_ticks<28800u)++d->idle_ticks;
    if(d->idle_ticks<28800u || d->hunt_filled<240 || d->pending_ticks)return;
    for(unsigned i=0;i<10;++i)if(d->lane[i].rx.symbols)return;
    status_lost(d);
    uint32_t (*hunt_clock)(void)=d->hunt_clock_us ? d->hunt_clock_us : d->clock_us;
    uint32_t started=hunt_clock ? hunt_clock() : 0;
    unsigned phase=(unsigned)(d->ticks%10);
    for(unsigned i=0;i<10;++i) {
        p25_demod_lane *l=&d->lane[i];
        unsigned age=(phase+10-((i+1)%10))%10;
        unsigned oldest=d->hunt_index+9-age;
        l->sum=l->sum_squares=0;
        for(unsigned j=0;j<24;++j) {
            unsigned pos=oldest+10*j;if(pos>=240)pos-=240;
            int32_t sample=d->hunt_history[pos];
            l->history[j]=l->history[j+24]=(int16_t)sample;
            l->sum+=sample;l->sum_squares+=sample*sample;
        }
        l->index=0;l->filled=24;l->quality=0;l->offset=l->gain=0;
        l->previous_value=l->previous_symbol=0;
        l->period_q16=10*65536;
        l->next_q16=(int32_t)(10-age)*65536;
        p25_rx_gap(&l->rx); // Keep per-lane telemetry counters monotonic.
        // The last sample for this nominal phase is zero..nine ticks old.
        // Rebuild rather than erase a partial sync; also recognize a sync
        // already complete at that sample, without skipping its next dibit.
        uint32_t start=d->clock_us ? d->clock_us() : 0;
        ++d->sync_tests;bool found=acquire(l);
        if(d->clock_us)d->sync_us+=d->clock_us()-start;
        if(found)++d->acquisitions;
    }
    d->idle_ticks=0;++d->hunt_rearms;
    if(hunt_clock) {
        uint32_t elapsed=hunt_clock()-started;
        d->hunt_us+=elapsed;
        if(elapsed>d->hunt_max_us)d->hunt_max_us=elapsed;
    }
}
static void interpolated(p25_demod *d,int16_t value,uint64_t sample_tick,p25_demod_frame_fn emit,void *context) {
    if(d->pending_ticks && !--d->pending_ticks) {
        status_select(d);
        ++d->frames;emit(&d->pending,context);d->pending_quality=0;d->idle_ticks=0;
    }
    ++d->ticks;hunting_history(d,value);
    for(unsigned i=0;i<10;++i) {
        p25_demod_lane *l=&d->lane[i];
        l->next_q16-=65536;
        if(l->next_q16<=0) {
            uint32_t back=(uint32_t)(-l->next_q16);
            int32_t x=p25_interpolate(d->previous,value,back);
            if(d->have_input_time) {
                // FIR output time minus its exact group delay. Decisions occur
                // near symbol centers; add half the learned symbol period to
                // report its END. Round the fractional phase once, <=0.5 tick.
                uint32_t half=(uint32_t)l->period_q16/2u;
                uint32_t offset=(half-back+32768u)/65536u;
                d->decision_valid=sample_tick>=P25_DEMOD_FIR_DELAY_TICKS;
                if(d->decision_valid)d->decision_tick=sample_tick-P25_DEMOD_FIR_DELAY_TICKS+offset;
            } else d->decision_valid=false;
            l->next_q16+=l->period_q16;
            uint32_t start=d->clock_us ? d->clock_us() : 0;
            symbol(d,l,(int16_t)x);
            if(d->clock_us)d->symbol_us+=d->clock_us()-start;
        }
    }
    // Run after this tick's data decisions: newly reconstructed lanes are
    // scheduled relative to now and must not consume the current tick twice.
    hunting_rearm(d);d->previous=value;
}
static void push(p25_demod *d,int16_t sample,p25_demod_frame_fn emit,void *context) {
    uint32_t start=d->clock_us ? d->clock_us() : 0;
    d->fir[d->fir_index]=d->fir[d->fir_index+21]=sample;
    int16_t values[6];
    p25_interp_sample(&d->fir[d->fir_index+21],values);
    if(++d->fir_index==21)d->fir_index=0;
    if(d->clock_us)d->fir_us+=d->clock_us()-start;
    for(unsigned p=0;p<6;++p)interpolated(d,values[p],d->have_input_time?d->input_tick+p:0,emit,context);
}
void p25_demod_push(p25_demod *d,int16_t sample,p25_demod_frame_fn emit,void *context) {
    // Mixing conventional and timestamped input cannot preserve a timing lease.
    if(d->have_input_time)status_lost(d);
    d->have_input_time=false;d->status_emit=NULL;d->status_context=NULL;
    push(d,sample,emit,context);
}
bool p25_demod_push_at(p25_demod *d,int16_t sample,uint64_t sample_tick,
                       uint32_t stream_epoch,p25_demod_frame_fn emit,
                       p25_demod_status_fn status_emit,void *context) {
    if(!d || !emit)return false;
    d->status_emit=status_emit;d->status_context=context;
    if(sample_tick>UINT64_MAX-6u) {status_lost(d);p25_demod_gap(d);return false;}
    bool continuous=!d->have_input_time || (d->stream_epoch==stream_epoch &&
        d->input_tick<=UINT64_MAX-P25_DEMOD_INPUT_STEP_TICKS &&
        sample_tick==d->input_tick+P25_DEMOD_INPUT_STEP_TICKS);
    if(!continuous) {
        uint32_t previous_epoch=d->lane_epoch;
        uint32_t (*profile_clock)(void)=d->clock_us;
        uint32_t (*hunt_clock)(void)=d->hunt_clock_us;
        uint32_t (*rare_clock)(void)=d->rare_fec_clock_us;
        status_lost(d);p25_demod_gap(d);d->lane_epoch=previous_epoch;
        d->clock_us=profile_clock;d->hunt_clock_us=hunt_clock;
        d->rare_fec_clock_us=rare_clock;
        d->status_emit=status_emit;d->status_context=context;
    }
    d->input_tick=sample_tick;d->stream_epoch=stream_epoch;d->have_input_time=true;
    push(d,sample,emit,context);return continuous;
}
