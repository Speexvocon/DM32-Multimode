// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_access.h"
#include "p25_tsdu.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static const p25_trunking_access_config configuration={
    .wacn=0xabcde,.radio_id=1234567,.min_hz=400000000,.max_hz=480000000,
    .tot_ms=30000,.system=0x123,.nac=0x293,.group=10,.rfss=1,.site=1};
static const p25_trunking_access_site configured_site={
    .wacn=0xabcde,.control_rx_hz=440075000,.control_tx_hz=445075000,
    .system=0x123,.nac=0x293,.rfss=1,.site=1,.fdma=true,.control_pair_valid=true};
static const p25_trunking_access_pair voice_pair={440087500,445087500,true};
static unsigned assertions;
#define CHECK(condition) do {++assertions;assert(condition);} while(0)

static void initialize(p25_trunking_access *a,uint32_t now) {
    p25_trunking_access_init(a);CHECK(p25_trunking_access_start(a,&configuration,now));
    CHECK(a->phase==P25_TRUNK_ACCESS_WAIT_SITE);
}
static void tick(p25_trunking_access *a,uint32_t now,bool down) {
    p25_trunking_access_poll(a,now,down,true,true);
}
static void refresh(p25_trunking_access *a,uint32_t now) {
    CHECK(p25_trunking_access_site_update(a,&configured_site,now));
}
static p25_trunking_access_action take(p25_trunking_access *a,
                                     p25_trunking_access_action_type type,uint32_t now) {
    p25_trunking_access_action action;
    CHECK(p25_trunking_access_take(a,&action,now));CHECK(action.type==type);
    CHECK(action.radio_id==configuration.radio_id && action.group==configuration.group);
    CHECK(action.nac==a->config.nac && action.tot_ms==a->config.tot_ms);
    if(type!=P25_TRUNK_ACTION_VOICE_START)CHECK(!action.channel && !action.options);
    return action;
}
static void done(p25_trunking_access *a,p25_trunking_access_action action,uint32_t now) {
    CHECK(p25_trunking_access_result(a,action.id,true,now));
    CHECK(!p25_trunking_access_result(a,action.id,true,now));
}
static bool event(p25_trunking_access *a,p25_trunking_osp value,uint32_t now) {
    return p25_trunking_access_consume(a,&value,configuration.nac,
        configured_site.control_rx_hz,&voice_pair,now);
}
static p25_trunking_osp registration(void) {
    p25_trunking_osp value={.type=P25_TRUNK_OSP_REGISTRATION,.opcode=0x2c,
        .system=0x123,.target=1234567,.assigned=1234567};return value;
}
static p25_trunking_osp affiliation(void) {
    p25_trunking_osp value={.type=P25_TRUNK_OSP_AFFILIATION,.opcode=0x28,
        .group=10,.target=1234567,.global=true};return value;
}
static p25_trunking_osp grant(void) {
    p25_trunking_osp value={.type=P25_TRUNK_OSP_GROUP_GRANT,.opcode=0,
        .channel=0x1001,.group=10,.source=1234567};return value;
}
static void ready(p25_trunking_access *a,uint32_t now) {
    initialize(a,now);refresh(a,now);tick(a,now,false);
    done(a,take(a,P25_TRUNK_ACTION_REGISTER,now),now+1);
    CHECK(a->phase==P25_TRUNK_ACCESS_WAIT_REG);
    CHECK(event(a,registration(),now+2));CHECK(a->registered && !a->affiliated);
    tick(a,now+3,false);done(a,take(a,P25_TRUNK_ACTION_AFFILIATE,now+3),now+4);
    CHECK(event(a,affiliation(),now+5));CHECK(a->phase==P25_TRUNK_ACCESS_READY);
    CHECK(a->registered && a->affiliated && !a->release_required);
}
static void requested(p25_trunking_access *a,uint32_t now) {
    ready(a,now);tick(a,now+6,true);
    done(a,take(a,P25_TRUNK_ACTION_GROUP_REQUEST,now+6),now+7);
    CHECK(a->phase==P25_TRUNK_ACCESS_WAIT_GRANT && a->want_voice);
}
static void granted(p25_trunking_access *a,uint32_t now) {
    requested(a,now);CHECK(event(a,grant(),now+8));
    CHECK(a->phase==P25_TRUNK_ACCESS_GRANTED && !a->voice_running);
    CHECK(a->voice_channel==0x1001u && !a->voice_options);
}
static p25_trunking_access_action started(p25_trunking_access *a,uint32_t now) {
    granted(a,now);tick(a,now+9,true);
    p25_trunking_access_action action=take(a,P25_TRUNK_ACTION_VOICE_START,now+9);
    CHECK(action.rx_hz==440087500 && action.tx_hz==445087500);
    done(a,action,now+10);CHECK(a->voice_running);return action;
}
static void no_action(p25_trunking_access *a,uint32_t now) {
    p25_trunking_access_action action;memset(&action,0xa5,sizeof action);
    p25_trunking_access_action before=action;
    CHECK(!p25_trunking_access_take(a,&action,now));CHECK(!memcmp(&action,&before,sizeof action));
}
static void test_validation_and_idle(void) {
    p25_trunking_access a,before;initialize(&a,0);CHECK(sizeof a<=192u);
    no_action(&a,0);refresh(&a,1);no_action(&a,1);
    p25_trunking_access_poll(&a,2,false,true,false);no_action(&a,2);
    tick(&a,3,false);no_action(&a,4); // Old idle is not a retained access token.
    p25_trunking_access_action action=take(&a,P25_TRUNK_ACTION_REGISTER,3);
    CHECK(action.tx_hz==445075000 && action.rx_hz==440075000);
    no_action(&a,3);CHECK(!p25_trunking_access_result(&a,action.id+1,true,4));
    done(&a,action,4);
    p25_trunking_osp response=registration();response.target++;
    CHECK(!event(&a,response,5));CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_REG);
    response=registration();response.system++;CHECK(!event(&a,response,5));
    response=registration();response.assigned++;
    CHECK(event(&a,response,5));CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);
    CHECK(!a.registered && !a.affiliated);no_action(&a,5);
    for(unsigned i=0;i<8;++i) {
        p25_trunking_access_stop(&a);before=a;
        p25_trunking_access_config config=configuration;
        if(i==0)config.radio_id=0;
        if(i==1)config.radio_id=0xffffff;
        if(i==2)config.wacn=0;
        if(i==3)config.system=0;
        if(i==4)config.nac=0x1000;
        if(i==5)config.tot_ms=999;
        if(i==6)config.tot_ms=P25_TRUNK_ACCESS_MAX_TOT_MS+1;
        if(i==7)config.min_hz=config.max_hz+1;
        CHECK(!p25_trunking_access_start(&a,&config,0));CHECK(!memcmp(&a,&before,sizeof a));
    }
    ready(&a,100);before=a;
    CHECK(!p25_trunking_access_start(&a,&configuration,110));CHECK(!memcmp(&a,&before,sizeof a));
}
static void test_site_identity(void) {
    for(unsigned i=0;i<10;++i) {
        p25_trunking_access a;initialize(&a,0);
        p25_trunking_access_site site=configured_site;
        if(i==0)site.wacn++;
        if(i==1)site.system++;
        if(i==2)site.nac++;
        if(i==3)site.rfss++;
        if(i==4)site.site++;
        if(i==5)site.fdma=false;
        if(i==6)site.control_pair_valid=false;
        if(i==7)site.control_tx_hz=0;
        if(i==8)site.control_rx_hz=300000000;
        if(i==9)site.control_tx_hz=500000000;
        CHECK(!p25_trunking_access_site_update(&a,&site,1));
        CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);no_action(&a,1);
    }
    p25_trunking_access a;ready(&a,100);tick(&a,3100,false);
    CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_SITE && !a.registered && !a.affiliated);
    no_action(&a,3100);refresh(&a,3101);tick(&a,3101,false);
    take(&a,P25_TRUNK_ACTION_REGISTER,3101);
    p25_trunking_access_site moved=configured_site;moved.control_tx_hz+=12500;
    CHECK(!p25_trunking_access_site_update(&a,&moved,3102));
    CHECK(a.phase==P25_TRUNK_ACCESS_FAILED && !a.outstanding);
}
static void test_fresh_ptt_and_own_grant(void) {
    p25_trunking_access a;initialize(&a,0);refresh(&a,0);tick(&a,0,true);
    CHECK(a.release_required); // Held through start never becomes a speech request.
    done(&a,take(&a,P25_TRUNK_ACTION_REGISTER,0),1);CHECK(event(&a,registration(),2));
    tick(&a,3,true);done(&a,take(&a,P25_TRUNK_ACTION_AFFILIATE,3),4);
    CHECK(event(&a,affiliation(),5));tick(&a,6,true);no_action(&a,6);
    tick(&a,7,false);tick(&a,8,true);take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,8);
    for(unsigned i=0;i<7;++i) {
        requested(&a,100);
        p25_trunking_osp wrong=grant();
        if(i==0)wrong.source++;
        if(i==1)wrong.group++;
        if(i==2)wrong.opcode=2;
        if(i==3)wrong.source=0;
        if(i==4)wrong.type=P25_TRUNK_OSP_ACK;
        bool accepted;
        if(i==5)accepted=p25_trunking_access_consume(&a,&wrong,0x294,440075000,&voice_pair,108);
        else if(i==6)accepted=p25_trunking_access_consume(&a,&wrong,0x293,440087500,&voice_pair,108);
        else accepted=event(&a,wrong,108);
        CHECK(!accepted);CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_GRANT);no_action(&a,108);
    }
    requested(&a,200);tick(&a,208,false);CHECK(a.phase==P25_TRUNK_ACCESS_READY);
    CHECK(!event(&a,grant(),209));no_action(&a,209);
    requested(&a,300);CHECK(!event(&a,grant(),307+P25_TRUNK_ACCESS_RESPONSE_MS));
    CHECK(a.phase==P25_TRUNK_ACCESS_REQUEST); // Missing poll cannot accept a late grant.
    granted(&a,400);tick(&a,409,false);CHECK(a.phase==P25_TRUNK_ACCESS_READY);
    no_action(&a,409); // Release between grant and take never starts RF.
}
static void test_grant_refusal(void) {
    for(unsigned i=0;i<9;++i) {
        p25_trunking_access a;requested(&a,0);p25_trunking_osp value=grant();
        p25_trunking_access_pair pair=voice_pair;
        if(i==0)value.encrypted=true;
        if(i==1)value.options=0x40;
        if(i==2)value.options=8;
        if(i==3)value.options=0x10;
        if(i==4)pair.valid=false;
        if(i==5)pair.tx_hz=0;
        if(i==6)pair.rx_hz=500000000;
        if(i==7)pair.rx_hz=configured_site.control_rx_hz;
        CHECK(p25_trunking_access_consume(&a,&value,0x293,440075000,i==8 ? NULL : &pair,8));
        CHECK(a.phase==P25_TRUNK_ACCESS_FAILED && !a.voice_running);no_action(&a,8);
    }
    p25_trunking_access a;granted(&a,0);tick(&a,8+P25_TRUNK_ACCESS_GRANT_MS,true);
    CHECK(a.phase==P25_TRUNK_ACCESS_FAILED && !a.voice_running);
}
static void test_deny_queue_and_retry(void) {
    p25_trunking_access a;requested(&a,0);
    p25_trunking_osp value={.type=P25_TRUNK_OSP_DENIED,.target=3166362,.service=0};
    CHECK(!event(&a,value,8));value.target=1234567;value.service=0x28;
    CHECK(!event(&a,value,8));value.service=0;value.additional=true;value.group=11;
    CHECK(!event(&a,value,8));value.group=10;
    CHECK(event(&a,value,8));CHECK(a.phase==P25_TRUNK_ACCESS_READY && a.release_required);
    tick(&a,9,true);no_action(&a,9);tick(&a,10,false);tick(&a,11,true);
    take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,11);

    requested(&a,100);
    value=(p25_trunking_osp){.type=P25_TRUNK_OSP_QUEUED,.target=1234567,.service=0};
    CHECK(event(&a,value,108));CHECK(a.queued);
    refresh(&a,2100);tick(&a,2100,true);CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_GRANT);
    CHECK(event(&a,value,2200));refresh(&a,4200);CHECK(event(&a,value,4500));
    CHECK(!event(&a,grant(),5107)); // Queues do not extend their absolute bound.
    CHECK(a.phase==P25_TRUNK_ACCESS_REQUEST);tick(&a,5107,true);no_action(&a,5107);
    tick(&a,5357,true);done(&a,take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,5357),5358);
    CHECK(a.attempts==2);
    refresh(&a,6858);tick(&a,6858,true);CHECK(a.phase==P25_TRUNK_ACCESS_REQUEST);
    tick(&a,7108,true);done(&a,take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,7108),7109);
    CHECK(a.attempts==P25_TRUNK_ACCESS_ATTEMPTS);
    refresh(&a,8609);tick(&a,8609,true);CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);
    CHECK(a.reason==P25_TRUNK_ACCESS_TIMEOUT);no_action(&a,8609);

    for(unsigned stage=0;stage<2;++stage) {
        initialize(&a,0);refresh(&a,0);tick(&a,0,false);
        done(&a,take(&a,P25_TRUNK_ACTION_REGISTER,0),1);
        if(stage) {CHECK(event(&a,registration(),2));tick(&a,3,false);
            done(&a,take(&a,P25_TRUNK_ACTION_AFFILIATE,3),4);}
        value=(p25_trunking_osp){.type=P25_TRUNK_OSP_DENIED,.target=1234567,.service=stage ? 0x28 : 0x2c};
        CHECK(event(&a,value,5));CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);
    }
}
static void test_lifecycle_and_faults(void) {
    p25_trunking_access a;started(&a,100);
    // The radio cannot refresh control while keyed. Site age alone must not
    // interrupt an otherwise authorized call before the configured TOT.
    tick(&a,10100,true);CHECK(a.voice_running && a.phase==P25_TRUNK_ACCESS_GRANTED);
    tick(&a,30110,true);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.release_required);
    CHECK(a.reason==P25_TRUNK_ACCESS_TOT);
    p25_trunking_access_action stop=take(&a,P25_TRUNK_ACTION_VOICE_STOP,30110);
    no_action(&a,30110);done(&a,stop,30111);CHECK(!a.voice_running);
    p25_trunking_access_action back=take(&a,P25_TRUNK_ACTION_RETURN_CONTROL,30112);
    CHECK(back.rx_hz==440075000);done(&a,back,30113);CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_SITE);
    no_action(&a,30113);refresh(&a,30114);tick(&a,30114,true);no_action(&a,30114);
    CHECK(a.phase==P25_TRUNK_ACCESS_READY && a.release_required);
    tick(&a,30115,false);tick(&a,30116,true);take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,30116);

    started(&a,0);tick(&a,11,false);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN);
    stop=take(&a,P25_TRUNK_ACTION_VOICE_STOP,11);
    CHECK(p25_trunking_access_result(&a,stop.id,false,12));
    tick(&a,3000,false);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);
    no_action(&a,3000); // Never retune before an actual hardware-stop acknowledgment.
    done(&a,stop,3001);back=take(&a,P25_TRUNK_ACTION_RETURN_CONTROL,3002);
    done(&a,back,3003);CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);

    granted(&a,0);tick(&a,9,true);
    p25_trunking_access_action voice=take(&a,P25_TRUNK_ACTION_VOICE_START,9);
    tick(&a,10,false);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN);
    CHECK(!p25_trunking_access_result(&a,voice.id,true,10));
    take(&a,P25_TRUNK_ACTION_VOICE_STOP,10); // Start raced release: always explicit stop.

    granted(&a,0);tick(&a,9,true);voice=take(&a,P25_TRUNK_ACTION_VOICE_START,9);
    CHECK(p25_trunking_access_result(&a,voice.id,false,10));
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN);take(&a,P25_TRUNK_ACTION_VOICE_STOP,10);

    started(&a,0);p25_trunking_access_poll(&a,11,true,false,true);
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.reason==P25_TRUNK_ACCESS_PERMISSION);
    take(&a,P25_TRUNK_ACTION_VOICE_STOP,11);
    ready(&a,0);p25_trunking_osp auth={.type=P25_TRUNK_OSP_UNSUPPORTED,.opcode=0x31};
    CHECK(event(&a,auth,6));CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);
    initialize(&a,0);refresh(&a,0);tick(&a,0,false);
    p25_trunking_access_action packet=take(&a,P25_TRUNK_ACTION_REGISTER,0);
    refresh(&a,P25_TRUNK_ACCESS_ACTION_MS);tick(&a,P25_TRUNK_ACCESS_ACTION_MS,false);
    CHECK(a.phase==P25_TRUNK_ACCESS_FAILED);
    CHECK(!p25_trunking_access_result(&a,packet.id,true,2001));
    uint32_t old_id=packet.id;p25_trunking_access_stop(&a);
    CHECK(p25_trunking_access_start(&a,&configuration,2002));refresh(&a,2002);tick(&a,2002,false);
    packet=take(&a,P25_TRUNK_ACTION_REGISTER,2002);CHECK(packet.id!=old_id);
    CHECK(!p25_trunking_access_result(&a,old_id,true,2003));
}
static void test_wraparound(void) {
    p25_trunking_access a;uint32_t now=UINT32_MAX-100u;
    started(&a,now);tick(&a,now+20u,false);
    p25_trunking_access_action action=take(&a,P25_TRUNK_ACTION_VOICE_STOP,now+20u);
    done(&a,action,now+21u);action=take(&a,P25_TRUNK_ACTION_RETURN_CONTROL,now+22u);
    done(&a,action,now+23u);CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_SITE);
    requested(&a,now);refresh(&a,1400u);tick(&a,1406u,true);
    CHECK(a.phase==P25_TRUNK_ACCESS_REQUEST);tick(&a,1656u,true);
    take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,1656u);
}
static void test_action_lease_edges(void) {
    p25_trunking_access a;initialize(&a,0);refresh(&a,0);tick(&a,0,false);
    p25_trunking_access_action action=take(&a,P25_TRUNK_ACTION_REGISTER,0);
    done(&a,action,1);tick(&a,2,false);CHECK(event(&a,registration(),2));
    no_action(&a,2); // Even a response in the same ms invalidates old idle.
    tick(&a,2,false);take(&a,P25_TRUNK_ACTION_AFFILIATE,2);

    ready(&a,0);tick(&a,6,false);refresh(&a,6);no_action(&a,6);
    requested(&a,0);refresh(&a,2900);CHECK(event(&a,grant(),2901)==false);
    // The preceding response deadline expired. Set up a fresh request close
    // to the control freshness boundary, without refreshing after its grant.
    ready(&a,0);tick(&a,2980,true);
    action=take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,2980);done(&a,action,2981);
    CHECK(event(&a,grant(),2982));tick(&a,2990,true);
    action=take(&a,P25_TRUNK_ACTION_VOICE_START,2990);
    tick(&a,3001,true);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);
    CHECK(!p25_trunking_access_result(&a,action.id,true,3002));
    take(&a,P25_TRUNK_ACTION_VOICE_STOP,3002);

    ready(&a,0);tick(&a,2980,true);
    action=take(&a,P25_TRUNK_ACTION_GROUP_REQUEST,2980);done(&a,action,2981);
    CHECK(event(&a,grant(),2982));tick(&a,2990,true);
    action=take(&a,P25_TRUNK_ACTION_VOICE_START,2990);
    CHECK(!p25_trunking_access_result(&a,action.id,true,3001)); // No intervening poll.
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);

    granted(&a,0);tick(&a,9,true);action=take(&a,P25_TRUNK_ACTION_VOICE_START,9);
    tick(&a,10,false);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);
    p25_trunking_access_site foreign=configured_site;foreign.site++;
    CHECK(!p25_trunking_access_site_update(&a,&foreign,11));
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);
    take(&a,P25_TRUNK_ACTION_VOICE_STOP,11);

    // TOT starts when the START permission leaves policy, not a delayed ack.
    granted(&a,0);a.config.tot_ms=1000;tick(&a,9,true);
    action=take(&a,P25_TRUNK_ACTION_VOICE_START,9);tick(&a,1009,true);
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.reason==P25_TRUNK_ACCESS_TOT);
    CHECK(!p25_trunking_access_result(&a,action.id,true,1509));
    take(&a,P25_TRUNK_ACTION_VOICE_STOP,1509);
    granted(&a,0);a.config.tot_ms=1000;tick(&a,9,true);
    action=take(&a,P25_TRUNK_ACTION_VOICE_START,9);
    CHECK(!p25_trunking_access_result(&a,action.id,true,1009));
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.reason==P25_TRUNK_ACCESS_TOT);
    granted(&a,0);a.config.tot_ms=1000;tick(&a,9,true);
    action=take(&a,P25_TRUNK_ACTION_VOICE_START,9);done(&a,action,509);
    CHECK(a.voice_ms==9);tick(&a,1009,true);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN);

    initialize(&a,0);refresh(&a,0);tick(&a,0,false);
    action=take(&a,P25_TRUNK_ACTION_REGISTER,0);
    CHECK(!p25_trunking_access_result(&a,action.id,true,P25_TRUNK_ACCESS_ACTION_MS));
    CHECK(a.phase==P25_TRUNK_ACCESS_FAILED && !a.registered);
    granted(&a,0);tick(&a,9,true);action=take(&a,P25_TRUNK_ACTION_VOICE_START,9);
    refresh(&a,2000);
    CHECK(!p25_trunking_access_result(&a,action.id,true,2009));
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);

    uint32_t now=UINT32_MAX-100u;granted(&a,now);a.config.tot_ms=1000;
    tick(&a,now+9u,true);action=take(&a,P25_TRUNK_ACTION_VOICE_START,now+9u);
    CHECK(!p25_trunking_access_result(&a,action.id,true,now+1009u));
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.reason==P25_TRUNK_ACCESS_TOT);
}
static void metadata_granted(p25_trunking_access *a,uint32_t now) {
    requested(a,now);p25_trunking_osp value=grant();
    value.channel=0xa321u;value.options=0x85u;CHECK(event(a,value,now+8u));
    CHECK(a->phase==P25_TRUNK_ACCESS_GRANTED && a->voice_channel==0xa321u && a->voice_options==0x85u);
}
static void no_grant_metadata(const p25_trunking_access *a) {
    CHECK(!a->voice_channel && !a->voice_options);
}
static void test_grant_metadata(void) {
    // Every supported clear emergency/priority combination survives the lease.
    // Later source-addressed grants cannot replace either metadata field.
    for(unsigned i=0;i<16u;++i) {
        p25_trunking_access a;requested(&a,0);p25_trunking_osp value=grant();
        uint16_t channel=(uint16_t)(0xa321u+i);
        uint8_t options=(uint8_t)((i&7u)|((i&8u) ? 0x80u:0u));
        value.channel=channel;value.options=options;CHECK(event(&a,value,8));
        value.channel++;value.options^=1u;CHECK(!event(&a,value,9));
        CHECK(a.voice_channel==channel && a.voice_options==options);
        tick(&a,10,true);p25_trunking_access_action action=take(&a,P25_TRUNK_ACTION_VOICE_START,10);
        CHECK(action.channel==channel && action.options==options);
        CHECK(!event(&a,value,11));CHECK(a.voice_channel==channel && a.voice_options==options);
        done(&a,action,12);CHECK(a.voice_running);
        CHECK(!event(&a,value,13));CHECK(a.voice_channel==channel && a.voice_options==options);
        tick(&a,14,false);CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN);no_grant_metadata(&a);
        // Revocation must still leave the exact pair available to safety STOP.
        p25_trunking_access_action stop=take(&a,P25_TRUNK_ACTION_VOICE_STOP,14);
        CHECK(stop.rx_hz==voice_pair.rx_hz && stop.tx_hz==voice_pair.tx_hz);
        done(&a,stop,15);no_grant_metadata(&a);
        p25_trunking_access_action back=take(&a,P25_TRUNK_ACTION_RETURN_CONTROL,16);
        done(&a,back,17);no_grant_metadata(&a);
        CHECK(!a.voice.valid && !a.voice.rx_hz && !a.voice.tx_hz);
        CHECK(action.channel==channel && action.options==options); // Issued copy is immutable.
    }
    for(unsigned i=0;i<8u;++i) {
        p25_trunking_access a;metadata_granted(&a,0);
        if(i==0)tick(&a,9,false); // Release before taking the grant.
        if(i==1)tick(&a,8u+P25_TRUNK_ACCESS_GRANT_MS,true);
        if(i==2)tick(&a,P25_TRUNK_ACCESS_SITE_MS,true);
        if(i==3) {
            p25_trunking_access_site moved=configured_site;moved.site++;
            CHECK(!p25_trunking_access_site_update(&a,&moved,9));
        }
        if(i==4) {
            p25_trunking_access_site unusable=configured_site;unusable.control_pair_valid=false;
            CHECK(!p25_trunking_access_site_update(&a,&unusable,9));
        }
        if(i==5)p25_trunking_access_poll(&a,9,true,false,true);
        if(i==6)p25_trunking_access_fault(&a,P25_TRUNK_ACCESS_TRANSPORT,9);
        if(i==7)p25_trunking_access_stop(&a);
        no_grant_metadata(&a);CHECK(a.phase!=P25_TRUNK_ACCESS_GRANTED);no_action(&a,10);
        p25_trunking_osp late=grant();late.channel=0xa321u;late.options=0x85u;
        CHECK(!event(&a,late,11));no_grant_metadata(&a);
    }
    // A possibly keyed start loses its metadata on fault, but its pair and
    // explicit stop obligation survive. An old completion cannot restore it.
    p25_trunking_access a;metadata_granted(&a,0);tick(&a,9,true);
    p25_trunking_access_action start=take(&a,P25_TRUNK_ACTION_VOICE_START,9);
    p25_trunking_access_fault(&a,P25_TRUNK_ACCESS_MAPPING,10);
    CHECK(a.phase==P25_TRUNK_ACCESS_DRAIN && a.voice_running);no_grant_metadata(&a);
    CHECK(!p25_trunking_access_result(&a,start.id,true,11));no_grant_metadata(&a);
    p25_trunking_access_action stop=take(&a,P25_TRUNK_ACTION_VOICE_STOP,11);
    CHECK(stop.tx_hz==voice_pair.tx_hz);done(&a,stop,12);
    p25_trunking_access_stop(&a);no_grant_metadata(&a);
    CHECK(p25_trunking_access_start(&a,&configuration,13));refresh(&a,13);tick(&a,13,false);
    CHECK(!event(&a,grant(),14));no_grant_metadata(&a);
    CHECK(!p25_trunking_access_result(&a,start.id,true,14));
    CHECK(start.channel==0xa321u && start.options==0x85u);
}
static void test_group_selection(void) {
    for(unsigned wrap=0;wrap<2u;++wrap) {
        uint32_t origin=wrap ? UINT32_MAX-12u:100u;
        p25_trunking_access a,before;ready(&a,origin);tick(&a,origin+6u,false);
        before=a;CHECK(p25_trunking_access_select_group(&a,10u,origin+6u));
        CHECK(!memcmp(&a,&before,sizeof a)); // Reselecting is a true no-op.
        uint32_t previous=a.serial;p25_trunking_access_site binding=a.site;
        CHECK(p25_trunking_access_select_group(&a,1000u,origin+6u));
        CHECK(a.phase==P25_TRUNK_ACCESS_AFFILIATE && a.registered && !a.affiliated);
        CHECK(a.config.group==1000u && a.serial==previous && a.release_required);
        CHECK(!memcmp(&a.site,&binding,sizeof binding) && a.have_site);
        CHECK(!a.action_eligible && !a.idle && !a.voice.valid && !a.voice_channel && !a.voice_options);
        no_action(&a,origin+6u);
        CHECK(!p25_trunking_access_result(&a,previous,true,origin+7u));
        CHECK(!event(&a,affiliation(),origin+7u)); // Old affiliation never authorizes the new group.
        // Holding PTT through re-affiliation may not become a later GROUP call.
        tick(&a,origin+7u,true);p25_trunking_access_action action;
        CHECK(p25_trunking_access_take(&a,&action,origin+7u));
        CHECK(action.type==P25_TRUNK_ACTION_AFFILIATE && action.group==1000u && action.id!=previous);
        done(&a,action,origin+8u);CHECK(!event(&a,affiliation(),origin+9u));
        CHECK(a.phase==P25_TRUNK_ACCESS_WAIT_AFF && !a.affiliated && a.registered);
        p25_trunking_osp fresh_aff=affiliation();fresh_aff.group=1000u;
        CHECK(event(&a,fresh_aff,origin+10u));CHECK(a.affiliated && a.phase==P25_TRUNK_ACCESS_READY);
        before=a;CHECK(!p25_trunking_access_select_group(&a,2000u,origin+10u));
        CHECK(!memcmp(&a,&before,sizeof a)); // READY alone is insufficient while PTT remains held.
        tick(&a,origin+11u,true);no_action(&a,origin+11u);
        tick(&a,origin+12u,false);tick(&a,origin+13u,true);
        CHECK(p25_trunking_access_take(&a,&action,origin+13u));
        CHECK(action.type==P25_TRUNK_ACTION_GROUP_REQUEST && action.group==1000u && action.id!=previous);
        done(&a,action,origin+14u);CHECK(!event(&a,grant(),origin+15u));
        p25_trunking_osp fresh_grant=grant();fresh_grant.group=1000u;
        CHECK(event(&a,fresh_grant,origin+16u));CHECK(a.phase==P25_TRUNK_ACCESS_GRANTED);
    }
    for(unsigned stage=0;stage<12u;++stage) {
        p25_trunking_access a,before;uint32_t now=120u;ready(&a,100u);
        if(stage==0u)p25_trunking_access_stop(&a);
        if(stage==1u)initialize(&a,100u);
        if(stage==2u) {initialize(&a,100u);refresh(&a,100u);}
        if(stage==3u) {initialize(&a,100u);refresh(&a,100u);tick(&a,100u,false);take(&a,P25_TRUNK_ACTION_REGISTER,100u);}
        if(stage==4u)tick(&a,106u,true); // New physical request, not quiescent.
        if(stage==5u)requested(&a,100u);
        if(stage==6u)granted(&a,100u);
        if(stage==7u) {granted(&a,100u);tick(&a,109u,true);take(&a,P25_TRUNK_ACTION_VOICE_START,109u);}
        if(stage==8u)started(&a,100u);
        if(stage==9u) {started(&a,100u);tick(&a,111u,false);}
        if(stage==10u) {started(&a,100u);tick(&a,111u,false);done(&a,take(&a,P25_TRUNK_ACTION_VOICE_STOP,111u),112u);}
        if(stage==11u)p25_trunking_access_fault(&a,P25_TRUNK_ACCESS_TRANSPORT,110u);
        before=a;CHECK(!p25_trunking_access_select_group(&a,1000u,now));
        CHECK(!memcmp(&a,&before,sizeof a));
    }
    p25_trunking_access a,before;ready(&a,100u);before=a;
    CHECK(!p25_trunking_access_select_group(&a,0u,106u));CHECK(!memcmp(&a,&before,sizeof a));
    CHECK(!p25_trunking_access_select_group(&a,1000u,3100u));CHECK(!memcmp(&a,&before,sizeof a));
}
static void write_request(FILE *output,p25_trunking_access_action action) {
    uint8_t block[1][12],wire[45];bool okay=false;
    if(action.type==P25_TRUNK_ACTION_REGISTER)okay=p25_trunking_isp_register(block[0],configuration.wacn,configuration.system,action.radio_id);
    if(action.type==P25_TRUNK_ACTION_AFFILIATE)okay=p25_trunking_isp_affiliate(block[0],configuration.system,action.group,action.radio_id);
    if(action.type==P25_TRUNK_ACTION_GROUP_REQUEST)okay=p25_trunking_isp_group_request(block[0],action.group,action.radio_id,0);
    CHECK(okay);CHECK(p25_tsdu_encode(wire,sizeof wire,action.nac,(const uint8_t (*)[12])block,1,P25_TRUNKING_ISP_STATUS)==sizeof wire);
    CHECK(fwrite(wire,1,sizeof wire,output)==sizeof wire);
}
static void encoded_exchange(const char *input_name,const char *output_name) {
    FILE *input=fopen(input_name,"rb"),*output=fopen(output_name,"wb");CHECK(input && output);
    p25_trunking_access a;initialize(&a,0);refresh(&a,0);tick(&a,0,false);
    const p25_trunking_access_action_type types[]={P25_TRUNK_ACTION_REGISTER,P25_TRUNK_ACTION_AFFILIATE,P25_TRUNK_ACTION_GROUP_REQUEST};
    for(unsigned i=0;i<3;++i) {
        uint32_t now=10u*i;tick(&a,now,i==2);
        p25_trunking_access_action action=take(&a,types[i],now);write_request(output,action);done(&a,action,now+1);
        uint8_t wire[45];CHECK(fread(wire,1,sizeof wire,input)==sizeof wire);
        p25_tsdu decoded;CHECK(p25_tsdu_decode(wire,sizeof wire,&decoded));CHECK(decoded.count==1);
        p25_trunking_osp osp;CHECK(p25_trunking_osp_parse(decoded.block[0],&osp));
        CHECK(p25_trunking_access_consume(&a,&osp,decoded.nac,440075000,&voice_pair,now+2));
    }
    CHECK(a.phase==P25_TRUNK_ACCESS_GRANTED && a.voice_channel==0xa321u && a.voice_options==0x85u);
    // A second independently encoded, CRC-qualified grant is stale once the
    // first grant owns the lease, even with our RID/TG and a valid pair.
    uint8_t wire[45];CHECK(fread(wire,1,sizeof wire,input)==sizeof wire);
    p25_tsdu decoded;CHECK(p25_tsdu_decode(wire,sizeof wire,&decoded));
    p25_trunking_osp osp;CHECK(p25_trunking_osp_parse(decoded.block[0],&osp));
    CHECK(osp.channel==0xa322u && osp.options==3u);
    CHECK(!p25_trunking_access_consume(&a,&osp,decoded.nac,440075000,&voice_pair,23));
    CHECK(a.voice_channel==0xa321u && a.voice_options==0x85u);tick(&a,30,true);
    p25_trunking_access_action action=take(&a,P25_TRUNK_ACTION_VOICE_START,30);
    CHECK(action.tx_hz==445087500 && action.channel==0xa321u && action.options==0x85u);
    CHECK(fgetc(input)==EOF);fclose(input);fclose(output);
}
static void encoded_unsupported(const char *input_name) {
    FILE *input=fopen(input_name,"rb");CHECK(input);
    for(unsigned i=0;i<12;++i) {
        p25_trunking_access a;ready(&a,0);uint8_t wire[45];
        CHECK(fread(wire,1,sizeof wire,input)==sizeof wire);
        p25_tsdu decoded;CHECK(p25_tsdu_decode(wire,sizeof wire,&decoded));
        p25_trunking_osp osp;CHECK(p25_trunking_osp_parse(decoded.block[0],&osp));
        CHECK(osp.type==P25_TRUNK_OSP_UNSUPPORTED);
        bool own=i>=9 || i%3==0;
        CHECK(p25_trunking_access_consume(&a,&osp,decoded.nac,440075000,NULL,6)==own);
        CHECK(a.phase==(own ? P25_TRUNK_ACCESS_FAILED : P25_TRUNK_ACCESS_READY));
        no_action(&a,6);
    }
    CHECK(fgetc(input)==EOF);fclose(input);
}
int main(int argc,char **argv) {
    test_validation_and_idle();test_site_identity();test_fresh_ptt_and_own_grant();
    test_grant_refusal();test_deny_queue_and_retry();test_lifecycle_and_faults();test_wraparound();
    test_action_lease_edges();test_grant_metadata();test_group_selection();
    if(argc>=3)encoded_exchange(argv[1],argv[2]);
    if(argc>=4)encoded_unsupported(argv[3]);
    printf("P25 subscriber policy: %u bounded access/lifecycle assertions passed; state=%lu bytes\n",assertions,(unsigned long)sizeof(p25_trunking_access));
    return 0;
}
