# SPDX-License-Identifier: GPL-3.0-or-later
"""Bit-exact boundary dispatch against pinned pre-change parser source.

Exhaust finite parser position/DUID/expected/input guard combinations and stream
independent OP25 TSDUs through both implementations. Optional host timing and a
saved PCM fixture rank host work only; neither qualifies target timing.
"""
import argparse
import ctypes as C
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--benchmark',action='store_true')
parser.add_argument('--pcm',type=Path,help='Optional owner-local signed16 little-endian 8-kHz fixture')
args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-rx-boundaries';BUILD.mkdir(exist_ok=True,parents=True)
FROZEN=ROOT/'tests/reference/p25_rx_before_boundaries.c'
assert hashlib.sha256(FROZEN.read_bytes().replace(b'\r\n',b'\n')).hexdigest()==(
    'a977a339921bf131ba9647848a3eae571f9a9dc707c62615a1cd7d47a27838fa')
rename='''#define p25_rx_init boundary_old_init
#define p25_rx_gap boundary_old_gap
#define p25_rx_push boundary_old_push
#define p25_rx_nid_decode boundary_old_nid_decode
#define p25_rx_voice_quality boundary_old_voice_quality
#define p25_rx_voice boundary_old_voice
'''
(BUILD/'old.c').write_text(rename+'#include "'+FROZEN.as_posix()+'"\n')
# Both demodulators use one current API/source snapshot. Only parser dispatch
# differs; no frozen demod algorithm or old struct layout is mixed into this test.
demod=(ROOT/'src/firmware/p25_demod.c').read_text()
(BUILD/'current-demod.c').write_text(demod)
(BUILD/'old-demod.c').write_text(rename+'''#define p25_demod_init boundary_old_demod_init
#define p25_demod_gap boundary_old_demod_gap
#define p25_demod_control_tracking boundary_old_demod_control_tracking
#define p25_demod_control_tracking_lanes boundary_old_demod_control_tracking_lanes
#define p25_demod_push boundary_old_demod_push
#define p25_demod_push_at boundary_old_demod_push_at
#define p25_demod_push_at_observed boundary_old_demod_push_at_observed
'''+demod)
library=BUILD/('boundaries.dll' if sys.platform=='win32' else 'boundaries.so')
command=['gcc','-std=c11','-Os','-Wall','-Wextra','-Werror','-Wshadow','-shared']
if sys.platform!='win32':command+=['-fPIC']
command+=['-Isrc/firmware','tests/test_p25_rx_boundaries.c',str(BUILD/'old.c'),
          str(BUILD/'old-demod.c'),str(BUILD/'current-demod.c'),
          'src/firmware/p25_rx.c','src/firmware/p25_tsdu.c','-o',str(library)]
subprocess.run(command,cwd=ROOT,check=True,timeout=120)
lib=C.CDLL(str(library));Byte=C.c_uint8;P=C.POINTER(Byte)
lib.boundary_check_states.restype=C.c_uint64
lib.boundary_check_stream.argtypes=[P,C.c_uint];lib.boundary_check_stream.restype=C.c_uint64
lib.boundary_check_pcm.argtypes=[C.POINTER(C.c_int16),C.c_uint,C.POINTER(C.c_uint64)]
lib.boundary_check_pcm.restype=C.c_uint64
lib.boundary_benchmark.argtypes=[P,C.c_uint,C.c_uint,C.c_uint]
lib.boundary_benchmark.restype=C.c_double
comparisons=lib.boundary_check_states()

reference=ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py'
assert hashlib.sha256(reference.read_bytes().replace(b'\r\n',b'\n')).hexdigest()==(
    '27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9')
spec=importlib.util.spec_from_file_location('boundary_op25',reference)
op=importlib.util.module_from_spec(spec);previous=Path.cwd();os.chdir(BUILD)
try:spec.loader.exec_module(op)
finally:os.chdir(previous)
op.outfile.close();op.text_out=lambda *_:None
generated=[]
op.print_spec=lambda symbols:generated.append(bytes(sum(symbols[i+j]<<(6-2*j) for j in range(4))
                                                 for i in range(0,len(symbols),4)))
def symbols(wire):return [(v>>shift)&3 for v in wire for shift in (6,4,2,0)]
def check(values):
    global comparisons
    data=(Byte*len(values))(*values)
    comparisons=lib.boundary_check_stream(data,len(data))
def frame(count,nac=0x293,marker=0):
    generated.clear();op.construct_tsdu3(nac,1,count,0,[0x34,0x3a,0][:count],
        [0x1000640000a0a4fe^marker,0x0001010112345678^marker,0x001001000a000001^marker][:count])
    return generated[0]
def replace_block(wire,index,block):
    values=symbols(wire)
    coded=op.data_interleave(op.trellis_1_2_encode(op.split_dibits(block,48)))
    for i,value in enumerate(coded):
        logical=56+98*index+i;values[logical+logical//35]=value
    return values
rng=random.Random(0x25B0A0);cases=0;corpus=[]
for count in (1,2,3):
    for nac in (0,1,0x293,0x7ff,0xfff):
        wire=frame(count,nac,rng.getrandbits(40));values=symbols(wire);corpus+=values
        check(values+values);cases+=1
        # Every truncation boundary, followed by invalid dibit reset and a
        # complete frame, proves early exits do not alter partial framing.
        for cut in range(len(values)+1):check(values[:cut]+[4]+values);cases+=1
        # Every physical coded/status bit, including every NID bit and both
        # sides of all three block-end decisions.
        for bit in range(len(values)*2):
            damaged=values.copy();damaged[bit//2]^=1<<(bit%2)
            check(damaged+[4]+values);cases+=1
        # Keep channel code perfect while making CRC and LB contradictory.
        for index in range(count):
            block=op.construct_tsbk(index==count-1,0,0x34,0,rng.getrandbits(64))
            check(replace_block(wire,index,block^1)+[4]+values);cases+=1
            block=op.construct_tsbk(index!=count-1,0,0x34,0,rng.getrandbits(64))
            check(replace_block(wire,index,block)+[4]+values);cases+=1
for _ in range(200):
    values=[rng.randrange(5) for _ in range(4096)]
    check(values);cases+=1
report=dict(comparisons=comparisons,stream_cases=cases,compiler=command,
    frozen_source_sha256=hashlib.sha256(FROZEN.read_bytes()).hexdigest(),
    current_source_sha256=hashlib.sha256((ROOT/'src/firmware/p25_rx.c').read_bytes()).hexdigest(),
    hardware_access=False,target_timing_qualified=False,cpu_utilization_measured=False)
if args.pcm:
    raw=args.pcm.read_bytes();assert raw and len(raw)%2==0 and len(raw)<=8_000_000
    pcm=(C.c_int16*(len(raw)//2)).from_buffer_copy(raw);out=(C.c_uint64*2)()
    report['comparisons']=lib.boundary_check_pcm(pcm,len(pcm),out)
    report['saved_pcm']=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                            frames=int(out[0]),statuses=int(out[1]))
if args.benchmark:
    data=(Byte*len(corpus))(*corpus);times=[[],[]]
    for old in (0,1):lib.boundary_benchmark(data,len(data),2,old)
    for repetition in range(7):
        for old in ((0,1) if repetition%2 else (1,0)):
            times[old].append(lib.boundary_benchmark(data,len(data),5000,old))
    report['host_elapsed_ranking']=dict(current_seconds=times[0],old_seconds=times[1],
        current_median=statistics.median(times[0]),old_median=statistics.median(times[1]),
        ratio_current_to_old=statistics.median(times[0])/statistics.median(times[1]),
        scope='Host -Os full parser timing only; not C-SKY cycles, MCU latency or utilization')
(BUILD/'result.private.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
