"""Offline canonical source identities, coding provenance and file boundaries."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("source_fixture_test", ROOT/"scripts/generate-p25-source-fixture.py")
TOOL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TOOL)
# Independently exported from all 192 actual SiteSim RxOriginWitness/BuildFrame
# units, not learned from a self-described manifest or a radio recording.
NATIVE_WIRE_SHA256 = "a1d83540e3cdfee60daaa6d26228bfba6852138694d3055f6418dea7bb9524f1"


def crc(data):
    value = 0
    for octet in data:
        for shift in range(7, -1, -1):
            bit = (octet >> shift) & 1
            carry = bool(value & 0x8000) ^ bool(bit)
            value = (value << 1) & 0xFFFF
            if carry:
                value ^= 0x1021
    return value ^ 0xFFFF


class SourceFixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames, cls.manifest = TOOL.make_fixture()

    def test_all_192_frames_match_independently_exported_native_sequence(self):
        wire = b"".join(self.frames)
        self.assertEqual(len(wire), 8640)
        self.assertEqual(hashlib.sha256(wire).hexdigest(), NATIVE_WIRE_SHA256)
        self.assertEqual(TOOL.make_fixture(), (self.frames, self.manifest))
        self.assertEqual(len(set(self.frames)), 192)

    def test_every_identity_crc_status_and_padding_has_the_canonical_geometry(self):
        reference = TOOL.BASE.load_reference()
        for index, (frame, entry) in enumerate(zip(self.frames, self.manifest["frames"])):
            with self.subTest(counter=index+1):
                word = bytes.fromhex(entry["decoded_hex"])
                self.assertEqual(word[:6], b"\xbf\x90ORIG")
                self.assertEqual(int.from_bytes(word[6:10], "big"), index+1)
                self.assertEqual(int.from_bytes(word[10:], "big"), crc(word[:10]))
                self.assertEqual((entry["counter"], entry["wire_offset"], entry["wire_bytes"]),
                                 (index+1, index*45, 45))
                dibits = [(value >> shift) & 3 for value in frame for shift in (6, 4, 2, 0)]
                self.assertEqual([dibits[p] for p in (35, 71, 107, 143, 179)], [3, 2, 2, 2, 2])
                payload = [value for pos, value in enumerate(dibits) if (pos+1) % 36]
                self.assertEqual(payload[:56], reference["start_packet"](0x293, 7))
                self.assertEqual(payload[154:], [0]*21)
                self.assertEqual(len(payload), 175)
                self.assertFalse(word[0] & 0x40)

    def test_manifest_and_serial_inventory_are_bounded_and_never_authorize_rf(self):
        m = self.manifest
        self.assertEqual(m["schema"], "dm32-p25-source-fixture-v1")
        self.assertEqual((m["counter_first"], m["counter_last"], m["units"], m["repetitions"]), (1, 192, 192, 1))
        self.assertEqual(m["airtime_seconds_without_preamble"], 7.2)
        for key in ("contains_grants", "contains_voice", "automatic_responses", "rf_verified",
                    "sample_clock_qualified", "rf_origin_qualified", "access_slot_qualified"):
            self.assertIs(m[key], False)
        serial = b"".join(map(TOOL.BASE.modem_packet, self.frames))
        self.assertEqual(len(serial), 9408)
        for i, frame in enumerate(self.frames):
            self.assertEqual(serial[i*49:(i+1)*49], b"\xe0\x31\x31\0"+frame)
        for name, data in (("control.bin", b"".join(self.frames)), ("control-mmdvm.bin", serial)):
            self.assertEqual(m["files"][name], {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

    def test_invalid_counter_and_modified_reference_fail_before_generation(self):
        reference = TOOL.BASE.load_reference()
        for counter in (0, 193, True, 1.0, "1", None):
            with self.subTest(counter=counter), self.assertRaises(ValueError):
                TOOL.encode_frame(reference, counter)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"changed.py"
            path.write_text(TOOL.BASE.REFERENCE.read_text()+"\n# drift\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "reviewed pin"):
                TOOL.BASE.load_reference(path)

    def test_cli_has_no_reference_top_level_output_or_hardware_side_effect(self):
        with tempfile.TemporaryDirectory() as directory:
            cwd, output = Path(directory), Path(directory)/"fixture"
            result = subprocess.run([sys.executable, "-B", str(ROOT/"scripts/generate-p25-source-fixture.py"),
                                     "--output", str(output)], cwd=cwd,
                                    capture_output=True, text=True, check=True)
            self.assertEqual({p.name for p in cwd.iterdir()}, {"fixture"})
            self.assertEqual({p.name for p in output.iterdir()}, {"control.bin", "control-mmdvm.bin", "manifest.json"})
            self.assertEqual(json.loads((output/"manifest.json").read_text()), self.manifest)
            receipt = json.loads(result.stdout)
            self.assertEqual(receipt["units"], 192)
            self.assertFalse(receipt["rf_verified"])


if __name__ == "__main__":
    unittest.main()
