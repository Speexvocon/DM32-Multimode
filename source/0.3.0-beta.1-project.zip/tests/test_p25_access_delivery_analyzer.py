# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent wire fixtures for the offline access-delivery shadow budget."""
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


analysis = load("access_delivery", "scripts/analyze-p25-access-delivery.py")
fixtures = load("rxstream_wire", "tests/test_p25_rx_stream_analyzer.py")


def slots(statuses=(3, 2, 2, 2, 2, 3), *, age=1500, origin=100000, epochs=None, tick_gap=0):
    ticks = [600 + 360 * i + (tick_gap if i >= 3 else 0) for i in range(len(statuses))]
    samples = ((max(ticks) // 6 + 256) // 256) * 256
    markers = [fixtures.marker(tick, origin=origin, age=age, status=status,
                               epoch=epochs[i] if epochs else 1)
               for i, (tick, status) in enumerate(zip(ticks, statuses))]
    halves = [fixtures.half(i, origin=origin + 32000 * i) for i in range(samples // 256)]
    return fixtures.capture(halves=halves, markers=markers, samples=samples, origin=origin)


class DeliveryTests(unittest.TestCase):
    def test_positive_nominal_margin_never_grants_rf_authority(self):
        result = analysis.analyze(slots(), 0, 0)
        rows = result["observed_idle_markers"]
        self.assertEqual(len(rows), 2)
        self.assertIsNone(rows[0]["nominal_budget_exhausted"])
        self.assertAlmostEqual(rows[1]["nominal_ideal_actuation_margin_us"], 2583.3333333333)
        self.assertFalse(rows[1]["nominal_budget_exhausted"])
        self.assertTrue(rows[1]["coherent_boundary_history"])
        for key in ("sample_origin_qualified", "sample_rate_qualified", "status_duid_recorded",
                    "control_carrier_qualified", "future_boundary_inferred",
                    "first_air_constant_qualified", "automatic_access_qualified", "rf_transmit_permitted"):
            self.assertIs(result[key], False)
        self.assertTrue(all(not row["rf_transmit_permitted"] and row["nid_hold_reason"] == "not_recorded" for row in rows))

    def test_existing_static_actuation_budget_already_exceeds_minimum_window(self):
        result = analysis.analyze(slots())
        self.assertAlmostEqual(result["model"]["configured_budget_before_delivery_us"], -69250)
        self.assertEqual(result["nominal_budget_exhausted_markers"], 1)

    def test_delayed_callback_exhausts_even_ideal_actuation_budget(self):
        row = analysis.analyze(slots(age=6000), 0, 0)["observed_idle_markers"][1]
        self.assertTrue(row["nominal_budget_exhausted"])
        self.assertLess(row["nominal_ideal_actuation_margin_us"], 0)

    def test_negative_origin_and_changed_epoch_are_not_repaired(self):
        trace = fixtures.capture(markers=[fixtures.marker(600, age=-100), fixtures.marker(960, age=-100),
                                          fixtures.marker(1320, epoch=2)])
        rows = analysis.analyze(trace, 0)["observed_idle_markers"]
        self.assertIn("negative_nominal_age_unknown_origin", rows[1]["issues"])
        self.assertIsNone(rows[1]["nominal_budget_exhausted"])
        self.assertIn("no_contiguous_prior_status_in_this_epoch", rows[2]["issues"])

    def test_wrap_and_nonidle_never_manufacture_an_idle_slot(self):
        origin = 0xFFFFF000
        trace = fixtures.capture(origin=origin, markers=[fixtures.marker(600, origin=origin),
            fixtures.marker(960, origin=origin, status=1), fixtures.marker(1320, origin=origin)])
        result = analysis.analyze(trace, 0)
        self.assertEqual(len(result["observed_idle_markers"]), 2)
        self.assertEqual(result["observed_idle_markers"][1]["nominal_irq_relative_age_us"], 1500)

    def test_torn_or_incomplete_evidence_cannot_supply_a_margin(self):
        trace = fixtures.capture(halves=[fixtures.half(0, flags=8192 | 4), fixtures.half(1, origin=132000)])
        result = analysis.analyze(trace, 0)
        self.assertFalse(result["all_streams_coherent"])
        self.assertTrue(all(row["nominal_ideal_actuation_margin_us"] is None for row in result["observed_idle_markers"]))
        with self.assertRaises(analysis.stream.StreamError):
            analysis.analyze(fixtures.capture().rsplit("RXSTREAM_END", 1)[0])

    def test_actuation_is_bounded_explicit_assumption(self):
        for value in (-1, 1000001, True, 1.5):
            with self.subTest(value=value), self.assertRaises(analysis.stream.StreamError):
                analysis.analyze(fixtures.capture(), value)

    def test_clock_lead_does_not_fit_minimum_slot_even_with_zero_actuation(self):
        result = analysis.analyze(slots(), 0)
        self.assertEqual(result["model"]["lead_bytes"], 16)
        self.assertAlmostEqual(result["model"]["lead_us"], 13333.3333333333)
        self.assertEqual(result["model"]["request_plus_lead_us"], 46250)
        self.assertAlmostEqual(result["model"]["ideal_delivery_budget_us"], -9250)
        self.assertTrue(result["observed_idle_markers"][1]["nominal_budget_exhausted"])

    def test_complete_sitesim_pattern_closes_observed_period_without_future_lease(self):
        result = analysis.analyze(slots(), 0, 0)
        history = result["observed_slot_histories"][0]
        self.assertEqual(history["coherent_idle_boundaries"], 1)
        self.assertEqual(history["closed_observed_periods"], [{
            "first_marker": 0, "last_marker": 5, "first_tick": 600, "last_tick": 2400,
            "microslots": 5, "observed_ticks": 1800, "nominal_period_us": 37500}])
        self.assertFalse(history["future_boundary_inferred"])
        self.assertFalse(history["rf_transmit_permitted"])

    def test_adjacent_idle_markers_and_single_boundary_do_not_establish_phase(self):
        for trace in (fixtures.capture(), slots(statuses=(3, 2, 2, 2, 2))):
            result = analysis.analyze(trace, 0, 0)
            self.assertEqual(result["observed_slot_histories"][0]["coherent_idle_boundaries"], 0)
            self.assertTrue(all(row["nominal_ideal_actuation_margin_us"] is None
                                for row in result["observed_idle_markers"]))

    def test_busy_unknown_or_status_gap_cannot_bridge_old_boundary(self):
        traces = [slots(statuses=(3, 2, status, 2, 2, 3)) for status in (0, 1)]
        traces.append(slots(tick_gap=360))
        for trace in traces:
            result = analysis.analyze(trace, 0, 0)
            self.assertEqual(result["observed_slot_histories"][0]["coherent_idle_boundaries"], 0)
            self.assertTrue(all(row["nominal_ideal_actuation_margin_us"] is None
                                for row in result["observed_idle_markers"]))

    def test_changed_lane_epoch_revokes_old_slot_history(self):
        result = analysis.analyze(slots(epochs=(1, 1, 1, 2, 2, 2)), 0, 0)
        self.assertEqual(result["observed_slot_histories"][0]["coherent_idle_boundaries"], 0)
        self.assertFalse(result["observed_idle_markers"][-1]["coherent_boundary_history"])

    def test_longer_past_period_does_not_increase_next_window_budget(self):
        result = analysis.analyze(slots(statuses=(3, 2, 2, 2, 2, 2, 2, 2, 3)), 0)
        period = result["observed_slot_histories"][0]["closed_observed_periods"][0]
        self.assertEqual(period["nominal_period_us"], 60000)
        self.assertEqual(result["model"]["minimum_window_ticks"], 1800)
        self.assertTrue(result["observed_idle_markers"][-1]["nominal_budget_exhausted"])

    def test_cpu_wrap_preserves_only_observed_nominal_history(self):
        result = analysis.analyze(slots(origin=0xFFFFF000), 0, 0)
        self.assertEqual(result["observed_slot_histories"][0]["coherent_idle_boundaries"], 1)
        self.assertAlmostEqual(result["observed_idle_markers"][-1]["nominal_irq_relative_age_us"], 1500)

    def test_lead_is_bounded_and_cannot_be_silently_coerced(self):
        for value in (-1, 17, True, 1.5):
            with self.subTest(value=value), self.assertRaises(analysis.stream.StreamError):
                analysis.analyze(slots(), 0, value)


if __name__ == "__main__":
    unittest.main()
