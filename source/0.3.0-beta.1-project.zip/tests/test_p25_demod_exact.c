// SPDX-License-Identifier: GPL-3.0-or-later
// Differential oracle is the frozen installed7d38b96, not a second fast path.
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "../src/firmware/p25_demod.c"
void p25_baseline_init(p25_demod *d);
void p25_baseline_gap(p25_demod *d);
void p25_baseline_push(p25_demod *d,int16_t sample,p25_demod_frame_fn emit,void *context);
bool p25_baseline_push_at(p25_demod *d,int16_t sample,uint64_t tick,uint32_t epoch,
    p25_demod_frame_fn emit,p25_demod_status_fn status,void *context);
bool p25_baseline_acquire(p25_demod_lane *lane);
int32_t p25_baseline_timing_error(int32_t delta,int32_t gain);
int32_t p25_baseline_interpolate(int16_t previous,int16_t value,uint32_t back);
static uint32_t rng=1u,clock_tick;
static uint32_t random_word(void) {rng=rng*1664525u+1013904223u;return rng;}
static uint32_t clock_word(void) {clock_tick+=13u;return clock_tick;}
typedef struct {
    p25_rx frames[4];uint64_t statuses[16][7];unsigned frame_count,status_count;
} outputs;
static outputs *active;
static void frame_output(const p25_rx *frame,void *context) {
    (void)context;assert(active->frame_count<4u);active->frames[active->frame_count++]=*frame;
}
static void status_output(const p25_demod_status *event,void *context) {
    (void)context;assert(active->status_count<16u);uint64_t *v=active->statuses[active->status_count++];
    v[0]=event->sample_tick;v[1]=event->stream_epoch;v[2]=event->lane_epoch;
    v[3]=event->nac;v[4]=event->status;v[5]=event->lane;
    v[6]=(event->selected?1u:0u)|(event->qualified?2u:0u)|((unsigned)event->duid<<8);
}
static void history(p25_demod_lane *l,const int16_t values[24],unsigned index) {
    memset(l,0,sizeof *l);l->index=index;l->filled=24u;
    for(unsigned i=0;i<24u;++i) {
        l->history[i]=l->history[i+24u]=values[i];
        l->sum+=values[i];l->sum_squares+=(int32_t)values[i]*values[i];
    }
    // Verify both the ordinary ring and every rearmed window's invariant.
    int32_t sum=0,squares=0;
    for(unsigned i=0;i<24u;++i) {int32_t v=l->history[l->index+i];sum+=v;squares+=v*v;}
    assert(sum==l->sum&&squares==l->sum_squares);
}
static unsigned correlation_bound(int32_t z,uint32_t xx) {
    assert(z>=-585728&&z<=585728&&xx<=2415919104u);
    bool exact_reject=10*(int64_t)z*z<1287*(int64_t)xx;
    bool coarse=correlation_reject(z,xx);
    assert(!coarse||exact_reject); // Includes every accepted/tied exact case.
    return 1u;
}
unsigned p25_exact_arithmetic(void) {
    static const int8_t sign[24]={1,1,1,1,1,-1,1,1,-1,-1,1,1,-1,-1,-1,-1,1,-1,1,-1,-1,-1,-1,-1};
    int16_t values[24];unsigned comparisons=0;
    for(unsigned n=0;n<300000u;++n) {
        unsigned kind=n%8u,index=n%24u;
        for(unsigned i=0;i<24u;++i) {
            int32_t v;
            if(kind==0u)v=(n&8u)?-2048:2047; // sx*sx can exceed INT32_MAX.
            else if(kind==1u)v=((i+n)&1u)?-2048:2047;
            else if(kind==2u)v=(random_word()&1u)?-2048:2047;
            else if(kind==3u)v=(int32_t)(random_word()%4096u)-2048;
            else {
                int32_t gain=1+(int32_t)(n%1100u),dc=(int32_t)(n%1700u)-850;
                v=sign[(i+24u-index)%24u]*gain+dc+(int32_t)(random_word()%101u)-50;
                if(v<-2048)v=-2048;
                if(v>2047)v=2047;
            }
            values[i]=(int16_t)v;
        }
        p25_demod_lane baseline,current;history(&baseline,values,index);current=baseline;
        bool old=p25_baseline_acquire(&baseline),fast=acquire(&current);
        assert(old==fast&&!memcmp(&baseline,&current,sizeof baseline));++comparisons;
    }
    const int32_t gains[]={1,2,3,99,100,1000,10923,16383,16384,16385,32768,65535,65536,1000000};
    for(unsigned i=0;i<sizeof gains/sizeof *gains;++i) {
        int32_t g=gains[i];
        for(int32_t delta=-4*g-2;delta<=4*g+2;delta+=(g<20000?1:127)) {
            int64_t oracle=(int64_t)delta*65536/g;
            if(oracle>262144)oracle=262144;
            if(oracle<-262144)oracle=-262144;
            assert(p25_timing_error(delta,g)==oracle);
            assert(p25_baseline_timing_error(delta,g)==oracle);++comparisons;
        }
    }
    for(unsigned n=0;n<1000000u;++n) {
        int16_t a=(int16_t)(random_word()>>16),b=(int16_t)(random_word()>>16);
        uint32_t back=random_word()&65535u;
        assert(p25_interpolate(a,b,back)==p25_baseline_interpolate(a,b,back));
        int32_t g=1+(int32_t)(random_word()%1000000u);
        int32_t delta=(int32_t)(random_word()%(8u*(uint32_t)g+1u))-4*g;
        assert(p25_timing_error(delta,g)==p25_baseline_timing_error(delta,g));comparisons+=2u;
        int32_t z=(int32_t)(random_word()%1171457u)-585728;
        comparisons+=correlation_bound(z,random_word()%2415919105u);
    }
    for(int32_t g=1;g<=16384;++g) {
        const int32_t delta[]={-4*g-1,-4*g,-4*g+1,-g-1,-g,-g+1,-1,0,1,g-1,g,g+1,4*g-1,4*g,4*g+1};
        for(unsigned i=0;i<sizeof delta/sizeof *delta;++i) {
            assert(p25_timing_error(delta[i],g)==p25_baseline_timing_error(delta[i],g));++comparisons;
        }
    }
    // Every U32 coarse-bin transition and both endpoints of its discarded
    // low16 variance bits, on both covariance polarities. Equality at the
    // coarse boundary is safe only because the covariance upper bound is strict.
    for(uint32_t bucket=1;bucket<=2289u;++bucket) {
        uint32_t transition=(10u*bucket*bucket+1286u)/1287u;
        for(int32_t step=-1;step<=1;++step) {
            int32_t bin=(int32_t)transition+step;
            if(bin<0||bin>36864)continue;
            for(unsigned low=0;low<2u;++low) {
                uint32_t xx=((uint32_t)bin<<16)+(low?65535u:0u);
                if(xx>2415919104u)continue;
                for(int32_t edge=-1;edge<=1;++edge) {
                    int32_t z=(int32_t)(bucket*256u)+edge;
                    if(z>585728)continue;
                    comparisons+=correlation_bound(z,xx)+correlation_bound(-z,xx);
                }
            }
        }
    }
    // Exact quality900 ties exist at z=429*k, xx=1430*k*k. They must never
    // be rejected, including one variance step either side of the threshold.
    for(int32_t k=1;k<=1299;++k) {
        int32_t z=429*k;uint32_t xx=1430u*(uint32_t)k*(uint32_t)k;
        for(int32_t step=-1;step<=1;++step) {
            uint32_t value=(uint32_t)((int64_t)xx+step);
            comparisons+=correlation_bound(z,value)+correlation_bound(-z,value);
        }
        assert(!correlation_reject(z,xx)&&!correlation_reject(-z,xx));
    }
    return comparisons;
}
unsigned p25_exact_run(const int16_t *samples,unsigned count,uint64_t origin,unsigned mode,unsigned seed) {
    p25_demod baseline,current;p25_baseline_init(&baseline);p25_demod_init(&current);
    if(mode==8u)baseline.ticks=current.ticks=UINT64_MAX-200u;
    if(mode==9u)baseline.clock_us=current.clock_us=clock_word;
    if(mode>=9u)baseline.rare_fec_clock_us=current.rare_fec_clock_us=clock_word;
    baseline.hunt_clock_us=current.hunt_clock_us=mode>=9u?clock_word:NULL;
    unsigned frames=0;
    for(unsigned i=0;i<count;++i) {
        outputs old={0},fast={0};bool same_old=true,same_fast=true;
        uint64_t tick=origin+(uint64_t)i*6u;uint32_t epoch=UINT32_MAX-1u;
        if(mode==2u&&i>=count/2u)tick+=6u;
        if(mode==3u&&i>=count/2u)++epoch;
        if(mode==4u&&i==count/2u) {p25_baseline_gap(&baseline);p25_demod_gap(&current);}
        if(mode==7u&&i==count/3u)baseline.lane_epoch=current.lane_epoch=UINT32_MAX;
        uint32_t begin=seed+i*71u;clock_tick=begin;active=&old;
        bool legacy=mode==0u||(mode==5u&&(i/997u)%2u);
        if(legacy)p25_baseline_push(&baseline,samples[i],frame_output,NULL);
        else same_old=p25_baseline_push_at(&baseline,samples[i],tick,epoch,frame_output,status_output,NULL);
        uint32_t end=clock_tick;clock_tick=begin;active=&fast;
        if(legacy)p25_demod_push(&current,samples[i],frame_output,NULL);
        else same_fast=p25_demod_push_at(&current,samples[i],tick,epoch,frame_output,status_output,NULL);
        active=NULL;
        if(same_old!=same_fast||end!=clock_tick||memcmp(&old,&fast,sizeof old)||memcmp(&baseline,&current,sizeof baseline)) {
            fprintf(stderr,"demod golden mismatch mode=%u sample=%u old_frames=%u new_frames=%u old_status=%u new_status=%u\n",
                mode,i,old.frame_count,fast.frame_count,old.status_count,fast.status_count);assert(false);
        }
        frames+=fast.frame_count;
    }
    return frames;
}
static volatile unsigned benchmark_hash;
static void benchmark_frame(const p25_rx *frame,void *context) {(void)context;benchmark_hash^=frame->frame[7];}
static void benchmark_status(const p25_demod_status *event,void *context) {(void)context;benchmark_hash^=(unsigned)event->sample_tick;}
double p25_exact_benchmark(const int16_t *samples,unsigned count,unsigned repeats,unsigned baseline) {
    clock_t begin=clock();
    for(unsigned rep=0;rep<repeats;++rep) {
        p25_demod d;if(baseline)p25_baseline_init(&d);else p25_demod_init(&d);
        for(unsigned i=0;i<count;++i) {
            if(baseline)(void)p25_baseline_push_at(&d,samples[i],(uint64_t)i*6u,1u,benchmark_frame,benchmark_status,NULL);
            else (void)p25_demod_push_at(&d,samples[i],(uint64_t)i*6u,1u,benchmark_frame,benchmark_status,NULL);
        }
    }
    return (double)(clock()-begin)/CLOCKS_PER_SEC;
}
