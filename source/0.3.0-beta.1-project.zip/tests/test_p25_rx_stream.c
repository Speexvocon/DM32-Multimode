// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx_stream.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct {
    p25_rx_stream stream;
    unsigned char ring[8192],ledger[15360],window[1024];
    uint32_t now,origin;
    unsigned reads,pending_after,mutate_after;
    bool pending;
} fixture;
static int16_t value(unsigned ordinal) {return (int16_t)(ordinal*173u+0x1213u);}
static void word(fixture *f,unsigned half,unsigned off,int16_t v) {
    unsigned n=(half-1u)*512u+off*2u;f->window[n]=(unsigned char)((uint16_t)v>>8);
    f->window[n+1]=(unsigned char)v;
}
static uint8_t read_byte(void *opaque,unsigned offset) {
    fixture *f=opaque;assert(offset<1024u);++f->reads;++f->now;
    if(f->pending_after&&f->reads==f->pending_after)f->pending=true;
    if(f->mutate_after&&f->reads==f->mutate_after)f->window[offset]^=0x55;
    return f->window[offset];
}
static uint32_t clock_us(void *opaque) {return ((fixture *)opaque)->now;}
static bool half_pending(void *opaque) {return ((fixture *)opaque)->pending;}
static p25_rx_progress_io io_for(fixture *f) {
    p25_rx_progress_io io={f,read_byte,clock_us,half_pending};return io;
}
static void start(fixture *f,unsigned samples,unsigned guard,uint32_t now) {
    memset(f,0,sizeof *f);f->now=f->origin=now;
    assert(p25_rx_stream_start(&f->stream,f->ring,sizeof f->ring,f->ledger,sizeof f->ledger,
        samples,guard,17,now));
    p25_rx_stream_irq(&f->stream,1,now);
}
static void fill(fixture *f,unsigned index,unsigned count) {
    unsigned half=index%2u?1u:2u;
    for(unsigned i=0;i<count;++i)word(f,half,i,value(index*256u+i));
}
static void consume(fixture *f) {
    p25_rx_stream_chunk row;
    while(p25_rx_stream_pop(&f->stream,&row,f->now)) {
        assert(row.first_sample+16u==f->stream.consumed);
        for(unsigned i=0;i<16u;++i)assert(row.samples[i]==value((unsigned)row.first_sample+i));
        assert(!row.flags&&!row.reserved[0]&&!row.reserved[1]&&!row.reserved[2]);
    }
}
static void run(unsigned samples,unsigned guard,uint32_t origin) {
    fixture f;start(&f,samples,guard,origin);p25_rx_progress_io io=io_for(&f);
    unsigned completed=0;
    for(uint32_t tick=500;tick<(samples/256u+2u)*32000u&&p25_rx_stream_active(&f.stream);tick+=500u) {
        f.now=origin+tick;
        unsigned next_completed=tick/32000u;
        if(next_completed>completed) {
            fill(&f,completed,256);completed=next_completed;
            p25_rx_stream_irq(&f.stream,completed%2u?2u:1u,f.now);
        }
        if(completed<samples/256u)fill(&f,completed,(tick%32000u)/125u);
        unsigned before=f.reads;(void)p25_rx_stream_step(&f.stream,&io,f.now);
        assert(f.reads-before<=96u);
        if(!(tick%4000u))consume(&f);
    }
    assert(f.stream.state==P25_RX_STREAM_DRAINING);
    assert(!f.stream.finalized);consume(&f);p25_rx_stream_finalize(&f.stream);
    assert(f.stream.state==P25_RX_STREAM_COMPLETE&&f.stream.finalized);
    assert(f.stream.produced==samples&&f.stream.consumed==samples&&f.stream.verified==samples&&!f.stream.faults);
    for(unsigned i=0;i<samples/256u;++i) {
        p25_rx_stream_half h;assert(p25_rx_stream_half_read(&f.stream,i,&h));
        assert(h.first_sample==(uint64_t)i*256u&&h.origin_irq_count==i+1u);
        assert(h.origin_irq_us==origin+i*32000u&&h.completion_irq_us==origin+(i+1u)*32000u);
        assert(h.early_samples+h.tail_samples==256u&&h.tail_samples&&!(h.tail_samples%16u));
        assert(h.verified_chunks==16u&&!h.mismatch_chunks&&h.flags==8192u);
        assert(h.published_hash==h.completed_hash&&h.max_read_us==96u&&h.max_queue_us<=4000u);
    }
}
static void faults(void) {
    fixture f;p25_rx_progress_io io;
    start(&f,512,2000,0);io=io_for(&f);fill(&f,0,64);f.now=8000;
    f.pending=true;assert(!p25_rx_stream_step(&f.stream,&io,f.now)&&!f.reads&&!f.stream.faults);
    f.pending=false;f.pending_after=90;
    assert(!p25_rx_stream_step(&f.stream,&io,f.now)&&f.stream.state==P25_RX_STREAM_FAULT);
    assert(f.stream.faults&P25_RX_STREAM_IRQ_READ);assert(!f.stream.produced&&!f.stream.finalized);
    p25_rx_stream_finalize(&f.stream);assert(f.stream.finalized);
    start(&f,512,2000,0);io=io_for(&f);fill(&f,0,64);f.now=8000;f.mutate_after=50;
    assert(!p25_rx_stream_step(&f.stream,&io,f.now)&&f.stream.faults&P25_RX_STREAM_CHANGED);
    start(&f,512,2000,0);p25_rx_stream_irq(&f.stream,1,32000);
    assert(f.stream.faults&P25_RX_STREAM_SEQUENCE);
    start(&f,512,2000,0);p25_rx_stream_irq(&f.stream,2,35000);
    assert(f.stream.faults&P25_RX_STREAM_CLOCK);
    start(&f,512,2000,0);p25_rx_stream_irq(&f.stream,2,32000);p25_rx_stream_irq(&f.stream,1,64000);
    assert(f.stream.faults&P25_RX_STREAM_OVERWRITTEN);
    start(&f,512,2000,0);io=io_for(&f);f.now=4000001;
    assert(!p25_rx_stream_step(&f.stream,&io,f.now)&&f.stream.state==P25_RX_STREAM_TIMEOUT);
    start(&f,512,2000,0);p25_rx_stream_cancel(&f.stream);assert(f.stream.state==P25_RX_STREAM_CANCELLED);
    p25_rx_stream_finalize(&f.stream);p25_rx_stream_half h;
    assert(p25_rx_stream_half_read(&f.stream,0,&h)&&h.flags&P25_RX_STREAM_UNPAIRED);
}
static void mismatch(void) {
    fixture f;start(&f,256,2000,0);p25_rx_progress_io io=io_for(&f);
    for(unsigned t=500;t<32000;t+=500) {f.now=t;fill(&f,0,t/125u);(void)p25_rx_stream_step(&f.stream,&io,t);consume(&f);}
    fill(&f,0,256);word(&f,2,0,123);f.now=32000;p25_rx_stream_irq(&f.stream,2,f.now);
    for(unsigned t=32000;t<34000&&p25_rx_stream_active(&f.stream);t+=500) {f.now=t;(void)p25_rx_stream_step(&f.stream,&io,t);consume(&f);}
    assert(f.stream.state==P25_RX_STREAM_FAULT&&f.stream.faults&P25_RX_STREAM_MISMATCH);
    p25_rx_stream_half h;assert(p25_rx_stream_half_read(&f.stream,0,&h)&&h.mismatch_chunks==1u);
}
static void ring_and_terminal_faults(void) {
    fixture f;start(&f,4096,2000,0);p25_rx_progress_io io=io_for(&f);unsigned completed=0;
    // Verification continues without a consumer. Retaining verified-but-not-
    // consumed rows must fail closed before any unread row is overwritten.
    for(unsigned t=500;p25_rx_stream_active(&f.stream);t+=500) {
        assert(t<400000u);f.now=t;
        if(t/32000u>completed) {fill(&f,completed,256);completed=t/32000u;
            p25_rx_stream_irq(&f.stream,completed%2u?2u:1u,t);}
        fill(&f,completed,t%32000u/125u);(void)p25_rx_stream_step(&f.stream,&io,t);
    }
    assert(f.stream.faults&P25_RX_STREAM_RING_FULL);
    assert(f.stream.produced==2048u&&!f.stream.consumed);
    start(&f,256,2000,0);f.stream.state=P25_RX_STREAM_DRAINING;f.stream.markers=384;
    unsigned char marker[32]={0};assert(!p25_rx_stream_marker(&f.stream,marker));
    assert(f.stream.state==P25_RX_STREAM_FAULT&&f.stream.faults&P25_RX_STREAM_RING_FULL);
    start(&f,256,2000,0);f.stream.state=P25_RX_STREAM_DRAINING;f.stream.produced=16;
    memset(f.ring,0xff,64);p25_rx_stream_chunk chunk;
    assert(!p25_rx_stream_pop(&f.stream,&chunk,0)&&f.stream.state==P25_RX_STREAM_FAULT);
    start(&f,256,2000,0);p25_rx_stream_cancel(&f.stream);
    assert(!p25_rx_stream_start(&f.stream,f.ring,8192,f.ring,15360,256,2000,1,0));
    assert(f.stream.state==P25_RX_STREAM_CANCELLED);
}
int main(void) {
    for(unsigned guard=0;guard<=8000;guard+=2000) {run(16384,guard,1000);run(256,guard,UINT32_MAX-10000u);}
    faults();mismatch();ring_and_terminal_faults();puts("RX stream continuous assembler: PASS");return 0;
}
