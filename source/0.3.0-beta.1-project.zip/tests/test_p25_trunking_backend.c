// SPDX-License-Identifier: GPL-3.0-or-later
// Native backend + independently encoded incoming/outgoing wire. No RF.
#include "p25_trunking_backend.h"
#include "p25_tsdu.h"
#include "p25_data_fec.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static unsigned checks;
#define CHECK(x) do {++checks;assert(x);} while(0)
typedef struct {
    p25_trunking_backend b;p25_trunking_session s;
    p25_trunking_session_clock clock;
    uint32_t now,epoch;uint64_t origin;
} model;
static uint8_t incoming[6][12];
static p25_trunking_session_config config(void) {
    return (p25_trunking_session_config){.subscriber={.wacn=0xabcde,.system=0x123,.radio_id=1234567,
        .nac=0x293,.group=10,.rfss=1,.site=2,.min_hz=400000000,.max_hz=480000000,.tot_ms=1000},
        .control_rx_hz=440075000,.slot_tolerance_ticks=3,.slot_max_age_ticks=300,
        .actuation_ticks=0,.burst_ticks=1580,.end_guard_ticks=24,.max_start_delay_ticks=0,
        .contention_skip=0,.contention_wait_ticks=48000};
}
static bool receive(model *m,const uint8_t block[12],uint32_t epoch) {
    return p25_trunking_backend_consume_control(&m->b,&m->s,0x293,440075000,epoch,block,m->now);
}
static void site(model *m) {for(unsigned i=0;i<3u;++i)CHECK(receive(m,incoming[i],m->epoch));}
static void start(model *m,p25_trunking_backend_mode mode) {
    memset(m,0,sizeof *m);m->epoch=11u;p25_trunking_session_config c=config();
    CHECK(p25_trunking_backend_start(&m->b,&m->s,&c,mode,0));site(m);
}
static void observed(model *m,uint64_t tick,unsigned status) {
    p25_trunking_slot_observation o={.sample_tick=tick,.stream_epoch=m->epoch,.lane_epoch=22u,
        .status=(uint8_t)status,.selected=true,.qualified=true};
    CHECK(p25_trunking_backend_observe(&m->b,&m->s,&o,m->now));
}
static void anchor(model *m) {
    m->origin+=10000u;m->now+=50u;
    if(m->s.slot.have_status) {
        p25_trunking_slot_observation lost={0};
        CHECK(!p25_trunking_backend_observe(&m->b,&m->s,&lost,m->now));
    }
    observed(m,m->origin,3u);for(unsigned i=1;i<5u;++i)observed(m,m->origin+i*360u,2u);
    observed(m,m->origin+1800u,3u);
    m->clock=(p25_trunking_session_clock){.now_tick=m->origin+2800u,.stream_epoch=m->epoch,.lane_epoch=22u};
}
static void poll(model *m,bool down,bool permission) {
    p25_trunking_backend_poll(&m->b,&m->s,m->now,&m->clock,permission,down);
}
static bool take(model *m,p25_trunking_backend_action *out) {
    return p25_trunking_backend_take(&m->b,&m->s,out,m->now,&m->clock);
}
static p25_trunking_backend_action request(model *m,p25_trunking_access_action_type expected,bool down) {
    anchor(m);poll(m,down,true);p25_trunking_backend_action a;
    CHECK(take(m,&a)&&a.session.access.type==expected&&a.experimental_nominal);
    CHECK(a.session.valid_bits==316u&&a.session.wire_bytes==45u&&a.session.budget.observed.boundary_tick==m->b.anchor_tick);
    CHECK(!m->s.clock_qualified&&!m->s.start_edge_qualified&&!m->s.access.idle&&m->s.access.experimental_opportunity);
    CHECK(!m->clock.origin_qualified&&!m->clock.rate_qualified&&!m->clock.start_edge_qualified);
    CHECK(!memcmp(a.native_ram,a.session.tsdu,39u)&&(a.native_ram[39]&0xf0u)==(a.session.tsdu[39]&0xf0u));
    CHECK(!(a.native_ram[39]&15u));for(unsigned i=40;i<72u;++i)CHECK(a.native_ram[i]==0u);
    uint32_t hash=2166136261u;for(unsigned i=0;i<72u;++i)hash=(hash^a.native_ram[i])*16777619u;
    CHECK(hash==a.image_hash);
    p25_trunking_backend_action unchanged;memset(&unchanged,0xa5,sizeof unchanged);
    p25_trunking_backend_action before=unchanged;CHECK(!take(m,&unchanged)&&!memcmp(&unchanged,&before,sizeof before));
    return a;
}
static void sent(model *m,const p25_trunking_backend_action *a) {
    uint32_t id=a->session.access.id;
    CHECK(!p25_trunking_backend_suspend(&m->b,&m->s,id+1u));
    CHECK(p25_trunking_backend_suspend(&m->b,&m->s,id)&&m->b.suspended);
    CHECK(!p25_trunking_backend_result(&m->b,&m->s,id,true,false,true,m->epoch+1u,m->now+40u));
    CHECK(!p25_trunking_backend_result(&m->b,&m->s,id,true,true,true,m->epoch,m->now+40u));
    CHECK(!p25_trunking_backend_result(&m->b,&m->s,id+1u,true,true,true,m->epoch+1u,m->now+40u));
    m->now+=40u;++m->epoch;
    CHECK(p25_trunking_backend_result(&m->b,&m->s,id,true,true,true,m->epoch,m->now));
    CHECK(!m->b.inflight&&!m->b.suspended);
}
static void attached(model *m) {
    start(m,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL);
    p25_trunking_backend_action a=request(m,P25_TRUNK_ACTION_REGISTER,false);
    CHECK(!receive(m,incoming[3],m->epoch)); // before RF-off + new RX
    sent(m,&a);CHECK(!m->s.access.registered);
    CHECK(!receive(m,incoming[3],m->epoch-1u));CHECK(receive(m,incoming[3],m->epoch));
    CHECK(m->s.access.registered&&!m->s.access.affiliated);
    a=request(m,P25_TRUNK_ACTION_AFFILIATE,false);sent(m,&a);
    CHECK(!receive(m,incoming[4],m->epoch-1u));CHECK(receive(m,incoming[4],m->epoch));
    CHECK(m->s.access.phase==P25_TRUNK_ACCESS_READY&&m->s.access.affiliated&&m->s.access.registered);
}
static p25_trunking_backend_action grant(model *m) {
    poll(m,false,true);poll(m,true,true);CHECK(m->s.access.phase==P25_TRUNK_ACCESS_REQUEST);
    p25_trunking_backend_action a=request(m,P25_TRUNK_ACTION_GROUP_REQUEST,true);sent(m,&a);
    CHECK(!receive(m,incoming[5],m->epoch-1u));CHECK(receive(m,incoming[5],m->epoch));
    CHECK(m->s.access.phase==P25_TRUNK_ACCESS_GRANTED);
    m->clock.stream_epoch=m->epoch;poll(m,true,true);CHECK(take(m,&a));
    CHECK(a.session.access.type==P25_TRUNK_ACTION_VOICE_START&&a.session.access.channel==0x1001u
        &&a.session.access.options==4u&&a.session.access.rx_hz==440087500u&&a.session.access.tx_hz==445087500u
        &&!a.session.wire_bytes&&!a.image_hash);return a;
}
static void lifecycle(const char *output) {
    FILE *out=fopen(output,"wb");CHECK(out);model m;start(&m,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL);
    p25_trunking_backend_action a=request(&m,P25_TRUNK_ACTION_REGISTER,false);
    CHECK(fwrite(a.session.tsdu,1,45u,out)==45u);sent(&m,&a);CHECK(receive(&m,incoming[3],m.epoch));
    a=request(&m,P25_TRUNK_ACTION_AFFILIATE,false);
    CHECK(fwrite(a.session.tsdu,1,45u,out)==45u);sent(&m,&a);CHECK(receive(&m,incoming[4],m.epoch));
    poll(&m,false,true);poll(&m,true,true);a=request(&m,P25_TRUNK_ACTION_GROUP_REQUEST,true);
    CHECK(fwrite(a.session.tsdu,1,45u,out)==45u);sent(&m,&a);CHECK(receive(&m,incoming[5],m.epoch));
    m.clock.stream_epoch=m.epoch;poll(&m,true,true);CHECK(take(&m,&a));
    CHECK(a.session.access.type==P25_TRUNK_ACTION_VOICE_START);
    CHECK(p25_trunking_backend_suspend(&m.b,&m.s,a.session.access.id));
    CHECK(p25_trunking_backend_result(&m.b,&m.s,a.session.access.id,true,false,false,m.epoch,++m.now));
    CHECK(m.s.access.voice_running);
    poll(&m,false,true);CHECK(take(&m,&a)&&a.session.access.type==P25_TRUNK_ACTION_VOICE_STOP);
    uint32_t stop_id=a.session.access.id;
    CHECK(p25_trunking_backend_result(&m.b,&m.s,stop_id,true,true,false,m.epoch,++m.now));
    poll(&m,false,true);CHECK(take(&m,&a)&&a.session.access.type==P25_TRUNK_ACTION_RETURN_CONTROL);
    CHECK(p25_trunking_backend_suspend(&m.b,&m.s,a.session.access.id));
    CHECK(p25_trunking_backend_result(&m.b,&m.s,a.session.access.id,true,true,true,++m.epoch,++m.now));
    CHECK(!m.b.suspended&&m.s.access.registered&&m.s.access.affiliated);
    m.clock.stream_epoch=m.epoch;site(&m);poll(&m,false,true);CHECK(m.s.access.phase==P25_TRUNK_ACCESS_READY);
    CHECK(p25_trunking_backend_deregister(&m.b,&m.s,m.now));
    a=request(&m,P25_TRUNK_ACTION_DEREGISTER,false);CHECK(fwrite(a.session.tsdu,1,45u,out)==45u);
    sent(&m,&a);CHECK(!m.b.running&&!m.s.running&&!m.s.access.registered&&!m.s.access.affiliated);
    CHECK(fclose(out)==0);
}
static void refusals(void) {
    model m;p25_trunking_backend_action a,old;
    start(&m,P25_TRUNK_BACKEND_QUALIFIED);anchor(&m);poll(&m,false,true);
    CHECK(!take(&m,&a)&&m.s.access.phase==P25_TRUNK_ACCESS_WAIT_SITE&&!m.s.clock_qualified);
    start(&m,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL);poll(&m,false,true);CHECK(!take(&m,&a));
    anchor(&m);poll(&m,false,true);
    CHECK(!p25_trunking_session_take(&m.s,&a.session,m.now,&m.clock)); // strict API cannot spend nominal job
    poll(&m,false,true);CHECK(take(&m,&a));
    CHECK(!p25_trunking_backend_stop(&m.b,&m.s,false)&&m.b.running&&m.b.inflight);
    uint32_t old_id=a.session.access.id;CHECK(p25_trunking_backend_stop(&m.b,&m.s,true));
    p25_trunking_session_config c=config();CHECK(p25_trunking_backend_start(&m.b,&m.s,&c,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL,m.now));
    CHECK(!p25_trunking_backend_result(&m.b,&m.s,old_id,true,true,true,99u,m.now));
    for(unsigned fault=0;fault<7u;++fault) {
        start(&m,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL);anchor(&m);
        if(fault==0u)m.now+=49u;
        if(fault==1u)m.clock.now_tick=m.b.anchor_tick+2305u;
        if(fault==2u)++m.clock.stream_epoch;
        if(fault==3u)++m.clock.lane_epoch;
        if(fault==4u) {
            p25_trunking_slot_observation busy={.sample_tick=m.origin+2160u,.stream_epoch=m.epoch,.lane_epoch=22u,
                .status=1,.selected=true,.qualified=true};CHECK(p25_trunking_backend_observe(&m.b,&m.s,&busy,m.now));
        }
        if(fault==5u)p25_trunking_backend_lost(&m.b,&m.s,m.now);
        if(fault==6u)poll(&m,false,false);else poll(&m,false,true);
        memset(&a,0xa5,sizeof a);old=a;CHECK(!take(&m,&a)&&!memcmp(&a,&old,sizeof a));
    }
    // Unrequested authentication is still conservative RX-only, not hidden by
    // the transaction's response-epoch filter before registration begins.
    start(&m,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL);uint8_t auth[12]={0xaa,0};
    uint32_t rid=1234567u;auth[4]=(uint8_t)(rid>>16);auth[5]=(uint8_t)(rid>>8);auth[6]=(uint8_t)rid;
    uint16_t crc=p25_data_crc16(auth,10u);auth[10]=(uint8_t)(crc>>8);auth[11]=(uint8_t)crc;
    CHECK(receive(&m,auth,m.epoch));CHECK(m.s.access.reason==P25_TRUNK_ACCESS_AUTH);
}
static void voice_safety(void) {
    for(unsigned fault=0;fault<5u;++fault) {
        model m;attached(&m);p25_trunking_backend_action a=grant(&m);
        uint32_t old_id=a.session.access.id;
        if(fault==0u) {poll(&m,false,true);}
        if(fault==1u) {poll(&m,true,false);}
        if(fault==2u) {m.now+=1500u;poll(&m,true,true);}
        if(fault==3u) {p25_trunking_backend_cancel(&m.b,&m.s,P25_TRUNK_ACCESS_PERMISSION,m.now);poll(&m,true,false);}
        if(fault==4u) {
            CHECK(p25_trunking_backend_result(&m.b,&m.s,old_id,true,false,false,m.epoch,++m.now));
            m.now+=1000u;poll(&m,true,true);
        }
        CHECK(!p25_trunking_backend_result(&m.b,&m.s,old_id,true,false,false,m.epoch,m.now));
        CHECK(take(&m,&a)&&a.session.access.type==P25_TRUNK_ACTION_VOICE_STOP&&a.session.access.id!=old_id);
        CHECK(p25_trunking_backend_result(&m.b,&m.s,a.session.access.id,false,false,false,m.epoch,++m.now));
        CHECK(m.b.inflight&&m.s.access.voice_running); // failed kill is not RF-off proof
        CHECK(!p25_trunking_backend_stop(&m.b,&m.s,false));CHECK(p25_trunking_backend_stop(&m.b,&m.s,true));
        CHECK(!m.b.running&&!m.s.running);
    }
}
static void incoming_receive(void) {
    model m;attached(&m);poll(&m,false,true);uint32_t site_ms=m.s.access.site_ms;
    CHECK(p25_trunking_backend_receive_suspend(&m.b,&m.s));
    CHECK(m.b.receive_suspended&&m.b.suspended&&m.s.access.registered&&m.s.access.affiliated);
    m.now+=5000u;poll(&m,true,true);p25_trunking_backend_action a;
    CHECK(!take(&m,&a)&&m.s.access.registered&&m.s.access.affiliated&&m.s.access.site_ms==site_ms);
    CHECK(!p25_trunking_backend_receive_resume(&m.b,&m.s,m.b.receive_epoch,m.now));
    CHECK(p25_trunking_backend_receive_resume(&m.b,&m.s,++m.epoch,m.now));
    CHECK(m.b.reacquiring&&!m.b.suspended&&!m.s.have_site&&!m.s.have_network
        &&m.s.access.site_ms==site_ms);
    m.clock.stream_epoch=m.epoch;poll(&m,true,true);CHECK(!take(&m,&a));
    CHECK(receive(&m,incoming[0],m.epoch));CHECK(receive(&m,incoming[1],m.epoch));
    CHECK(m.b.reacquiring&&!take(&m,&a));CHECK(receive(&m,incoming[2],m.epoch));
    CHECK(!m.b.reacquiring&&m.s.access.registered&&m.s.access.affiliated&&m.s.access.site_ms==m.now);
    poll(&m,true,true);CHECK(m.s.access.phase==P25_TRUNK_ACCESS_READY&&!take(&m,&a));
    poll(&m,false,true);poll(&m,true,true);CHECK(m.s.access.phase==P25_TRUNK_ACCESS_REQUEST);
    CHECK(!p25_trunking_backend_receive_suspend(&m.b,&m.s));
    attached(&m);poll(&m,false,true);CHECK(p25_trunking_backend_receive_suspend(&m.b,&m.s));
    CHECK(p25_trunking_backend_receive_resume(&m.b,&m.s,++m.epoch,m.now));
    m.now+=P25_TRUNK_ACCESS_SITE_MS;poll(&m,false,true);
    CHECK(m.s.access.phase==P25_TRUNK_ACCESS_FAILED&&m.s.access.reason==P25_TRUNK_ACCESS_SITE_LOST
        &&!m.s.access.registered&&!m.s.access.affiliated&&!take(&m,&a));
}
static void retries(void) {
    model m;start(&m,P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL);
    for(unsigned attempt=1u;attempt<=3u;++attempt) {
        p25_trunking_backend_action a=request(&m,P25_TRUNK_ACTION_REGISTER,false);
        CHECK(m.s.access.attempts==attempt);sent(&m,&a);
        m.now+=P25_TRUNK_ACCESS_RESPONSE_MS;site(&m);poll(&m,false,true);
        if(attempt<3u) {
            CHECK(m.s.access.phase==P25_TRUNK_ACCESS_REGISTER);
            m.now=m.s.access.retry_ms;
        } else CHECK(m.s.access.phase==P25_TRUNK_ACCESS_FAILED&&m.s.access.reason==P25_TRUNK_ACCESS_TIMEOUT);
    }
}
int main(int argc,char **argv) {
    CHECK(argc==3);FILE *in=fopen(argv[1],"rb");CHECK(in);
    for(unsigned i=0;i<6u;++i) {
        uint8_t wire[45];p25_tsdu unit;CHECK(fread(wire,1,45u,in)==45u);
        CHECK(p25_tsdu_decode(wire,45u,&unit)&&unit.nac==0x293&&unit.count==1u);
        memcpy(incoming[i],unit.block[0],12u);
    }
    CHECK(fgetc(in)==EOF&&fclose(in)==0);lifecycle(argv[2]);refusals();voice_safety();incoming_receive();retries();
    printf("Subscriber backend: PASS (%u checks; state=%u action=%u bytes)\n",checks,
        (unsigned)sizeof(p25_trunking_backend),(unsigned)sizeof(p25_trunking_backend_action));return 0;
}
