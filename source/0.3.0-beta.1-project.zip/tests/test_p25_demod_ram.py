"""Exact object-section placement and linked startup-copy evidence, no hardware."""
import importlib.util
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT/path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


placer = module('p25_hot_placer', 'scripts/place-p25-demod-ram.py')
audit = module('p25_hot_audit', 'scripts/analyze-imbe-build.py')


def make_elf(rows, relocatable=True):
    """Small independent ELF fixture: name,payload,flags,kind,address."""
    raw = bytearray(128); raw[:7] = b'\x7fELF\x01\x01\x01'
    struct.pack_into('<HHI', raw, 16, 1 if relocatable else 2, 252, 1)
    struct.pack_into('<H', raw, 40, 52)
    names = bytearray(b'\0'); headers = [(0,)*10]
    for name, payload, flags, kind, address in rows:
        name_offset = len(names); names += name.encode()+b'\0'
        begin = len(raw); raw += payload
        headers.append((name_offset, kind, flags, address, begin, len(payload), 0, 0, 4, 0))
    name_offset = len(names); names += b'.shstrtab\0'
    begin = len(raw); raw += names
    headers.append((name_offset, 3, 0, 0, begin, len(names), 0, 0, 1, 0))
    while len(raw) % 4: raw += b'\0'
    offset = len(raw)
    for header in headers: raw += struct.pack('<10I', *header)
    struct.pack_into('<I', raw, 32, offset)
    struct.pack_into('<HHH', raw, 46, 40, len(headers), len(headers)-1)
    return bytes(raw)


def object_rows():
    return [(name, bytes([index+1])*(4+index*4), 6 if name.startswith('.text') else 2, 1, 0)
            for index, name in enumerate(placer.SECTIONS)] + [
                ('.text.keep', b'KEEP', 6, 1, 0), ('.rodata.keep', b'DATA', 2, 1, 0),
                ('.bss.keep', bytes(8), 3, 8, 0)]


def linked_fixture():
    payload = bytes(range(64)); address = 0x12000
    elf = bytearray(make_elf([('.ramfunc', payload, 6, 1, address)], False))
    struct.pack_into('<I', elf, 28, 52)
    struct.pack_into('<HH', elf, 42, 32, 1)
    struct.pack_into('<8I', elf, 52, 1, 128, address, 0x0300c080, 64, 64, 5, 4)
    rows = ''.join(f' {placer.PREFIX+name}\n 0x{address+i*8:08x} 0x8 build/live/imbe/demod.o\n'
                   for i, name in enumerate(placer.SECTIONS))
    return bytes(elf), 'Linker script and memory map\n'+rows, bytes(128)+payload


class PlacementTests(unittest.TestCase):
    def execute(self, rows=None, mutation=None, failure=False):
        rows = object_rows() if rows is None else rows
        original = make_elf(rows)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'demod.o'; path.write_bytes(original)
            def objcopy(command, **kwargs):
                self.assertTrue(kwargs['check']); self.assertEqual(kwargs['timeout'], 120)
                expected = [pair for name in placer.SECTIONS
                            for pair in ('--rename-section', name+'='+placer.PREFIX+name)]
                self.assertEqual(command[1:-2], expected)
                self.assertEqual(Path(command[-2]), path)
                if failure: raise subprocess.CalledProcessError(1, command)
                moved = [(placer.PREFIX+name if name in placer.SECTIONS else name, data, flags, kind, address)
                         for name, data, flags, kind, address in rows]
                if mutation: moved = mutation(moved)
                Path(command[-1]).write_bytes(make_elf(moved))
            with patch.object(placer.subprocess, 'run', side_effect=objcopy):
                try:
                    total = placer.place('target-objcopy', path)
                except Exception:
                    self.assertEqual(path.read_bytes(), original)
                    raise
            return total, placer.allocated_sections(path.read_bytes())

    def test_only_four_named_sections_move_with_identical_content_and_flags(self):
        total, moved = self.execute()
        self.assertEqual(total, 40)
        for name, data, flags, kind, address in object_rows():
            target = placer.PREFIX+name if name in placer.SECTIONS else name
            self.assertEqual(moved[target], (kind, flags, address, len(data), data if kind != 8 else None))

    def test_missing_empty_wrong_flags_and_duplicate_targets_refuse_before_objcopy(self):
        rows = object_rows()
        invalid = [rows[:index]+rows[index+1:] for index in range(4)]
        invalid += [rows+[rows[0]], [(rows[0][0], b'', *rows[0][2:])]+rows[1:],
                    [(rows[0][0], rows[0][1], 2, 1, 0)]+rows[1:],
                    [(placer.PREFIX+rows[0][0], *rows[0][1:])]+rows[1:]]
        for case in invalid:
            with self.subTest(case=case), patch.object(placer.subprocess, 'run') as run:
                with self.assertRaises(ValueError): placer.selection(make_elf(case))
                run.assert_not_called()

    def test_foreign_truncated_and_invalid_section_tables_refused(self):
        good = make_elf(object_rows())
        cases = [b'', good[:51], good[:150], good[:16]+b'\x02\0'+good[18:]]
        for offset, value, fmt in ((18, 62, '<H'), (46, 39, '<H'), (50, 65535, '<H'), (32, 0xfffffff0, '<I')):
            changed = bytearray(good); struct.pack_into(fmt, changed, offset, value); cases.append(bytes(changed))
        for data in cases:
            with self.subTest(size=len(data)), self.assertRaises(ValueError): placer.selection(data)

    def test_unexpected_copy_changes_do_not_replace_original(self):
        def alter_keep(rows):
            return [(name, b'EVIL' if name == '.text.keep' else data, flags, kind, address)
                    for name, data, flags, kind, address in rows]
        mutations = [alter_keep, lambda rows: rows[:-1],
                     lambda rows: rows+[(placer.PREFIX+'.text.extra', b'EXTRA', 6, 1, 0)]]
        for mutation in mutations:
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, 'exact P25 hot allowlist'):
                self.execute(mutation=mutation)
        with self.assertRaises(subprocess.CalledProcessError): self.execute(failure=True)


class LinkedEvidenceTests(unittest.TestCase):
    def test_historical_artifact_without_prefix_still_supported(self):
        self.assertEqual(audit.demod_hot_placement(b'', 'Linker script and memory map\n', b''), {'enabled': False})

    def test_all_four_sections_require_executable_ram_and_matching_flash_load_bytes(self):
        elf, linked, raw = linked_fixture()
        result = audit.demod_hot_placement(elf, linked, raw)
        self.assertEqual(result['total_bytes'], 32)
        self.assertTrue(result['startup_copy_bytes_verified'])
        self.assertFalse(result['hardware_performance_measured'])
        self.assertEqual(result['sections'][0]['address'], '0x12000')
        self.assertEqual(result['sections'][0]['load_address'], '0x300c080')

    def test_partial_extra_wrong_owner_flash_and_unmoved_sections_refused(self):
        elf, linked, raw = linked_fixture()
        cases = [linked.replace(placer.PREFIX+'.text.push', '.other.push'),
                 linked+f' {placer.PREFIX}.text.extra\n 0x00012020 0x8 build/live/imbe/demod.o\n',
                 linked.replace('/imbe/demod.o', '/imbe/foreign.o', 1),
                 linked.replace('0x00012000', '0x03012000'),
                 linked.replace('0x00012008', '0x00012004'),
                 'Linker script and memory map\n '+placer.PREFIX+'.text.push corrupt\n',
                 linked+' .text.push\n 0x03020000 0x8 build/live/imbe/demod.o\n']
        for text in cases:
            with self.subTest(text=text), self.assertRaises(ValueError): audit.demod_hot_placement(elf, text, raw)

    def test_copy_data_and_elf_execution_and_load_evidence_are_required(self):
        elf, linked, raw = linked_fixture()
        with self.assertRaisesRegex(ValueError, 'startup bytes'): audit.demod_hot_placement(elf, linked, bytes(len(raw)))
        headers = struct.unpack_from('<I', elf, 32)[0]
        for offset, value, fmt in ((headers+40+8, 2, '<I'), (42, 0, '<H'), (28, 0xfffffff0, '<I')):
            changed = bytearray(elf); struct.pack_into(fmt, changed, offset, value)
            with self.assertRaises(ValueError): audit.demod_hot_placement(bytes(changed), linked, raw)


if __name__ == '__main__': unittest.main(verbosity=2)
