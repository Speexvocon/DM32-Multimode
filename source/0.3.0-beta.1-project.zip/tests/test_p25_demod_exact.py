# SPDX-License-Identifier: GPL-3.0-or-later
"""Byte/state/timestamp differential tests against frozen7d38b96 and744de01.

The frozen reference is SHA-pinned and remains available in shallow checkouts.
Host elapsed comparisons rank changes only; they do not qualify target timing.
"""
from pathlib import Path
import argparse
import ast
import ctypes as C
import hashlib
import importlib.util
import json
import math
import subprocess
import sys
import time
import numpy as np

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--benchmark',action='store_true',help='Optional host-only elapsed ranking; never target qualification')
options=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-demod-exact'
BUILD.mkdir(parents=True,exist_ok=True)
PINS={'7d38b96':{'p25_demod.c':'4ac5595f9a8952818a9876485d0f7349dc95b070f0df3c02ddc2b280771f9c3c',
                 'p25_demod_math.h':'ae4a10e7670fcfae3e69df017592771646d3f056226512e96954962c4a9e544c'},
      '744de01':{'p25_demod.c':'be906a93f55916764735a99825e0f842ec8aa15a4f66607af84a2cca57bcd3ab',
                 'p25_demod_math.h':'ed9d16c44624f5ea327f1b99c457a1ba92d584099ace5a54fa995b1edd0b9ba9'}}
for version,pins in PINS.items():
    folder=BUILD/version;folder.mkdir(exist_ok=True)
    for name,expected in pins.items():
        data=(ROOT/f'tests/fixtures/p25-demod-{version}'/name).read_bytes().replace(b'\r\n',b'\n')
        assert hashlib.sha256(data).hexdigest()==expected,(version,name,'frozen baseline changed')
        (folder/name).write_bytes(data)
for name,expected in (
    # Optional per-push observation API only; struct/state layout is unchanged.
    ('p25_demod.h','196bc94d8b3b12fe027e4aabfa28f0353839d6b1947b31a0af3860d676578553'),
    ('p25_demod_filter.h','a132770818172623a9825dc0cd0f71ff964dc18c2f451fd35b511738b12daf1f')):
    data=(ROOT/'src/firmware'/name).read_bytes().replace(b'\r\n',b'\n')
    assert hashlib.sha256(data).hexdigest()==expected,(name,'shared baseline ABI/FIR changed')
WRAPPER='''#define p25_demod_init p25_baseline_init
#define p25_demod_gap p25_baseline_gap
#define p25_demod_push p25_baseline_push
#define p25_demod_push_at p25_baseline_push_at
#include "p25_demod.c"
bool p25_baseline_acquire(p25_demod_lane *l) {return acquire(l);}
int32_t p25_baseline_timing_error(int32_t d,int32_t g) {return p25_timing_error(d,g);}
int32_t p25_baseline_interpolate(int16_t a,int16_t b,uint32_t back) {return p25_interpolate(a,b,back);}
'''
FLAGS=['gcc','-std=c11','-O3','-Wall','-Wextra','-Werror','-Wshadow','-shared']
if sys.platform!='win32':FLAGS+=['-fPIC']
extension='.dll' if sys.platform=='win32' else '.so'
libraries=[];commands=[];comparison_counts=[]
for version in PINS:
    wrapper=BUILD/version/'baseline-wrapper.c';wrapper.write_text(WRAPPER,encoding='utf-8',newline='\n')
    library=BUILD/('exact-'+version+extension)
    command=FLAGS+['-Isrc/firmware','tests/test_p25_demod_exact.c',str(wrapper),
                   'src/firmware/p25_rx.c','src/firmware/p25_tsdu.c','-o',str(library)]
    subprocess.run(command,cwd=ROOT,check=True,timeout=120);commands.append(command)
    lib=C.CDLL(str(library));libraries.append(lib)
    lib.p25_exact_arithmetic.restype=C.c_uint
    lib.p25_exact_run.argtypes=[C.POINTER(C.c_int16),C.c_uint,C.c_uint64,C.c_uint,C.c_uint]
    lib.p25_exact_run.restype=C.c_uint
    lib.p25_exact_benchmark.argtypes=[C.POINTER(C.c_int16),C.c_uint,C.c_uint,C.c_uint]
    lib.p25_exact_benchmark.restype=C.c_double
    comparison_counts.append(lib.p25_exact_arithmetic())
assert len(set(comparison_counts))==1
comparisons=comparison_counts[0];command=commands[0]
trapped_library=BUILD/('exact-trapv.dll' if sys.platform=='win32' else 'exact-trapv.so')
trapped_command=command[:2]+['-ftrapv','-static-libgcc']+command[2:-1]+[str(trapped_library)]
subprocess.run(trapped_command,cwd=ROOT,check=True,timeout=120)
trapped=C.CDLL(str(trapped_library));trapped.p25_exact_arithmetic.restype=C.c_uint
assert trapped.p25_exact_arithmetic()==comparisons

spec=importlib.util.spec_from_file_location('exact_fixture',ROOT/'scripts/generate-p25-trunking-fixture.py')
generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
reference=generator.load_reference(ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py')
mod=ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/op25_c4fm_mod.py'
data=mod.read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(data).hexdigest()=='b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef'
nodes=[n for n in ast.parse(data).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))
       and n.name in {'transfer_function_tx','c4fm_taps'}]
scope=dict(np=np,pi=math.pi,sin=math.sin,cos=math.cos,_def_symbol_rate=4800,
           _def_output_sample_rate=48000,_def_span=13)
exec(compile(ast.Module(body=nodes,type_ignores=[]),'pinned-op25-c4fm','exec'),scope)
taps=scope['c4fm_taps']().generate()
frames=[generator.encode_tsdu(reference,0x293,[(0x3b,0x000abcde12300001)]*n)[0] for n in (1,2,3)]
def waveform(wire,phase=0,polarity=1,ppm=0,gain=1.,dc=0):
    dibits=np.array([(v>>shift)&3 for v in b'\x77'*72+wire for shift in (6,4,2,0)])
    impulses=np.zeros(len(dibits)*10);impulses[::10]=np.array([1,3,-1,-3])[dibits]
    shaped=np.convolve(impulses,taps)*60000*polarity*gain
    positions=np.arange(phase,len(shaped)-1,6*(1+ppm/1000000))
    pcm=np.clip(np.rint(np.interp(positions,np.arange(len(shaped)),shaped)+dc),-32768,32767).astype('<i2')
    return np.concatenate((pcm,np.zeros(64,dtype='<i2')))
cases=samples=decoded=0
def check(pcm,modes=(0,1),origin=1000000):
    global cases,samples,decoded
    pcm=np.ascontiguousarray(pcm,dtype='<i2')
    for mode in modes:
        counts=[library.p25_exact_run(pcm.ctypes.data_as(C.POINTER(C.c_int16)),len(pcm),origin,mode,0xfffffff0)
                for library in libraries]
        assert len(set(counts))==1
        decoded+=counts[0]
        cases+=1;samples+=len(pcm)

clean=frames[0]*12
for phase in range(6):
    for polarity in (1,-1):check(waveform(clean,phase,polarity))
mixed=b''.join(frames*4)
pcm=waveform(mixed)
check(pcm,modes=range(11))
check(pcm,modes=(1,2,3,4,5,6,7,8,9,10),origin=(1<<64)-6000)
# Correctable trellis bit, uncorrectable NID and corrupt block payload. Baseline
# comparison covers rejected lanes, not just emitted good units.
for offset,mask in ((20,1),(6,0xff),(16,0xff)):
    bad=bytearray(frames[0]);bad[offset]^=mask
    check(waveform(frames[0]*4+bad+frames[0]*4),modes=(0,1,9,10))
for ppm in (-1900,-750,750,1900):
    check(waveform(clean,ppm=ppm),modes=(0,1))
for gain,dc in ((.04,0),(.2,-9000),(.6,14000),(1.8,0),(4.,10000)):
    check(waveform(clean,gain=gain,dc=dc),modes=(0,1))
# Independent pinned voice/control bytes exercise conventional arbitration too.
voice=(ROOT/'fixtures/p25-1011/call.bin').read_bytes()
check(waveform(voice),modes=(0,1,9,10))
# Silence/rearm, full-scale rails, impulses, quantization edges and deterministic
# full-range noise cover every ring index and idle-reacquisition boundary.
random=np.random.default_rng(777)
for values in (np.zeros(10000),np.full(10000,-32768),np.full(10000,32767),
               np.tile([-32768,32767],5000),np.tile([-17,-16,-15,-1,0,1,15,16,17],1200),
               random.integers(-32768,32768,20000)):
    check(values,modes=(0,1,4,8,9,10))
check(np.concatenate((pcm,np.zeros(8000),pcm*-1)),modes=(0,1,9,10))

# Count only the executed wide-square boundary in generated test-only source
# copies. Production gets no hook, timer, field, counter or instrumented code.
COUNTER='''
static void counter_frame(const p25_rx *frame,void *context) {(void)frame;(void)context;}
static void counter_status(const p25_demod_status *event,void *context) {(void)event;(void)context;}
void p25_exact_wide_count(const int16_t *samples,unsigned count,uint32_t output[4]) {
    p25_demod d;p25_demod_init(&d);test_wide_count=0;
    for(unsigned i=0;i<count;++i)(void)p25_demod_push_at(&d,samples[i],(uint64_t)i*6u,1u,
        counter_frame,counter_status,NULL);
    output[0]=d.sync_tests;output[1]=test_wide_count;output[2]=d.acquisitions;output[3]=d.frames;
}
'''
control=waveform(frames[0]*16);wide_counts={}
for version,folder in (('744de01',BUILD/'744de01'),('current',ROOT/'src/firmware')):
    destination=BUILD/('count-'+version);destination.mkdir(exist_ok=True)
    for header in ('p25_demod_math.h',):
        (destination/header).write_bytes((folder/header).read_bytes().replace(b'\r\n',b'\n'))
    source=(folder/'p25_demod.c').read_text();anchor='int64_t square=(int64_t)z*z;'
    assert source.count(anchor)==1
    (destination/'count.c').write_text('static unsigned test_wide_count;\n'+
        source.replace(anchor,'++test_wide_count;'+anchor)+COUNTER,encoding='utf-8',newline='\n')
    binary=destination/('counter'+extension)
    subprocess.run(FLAGS+['-Isrc/firmware',str(destination/'count.c'),
        'src/firmware/p25_rx.c','src/firmware/p25_tsdu.c','-o',str(binary)],cwd=ROOT,check=True,timeout=120)
    counter=C.CDLL(str(binary));counter.p25_exact_wide_count.argtypes=[C.POINTER(C.c_int16),C.c_uint,C.POINTER(C.c_uint32)]
    counter.p25_exact_wide_count.restype=None
    output=(C.c_uint32*4)()
    counter.p25_exact_wide_count(control.ctypes.data_as(C.POINTER(C.c_int16)),len(control),output)
    wide_counts[version]=dict(zip(('sync_tests','wide_squares','acquisitions','frames'),output))
old,new=wide_counts['744de01'],wide_counts['current']
assert all(old[key]==new[key] for key in ('sync_tests','acquisitions','frames'))
assert 0<new['wide_squares']<old['wide_squares']<=old['sync_tests']
coverage={'fixture':'pinned OP25 C4FM sixteen one-block TSDUs; no RF samples',
          'pcm_sha256':hashlib.sha256(control.tobytes()).hexdigest(),'samples':len(control),
          'counts':wide_counts,'wide_squares_bypassed':old['wide_squares']-new['wide_squares'],
          'bypassed_fraction':1-new['wide_squares']/old['wide_squares']}

# Alternate execution order, same fixture/callbacks/compiler. This is explicitly
# host elapsed ranking, never target CPU/air/sample-clock qualification.
bench=waveform(clean);timings=[]
if options.benchmark:
    for index in range(6):
        for baseline in ((0,1) if index%2 else (1,0)):
            cpu_begin=time.process_time()
            elapsed=lib.p25_exact_benchmark(bench.ctypes.data_as(C.POINTER(C.c_int16)),len(bench),200,baseline)
            cpu_elapsed=time.process_time()-cpu_begin
            timings.append({'baseline':bool(baseline),'clock_elapsed_seconds':elapsed,
                            'host_process_cpu_seconds':cpu_elapsed})
report={'baselines':list(PINS),'arithmetic_comparisons_per_reference':comparisons,
        'cases':cases,'reference_case_comparisons':cases*len(libraries),'samples':samples,
        'reference_sample_comparisons':samples*len(libraries),'coarse_rejection_coverage':coverage,
        'decoded_frames_compared':decoded,'all_state_frame_timestamp_bytes_equal':True,
        'arithmetic_overflow_trap_passed':True,
        'host_benchmark_reference':'744de01' if options.benchmark else None,
        'host_elapsed_rank_only':timings,'target_cpu_timing_qualified':False}
(BUILD/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
