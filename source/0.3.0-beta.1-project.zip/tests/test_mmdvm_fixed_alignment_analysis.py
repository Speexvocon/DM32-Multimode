"""Offline fixed-call association, measured reference errors and evidence checks."""
from contextlib import redirect_stdout, redirect_stderr
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("fixed_alignment_analysis", ROOT / "research/examples/mmdvm_fixed_alignment_analysis.py")
analysis = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(analysis)


class FixedAlignmentAnalysis(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.storage = tempfile.TemporaryDirectory()
        cls.base = Path(cls.storage.name)
        cls.references = {}
        for extra in (0, 1, 21):
            folder = cls.base / f"refs{extra}"
            analysis.fixed_export.export(folder, pairs=14, startup_extra=extra)
            cls.references[extra] = folder

    @classmethod
    def tearDownClass(cls):
        cls.storage.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)

    def fixture(self, specs=None, *, extra=0, tdu=True, orphan=False, start=True, end=True,
                future_endpoints=False):
        """Each spec: host kind, changed RF bits, optional raw DUID override,
        optional number of host events; changes are synthetic protected errors.
        """
        refs = {n: (self.references[extra] / f"ldu{n}.bin").read_bytes() for n in (1, 2)}
        transport = (self.references[extra] / "transport.bin").read_bytes()
        specs = specs if specs is not None else [(1 if i % 2 == 0 else 2, []) for i in range(28)]
        lines, rows = [], []
        def log(body):
            lines.append("D: 2026-11-03 04:00:00.000 " + body)
        if orphan:
            log("P25, LDU1 audio, errs: 0/1233 (0.0%)")
        if start:
            log("P25, received RF voice transmission from N0CALL to TG 10")
        def dump(raw, count, kind, event_count=1):
            log("RX P25 LDU")
            serial = bytes((0xE0, 220, 0x31, 1)) + raw
            for offset in range(0, len(serial), 16):
                log(f"{offset:04X}: " + " ".join(f"{b:02X}" for b in serial[offset:offset + 16]))
            phase = (339 + extra) % 36
            positions = count if isinstance(count, list) else []
            corrected = len(positions)
            rows.append({"schema": "mmdvm-p25-ldu-fec-v1", "index": len(rows), "ldu_bytes": 216,
                         "protected_bits": 1233, "startup_extra_bytes": extra,
                         "assumed_ldu_start_byte_mod36": phase, "transport_block_bytes": 36,
                         "raw_nac_hex_unvalidated": f"{(raw[6] << 4) | (raw[7] >> 4):03X}",
                         "raw_duid_unvalidated": raw[7] & 15, "corrections": corrected,
                         "voice_corrections": [corrected] + [0] * 8,
                         "regenerated_rf_changed_bit_count": corrected,
                         "regenerated_rf_changed_bit_positions_msb0": positions,
                         "changed_transport_byte_mod36_assumed": [(phase + b // 8) % 36 for b in positions]})
            for _ in range(event_count):
                log(f"P25, LDU{kind} audio, errs: {corrected}/1233 (0.0%)")
        for index, spec in enumerate(specs):
            kind, positions, *options = spec
            raw = bytearray(refs[kind])
            for bit in positions:
                raw[bit // 8] ^= 0x80 >> (bit % 8)
            if future_endpoints:
                offset = 339 + extra + index * 216
                for byte in range(6, 216):
                    if (offset + byte) % 36 == 35:
                        raw[byte] = transport[offset + byte + 36]
                # Fake reporter output covers protected voice changes only;
                # the direct byte comparisons also retain control/status bits.
                positions = [b for b in analysis.changed_bits(raw, refs[kind])
                             if b in analysis.protected_bits()]
            if options and options[0] is not None:
                raw[7] = (raw[7] & 0xF0) | options[0]
            event_count = options[1] if len(options) > 1 else 1
            dump(bytes(raw), positions, kind, event_count)
        if tdu:
            raw = (self.references[extra] / "tdu.bin").read_bytes() + b"\xA5" * 198
            dump(raw, [], 1, 0)
        if end:
            log("P25, received RF end of voice transmission from N0CALL to TG 10, 5.0 seconds, BER: 0.0%")
        text = "\n".join(lines) + "\n"
        (self.folder / "host-stdout.log").write_bytes(text.encode("utf-8"))
        parsed = analysis.trace_parser.parse_trace(text)
        parsed["input"] = {"sha256": hashlib.sha256(text.encode()).hexdigest()}
        (self.folder / "parsed.json").write_text(json.dumps(parsed), encoding="utf-8")
        (self.folder / "fec.jsonl").write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
        return rows

    def run_analysis(self, extra=0, **kwargs):
        return analysis.analyze(self.folder, self.references[extra], startup_extra=extra,
                                nac=0x293, talkgroup=10, source_id=1234567, **kwargs)

    def test_complete_call_excludes_padded_tdu_and_keeps_metrics_distinct(self):
        protected = analysis.protected_bits()
        endpoint = next(b for b in protected if (15 + b // 8) % 36 == 35)
        self.fixture(specs=[(1, [endpoint])] + [(1 if i % 2 == 0 else 2, []) for i in range(1, 28)])
        result = self.run_analysis()
        self.assertEqual(result["status"], "complete_unambiguous_comparison")
        self.assertEqual(result["expectations"]["accepted_reference_comparisons"], 28)
        self.assertEqual(result["expectations"]["serial_ldu_records_including_padded_tdu"], 29)
        self.assertEqual(result["excluded_records"][0]["reason"], "padded_tdu")
        self.assertEqual(result["direct_reference"]["errors"], 1)
        self.assertEqual(result["direct_reference"]["compared_bits"], 28 * 1680)
        self.assertEqual(result["fec"]["accepted_records_only"]["protected_bits"], 28 * 1233)
        self.assertEqual(result["direct_reference"]["phase35_vs_rest"]["phase35"]["errors"], 1)
        self.assertEqual(sum(r["compared_bits"] for r in result["direct_reference"]["by_assumed_transport_phase"]), 28 * 1680)
        self.assertEqual(sum(r["errors"] for r in result["direct_reference"]["by_rf_bit"]), 1)

    def test_shifted_endpoint_moves_one_byte_in_rf_coordinates(self):
        for extra, byte in ((0, 20), (1, 19)):
            with self.subTest(extra=extra):
                self.fixture(specs=[(1, [byte * 8])], extra=extra)
                result = self.run_analysis(extra)
                self.assertEqual(result["direct_reference"]["phase35_vs_rest"]["phase35"]["errors"], 1)
                self.assertEqual(result["direct_reference"]["by_rf_bit"][byte * 8 - 48]["assumed_transport_phase"], 35)

    def test_future_block_alias_tracks_alignment_and_final_padding(self):
        for extra, first in ((0, 20), (1, 19), (21, 35)):
            with self.subTest(extra=extra):
                self.fixture(extra=extra, future_endpoints=True)
                result = self.run_analysis(extra)
                alias = result["transport_endpoint_future_block"]
                self.assertEqual(result["status"], "complete_unambiguous_comparison")
                self.assertEqual(alias["status"], "complete_sequence_compared")
                metric = alias["metrics"]
                self.assertEqual(metric["endpoint_ldu_bytes"], list(range(first, 216, 36)))
                self.assertEqual(metric["compared_endpoint_bytes"], 28 * 6)
                self.assertEqual(metric["future_block_reference"]["errors"], 0)
                self.assertEqual(metric["future_block_reference"]["exact_matching_bytes"], 28 * 6)
                self.assertGreater(metric["correct_reference"]["errors"], 0)
                self.assertEqual(metric["correct_reference"]["errors"], result["direct_reference"]["errors"])
                self.assertEqual(sum(u["correct_reference"]["errors"] for u in metric["per_ldu"]),
                                 metric["correct_reference"]["errors"])
                self.assertEqual([u["global_ldu_index_zero_based"] for u in metric["per_ldu"]], list(range(28)))
                self.assertEqual(metric["per_ldu"][-1]["transport_ldu_byte_offset"], 339 + extra + 27 * 216)
                final = metric["per_ldu"][-1]["endpoint_substitutions"][-1]
                self.assertEqual(final["future_reference_region"], "padding")
                self.assertEqual(final["future_reference_hex"], "77")
                self.assertEqual(final["observed_hex"], "77")
                self.assertEqual(final["future_transport_byte_offset"], metric["reference_transport_bytes"] - 1)
                self.assertEqual(metric["future_reference_regions"]["padding"], 1)
                self.assertTrue(metric["example_substitutions"])
                for example in metric["example_substitutions"]:
                    self.assertEqual(example["observed_hex"], example["future_reference_hex"])
                    self.assertNotEqual(example["correct_reference_hex"], example["future_reference_hex"])
                compact = analysis.compact(result)["transport_endpoint_future_block"]["metrics"]
                self.assertNotIn("per_ldu", compact)
                self.assertEqual(compact["correct_reference"], metric["correct_reference"])

    def test_future_endpoint_bounds_and_raw_global_index_guard(self):
        self.fixture(future_endpoints=True)
        result = self.run_analysis()
        manifest, refs = analysis.reference_set(self.references[0], 0, 0x293, 10, 1234567, 28)
        frames = json.loads((self.folder / "parsed.json").read_text())["frames"]
        refs["transport.bin"] = refs["transport.bin"][:-1]
        with self.assertRaisesRegex(analysis.AnalysisError, "future endpoint outside padded"):
            analysis.future_block_endpoints(frames, result["matched_records"], refs, manifest,
                                            complete_single_call=True, expected_ldus=28)
        # Accepted records must not be renumbered after a missing raw record.
        refused = analysis.future_block_endpoints(frames, result["matched_records"][1:], refs, manifest,
                                                   complete_single_call=True, expected_ldus=28)
        self.assertIsNone(refused["metrics"])
        self.assertEqual(refused["reason"], "requires_contiguous_ordered_raw_ldu_indices")

    def test_future_alias_metric_unavailable_for_incomplete_call(self):
        self.fixture(specs=[(1 if i % 2 == 0 else 2, []) for i in range(26)])
        result = self.run_analysis()
        self.assertEqual(len(result["matched_records"]), 26)
        self.assertIsNone(result["transport_endpoint_future_block"]["metrics"])
        self.assertEqual(result["transport_endpoint_future_block"]["reason"],
                         "requires_one_complete_unambiguous_expected_call")

    def test_future_alias_does_not_join_two_complete_calls_into_one_stream(self):
        self.fixture()
        lines = (self.folder / "host-stdout.log").read_text().splitlines()
        audio = [i for i, line in enumerate(lines) if " audio, errs:" in line]
        at = audio[13] + 1
        lines[at:at] = [
            "D: 2026-11-03 04:00:00.000 P25, received RF end of voice transmission from N0CALL to TG 10",
            "D: 2026-11-03 04:00:00.000 P25, received RF voice transmission from N0CALL to TG 10"]
        text = "\n".join(lines) + "\n"
        (self.folder / "host-stdout.log").write_bytes(text.encode())
        parsed = analysis.trace_parser.parse_trace(text)
        parsed["input"] = {"sha256": hashlib.sha256(text.encode()).hexdigest()}
        (self.folder / "parsed.json").write_text(json.dumps(parsed))
        result = self.run_analysis(expected_calls=2)
        # Preserve the existing aggregate expectation semantics, while refusing
        # to invent a continuous physical offset across two RF key-ups.
        self.assertTrue(result["expectations"]["all_expectations_met"])
        self.assertIsNone(result["transport_endpoint_future_block"]["metrics"])

    def test_raw_duid_does_not_select_reference(self):
        self.fixture(specs=[(1, [], 8), (2, [], 5)])
        result = self.run_analysis()
        self.assertEqual(len(result["matched_records"]), 2)
        self.assertEqual([r["host_kind"] for r in result["matched_records"]], ["LDU1", "LDU2"])
        self.assertEqual([r["raw_duid_unvalidated"] for r in result["matched_records"]], [8, 5])
        self.assertEqual(result["expectations"]["expected_minus_accepted_comparisons"], 26)

    def test_direct_control_error_is_separate_from_protected_voice_fec(self):
        rows = self.fixture(specs=[(1, [48])])
        # Bit 48 belongs to NID, outside the 1233 protected voice bits. The
        # reference sees its error; voice-only FEC does not process or repair it.
        rows[0].update(corrections=0, voice_corrections=[0] * 9,
                       regenerated_rf_changed_bit_count=0,
                       regenerated_rf_changed_bit_positions_msb0=[],
                       changed_transport_byte_mod36_assumed=[])
        (self.folder / "fec.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
        text = (self.folder / "host-stdout.log").read_text().replace("errs: 1/1233", "errs: 0/1233")
        (self.folder / "host-stdout.log").write_bytes(text.encode())
        parsed = analysis.trace_parser.parse_trace(text)
        parsed["input"] = {"sha256": hashlib.sha256(text.encode()).hexdigest()}
        (self.folder / "parsed.json").write_text(json.dumps(parsed))
        result = self.run_analysis()
        self.assertEqual(result["direct_reference"]["errors"], 1)
        self.assertEqual(result["direct_reference"]["protected_voice_only"]["errors"], 0)
        self.assertEqual(result["fec"]["accepted_records_only"]["corrected_bits"], 0)

    def test_equal_reference_distances_are_ambiguous(self):
        ldu1 = (self.references[0] / "ldu1.bin").read_bytes()
        ldu2 = (self.references[0] / "ldu2.bin").read_bytes()
        differing = analysis.changed_bits(ldu1, ldu2)
        self.assertEqual(len(differing) % 2, 0)
        rows = self.fixture(specs=[(1, differing[:len(differing) // 2])])
        # The fixture helper places all synthetic FEC counts in one codeword;
        # balance the test count across codewords within their valid bounds.
        count = rows[0]["corrections"]
        # The fixed templates differ only outside protected voice. No voice
        # repair is reported even though the control/NID reference is a tie.
        self.assertFalse(set(differing) & analysis.protected_bits())
        rows[0].update(corrections=0, voice_corrections=[0] * 9,
                       regenerated_rf_changed_bit_count=0,
                       regenerated_rf_changed_bit_positions_msb0=[],
                       changed_transport_byte_mod36_assumed=[])
        (self.folder / "fec.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
        text = (self.folder / "host-stdout.log").read_text().replace(f"errs: {count}/1233", "errs: 0/1233")
        (self.folder / "host-stdout.log").write_bytes(text.encode())
        parsed = analysis.trace_parser.parse_trace(text)
        parsed["input"] = {"sha256": hashlib.sha256(text.encode()).hexdigest()}
        (self.folder / "parsed.json").write_text(json.dumps(parsed))
        result = self.run_analysis()
        self.assertEqual(result["ambiguous_records"][0]["nearest_reference_kinds"], [1, 2])
        self.assertEqual(result["direct_reference"]["compared_bits"], 0)
        self.assertIsNone(result["transport_endpoint_future_block"]["metrics"])

    def test_repeated_kind_cannot_pass_complete_even_when_total_count_matches(self):
        self.fixture(specs=[(1, []) for _ in range(28)])
        result = self.run_analysis()
        self.assertEqual(result["expectations"]["accepted_reference_comparisons"], 28)
        self.assertEqual(result["direct_reference"]["errors"], 0)
        self.assertEqual(len(result["expectations"]["alternating_kind_sequence_violations"]), 14)
        self.assertFalse(result["expectations"]["all_expectations_met"])
        self.assertEqual(result["status"], "partial_or_ambiguous_comparison")
        self.assertIsNone(result["transport_endpoint_future_block"]["metrics"])

    def test_audio_after_end_is_excluded_even_when_call_counts_match(self):
        self.fixture(tdu=False, end=False)
        text = (self.folder / "host-stdout.log").read_text()
        lines = text.splitlines()
        lines.insert(1, "D: 2026-11-03 04:00:00.000 P25, received RF end of voice transmission from N0CALL to TG 10")
        text = "\n".join(lines) + "\n"
        (self.folder / "host-stdout.log").write_bytes(text.encode())
        parsed = analysis.trace_parser.parse_trace(text)
        parsed["input"] = {"sha256": hashlib.sha256(text.encode()).hexdigest()}
        (self.folder / "parsed.json").write_text(json.dumps(parsed))
        result = self.run_analysis()
        self.assertEqual(result["expectations"]["rf_acquisitions"], 1)
        self.assertEqual(result["expectations"]["rf_ends"], 1)
        self.assertEqual(result["expectations"]["accepted_reference_comparisons"], 0)
        self.assertEqual(len(result["ambiguous_records"]), 28)
        self.assertEqual(result["status"], "partial_or_ambiguous_comparison")

    def test_disagreed_host_kind_and_fec_mismatch_are_not_totalled(self):
        rows = self.fixture(specs=[(1, []), (2, [])])
        text = (self.folder / "host-stdout.log").read_text()
        # Preserve the trace bytes, but claim the wrong decoded kind for first LDU.
        text = text.replace("P25, LDU1 audio", "P25, LDU2 audio", 1)
        (self.folder / "host-stdout.log").write_bytes(text.encode("utf-8"))
        parsed = analysis.trace_parser.parse_trace(text)
        parsed["input"] = {"sha256": hashlib.sha256(text.encode()).hexdigest()}
        (self.folder / "parsed.json").write_text(json.dumps(parsed))
        rows[1]["corrections"] = 1
        rows[1]["voice_corrections"][0] = 1
        bit = next(iter(analysis.protected_bits()))
        rows[1].update(regenerated_rf_changed_bit_count=1,
                       regenerated_rf_changed_bit_positions_msb0=[bit],
                       changed_transport_byte_mod36_assumed=[(15 + bit // 8) % 36])
        (self.folder / "fec.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
        result = self.run_analysis()
        self.assertEqual({r["reason"] for r in result["ambiguous_records"]},
                         {"reference_tie_or_host_kind_disagreement", "host_offline_fec_count_mismatch"})
        self.assertEqual(result["direct_reference"]["compared_bits"], 0)
        self.assertIsNone(result["direct_reference"]["fraction"])
        self.assertEqual(result["fec"]["accepted_records_only"]["protected_bits"], 0)

    def test_multiple_or_orphan_events_and_unprocessed_frame_stay_explicit(self):
        self.fixture(specs=[(1, [], None, 2), (2, [], None, 0)], orphan=True)
        result = self.run_analysis()
        self.assertEqual(len(result["ambiguous_records"]), 1)
        self.assertEqual(len(result["unprocessed_serial_ldus"]), 1)
        self.assertEqual(len(result["unassociated_host_audio_events"]), 3)
        self.assertEqual(result["direct_reference"]["compared_bits"], 0)

    def test_empty_no_acquisition_is_an_explicit_partial_result(self):
        self.fixture(specs=[], tdu=False, start=False, end=False)
        result = self.run_analysis()
        self.assertEqual(result["expectations"]["rf_acquisitions"], 0)
        self.assertEqual(result["expectations"]["expected_minus_host_audio_events"], 28)
        self.assertEqual(result["status"], "partial_or_ambiguous_comparison")
        self.assertIsNone(result["direct_reference"]["fraction"])

    def test_reference_profile_alignment_and_file_integrity_enforced(self):
        self.fixture()
        with self.assertRaisesRegex(analysis.AnalysisError, "talkgroup"):
            analysis.analyze(self.folder, self.references[0], startup_extra=0, nac=0x293, talkgroup=11, source_id=1234567)
        with self.assertRaisesRegex(analysis.AnalysisError, "startup_extra"):
            analysis.analyze(self.folder, self.references[0], startup_extra=1, nac=0x293, talkgroup=10, source_id=1234567)
        corrupt = self.folder / "corrupt-refs"
        shutil.copytree(self.references[0], corrupt)
        (corrupt / "ldu1.bin").write_bytes(b"\x00" * 216)
        with self.assertRaisesRegex(analysis.AnalysisError, "hash/length"):
            analysis.analyze(self.folder, corrupt, startup_extra=0, nac=0x293, talkgroup=10, source_id=1234567)

    def test_self_consistent_wrong_reference_bytes_fail_independent_generation(self):
        self.fixture()
        corrupt = self.folder / "forged-refs"
        shutil.copytree(self.references[0], corrupt)
        data = b"\x00" * 216
        (corrupt / "ldu1.bin").write_bytes(data)
        manifest = json.loads((corrupt / "manifest.json").read_text())
        manifest["files"]["ldu1.bin"] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        (corrupt / "manifest.json").write_text(json.dumps(manifest))
        with self.assertRaisesRegex(analysis.AnalysisError, "independently generated"):
            analysis.analyze(self.folder, corrupt, startup_extra=0, nac=0x293, talkgroup=10, source_id=1234567)

    def test_stale_parsed_fec_count_or_phase_fail_closed(self):
        rows = self.fixture()
        parsed = json.loads((self.folder / "parsed.json").read_text())
        parsed["frames"][0]["raw_duid"] = 8
        (self.folder / "parsed.json").write_text(json.dumps(parsed))
        with self.assertRaisesRegex(analysis.AnalysisError, "reparsed"):
            self.run_analysis()
        self.fixture()
        (self.folder / "fec.jsonl").write_text("")
        with self.assertRaisesRegex(analysis.AnalysisError, "row count"):
            self.run_analysis()
        rows[0]["startup_extra_bytes"] = 1
        (self.folder / "fec.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
        with self.assertRaisesRegex(analysis.AnalysisError, "startup_extra"):
            self.run_analysis()

    def test_cli_writes_new_output_and_refuses_overwrite(self):
        self.fixture()
        output = self.folder / "analysis.json"
        argv = [str(self.folder), "--references", str(self.references[0]), "--startup-extra", "0",
                "--nac", "293", "--tg", "10", "--source", "1234567", "--output", str(output)]
        with redirect_stdout(io.StringIO()) as stdout:
            self.assertEqual(analysis.main(argv), 0)
        self.assertEqual(json.loads(stdout.getvalue())["status"], "complete_unambiguous_comparison")
        before = output.read_bytes()
        with redirect_stderr(io.StringIO()):
            self.assertEqual(analysis.main(argv), 2)
        self.assertEqual(output.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
