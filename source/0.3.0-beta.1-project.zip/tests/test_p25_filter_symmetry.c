// SPDX-License-Identifier: GPL-3.0-or-later
// New polyphase kernel, frozen old kernel, and full121-tap int64 oracle.
#include "p25_demod_filter.h"
#include <assert.h>
#include <limits.h>
#include <string.h>

#undef P25_DEMOD_FILTER_H
#define p25_interp old_p25_interp
#define p25_interp_sample old_p25_interp_sample
#include "reference/p25_filter_before_phase3.h"
#undef p25_interp
#undef p25_interp_sample

static uint64_t cases;
static uint32_t rng=0x25f103u;
static uint32_t random_word(void) {
    rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;
}
static int64_t reference_sum(const int16_t input[21],unsigned phase) {
    int64_t sum=0;
    for(unsigned k=phase,j=0;k<121u;k+=6u,++j)
        sum+=(int64_t)old_p25_interp[k]*input[20u-j];
    return sum;
}
static void check(const int16_t input[21]) {
    int16_t current[6],old[6];
    p25_interp_sample(input+20,current);old_p25_interp_sample(input+20,old);
    assert(!memcmp(current,old,sizeof current));
    for(unsigned phase=0;phase<6u;++phase) {
        int64_t expected=reference_sum(input,phase)/32768;
        if(expected>INT16_MAX)expected=INT16_MAX;
        if(expected<INT16_MIN)expected=INT16_MIN;
        assert(current[phase]==expected);
    }
    ++cases;
}
static void phase3_total(int16_t input[21],int64_t total) {
    // Construct an exact requested phase3 sum with the two20758 center taps
    // and coefficients -69/164. Since (-69)*19 ==1 (mod164), every residue
    // is attainable without relying on the production convolution algorithm.
    memset(input,0,21u*sizeof *input);
    int64_t pair=total/20758,rem=total-pair*20758;
    int64_t x=(rem*19)%164;if(x<0)x+=164;
    int64_t y=(rem+69*x)/164;
    assert(pair/2>=INT16_MIN&&pair/2<=INT16_MAX);
    assert(pair-pair/2>=INT16_MIN&&pair-pair/2<=INT16_MAX);
    assert(x>=INT16_MIN&&x<=INT16_MAX&&y>=INT16_MIN&&y<=INT16_MAX);
    input[11]=(int16_t)(pair/2);input[10]=(int16_t)(pair-pair/2);
    input[20]=(int16_t)x;input[19]=(int16_t)y;
    assert(reference_sum(input,3)==total);check(input);
}
uint64_t p25_filter_symmetry_test(void) {
    assert(sizeof p25_interp==sizeof old_p25_interp);
    assert(!memcmp(p25_interp,old_p25_interp,sizeof p25_interp));
    int64_t first9=0;
    for(unsigned j=0;j<10u;++j) {
        assert(old_p25_interp[3u+6u*j]==old_p25_interp[117u-6u*j]);
        if(j<9u)first9+=old_p25_interp[3u+6u*j]<0?
            -old_p25_interp[3u+6u*j]:old_p25_interp[3u+6u*j];
    }
    assert(first9==15966&&first9*65536==1046347776);
    assert(old_p25_interp[57]==20758&&INT64_C(20758)*65536==1360396288);
    assert(first9*65536<INT32_MAX&&INT64_C(20758)*65536<INT32_MAX);
    int16_t input[21];
    // Every input position at every signed16 value, including the otherwise
    // zero phase0 taps, verifies impulse coefficients and all scale signs.
    for(unsigned pos=0;pos<21u;++pos) {
        memset(input,0,sizeof input);
        for(int32_t value=INT16_MIN;value<=INT16_MAX;++value) {
            input[pos]=(int16_t)value;check(input);
        }
    }
    for(unsigned pattern=0;pattern<64u;++pattern) {
        for(unsigned i=0;i<21u;++i)
            input[i]=(pattern&(1u<<(i%6u)))?INT16_MIN:INT16_MAX;
        check(input);
    }
    // Each phase's coefficient-sign pattern attains its maximum absolute
    // convolution magnitude; full phases2..4 exceed int32 before saturation.
    for(unsigned phase=0;phase<6u;++phase)for(unsigned sign=0;sign<2u;++sign) {
        memset(input,0,sizeof input);
        for(unsigned k=phase,j=0;k<121u;k+=6u,++j)
            input[20u-j]=((old_p25_interp[k]<0)!=sign)?INT16_MIN:INT16_MAX;
        check(input);
    }
    // Exact sums sweep both sides of truncation and saturation thresholds.
    const int64_t bases[]={0,32768,-32768,INT64_C(32767)*32768,
        INT64_C(32768)*32768,-INT64_C(32768)*32768,-INT64_C(32769)*32768};
    for(unsigned b=0;b<sizeof bases/sizeof *bases;++b)
        for(int32_t delta=-32769;delta<=32769;++delta)phase3_total(input,bases[b]+delta);
    for(unsigned n=0;n<300000u;++n) {
        for(unsigned i=0;i<21u;++i) {
            uint32_t value=random_word();
            input[i]=(n%3u==0)?(value&1u?INT16_MIN:INT16_MAX):
                n%3u==1?(int16_t)(value%129u-64u):(int16_t)value;
        }
        check(input);
    }
    return cases;
}
