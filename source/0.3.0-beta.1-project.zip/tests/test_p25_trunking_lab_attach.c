// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_lab_attach.h"
#include "p25_tsdu.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static unsigned checks;
#define CHECK(x) do {++checks;assert(x);} while(0)
static const char *directory;
static uint32_t next_sequence(uint32_t seq) {++seq;return seq ? seq:1u;}
static p25_lab_exchange_owner owner(unsigned profile,uint32_t seq) {
    const p25_trunking_lab_profile *p=p25_trunking_lab_get(profile);
    p25_lab_exchange_owner o={.sequence=seq,.owner_tag=0x87654321u,.radio_id=1234567u,
        .wacn=P25_TRUNK_LAB_WACN,.control_rx_hz=p->control_rx_hz,.control_tx_hz=p->control_tx_hz,
        .nac=P25_TRUNK_LAB_NAC,.system=P25_TRUNK_LAB_SYSTEM,.group=1,
        .expected_channel=P25_LAB_VOICE_CHANNEL,.profile=(uint8_t)profile,
        .request=P25_LAB_GROUP,.expected_options=P25_LAB_VOICE_OPTIONS};return o;
}
static void block(const char *label,uint8_t out[12]) {
    char path[1024];snprintf(path,sizeof path,"%s/%s.bin",directory,label);
    FILE *f=fopen(path,"rb");CHECK(f);uint8_t wire[90];size_t bytes=fread(wire,1,sizeof wire,f);
    CHECK(!ferror(f));fclose(f);p25_tsdu unit;CHECK(p25_tsdu_decode(wire,bytes,&unit) && unit.nac==0x293 && unit.count==1);
    memcpy(out,unit.block[0],12);
}
static void start(p25_lab_attach *s,unsigned profile,uint32_t seq,uint32_t base) {
    memset(s,0,sizeof *s);p25_lab_exchange_owner o=owner(profile,seq);
    CHECK(p25_lab_attach_start(s,&o,11,true,true,true,base));
    CHECK(s->phase==P25_LAB_ATTACH_REGISTER && p25_lab_attach_owned(s));
}
static void prepared(p25_lab_attach *s,p25_lab_exchange *e,uint32_t base,bool aff) {
    p25_lab_exchange_owner o;CHECK(p25_lab_attach_leg_owner(s,&o));
    CHECK(o.request==(aff ? P25_LAB_AFFILIATE:P25_LAB_REGISTER) && !o.expected_channel && !o.expected_options);
    CHECK(o.sequence==(aff ? next_sequence(s->owner.sequence):s->owner.sequence));
    memset(e,0,sizeof *e);CHECK(p25_lab_exchange_prepare(e,&o,aff ? 14:12,base+1000u));
    CHECK(p25_lab_attach_bind_prepared(s,e,&s->owner,base+1001u));
    CHECK(s->phase==(aff ? P25_LAB_ATTACH_WAIT_AFF:P25_LAB_ATTACH_WAIT_REG) && s->needs_rf_off);
    CHECK(!p25_lab_attach_bind_prepared(s,e,&s->owner,base+1002u));
}
static void waiting(p25_lab_exchange *e,uint32_t base,bool aff) {
    CHECK(p25_lab_exchange_tx_started(e,e->owner.sequence,base+2000u));
    CHECK(p25_lab_exchange_tx_done(e,e->owner.sequence,true,base+57000u));
    CHECK(p25_lab_exchange_begin_return(e,e->owner.sequence,true,base+57001u));
    CHECK(p25_lab_exchange_rx_ready(e,e->owner.sequence,true,aff ? 15:13,base+90000u));
}
static bool consume(p25_lab_exchange *e,const char *label,uint32_t now) {
    uint8_t data[12];block(label,data);
    return p25_lab_exchange_consume(e,e->owner.sequence,e->owner.owner_tag,e->rx_epoch,e->owner.nac,
        e->owner.control_rx_hz,data,now);
}
static void accepted(p25_lab_attach *s,p25_lab_exchange *e,uint32_t base,bool aff) {
    prepared(s,e,base,aff);waiting(e,base,aff);
    CHECK(consume(e,aff ? "affiliation-accepted":"registration-accepted",base+100000u));
    CHECK(p25_lab_attach_observe(s,e,&s->owner,true,true,true,base+100010u));
    CHECK(s->phase==(aff ? P25_LAB_ATTACH_RETURN_PENDING:P25_LAB_ATTACH_AFFILIATE) && !s->needs_rf_off);
}
static void returning(p25_lab_attach *s,p25_lab_exchange *e,unsigned profile,uint32_t seq,uint32_t base) {
    start(s,profile,seq,base);accepted(s,e,base,false);accepted(s,e,base+150000u,true);
    CHECK(p25_lab_attach_begin_return(s,true,base+250020u));
}
static void ready(p25_lab_attach *s,p25_lab_exchange *e,unsigned profile,uint32_t seq,uint32_t base) {
    returning(s,e,profile,seq,base);CHECK(p25_lab_attach_ready(s,16,true,true,true,base+300000u));
    CHECK(s->phase==P25_LAB_ATTACH_READY && s->ready_epoch==16);
}
static void complete(void) {
    CHECK(sizeof(p25_lab_attach)<=112u);
    for(unsigned profile=0;profile<2;++profile)for(unsigned wrap=0;wrap<3;++wrap) {
        uint32_t base=wrap==0 ? 1000000u:wrap==1 ? UINT32_MAX-100000u:UINT32_MAX-299999u;
        uint32_t seq=wrap ? UINT32_MAX:7u;p25_lab_attach s;p25_lab_exchange e;
        ready(&s,&e,profile,seq,base);p25_lab_exchange_owner expected;
        CHECK(p25_lab_attach_ptt_owner(&s,&expected) && expected.request==P25_LAB_GROUP
            && expected.sequence==next_sequence(next_sequence(seq)) && expected.expected_channel==0x1001 && expected.expected_options==4);
        CHECK(s.registration.sequence==seq && s.registration.rx_epoch==13 && s.registration.reply_us==base+100000u
            && s.registration.assigned==1234567u && s.registration.type==P25_TRUNK_OSP_REGISTRATION && !s.registration.response);
        CHECK(s.affiliation.sequence==next_sequence(seq) && s.affiliation.rx_epoch==15 && s.affiliation.reply_us==base+250000u
            && s.affiliation.group==1 && s.affiliation.type==P25_TRUNK_OSP_AFFILIATION && !s.affiliation.response);
        CHECK(s.owner.sequence==seq && s.owner.request==P25_LAB_GROUP && s.start_epoch==11);
        CHECK(p25_lab_attach_consume_ready(&s,&s.owner,16,true,true,true,base+300010u));
        CHECK(!p25_lab_attach_consume_ready(&s,&s.owner,16,true,true,true,base+300011u));
        CHECK(p25_lab_attach_armed(&s,&expected,true,base+300020u));
        CHECK(s.phase==P25_LAB_ATTACH_ARMED && !p25_lab_attach_owned(&s));
        p25_lab_attach saved=s;p25_lab_attach_poll(&s,base+70000000u);
        CHECK(!memcmp(&s,&saved,sizeof s)); // Existing PTT has its own60s lease.
        CHECK(!p25_lab_attach_input(&s,&s.owner,false,true,base+70000001u));
        CHECK(!memcmp(&s,&saved,sizeof s));
        CHECK(!p25_lab_attach_armed(&s,&expected,true,base+70000002u));
        p25_lab_exchange_owner next=s.owner;next.sequence=s.used_sequence;
        CHECK(!p25_lab_attach_start(&s,&next,16,true,true,true,base+70000003u));
        next.sequence=next_sequence(next.sequence);
        CHECK(p25_lab_attach_start(&s,&next,16,true,true,true,base+70000004u));
    }
}
static void native_wrong_and_nonacceptance(void) {
    const char *reg[]={"reg-wrong-target","reg-wrong-system","reg-wrong-assigned"};
    const char *aff[]={"aff-wrong-target","aff-wrong-group"};
    for(unsigned stage=0;stage<2;++stage)for(unsigned i=0;i<(stage ? 2u:3u);++i) {
        p25_lab_attach s;p25_lab_exchange e;start(&s,0,7,1000000u);
        if(stage)accepted(&s,&e,1000000u,false);
        uint32_t base=stage ? 1150000u:1000000u;prepared(&s,&e,base,stage);waiting(&e,base,stage);
        p25_lab_exchange before=e;CHECK(!consume(&e,stage ? aff[i]:reg[i],base+100000u));
        CHECK(!memcmp(&e,&before,sizeof e));p25_lab_attach saved=s;
        CHECK(!p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,base+100010u));CHECK(!memcmp(&s,&saved,sizeof s));
    }
    for(unsigned kind=0;kind<4;++kind) {
        p25_lab_attach s;p25_lab_exchange e;start(&s,0,7,1000000u);prepared(&s,&e,1000000u,false);waiting(&e,1000000u,false);
        const char *label=kind==0 ? "reg-ack":kind==1 ? "registration-queued":kind==2 ? "reg-negative":"registration-denied";
        CHECK(consume(&e,label,1100000u));CHECK(!p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,1100010u));
        if(kind<2) {
            CHECK(s.phase==P25_LAB_ATTACH_WAIT_REG && !s.registration.sequence);
            CHECK(consume(&e,"registration-accepted",1100100u));
            CHECK(p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,1100110u));
        } else CHECK(s.phase==P25_LAB_ATTACH_FAILED && !s.registration.sequence && !s.affiliation.sequence);
    }
    p25_lab_attach s;p25_lab_exchange e;start(&s,0,7,1000000u);accepted(&s,&e,1000000u,false);
    prepared(&s,&e,1150000u,true);waiting(&e,1150000u,true);CHECK(consume(&e,"aff-negative",1250000u));
    CHECK(!p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,1250010u));
    CHECK(s.phase==P25_LAB_ATTACH_FAILED && s.registration.sequence==7 && !s.affiliation.sequence);
}
static void binding_refusals(void) {
    for(unsigned field=0;field<13;++field) {
        p25_lab_attach s;start(&s,1,7,1000000u);p25_lab_exchange_owner expected;
        CHECK(p25_lab_attach_leg_owner(&s,&expected));p25_lab_exchange e={0};
        CHECK(p25_lab_exchange_prepare(&e,&expected,12,1001000u));p25_lab_exchange_owner current=s.owner;
        switch(field) {
        case 0:e.owner.sequence++;break;case 1:e.owner.owner_tag++;break;case 2:e.owner.request=P25_LAB_AFFILIATE;break;
        case 3:e.owner.expected_channel=0x1001;break;case 4:e.owner.expected_options=4;break;
        case 5:e.phase=P25_LAB_TX_ACTIVE;break;case 6:e.previous_epoch=0;break;case 7:e.previous_epoch=10;break;
        case 8:e.prepared_us=s.start_us-1u;break;case 9:e.prepared_us=1001002u;break;
        case 10:current.group++;break;case 11:current.control_tx_hz++;break;default:current.request=P25_LAB_REGISTER;break;
        }
        p25_lab_attach saved=s;CHECK(!p25_lab_attach_bind_prepared(&s,&e,&current,1001001u));CHECK(!memcmp(&s,&saved,sizeof s));
    }
}
static void receipt_refusals(void) {
    for(unsigned stage=0;stage<2;++stage)for(unsigned field=0;field<23;++field) {
        p25_lab_attach s;p25_lab_exchange e;start(&s,0,7,1000000u);if(stage)accepted(&s,&e,1000000u,false);
        uint32_t base=stage ? 1150000u:1000000u;prepared(&s,&e,base,stage);waiting(&e,base,stage);
        CHECK(consume(&e,stage ? "affiliation-accepted":"registration-accepted",base+100000u));
        switch(field) {
        case 0:e.owner.sequence++;break;case 1:e.owner.owner_tag++;break;case 2:e.owner.group++;break;
        case 3:e.owner.system++;break;case 4:e.previous_epoch++;break;case 5:e.prepared_us++;break;
        case 6:e.rx_epoch=e.previous_epoch;break;case 7:e.rx_epoch=0;break;case 8:e.tx_started_us=e.prepared_us-1u;break;
        case 9:e.tx_started_us=e.prepared_us+250000u;break;case 10:e.cutoff_us=e.tx_started_us+55501u;break;
        case 11:e.return_begin_us=e.cutoff_us-1u;break;case 12:e.rx_ready_us=e.cutoff_us+250000u;break;
        case 13:e.reply_us=e.rx_ready_us-1u;break;case 14:e.reply_us=e.cutoff_us+1500000u;break;
        case 15:e.replies=0;break;case 16:e.replies=9;break;case 17:e.reason=P25_LAB_CONFIG;break;
        case 18:e.response=1;break;case 19:e.reply_type=P25_TRUNK_OSP_ACK;break;
        case 20:if(stage)e.reply_group++;else e.assigned++;break;
        case 21:e.owner.profile=1;break;default:e.rx_epoch=e.previous_epoch-1u;break;
        }
        CHECK(!p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,base+100010u));
        CHECK(s.phase==P25_LAB_ATTACH_FAILED && s.needs_rf_off);
        CHECK(stage ? s.registration.sequence==7 && !s.affiliation.sequence:!s.registration.sequence && !s.affiliation.sequence);
    }
}
static void cancellation_and_time(void) {
    for(unsigned stage=0;stage<8;++stage) {
        p25_lab_attach s;p25_lab_exchange e;start(&s,0,7,1000000u);
        if(stage>=1)prepared(&s,&e,1000000u,false);
        if(stage>=2) {waiting(&e,1000000u,false);CHECK(consume(&e,"registration-accepted",1100000u));CHECK(p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,1100010u));}
        if(stage>=3)prepared(&s,&e,1150000u,true);
        if(stage>=4) {waiting(&e,1150000u,true);CHECK(consume(&e,"affiliation-accepted",1250000u));CHECK(p25_lab_attach_observe(&s,&e,&s.owner,true,true,true,1250010u));}
        if(stage>=5)CHECK(p25_lab_attach_begin_return(&s,true,1250020u));
        if(stage>=6)CHECK(p25_lab_attach_ready(&s,16,true,true,true,1300000u));
        if(stage>=7)CHECK(p25_lab_attach_consume_ready(&s,&s.owner,16,true,true,true,1300010u));
        CHECK(!p25_lab_attach_input(&s,&s.owner,false,true,1300020u));
        CHECK(s.phase==P25_LAB_ATTACH_CANCELLED && s.reason==P25_LAB_ATTACH_PTT);
        p25_lab_exchange_owner untouched=owner(1,123),out=untouched;
        CHECK(!p25_lab_attach_leg_owner(&s,&out) && !memcmp(&out,&untouched,sizeof out));
        CHECK(!p25_lab_attach_ptt_owner(&s,&out) && !memcmp(&out,&untouched,sizeof out));
        if(s.needs_rf_off) {CHECK(!p25_lab_attach_abort_off(&s,false,1300030u));CHECK(p25_lab_attach_abort_off(&s,true,1300031u));}
        CHECK(!p25_lab_attach_owned(&s));
    }
    for(unsigned wrap=0;wrap<2;++wrap) {
        uint32_t base=wrap ? UINT32_MAX-100000u:1000000u;p25_lab_attach s;p25_lab_exchange e;
        start(&s,0,7,base);p25_lab_attach_poll(&s,base+8000000u);CHECK(s.phase==P25_LAB_ATTACH_FAILED);
        start(&s,0,7,base);prepared(&s,&e,base,false);p25_lab_attach_poll(&s,s.prepared_us+P25_LAB_ATTACH_LEG_US);
        CHECK(s.phase==P25_LAB_ATTACH_FAILED && s.needs_rf_off);
        returning(&s,&e,0,7,base);CHECK(!p25_lab_attach_ready(&s,16,true,true,true,s.return_us+1000000u));
        CHECK(s.phase==P25_LAB_ATTACH_FAILED && !s.ready_epoch);
        returning(&s,&e,0,7,base);CHECK(!p25_lab_attach_ready(&s,15,true,true,true,s.return_us+1u));
        CHECK(!p25_lab_attach_ready(&s,14,true,true,true,s.return_us+2u));CHECK(!p25_lab_attach_ready(&s,16,false,true,true,s.return_us+3u));
        CHECK(p25_lab_attach_ready(&s,16,true,true,true,s.return_us+999999u));
        CHECK(!p25_lab_attach_consume_ready(&s,&s.owner,17,true,true,true,s.ready_us+1u));CHECK(s.phase==P25_LAB_ATTACH_FAILED);
        ready(&s,&e,0,7,base);CHECK(p25_lab_attach_consume_ready(&s,&s.owner,16,true,true,true,s.ready_us+1u));
        p25_lab_exchange_owner expected;CHECK(p25_lab_attach_ptt_owner(&s,&expected));expected.sequence++;
        CHECK(!p25_lab_attach_armed(&s,&expected,true,s.ready_us+2u));CHECK(s.phase==P25_LAB_ATTACH_FAILED);
    }
    p25_lab_attach s;p25_lab_exchange e;start(&s,0,7,1000000u);p25_lab_exchange_owner wrong=s.owner;wrong.group++;
    CHECK(!p25_lab_attach_input(&s,&wrong,true,true,1001000u));CHECK(s.reason==P25_LAB_ATTACH_OWNER);
    start(&s,0,7,1000000u);CHECK(!p25_lab_attach_input(&s,&s.owner,true,false,1001000u));CHECK(s.reason==P25_LAB_ATTACH_PERMISSION);
    returning(&s,&e,0,7,1000000u);CHECK(!p25_lab_attach_ready(&s,16,true,true,false,1300000u));CHECK(s.needs_rf_off);
    CHECK(p25_lab_attach_abort_off(&s,true,1300001u));CHECK(!s.ready_epoch);
}
int main(int argc,char **argv) {
    CHECK(argc==2);directory=argv[1];complete();native_wrong_and_nonacceptance();binding_refusals();receipt_refusals();cancellation_and_time();
    printf("Finite lab attach: PASS checks=%u bytes=%u\n",checks,(unsigned)sizeof(p25_lab_attach));return 0;
}
