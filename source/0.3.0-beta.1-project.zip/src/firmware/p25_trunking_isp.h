// SPDX-License-Identifier: GPL-3.0-or-later
// Wire-only Phase 1 subscriber signaling. No RF, access timing or authorization.
#ifndef P25_TRUNKING_ISP_H
#define P25_TRUNKING_ISP_H
#include <stdbool.h>
#include <stdint.h>

#define P25_TRUNKING_ISP_STATUS 2u

// Build one complete standard, unprotected last-block TSBK including CRC.
// Nonzero IDs must fit their on-air widths. Failure leaves output unchanged.
bool p25_trunking_isp_register(uint8_t out[12],uint32_t wacn,uint16_t system,uint32_t rid);
bool p25_trunking_isp_affiliate(uint8_t out[12],uint16_t system,uint16_t group,uint32_t rid);
// Only clear half-duplex circuit voice is supported: emergency/priority bits
// (0x87) are allowed; encryption, duplex, packet and reserved bits are refused.
bool p25_trunking_isp_group_request(uint8_t out[12],uint16_t group,uint32_t rid,uint8_t options);
bool p25_trunking_isp_deregister(uint8_t out[12],uint32_t wacn,uint16_t system,uint32_t rid);

typedef enum {
    P25_TRUNK_OSP_NONE,P25_TRUNK_OSP_GROUP_GRANT,P25_TRUNK_OSP_REGISTRATION,
    P25_TRUNK_OSP_AFFILIATION,P25_TRUNK_OSP_ACK,P25_TRUNK_OSP_QUEUED,
    P25_TRUNK_OSP_DENIED,P25_TRUNK_OSP_UNSUPPORTED
} p25_trunking_osp_type;
typedef struct {
    p25_trunking_osp_type type;
    uint8_t opcode,service,options,response;
    uint16_t system,group,announcement,channel;
    // Grant: source=calling RID. Responses: target=addressed requester RID.
    // Registration: assigned=assigned source ID; no silent ID substitution.
    // ACK/queue/deny: source=additional other address when present; an extended
    // ACK carries WACN/system instead, with source left zero. UNSUPPORTED:
    // known 0x2a/0x2d targets precede the source address; 0x32 addresses the
    // subscriber after its auth result. A zero target means the unsupported
    // address format cannot be qualified, requiring a conservative RX-only
    // fallback on the matching qualified site, never attached/TX operation.
    uint32_t source,target,assigned;
    bool additional,extended,global,encrypted;
} p25_trunking_osp;

// Parse a standard unprotected OSP TSBK after qualifying its own CRC. Unknown,
// malformed and vendor/protected blocks return false without changing output.
// UNSUPPORTED identifies authentication, registration-command or affiliation-
// query handling that this first subscriber profile cannot complete. A nonzero
// target is a decoded address, not a claim it matches this unit. Callers bind
// events to a qualified NAC/site and pending transaction before authorizing TX.
bool p25_trunking_osp_parse(const uint8_t block[12],p25_trunking_osp *out);
#endif
