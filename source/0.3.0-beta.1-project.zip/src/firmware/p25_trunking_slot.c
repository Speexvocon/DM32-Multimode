// SPDX-License-Identifier: GPL-3.0-or-later
// Nominal status cadence and meanings: Zetron TG-001 rev5, chapter6 pp76,80.
// That overview does not specify a complete subscriber access/backoff engine.
#include "p25_trunking_slot.h"
#include <string.h>

bool p25_trunking_slot_init(p25_trunking_slot *t,uint16_t tolerance_ticks,
                            uint16_t max_age_ticks) {
    if(!t || tolerance_ticks>=P25_TRUNK_SLOT_MICRO_TICKS/2u || !max_age_ticks ||
       max_age_ticks>P25_TRUNK_SLOT_MICRO_TICKS-tolerance_ticks)return false;
    p25_trunking_slot value={0};value.tolerance_ticks=tolerance_ticks;
    value.max_age_ticks=max_age_ticks;value.configured=true;*t=value;return true;
}
void p25_trunking_slot_lost(p25_trunking_slot *t) {
    if(!t)return;
    t->last_tick=t->boundary_tick=0;t->stream_epoch=t->lane_epoch=0;
    t->microslots=0;t->status=0;t->have_status=t->have_boundary=t->coherent=false;
}
bool p25_trunking_slot_observe(p25_trunking_slot *t,
                               const p25_trunking_slot_observation *observation) {
    if(!t || !t->configured)return false;
    if(!observation || !observation->selected || !observation->qualified ||
       !observation->status || observation->status>3u) {
        p25_trunking_slot_lost(t);return false;
    }
    if(t->have_status && (t->stream_epoch!=observation->stream_epoch ||
                          t->lane_epoch!=observation->lane_epoch))p25_trunking_slot_lost(t);
    if(t->have_status) {
        if(observation->sample_tick<=t->last_tick) {p25_trunking_slot_lost(t);return false;}
        uint64_t delta=observation->sample_tick-t->last_tick;
        if(delta<P25_TRUNK_SLOT_MICRO_TICKS-t->tolerance_ticks ||
           delta>P25_TRUNK_SLOT_MICRO_TICKS+t->tolerance_ticks) {
            p25_trunking_slot_lost(t);return false;
        }
        if(t->have_boundary) {
            if(t->microslots==UINT16_MAX) {p25_trunking_slot_lost(t);return false;}
            ++t->microslots;
        }
    }
    t->last_tick=observation->sample_tick;t->stream_epoch=observation->stream_epoch;
    t->lane_epoch=observation->lane_epoch;t->status=observation->status;t->have_status=true;
    if(t->status==1u) {
        // A busy observation invalidates idle phase; it does not authorize a
        // predicted future idle boundary or contention retry.
        t->have_boundary=t->coherent=false;t->microslots=0;
    } else if(t->status==3u) {
        if(t->have_boundary) {
            if(t->microslots<P25_TRUNK_SLOT_MIN_MICROS) {
                p25_trunking_slot_lost(t);return false;
            }
            t->coherent=true;
        }
        t->boundary_tick=t->last_tick;t->have_boundary=true;t->microslots=0;
    }
    return true;
}
bool p25_trunking_slot_phase(const p25_trunking_slot *t,uint64_t now_tick,
                             p25_trunking_slot_phase_view *out) {
    if(!t || !out || !t->configured || !t->have_status || !t->have_boundary || !t->coherent ||
       now_tick<t->last_tick || now_tick-t->last_tick>t->max_age_ticks)return false;
    p25_trunking_slot_phase_view value={.last_status_tick=t->last_tick,
        .last_boundary_tick=t->boundary_tick,.stream_epoch=t->stream_epoch,
        .lane_epoch=t->lane_epoch,.microslots_since_boundary=t->microslots,.last_status=t->status};
    *out=value;return true;
}
bool p25_trunking_slot_boundary(const p25_trunking_slot *t,uint64_t now_tick,
                                p25_trunking_slot_boundary_view *out) {
    p25_trunking_slot_phase_view phase;
    if(!out || !p25_trunking_slot_phase(t,now_tick,&phase) || phase.last_status!=3u ||
       phase.microslots_since_boundary || phase.last_status_tick!=phase.last_boundary_tick ||
       phase.last_boundary_tick>UINT64_MAX-P25_TRUNK_SLOT_MIN_TICKS)return false;
    p25_trunking_slot_boundary_view value={.boundary_tick=phase.last_boundary_tick,
        .earliest_end_tick=phase.last_boundary_tick+P25_TRUNK_SLOT_MIN_TICKS,
        .stream_epoch=phase.stream_epoch,.lane_epoch=phase.lane_epoch};
    *out=value;return true;
}
bool p25_trunking_slot_fit(const p25_trunking_slot *t,uint64_t now_tick,
                           uint16_t actuation_ticks,uint16_t burst_ticks,
                           uint16_t end_guard_ticks,p25_trunking_slot_budget *out) {
    p25_trunking_slot_budget value;
    if(!out || !burst_ticks || !p25_trunking_slot_boundary(t,now_tick,&value.observed))return false;
    uint32_t required=(uint32_t)actuation_ticks+burst_ticks+end_guard_ticks;
    if(required>P25_TRUNK_SLOT_MIN_TICKS || now_tick>value.observed.earliest_end_tick ||
       required>value.observed.earliest_end_tick-now_tick)return false;
    value.projected_start_tick=now_tick+actuation_ticks;
    value.projected_end_tick=value.projected_start_tick+burst_ticks;
    *out=value;return true;
}
void p25_trunking_slot_backoff_cancel(p25_trunking_slot_backoff *b) {
    if(b)memset(b,0,sizeof *b);
}
bool p25_trunking_slot_backoff_arm(p25_trunking_slot_backoff *b,
    const p25_trunking_slot *t,uint64_t now_tick,uint8_t skip,uint32_t wait_ticks) {
    p25_trunking_slot_phase_view phase;
    if(!b || skip>P25_TRUNK_SLOT_MAX_BACKOFF || !wait_ticks ||
       wait_ticks>P25_TRUNK_SLOT_MAX_WAIT_TICKS || now_tick>UINT64_MAX-wait_ticks ||
       !p25_trunking_slot_phase(t,now_tick,&phase))return false;
    p25_trunking_slot_backoff value={.deadline_tick=now_tick+wait_ticks,
        .last_boundary_tick=phase.last_boundary_tick,.stream_epoch=phase.stream_epoch,
        .last_poll_tick=now_tick,.lane_epoch=phase.lane_epoch,.skip=skip,.active=true};
    *b=value;return true;
}
bool p25_trunking_slot_backoff_take(p25_trunking_slot_backoff *b,
    const p25_trunking_slot *t,uint64_t now_tick,p25_trunking_slot_boundary_view *out) {
    if(!b || !out || !b->active)return false;
    p25_trunking_slot_phase_view phase;
    if(now_tick<b->last_poll_tick || now_tick>=b->deadline_tick || !p25_trunking_slot_phase(t,now_tick,&phase) ||
       phase.stream_epoch!=b->stream_epoch || phase.lane_epoch!=b->lane_epoch ||
       phase.last_boundary_tick<b->last_boundary_tick) {
        p25_trunking_slot_backoff_cancel(b);return false;
    }
    b->last_poll_tick=now_tick;
    p25_trunking_slot_boundary_view value;
    if(!p25_trunking_slot_boundary(t,now_tick,&value) || value.boundary_tick==b->last_boundary_tick)return false;
    b->last_boundary_tick=value.boundary_tick;
    if(b->skip) {--b->skip;return false;}
    b->active=false;*out=value;return true;
}
