// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit pre-NID receive witness. Never a qualified current-unit identity.
#ifndef P25_RX_EARLY_H
#define P25_RX_EARLY_H
#include "p25_rx_origin.h"

#define P25_RX_EARLY_SCHEMA 2u
#define P25_RX_EARLY_EVENT_BYTES 64u
#define P25_RX_EARLY_MAX_SAMPLES 4096u
#define P25_RX_EARLY_STATUS 4u

// Schema2 retains ordinary canonical64 events, with a smaller input bound.
// Type4 carries the raw first status on a lane selected by a PREVIOUS
// CRC-valid control unit. NAC/DUID are inherited, current NID is unknown,
// selected is always true and qualified is always false. Status0 is retained.
static inline bool p25_rx_early_encode(unsigned char out[64],const p25_rx_origin_event *event) {
    if(!out||!event)return false;
    p25_rx_origin_event e=*event;
    if(e.type!=P25_RX_ORIGIN_FAULT
       &&(e.chunk_first_sample>=P25_RX_EARLY_MAX_SAMPLES
          ||e.delivery_input_ordinal>=P25_RX_EARLY_MAX_SAMPLES))return false;
    if(e.type!=P25_RX_EARLY_STATUS)return p25_rx_origin_encode(out,&e);
    if(e.status>3u||e.evidence!=P25_RX_ORIGIN_SELECTED||e.lane>=10u||e.duid!=7u)return false;
    uint8_t raw_status=e.status;
    // Only the local validation copy is normalized. Ordinary STATUS0 remains
    // invalid, and the caller's event and destination stay intact on refusal.
    e.type=P25_RX_ORIGIN_STATUS;
    if(!e.status)e.status=1u;
    if(!p25_rx_origin_encode(out,&e))return false;
    out[40]=P25_RX_EARLY_STATUS;out[42]=raw_status;return true;
}
#endif
