// SPDX-License-Identifier: GPL-3.0-or-later
// Task-owned, bounded call history and common digital service addressing.
#ifndef RADIO_CALL_SERVICES_H
#define RADIO_CALL_SERVICES_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

typedef enum { RADIO_PROTOCOL_P25=1, RADIO_PROTOCOL_DMR=2 } radio_protocol;
typedef enum { RADIO_CALL_GROUP=0, RADIO_CALL_INDIVIDUAL=1 } radio_call_kind;
enum { RADIO_CALL_EMERGENCY=1u, RADIO_CALL_ENCRYPTED=2u, RADIO_CALL_FILTERED=4u,RADIO_CALL_TRUNKED=8u,
       RADIO_HISTORY_CAPACITY=32, RADIO_CONTACT_CAPACITY=96,
       RADIO_CONTACT_NAME_BYTES=24, RADIO_MESSAGE_TEXT_BYTES=80 };

typedef struct {
    uint32_t rx_hz,source,destination,start_ms,last_ms,sequence;
    uint16_t nac;
    uint8_t protocol,kind,cc,ts,flags;
} radio_heard_call;
typedef struct {
    radio_heard_call entries[RADIO_HISTORY_CAPACITY];
    uint32_t serial,next_sequence;
    uint8_t head,count;
    bool active;
} radio_call_history;

static inline bool radio_address_valid(unsigned protocol,unsigned kind,uint32_t id) {
    return (protocol==RADIO_PROTOCOL_P25 || protocol==RADIO_PROTOCOL_DMR)
        && kind<=RADIO_CALL_INDIVIDUAL && id
        && id<=((protocol==RADIO_PROTOCOL_P25 && kind==RADIO_CALL_GROUP) ? 0xffffu : 0xffffffu);
}
static inline const radio_heard_call *radio_history_get(const radio_call_history *h,unsigned newest) {
    return newest<h->count ? &h->entries[(h->head+RADIO_HISTORY_CAPACITY-newest)%RADIO_HISTORY_CAPACITY] : NULL;
}
static inline void radio_history_end(radio_call_history *h) {
    if(h->active) {h->active=false;++h->serial;}
}
// A validated identity creates one entry per call, not one per voice frame.
// The adapter passes explicit protocol call boundaries and closes on loss/retune.
// Unsigned millisecond differences tolerate the system clock wrapping.
static inline bool radio_history_observe(radio_call_history *h,const radio_heard_call *v,
                                         uint32_t now_ms,bool new_call) {
    if(!v || !v->source || v->source>0xffffffu || !radio_address_valid(v->protocol,v->kind,v->destination)
       || !v->rx_hz || (v->protocol==RADIO_PROTOCOL_P25 ? v->nac>0xfffu : v->cc>15u || v->ts<1u || v->ts>2u))return false;
    radio_heard_call *last=h->count ? &h->entries[h->head] : NULL;
    bool same=h->active && last && !new_call && last->protocol==v->protocol && last->kind==v->kind
        && last->rx_hz==v->rx_hz && last->source==v->source && last->destination==v->destination
        && last->nac==v->nac && last->cc==v->cc && last->ts==v->ts;
    if(!same) {
        h->head=h->count ? (uint8_t)((h->head+1u)%RADIO_HISTORY_CAPACITY) : 0;
        if(h->count<RADIO_HISTORY_CAPACITY)++h->count;
        last=&h->entries[h->head];*last=*v;last->start_ms=now_ms;
        last->sequence=++h->next_sequence;h->active=true;++h->serial;
    } else if(last->flags!=(uint8_t)(v->flags|(last->flags&RADIO_CALL_EMERGENCY)))++h->serial;
    // Emergency remains visible in the history even if later metadata clears it.
    last->flags=(uint8_t)(v->flags|(last->flags&RADIO_CALL_EMERGENCY));
    last->last_ms=now_ms;return true;
}

// Contacts use the V5 32-byte codeplug record. Prefer a protocol-specific name
// over a Both entry. Unit and group namespaces must never alias one another.
static inline bool radio_contact_name(const uint8_t contacts[][32],unsigned count,
        unsigned protocol,unsigned kind,uint32_t id,char out[RADIO_CONTACT_NAME_BYTES+1]) {
    const uint8_t *fallback=NULL;out[0]=0;
    if(!radio_address_valid(protocol,kind,id))return false;
    unsigned mask=protocol==RADIO_PROTOCOL_P25 ? 2u : 4u;
    for(unsigned i=0;i<count;++i) {
        const uint8_t *p=contacts[i];
        uint32_t candidate=(uint32_t)p[1]|(uint32_t)p[2]<<8|(uint32_t)p[3]<<16;
        if(!(p[0]&1u) || !(p[0]&mask) || ((p[0]&8u)!=0)!=(kind==RADIO_CALL_GROUP) || candidate!=id)continue;
        if((p[0]&6u)==mask) {fallback=p;break;}
        fallback=p;
    }
    if(!fallback)return false;
    memcpy(out,fallback+4,RADIO_CONTACT_NAME_BYTES);out[RADIO_CONTACT_NAME_BYTES]=0;return true;
}

// Messaging foundation only: the address/envelope is shared, the wire formats
// are not. An unimplemented backend must not accept or acknowledge a send.
typedef enum { RADIO_MESSAGE_DRAFT, RADIO_MESSAGE_QUEUED, RADIO_MESSAGE_ON_AIR,
    RADIO_MESSAGE_DELIVERED, RADIO_MESSAGE_FAILED, RADIO_MESSAGE_UNAVAILABLE } radio_message_state;
typedef struct {
    uint32_t source,destination,token;
    uint8_t protocol,kind;
    char text[RADIO_MESSAGE_TEXT_BYTES+1];
} radio_message;
typedef struct {bool receive,transmit,acknowledgments;} radio_message_capabilities;
static inline radio_message_capabilities radio_message_capability(unsigned protocol) {
    return (radio_message_capabilities){protocol==RADIO_PROTOCOL_P25 || protocol==RADIO_PROTOCOL_DMR,
        protocol==RADIO_PROTOCOL_P25 || protocol==RADIO_PROTOCOL_DMR,protocol==RADIO_PROTOCOL_DMR};
}
static inline bool radio_message_valid(const radio_message *m) {
    if(!m || !m->source || m->source>0xffffffu || !radio_address_valid(m->protocol,m->kind,m->destination))return false;
    for(unsigned i=0;i<=RADIO_MESSAGE_TEXT_BYTES;++i) {
        unsigned c=(unsigned char)m->text[i];
        if(!c)return i!=0;
        if(c<32u || c>126u)return false;
    }
    return false;
}
#endif
