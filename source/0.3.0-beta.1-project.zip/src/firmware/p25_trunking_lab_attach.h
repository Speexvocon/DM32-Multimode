// SPDX-License-Identifier: GPL-3.0-or-later
// Finite laboratory REGISTER/AFFILIATE receipts, never subscriber authority.
#ifndef P25_TRUNKING_LAB_ATTACH_H
#define P25_TRUNKING_LAB_ATTACH_H
#include "p25_trunking_lab_voice.h"

#define P25_LAB_ATTACH_TOTAL_US 8000000u
#define P25_LAB_ATTACH_RETURN_US 1000000u
#define P25_LAB_ATTACH_LEG_US (P25_LAB_EXCHANGE_WARM_US+P25_LAB_EXCHANGE_TX_US+P25_LAB_EXCHANGE_REPLY_US)
typedef enum {
    P25_LAB_ATTACH_IDLE,P25_LAB_ATTACH_REGISTER,P25_LAB_ATTACH_WAIT_REG,
    P25_LAB_ATTACH_AFFILIATE,P25_LAB_ATTACH_WAIT_AFF,P25_LAB_ATTACH_RETURN_PENDING,
    P25_LAB_ATTACH_RETURN,P25_LAB_ATTACH_READY,P25_LAB_ATTACH_ARM_PTT,
    P25_LAB_ATTACH_ARMED,P25_LAB_ATTACH_CANCELLED,P25_LAB_ATTACH_FAILED
} p25_lab_attach_phase;
typedef enum {
    P25_LAB_ATTACH_OK,P25_LAB_ATTACH_CONFIG,P25_LAB_ATTACH_OWNER,
    P25_LAB_ATTACH_EPOCH,P25_LAB_ATTACH_PTT,P25_LAB_ATTACH_PERMISSION,
    P25_LAB_ATTACH_EXPIRED,P25_LAB_ATTACH_REPLY,P25_LAB_ATTACH_RF_NOT_OFF,
    P25_LAB_ATTACH_TRANSPORT,P25_LAB_ATTACH_CANCEL
} p25_lab_attach_reason;
typedef struct {
    uint32_t sequence,rx_epoch,reply_us,assigned;
    uint16_t group;
    uint8_t type,response;
} p25_lab_attach_receipt;
typedef struct {
    // Sequence is the expected REGISTER token. GROUP uses the second next
    // token, skipping zero; every other base identity field stays immutable.
    p25_lab_exchange_owner owner;
    p25_lab_attach_receipt registration,affiliation;
    uint32_t start_epoch,start_us,prepared_epoch,prepared_us;
    uint32_t return_us,ready_us,ready_epoch,used_sequence;
    uint8_t phase,reason,needs_rf_off;
} p25_lab_attach;

bool p25_lab_attach_owned(const p25_lab_attach *s);
bool p25_lab_attach_start(p25_lab_attach *s,const p25_lab_exchange_owner *group_owner,
    uint32_t epoch,bool released,bool permission,bool rf_off,uint32_t now_us);
// current is always the original GROUP base identity/REGISTER sequence, even
// while the live probe is executing a different staged request/token.
bool p25_lab_attach_input(p25_lab_attach *s,const p25_lab_exchange_owner *current,
    bool released,bool permission,uint32_t now_us);
// Outputs are unchanged on refusal. These describe packets, not RF permits.
bool p25_lab_attach_leg_owner(const p25_lab_attach *s,p25_lab_exchange_owner *out);
bool p25_lab_attach_ptt_owner(const p25_lab_attach *s,p25_lab_exchange_owner *out);
bool p25_lab_attach_bind_prepared(p25_lab_attach *s,const p25_lab_exchange *prepared,
    const p25_lab_exchange_owner *current,uint32_t now_us);
// Exact accepted native reply only; ACK/QUEUED are not accepted receipts.
bool p25_lab_attach_observe(p25_lab_attach *s,const p25_lab_exchange *reply,
    const p25_lab_exchange_owner *current,bool released,bool permission,
    bool rf_off,uint32_t now_us);
bool p25_lab_attach_begin_return(p25_lab_attach *s,bool rf_off,uint32_t now_us);
bool p25_lab_attach_ready(p25_lab_attach *s,uint32_t epoch,bool raw_input,
    bool released,bool rf_off,uint32_t now_us);
// Spend READY before calling the existing one-call PTT arm. A refused handover
// fails the whole chain; it must not dispatch another control request.
bool p25_lab_attach_consume_ready(p25_lab_attach *s,const p25_lab_exchange_owner *current,
    uint32_t epoch,bool released,bool permission,bool rf_off,uint32_t now_us);
bool p25_lab_attach_armed(p25_lab_attach *s,const p25_lab_exchange_owner *ptt_owner,
    bool success,uint32_t now_us);
void p25_lab_attach_poll(p25_lab_attach *s,uint32_t now_us);
void p25_lab_attach_cancel(p25_lab_attach *s,p25_lab_attach_reason reason);
bool p25_lab_attach_abort_off(p25_lab_attach *s,bool rf_off,uint32_t now_us);
#endif
