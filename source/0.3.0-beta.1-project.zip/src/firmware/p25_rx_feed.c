// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx_feed.h"
#include <limits.h>
#include <string.h>

_Static_assert(sizeof(p25_rx_feed_chunk)<=64u,"Lean chunk exceeds fixed row budget");
_Static_assert(P25_RX_FEED_STORAGE_BYTES<=1024u,"Lean feed exceeds1KiB arena budget");
static uint16_t get16(const unsigned char *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static uint32_t get32(const unsigned char *p) {return (uint32_t)get16(p)|(uint32_t)get16(p+2)<<16;}
static void put16(unsigned char *p,uint16_t n) {p[0]=(unsigned char)n;p[1]=(unsigned char)(n>>8);}
static void put32(unsigned char *p,uint32_t n) {put16(p,(uint16_t)n);put16(p+2,(uint16_t)(n>>16));}
static bool disjoint(const void *a,size_t na,const void *b,size_t nb) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    return x<=UINTPTR_MAX-na&&y<=UINTPTR_MAX-nb&&(x+na<=y||y+nb<=x);
}
static unsigned char *row(const p25_rx_feed *s,uint32_t ordinal) {
    return s->storage+((ordinal/16u)%P25_RX_FEED_RING_ROWS)*P25_RX_FEED_ROW_BYTES;
}
void p25_rx_feed_init(p25_rx_feed *s) {if(s)memset(s,0,sizeof *s);}
bool p25_rx_feed_active(const p25_rx_feed *s) {
    return p25_rx_feed_producing(s)||(s&&s->state==P25_RX_FEED_DRAINING);
}
bool p25_rx_feed_producing(const p25_rx_feed *s) {
    return s&&(s->state==P25_RX_FEED_WAIT_IRQ||s->state==P25_RX_FEED_RUNNING);
}
static bool fail(p25_rx_feed *s,unsigned why) {
    if(p25_rx_feed_active(s)) {s->faults|=(uint16_t)why;s->state=P25_RX_FEED_FAULT;}
    return false;
}
static bool fresh(p25_rx_feed *s,uint32_t now) {
    if(s->consumed>s->produced||((s->produced|s->consumed)&15u)
       ||s->produced-s->consumed>P25_RX_FEED_RING_ROWS*16u)return fail(s,P25_RX_FEED_META);
    if(s->consumed==s->produced)return true;
    const unsigned char *p=row(s,s->consumed);
    if(get32(p+32)!=s->consumed)return fail(s,P25_RX_FEED_META);
    uint32_t age=now-get32(p+40);
    if(age>INT32_MAX)return fail(s,P25_RX_FEED_CLOCK);
    if(age>s->max_queue_us)s->max_queue_us=age;
    return age<=s->max_age_us||fail(s,P25_RX_FEED_STALE);
}
static bool timely(p25_rx_feed *s,uint32_t now) {
    if(s->state==P25_RX_FEED_DRAINING)return fresh(s,now);
    uint32_t age=now-(s->state==P25_RX_FEED_WAIT_IRQ?s->armed_us:s->last_irq_us);
    if(age>INT32_MAX)return fail(s,P25_RX_FEED_CLOCK);
    if(age>(s->state==P25_RX_FEED_WAIT_IRQ?P25_RX_FEED_FIRST_IRQ_TIMEOUT_US:34000u))
        return fail(s,P25_RX_FEED_MISSING_IRQ);
    return fresh(s,now);
}
bool p25_rx_feed_start(p25_rx_feed *s,void *storage,size_t bytes,
    const p25_rx_feed_config *config,uint32_t epoch,uint32_t now) {
    if(!s||!storage||!config||p25_rx_feed_active(s)||bytes<P25_RX_FEED_STORAGE_BYTES
       ||!epoch||(s->stream_epoch&&epoch<=s->stream_epoch)
       ||config->guard_us<P25_RX_FEED_GUARD_US||config->guard_us>8000u
       ||config->max_age_us<1000u||config->max_age_us>P25_RX_FEED_MAX_AGE_US
       ||(config->sample_limit&&(config->sample_limit<256u||config->sample_limit>8192u
           ||config->sample_limit%256u))
       ||!disjoint(s,sizeof *s,storage,P25_RX_FEED_STORAGE_BYTES))return false;
    p25_rx_feed_config c=*config;
    p25_rx_feed_init(s);s->storage=storage;s->guard_us=c.guard_us;s->max_age_us=c.max_age_us;
    s->stream_epoch=epoch;s->armed_us=now;s->sample_limit=c.sample_limit;
    s->state=P25_RX_FEED_WAIT_IRQ;return true;
}
bool p25_rx_feed_irq(p25_rx_feed *s,unsigned half,uint32_t now) {
    if(!p25_rx_feed_producing(s))return false;
    if(s->irq_serial>=UINT32_MAX-1u)return fail(s,P25_RX_FEED_COUNTER);
    ++s->irq_serial;
    unsigned why=0;
    uint32_t age=now-(s->irq_count?s->last_irq_us:s->armed_us);
    if(half!=1u&&half!=2u)why=P25_RX_FEED_BAD_IRQ;
    else if(age>INT32_MAX)why=P25_RX_FEED_CLOCK;
    else if(!s->irq_count&&age>P25_RX_FEED_FIRST_IRQ_TIMEOUT_US)why=P25_RX_FEED_MISSING_IRQ;
    else if(s->irq_count&&half==s->last_half)why=P25_RX_FEED_IRQ_SEQUENCE;
    else if(s->irq_count&&(age<30000u||age>34000u))why=P25_RX_FEED_IRQ_CLOCK;
    else if(s->irq_count>=UINT32_MAX/256u+1u)why=P25_RX_FEED_COUNTER;
    else if(s->irq_count>1u&&s->produced<(s->irq_count-1u)*256u)why=P25_RX_FEED_OVERWRITTEN;
    if(why) {fail(s,why);++s->irq_serial;return false;}
    if(!fresh(s,now)) {++s->irq_serial;return false;}
    s->previous_irq_us=s->last_irq_us;s->last_irq_us=now;s->last_half=(uint8_t)half;
    ++s->irq_count;++s->irq_serial;s->state=P25_RX_FEED_RUNNING;s->pending_wait=false;return true;
}
p25_rx_feed_step_result p25_rx_feed_step(p25_rx_feed *s,const p25_rx_feed_io *io,uint32_t now) {
    if(!p25_rx_feed_active(s))return P25_RX_FEED_REVOKED;
    if(s->state==P25_RX_FEED_DRAINING)
        return fresh(s,now)?P25_RX_FEED_WAIT:P25_RX_FEED_REVOKED;
    if(!io||!io->read_byte||!io->clock_us||!io->half_pending) {
        fail(s,P25_RX_FEED_BAD_IO);return P25_RX_FEED_REVOKED;
    }
    if(s->have_step&&(uint32_t)(now-s->last_step_us)>INT32_MAX) {
        fail(s,P25_RX_FEED_CLOCK);return P25_RX_FEED_REVOKED;
    }
    s->have_step=true;s->last_step_us=now;
    if(!timely(s,now))return P25_RX_FEED_REVOKED;
    if(s->state==P25_RX_FEED_WAIT_IRQ)return P25_RX_FEED_WAIT;
    s->pending_wait=io->half_pending(io->context);
    if(s->pending_wait)return P25_RX_FEED_WAIT;
    uint32_t serial=s->irq_serial,count=s->irq_count,irq=s->last_irq_us,previous=s->previous_irq_us;
    unsigned half=s->last_half;
    if((serial&1u)||!count||half<1u||half>2u) {
        fail(s,P25_RX_FEED_META);return P25_RX_FEED_REVOKED;
    }
    uint32_t ordinal=s->produced,index=ordinal/256u,current=count-1u,age=now-irq;
    unsigned offset=ordinal%256u,target=3u-half;
    bool tail=index+1u==current;
    if(index!=current&&!tail) {fail(s,P25_RX_FEED_OVERWRITTEN);return P25_RX_FEED_REVOKED;}
    if(ordinal>UINT32_MAX-16u) {fail(s,P25_RX_FEED_COUNTER);return P25_RX_FEED_REVOKED;}
    if(age>=32000u||(!tail&&age<(offset+16u)*125u+s->guard_us))return P25_RX_FEED_WAIT;
    if(ordinal-s->consumed>=P25_RX_FEED_RING_ROWS*16u) {
        fail(s,P25_RX_FEED_RING_FULL);return P25_RX_FEED_REVOKED;
    }
    if(tail)target=half;
    int16_t samples[16];uint32_t begin=io->clock_us(io->context);bool torn=false;
    unsigned base=(target-1u)*512u+offset*2u;
    for(unsigned i=0;i<16u;++i) {
        uint8_t hi=io->read_byte(io->context,base+2u*i);
        uint8_t lo=io->read_byte(io->context,base+2u*i+1u);
        if(hi!=io->read_byte(io->context,base+2u*i))torn=true;
        samples[i]=(int16_t)((uint16_t)hi<<8|lo);
    }
    uint32_t end=io->clock_us(io->context);bool pending=io->half_pending(io->context);
    if(!p25_rx_feed_active(s))return P25_RX_FEED_REVOKED;
    ++s->read_calls;
    s->read_bytes=s->read_bytes>UINT32_MAX-48u?UINT32_MAX:s->read_bytes+48u;
    if(end-begin<=INT32_MAX&&end-begin>s->max_read_us)s->max_read_us=end-begin;
    unsigned why=0;
    if(torn)why|=P25_RX_FEED_TORN;
    if(pending||serial!=s->irq_serial||count!=s->irq_count)why|=P25_RX_FEED_IRQ_READ;
    if(begin-now>INT32_MAX||end-begin>INT32_MAX)why|=P25_RX_FEED_CLOCK;
    if(end-irq>=32000u)why|=P25_RX_FEED_OVERWRITTEN;
    if(why) {fail(s,why);return P25_RX_FEED_REVOKED;}
    if(!fresh(s,end))return P25_RX_FEED_REVOKED;
    unsigned char *p=row(s,ordinal);
    for(unsigned i=0;i<16u;++i)put16(p+2u*i,(uint16_t)samples[i]);
    put32(p+32,ordinal);put32(p+36,begin);put32(p+40,end);
    put32(p+44,tail?previous:irq);put32(p+48,tail?count-1u:count);
    put16(p+52,(uint16_t)offset);p[54]=(uint8_t)target;p[55]=0;
    s->produced=ordinal+16u;
    if(s->sample_limit&&s->produced==s->sample_limit)s->state=P25_RX_FEED_DRAINING;
    return P25_RX_FEED_PUBLISHED;
}
bool p25_rx_feed_pop(p25_rx_feed *s,p25_rx_feed_chunk *out,uint32_t now) {
    if(!p25_rx_feed_active(s)||!out)return false;
    if(!disjoint(out,sizeof *out,s,sizeof *s)
       ||!disjoint(out,sizeof *out,s->storage,P25_RX_FEED_STORAGE_BYTES))return false;
    if(!timely(s,now)||s->consumed==s->produced)return false;
    const unsigned char *p=row(s,s->consumed);p25_rx_feed_chunk value;
    memset(&value,0,sizeof value);
    for(unsigned i=0;i<16u;++i)value.samples[i]=(int16_t)get16(p+2u*i);
    value.first_sample=get32(p+32);value.read_begin_us=get32(p+36);value.read_end_us=get32(p+40);
    value.origin_irq_us=get32(p+44);value.origin_irq_count=get32(p+48);
    value.sample_offset=get16(p+52);value.target_half=p[54];
    *out=value;s->consumed+=16u;
    if(s->state==P25_RX_FEED_DRAINING&&s->consumed==s->produced)s->state=P25_RX_FEED_COMPLETE;
    return true;
}
uint32_t p25_rx_feed_next_delay(const p25_rx_feed *s,uint32_t now) {
    if(!p25_rx_feed_producing(s))return 0;
    uint32_t delay=500u;
    if(s->state==P25_RX_FEED_RUNNING&&!s->pending_wait&&s->irq_count) {
        uint32_t age=now-s->last_irq_us,index=s->produced/256u,current=s->irq_count-1u;
        unsigned due=(s->produced%256u+16u)*125u+s->guard_us;
        if(index==current&&age<32000u&&due<32000u)delay=age>=due?1u:due-age;
    }
    if(s->consumed<s->produced) {
        uint32_t age=now-get32(row(s,s->consumed)+40);
        if(age>s->max_age_us)return 1u;
        uint32_t fresh_delay=s->max_age_us-age+1u;
        if(fresh_delay<delay)delay=fresh_delay;
    }
    return delay;
}
void p25_rx_feed_stop(p25_rx_feed *s) {
    if(p25_rx_feed_active(s))s->state=P25_RX_FEED_STOPPED;
}
