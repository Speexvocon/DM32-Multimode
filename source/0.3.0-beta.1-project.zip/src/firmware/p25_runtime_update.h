// SPDX-License-Identifier: GPL-3.0-or-later
// Unified-controller hooks. Included after its normal owners are defined.
#ifndef P25_RUNTIME_UPDATE_H
#define P25_RUNTIME_UPDATE_H
#if DM32_RUNTIME_STUB_ENTRY
extern void hrc_vocoder_park(void);
extern void hrc_host_uart_drain(void);
#ifndef P25_RUNTIME_STUB_MEMORY
#define P25_RUNTIME_STUB_MEMORY ((uint8_t *)(uintptr_t)P25_STUB_LOAD_ADDR)
#endif
static p25_stub_entry runtime_update;
static p25_stub_state runtime_update_shown=P25_STUB_IDLE;
static bool runtime_update_ptt_released(void) {
    // DM32 shares PTT with UART0 RX. A serial zero is not a key press;
    // the board's shared-PTT filter qualifies sustained lows after UART idle.
    return ptt_mask && !(board.input->scan()&ptt_mask);
}
static bool runtime_update_admit(void *context) {
    (void)context;
    return normal_mode && features_ready && board.system && board.system->enter_stub
        && runtime_update_ptt_released() && board.power->switch_on()
        && !call_active && !hardware_running && !prepared && !radio_busy(&control)
        && !digital_dmr.tx_armed && !digital_dmr.data_armed
        && !rx_job && !rx_sampling && !pcm_owner && !apps_active() && !applet_owns_radio
        && !cps_link && !cps_active && !editing && !menu_open && !rx_lab
        && !message_packet_tx && !message_active_id && !telemetry_pending()
        && !command_deferred && !pref_dirty;
}
static void runtime_update_force_safe(void *context) {
    (void)context;board_rf_safe();hardware_stop();
    if(board.audio) {board.audio->stop();board.audio->speaker_pcm(false);}
    board.radio->audio(false);
}
static bool runtime_update_quiesce(void *context) {
    (void)context;
#if DM32_TRUNK_SUBSCRIBER
    trunk_preload_cc_cancel();
    trunk_lab_return_cancel();
#endif
    // The loader owns the controller before this callback. Stop owners without
    // adopting a scan hit or persisting a temporary channel selection.
    (void)feature_stop_scan(false);feature_pause();
    if(rx_job)rx_end("updating");
    if(apps_active())apps_stop(false);
    mon_enabled=false;armed=session_enabled=false;
    control.cancel=true;control.tx_enabled=false;
    runtime_update_force_safe(NULL);
    call_active=audio_on=prepared=false;pcmq.accepting=false;
    telemetry_reset();command_deferred_reset();
    if(!imbe_bench_release())return false;
    // Only accepted BEGIN reaches this permanent park. INFO/VERSION never do.
    hrc_vocoder_park();
    reason="updating";
    return runtime_update_ptt_released() && !hardware_running;
}
static bool runtime_update_safe(void *context) {
    (void)context;
    return runtime_update_ptt_released() && board.power->switch_on()
        && !hardware_running && !call_active && !prepared && !audio_on
        && !digital_dmr.owned && !analog_fm.owned && !mon_running
        && !pcm_owner && !apps_active() && !cps_link && !cps_active;
}
static const char *runtime_update_codec(void *context) {
    (void)context;return hal_vocoder_id(board.vocoder);
}
static bool runtime_update_write(void *context,const uint8_t *bytes,size_t n) {
    (void)context;
    // Never splice binary replies into another owner's text/audio stream.
    if(!p25_stub_entry_owned(&runtime_update) && (telemetry_pending() || command_deferred
       || cps_link || cps_active || pcm_owner || apps_active()
       || command_tx_critical(!runtime_update_ptt_released())))return false;
    return board.host_port->write(bytes,n)==n;
}
static bool runtime_update_drain(void *context) {
    (void)context;hrc_host_uart_drain();return true;
}
static bool runtime_update_enter(void *context,uint32_t entry) {
    (void)context;return board.system && board.system->enter_stub && board.system->enter_stub(entry);
}
static bool runtime_update_init(void) {
    if(!board.system || !board.system->enter_stub)return false;
    p25_stub_config config={.region=P25_RUNTIME_STUB_MEMORY,.load_addr=P25_STUB_LOAD_ADDR,
        .region_bytes=P25_STUB_REGION_BYTES,.board="DM-32UV",.git=BENCH_GIT,
        .codec=runtime_update_codec,.admit=runtime_update_admit,.quiesce=runtime_update_quiesce,
        .safe=runtime_update_safe,.force_safe=runtime_update_force_safe,.write=runtime_update_write,
        .drain=runtime_update_drain,.enter=runtime_update_enter,.image_ok=board.system->stub_image_ok};
    runtime_update_shown=P25_STUB_IDLE;
    return p25_stub_entry_init(&runtime_update,&config);
}
static void runtime_update_screen(void) {
    if(runtime_update_shown==runtime_update.state)return;
    runtime_update_shown=runtime_update.state;
    if(!display_ok)return;
    gfx_frame_begin();gfx_clear(P25_UI_BG);p25_ui_palette();
    gfx_fill(0,0,gfx_width(),4,P25_UI_BG);
    p25_ui_text(&font_12x24,8,44,224,"Firmware update",P25_UI_FG);
    gfx_text(&font_8x16,8,96,runtime_update.state==P25_STUB_FAILED ? "Restart radio to exit" : "PC owns radio / RF off",P25_UI_MUTED);
    // This exclusive owner already stopped RF/audio. Finish its one-time
    // installer screen before handing control to the RAM loader.
    bool deferred=radio_gfx_deferred();radio_gfx_defer(false);
    gfx_flush();radio_gfx_defer(deferred);board.display->set_backlight(80);
}
static void runtime_update_poll(void) {
    p25_stub_entry_poll(&runtime_update,hal_millis());
    runtime_update_screen();
    board.power->led(LED_RED,false);board.power->led(LED_GREEN,false);
    if(!board.power->switch_on()) {runtime_update_force_safe(NULL);board.power->latch(false);}
}
#endif
#endif
