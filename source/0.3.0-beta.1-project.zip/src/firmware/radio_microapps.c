// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_microapps.h"
#include <stddef.h>
#include <string.h>

typedef struct { const char *text; unsigned length; } token_t;
typedef void (*app_command_t)(radio_microapps_t *,const token_t *,unsigned);
typedef struct { const char *name,*description; app_command_t command; } app_t;

static void emit(radio_microapps_t *apps,const char *line) {
    if(apps->hal.emit)apps->hal.emit(apps->opaque,line);
}
static char upper(char c) {return c>='a' && c<='z' ? (char)(c-'a'+'A') : c;}
static bool equal(token_t token,const char *text) {
    unsigned i=0;
    while(i<token.length && text[i] && upper(token.text[i])==text[i])++i;
    return i==token.length && !text[i];
}
static unsigned append(char *out,unsigned position,const char *text) {
    while(*text)out[position++]=*text++;
    out[position]=0;return position;
}
static unsigned decimal(char *out,unsigned position,uint32_t value) {
    char digits[10];unsigned n=0;
    do {digits[n++]=(char)('0'+value%10u);value/=10u;}while(value);
    while(n)out[position++]=digits[--n];
    out[position]=0;return position;
}
static void help(radio_microapps_t *apps) {
    emit(apps,"APPS | APP HELP");
    emit(apps,"APP PCM OPEN RAW|VOICE FM|NFM|P25|DMR RX|TX Hz  (use dm32-pcm.py)");
    emit(apps,"APP SAME START [Hz]  (default 162550000; seven NOAA channels)");
    emit(apps,"APP SAME STATUS | APP SAME LAST");
    emit(apps,"APP SAME WATCH ON | APP SAME WATCH OFF");
    emit(apps,"APP STOP  (restore normal radio operation)");
}
static bool frequency(token_t token,uint32_t *hz) {
    uint32_t value=0;
    if(!token.length || token.length>10u)return false;
    for(unsigned i=0;i<token.length;++i) {
        char c=token.text[i];
        if(c<'0' || c>'9')return false;
        unsigned digit=(unsigned)(c-'0');
        if(value>(UINT32_MAX-digit)/10u)return false;
        value=value*10u+digit;
    }
    if(!radio_microapps_same_frequency_valid(value))return false;
    *hz=value;return true;
}
static void status(radio_microapps_t *apps) {
    char line[100];unsigned p=0;
    p=append(line,p,apps->active==RADIO_MICROAPP_SAME ? "SAME RUNNING RX_ONLY HZ=" : "SAME IDLE HZ=");
    p=decimal(line,p,apps->frequency_hz);
    p=append(line,p," EVENTS=");p=decimal(line,p,apps->headers);
    p=append(line,p,apps->watch ? " WATCH=ON" : " WATCH=OFF");
    (void)append(line,p,apps->last[0] ? (apps->last_confirmed ? " LAST=CONFIRMED" : " LAST=UNCONFIRMED") : " LAST=NONE");
    emit(apps,line);
    if(apps->hal.status)apps->hal.status(apps->opaque);
}
static void last(radio_microapps_t *apps) {
    char line[RADIO_MICROAPPS_HEADER_MAX+24u];
    if(!apps->last[0]) {emit(apps,"SAME LAST NONE");return;}
    unsigned p=append(line,0,apps->last_confirmed ? "SAME CONFIRMED " : "SAME UNCONFIRMED ");
    (void)append(line,p,apps->last);emit(apps,line);
}
static void same_command(radio_microapps_t *apps,const token_t *tokens,unsigned count) {
    if(!count) {status(apps);return;}
    if(equal(tokens[0],"START") && (count==1u || count==2u)) {
        uint32_t hz=RADIO_MICROAPPS_SAME_DEFAULT_HZ;
        if(count==2u && !frequency(tokens[1],&hz)) {
            emit(apps,"APP ERROR frequency: use Hz 162400000..162550000 in 25000-Hz steps");return;
        }
        if(apps->active!=RADIO_MICROAPP_NONE) {
            if(apps->active==RADIO_MICROAPP_SAME && apps->frequency_hz==hz)status(apps);
            else emit(apps,"APP ERROR busy: APP STOP before changing frequency");
            return;
        }
        if(!apps->hal.start_same || !apps->hal.stop || !apps->hal.start_same(apps->opaque,hz)) {
            emit(apps,"APP ERROR SAME start failed; radio state restored");return;
        }
        apps->active=RADIO_MICROAPP_SAME;apps->frequency_hz=hz;
        apps->headers=0;apps->last[0]=0;apps->last_confirmed=false;
        status(apps);return;
    }
    if(equal(tokens[0],"STATUS") && count==1u) {status(apps);return;}
    if(equal(tokens[0],"LAST") && count==1u) {last(apps);return;}
    if(equal(tokens[0],"WATCH") && count==2u && (equal(tokens[1],"ON") || equal(tokens[1],"OFF"))) {
        apps->watch=equal(tokens[1],"ON");emit(apps,apps->watch ? "SAME WATCH ON" : "SAME WATCH OFF");return;
    }
    emit(apps,"APP ERROR syntax: APP SAME START [Hz] | STATUS | LAST | WATCH ON/OFF");
}
static const app_t registry[]={
    {"SAME","SAME - NOAA SAME header decoder (receive only)",same_command}
};

void radio_microapps_init(radio_microapps_t *apps,const radio_microapps_hal_t *hal,void *opaque) {
    if(!apps)return;
    memset(apps,0,sizeof *apps);if(hal)apps->hal=*hal;
    apps->opaque=opaque;apps->watch=true;
}
bool radio_microapps_same_frequency_valid(uint32_t hz) {
    return hz>=162400000u && hz<=162550000u && !((hz-162400000u)%25000u);
}
void radio_microapps_stop(radio_microapps_t *apps) {
    if(!apps || apps->active==RADIO_MICROAPP_NONE)return;
    apps->active=RADIO_MICROAPP_NONE;apps->frequency_hz=0;
    if(apps->hal.stop)apps->hal.stop(apps->opaque);
}
bool radio_microapps_command(radio_microapps_t *apps,const char *line) {
    if(!apps || !line)return false;
    while(*line==' ' || *line=='\t')++line;
    unsigned prefix=0;
    while(prefix<4u && line[prefix] && line[prefix]!=' ' && line[prefix]!='\t' && line[prefix]!='\r' && line[prefix]!='\n')++prefix;
    token_t name={line,prefix};
    bool plural=equal(name,"APPS");
    if(!plural && !equal(name,"APP"))return false;
    // Reject APPEND/APPSX and other longer, non-namespace first words.
    if(line[prefix] && line[prefix]!=' ' && line[prefix]!='\t' && line[prefix]!='\r' && line[prefix]!='\n')return false;
    unsigned length=0;
    while(length<=RADIO_MICROAPPS_COMMAND_MAX && line[length])++length;
    if(length>RADIO_MICROAPPS_COMMAND_MAX) {emit(apps,"APP ERROR command too long");return true;}
    while(length && (line[length-1u]=='\r' || line[length-1u]=='\n'))--length;
    token_t tokens[5];unsigned count=0,position=prefix;
    while(position<length) {
        while(position<length && (line[position]==' ' || line[position]=='\t'))++position;
        if(position==length)break;
        if(count==5u) {emit(apps,"APP ERROR too many arguments");return true;}
        unsigned start=position;
        while(position<length && line[position]!=' ' && line[position]!='\t') {
            if((unsigned char)line[position]<32u || (unsigned char)line[position]>126u) {
                emit(apps,"APP ERROR invalid command character");return true;
            }
            ++position;
        }
        tokens[count++]=(token_t){line+start,position-start};
    }
    if(plural) {
        if(count)emit(apps,"APP ERROR syntax: APPS");
        else for(unsigned i=0;i<sizeof registry/sizeof registry[0];++i)emit(apps,registry[i].description);
        return true;
    }
    if(!count || (count==1u && equal(tokens[0],"HELP"))) {help(apps);return true;}
    if(count==1u && equal(tokens[0],"STOP")) {
        radio_microapps_stop(apps);emit(apps,"APP STOPPED; normal radio operation restored");return true;
    }
    for(unsigned i=0;i<sizeof registry/sizeof registry[0];++i) {
        if(equal(tokens[0],registry[i].name)) {registry[i].command(apps,tokens+1,count-1u);return true;}
    }
    emit(apps,"APP ERROR unknown app or command; use APP HELP");return true;
}
bool radio_microapps_publish_same(radio_microapps_t *apps,const char *header,unsigned length,bool confirmed) {
    if(!apps || apps->active!=RADIO_MICROAPP_SAME || !header || !length || length>RADIO_MICROAPPS_HEADER_MAX)return false;
    for(unsigned i=0;i<length;++i)if((unsigned char)header[i]<32u || (unsigned char)header[i]>126u)return false;
    memcpy(apps->last,header,length);apps->last[length]=0;apps->last_confirmed=confirmed;
    if(apps->headers<UINT32_MAX)++apps->headers;
    if(apps->watch)last(apps);
    return true;
}
