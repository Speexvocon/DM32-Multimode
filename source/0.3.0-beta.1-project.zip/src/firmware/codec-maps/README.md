# Experimental codec metadata

`dm32-nrfb-050.json` is copied byte for byte from RadioFoundry commit
[`f07134f2576f286e95a839b3e4cea791ce4f1a8d`](https://github.com/RadioFoundry/RadioFoundry/blob/f07134f2576f286e95a839b3e4cea791ce4f1a8d/tools/rfoundry/rfoundry/codec_maps/dm32/dm32-nrfb-050.json).
The upstream codec map format is MIT licensed; these are addresses, lengths,
relocations and hashes, with no codec bytes. SHA-256 of the copied JSON:
`bf2aac3eb338144a0f073dd87a445df86a831707d3a54cae4513200a578bf6f3`.

Its codec occupies the existing 83,456-byte executable window. Its 12,152-byte
table window starts at `0x18000EC0` and ends at `0x18003E38`, 16 bytes beyond
the classic board reservation. The experimental linker overlay reserves that
additional modem SRAM without changing application RAM or program flash.

The map has no known full stock update hash. Offline identification requires a
complete program dump and exact code and table fingerprints. RF-B remains
unqualified and incompatible in the public installer. This metadata does not
enable a release or bypass that compatibility gate.
