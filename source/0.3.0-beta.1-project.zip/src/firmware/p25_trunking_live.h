// SPDX-License-Identifier: GPL-3.0-or-later
// Qualified diagnostic and explicitly experimental normal subscriber adapters.
// Experimental operation never upgrades the measured timing qualifications.
#ifndef P25_TRUNKING_LIVE_H
#define P25_TRUNKING_LIVE_H
#if DM32_TRUNK_SUBSCRIBER
#include "p25_trunking_backend.h"
static p25_trunking_backend trunk_subscriber_backend;
static p25_trunking_session_clock trunk_access_clock(void) {
    // This is the last consumed recorder ordinal, NOT the current air time.
    // Preserve it for diagnostics without upgrading it to an RF clock.
    p25_trunking_session_clock clock={.now_tick=trunk_sample_tick,
        .stream_epoch=trunk_stream_epoch,.lane_epoch=monitor.demod.lane_epoch,
        .origin_qualified=false,.rate_qualified=false,.start_edge_qualified=false};
    return clock;
}
#include "p25_trunking_subscriber_live.h"
static void trunk_access_stop(void) {
    trunk_subscriber_cancel();
    p25_trunking_session_stop(&trunk_session);
}
static void trunk_access_status_symbol(const p25_demod_status *status,void *context) {
    (void)context;
    trunk_preload_cc_status(status);
    if(trunk_subscriber_active()) {trunk_subscriber_status(status);return;}
    if(!trunk_session.running)return;
    p25_trunking_slot_observation observation={.sample_tick=status->sample_tick,
        .stream_epoch=status->stream_epoch,.lane_epoch=status->lane_epoch,
        .status=status->status,.selected=status->selected,
        .qualified=status->qualified && status->duid==7u && trunk_enabled
            && mon_running && receiver_frequency()==trunk_session.config.control_rx_hz
            && status->nac==trunk_session.config.subscriber.nac};
    (void)p25_trunking_session_observe(&trunk_session,&observation);
}
static bool trunk_access_start(void) {
    // Volatile, isolated test-site identity only. No saved channel or native
    // default changes, automatic registration, or qualification override.
    if(trunk_session.running || frequency!=TRUNK_PROBE_RX_HZ
       || control.nac!=TRUNK_PROBE_NAC || !control.talkgroup || control.talkgroup>65535u)
        return false;
    if(!trunk_start())return false;
    // PROM is a saved receive preference, not permission to adopt a foreign
    // site's identity for an explicitly configured subscriber session.
    trunk.configured_nac=trunk.learned_nac=TRUNK_PROBE_NAC;trunk.have_nac=true;
    p25_trunking_session_config config={
        .subscriber={.wacn=TRUNK_PROBE_WACN,.system=TRUNK_PROBE_SYSTEM,
            .radio_id=control.source_id,.group=(uint16_t)control.talkgroup,.nac=TRUNK_PROBE_NAC,
            .rfss=1,.site=1,.min_hz=136000000u,.max_hz=480000000u,
            .tot_ms=feature_tx_tot()*1000u},
        .control_rx_hz=frequency,.slot_tolerance_ticks=3u,.slot_max_age_ticks=300u,
        // The existing renderer's smallest software lead is 72 bytes/60 ms.
        // Even this lower bound exceeds a minimum37.5-ms access slot before
        // adding the32.917-ms ISP. Do not hide that with a future-idle guess.
        .actuation_ticks=2880u,.burst_ticks=P25_TRUNK_SESSION_ISP_TICKS,
        .end_guard_ticks=24u,.max_start_delay_ticks=0u,
        .contention_skip=(uint8_t)((control.source_id^hrc_micros())&31u),
        .contention_wait_ticks=P25_TRUNK_SLOT_MAX_WAIT_TICKS};
    if(!p25_trunking_session_start(&trunk_session,&config,trunk_now_ms())) {
        trunk_stop("access_config");return false;
    }
    trunk_reason="access_timing_unqualified";return true;
}
static void trunk_access_poll(bool down) {
    if(trunk_subscriber_active()) {trunk_subscriber_poll(down);return;}
    p25_trunking_session_clock clock=trunk_access_clock();
    bool permission=!owner_tx_inhibit && !(channel_record[12]&16u) && bf_cal_valid()
        && ui_battery_valid && ui_battery_mv>=board.battery_critical_mv
        && !control.cancel && !call_active && !prepared && !hardware_running
        && !digital_dmr.tx_armed && !digital_dmr.data_armed;
    uint32_t now=trunk_now_ms();
    p25_trunking_session_poll(&trunk_session,now,&clock,permission,down);
    p25_trunking_session_action action;
    if(p25_trunking_session_take(&trunk_session,&action,now,&clock)) {
        // Independent platform barrier: this build has no qualified RF
        // dispatcher. A policy regression must never reach ordinary voice TX.
        board_rf_safe();
        (void)p25_trunking_session_result(&trunk_session,action.access.id,false,now);
        trunk_reason="access_backend_unqualified";
    }
}
#endif
#endif
