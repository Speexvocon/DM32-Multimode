// SPDX-License-Identifier: GPL-3.0-or-later
// Pure subscriber-session coordinator. No RF, serial, storage or allocation.
#ifndef P25_TRUNKING_SESSION_H
#define P25_TRUNKING_SESSION_H
#include "p25_trunking.h"
#include "p25_trunking_access.h"
#include "p25_trunking_slot.h"
#include <stddef.h>

#define P25_TRUNK_SESSION_ISP_BITS 316u
#define P25_TRUNK_SESSION_ISP_BYTES 45u
#define P25_TRUNK_SESSION_ISP_TICKS 1580u // 158 symbols at ten 48-kHz samples.

typedef enum {
    P25_TRUNK_SESSION_OFF,P25_TRUNK_SESSION_WAIT_SITE,
    P25_TRUNK_SESSION_IDENTITY,P25_TRUNK_SESSION_MAPPING,
    P25_TRUNK_SESSION_TIMING_UNQUALIFIED,P25_TRUNK_SESSION_START_EDGE_UNQUALIFIED,
    P25_TRUNK_SESSION_NO_PHASE,P25_TRUNK_SESSION_BACKOFF,
    P25_TRUNK_SESSION_DOES_NOT_FIT,P25_TRUNK_SESSION_PHYSICAL_PERMISSION,
    P25_TRUNK_SESSION_READY,P25_TRUNK_SESSION_STALE,P25_TRUNK_SESSION_FAILED
} p25_trunking_session_gate;

typedef struct {
    p25_trunking_access_config subscriber;
    uint32_t control_rx_hz,contention_wait_ticks;
    uint16_t slot_tolerance_ticks,slot_max_age_ticks;
    uint16_t actuation_ticks,burst_ticks,end_guard_ticks,max_start_delay_ticks;
    uint8_t contention_skip;
} p25_trunking_session_config;

typedef struct {
    uint64_t now_tick;
    uint32_t stream_epoch,lane_epoch;
    // These are independent, explicitly measured platform qualifications.
    // A nominal 48-kHz recorder ordinal, task arrival time or CPU profiling
    // counter cannot set them. No serial command should override them.
    bool origin_qualified,rate_qualified,start_edge_qualified;
} p25_trunking_session_clock;

typedef struct {
    p25_trunking_access_action access;
    p25_trunking_slot_budget budget;
    uint64_t lease_tick;
    uint32_t lease_ms,stream_epoch,lane_epoch;
    uint16_t valid_bits;
    uint8_t wire_bytes;
    // Complete software TSDU vector; only the first316 bits are meaningful in
    // a finite ISP. The trailing44 pad bits are not authorization to radiate.
    uint8_t tsdu[P25_TRUNK_SESSION_ISP_BYTES];
} p25_trunking_session_action;

typedef struct {
    p25_trunking_session_config config;
    p25_trunking map;
    p25_trunking_access access;
    p25_trunking_slot slot;
    p25_trunking_slot_backoff backoff;
    p25_trunking_session_clock clock;
    p25_trunking_slot_budget budget;
    uint64_t gate_tick,last_boundary_used;
    uint32_t gate_ms,network_ms,site_ms,backoff_serial;
    uint16_t network_channel,site_channel,voice_channel;
    p25_trunking_session_gate gate;
    bool running,have_network,have_site,site_qualified,clock_qualified,activated;
    bool start_edge_qualified,fit,have_poll,opportunity,have_boundary_used,clock_fault,have_clock,have_voice_channel;
    bool experimental_poll;
} p25_trunking_session;

void p25_trunking_session_init(p25_trunking_session *s);
bool p25_trunking_session_start(p25_trunking_session *s,
    const p25_trunking_session_config *config,uint32_t now_ms);
// Only qualified control-carrier DUID7 TSBKs belong here. Map learning never
// invokes the passive follower's grant-retune policy. OSPs are parsed natively
// and any grant frequency pair is resolved from this same current site map.
bool p25_trunking_session_consume_control(p25_trunking_session *s,uint16_t nac,
    uint32_t carrier_hz,const uint8_t block[12],uint32_t now_ms);
// Quiescent READY-only group selection uses this same fresh mapped site and
// preserves registration, not the old affiliation or any RF opportunity. It
// never upgrades a timing/start-edge qualification. Refusal is non-mutating.
bool p25_trunking_session_select_group(p25_trunking_session *s,uint16_t group,uint32_t now_ms);
bool p25_trunking_session_observe(p25_trunking_session *s,
    const p25_trunking_slot_observation *observation);
// Physical permission is separate from timing qualification: an unqualified
// backend can learn/inspect the site indefinitely without entering TX policy.
void p25_trunking_session_poll(p25_trunking_session *s,uint32_t now_ms,
    const p25_trunking_session_clock *clock,bool physical_tx_allowed,bool ptt_down);
// Explicit alternative policy for a nominal-clock experimental backend. The
// supplied boundary is a retained actual observation, not a future idle grant.
// Source-to-MCU age/owner/native-start checks remain mandatory in the adapter.
// Measured clock/start-edge flags and qualified idle are never upgraded.
void p25_trunking_session_poll_nominal(p25_trunking_session *s,uint32_t now_ms,
    const p25_trunking_session_clock *clock,bool physical_tx_allowed,bool ptt_down,
    const p25_trunking_slot_boundary_view *anchor);
// RF actions require exactly the latest poll's ms/tick/epochs and qualified
// clock/start edge. One take per observed boundary. The adapter must recheck
// its physical permission immediately before keying and enforce hard cutoff.
// Cleanup STOP/RETURN actions never depend on an RF access opportunity.
bool p25_trunking_session_take(p25_trunking_session *s,p25_trunking_session_action *out,
    uint32_t now_ms,const p25_trunking_session_clock *clock);
bool p25_trunking_session_take_nominal(p25_trunking_session *s,p25_trunking_session_action *out,
    uint32_t now_ms,const p25_trunking_session_clock *clock);
bool p25_trunking_session_result(p25_trunking_session *s,uint32_t id,bool success,uint32_t now_ms);
// Explicit RX timing loss revokes all prepared action leases and observed
// phase. Site loss also invalidates registration/affiliation; RF must already
// be stopped independently by the adapter on an actual hardware fault.
void p25_trunking_session_lost(p25_trunking_session *s,uint32_t now_ms);
void p25_trunking_session_stop(p25_trunking_session *s);

#endif
