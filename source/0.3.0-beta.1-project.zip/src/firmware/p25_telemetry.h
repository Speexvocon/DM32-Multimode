// SPDX-License-Identifier: GPL-3.0-or-later
// Controller-owned ASCII diagnostics. Never format or write from an IRQ.
#ifndef P25_TELEMETRY_H
#define P25_TELEMETRY_H
enum {TELEMETRY_ROW_BYTES=448u,TELEMETRY_WRITE_BYTES=32u};
static struct {
    char line[TELEMETRY_ROW_BYTES];
    uint16_t row,length,offset;
    uint8_t kind,queued[2],queued_count;
    bool aborting;
} telemetry;
_Static_assert(sizeof telemetry<=464u,"Telemetry exceeds its bounded RAM budget");
static bool telemetry_pending(void) {return telemetry.kind!=TELEMETRY_NONE;}
static bool telemetry_partial(void) {return telemetry.offset && telemetry.offset<telemetry.length;}
static void telemetry_reset(void) {
    telemetry.kind=TELEMETRY_NONE;telemetry.queued_count=0;telemetry.aborting=false;
    telemetry.row=telemetry.length=telemetry.offset=0;
}
static void telemetry_request(telemetry_kind kind) {
    if(kind<=TELEMETRY_NONE || kind>TELEMETRY_RXFEED || telemetry.aborting)return;
    if(command_deferred&(COMMAND_DEFER_STOP_ACK|COMMAND_DEFER_TRUNK_STOP_ACK))return;
    if(apps_active() || cps_link || cps_active) {
        command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return;
    }
    if(!telemetry_pending()) {telemetry.kind=(uint8_t)kind;telemetry.row=0;return;}
    if(telemetry.kind==kind)return;
    for(unsigned i=0;i<telemetry.queued_count;++i)if(telemetry.queued[i]==kind)return;
    if(telemetry.queued_count<2u)telemetry.queued[telemetry.queued_count++]=(uint8_t)kind;
}
static void telemetry_abort_after_row(void) {
    telemetry.queued_count=0;
    if(!telemetry_partial())telemetry_reset();
    else telemetry.aborting=true; // STOP kills RF now; complete only its begun text row.
}
static void telemetry_next(void) {
    telemetry.row=telemetry.length=telemetry.offset=0;
    if(telemetry.aborting || !telemetry.queued_count) {telemetry_reset();return;}
    telemetry.kind=telemetry.queued[0];
    if(--telemetry.queued_count)telemetry.queued[0]=telemetry.queued[1];
}
static int telemetry_format(unsigned row,char *line,size_t capacity) {
    if(telemetry.kind==TELEMETRY_LIVE)return live_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_PROBE)return trunk_probe_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_TRUNK)return trunk_status_row(row,line,capacity);
#if DM32_TRUNK_SUBSCRIBER
    if(telemetry.kind==TELEMETRY_RXPROGRESS)return trunk_rx_progress_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_PRELOAD)return trunk_preload_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_RXSTREAM)return trunk_rx_stream_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_RXFEED)return trunk_rx_feed_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_LABVOICE)return trunk_lab_voice_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_LABPTT)return trunk_lab_ptt_status_row(row,line,capacity);
    if(telemetry.kind==TELEMETRY_LABATTACH)return trunk_lab_attach_status_row(row,line,capacity);
#endif
    return -1;
}
static void telemetry_poll(bool down) {
    if(!telemetry_pending() || pcm_owner || apps_active() || cps_link || cps_active
       || call_active || prepared || hardware_running || rx_sampling || command_tx_critical(down))return;
    // Receive/control work has already run in this pass. Do not add wire time
    // while the raw ring is catching up, including during a control retune.
    if(mon_running && mon_count(monitor.raw_head,monitor.raw_tail,MON_RAW_BLOCKS)>=4u)return;
    if(telemetry.length==0u) {
        for(unsigned skipped=0;skipped<64u;++skipped) {
            int n=telemetry_format(telemetry.row++,telemetry.line,sizeof telemetry.line);
            if(n<0) {telemetry_next();return;}
            if(!n)continue;
            if((unsigned)n>=sizeof telemetry.line) {
                const char *error="ERR STATUS row too long\r\n";
                memcpy(telemetry.line,error,strlen(error)+1u);
                n=(int)strlen(error);telemetry.aborting=true;telemetry.queued_count=0;
            }
            telemetry.length=(uint16_t)n;telemetry.offset=0;break;
        }
        if(!telemetry.length) {telemetry_reset();return;}
    }
    size_t n=telemetry.length-telemetry.offset;
    if(n>TELEMETRY_WRITE_BYTES)n=TELEMETRY_WRITE_BYTES;
    size_t sent=board.host_port->write((const uint8_t *)telemetry.line+telemetry.offset,n);
    if(sent>n)sent=n;
    telemetry.offset+=(uint16_t)sent;
    if(telemetry.offset==telemetry.length) {
        telemetry.length=telemetry.offset=0;
        // Retire the request in the same pass as its last wire byte: a client
        // may immediately send CPS after reading this established terminator.
        bool last=(telemetry.kind==TELEMETRY_LIVE && telemetry.row==44u)
            || (telemetry.kind==TELEMETRY_PROBE && telemetry.row==12u)
            || (telemetry.kind==TELEMETRY_TRUNK && telemetry.row==(DM32_TRUNK_SUBSCRIBER ? 3u : 1u))
#if DM32_TRUNK_SUBSCRIBER
            || (telemetry.kind==TELEMETRY_RXPROGRESS && trunk_rx_progress_status_last(telemetry.row))
            || (telemetry.kind==TELEMETRY_PRELOAD && telemetry.row==TRUNK_PRELOAD_ROW_COUNT)
            || (telemetry.kind==TELEMETRY_RXSTREAM && trunk_rx_stream_status_last(telemetry.row))
            || (telemetry.kind==TELEMETRY_RXFEED && telemetry.row==4u)
            || (telemetry.kind==TELEMETRY_LABVOICE && telemetry.row==2u)
            || (telemetry.kind==TELEMETRY_LABPTT && telemetry.row==2u)
            || (telemetry.kind==TELEMETRY_LABATTACH && telemetry.row==2u)
#endif
            ;
        if(telemetry.aborting || last)telemetry_next();
    }
}
#endif
