// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_preload.h"
#include <string.h>

bool p25_trunking_preload_phase_image(uint8_t out[P25_TRUNK_PRELOAD_RAM_BYTES]) {
    // Fixed offline SHAKE256 marker: "DM32 native PHY phase marker v1; no CAI packet".
    // No runtime generator, mutable shared state, protocol header or owner ID.
    static const uint8_t marker[P25_TRUNK_PRELOAD_RAM_BYTES]={
        0x66u,0x2bu,0xb0u,0x6eu,0xc1u,0xcbu,0x4du,0xe7u,0xbau,0x41u,0x42u,0xadu,
        0x05u,0x9bu,0x15u,0x5bu,0xebu,0x6cu,0x8cu,0x1au,0x82u,0x1du,0xbcu,0xaau,
        0xfeu,0xf9u,0x18u,0x24u,0xf6u,0x01u,0x40u,0xebu,0x29u,0xbeu,0x1au,0xd1u,
        0x0fu,0x1au,0x4eu,0xf4u,0xc8u,0x6cu,0x6fu,0xc1u,0xe8u,0x10u,0xbdu,0xd7u,
        0x94u,0xbbu,0x7fu,0xe6u,0xf4u,0xe3u,0xb0u,0xebu,0x5fu,0x56u,0x46u,0x58u,
        0x2eu,0xc7u,0x63u,0x22u,0x1fu,0xf7u,0x82u,0x84u,0x6fu,0x5eu,0x89u,0x2au
    };
    if(!out)return false;
    memcpy(out,marker,sizeof marker);return true;
}

bool p25_trunking_preload_plan_make(p25_trunking_preload_plan *out,
                                   const p25_trunking_preload_config *config) {
    if(!out || !config || config->first_half>1u
       || config->lead_bytes>P25_TRUNK_PRELOAD_MAX_LEAD_BYTES
       || config->lead_bytes+P25_TRUNK_PRELOAD_PREFIX_BYTES>P25_TRUNK_PRELOAD_RAM_BYTES)return false;
    unsigned lead_bits=config->lead_bytes*8u;
    unsigned first_bits=P25_TRUNK_PRELOAD_HALF_BYTES*8u-lead_bits;
    unsigned total_bits=P25_TRUNK_PRELOAD_VALID_BITS+lead_bits;
    p25_trunking_preload_plan value={.valid_bits=P25_TRUNK_PRELOAD_VALID_BITS,
        .prefix_bytes=P25_TRUNK_PRELOAD_PREFIX_BYTES,.ram_bytes=P25_TRUNK_PRELOAD_RAM_BYTES,
        .half_bytes=P25_TRUNK_PRELOAD_HALF_BYTES,.first_valid_bits=(uint16_t)first_bits,
        .second_valid_bits=(uint16_t)(P25_TRUNK_PRELOAD_VALID_BITS-first_bits),
        .nominal_us=(total_bits*1000000u+9599u)/9600u,.nominal_ticks=(uint16_t)(total_bits*5u),
        .first_half=config->first_half,.fill_byte=config->fill_byte,.lead_bytes=config->lead_bytes};
    *out=value;return true;
}
static bool valid_plan(const p25_trunking_preload_plan *plan) {
    return plan && plan->first_half<=1u && plan->lead_bytes<=P25_TRUNK_PRELOAD_MAX_LEAD_BYTES
        && plan->lead_bytes+P25_TRUNK_PRELOAD_PREFIX_BYTES<=P25_TRUNK_PRELOAD_RAM_BYTES
        && plan->valid_bits==P25_TRUNK_PRELOAD_VALID_BITS
        && plan->prefix_bytes==P25_TRUNK_PRELOAD_PREFIX_BYTES
        && plan->ram_bytes==P25_TRUNK_PRELOAD_RAM_BYTES
        && plan->half_bytes==P25_TRUNK_PRELOAD_HALF_BYTES
        && plan->first_valid_bits==288u-plan->lead_bytes*8u
        && plan->second_valid_bits==28u+plan->lead_bytes*8u
        && plan->nominal_us==((316u+plan->lead_bytes*8u)*1000000u+9599u)/9600u
        && plan->nominal_ticks==(316u+plan->lead_bytes*8u)*5u;
}
bool p25_trunking_preload_render(const p25_trunking_preload_plan *plan,
    const uint8_t prefix[P25_TRUNK_PRELOAD_PREFIX_BYTES],uint8_t out[P25_TRUNK_PRELOAD_RAM_BYTES]) {
    if(!prefix || !out || !valid_plan(plan))return false;
    uint8_t image[P25_TRUNK_PRELOAD_RAM_BYTES];
    unsigned first=plan->first_half*P25_TRUNK_PRELOAD_HALF_BYTES;
    memset(image,plan->fill_byte,sizeof image);
    for(unsigned i=0;i<plan->lead_bytes;++i)
        image[(first+i)%P25_TRUNK_PRELOAD_RAM_BYTES]=P25_TRUNK_PRELOAD_LEAD_BYTE;
    first+=plan->lead_bytes;
    for(unsigned i=0;i<P25_TRUNK_PRELOAD_PREFIX_BYTES-1u;++i)
        image[(first+i)%P25_TRUNK_PRELOAD_RAM_BYTES]=prefix[i];
    image[(first+39u)%P25_TRUNK_PRELOAD_RAM_BYTES]=(uint8_t)((prefix[39]&0xf0u)|(plan->fill_byte&0x0fu));
    memcpy(out,image,sizeof image);return true;
}
