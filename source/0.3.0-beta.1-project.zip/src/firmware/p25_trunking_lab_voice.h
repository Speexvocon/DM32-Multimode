// SPDX-License-Identifier: GPL-3.0-or-later
// One finite, explicitly selected laboratory voice action. No subscriber or
// access-slot qualification is established by this policy.
#ifndef P25_TRUNKING_LAB_VOICE_H
#define P25_TRUNKING_LAB_VOICE_H
#include "p25_trunking_lab_exchange.h"
#include "p25_trunking_lab.h"

#define P25_LAB_VOICE_LEASE_US 250000u
#define P25_LAB_VOICE_RF_MAX_US 6000000u
#define P25_LAB_VOICE_RETURN_US 1000000u
#define P25_LAB_VOICE_LDUS 20u
#define P25_LAB_VOICE_QUIET_LDUS 2u
#define P25_LAB_VOICE_MIC_FRAMES ((P25_LAB_VOICE_LDUS-P25_LAB_VOICE_QUIET_LDUS)*9u)
#define P25_LAB_VOICE_CHANNEL 0x1001u
#define P25_LAB_VOICE_OPTIONS 4u

typedef enum {
    P25_LAB_VOICE_IDLE,P25_LAB_VOICE_ARMED,P25_LAB_VOICE_GRANTED,
    P25_LAB_VOICE_TAKEN,P25_LAB_VOICE_VOICE,P25_LAB_VOICE_DRAIN,
    P25_LAB_VOICE_RETURN,P25_LAB_VOICE_DONE,P25_LAB_VOICE_CANCELLED,
    P25_LAB_VOICE_FAILED
} p25_lab_voice_phase;
typedef enum {
    P25_LAB_VOICE_OK,P25_LAB_VOICE_CONFIG,P25_LAB_VOICE_OWNER,
    P25_LAB_VOICE_EPOCH,P25_LAB_VOICE_LEASE,P25_LAB_VOICE_PERMISSION,
    P25_LAB_VOICE_PTT,P25_LAB_VOICE_RF_NOT_OFF,P25_LAB_VOICE_TRANSPORT,
    P25_LAB_VOICE_RF_LIMIT,P25_LAB_VOICE_CLOCK,P25_LAB_VOICE_CANCEL
} p25_lab_voice_reason;

typedef struct {
    p25_lab_exchange_owner owner;
    uint32_t grant_epoch,return_epoch;
    uint32_t grant_us,start_us,rf_us,end_us,return_us,ready_us;
    uint8_t phase,reason,needs_rf_off,finish_phase;
} p25_lab_voice;

bool p25_lab_voice_owned(const p25_lab_voice *s);
// Called once at a successful new PREPARE; OFF is recorded without arming.
// Sequence must advance modulo32 (nonzero, less than half a cycle forward).
bool p25_lab_voice_arm(p25_lab_voice *s,bool enabled,const p25_lab_exchange *prepared);
bool p25_lab_voice_offer(p25_lab_voice *s,const p25_lab_exchange *reply,uint32_t now_us);
// Consume the sole action before any hardware transition. Failure cannot retry
// that grant; successful take is potentially keyed until explicit RF-off ack.
// The adapter supplies explicit PTT permission: released for serial lab mode,
// or a separately frozen one-shot held physical intent. This is no RF lease.
bool p25_lab_voice_take(p25_lab_voice *s,const p25_lab_exchange *reply,
    const p25_lab_exchange_owner *current,uint32_t current_epoch,
    bool permission,bool ptt_permitted,bool rf_off,uint32_t now_us);
// Recheck at BOTH initial RF and PA gates. It does not mark RF as observed.
bool p25_lab_voice_key_allowed(const p25_lab_voice *s,uint32_t now_us);
// Records the actual first PA/RF start, not a timer-arm or planned timestamp.
bool p25_lab_voice_rf_started(p25_lab_voice *s,uint32_t now_us);
bool p25_lab_voice_drain(p25_lab_voice *s,uint32_t now_us);
// Success requires a real drained voice end and RF-off. A failed/pending start
// still needs this RF-off acknowledgement before a control return can finish.
bool p25_lab_voice_tx_done(p25_lab_voice *s,bool success,bool rf_off,uint32_t now_us);
bool p25_lab_voice_return_ready(p25_lab_voice *s,uint32_t epoch,bool raw_input,
    bool rf_off,uint32_t now_us);
void p25_lab_voice_cancel(p25_lab_voice *s,p25_lab_voice_reason why);
// Explicit STOP/profile/update cancellation may finish RF-off without starting
// RX. This records CANCELLED, never DONE or a fabricated return epoch.
bool p25_lab_voice_abort_off(p25_lab_voice *s,bool rf_off,uint32_t now_us);
void p25_lab_voice_poll(p25_lab_voice *s,uint32_t now_us);
#endif
