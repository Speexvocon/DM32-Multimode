// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_APPLET_VM_H
#define RADIO_APPLET_VM_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Portable DAPP v1 bytecode, fetched through the owner's read-only storage API.
// All integers in a package are little-endian. Header (64 bytes):
// 0 DAPP,4 u16 version=1,6 u16 header=64,8 u32 total,12 u32 caps,
// 16 u32 code_offset=64,20 u16 count,22 u16 entry,24 u32 strings_offset,
// 28 u32 strings_size,32 name[24] (nonempty, NUL+zero padded),56 reserved=0,
// 60 CRC32 over [0,60) followed by [64,total), IEEE/zlib convention.
// Code is count*8 bytes immediately followed by printable ASCII string bytes.
// Instruction: opcode:u8,a:u8,b:u16,imm:u32. Unused operands must be zero.
#define RADIO_APPLET_HEADER_BYTES 64u
#define RADIO_APPLET_MAX_BYTES 32768u
#define RADIO_APPLET_INSTRUCTION_BYTES 8u
#define RADIO_APPLET_REGISTERS 8u
#define RADIO_APPLET_TEXT_MAX 95u
#define RADIO_APPLET_TICK_INSTRUCTIONS 32u
#define RADIO_APPLET_BURST_FUEL 100000u

enum {
 RADIO_APPLET_CAP_SAME=1u, RADIO_APPLET_CAP_SERIAL=2u,
 RADIO_APPLET_CAP_DISPLAY=4u, RADIO_APPLET_CAP_KEY=8u,
 RADIO_APPLET_CAP_ALL=15u
};
enum {RADIO_APPLET_EVENT_HEADER=1u,RADIO_APPLET_EVENT_CONFIRMED=2u,
      RADIO_APPLET_EVENT_EOM=4u,RADIO_APPLET_EVENT_KEY=8u};
typedef enum {
 RADIO_APPLET_END=0, RADIO_APPLET_SET, RADIO_APPLET_ADD,
 RADIO_APPLET_JEQ, RADIO_APPLET_JNE, RADIO_APPLET_JMP,
 RADIO_APPLET_WAIT, RADIO_APPLET_YIELD, RADIO_APPLET_EMIT_LITERAL,
 RADIO_APPLET_DISPLAY_LITERAL, RADIO_APPLET_SAME_START,
 RADIO_APPLET_SAME_LAST, RADIO_APPLET_DISPLAY_SAME, RADIO_APPLET_EMIT_REG,
 RADIO_APPLET_GET, RADIO_APPLET_AWAIT
} radio_applet_opcode;
typedef enum {
 RADIO_APPLET_ERROR_NONE=0,RADIO_APPLET_ERROR_READ,RADIO_APPLET_ERROR_FORMAT,
 RADIO_APPLET_ERROR_CRC,RADIO_APPLET_ERROR_OPCODE,RADIO_APPLET_ERROR_OPERAND,
 RADIO_APPLET_ERROR_CAPABILITY,RADIO_APPLET_ERROR_BRANCH,RADIO_APPLET_ERROR_STRING,
 RADIO_APPLET_ERROR_FUEL,RADIO_APPLET_ERROR_SERVICE
} radio_applet_error;
typedef enum {
 RADIO_APPLET_IDLE=0,RADIO_APPLET_RUNNING,RADIO_APPLET_WAITING,
 RADIO_APPLET_FINISHED,RADIO_APPLET_FAULT
} radio_applet_state;

// GET fields 0 event / 1 originator (3 ASCII bytes packed LSB first),
// 2 locations,3 purge_minutes,4 issue_day,5 issue_hour,6 issue_minute,
// 7 confirmed,8 last key,9 uptime_ms,10 headers,11 confirmations,12 EOMs,
// 13 event sequence. Fields 0..7 and10..13 require SAME; field8 requires KEY.
typedef bool (*radio_applet_read_fn)(void *context,uint32_t offset,void *out,size_t count);
typedef struct {
 bool (*same_start)(void *context,uint32_t hz);
 bool (*same_last)(void *context);
 bool (*display)(void *context,const char *text);
 bool (*display_same)(void *context);
 bool (*emit)(void *context,const char *text);
 bool (*get)(void *context,unsigned field,uint32_t *value);
} radio_applet_services;
typedef struct {
 uint32_t total_bytes,capabilities,strings_offset,strings_bytes,crc;
 uint16_t instruction_count,entry;
 char name[24];
} radio_applet_package;
typedef struct {
 radio_applet_read_fn read;
 void *read_context;
 radio_applet_services services;
 void *service_context;
 radio_applet_package package;
 uint32_t registers[RADIO_APPLET_REGISTERS];
 uint32_t pending_events,instructions,fuel,wait_started,wait_ms;
 uint16_t pc,await_events;
 uint8_t await_register;
 radio_applet_state state;
 radio_applet_error error;
 char text[RADIO_APPLET_TEXT_MAX+1u];
} radio_applet_vm;

// Caller serializes storage reads/validation/execution and keeps a running
// package immutable. No RF, serial, display, allocation or executable code load
// occurs during validation. Each instruction is checked again before execution.
bool radio_applet_vm_validate(radio_applet_read_fn read,void *context,
                             radio_applet_package *out,radio_applet_error *error);
void radio_applet_vm_init(radio_applet_vm *vm,radio_applet_read_fn read,void *read_context,
                          const radio_applet_services *services,void *service_context);
bool radio_applet_vm_start(radio_applet_vm *vm,radio_applet_error *error);
// Main/task context only; never ISR. At most 32 instructions per call. A loop
// without WAIT/YIELD/AWAIT faults after 100000 instructions across calls.
radio_applet_state radio_applet_vm_tick(radio_applet_vm *vm,uint32_t now_ms);
void radio_applet_vm_signal(radio_applet_vm *vm,uint32_t events);
void radio_applet_vm_stop(radio_applet_vm *vm);
const char *radio_applet_vm_error_name(radio_applet_error error);
#endif
