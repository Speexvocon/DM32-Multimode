// SPDX-License-Identifier: GPL-3.0-or-later
#include "same_protocol.h"
#include <string.h>

enum { SAME_IDLE = 0, SAME_HEADER, SAME_EOM };

static bool decimal(const char *p, size_t n, unsigned *out) {
 unsigned v = 0;
 for(size_t i = 0; i < n; ++i) {
  if(p[i] < '0' || p[i] > '9')return false;
  v = v * 10u + (unsigned)(p[i] - '0');
 }
 *out = v;return true;
}

static bool uppercase(const char *p, size_t n) {
 for(size_t i = 0; i < n; ++i)if(p[i] < 'A' || p[i] > 'Z')return false;
 return true;
}

/* No complete temporary same_header or location array on the target stack. */
static bool fields(const char *raw, size_t length, same_header *out) {
 unsigned value, hours, minutes, day, issue_h, issue_m, locations = 0;
 size_t pos = 13;
 if(!raw || length < 42u || length > SAME_HEADER_MAX || memcmp(raw,"ZCZC-",5))return false;
 for(size_t i = 0; i < length; ++i)if((unsigned char)raw[i] < 32u || (unsigned char)raw[i] > 126u)return false;
 if(raw[8] != '-' || raw[12] != '-' || !uppercase(raw + 5,3) || !uppercase(raw + 9,3))return false;
 if(memcmp(raw + 5,"WXR",3) && memcmp(raw + 5,"EAS",3) &&
    memcmp(raw + 5,"CIV",3) && memcmp(raw + 5,"PEP",3))return false;
 for(;;) {
  if(locations == SAME_MAX_LOCATIONS || pos + 7u > length || !decimal(raw + pos,6,&value))return false;
  ++locations;pos += 6;
  if(raw[pos] == '+') {++pos;break;}
  if(raw[pos++] != '-')return false;
 }
 if(pos + 22u != length || !decimal(raw + pos,2,&hours) || !decimal(raw + pos + 2,2,&minutes))return false;
 if(minutes >= 60u || (!hours && (!minutes || minutes % 15u)) || (hours && minutes % 30u))return false;
 pos += 4;
 if(raw[pos++] != '-' || !decimal(raw + pos,3,&day) || !day || day > 366u ||
    !decimal(raw + pos + 3,2,&issue_h) || issue_h > 23u ||
    !decimal(raw + pos + 5,2,&issue_m) || issue_m > 59u)return false;
 pos += 7;
 if(raw[pos++] != '-' || raw[pos + 8] != '-')return false;
 for(size_t i = 0; i < 8; ++i)if(raw[pos + i] == '-' || raw[pos + i] == '+')return false;
 if(out) {
  memcpy(out->originator,raw + 5,3);out->originator[3] = 0;
  memcpy(out->event,raw + 9,3);out->event[3] = 0;
  memcpy(out->sender,raw + pos,8);out->sender[8] = 0;
  out->length = (uint16_t)length;
  out->purge_minutes = (uint16_t)(hours * 60u + minutes);
  out->issue_day = (uint16_t)day;
  out->issue_hour = (uint8_t)issue_h;out->issue_minute = (uint8_t)issue_m;
  out->location_count = (uint8_t)locations;
 }
 return true;
}

bool same_header_parse(const char *raw, size_t length, same_header *out) {
 if(!out)return false;
 memset(out,0,sizeof *out);
 if(!fields(raw,length,out))return false;
 memcpy(out->raw,raw,length);out->raw[length] = 0;
 return true;
}

bool same_protocol_location(const same_header *h, unsigned index, char out[7]) {
 if(!out)return false;
 out[0] = 0;
 if(!h || index >= h->location_count || index >= SAME_MAX_LOCATIONS)return false;
 size_t pos = 13u + index * 7u;
 if(pos + 6u > h->length || h->length > SAME_HEADER_MAX)return false;
 memcpy(out,h->raw + pos,6);out[6] = 0;return true;
}

void same_protocol_init(same_protocol *s) {
 if(s)memset(s,0,sizeof *s);
}

static void group_clear(same_protocol *s) {
 s->group_active = 0;s->group_attempts = 0;s->group_has_latest = 0;
 s->group_confirmed = 0;s->candidate_length = 0;
}

uint32_t same_protocol_discontinuity(same_protocol *s) {
 if(!s)return 0;
 uint32_t event = 0;
 if(s->phase) {++s->partials;event = SAME_EVENT_PARTIAL;}
 s->phase = SAME_IDLE;s->preamble_count = 0;s->error = SAME_ERROR_DISCONTINUITY;
 group_clear(s);s->eom_active = 0;s->eom_attempts = 0;s->eom_confirmed = 0;
 return event;
}

static void header_attempt(same_protocol *s, uint32_t now) {
 if(!s->group_active || s->group_attempts >= 3u || (uint32_t)(now - s->group_start_ms) > SAME_REPEAT_WINDOW_MS) {
  group_clear(s);s->group_active = 1;s->group_start_ms = now;
 }
 ++s->group_attempts;
}

static uint32_t invalid_burst(same_protocol *s, uint8_t error, bool partial, uint32_t now) {
 if(s->phase == SAME_HEADER)header_attempt(s,now);
 s->phase = SAME_IDLE;s->preamble_count = 0;s->error = error;
 if(partial) {++s->partials;return SAME_EVENT_PARTIAL;}
 ++s->invalid;return SAME_EVENT_INVALID;
}

uint32_t same_protocol_tick(same_protocol *s, uint32_t now) {
 uint32_t event = 0;
 if(!s)return 0;
 if(s->phase && ((uint32_t)(now - s->last_byte_ms) > SAME_BYTE_TIMEOUT_MS ||
                  (uint32_t)(now - s->burst_start_ms) > SAME_BURST_TIMEOUT_MS))
  event = invalid_burst(s,SAME_ERROR_TIMEOUT,true,now);
 if(s->preamble_count && (uint32_t)(now - s->last_byte_ms) > SAME_BYTE_TIMEOUT_MS)s->preamble_count = 0;
 if(s->group_active && (uint32_t)(now - s->group_start_ms) > SAME_REPEAT_WINDOW_MS)group_clear(s);
 if(s->eom_active && (uint32_t)(now - s->eom_start_ms) > SAME_REPEAT_WINDOW_MS) {
  s->eom_active = 0;s->eom_attempts = 0;s->eom_confirmed = 0;
 }
 return event;
}

static uint32_t complete_header(same_protocol *s, uint32_t now) {
 header_attempt(s,now);
 bool match = (s->candidate_length == s->raw_length && s->candidate_length &&
               !memcmp(s->candidate,s->raw,s->raw_length)) ||
              (s->group_has_latest && s->latest.length == s->raw_length &&
               !memcmp(s->latest.raw,s->raw,s->raw_length));
 uint32_t event = SAME_EVENT_HEADER;
 s->latest_confirmed = (uint8_t)match;
 if(match && !s->group_confirmed) {
  event |= SAME_EVENT_CONFIRMED;s->group_confirmed = 1;++s->confirmations;
 }
 if(!s->candidate_length) {
  memcpy(s->candidate,s->raw,s->raw_length + 1u);s->candidate_length = s->raw_length;
 }
 (void)same_header_parse(s->raw,s->raw_length,&s->latest);
 s->group_has_latest = 1;s->eom_active = 0;s->eom_attempts = 0;s->eom_confirmed = 0;
 ++s->headers;s->phase = SAME_IDLE;s->error = SAME_ERROR_NONE;
 return event;
}

static uint32_t complete_eom(same_protocol *s, uint32_t now) {
 uint32_t event = SAME_EVENT_EOM;
 if(!s->eom_active || s->eom_attempts >= 3u) {
  s->eom_active = 1;s->eom_start_ms = now;s->eom_attempts = 0;s->eom_confirmed = 0;
 }
 ++s->eom_attempts;
 if(s->eom_attempts >= 2u && !s->eom_confirmed) {
  s->eom_confirmed = 1;++s->eom_confirmations;event |= SAME_EVENT_EOM_CONFIRMED;
 }
 group_clear(s);s->latest_confirmed = 0;
 ++s->eoms;s->phase = SAME_IDLE;s->error = SAME_ERROR_NONE;
 return event;
}

/* A small prefix recognizer avoids retaining arbitrary noise until timeout. */
static bool prefix_ok(const char *raw, size_t length) {
 static const char start[] = "ZCZC-";
 unsigned locations = 0;
 size_t pos = 13;
 if(length <= 5u)return !memcmp(raw,start,length);
 if(length <= 8u)return uppercase(raw + 5,length - 5u);
 if(raw[8] != '-')return false;
 if(length <= 12u)return uppercase(raw + 9,length - 9u);
 if(raw[12] != '-')return false;
 for(;;) {
  if(locations == SAME_MAX_LOCATIONS)return false;
  for(unsigned i = 0; i < 6; ++i) {
   if(pos == length)return true;
   if(raw[pos] < '0' || raw[pos] > '9')return false;
   ++pos;
  }
  ++locations;
  if(pos == length)return true;
  if(raw[pos] == '+') {++pos;break;}
  if(raw[pos++] != '-')return false;
 }
 for(unsigned i = 0; i < 4; ++i) {
  if(pos == length)return true;
  if(raw[pos] < '0' || raw[pos] > '9')return false;
  ++pos;
 }
 if(pos == length)return true;
 if(raw[pos++] != '-')return false;
 for(unsigned i = 0; i < 7; ++i) {
  if(pos == length)return true;
  if(raw[pos] < '0' || raw[pos] > '9')return false;
  ++pos;
 }
 if(pos == length)return true;
 if(raw[pos++] != '-')return false;
 for(unsigned i = 0; i < 8; ++i) {
  if(pos == length)return true;
  if(raw[pos] == '-' || raw[pos] == '+')return false;
  ++pos;
 }
 if(pos == length)return true;
 return raw[pos] == '-' && pos + 1u == length;
}

uint32_t same_protocol_feed_byte(same_protocol *s, uint8_t byte, uint32_t now) {
 if(!s)return 0;
 uint32_t event = same_protocol_tick(s,now);
 ++s->bytes;s->last_byte_ms = now;
 if(!s->phase) {
  if(byte == 0xABu) {
   if(s->preamble_count < 255u)++s->preamble_count;
   return event;
  }
  uint8_t count = s->preamble_count;s->preamble_count = 0;
  if(count < SAME_PREAMBLE_MIN)return event;
  ++s->preambles;s->raw_length = 0;s->raw[0] = 0;s->error = SAME_ERROR_NONE;
  byte &= 0x7Fu;
  if(byte != 'Z' && byte != 'N') {
   /* An unreadable start still consumes an attempt; otherwise A, bad, bad, A
    * could be incorrectly counted as two equal copies among three bursts. */
   header_attempt(s,now);++s->invalid;s->error = SAME_ERROR_FORMAT;
   return event | SAME_EVENT_INVALID;
  }
  if(byte == 'N')group_clear(s); /* Never carry a header vote across EOM framing. */
  s->phase = byte == 'Z' ? SAME_HEADER : SAME_EOM;s->burst_start_ms = now;
 }
 /* Do not treat a high-bit '+' (AB) inside a header as preamble. */
 uint8_t text = byte & 0x7Fu;
 if(s->raw_length >= SAME_HEADER_MAX) {
  event |= invalid_burst(s,SAME_ERROR_LENGTH,false,now);
  if(byte == 0xABu)s->preamble_count = 1;
  return event;
 }
 s->raw[s->raw_length++] = text >= 32u && text <= 126u ? (char)text : '?';
 s->raw[s->raw_length] = 0;
 if(text < 32u || text > 126u) return event | invalid_burst(s,SAME_ERROR_CHARACTER,false,now);
 if(s->phase == SAME_EOM) {
  if(text != 'N') {
   event |= invalid_burst(s,SAME_ERROR_FORMAT,false,now);
   if(byte == 0xABu)s->preamble_count = 1;
   return event;
  }
  return event | (s->raw_length == 4u ? complete_eom(s,now) : 0u);
 }
 if(!prefix_ok(s->raw,s->raw_length)) {
  event |= invalid_burst(s,SAME_ERROR_FORMAT,false,now);
  if(byte == 0xABu)s->preamble_count = 1;
  return event;
 }
 if(text == '-') {
  const char *plus = memchr(s->raw,'+',s->raw_length);
  if(plus && s->raw_length == (size_t)(plus - s->raw) + 23u) {
   if(fields(s->raw,s->raw_length,NULL))return event | complete_header(s,now);
   return event | invalid_burst(s,SAME_ERROR_FORMAT,false,now);
  }
 }
 if(s->raw_length == SAME_HEADER_MAX) return event | invalid_burst(s,SAME_ERROR_LENGTH,false,now);
 return event;
}
