// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_access.h"
#include <string.h>

static bool hz_valid(const p25_trunking_access *a,uint32_t hz) {
    return hz>=a->config.min_hz && hz<=a->config.max_hz;
}
static bool fresh(const p25_trunking_access *a,uint32_t now) {
    return a->have_site && (uint32_t)(now-a->site_ms)<P25_TRUNK_ACCESS_SITE_MS;
}
static bool before(uint32_t now,uint32_t due) {return (int32_t)(now-due)<0;}
static void clear_action(p25_trunking_access *a) {
    a->outstanding=P25_TRUNK_ACTION_NONE;a->outstanding_id=0;
}
static void clear_grant(p25_trunking_access *a) {
    a->voice_channel=0;a->voice_options=0;
}
static void clear_voice(p25_trunking_access *a) {
    memset(&a->voice,0,sizeof a->voice);clear_grant(a);
}
static void phase(p25_trunking_access *a,p25_trunking_access_phase value,uint32_t now) {
    a->phase=value;a->phase_ms=now;
}
static void exchange(p25_trunking_access *a,p25_trunking_access_phase value,uint32_t now) {
    clear_action(a);clear_grant(a);a->attempts=0;a->queued=false;a->retry_ms=now;phase(a,value,now);
}
static void cancel_request(p25_trunking_access *a,uint32_t now) {
    clear_action(a);a->want_voice=false;a->queued=false;clear_voice(a);
    phase(a,P25_TRUNK_ACCESS_READY,now);
}
void p25_trunking_access_init(p25_trunking_access *a) {if(a)memset(a,0,sizeof *a);}
void p25_trunking_access_stop(p25_trunking_access *a) {
    if(!a)return;
    uint32_t serial=a->serial;memset(a,0,sizeof *a);a->serial=serial;
}
bool p25_trunking_access_start(p25_trunking_access *a,
    const p25_trunking_access_config *config,uint32_t now) {
    if(!a || !config || (a->phase!=P25_TRUNK_ACCESS_OFF && a->phase!=P25_TRUNK_ACCESS_FAILED)
       || a->outstanding || a->voice_running || !config->wacn || config->wacn>0xfffffu || !config->radio_id
       || config->radio_id>=0xffffffu || !config->system || config->system>0xfffu || config->nac>0xfffu
       || !config->group || !config->min_hz || config->min_hz>config->max_hz
       || config->tot_ms<1000u || config->tot_ms>P25_TRUNK_ACCESS_MAX_TOT_MS)return false;
    p25_trunking_access_stop(a);a->config=*config;a->release_required=true;
    phase(a,P25_TRUNK_ACCESS_WAIT_SITE,now);return true;
}
void p25_trunking_access_fault(p25_trunking_access *a,
                              p25_trunking_access_reason why,uint32_t now) {
    if(!a || a->phase==P25_TRUNK_ACCESS_OFF)return;
    bool voice=a->voice_running || a->outstanding==P25_TRUNK_ACTION_VOICE_START;
    clear_action(a);clear_grant(a);a->registered=a->affiliated=a->want_voice=false;
    a->release_required=true;a->reason=why;a->failure_return=true;
    if(voice) {a->voice_running=true;phase(a,P25_TRUNK_ACCESS_DRAIN,now);}
    else if(a->phase==P25_TRUNK_ACCESS_DRAIN || a->phase==P25_TRUNK_ACCESS_RETURN)
        phase(a,P25_TRUNK_ACCESS_RETURN,now);
    else phase(a,P25_TRUNK_ACCESS_FAILED,now);
}
static void lost_site(p25_trunking_access *a,uint32_t now) {
    clear_action(a);clear_grant(a);a->have_site=a->registered=a->affiliated=a->want_voice=false;
    a->release_required=true;a->reason=P25_TRUNK_ACCESS_SITE_LOST;
    phase(a,P25_TRUNK_ACCESS_WAIT_SITE,now);
}
bool p25_trunking_access_site_update(p25_trunking_access *a,
    const p25_trunking_access_site *site,uint32_t now) {
    if(!a || !site || a->phase==P25_TRUNK_ACCESS_OFF || a->phase==P25_TRUNK_ACCESS_FAILED)return false;
    a->action_eligible=false;
    if(site->wacn!=a->config.wacn || site->system!=a->config.system || site->nac!=a->config.nac
       || site->rfss!=a->config.rfss || site->site!=a->config.site) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_SITE_CHANGED,now);return false;
    }
    if(!site->fdma || !site->control_pair_valid || !hz_valid(a,site->control_rx_hz)
       || !hz_valid(a,site->control_tx_hz)) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_MAPPING,now);return false;
    }
    if(a->have_site && (site->control_rx_hz!=a->site.control_rx_hz ||
                       site->control_tx_hz!=a->site.control_tx_hz)) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_SITE_CHANGED,now);return false;
    }
    a->site=*site;a->site_ms=now;a->have_site=true;
    if(a->phase==P25_TRUNK_ACCESS_WAIT_SITE) {
        if(!a->registered)exchange(a,P25_TRUNK_ACCESS_REGISTER,now);
        else if(!a->affiliated)exchange(a,P25_TRUNK_ACCESS_AFFILIATE,now);
        else phase(a,P25_TRUNK_ACCESS_READY,now);
    }
    return true;
}
bool p25_trunking_access_select_group(p25_trunking_access *a,uint16_t group,uint32_t now) {
    if(!a || !group || a->phase!=P25_TRUNK_ACCESS_READY || !a->registered || !a->affiliated
       || !fresh(a,now) || a->ptt_down || a->outstanding || a->outstanding_id
       || a->want_voice || a->voice_running)return false;
    if(group==a->config.group)return true;
    a->config.group=group;a->affiliated=false;a->release_required=true;
    a->action_eligible=false;a->idle=false;a->reason=P25_TRUNK_ACCESS_OK;
    clear_voice(a);exchange(a,P25_TRUNK_ACCESS_AFFILIATE,now);return true;
}
bool p25_trunking_access_deregister(p25_trunking_access *a,uint32_t now) {
    if(!a||a->phase!=P25_TRUNK_ACCESS_READY||!a->registered||!a->affiliated||!fresh(a,now)
       ||a->ptt_down||a->outstanding||a->voice_running||a->want_voice)return false;
    a->action_eligible=a->idle=a->experimental_opportunity=false;
    a->reason=P25_TRUNK_ACCESS_OK;exchange(a,P25_TRUNK_ACCESS_DEREGISTER,now);return true;
}
static void drain(p25_trunking_access *a,p25_trunking_access_reason why,uint32_t now) {
    if(a->outstanding==P25_TRUNK_ACTION_VOICE_START)a->voice_running=true;
    // The pair remains available for a possibly keyed safety STOP. Grant
    // metadata is no longer a start lease once release/fault/drain begins.
    clear_action(a);clear_grant(a);a->want_voice=false;a->reason=why;
    if(why==P25_TRUNK_ACCESS_TOT)a->release_required=true;
    phase(a,P25_TRUNK_ACCESS_DRAIN,now);
}
static void response_timeout(p25_trunking_access *a,uint32_t now) {
    uint32_t limit=a->queued ? P25_TRUNK_ACCESS_QUEUE_MS : P25_TRUNK_ACCESS_RESPONSE_MS;
    if((uint32_t)(now-a->sent_ms)<limit)return;
    a->queued=false;
    if(a->attempts>=P25_TRUNK_ACCESS_ATTEMPTS) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TIMEOUT,now);return;
    }
    p25_trunking_access_phase next=a->phase==P25_TRUNK_ACCESS_WAIT_REG ? P25_TRUNK_ACCESS_REGISTER
        : a->phase==P25_TRUNK_ACCESS_WAIT_AFF ? P25_TRUNK_ACCESS_AFFILIATE : P25_TRUNK_ACCESS_REQUEST;
    a->retry_ms=now+P25_TRUNK_ACCESS_RETRY_MS;phase(a,next,now);
}
static void poll(p25_trunking_access *a,uint32_t now,
                 bool ptt_down,bool tx_allowed,bool opportunity,bool nominal) {
    if(!a || a->phase==P25_TRUNK_ACCESS_OFF)return;
    bool rising=ptt_down && !a->ptt_down;a->ptt_down=ptt_down;a->permit=tx_allowed;
    a->idle=!nominal&&opportunity;a->experimental_opportunity=nominal&&opportunity;
    a->gate_ms=now;a->action_eligible=true;
    if(!ptt_down)a->release_required=false;
    if(a->phase==P25_TRUNK_ACCESS_FAILED)return;
    if(a->phase==P25_TRUNK_ACCESS_DRAIN || a->phase==P25_TRUNK_ACCESS_RETURN) {
        if(a->outstanding && (uint32_t)(now-a->action_ms)>=P25_TRUNK_ACCESS_ACTION_MS) {
            // A missing hardware stop acknowledgment is never proof RF ended.
            a->reason=P25_TRUNK_ACCESS_TRANSPORT;a->failure_return=true;
            if(a->phase==P25_TRUNK_ACCESS_RETURN) {clear_action(a);phase(a,P25_TRUNK_ACCESS_FAILED,now);}
        }
        return;
    }
    if(!tx_allowed) {p25_trunking_access_fault(a,P25_TRUNK_ACCESS_PERMISSION,now);return;}
    if(a->voice_running || a->outstanding==P25_TRUNK_ACTION_VOICE_START) {
        if(!ptt_down)drain(a,P25_TRUNK_ACCESS_RELEASED,now);
        else if((uint32_t)(now-a->voice_ms)>=a->config.tot_ms)drain(a,P25_TRUNK_ACCESS_TOT,now);
        else if(!a->voice_running && !fresh(a,now))
            p25_trunking_access_fault(a,P25_TRUNK_ACCESS_SITE_LOST,now);
        else if(a->outstanding==P25_TRUNK_ACTION_VOICE_START &&
                (uint32_t)(now-a->action_ms)>=P25_TRUNK_ACCESS_ACTION_MS)
            p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TRANSPORT,now);
        return;
    }
    if((a->phase==P25_TRUNK_ACCESS_REQUEST || a->phase==P25_TRUNK_ACCESS_WAIT_GRANT ||
        a->phase==P25_TRUNK_ACCESS_GRANTED) && !ptt_down) {
        if(a->outstanding==P25_TRUNK_ACTION_VOICE_START) {
            // It may have keyed after take(), so obtain an explicit STOP ack.
            a->voice_running=true;drain(a,P25_TRUNK_ACCESS_RELEASED,now);
        } else {a->reason=P25_TRUNK_ACCESS_RELEASED;cancel_request(a,now);}
        return;
    }
    if(a->phase!=P25_TRUNK_ACCESS_WAIT_SITE && !fresh(a,now)) {lost_site(a,now);return;}
    if(a->outstanding && (uint32_t)(now-a->action_ms)>=P25_TRUNK_ACCESS_ACTION_MS) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TRANSPORT,now);return;
    }
    if(a->phase==P25_TRUNK_ACCESS_GRANTED && (uint32_t)(now-a->phase_ms)>=P25_TRUNK_ACCESS_GRANT_MS) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TIMEOUT,now);return;
    }
    if(a->phase==P25_TRUNK_ACCESS_WAIT_REG || a->phase==P25_TRUNK_ACCESS_WAIT_AFF ||
       a->phase==P25_TRUNK_ACCESS_WAIT_GRANT)response_timeout(a,now);
    else if((a->phase==P25_TRUNK_ACCESS_REGISTER || a->phase==P25_TRUNK_ACCESS_AFFILIATE ||
             a->phase==P25_TRUNK_ACCESS_REQUEST || a->phase==P25_TRUNK_ACCESS_DEREGISTER) && !a->outstanding &&
            (uint32_t)(now-a->phase_ms)>=P25_TRUNK_ACCESS_IDLE_MS)
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TIMEOUT,now);
    else if(a->phase==P25_TRUNK_ACCESS_READY && rising && !a->release_required) {
        a->want_voice=true;a->reason=P25_TRUNK_ACCESS_OK;exchange(a,P25_TRUNK_ACCESS_REQUEST,now);
    } else if(rising && a->phase!=P25_TRUNK_ACCESS_READY && !a->want_voice)a->release_required=true;
}
void p25_trunking_access_poll(p25_trunking_access *a,uint32_t now,
                             bool ptt_down,bool tx_allowed,bool idle) {
    poll(a,now,ptt_down,tx_allowed,idle,false);
}
void p25_trunking_access_poll_nominal(p25_trunking_access *a,uint32_t now,
                             bool ptt_down,bool tx_allowed,bool opportunity) {
    poll(a,now,ptt_down,tx_allowed,opportunity,true);
}
bool p25_trunking_access_take(p25_trunking_access *a,
    p25_trunking_access_action *out,uint32_t now) {
    if(!a || !out || a->outstanding)return false;
    p25_trunking_access_action_type type=P25_TRUNK_ACTION_NONE;
    if(a->phase==P25_TRUNK_ACCESS_DRAIN)type=P25_TRUNK_ACTION_VOICE_STOP;
    else if(a->phase==P25_TRUNK_ACCESS_RETURN)type=P25_TRUNK_ACTION_RETURN_CONTROL;
    else {
        if(!a->permit || !a->action_eligible || a->gate_ms!=now || !fresh(a,now) || before(now,a->retry_ms))return false;
        if(a->phase==P25_TRUNK_ACCESS_GRANTED && a->want_voice && a->ptt_down &&
           !a->release_required && a->voice.valid && !a->voice_running &&
           (uint32_t)(now-a->phase_ms)<P25_TRUNK_ACCESS_GRANT_MS)type=P25_TRUNK_ACTION_VOICE_START;
        else if(a->idle||a->experimental_opportunity) {
            if(a->phase==P25_TRUNK_ACCESS_REGISTER)type=P25_TRUNK_ACTION_REGISTER;
            else if(a->phase==P25_TRUNK_ACCESS_AFFILIATE)type=P25_TRUNK_ACTION_AFFILIATE;
            else if(a->phase==P25_TRUNK_ACCESS_REQUEST && a->want_voice && a->ptt_down &&
                    !a->release_required)type=P25_TRUNK_ACTION_GROUP_REQUEST;
            else if(a->phase==P25_TRUNK_ACCESS_DEREGISTER&&!a->ptt_down)type=P25_TRUNK_ACTION_DEREGISTER;
        }
    }
    if(type==P25_TRUNK_ACTION_NONE)return false;
    p25_trunking_access_action value={.type=type,.radio_id=a->config.radio_id,
        .nac=a->config.nac,.group=a->config.group,.tot_ms=a->config.tot_ms,
        .rx_hz=a->site.control_rx_hz,.tx_hz=a->site.control_tx_hz};
    if(type==P25_TRUNK_ACTION_VOICE_START || type==P25_TRUNK_ACTION_VOICE_STOP) {
        value.rx_hz=a->voice.rx_hz;value.tx_hz=a->voice.tx_hz;
    }
    if(type==P25_TRUNK_ACTION_VOICE_START) {
        value.channel=a->voice_channel;value.options=a->voice_options;
    }
    if(++a->serial==0)++a->serial;
    value.id=a->serial;a->outstanding_id=value.id;a->outstanding=type;a->action_ms=now;
    a->action_eligible=false;
    if(type==P25_TRUNK_ACTION_VOICE_START)a->voice_ms=now;
    if(type==P25_TRUNK_ACTION_REGISTER || type==P25_TRUNK_ACTION_AFFILIATE ||
       type==P25_TRUNK_ACTION_GROUP_REQUEST || type==P25_TRUNK_ACTION_DEREGISTER)++a->attempts;
    *out=value;return true;
}
bool p25_trunking_access_result(p25_trunking_access *a,uint32_t id,bool success,uint32_t now) {
    if(!a || !id || id!=a->outstanding_id || !a->outstanding)return false;
    p25_trunking_access_action_type type=a->outstanding;
    if(type==P25_TRUNK_ACTION_VOICE_START && !fresh(a,now)) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_SITE_LOST,now);return false;
    }
    if(type==P25_TRUNK_ACTION_VOICE_START && (uint32_t)(now-a->voice_ms)>=a->config.tot_ms) {
        a->voice_running=true;drain(a,P25_TRUNK_ACCESS_TOT,now);return false;
    }
    if(type==P25_TRUNK_ACTION_VOICE_START && (uint32_t)(now-a->phase_ms)>=P25_TRUNK_ACCESS_GRANT_MS) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TIMEOUT,now);return false;
    }
    if(type!=P25_TRUNK_ACTION_VOICE_STOP && (uint32_t)(now-a->action_ms)>=P25_TRUNK_ACCESS_ACTION_MS) {
        if(type==P25_TRUNK_ACTION_RETURN_CONTROL) {
            clear_action(a);a->reason=P25_TRUNK_ACCESS_TRANSPORT;phase(a,P25_TRUNK_ACCESS_FAILED,now);
        } else p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TRANSPORT,now);
        return false;
    }
    if(type!=P25_TRUNK_ACTION_VOICE_STOP && type!=P25_TRUNK_ACTION_RETURN_CONTROL &&
       type!=P25_TRUNK_ACTION_VOICE_START && !fresh(a,now)) {lost_site(a,now);return false;}
    if(!success) {
        if(type==P25_TRUNK_ACTION_VOICE_STOP) {
            a->reason=P25_TRUNK_ACCESS_TRANSPORT;a->failure_return=true;return true;
        }
        if(type==P25_TRUNK_ACTION_VOICE_START)a->voice_running=true;
        clear_action(a);p25_trunking_access_fault(a,P25_TRUNK_ACCESS_TRANSPORT,now);return true;
    }
    clear_action(a);
    if(type==P25_TRUNK_ACTION_DEREGISTER) {
        p25_trunking_access_stop(a);
    } else if(type==P25_TRUNK_ACTION_VOICE_STOP) {
        clear_grant(a);a->voice_running=false;phase(a,P25_TRUNK_ACCESS_RETURN,now);
    } else if(type==P25_TRUNK_ACTION_RETURN_CONTROL) {
        a->have_site=false;clear_voice(a);
        phase(a,a->failure_return ? P25_TRUNK_ACCESS_FAILED : P25_TRUNK_ACCESS_WAIT_SITE,now);
    } else if(type==P25_TRUNK_ACTION_VOICE_START) {
        a->voice_running=true;
    } else {
        a->sent_ms=now;a->queued=false;
        phase(a,type==P25_TRUNK_ACTION_REGISTER ? P25_TRUNK_ACCESS_WAIT_REG :
            type==P25_TRUNK_ACTION_AFFILIATE ? P25_TRUNK_ACCESS_WAIT_AFF : P25_TRUNK_ACCESS_WAIT_GRANT,now);
    }
    return true;
}
static unsigned expected_service(const p25_trunking_access *a) {
    return a->phase==P25_TRUNK_ACCESS_WAIT_REG ? 0x2cu :
        a->phase==P25_TRUNK_ACCESS_WAIT_AFF ? 0x28u : 0x00u;
}
bool p25_trunking_access_consume(p25_trunking_access *a,const p25_trunking_osp *event,
    uint16_t nac,uint32_t control_rx_hz,const p25_trunking_access_pair *pair,uint32_t now) {
    if(!a || !event || !a->permit || !fresh(a,now) || nac!=a->config.nac ||
       control_rx_hz!=a->site.control_rx_hz)return false;
    a->action_eligible=false;
    bool waiting=a->phase==P25_TRUNK_ACCESS_WAIT_REG || a->phase==P25_TRUNK_ACCESS_WAIT_AFF ||
                 a->phase==P25_TRUNK_ACCESS_WAIT_GRANT;
    if(event->type==P25_TRUNK_OSP_UNSUPPORTED && (!event->target || event->target==0xffffffu || event->target==a->config.radio_id)) {
        p25_trunking_access_fault(a,P25_TRUNK_ACCESS_AUTH,now);return true;
    }
    if(a->outstanding)return false;
    if(!waiting)return false;
    if((uint32_t)(now-a->sent_ms)>=(a->queued ? P25_TRUNK_ACCESS_QUEUE_MS : P25_TRUNK_ACCESS_RESPONSE_MS)) {
        response_timeout(a,now);return false;
    }
    if(event->type==P25_TRUNK_OSP_DENIED || event->type==P25_TRUNK_OSP_QUEUED || event->type==P25_TRUNK_OSP_ACK) {
        if(event->target!=a->config.radio_id || event->service!=expected_service(a))return false;
        if(event->additional && a->phase!=P25_TRUNK_ACCESS_WAIT_REG && event->group!=a->config.group)return false;
        if(event->type==P25_TRUNK_OSP_DENIED) {
            if(a->phase==P25_TRUNK_ACCESS_WAIT_GRANT) {
                cancel_request(a,now);a->release_required=true;a->reason=P25_TRUNK_ACCESS_DENIED;
            } else p25_trunking_access_fault(a,P25_TRUNK_ACCESS_DENIED,now);
        } else if(event->type==P25_TRUNK_OSP_QUEUED)a->queued=true;
        // Generic ACK is not an accepted registration/affiliation/grant.
        return true;
    }
    if(event->type==P25_TRUNK_OSP_REGISTRATION && a->phase==P25_TRUNK_ACCESS_WAIT_REG) {
        if(event->target!=a->config.radio_id || event->system!=a->config.system)return false;
        if(event->response || event->assigned!=a->config.radio_id) {
            p25_trunking_access_fault(a,P25_TRUNK_ACCESS_DENIED,now);return true;
        }
        a->registered=true;exchange(a,P25_TRUNK_ACCESS_AFFILIATE,now);return true;
    }
    if(event->type==P25_TRUNK_OSP_AFFILIATION && a->phase==P25_TRUNK_ACCESS_WAIT_AFF) {
        if(event->target!=a->config.radio_id || event->group!=a->config.group)return false;
        if(event->response) {p25_trunking_access_fault(a,P25_TRUNK_ACCESS_DENIED,now);return true;}
        a->affiliated=true;phase(a,P25_TRUNK_ACCESS_READY,now);return true;
    }
    if(event->type==P25_TRUNK_OSP_GROUP_GRANT && a->phase==P25_TRUNK_ACCESS_WAIT_GRANT) {
        if(event->opcode!=0 || event->source!=a->config.radio_id || event->group!=a->config.group ||
           !a->want_voice || !a->ptt_down || a->release_required)return false;
        if(event->encrypted || (event->options&0x78u) || !pair || !pair->valid ||
           !hz_valid(a,pair->rx_hz) || !hz_valid(a,pair->tx_hz) || pair->rx_hz==a->site.control_rx_hz) {
            p25_trunking_access_fault(a,P25_TRUNK_ACCESS_MAPPING,now);return true;
        }
        a->voice=*pair;a->voice_channel=event->channel;a->voice_options=event->options;
        a->queued=false;phase(a,P25_TRUNK_ACCESS_GRANTED,now);return true;
    }
    return false;
}
