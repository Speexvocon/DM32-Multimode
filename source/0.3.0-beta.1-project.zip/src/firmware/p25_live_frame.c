// SPDX-License-Identifier: GPL-3.0-or-later
// Fixed-storage adaptation of pinned OP25 imbe_unpack/header_encode/interleave.
// Reference and provenance: research/references/boatbod/op25, UPSTREAMS.json.
#include "p25_live_frame.h"
#include "p25_interleave.h"
#include "p25_test_vectors.h"
#include "p25_channel_masks.h"
#include <string.h>
_Static_assert(sizeof(p25_channel_frames)==549,"Template byte layout changed");
bool p25_channel_build(p25_channel_frames *out,uint32_t nac,uint32_t tg,uint32_t source) {
    if(!out || nac>0xfff || tg>0xffff || source>0xffffff) return false;
    memcpy(out->hdu,p25_test_hdu,99); memcpy(out->ldu1,p25_test_ldu1,216);
    memcpy(out->ldu2,p25_test_ldu2,216); memcpy(out->tdu,p25_test_tdu,18);
    const uint32_t values[]={nac^0x293u,tg^1u,source^1u};
    const unsigned widths[]={12,16,24};
    unsigned index=0;
    unsigned char *bytes=(unsigned char *)out;
    for(unsigned field=0;field<3;++field) for(unsigned bit=0;bit<widths[field];++bit,++index) {
        if(!(values[field]&(1u<<bit))) continue;
        for(unsigned j=p25_channel_index[index];j<p25_channel_index[index+1];++j) {
            uint32_t patch=p25_channel_masks[j]; bytes[patch>>8]^=(uint8_t)patch;
        }
    }
    return true;
}
// GF(64), x^6+x+1. Twelve parity symbols, first root alpha^1. The small
// polynomial encoder avoids adding a second bank of sparse channel tables.
static uint8_t lc_multiply(uint8_t a,uint8_t b) {
    uint8_t value=0;
    for(unsigned i=0;i<6;++i) {
        if(b&1)value^=a;
        a<<=1;if(a&0x40)a^=0x43;b>>=1;
    }
    return value;
}
static void encode_lc(uint8_t frame[216],const uint8_t lc[9]) {
    static const uint8_t polynomial[13]={1,57,5,45,3,57,28,48,9,60,2,33,40};
    static const uint16_t hamming_matrix[6]={0x20e,0x10d,0x08b,0x047,0x023,0x01c};
    uint8_t symbols[24]={0},remainder[24]={0};
    for(unsigned i=0;i<72;++i)
        symbols[i/6]|=(uint8_t)(((lc[i/8]>>(7-i%8))&1u)<<(5-i%6));
    memcpy(remainder,symbols,12);
    for(unsigned i=0;i<12;++i) {
        uint8_t factor=remainder[i];
        for(unsigned j=0;j<13;++j)remainder[i+j]^=lc_multiply(factor,polynomial[j]);
    }
    memcpy(symbols+12,remainder+12,12);
    for(unsigned i=0;i<24;++i) {
        uint16_t word=0;
        for(unsigned j=0;j<6;++j)if(symbols[i]&(32u>>j))word^=hamming_matrix[j];
        unsigned start=400+(i/4)*184+(i%4)*10;
        for(unsigned j=0;j<10;++j) {
            unsigned data_bit=start+j,bit=data_bit+2*(data_bit/70);
            uint8_t mask=(uint8_t)(1u<<(7-bit%8));
            frame[bit/8]=(uint8_t)((frame[bit/8]&~mask)|((word&(1u<<(9-j)))?mask:0));
        }
    }
}
bool p25_channel_build_call(p25_channel_frames *out,uint32_t nac,uint32_t tg,
                           uint32_t source,bool private_call,uint32_t destination) {
    // Validate the complete request before touching output, including ignored
    // group context, so callers cannot silently retain an invalid channel.
    if(!out || nac>0xfff || tg>0xffff || source>0xffffff
        || destination>0xffffff || (private_call && !destination))return false;
    if(!p25_channel_build(out,nac,private_call?0:tg,source))return false;
    if(private_call) {
        const uint8_t lc[9]={3,0,0,(uint8_t)(destination>>16),(uint8_t)(destination>>8),
            (uint8_t)destination,(uint8_t)(source>>16),(uint8_t)(source>>8),(uint8_t)source};
        encode_lc(out->ldu1,lc);
    }
    return true;
}
bool p25_channel_build_group_options(p25_channel_frames *out,uint32_t nac,uint32_t tg,
                                    uint32_t source,uint8_t options) {
    // The bounded laboratory grant supports clear half-duplex circuit voice:
    // emergency and priority only. Reject unsupported/encrypted service bits
    // before touching any output, just as the existing call factory does.
    if(options&~0x87u)return false;
    if(!p25_channel_build(out,nac,tg,source))return false;
    if(options) {
        const uint8_t lc[9]={0,0,options,0,(uint8_t)(tg>>8),(uint8_t)tg,
            (uint8_t)(source>>16),(uint8_t)(source>>8),(uint8_t)source};
        encode_lc(out->ldu1,lc);
    }
    return true;
}
static uint32_t golay(uint32_t u) {
    static const uint32_t g[12]={040006165,020003073,010007550,04003664,02001732,01006631,
        0403315,0201547,0106706,045227,024476,014353};
    uint32_t v=0;
    for(unsigned i=0;i<12;++i) if(u&(1u<<(11-i))) v^=g[i];
    return v>>1;
}
static uint32_t hamming(uint32_t u) {
    static const uint16_t g[11]={0x400f,0x200e,0x100d,0x080c,0x040b,0x020a,0x0109,0x0087,0x0046,0x0025,0x0013};
    uint32_t v=0;
    for(unsigned i=0;i<11;++i) if(u&(1u<<(10-i))) v^=g[i];
    return v;
}
static uint32_t pn_bits(uint32_t *pn,unsigned bits) {
    uint32_t value=0;
    for(unsigned i=0;i<bits;++i) {
        *pn=(173u**pn+13849u)&0xffffu;
        value=(value<<1)|(*pn>>15);
    }
    return value;
}
void p25_live_ldu(uint8_t out[216],const uint8_t payload[9][11],bool ldu2) {
    p25_live_ldu_template(out,payload,ldu2 ? p25_test_ldu2 : p25_test_ldu1);
}
void p25_live_ldu_template(uint8_t out[216],const uint8_t payload[9][11],const uint8_t base[216]) {
    memcpy(out,base,216);
    for(unsigned f=0;f<9;++f) {
        const uint8_t *p=payload[f];
        uint32_t u[8]={ (p[0]<<4)|(p[1]>>4), ((p[1]&15)<<8)|p[2],
            (p[3]<<4)|(p[4]>>4), ((p[4]&15)<<8)|p[5],
            (p[6]<<3)|(p[7]>>5), ((p[7]&31)<<6)|(p[8]>>2),
            ((p[8]&3)<<9)|(p[9]<<1)|(p[10]>>7), p[10]&127 };
        uint32_t pn=u[0]<<4;
        unsigned index=0;
        for(unsigned j=0;j<8;++j) {
            unsigned bits=j<4 ? 23 : j<7 ? 15 : 7;
            uint32_t value=j<4 ? golay(u[j]) : j<7 ? hamming(u[j]) : u[j];
            if(j>0 && j<7) value^=pn_bits(&pn,bits);
            for(unsigned b=0;b<bits;++b) {
                unsigned bit=p25_voice_bits[f][index++];
                uint8_t mask=(uint8_t)(1u<<(7-bit%8));
                out[bit/8]=(uint8_t)((out[bit/8]&~mask)|(((value>>(bits-1-b))&1u) ? mask : 0));
            }
        }
    }
}
