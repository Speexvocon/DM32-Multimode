// SPDX-License-Identifier: GPL-3.0-or-later
// Primary layout: pinned modem-hrc7000.md8.5: BE16 recorder samples, two512-byte
// halves; bit14 half-fill IRQ and FM_ADDR_SW1/2 identify a completed half. Which
// bytes update between those interrupts is deliberately an open measurement.
#include "p25_rx_progress.h"
#include <limits.h>
#include <string.h>

_Static_assert(sizeof(p25_rx_progress_row)==P25_RX_PROGRESS_ROW_BYTES,"Progress row layout changed");
_Static_assert(offsetof(p25_rx_progress_row,cpu_begin_us)==64,"Progress timestamp layout changed");
_Static_assert(offsetof(p25_rx_progress_row,changed_mask)==88,"Progress mask layout changed");
_Static_assert(offsetof(p25_rx_progress_row,half_begin)==92,"Progress flags layout changed");
_Static_assert(sizeof(p25_rx_progress)<=128,"Progress controller exceeds compact-state budget");
const uint8_t p25_rx_progress_indices[P25_RX_PROGRESS_POINTS]={0,36,72,108,144,180,216,255};

void p25_rx_progress_init(p25_rx_progress *s) {if(s)memset(s,0,sizeof *s);}
bool p25_rx_progress_active(const p25_rx_progress *s) {
    return s && (s->state==P25_RX_PROGRESS_WAIT_IRQ || s->state==P25_RX_PROGRESS_RECORDING);
}
bool p25_rx_progress_start(p25_rx_progress *s,void *storage,size_t bytes,
    const p25_rx_progress_config *config,uint32_t now) {
    if(!s || !storage || !config || p25_rx_progress_active(s))return false;
    p25_rx_progress_config c=*config;
    size_t need=(size_t)c.rows*P25_RX_PROGRESS_ROW_BYTES;
    uintptr_t begin=(uintptr_t)storage,object=(uintptr_t)s;
    if(!c.rows || c.rows>P25_RX_PROGRESS_MAX_ROWS || bytes<need || begin>UINTPTR_MAX-need
       || object>UINTPTR_MAX-sizeof *s || (begin<object+sizeof *s && object<begin+need)
       || c.cadence_us<P25_RX_PROGRESS_MIN_CADENCE_US || c.cadence_us>P25_RX_PROGRESS_MAX_CADENCE_US
       || c.timeout_us<P25_RX_PROGRESS_MIN_TIMEOUT_US || c.timeout_us>P25_RX_PROGRESS_MAX_TIMEOUT_US
       || (uint32_t)(c.rows-1u)*c.cadence_us>=c.timeout_us)return false;
    memset(s,0,sizeof *s);s->storage=storage;s->limit=c.rows;s->cadence_us=c.cadence_us;
    s->armed_us=s->next_due_us=now;s->timeout_us=c.timeout_us;s->state=P25_RX_PROGRESS_WAIT_IRQ;
    return true;
}
static bool expired(p25_rx_progress *s,uint32_t now) {
    uint32_t elapsed=now-s->armed_us;
    if(elapsed>INT32_MAX) {s->state=P25_RX_PROGRESS_CLOCK_ERROR;return true;}
    if(elapsed>=s->timeout_us) {s->state=P25_RX_PROGRESS_TIMEOUT;return true;}
    return false;
}
bool p25_rx_progress_irq(p25_rx_progress *s,unsigned half,uint32_t now) {
    if(!p25_rx_progress_active(s) || expired(s,now))return false;
    uint32_t serial=s->irq_serial;s->irq_serial=serial+1u;
    if(half!=1u && half!=2u) {
        ++s->invalid_irqs;s->irq_serial=serial+2u;return false;
    }
    if(s->valid_irqs) {
        uint32_t delta=now-s->last_irq_us;
        if(delta>INT32_MAX) {
            ++s->sequence_errors;s->state=P25_RX_PROGRESS_CLOCK_ERROR;
            s->irq_serial=serial+2u;return false;
        }
        // Record anomalies without interpreting them as an RF/sample clock.
        if(half==s->completed_half || !delta || delta>48000u)++s->sequence_errors;
    }
    s->last_irq_us=now;s->completed_half=(uint8_t)half;++s->valid_irqs;
    s->state=P25_RX_PROGRESS_RECORDING;s->irq_serial=serial+2u;return true;
}
typedef struct {uint32_t time,count,invalid,sequence;uint8_t half;bool stable;} irq_view;
static irq_view snapshot_irq(const p25_rx_progress *s) {
    uint32_t serial=s->irq_serial;
    irq_view v={.time=s->last_irq_us,.count=s->valid_irqs,.invalid=s->invalid_irqs,
        .sequence=s->sequence_errors,.half=s->completed_half};
    uint32_t after=s->irq_serial;v.stable=!(serial&1u) && serial==after;
    return v;
}
static void put16(unsigned char *p,uint16_t value) {p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8);}
static void put32(unsigned char *p,uint32_t value) {
    for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(value>>(8u*i));
}
static uint16_t get16(const unsigned char *p) {return (uint16_t)((unsigned)p[0]|(unsigned)p[1]<<8);}
static uint32_t get32(const unsigned char *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static int16_t signed16(uint16_t value) {return (int16_t)(value<=INT16_MAX ? (int32_t)value : (int32_t)value-65536);}
static void store_row(unsigned char *p,const p25_rx_progress_row *row) {
    for(unsigned i=0;i<16;++i) {put16(p+2u*i,(uint16_t)row->first[i]);put16(p+32u+2u*i,(uint16_t)row->second[i]);}
    put32(p+64,row->cpu_begin_us);put32(p+68,row->cpu_end_us);put32(p+72,row->irq_begin_us);
    put32(p+76,row->irq_end_us);put32(p+80,row->irq_count_begin);put32(p+84,row->irq_count_end);
    put16(p+88,row->changed_mask);put16(p+90,row->torn_mask);
    p[92]=row->half_begin;p[93]=row->half_end;p[94]=row->flags;p[95]=row->missed_periods;
}
static void read_pass(const p25_rx_progress_io *io,int16_t out[16],uint16_t *torn) {
    for(unsigned i=0;i<16;++i) {
        unsigned offset=(i/8u)*P25_RX_PROGRESS_HALF_BYTES+2u*p25_rx_progress_indices[i%8u];
        uint8_t high=io->read_byte(io->context,offset),low=io->read_byte(io->context,offset+1u);
        uint8_t again=io->read_byte(io->context,offset);
        if(high!=again)*torn|=(uint16_t)(1u<<i);
        out[i]=signed16((uint16_t)((unsigned)high<<8|low));
    }
}
bool p25_rx_progress_poll(p25_rx_progress *s,const p25_rx_progress_io *io,uint32_t now) {
    if(!p25_rx_progress_active(s) || expired(s,now))return false;
    if(s->have_poll && now-s->last_poll_us>INT32_MAX) {s->state=P25_RX_PROGRESS_CLOCK_ERROR;return false;}
    s->last_poll_us=now;s->have_poll=true;
    if(s->state!=P25_RX_PROGRESS_RECORDING || !io || !io->read_byte || !io->clock_us)return false;
    if(!s->storage || !s->limit || s->limit>P25_RX_PROGRESS_MAX_ROWS || s->count>=s->limit) {
        s->state=P25_RX_PROGRESS_CANCELLED;return false;
    }
    if(!s->count)s->next_due_us=s->last_irq_us;
    if((int32_t)(now-s->next_due_us)<0)return false;
    uint32_t missed=(now-s->next_due_us)/s->cadence_us;
    s->next_due_us+=(missed+1u)*s->cadence_us;
    if(UINT32_MAX-s->missed_periods<missed)s->missed_periods=UINT32_MAX;else s->missed_periods+=missed;
    p25_rx_progress_row row={0};irq_view before=snapshot_irq(s);
    row.cpu_begin_us=io->clock_us(io->context);
    read_pass(io,row.first,&row.torn_mask);read_pass(io,row.second,&row.torn_mask);
    row.cpu_end_us=io->clock_us(io->context);irq_view after=snapshot_irq(s);
    row.irq_begin_us=before.time;row.irq_end_us=after.time;row.irq_count_begin=before.count;row.irq_count_end=after.count;
    row.half_begin=before.half;row.half_end=after.half;
    if(!before.stable || !after.stable)row.flags|=P25_RX_PROGRESS_META_UNSTABLE;
    if(before.count!=after.count || before.time!=after.time || before.half!=after.half)row.flags|=P25_RX_PROGRESS_IRQ_DURING_READ;
    for(unsigned i=0;i<16;++i)if(row.first[i]!=row.second[i])row.changed_mask|=(uint16_t)(1u<<i);
    if(row.torn_mask)row.flags|=P25_RX_PROGRESS_WORD_TORN;
    if(row.changed_mask)row.flags|=P25_RX_PROGRESS_VALUES_CHANGED;
    if(before.invalid!=s->previous_invalid || after.invalid!=before.invalid)row.flags|=P25_RX_PROGRESS_INVALID_IRQ;
    if(before.sequence!=s->previous_sequence || after.sequence!=before.sequence)row.flags|=P25_RX_PROGRESS_IRQ_SEQUENCE;
    s->previous_invalid=after.invalid;s->previous_sequence=after.sequence;
    if(missed)row.flags|=P25_RX_PROGRESS_MISSED_CADENCE;
    row.missed_periods=(uint8_t)(missed>UINT8_MAX ? UINT8_MAX : missed);
    if(row.cpu_begin_us-now>INT32_MAX || row.cpu_end_us-row.cpu_begin_us>INT32_MAX
       || s->state==P25_RX_PROGRESS_CLOCK_ERROR) {
        row.flags|=P25_RX_PROGRESS_CLOCK_ANOMALY;s->state=P25_RX_PROGRESS_CLOCK_ERROR;
    }
    // Character stores preserve the declared monitor.pcm type; there is no
    // row-struct alias into that borrowed int16_t array and no alignment need.
    store_row(s->storage+(size_t)s->count*P25_RX_PROGRESS_ROW_BYTES,&row);++s->count;
    if(s->state==P25_RX_PROGRESS_RECORDING && !expired(s,row.cpu_end_us)
       && s->count==s->limit)s->state=P25_RX_PROGRESS_DONE;
    return true;
}
void p25_rx_progress_cancel(p25_rx_progress *s) {
    if(p25_rx_progress_active(s))s->state=P25_RX_PROGRESS_CANCELLED;
}
bool p25_rx_progress_read(const p25_rx_progress *s,unsigned index,p25_rx_progress_row *out) {
    if(!s || !out || p25_rx_progress_active(s) || index>=s->count || !s->storage)return false;
    const unsigned char *p=s->storage+(size_t)index*P25_RX_PROGRESS_ROW_BYTES;
    p25_rx_progress_row row={0};
    for(unsigned i=0;i<16;++i) {row.first[i]=signed16(get16(p+2u*i));row.second[i]=signed16(get16(p+32u+2u*i));}
    row.cpu_begin_us=get32(p+64);row.cpu_end_us=get32(p+68);row.irq_begin_us=get32(p+72);row.irq_end_us=get32(p+76);
    row.irq_count_begin=get32(p+80);row.irq_count_end=get32(p+84);row.changed_mask=get16(p+88);row.torn_mask=get16(p+90);
    row.half_begin=p[92];row.half_end=p[93];row.flags=p[94];row.missed_periods=p[95];*out=row;return true;
}

_Static_assert(sizeof(p25_rx_chunk_row)==P25_RX_CHUNK_ROW_BYTES,"Chunk row layout changed");
_Static_assert(offsetof(p25_rx_chunk_row,cpu_begin_us)==96,"Chunk clock layout changed");
_Static_assert(offsetof(p25_rx_chunk_row,flags)==138,"Chunk flag layout changed");
_Static_assert(offsetof(p25_rx_chunk_row,target_half)==140,"Chunk half layout changed");
_Static_assert(sizeof(p25_rx_chunk)<=160,"Chunk controller exceeds compact-state budget");
static void chunk_store(unsigned char *p,const p25_rx_chunk_row *r) {
    for(unsigned i=0;i<P25_RX_CHUNK_SAMPLES;++i) {
        put16(p+2u*i,(uint16_t)r->first[i]);put16(p+32u+2u*i,(uint16_t)r->second[i]);
        put16(p+64u+2u*i,(uint16_t)r->completed[i]);
    }
    put32(p+96,r->cpu_begin_us);put32(p+100,r->cpu_end_us);put32(p+104,r->origin_irq_us);
    put32(p+108,r->compare_begin_us);put32(p+112,r->compare_end_us);put32(p+116,r->completion_irq_us);
    put32(p+120,r->origin_irq_count);put32(p+124,r->completion_irq_count);
    put16(p+128,r->sample_offset);put16(p+130,r->changed_mask);put16(p+132,r->torn_mask);
    put16(p+134,r->mismatch_mask);put16(p+136,r->completed_torn_mask);put16(p+138,r->flags);
    p[140]=r->target_half;p[141]=p[142]=p[143]=0;
}
static void chunk_load(const unsigned char *p,p25_rx_chunk_row *r) {
    memset(r,0,sizeof *r);
    for(unsigned i=0;i<P25_RX_CHUNK_SAMPLES;++i) {
        r->first[i]=signed16(get16(p+2u*i));r->second[i]=signed16(get16(p+32u+2u*i));
        r->completed[i]=signed16(get16(p+64u+2u*i));
    }
    r->cpu_begin_us=get32(p+96);r->cpu_end_us=get32(p+100);r->origin_irq_us=get32(p+104);
    r->compare_begin_us=get32(p+108);r->compare_end_us=get32(p+112);r->completion_irq_us=get32(p+116);
    r->origin_irq_count=get32(p+120);r->completion_irq_count=get32(p+124);
    r->sample_offset=get16(p+128);r->changed_mask=get16(p+130);r->torn_mask=get16(p+132);
    r->mismatch_mask=get16(p+134);r->completed_torn_mask=get16(p+136);r->flags=get16(p+138);r->target_half=p[140];
}
void p25_rx_chunk_init(p25_rx_chunk *s) {if(s)memset(s,0,sizeof *s);}
bool p25_rx_chunk_active(const p25_rx_chunk *s) {return s && p25_rx_progress_active(&s->base);}
bool p25_rx_chunk_start(p25_rx_chunk *s,void *storage,size_t bytes,const p25_rx_chunk_config *config,uint32_t now) {
    if(!s || !storage || !config || p25_rx_chunk_active(s))return false;
    p25_rx_chunk_config c=*config;
    size_t need=(size_t)c.rows*P25_RX_CHUNK_ROW_BYTES;
    uintptr_t begin=(uintptr_t)storage,object=(uintptr_t)s;
    if(!c.rows || c.rows>P25_RX_CHUNK_MAX_ROWS || c.guard_us>P25_RX_CHUNK_MAX_GUARD_US
       || bytes<need || begin>UINTPTR_MAX-need || object>UINTPTR_MAX-sizeof *s
       || (begin<object+sizeof *s && object<begin+need))return false;
    memset(s,0,sizeof *s);
    p25_rx_progress_config base={c.rows,P25_RX_CHUNK_PERIOD_US,P25_RX_PROGRESS_MAX_TIMEOUT_US};
    // The stricter full-object/full-row bounds were checked before any mutation.
    if(!p25_rx_progress_start(&s->base,storage,bytes,&base,now))return false;
    s->guard_us=c.guard_us;return true;
}
bool p25_rx_chunk_irq(p25_rx_chunk *s,unsigned half,uint32_t now) {
    return s && p25_rx_progress_irq(&s->base,half,now);
}
static void chunk_finalize(p25_rx_chunk *s) {
    if(s->finalized || !s->base.storage)return;
    // Only the task finalizes rows. In particular, an ISR timeout never copies
    // samples or touches borrowed storage. Unpaired data cannot look matched.
    unsigned count=s->base.count>P25_RX_CHUNK_MAX_ROWS ? P25_RX_CHUNK_MAX_ROWS : s->base.count;
    for(unsigned i=s->next_verify;i<count;++i) {
        unsigned char *p=s->base.storage+(size_t)i*P25_RX_CHUNK_ROW_BYTES;
        put16(p+138,(uint16_t)(get16(p+138)|P25_RX_CHUNK_UNPAIRED));
    }
    s->finalized=true;
}
static void chunk_pass(const p25_rx_progress_io *io,unsigned half,unsigned index,int16_t out[16],uint16_t *torn) {
    for(unsigned i=0;i<P25_RX_CHUNK_SAMPLES;++i) {
        unsigned offset=(half-1u)*P25_RX_PROGRESS_HALF_BYTES+2u*(index+i);
        uint8_t high=io->read_byte(io->context,offset),low=io->read_byte(io->context,offset+1u);
        uint8_t again=io->read_byte(io->context,offset);
        if(high!=again)*torn|=(uint16_t)(1u<<i);
        out[i]=signed16((uint16_t)((unsigned)high<<8|low));
    }
}
static bool chunk_epoch_changed(irq_view before,irq_view after) {
    return before.count!=after.count || before.time!=after.time || before.half!=after.half;
}
static bool chunk_compare(p25_rx_chunk *s,const p25_rx_progress_io *io,uint32_t now,irq_view before) {
    if(s->next_verify>=s->base.count)return false;
    unsigned char *p=s->base.storage+(size_t)s->next_verify*P25_RX_CHUNK_ROW_BYTES;
    p25_rx_chunk_row row;chunk_load(p,&row);
    if(before.count==row.origin_irq_count)return false;
    if(before.count-row.origin_irq_count!=1u || before.half!=row.target_half
       || now-before.time>=P25_RX_CHUNK_HALF_US) {
        row.flags|=P25_RX_CHUNK_OVERWRITTEN|P25_RX_CHUNK_UNPAIRED;
    } else {
        row.completion_irq_us=before.time;row.completion_irq_count=before.count;
        row.compare_begin_us=io->clock_us(io->context);
        chunk_pass(io,row.target_half,row.sample_offset,row.completed,&row.completed_torn_mask);
        row.compare_end_us=io->clock_us(io->context);irq_view after=snapshot_irq(&s->base);
        row.flags|=P25_RX_CHUNK_COMPARED;
        if(!before.stable || !after.stable)row.flags|=P25_RX_CHUNK_COMPARE_META_UNSTABLE;
        if(chunk_epoch_changed(before,after))row.flags|=P25_RX_CHUNK_COMPARE_IRQ_DURING_READ|P25_RX_CHUNK_OVERWRITTEN;
        if(io->half_pending && io->half_pending(io->context))row.flags|=P25_RX_CHUNK_COMPARE_IRQ_DURING_READ|P25_RX_CHUNK_OVERWRITTEN;
        if(before.sequence || after.sequence || before.invalid || after.invalid)row.flags|=P25_RX_CHUNK_IRQ_SEQUENCE;
        if(row.completed_torn_mask)row.flags|=P25_RX_CHUNK_COMPARE_WORD_TORN;
        if(row.compare_begin_us-now>INT32_MAX || row.compare_end_us-row.compare_begin_us>INT32_MAX
           || s->base.state==P25_RX_PROGRESS_CLOCK_ERROR) {
            row.flags|=P25_RX_CHUNK_CLOCK_ANOMALY|P25_RX_CHUNK_OVERWRITTEN;s->base.state=P25_RX_PROGRESS_CLOCK_ERROR;
        }
        if(row.compare_end_us-before.time>=P25_RX_CHUNK_HALF_US)row.flags|=P25_RX_CHUNK_OVERWRITTEN;
        if(p25_rx_chunk_active(s) && expired(&s->base,row.compare_end_us))row.flags|=P25_RX_CHUNK_UNPAIRED;
        if(!p25_rx_chunk_active(s))row.flags|=P25_RX_CHUNK_UNPAIRED;
        for(unsigned i=0;i<P25_RX_CHUNK_SAMPLES;++i)if(row.second[i]!=row.completed[i])row.mismatch_mask|=(uint16_t)(1u<<i);
        if(row.mismatch_mask) {row.flags|=P25_RX_CHUNK_MISMATCH;++s->mismatches;}
        ++s->compared;
    }
    chunk_store(p,&row);++s->next_verify;
    if(p25_rx_chunk_active(s) && !expired(&s->base,now) && s->base.count==s->base.limit && s->next_verify==s->base.count) {
        s->base.state=P25_RX_PROGRESS_DONE;s->finalized=true;
    }
    return true;
}
bool p25_rx_chunk_step(p25_rx_chunk *s,const p25_rx_progress_io *io,uint32_t now) {
    if(!s)return false;
    if(!p25_rx_chunk_active(s) || expired(&s->base,now))return false;
    if(s->base.have_poll && now-s->base.last_poll_us>INT32_MAX) {
        s->base.state=P25_RX_PROGRESS_CLOCK_ERROR;return false;
    }
    s->base.last_poll_us=now;s->base.have_poll=true;
    if(s->base.state!=P25_RX_PROGRESS_RECORDING || !io || !io->read_byte || !io->clock_us)return false;
    if(!s->base.storage || !s->base.limit || s->base.limit>P25_RX_CHUNK_MAX_ROWS || s->base.count>s->base.limit) {
        s->base.state=P25_RX_PROGRESS_CANCELLED;return false;
    }
    if(io->half_pending && io->half_pending(io->context))return false;
    irq_view before=snapshot_irq(&s->base);
    // Compare before taking another candidate: a completed half is available
    // for only one subsequent fill interval. One operation per poll is bounded.
    if(chunk_compare(s,io,now,before))return true;
    if(s->base.count==s->base.limit)return false; // Drain pending candidates.
    if(s->observed_irq!=before.count) {
        if(s->observed_irq && s->next_sample<256u)s->skipped_chunks+=(256u-s->next_sample)/P25_RX_CHUNK_SAMPLES;
        s->observed_irq=before.count;s->next_sample=0;
    }
    uint32_t age=now-before.time;
    if(age>INT32_MAX) {s->base.state=P25_RX_PROGRESS_CLOCK_ERROR;return false;}
    if(age>=P25_RX_CHUNK_HALF_US || age<(uint32_t)s->guard_us+P25_RX_CHUNK_PERIOD_US)return false;
    unsigned latest=(unsigned)((age-s->guard_us)/P25_RX_CHUNK_PERIOD_US-1u)*P25_RX_CHUNK_SAMPLES;
    if(latest>240u)latest=240u;
    if(latest<s->next_sample)return false;
    s->skipped_chunks+=(latest-s->next_sample)/P25_RX_CHUNK_SAMPLES;
    s->next_sample=(uint16_t)(latest+P25_RX_CHUNK_SAMPLES);
    p25_rx_chunk_row row={0};row.origin_irq_us=before.time;row.origin_irq_count=before.count;
    row.sample_offset=(uint16_t)latest;row.target_half=(uint8_t)(3u-before.half);
    row.cpu_begin_us=io->clock_us(io->context);
    chunk_pass(io,row.target_half,latest,row.first,&row.torn_mask);
    chunk_pass(io,row.target_half,latest,row.second,&row.torn_mask);
    row.cpu_end_us=io->clock_us(io->context);irq_view after=snapshot_irq(&s->base);
    if(!before.stable || !after.stable)row.flags|=P25_RX_CHUNK_META_UNSTABLE;
    if(chunk_epoch_changed(before,after))row.flags|=P25_RX_CHUNK_IRQ_DURING_READ;
    if(io->half_pending && io->half_pending(io->context))row.flags|=P25_RX_CHUNK_IRQ_DURING_READ;
    if(before.sequence || after.sequence || before.invalid || after.invalid)row.flags|=P25_RX_CHUNK_IRQ_SEQUENCE;
    if(row.torn_mask)row.flags|=P25_RX_CHUNK_WORD_TORN;
    for(unsigned i=0;i<P25_RX_CHUNK_SAMPLES;++i)if(row.first[i]!=row.second[i])row.changed_mask|=(uint16_t)(1u<<i);
    if(row.changed_mask)row.flags|=P25_RX_CHUNK_VALUES_CHANGED;
    uint32_t due=before.time+(latest+P25_RX_CHUNK_SAMPLES)*125u+s->guard_us;
    if((row.cpu_begin_us-due>=P25_RX_CHUNK_PERIOD_US && row.cpu_begin_us-due<=INT32_MAX)
       || row.cpu_end_us-before.time>=P25_RX_CHUNK_HALF_US)row.flags|=P25_RX_CHUNK_SCHEDULE_LATE;
    if(row.cpu_begin_us-now>INT32_MAX || row.cpu_end_us-row.cpu_begin_us>INT32_MAX) {
        row.flags|=P25_RX_CHUNK_CLOCK_ANOMALY;s->base.state=P25_RX_PROGRESS_CLOCK_ERROR;
    }
    chunk_store(s->base.storage+(size_t)s->base.count*P25_RX_CHUNK_ROW_BYTES,&row);++s->base.count;
    if(p25_rx_chunk_active(s))(void)expired(&s->base,row.cpu_end_us);
    return true;
}
bool p25_rx_chunk_poll(p25_rx_chunk *s,const p25_rx_progress_io *io,uint32_t now) {
    bool result=p25_rx_chunk_step(s,io,now);
    if(s && !p25_rx_chunk_active(s))chunk_finalize(s);
    return result;
}
void p25_rx_chunk_cancel(p25_rx_chunk *s) {
    if(s) {p25_rx_progress_cancel(&s->base);chunk_finalize(s);}
}
bool p25_rx_chunk_read(const p25_rx_chunk *s,unsigned index,p25_rx_chunk_row *out) {
    if(!s || !out || p25_rx_chunk_active(s) || index>=s->base.count || !s->base.storage)return false;
    chunk_load(s->base.storage+(size_t)index*P25_RX_CHUNK_ROW_BYTES,out);return true;
}
