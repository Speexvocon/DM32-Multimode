// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx_stream.h"
#include <string.h>
#include <limits.h>
static uint16_t get16(const unsigned char *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static uint32_t get32(const unsigned char *p) {return (uint32_t)get16(p)|(uint32_t)get16(p+2)<<16;}
static uint64_t get64(const unsigned char *p) {return (uint64_t)get32(p)|(uint64_t)get32(p+4)<<32;}
static void put16(unsigned char *p,uint16_t n) {p[0]=(unsigned char)n;p[1]=(unsigned char)(n>>8);}
static void put32(unsigned char *p,uint32_t n) {put16(p,(uint16_t)n);put16(p+2,(uint16_t)(n>>16));}
static void put64(unsigned char *p,uint64_t n) {put32(p,(uint32_t)n);put32(p+4,(uint32_t)(n>>32));}
static unsigned char *half_row(const p25_rx_stream *s,unsigned n) {return s->ledger+n*48u;}
static unsigned char *ring_row(const p25_rx_stream *s,uint32_t sample) {return s->ring+((sample/16u)%128u)*64u;}
static void add16(unsigned char *p,unsigned n) {put16(p,(uint16_t)(get16(p)+n));}
static uint32_t hash_word(uint32_t h,int16_t v) {
    h^=(uint8_t)v;h*=16777619u;h^=(uint8_t)((uint16_t)v>>8);return h*16777619u;
}
static bool disjoint(const void *a,size_t na,const void *b,size_t nb) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    return x<=UINTPTR_MAX-na&&y<=UINTPTR_MAX-nb&&(x+na<=y||y+nb<=x);
}
static void fail(p25_rx_stream *s,unsigned flag) {
    if(!p25_rx_stream_active(s)&&s->state!=P25_RX_STREAM_DRAINING)return;
    s->faults|=(uint16_t)flag;
    if(s->halves) {unsigned n=s->produced/256u;if(n>=s->halves)n=s->halves-1u;
        unsigned char *p=half_row(s,n);put16(p+36,(uint16_t)(get16(p+36)|flag));}
    s->state=P25_RX_STREAM_FAULT;
}
void p25_rx_stream_init(p25_rx_stream *s) {if(s)memset(s,0,sizeof *s);}
bool p25_rx_stream_active(const p25_rx_stream *s) {
    return s&&(s->state==P25_RX_STREAM_WAIT||s->state==P25_RX_STREAM_RUNNING);
}
bool p25_rx_stream_start(p25_rx_stream *s,void *ring,size_t ring_bytes,
    void *ledger,size_t ledger_bytes,unsigned samples,unsigned guard,uint32_t epoch,uint32_t now) {
    if(!s||!ring||!ledger||p25_rx_stream_active(s)||s->state==P25_RX_STREAM_DRAINING
       ||ring_bytes<8192u||ledger_bytes<15360u||samples<256u||samples>16384u
       ||samples%256u||guard>8000u||!disjoint(ring,8192u,ledger,15360u)
       ||!disjoint(s,sizeof *s,ring,8192u)||!disjoint(s,sizeof *s,ledger,15360u))return false;
    p25_rx_stream_init(s);s->ring=ring;s->ledger=ledger;
    memset(ledger,0,15360u);s->limit_halves=(uint16_t)(samples/256u);
    s->guard_us=(uint16_t)guard;s->armed_us=now;s->stream_epoch=epoch;
    s->marker_bytes=P25_RX_STREAM_MARK_BYTES;
    s->state=P25_RX_STREAM_WAIT;return true;
}
bool p25_rx_stream_origin_start(p25_rx_stream *s,void *ring,size_t ring_bytes,
    void *ledger,size_t ledger_bytes,unsigned samples,unsigned guard,uint32_t epoch,uint32_t now) {
    if(samples>P25_RX_STREAM_ORIGIN_MAX_SAMPLES
       ||!p25_rx_stream_start(s,ring,ring_bytes,ledger,ledger_bytes,samples,guard,epoch,now))return false;
    s->marker_bytes=P25_RX_STREAM_ORIGIN_MARK_BYTES;s->marker_schema=1u;return true;
}
bool p25_rx_stream_early_start(p25_rx_stream *s,void *ring,size_t ring_bytes,
    void *ledger,size_t ledger_bytes,unsigned samples,unsigned guard,uint32_t epoch,uint32_t now) {
    if(samples>P25_RX_STREAM_EARLY_MAX_SAMPLES
       ||!p25_rx_stream_origin_start(s,ring,ring_bytes,ledger,ledger_bytes,samples,guard,epoch,now))return false;
    s->marker_schema=2u;return true;
}
static void begin_half(p25_rx_stream *s,unsigned index,uint32_t now) {
    unsigned char *p=half_row(s,index);put64(p,(uint64_t)index*256u);
    put32(p+8,now);put32(p+16,2166136261u);put32(p+20,2166136261u);
    put32(p+24,s->irq_count);s->halves=(uint16_t)(index+1u);
}
void p25_rx_stream_irq(p25_rx_stream *s,unsigned half,uint32_t now) {
    if(!p25_rx_stream_active(s))return;
    ++s->irq_serial;
    if((half!=1u&&half!=2u)||(s->irq_count&&half==s->last_half)) {
        fail(s,P25_RX_STREAM_SEQUENCE);++s->irq_serial;return;
    }
    if(s->irq_count) {
        uint32_t elapsed=now-s->last_irq_us;
        if(elapsed<30000u||elapsed>34000u) {fail(s,P25_RX_STREAM_CLOCK);++s->irq_serial;return;}
        // At this edge the half completed one IRQ ago starts being overwritten.
        if(s->completed_halves&&s->verified<(uint32_t)s->completed_halves*256u) {
            fail(s,P25_RX_STREAM_OVERWRITTEN);++s->irq_serial;return;
        }
    }
    s->last_half=(uint8_t)half;s->last_irq_us=now;++s->irq_count;
    if(s->state==P25_RX_STREAM_WAIT) {begin_half(s,0,now);s->state=P25_RX_STREAM_RUNNING;}
    else {
        unsigned index=s->irq_count-2u;
        if(index<s->limit_halves) {
            put32(half_row(s,index)+12,now);s->completed_halves=(uint16_t)(index+1u);
            if(index+1u<s->limit_halves)begin_half(s,index+1u,now);
        }
    }
    ++s->irq_serial;
}
static bool read_words(const p25_rx_progress_io *io,unsigned half,unsigned offset,int16_t *out) {
    bool torn=false;unsigned base=(half-1u)*512u+offset*2u;
    for(unsigned i=0;i<16u;++i) {
        uint8_t hi=io->read_byte(io->context,base+2u*i);
        uint8_t lo=io->read_byte(io->context,base+2u*i+1u);
        if(hi!=io->read_byte(io->context,base+2u*i))torn=true;
        out[i]=(int16_t)((uint16_t)hi<<8|lo);
    }
    return torn;
}
static bool pending(const p25_rx_progress_io *io) {return io->half_pending&&io->half_pending(io->context);}
bool p25_rx_stream_step(p25_rx_stream *s,const p25_rx_progress_io *io,uint32_t now) {
    if(!p25_rx_stream_active(s))return false;
    if(s->have_step&&(uint32_t)(now-s->last_step_us)>INT32_MAX) {fail(s,P25_RX_STREAM_CLOCK);return false;}
    s->have_step=true;s->last_step_us=now;
    if((uint32_t)(now-s->armed_us)>P25_RX_STREAM_TIMEOUT_US) {s->state=P25_RX_STREAM_TIMEOUT;return false;}
    if(s->state==P25_RX_STREAM_WAIT||!io||!io->read_byte||!io->clock_us||pending(io))return false;
    uint32_t serial=s->irq_serial,count=s->irq_count,irq=s->last_irq_us;
    unsigned completed=s->completed_halves,half=s->last_half;
    if(serial&1u) {fail(s,P25_RX_STREAM_META);return false;}
    uint32_t age=now-irq;
    if(age>=34000u) {fail(s,P25_RX_STREAM_CLOCK);return false;}
    uint32_t total=(uint32_t)s->limit_halves*256u,ordinal=s->produced;
    unsigned index=ordinal/256u,offset=ordinal%256u,target=3u-half;
    bool tail=index<completed;
    bool ready=ordinal<total&&(tail||(index==completed&&age>=(offset+16u)*125u+s->guard_us&&age<32000u));
    if(ready) {
        if(tail) {if(index+1u!=completed) {fail(s,P25_RX_STREAM_OVERWRITTEN);return false;}target=half;}
        uint32_t retained=s->consumed<s->verified?s->consumed:s->verified;
        if(ordinal-retained>=128u*16u) {fail(s,P25_RX_STREAM_RING_FULL);return false;}
        int16_t a[16],b[16];uint32_t begin=io->clock_us(io->context);
        bool torn=read_words(io,target,offset,a);torn=read_words(io,target,offset,b)||torn;
        uint32_t end=io->clock_us(io->context);unsigned flags=0;
        if(!p25_rx_stream_active(s))return false;
        if(torn)flags|=P25_RX_STREAM_TORN;
        for(unsigned i=0;i<16u;++i)if(a[i]!=b[i])flags|=P25_RX_STREAM_CHANGED;
        if(pending(io)||serial!=s->irq_serial||count!=s->irq_count)flags|=P25_RX_STREAM_IRQ_READ;
        if(end-begin>INT32_MAX||end-irq>=32000u)flags|=P25_RX_STREAM_CLOCK;
        if(flags) {fail(s,flags);return false;}
        unsigned char *r=ring_row(s,ordinal),*p=half_row(s,index);uint32_t h=get32(p+16);
        for(unsigned i=0;i<16u;++i) {put16(r+2u*i,(uint16_t)b[i]);h=hash_word(h,b[i]);}
        put64(r+32,ordinal);put32(r+40,begin);put32(r+44,end);put32(r+48,get32(p+8));
        put32(r+52,get32(p+24));put16(r+56,(uint16_t)offset);put16(r+58,0);
        r[60]=(uint8_t)target;r[61]=r[62]=r[63]=0;
        put32(p+16,h);add16(p+(tail?30u:28u),16u);
        uint32_t duration=end-begin;if(duration>UINT16_MAX)duration=UINT16_MAX;
        if(duration>get16(p+38))put16(p+38,(uint16_t)duration);
        s->produced=ordinal+16u;return true;
    }
    ordinal=s->verified;index=ordinal/256u;offset=ordinal%256u;
    if(index>=completed||ordinal>=s->produced)return false;
    if(index+1u!=completed||age>=32000u) {fail(s,P25_RX_STREAM_OVERWRITTEN);return false;}
    unsigned char *r=ring_row(s,ordinal),*p=half_row(s,index);
    if(get64(r+32)!=ordinal||r[60]!=half) {fail(s,P25_RX_STREAM_COMPARE_META);return false;}
    int16_t words[16];uint32_t begin=io->clock_us(io->context);
    bool torn=read_words(io,half,offset,words);uint32_t end=io->clock_us(io->context);
    if(!p25_rx_stream_active(s))return false;
    unsigned flags=0;bool mismatch=false;uint32_t h=get32(p+20);
    for(unsigned i=0;i<16u;++i) {if(words[i]!=(int16_t)get16(r+2u*i))mismatch=true;h=hash_word(h,words[i]);}
    if(torn)flags|=P25_RX_STREAM_COMPARE_TORN;
    if(mismatch) {flags|=P25_RX_STREAM_MISMATCH;add16(p+34,1);}
    if(pending(io)||serial!=s->irq_serial||count!=s->irq_count)flags|=P25_RX_STREAM_COMPARE_IRQ;
    if(end-begin>INT32_MAX||end-irq>=32000u)flags|=P25_RX_STREAM_CLOCK;
    if(flags) {put16(p+36,(uint16_t)(get16(p+36)|flags));fail(s,flags);return false;}
    put32(p+20,h);add16(p+32,1);s->verified=ordinal+16u;
    if(offset==240u)put16(p+36,(uint16_t)(get16(p+36)|P25_RX_STREAM_VERIFIED));
    if(s->verified==total&&s->produced==total)s->state=P25_RX_STREAM_DRAINING;
    return false;
}
bool p25_rx_stream_pop(p25_rx_stream *s,p25_rx_stream_chunk *out,uint32_t now) {
    if(!s||!out||!s->ring||s->consumed>=s->produced||
       (s->state!=P25_RX_STREAM_RUNNING&&s->state!=P25_RX_STREAM_DRAINING))return false;
    uint32_t ordinal=s->consumed;const unsigned char *r=ring_row(s,ordinal);
    if(get64(r+32)!=ordinal) {fail(s,P25_RX_STREAM_RING_FULL);return false;}
    for(unsigned i=0;i<16u;++i)out->samples[i]=(int16_t)get16(r+2u*i);
    out->first_sample=get64(r+32);out->read_begin_us=get32(r+40);out->read_end_us=get32(r+44);
    out->origin_irq_us=get32(r+48);out->origin_irq_count=get32(r+52);
    out->sample_offset=get16(r+56);out->flags=get16(r+58);out->target_half=r[60];
    memset(out->reserved,0,sizeof out->reserved);
    unsigned char *p=half_row(s,ordinal/256u);uint32_t latency=now-out->read_end_us;
    if(latency>INT32_MAX) {fail(s,P25_RX_STREAM_CLOCK);return false;}
    if(latency>get32(p+40))put32(p+40,latency);
    put32(p+44,now);s->consumed=ordinal+16u;
    // COMPLETE is deferred until after the caller processes this final chunk.
    return true;
}
void p25_rx_stream_cancel(p25_rx_stream *s) {
    if(s&&(p25_rx_stream_active(s)||s->state==P25_RX_STREAM_DRAINING))s->state=P25_RX_STREAM_CANCELLED;
}
void p25_rx_stream_finalize(p25_rx_stream *s) {
    if(!s||!s->ledger||p25_rx_stream_active(s))return;
    if(s->state==P25_RX_STREAM_DRAINING) {
        if(s->consumed!=s->produced)return;
        s->state=P25_RX_STREAM_COMPLETE;
    }
    if(s->finalized)return;
    for(unsigned i=0;i<s->halves;++i) {unsigned char *p=half_row(s,i);
        if(get16(p+32)!=16u)put16(p+36,(uint16_t)(get16(p+36)|P25_RX_STREAM_UNPAIRED));}
    s->finalized=true;
}
bool p25_rx_stream_half_read(const p25_rx_stream *s,unsigned index,p25_rx_stream_half *o) {
    if(!s||!o||!s->ledger||index>=s->halves)return false;
    const unsigned char *p=half_row(s,index);o->first_sample=get64(p);
    o->origin_irq_us=get32(p+8);o->completion_irq_us=get32(p+12);o->published_hash=get32(p+16);
    o->completed_hash=get32(p+20);o->origin_irq_count=get32(p+24);
    o->early_samples=get16(p+28);o->tail_samples=get16(p+30);o->verified_chunks=get16(p+32);
    o->mismatch_chunks=get16(p+34);o->flags=get16(p+36);o->max_read_us=get16(p+38);
    o->max_queue_us=get32(p+40);o->last_delivery_us=get32(p+44);return true;
}
bool p25_rx_stream_marker(p25_rx_stream *s,const unsigned char marker[32]) {
    if(!s||!marker||!s->ledger||s->marker_bytes!=P25_RX_STREAM_MARK_BYTES||s->marker_schema||
       (s->state!=P25_RX_STREAM_RUNNING&&s->state!=P25_RX_STREAM_DRAINING))return false;
    if(s->markers>=384u) {fail(s,P25_RX_STREAM_RING_FULL);return false;}
    memcpy(s->ledger+3072u+(unsigned)s->markers*32u,marker,32u);++s->markers;return true;
}
bool p25_rx_stream_origin_marker(p25_rx_stream *s,const unsigned char marker[64]) {
    if(!s||!marker||!s->ledger||s->marker_bytes!=P25_RX_STREAM_ORIGIN_MARK_BYTES||s->marker_schema!=1u||
       (s->state!=P25_RX_STREAM_RUNNING&&s->state!=P25_RX_STREAM_DRAINING))return false;
    if(s->markers>=P25_RX_STREAM_ORIGIN_MAX_MARKS) {fail(s,P25_RX_STREAM_RING_FULL);return false;}
    memcpy(s->ledger+3072u+(unsigned)s->markers*64u,marker,64u);++s->markers;return true;
}
bool p25_rx_stream_early_marker(p25_rx_stream *s,const unsigned char marker[64]) {
    if(!s||!marker||!s->ledger||s->marker_bytes!=P25_RX_STREAM_EARLY_MARK_BYTES||s->marker_schema!=2u||
       (s->state!=P25_RX_STREAM_RUNNING&&s->state!=P25_RX_STREAM_DRAINING))return false;
    if(s->markers>=P25_RX_STREAM_EARLY_MAX_MARKS) {fail(s,P25_RX_STREAM_RING_FULL);return false;}
    memcpy(s->ledger+3072u+(unsigned)s->markers*64u,marker,64u);++s->markers;return true;
}
