// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded, receive-only SRAM progress observations. No RF/sample-clock claim.
#ifndef P25_RX_PROGRESS_H
#define P25_RX_PROGRESS_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define P25_RX_PROGRESS_MAX_ROWS 128u
#define P25_RX_PROGRESS_ROW_BYTES 96u
#define P25_RX_PROGRESS_STORAGE_BYTES (P25_RX_PROGRESS_MAX_ROWS*P25_RX_PROGRESS_ROW_BYTES)
#define P25_RX_PROGRESS_HALF_BYTES 512u
#define P25_RX_PROGRESS_RAM_BYTES 1024u
#define P25_RX_PROGRESS_POINTS 8u
#define P25_RX_PROGRESS_MIN_CADENCE_US 250u
#define P25_RX_PROGRESS_MAX_CADENCE_US 8000u
#define P25_RX_PROGRESS_MIN_TIMEOUT_US 32000u
#define P25_RX_PROGRESS_MAX_TIMEOUT_US 2000000u

typedef enum {
    P25_RX_PROGRESS_IDLE,P25_RX_PROGRESS_WAIT_IRQ,P25_RX_PROGRESS_RECORDING,
    P25_RX_PROGRESS_DONE,P25_RX_PROGRESS_CANCELLED,P25_RX_PROGRESS_TIMEOUT,
    P25_RX_PROGRESS_CLOCK_ERROR
} p25_rx_progress_state;
enum {
    P25_RX_PROGRESS_META_UNSTABLE=1u,
    P25_RX_PROGRESS_IRQ_DURING_READ=2u,
    P25_RX_PROGRESS_WORD_TORN=4u,
    P25_RX_PROGRESS_VALUES_CHANGED=8u,
    P25_RX_PROGRESS_IRQ_SEQUENCE=16u,
    P25_RX_PROGRESS_MISSED_CADENCE=32u,
    P25_RX_PROGRESS_CLOCK_ANOMALY=64u,
    P25_RX_PROGRESS_INVALID_IRQ=128u
};
typedef struct {
    uint16_t rows,cadence_us;
    uint32_t timeout_us; // Includes waiting for the first valid half IRQ.
} p25_rx_progress_config;

typedef struct {
    // Points0..7 are low-half sample indices;8..15 are the same high-half
    // indices. Fixed indices are exported below. Samples are signed BE16.
    int16_t first[2u*P25_RX_PROGRESS_POINTS],second[2u*P25_RX_PROGRESS_POINTS];
    uint32_t cpu_begin_us,cpu_end_us,irq_begin_us,irq_end_us,irq_count_begin,irq_count_end;
    uint16_t changed_mask,torn_mask;
    uint8_t half_begin,half_end,flags,missed_periods;
} p25_rx_progress_row;
// WORD_TORN detects a high byte changing around its low-byte read. Low-byte-only
// changes and ABA can escape it. Equal passes/clear flags never certify atomic
// words, a writer frontier, recorder-to-air latency or a physical sample clock.

typedef struct {
    void *context;
    // A direct volatile read of the recorder's1024-byte window. No flash,
    // UART, codec, SPI transactions or unrelated hardware operations here.
    uint8_t (*read_byte)(void *context,unsigned offset);
    uint32_t (*clock_us)(void *context); // CPU diagnostic clock, not sample time.
    // Optional direct pending-half status, without clearing/consuming the IRQ.
    // In non-nesting ISR mode it catches a boundary the CPU cannot publish yet.
    bool (*half_pending)(void *context);
} p25_rx_progress_io;

typedef struct {
    unsigned char *storage;
    uint32_t armed_us,next_due_us,last_poll_us,timeout_us;
    uint32_t missed_periods,previous_invalid,previous_sequence;
    volatile uint32_t irq_serial,valid_irqs,invalid_irqs,sequence_errors,last_irq_us;
    uint16_t limit;
    volatile uint16_t count;
    uint16_t cadence_us;
    volatile uint8_t state,completed_half;
    bool have_poll;
} p25_rx_progress;

extern const uint8_t p25_rx_progress_indices[P25_RX_PROGRESS_POINTS];
void p25_rx_progress_init(p25_rx_progress *s);
bool p25_rx_progress_active(const p25_rx_progress *s);
// Start only with the recorder exclusively owned and voice decoding/speaker
// disabled. The caller may borrow monitor.pcm; no permanent large RAM is added.
// Storage is accessed only as character bytes; monitor.pcm retains its declared
// int16_t type and no alignment or incompatible typed alias is imposed. It must
// be large enough and not overlap state. Stored rows are canonical little endian:
// first[16]@0,second[16]@32,cpu_begin/end@64/68,irq_begin/end@72/76,
// irq_count_begin/end@80/84,changed/torn@88/90,half_begin/end/flags/missed@92..95.
// The matching offline unpack format is '<32h6I2H4B'.
// Invalid input/refused restart leaves state and storage unchanged.
bool p25_rx_progress_start(p25_rx_progress *s,void *storage,size_t storage_bytes,
    const p25_rx_progress_config *config,uint32_t now_us);
// The only ISR operation: publish completed half1/2 and its CPU timestamp.
// No sample reads/copies. Invalid/repeated halves are counted as evidence.
bool p25_rx_progress_irq(p25_rx_progress *s,unsigned half,uint32_t irq_us);
// Task operation, at most one96-byte row and96 volatile byte reads per call.
// Starts only after the first valid IRQ. Late polls skip cadence periods;
// there is no catch-up loop. No callbacks or storage access while inactive.
bool p25_rx_progress_poll(p25_rx_progress *s,const p25_rx_progress_io *io,uint32_t now_us);
void p25_rx_progress_cancel(p25_rx_progress *s);
// Readout is refused until capture has stopped. Output unchanged on refusal.
bool p25_rx_progress_read(const p25_rx_progress *s,unsigned row,p25_rx_progress_row *out);

// Experimental contiguous early reads, later compared with the completed half.
// The nominal 8-kHz geometry is only a scheduling hypothesis. Neither a match
// nor a clean metadata epoch certifies a writer frontier or physical clock.
#define P25_RX_CHUNK_SAMPLES 16u
#define P25_RX_CHUNK_ROW_BYTES 144u
#define P25_RX_CHUNK_MAX_ROWS 96u
#define P25_RX_CHUNK_STORAGE_BYTES (P25_RX_CHUNK_ROW_BYTES*P25_RX_CHUNK_MAX_ROWS)
#define P25_RX_CHUNK_PERIOD_US 2000u
#define P25_RX_CHUNK_HALF_US 32000u
#define P25_RX_CHUNK_MAX_GUARD_US 16000u
enum {
    P25_RX_CHUNK_META_UNSTABLE=1u,P25_RX_CHUNK_IRQ_DURING_READ=2u,
    P25_RX_CHUNK_WORD_TORN=4u,P25_RX_CHUNK_VALUES_CHANGED=8u,
    P25_RX_CHUNK_IRQ_SEQUENCE=16u,P25_RX_CHUNK_COMPARE_META_UNSTABLE=32u,
    P25_RX_CHUNK_COMPARE_IRQ_DURING_READ=64u,P25_RX_CHUNK_OVERWRITTEN=128u,
    P25_RX_CHUNK_COMPARE_WORD_TORN=256u,P25_RX_CHUNK_MISMATCH=512u,
    P25_RX_CHUNK_CLOCK_ANOMALY=1024u,P25_RX_CHUNK_UNPAIRED=2048u,
    P25_RX_CHUNK_SCHEDULE_LATE=4096u,P25_RX_CHUNK_COMPARED=8192u
};
typedef struct {uint16_t rows,guard_us;} p25_rx_chunk_config;
typedef struct {
    int16_t first[P25_RX_CHUNK_SAMPLES],second[P25_RX_CHUNK_SAMPLES],completed[P25_RX_CHUNK_SAMPLES];
    uint32_t cpu_begin_us,cpu_end_us,origin_irq_us,compare_begin_us,compare_end_us,
        completion_irq_us,origin_irq_count,completion_irq_count;
    uint16_t sample_offset,changed_mask,torn_mask,mismatch_mask,completed_torn_mask,flags;
    uint8_t target_half,reserved[3];
} p25_rx_chunk_row;
// Canonical little endian '<48h8I6HB3x',144 bytes, independent of C alignment.
typedef struct {
    p25_rx_progress base;
    uint32_t observed_irq;
    volatile uint32_t skipped_chunks,compared,mismatches;
    uint16_t guard_us,next_sample;
    volatile uint16_t next_verify;
    bool finalized;
} p25_rx_chunk;
void p25_rx_chunk_init(p25_rx_chunk *s);
bool p25_rx_chunk_active(const p25_rx_chunk *s);
bool p25_rx_chunk_start(p25_rx_chunk *s,void *storage,size_t storage_bytes,
    const p25_rx_chunk_config *config,uint32_t now_us);
// ISR publishes metadata only; it never reads samples or accesses row storage.
bool p25_rx_chunk_irq(p25_rx_chunk *s,unsigned half,uint32_t irq_us);
// At most one candidate (96 volatile byte reads) OR one comparison (48 reads).
// Comparisons require the immediate next completed-half epoch throughout the
// read, and age<32ms. This is a conservative nominal overwrite guard, not proof
// that hidden/coalesced recorder interrupts or device writes cannot occur.
bool p25_rx_chunk_poll(p25_rx_chunk *s,const p25_rx_progress_io *io,uint32_t now_us);
// ISR-safe bounded step, no pending-row finalization. The task must subsequently
// call poll (even with io=NULL) or cancel to finalize a terminated trace before
// dumping it. Never use step concurrently with task-side poll/cancel.
bool p25_rx_chunk_step(p25_rx_chunk *s,const p25_rx_progress_io *io,uint32_t now_us);
void p25_rx_chunk_cancel(p25_rx_chunk *s);
bool p25_rx_chunk_read(const p25_rx_chunk *s,unsigned row,p25_rx_chunk_row *out);

#endif
