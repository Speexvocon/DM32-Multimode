// SPDX-License-Identifier: GPL-3.0-or-later
// Finite transport/reply observation only; no subscriber or RF authority.
#ifndef P25_TRUNKING_LAB_EXCHANGE_H
#define P25_TRUNKING_LAB_EXCHANGE_H
#include "p25_trunking_isp.h"

#define P25_LAB_EXCHANGE_WARM_US 250000u
#define P25_LAB_EXCHANGE_TX_US 55501u // Existing55-ms cutoff plus permitted500-us lateness.
#define P25_LAB_EXCHANGE_RETURN_US 250000u
#define P25_LAB_EXCHANGE_REPLY_US 1500000u
#define P25_LAB_EXCHANGE_MAX_REPLIES 8u
typedef enum {P25_LAB_REGISTER=1,P25_LAB_AFFILIATE,P25_LAB_GROUP} p25_lab_request;
typedef enum {P25_LAB_IDLE,P25_LAB_PREPARED,P25_LAB_TX_ACTIVE,P25_LAB_RETURN_PENDING,P25_LAB_RX_STARTING,
    P25_LAB_WAIT_REPLY,P25_LAB_REPLY,P25_LAB_TIMEOUT,P25_LAB_CANCELLED,P25_LAB_FAILED} p25_lab_phase;
typedef enum {P25_LAB_OK,P25_LAB_CONFIG,P25_LAB_TRANSPORT,P25_LAB_RF_NOT_OFF,
    P25_LAB_EPOCH,P25_LAB_OWNER,P25_LAB_EXPIRED,P25_LAB_REPLY_LIMIT} p25_lab_reason;
typedef struct {
    uint32_t sequence,owner_tag,radio_id,wacn,control_rx_hz,control_tx_hz;
    // GROUP freezes one expected clear service/channel; neither field resolves
    // a frequency or authorizes a later voice transmission. Others use zero.
    uint16_t nac,system,group,expected_channel;
    uint8_t profile,request,expected_options;
} p25_lab_exchange_owner;
typedef struct {
    p25_lab_exchange_owner owner;
    uint32_t previous_epoch,rx_epoch,prepared_us,tx_started_us,cutoff_us,return_begin_us,rx_ready_us,deadline_us,reply_us;
    uint32_t assigned,reply_source;
    p25_lab_phase phase;
    p25_lab_reason reason;
    uint16_t reply_group,reply_channel;
    uint8_t reply_type,response,service,opcode,replies,reply_options;
} p25_lab_exchange;

bool p25_lab_exchange_active(const p25_lab_exchange *s);
// No site metadata or qualification timestamps are refreshed by this helper.
bool p25_lab_exchange_prepare(p25_lab_exchange *s,const p25_lab_exchange_owner *owner,
    uint32_t previous_epoch,uint32_t now_us);
bool p25_lab_exchange_owner_matches(const p25_lab_exchange *s,const p25_lab_exchange_owner *owner);
bool p25_lab_exchange_tx_started(p25_lab_exchange *s,uint32_t sequence,uint32_t arm_us);
bool p25_lab_exchange_tx_done(p25_lab_exchange *s,uint32_t sequence,bool success,uint32_t now_us);
bool p25_lab_exchange_begin_return(p25_lab_exchange *s,uint32_t sequence,bool rf_off,uint32_t now_us);
bool p25_lab_exchange_rx_ready(p25_lab_exchange *s,uint32_t sequence,bool rf_off,uint32_t epoch,uint32_t now_us);
// Own CRC/MFID/protection validation is repeated. Carrier/NAC/epoch/identity and
// request kind must match; recorded reply metadata NEVER updates subscriber FSM.
bool p25_lab_exchange_consume(p25_lab_exchange *s,uint32_t sequence,uint32_t owner_tag,
    uint32_t epoch,uint16_t nac,uint32_t carrier_hz,const uint8_t block[12],uint32_t now_us);
void p25_lab_exchange_poll(p25_lab_exchange *s,uint32_t now_us);
void p25_lab_exchange_cancel(p25_lab_exchange *s,p25_lab_reason reason);
#endif
