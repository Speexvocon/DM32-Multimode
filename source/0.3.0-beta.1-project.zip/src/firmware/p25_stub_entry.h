// SPDX-License-Identifier: GPL-3.0-or-later
// Runtime loader bridge for the unified controller. The ordinary RadioFoundry
// host task is not started by this application; only its small framed loader
// protocol is reused here. Task context only, one serial owner, no ISR calls.
#ifndef P25_STUB_ENTRY_H
#define P25_STUB_ENTRY_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "debuglink/dl_frame.h"
#include "stubentry/stub_load.h"

#define P25_STUB_LOAD_ADDR 0x00044000u
#define P25_STUB_REGION_BYTES 0x00014000u
#define P25_STUB_REPLY_BYTES 128u
#define P25_STUB_ENTER_DELAY_MS 100u
#define P25_STUB_IDLE_MS 10000u
#define P25_STUB_TOTAL_MS 120000u

typedef enum {
    P25_STUB_IDLE,
    P25_STUB_LOADING,
    P25_STUB_ENTER_PENDING,
    P25_STUB_ENTERING,
    P25_STUB_FAILED
} p25_stub_state;

typedef struct {
    void *context;
    uint8_t *region;             // Reserved codec window; obtaining it must not park the codec.
    uint32_t load_addr,region_bytes;
    const char *board,*git;      // board must be DM-32UV; git is our application revision.
    const char *(*codec)(void *context); // Read-only identity, no codec reset/parking.
    bool (*admit)(void *context);       // Read-only, complete controller/PTT/owner checks.
    // Called only after a valid BEGIN and successful admit. Stop all receive,
    // audio, applet and timer owners, then permanently park the native codec.
    // Any return, including false, leaves loader ownership latched until reboot.
    bool (*quiesce)(void *context);
    bool (*safe)(void *context);       // PTT released, RF off, exclusive ownership retained.
    void (*force_safe)(void *context); // RF/audio kill, never resume ordinary operation.
    bool (*write)(void *context,const uint8_t *bytes,size_t length); // Entire reply, or false.
    bool (*drain)(void *context);      // Bounded UART shifter drain before enter.
    bool (*enter)(void *context,uint32_t entry); // Native RAM handover does not return.
    bool (*image_ok)(const uint8_t *image,uint32_t length); // Optional native image check.
} p25_stub_config;

typedef struct {
    p25_stub_config config;
    dl_parser_t parser;
    stub_load_t load;
    uint8_t reply[DL_HDR+P25_STUB_REPLY_BYTES+2u];
    p25_stub_state state;
    uint32_t now_ms,started_ms,activity_ms,reply_ms,entry;
    bool initialized,enter_replied;
} p25_stub_entry;

bool p25_stub_entry_init(p25_stub_entry *entry,const p25_stub_config *config);
bool p25_stub_entry_owned(const p25_stub_entry *entry);
bool p25_stub_entry_in_frame(p25_stub_entry *entry,uint32_t now_ms);
// Consumes at most one binary frame. Returns zero for a non-loader byte; the
// caller can then pass that byte to its existing ASCII/CPS dispatcher. During a
// partial frame every byte belongs here, even CR/LF, Ctrl-C or printable bytes.
size_t p25_stub_entry_feed(p25_stub_entry *entry,const uint8_t *bytes,size_t length,uint32_t now_ms);
void p25_stub_entry_poll(p25_stub_entry *entry,uint32_t now_ms);
// STOP, timeout or failure after BEGIN requires a reboot. Parked AMBE code must
// never be called after its SRAM has been overwritten, even after a partial load.
void p25_stub_entry_abort(p25_stub_entry *entry);

#endif
