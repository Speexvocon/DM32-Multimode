// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit, volatile, one-press GROUP laboratory adapter. No subscriber FSM.
#ifndef P25_TRUNKING_LAB_PTT_LIVE_H
#define P25_TRUNKING_LAB_PTT_LIVE_H
#include "p25_trunking_lab_ptt.h"

static p25_lab_ptt trunk_lab_ptt;
static struct {
    typeof(trunk_preload_config) config;
    uint32_t previous_sequence;
    uint16_t target,padded;
    volatile bool down;
    bool selected,draining,retaining;
} trunk_lab_ptt_io;
_Static_assert(sizeof trunk_lab_ptt_io<=28u,"PTT adapter exceeds compact state budget");
static bool trunk_lab_ptt_selected(void) {return trunk_lab_ptt_io.selected;}
static p25_lab_exchange_owner trunk_lab_ptt_current(void) {
    p25_lab_exchange_owner o={0};
    if(control.talkgroup<1u || control.talkgroup>0xffffu)return o;
    uint32_t sequence=trunk_probe.sequence;
    if(sequence==trunk_lab_ptt_io.previous_sequence) {
        ++sequence;if(!sequence)sequence=1u;
    }
    o.sequence=sequence;o.owner_tag=trunk_lab_return_tag();
    o.radio_id=control.source_id;o.wacn=TRUNK_PROBE_WACN;o.system=TRUNK_PROBE_SYSTEM;
    o.control_rx_hz=frequency;o.control_tx_hz=control.tx_frequency;
    o.nac=control.nac;o.group=(uint16_t)control.talkgroup;o.profile=trunk_lab_profile;
    o.request=trunk_preload_request_kind(trunk_preload_config.request);
    o.expected_channel=TRUNK_PRELOAD_GROUP_CHANNEL;o.expected_options=TRUNK_PRELOAD_GROUP_OPTIONS;
    return o;
}
static bool trunk_lab_ptt_identity(void) {
    return trunk_lab_ptt_io.selected
        && !memcmp(&trunk_lab_ptt_io.config,&trunk_preload_config,sizeof trunk_preload_config);
}
static bool trunk_lab_ptt_permission(void) {
    // Same immediate ownership/permission barriers as the finite request. This
    // deliberately does not change message_tx_permission or the global PTT
    // release latch: only this immutable, explicitly armed action may bypass it.
    return trunk_lab_ptt_identity() && normal_mode && features_ready && feature_p25()
        && !trunk_enabled && trunk_probe_profile_matches() && control.split
        && !radio_channel_get_private(channel_record) && !channel_scan.running
        && !apps_active() && !pcm_owner && !applet_owns_radio && !cps_active && !cps_link
        && !editing && !menu_open && !rx_lab && !rx_job && !broadcast_show && !airband_show
        && !digital_dmr.owned && !analog_fm.owned && dev && hooks && board.audio && board.radio
        && feature_tx_settings_valid() && feature_tx_power()==0u && tx_writer==TX_WRITER_ALT1
        && tx_dac_restore && !tx_fixed && !control.cancel && !owner_tx_inhibit
        && !control.inhibit && control.state!=RADIO_FAULT && control.tx_enabled
        && !(channel_record[12]&16u) && board.power->switch_on();
}
static bool trunk_lab_ptt_held(void) {
    p25_lab_exchange_owner current=trunk_lab_ptt_current();
    return trunk_lab_ptt_identity() && trunk_lab_ptt_io.down && !hrc_pin_read(PIN_PTT)
        && p25_lab_ptt_allow_held(&trunk_lab_ptt,&current,true,hrc_micros());
}
static bool trunk_lab_ptt_request_held(void) {
    return trunk_lab_ptt.phase==P25_LAB_PTT_REQUEST && trunk_lab_ptt_held();
}
static bool trunk_lab_ptt_request_permission(void) {
    return trunk_lab_ptt_request_held() && trunk_lab_ptt_permission()
        && !rx_job && !rx_lab && bf_cal_valid() && channel_in_band(control.tx_frequency,true)
        && board.power->battery_mv()>=board.battery_critical_mv;
}
static bool trunk_lab_ptt_fire_permitted(void) {
    return !trunk_lab_ptt_io.selected || (trunk_lab_ptt_request_held() && trunk_lab_ptt.spent
        && trunk_lab_ptt.request_epoch==trunk_lab_exchange.previous_epoch
        && trunk_lab_ptt.prepared_us==trunk_lab_exchange.prepared_us
        && trunk_lab_ptt.owner.sequence==trunk_lab_exchange.owner.sequence);
}
static bool trunk_lab_ptt_voice_held(bool initial) {
    if(!trunk_lab_ptt_identity())return false;
    if(initial)return trunk_lab_ptt.phase==P25_LAB_PTT_GRANTED && trunk_lab_ptt_held();
    // A physical release after the actual PA stops capture in the next task
    // pass. It must not kill an already emitted LDU before its TDU/drain.
    p25_lab_exchange_owner current=trunk_lab_ptt_current();
    return (trunk_lab_ptt.phase==P25_LAB_PTT_RETURN
            || ((trunk_lab_ptt.phase==P25_LAB_PTT_VOICE || trunk_lab_ptt.phase==P25_LAB_PTT_DRAIN)
                && (uint32_t)(hrc_micros()-trunk_lab_ptt.voice_us)<P25_LAB_PTT_VOICE_US))
        && p25_lab_exchange_owner_matches(&trunk_lab_exchange,&current)
        ;
}
static void trunk_lab_ptt_cancel(void) {
    if(!trunk_lab_ptt_io.selected && !p25_lab_ptt_owned(&trunk_lab_ptt))return;
    uint32_t lock=hrc_irq_save();
    if(p25_lab_ptt_owned(&trunk_lab_ptt)) {
        if(trunk_lab_ptt.phase>=P25_LAB_PTT_ARMED && trunk_lab_ptt.phase<=P25_LAB_PTT_RETURN)
            p25_lab_ptt_cancel(&trunk_lab_ptt,P25_LAB_PTT_CANCEL);
        ptt_release_required=true;ptt_release_seen=false;
    }
    if(!trunk_lab_ptt_io.retaining)trunk_lab_ptt_io.selected=false;
    hrc_irq_restore(lock);
}
static void trunk_lab_ptt_cancel_off(void) {
    uint32_t lock=hrc_irq_save();
    if(trunk_lab_ptt.needs_rf_off && trunk_lab_return_rf_off())
        (void)p25_lab_ptt_abort_off(&trunk_lab_ptt,true,hrc_micros());
    hrc_irq_restore(lock);
}
static void trunk_lab_ptt_abort(void) {
    // Natural failure retains the selected lab mode, preventing a subsequent
    // held/fresh PTT from falling through to conventional control-channel TX.
    trunk_lab_ptt_io.retaining=true;trunk_lab_return_cancel();trunk_lab_ptt_io.retaining=false;
}
static bool trunk_lab_ptt_grant(void) {
    if(!trunk_lab_ptt_io.selected)return true; // Serial ON/MIC unchanged.
    p25_lab_exchange_owner current=trunk_lab_ptt_current();
    bool permission=trunk_lab_ptt_permission() && trunk_preload_warm_health();
    uint32_t lock=hrc_irq_save();
    bool okay=p25_lab_ptt_grant(&trunk_lab_ptt,&trunk_lab_exchange,&current,
        trunk_lab_ptt_io.down && !hrc_pin_read(PIN_PTT),permission,hrc_micros());
    hrc_irq_restore(lock);return okay;
}
static bool trunk_lab_ptt_pa_started(void) {
    if(!trunk_lab_ptt_io.selected)return true;
    p25_lab_exchange_owner current=trunk_lab_ptt_current();
    return p25_lab_ptt_voice_started(&trunk_lab_ptt,&current,
        trunk_lab_ptt_io.down && !hrc_pin_read(PIN_PTT),hrc_micros());
}
static bool trunk_lab_ptt_released_voice(void) {
    return trunk_lab_ptt_io.selected && trunk_lab_ptt_io.draining;
}
static void trunk_lab_ptt_note_padding(void) {++trunk_lab_ptt_io.padded;}
static void trunk_lab_ptt_voice_cancelled(void) {
    if(trunk_lab_ptt_io.selected && trunk_lab_ptt.phase>=P25_LAB_PTT_ARMED
       && trunk_lab_ptt.phase<=P25_LAB_PTT_RETURN)
        p25_lab_ptt_cancel(&trunk_lab_ptt,P25_LAB_PTT_TRANSPORT);
}
static unsigned trunk_lab_ptt_mic_target(void) {
    return trunk_lab_ptt_io.selected ? trunk_lab_ptt_io.target:P25_LAB_VOICE_MIC_FRAMES;
}
static void trunk_lab_ptt_capture_stop(void) {
    if(!trunk_lab_ptt_io.selected || trunk_lab_ptt_io.draining)return;
    uint32_t lock=hrc_irq_save();
    if(trunk_lab_ptt.phase==P25_LAB_PTT_VOICE)
        (void)p25_lab_ptt_drain(&trunk_lab_ptt,hrc_micros());
    if(trunk_lab_ptt.phase==P25_LAB_PTT_DRAIN) {
        pcmq.accepting=false;trunk_lab_ptt_io.draining=true;
        trunk_lab_ptt_io.target=(uint16_t)(((pcmq.captured+17u)/18u)*18u);
    }
    hrc_irq_restore(lock);audio_stop();
}
static void trunk_lab_ptt_voice_done(bool success) {
    if(!trunk_lab_ptt_io.selected)return;
    if(success && trunk_lab_ptt.phase==P25_LAB_PTT_VOICE)
        (void)p25_lab_ptt_drain(&trunk_lab_ptt,hrc_micros());
    (void)p25_lab_ptt_tx_done(&trunk_lab_ptt,success,trunk_lab_return_rf_off() || !hardware_running,hrc_micros());
}
static void trunk_lab_ptt_return_ready(void) {
    if(trunk_lab_ptt_io.selected && trunk_lab_voice_io.full_rx)
        (void)p25_lab_ptt_return_ready(&trunk_lab_ptt,trunk_stream_epoch,true,
            trunk_lab_return_rf_off(),hrc_micros());
}
static void trunk_lab_ptt_poll(bool down) {
    trunk_lab_ptt_io.down=down;
    if(!trunk_lab_ptt_io.selected) {trunk_lab_ptt_cancel_off();return;}
    if(trunk_lab_ptt.phase>=P25_LAB_PTT_DONE) {trunk_lab_ptt_cancel_off();return;}
    p25_lab_exchange_owner current=trunk_lab_ptt_current();
    bool permission=trunk_lab_ptt_permission() && trunk_preload_warm_health();
    uint32_t lock=hrc_irq_save();
    p25_lab_ptt_action action=p25_lab_ptt_input(&trunk_lab_ptt,&current,down,permission,hrc_micros());
    hrc_irq_restore(lock);
    if(action==P25_LAB_PTT_ABORT) {trunk_lab_ptt_abort();return;}
    if(action==P25_LAB_PTT_BEGIN_DRAIN)trunk_lab_ptt_capture_stop();
    if(action==P25_LAB_PTT_SEND_REQUEST) {
        ptt_release_required=true;ptt_release_seen=false;
        trunk_lab_ptt_io.retaining=true;
        bool okay=trunk_preload_prepare(true,true);
        current=trunk_lab_ptt_current();lock=hrc_irq_save();
        if(okay)okay=p25_lab_ptt_bind_prepared(&trunk_lab_ptt,&trunk_lab_exchange,&current,hrc_micros());
        hrc_irq_restore(lock);
        if(okay)okay=trunk_preload_config.clock ? trunk_preload_clock_poll(trunk_lab_ptt.owner.sequence,true)
            : trunk_preload_fire(trunk_lab_ptt.owner.sequence,true);
        trunk_lab_ptt_io.retaining=false;
        if(!okay) {
            trunk_lab_ptt_abort();return;
        }
        reason="lab_wait_grant";if(display_ok)screen("WAIT GRANT");
    }
    if(trunk_preload_config.clock && trunk_lab_ptt.phase==P25_LAB_PTT_REQUEST && trunk_preload_warmed()) {
        trunk_lab_ptt_io.retaining=true;
        bool okay=trunk_preload_clock_poll(trunk_lab_ptt.owner.sequence,down);
        trunk_lab_ptt_io.retaining=false;
        if(!okay) {trunk_lab_ptt_abort();return;}
    }
    if(trunk_lab_ptt.phase==P25_LAB_PTT_REQUEST && !trunk_probe.active && !trunk_lab_return_owned()
       && trunk_lab_exchange.owner.sequence==trunk_lab_ptt.owner.sequence
       && trunk_lab_exchange.phase!=P25_LAB_REPLY)trunk_lab_ptt_abort();
}
static bool trunk_lab_ptt_arm(bool down) {
    if(down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)) {
        // Refusing an already held arm must not turn that same physical hold
        // into a conventional transmission as its input filter settles.
        if(trunk_lab_ptt_io.selected && trunk_lab_ptt.phase==P25_LAB_PTT_ARMED)
            trunk_lab_return_cancel();
        ptt_release_required=true;ptt_release_seen=false;return false;
    }
    if(!ptt_mask || p25_lab_ptt_owned(&trunk_lab_ptt) || trunk_lab_return_owned() || trunk_probe.active
       || call_active || prepared || hardware_running || radio_busy(&control) || rx_sampling
       || armed || session_enabled || !trunk_probe_mailbox_idle()
       || (ptt_release_required && !trunk_lab_attach_arm_permission())
       || !trunk_preload_config.configured || !trunk_preload_config.return_rx
       || trunk_preload_config.phase || (trunk_preload_config.clock && !trunk_preload_clock_configured())
       || trunk_preload_config.request!=2u || trunk_preload_config.voice!=TRUNK_PRELOAD_VOICE_MIC
       || !trunk_probe_context() || !trunk_preload_warm_health() || !trunk_stream_epoch
       || (mon_running && (mon_sync_active(hrc_micros()) || monitor.call.active || monitor.playing
           || mon_routed || mon_pcm_pending || monitor.pcm_head!=monitor.pcm_tail)))return false;
    trunk_lab_ptt_io.previous_sequence=trunk_probe.sequence;
    p25_lab_exchange_owner current=trunk_lab_ptt_current();
    uint32_t lock=hrc_irq_save();
    bool okay=p25_lab_ptt_arm(&trunk_lab_ptt,&current,trunk_stream_epoch,false,
        trunk_lab_return_rf_off(),hrc_micros());
    if(okay) {
        memset(&trunk_lab_ptt_io,0,sizeof trunk_lab_ptt_io);
        trunk_lab_ptt_io.config=trunk_preload_config;trunk_lab_ptt_io.selected=true;
        trunk_lab_ptt_io.previous_sequence=trunk_probe.sequence;
        trunk_lab_ptt_io.target=P25_LAB_VOICE_MIC_FRAMES;
    }
    hrc_irq_restore(lock);
    if(okay) {reason="lab_ptt_armed";home_hint_refresh();}
    return okay;
}
static bool trunk_lab_ptt_command(const char *line,bool down) {
    if(!strcmp(line,"TRUNK PTT STATUS")) {telemetry_request(TELEMETRY_LABPTT);return true;}
    if(!strcmp(line,"TRUNK PTT ARM")) {
        send(trunk_lab_ptt_arm(down) ? "OK TRUNK PTT ARM one fresh press; finite lab GROUP MIC\r\n"
            : "ERR TRUNK PTT ARM idle released PTT, configured GROUP RETURN MIC required\r\n");return true;
    }
    return false;
}
static int trunk_lab_ptt_status_row(unsigned row,char *line,size_t capacity) {
    p25_lab_ptt value;typeof(trunk_lab_ptt_io) io;
    uint32_t lock=hrc_irq_save();value=trunk_lab_ptt;io=trunk_lab_ptt_io;hrc_irq_restore(lock);
    if(row==0u)return snprintf(line,capacity,"TRUNKPTT selected=%u sequence=%lu phase=%u reason=%u source=%lu group=%u nac=%03x channel=%u options=%u profile=%s arm_us=%lu request_us=%lu arm_epoch=%lu arm_limit_us=60000000 request_limit_us=10000000 mic_limit=162 max_rf_us=6000000 lab_only=1\r\n",
        (unsigned)io.selected,(unsigned long)value.owner.sequence,(unsigned)value.phase,(unsigned)value.reason,
        (unsigned long)value.owner.radio_id,(unsigned)value.owner.group,(unsigned)value.owner.nac,
        (unsigned)value.owner.expected_channel,(unsigned)value.owner.expected_options,p25_trunking_lab_name(value.owner.profile),
        (unsigned long)value.arm_us,(unsigned long)value.request_us,(unsigned long)value.arm_epoch);
    if(row==1u)return snprintf(line,capacity,"TRUNKPTT_END sequence=%lu prepared_us=%lu request_epoch=%lu grant_us=%lu voice_us=%lu end_us=%lu ready_us=%lu grant_epoch=%lu return_epoch=%lu down=%u draining=%u target=%u padded=%u timestamps=software_not_air access=unqualified\r\n",
        (unsigned long)value.owner.sequence,(unsigned long)value.prepared_us,(unsigned long)value.request_epoch,
        (unsigned long)value.grant_us,(unsigned long)value.voice_us,
        (unsigned long)value.end_us,(unsigned long)value.ready_us,(unsigned long)value.grant_epoch,
        (unsigned long)value.return_epoch,(unsigned)io.down,(unsigned)io.draining,(unsigned)io.target,(unsigned)io.padded);
    return -1;
}
#endif
