// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_applet_vm.h"
#include <string.h>

static uint16_t get16(const uint8_t *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static uint32_t get32(const uint8_t *p) {return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static bool fail(radio_applet_error *out,radio_applet_error error) {if(out)*out=error;return false;}
static uint32_t crc_add(uint32_t crc,const uint8_t *data,unsigned count) {
 while(count--) {crc^=*data++;for(unsigned bit=0;bit<8;++bit)crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);}return crc;
}
static bool printable(uint8_t value) {return value>=32u && value<=126u;}
static bool frequency(uint32_t hz) {return hz>=162400000u && hz<=162550000u && !((hz-162400000u)%25000u);}

static bool instruction(const radio_applet_package *p,const uint8_t *code,radio_applet_error *error) {
 unsigned op=code[0],a=code[1],b=get16(code+2);uint32_t imm=get32(code+4),caps=0;
 switch(op) {
 case RADIO_APPLET_END:case RADIO_APPLET_YIELD:
  if(a || b || imm)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  break;
 case RADIO_APPLET_SET:case RADIO_APPLET_ADD:
  if(a>=RADIO_APPLET_REGISTERS || b)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  break;
 case RADIO_APPLET_JEQ:case RADIO_APPLET_JNE:
  if(a>=RADIO_APPLET_REGISTERS)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  if(b>=p->instruction_count)return fail(error,RADIO_APPLET_ERROR_BRANCH);
  break;
 case RADIO_APPLET_JMP:
  if(a || imm)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  if(b>=p->instruction_count)return fail(error,RADIO_APPLET_ERROR_BRANCH);
  break;
 case RADIO_APPLET_WAIT:
  if(a || b || !imm || imm>60000u)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  break;
 case RADIO_APPLET_EMIT_LITERAL:case RADIO_APPLET_DISPLAY_LITERAL:
  if(a || !b || b>RADIO_APPLET_TEXT_MAX || imm>p->strings_bytes || b>p->strings_bytes-imm)
   return fail(error,RADIO_APPLET_ERROR_STRING);
  caps=op==RADIO_APPLET_EMIT_LITERAL ? RADIO_APPLET_CAP_SERIAL : RADIO_APPLET_CAP_DISPLAY;break;
 case RADIO_APPLET_SAME_START:
  if(a || b || !frequency(imm))return fail(error,RADIO_APPLET_ERROR_OPERAND);
  caps=RADIO_APPLET_CAP_SAME;break;
 case RADIO_APPLET_SAME_LAST:case RADIO_APPLET_DISPLAY_SAME:
  if(a || b || imm)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  caps=RADIO_APPLET_CAP_SAME|(op==RADIO_APPLET_SAME_LAST ? RADIO_APPLET_CAP_SERIAL : RADIO_APPLET_CAP_DISPLAY);break;
 case RADIO_APPLET_EMIT_REG:
  if(a>=RADIO_APPLET_REGISTERS || b || imm)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  caps=RADIO_APPLET_CAP_SERIAL;break;
 case RADIO_APPLET_GET:
  if(a>=RADIO_APPLET_REGISTERS || b>13u || imm)return fail(error,RADIO_APPLET_ERROR_OPERAND);
  caps=b==9u ? 0u : b==8u ? RADIO_APPLET_CAP_KEY : RADIO_APPLET_CAP_SAME;break;
 case RADIO_APPLET_AWAIT:
  if(a>=RADIO_APPLET_REGISTERS || !b || (b&~15u) || !imm || imm>60000u)
   return fail(error,RADIO_APPLET_ERROR_OPERAND);
  if(b&(RADIO_APPLET_EVENT_HEADER|RADIO_APPLET_EVENT_CONFIRMED|RADIO_APPLET_EVENT_EOM))caps|=RADIO_APPLET_CAP_SAME;
  if(b&RADIO_APPLET_EVENT_KEY)caps|=RADIO_APPLET_CAP_KEY;
  break;
 default:return fail(error,RADIO_APPLET_ERROR_OPCODE);
 }
 if((p->capabilities&caps)!=caps)return fail(error,RADIO_APPLET_ERROR_CAPABILITY);
 return true;
}

bool radio_applet_vm_validate(radio_applet_read_fn read,void *context,
                             radio_applet_package *out,radio_applet_error *error) {
 uint8_t buffer[64];radio_applet_package package;
 if(error)*error=RADIO_APPLET_ERROR_NONE;
 if(out)memset(out,0,sizeof *out);
 if(!read || !read(context,0,buffer,sizeof buffer))return fail(error,RADIO_APPLET_ERROR_READ);
 if(memcmp(buffer,"DAPP",4) || get16(buffer+4)!=1u || get16(buffer+6)!=RADIO_APPLET_HEADER_BYTES ||
    get32(buffer+16)!=RADIO_APPLET_HEADER_BYTES || get32(buffer+56))return fail(error,RADIO_APPLET_ERROR_FORMAT);
 memset(&package,0,sizeof package);
 package.total_bytes=get32(buffer+8);package.capabilities=get32(buffer+12);
 package.instruction_count=get16(buffer+20);package.entry=get16(buffer+22);
 package.strings_offset=get32(buffer+24);package.strings_bytes=get32(buffer+28);package.crc=get32(buffer+60);
 uint32_t code_end=RADIO_APPLET_HEADER_BYTES+(uint32_t)package.instruction_count*RADIO_APPLET_INSTRUCTION_BYTES;
 if(package.total_bytes>RADIO_APPLET_MAX_BYTES || package.total_bytes<RADIO_APPLET_HEADER_BYTES ||
    !package.instruction_count || package.entry>=package.instruction_count ||
    (package.capabilities&~RADIO_APPLET_CAP_ALL) || package.strings_offset!=code_end ||
    code_end>package.total_bytes || package.strings_bytes!=package.total_bytes-code_end)
  return fail(error,RADIO_APPLET_ERROR_FORMAT);
 bool ended=false;
 for(unsigned i=0;i<sizeof package.name;++i) {
  uint8_t ch=buffer[32u+i];
  if(!ch)ended=true;
  else if(ended || !printable(ch))return fail(error,RADIO_APPLET_ERROR_FORMAT);
  package.name[i]=(char)ch;
 }
 if(!ended || !package.name[0])return fail(error,RADIO_APPLET_ERROR_FORMAT);
 uint32_t crc=crc_add(~0u,buffer,60);
 for(uint32_t offset=64u;offset<package.total_bytes;) {
  unsigned count=package.total_bytes-offset>sizeof buffer ? sizeof buffer : package.total_bytes-offset;
  if(!read(context,offset,buffer,count))return fail(error,RADIO_APPLET_ERROR_READ);
  crc=crc_add(crc,buffer,count);
  for(unsigned i=0;i<count;++i)
   if(offset+i>=package.strings_offset && !printable(buffer[i]))return fail(error,RADIO_APPLET_ERROR_STRING);
  offset+=count;
 }
 if(~crc!=package.crc)return fail(error,RADIO_APPLET_ERROR_CRC);
 for(unsigned i=0;i<package.instruction_count;++i) {
  if(!read(context,64u+i*8u,buffer,8))return fail(error,RADIO_APPLET_ERROR_READ);
  if(!instruction(&package,buffer,error))return false;
 }
 if(out)*out=package;
 return true;
}

void radio_applet_vm_init(radio_applet_vm *v,radio_applet_read_fn read,void *read_context,
                          const radio_applet_services *services,void *service_context) {
 if(!v)return;
 memset(v,0,sizeof *v);v->read=read;v->read_context=read_context;
 if(services)v->services=*services;
 v->service_context=service_context;
}
bool radio_applet_vm_start(radio_applet_vm *v,radio_applet_error *error) {
 if(!v)return fail(error,RADIO_APPLET_ERROR_FORMAT);
 radio_applet_vm_stop(v);
 if(!radio_applet_vm_validate(v->read,v->read_context,&v->package,&v->error)) {
  v->state=RADIO_APPLET_FAULT;if(error)*error=v->error;return false;
 }
 memset(v->registers,0,sizeof v->registers);v->pending_events=v->instructions=0;
 v->pc=v->package.entry;v->fuel=RADIO_APPLET_BURST_FUEL;v->state=RADIO_APPLET_RUNNING;
 if(error)*error=RADIO_APPLET_ERROR_NONE;
 return true;
}
void radio_applet_vm_stop(radio_applet_vm *v) {
 if(!v)return;
 v->state=RADIO_APPLET_IDLE;v->error=RADIO_APPLET_ERROR_NONE;
 v->pending_events=v->await_events=0;v->wait_ms=0;
}
void radio_applet_vm_signal(radio_applet_vm *v,uint32_t events) {
 if(v && (v->state==RADIO_APPLET_RUNNING || v->state==RADIO_APPLET_WAITING))v->pending_events|=events&15u;
}
static radio_applet_state fault(radio_applet_vm *v,radio_applet_error error) {
 v->state=RADIO_APPLET_FAULT;v->error=error;return v->state;
}
static bool text(radio_applet_vm *v,unsigned length,uint32_t offset) {
 if(!v->read(v->read_context,v->package.strings_offset+offset,v->text,length))return false;
 for(unsigned i=0;i<length;++i)if(!printable((uint8_t)v->text[i]))return false;
 v->text[length]=0;return true;
}
static void decimal(char *out,uint32_t value) {
 char digits[10];unsigned count=0;
 do {digits[count++]=(char)('0'+value%10u);value/=10u;}while(value);
 unsigned i=0;while(count)out[i++]=digits[--count];out[i]=0;
}

radio_applet_state radio_applet_vm_tick(radio_applet_vm *v,uint32_t now_ms) {
 if(!v)return RADIO_APPLET_FAULT;
 if(v->state==RADIO_APPLET_WAITING) {
  uint32_t ready=v->pending_events&v->await_events;
  if(!ready && now_ms-v->wait_started<v->wait_ms)return v->state;
  if(v->await_events) {v->registers[v->await_register]=ready;v->pending_events&=~ready;}
  v->await_events=0;v->state=RADIO_APPLET_RUNNING;
 }
 if(v->state!=RADIO_APPLET_RUNNING)return v->state;
 for(unsigned count=0;count<RADIO_APPLET_TICK_INSTRUCTIONS;++count) {
  uint8_t code[8];
  if(!v->fuel)return fault(v,RADIO_APPLET_ERROR_FUEL);
  if(v->pc>=v->package.instruction_count)return fault(v,RADIO_APPLET_ERROR_BRANCH);
  if(!v->read || !v->read(v->read_context,64u+(uint32_t)v->pc*8u,code,8))return fault(v,RADIO_APPLET_ERROR_READ);
  if(!instruction(&v->package,code,&v->error)) {v->state=RADIO_APPLET_FAULT;return v->state;}
  --v->fuel;++v->instructions;++v->pc;
  unsigned op=code[0],a=code[1],b=get16(code+2);uint32_t imm=get32(code+4);bool ok=true;
  switch(op) {
  case RADIO_APPLET_END:v->state=RADIO_APPLET_FINISHED;return v->state;
  case RADIO_APPLET_SET:v->registers[a]=imm;break;
  case RADIO_APPLET_ADD:v->registers[a]+=imm;break;
  case RADIO_APPLET_JEQ:if(v->registers[a]==imm)v->pc=(uint16_t)b;break;
  case RADIO_APPLET_JNE:if(v->registers[a]!=imm)v->pc=(uint16_t)b;break;
  case RADIO_APPLET_JMP:v->pc=(uint16_t)b;break;
  case RADIO_APPLET_WAIT:case RADIO_APPLET_YIELD:case RADIO_APPLET_AWAIT:
   v->fuel=RADIO_APPLET_BURST_FUEL;v->wait_started=now_ms;
   v->wait_ms=op==RADIO_APPLET_YIELD ? 1u : imm;
   v->await_events=op==RADIO_APPLET_AWAIT ? (uint16_t)b : 0u;v->await_register=(uint8_t)a;
   if(v->await_events && (v->pending_events&v->await_events)) {
    uint32_t ready=v->pending_events&v->await_events;v->registers[a]=ready;v->pending_events&=~ready;
    v->await_events=0;
   } else {v->state=RADIO_APPLET_WAITING;return v->state;}
   break;
  case RADIO_APPLET_EMIT_LITERAL:case RADIO_APPLET_DISPLAY_LITERAL:
   if(!text(v,b,imm))return fault(v,RADIO_APPLET_ERROR_READ);
   ok=op==RADIO_APPLET_EMIT_LITERAL ? v->services.emit && v->services.emit(v->service_context,v->text)
                                    : v->services.display && v->services.display(v->service_context,v->text);break;
  case RADIO_APPLET_SAME_START:ok=v->services.same_start && v->services.same_start(v->service_context,imm);break;
  case RADIO_APPLET_SAME_LAST:ok=v->services.same_last && v->services.same_last(v->service_context);break;
  case RADIO_APPLET_DISPLAY_SAME:ok=v->services.display_same && v->services.display_same(v->service_context);break;
  case RADIO_APPLET_EMIT_REG:
   decimal(v->text,v->registers[a]);ok=v->services.emit && v->services.emit(v->service_context,v->text);break;
  case RADIO_APPLET_GET:ok=v->services.get && v->services.get(v->service_context,b,&v->registers[a]);break;
  default:return fault(v,RADIO_APPLET_ERROR_OPCODE);
  }
  if(!ok)return fault(v,RADIO_APPLET_ERROR_SERVICE);
 }
 return v->state;
}

const char *radio_applet_vm_error_name(radio_applet_error error) {
 static const char *const names[]={"none","read","format","crc","opcode","operand","capability","branch","string","fuel","service"};
 return (unsigned)error<sizeof names/sizeof names[0] ? names[error] : "unknown";
}
