// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef SAME_PROTOCOL_H
#define SAME_PROTOCOL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Receive-only SAME/EAS framing. Primary references:
 * https://www.weather.gov/media/directives/010_pdfs/pd01017012curr.pdf
 * Appendix A defines 16 AB preamble bytes, 31 locations, ZCZC and NNNN;
 * Appendix B recommends identical copies in two of three transmissions.
 * https://www.govinfo.gov/content/pkg/CFR-2009-title47-vol1/pdf/CFR-2009-title47-vol1-part11.pdf
 * 11.31 permits either value of the eighth ASCII bit, unlike NOAA's zero.
 * Text is normalized to seven bits; preamble detection uses the raw byte.
 * No RF, audio, alert activation, wall-clock expiry, or authenticity claims.
 */
#define SAME_MAX_LOCATIONS 31u
#define SAME_HEADER_MAX 252u /* Does not include the 16-byte preamble. */
#define SAME_PREAMBLE_MIN 3u /* Acquire after loss of early preamble bytes. */
#define SAME_BYTE_TIMEOUT_MS 250u
#define SAME_BURST_TIMEOUT_MS 5000u
#define SAME_REPEAT_WINDOW_MS 15000u

enum {
 SAME_EVENT_HEADER = 1u << 0,       /* Complete, syntactically valid copy. */
 SAME_EVENT_CONFIRMED = 1u << 1,    /* Exact canonical match in 2 of 3. */
 SAME_EVENT_EOM = 1u << 2,
 SAME_EVENT_EOM_CONFIRMED = 1u << 3,
 SAME_EVENT_INVALID = 1u << 4,
 SAME_EVENT_PARTIAL = 1u << 5       /* Interrupted or timed-out copy. */
};
enum {
 SAME_ERROR_NONE = 0, SAME_ERROR_FORMAT, SAME_ERROR_CHARACTER,
 SAME_ERROR_LENGTH, SAME_ERROR_TIMEOUT, SAME_ERROR_DISCONTINUITY
};

typedef struct {
 char raw[SAME_HEADER_MAX + 1u]; /* Printable, canonical ASCII; NUL terminated. */
 char originator[4], event[4], sender[9];
 uint16_t length, purge_minutes, issue_day;
 uint8_t issue_hour, issue_minute, location_count;
} same_header;

typedef struct {
 same_header latest;             /* Last valid header; retained after expiry. */
 char raw[SAME_HEADER_MAX + 1u];  /* Current/last burst; controls become '?'. */
 char candidate[SAME_HEADER_MAX + 1u]; /* First valid vote in current group. */
 uint32_t bytes, headers, confirmations, eoms, eom_confirmations;
 uint32_t invalid, partials, preambles;
 uint32_t burst_start_ms, last_byte_ms, group_start_ms, eom_start_ms;
 uint16_t raw_length, candidate_length;
 uint8_t phase, preamble_count, error, latest_confirmed;
 uint8_t group_active, group_attempts, group_has_latest, group_confirmed;
 uint8_t eom_active, eom_attempts, eom_confirmed;
} same_protocol;

/* Strict bounded parser for canonical ASCII. Unknown uppercase event codes are
 * displayed, not acted on. Geographic assignment validity is not checked against
 * a mutable county database. Purge accepts 00:15..99:30, in 15-minute steps up to
 * one hour and 30-minute steps thereafter. Sender occupies exactly eight bytes,
 * including any ASCII space padding. On failure out is completely zeroed. */
bool same_header_parse(const char *raw, size_t length, same_header *out);
bool same_protocol_location(const same_header *header, unsigned index, char out[7]);
void same_protocol_init(same_protocol *state);
/* A missing PCM block breaks framing and all agreement votes. Keep historical
 * latest/counters so diagnostics do not silently lose evidence. Returns PARTIAL
 * and increments partials if a header/EOM was being assembled; no stack copy. */
uint32_t same_protocol_discontinuity(same_protocol *state);
/* All times use one monotonic millisecond clock; wrap at UINT32_MAX is supported.
 * Each new burst needs a fresh preamble. A group has at most three attempts,
 * including invalid/partial headers. No bitwise repair or hash-only agreement.
 * Reading state and feeding it must be serialized by the caller. */
uint32_t same_protocol_feed_byte(same_protocol *state, uint8_t byte, uint32_t now_ms);
uint32_t same_protocol_tick(same_protocol *state, uint32_t now_ms);

#endif
