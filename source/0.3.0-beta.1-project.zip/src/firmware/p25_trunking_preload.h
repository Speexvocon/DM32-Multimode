// SPDX-License-Identifier: GPL-3.0-or-later
// Pure native-RAM geometry for a finite laboratory ISP. No RF permission.
#ifndef P25_TRUNKING_PRELOAD_H
#define P25_TRUNKING_PRELOAD_H
#include <stdbool.h>
#include <stdint.h>

#define P25_TRUNK_PRELOAD_VALID_BITS 316u
#define P25_TRUNK_PRELOAD_PREFIX_BYTES 40u
#define P25_TRUNK_PRELOAD_HALF_BYTES 36u
#define P25_TRUNK_PRELOAD_RAM_BYTES 72u
#define P25_TRUNK_PRELOAD_MAX_LEAD_BYTES 16u
#define P25_TRUNK_PRELOAD_LEAD_BYTE 0x77u
#define P25_TRUNK_PRELOAD_NOMINAL_TICKS 1580u // 48 kHz / 9600 bit/s * 316 bits.
#define P25_TRUNK_PRELOAD_NOMINAL_US 32917u  // Rounded UP; not a measured cutoff.

typedef struct {
    uint8_t first_half; // Physical native RAM half sent first: 0 or 1.
    uint8_t fill_byte;  // Explicit RAM byte pattern; NOT a guarantee of RF silence.
    uint8_t lead_bytes; // Optional 0..16 bytes of 0x77 before the ISP; default 0.
} p25_trunking_preload_config;
typedef struct {
    uint16_t valid_bits,prefix_bytes,ram_bytes,half_bytes;
    uint16_t first_valid_bits,second_valid_bits;
    uint32_t nominal_us;
    uint16_t nominal_ticks;
    uint8_t first_half,fill_byte,lead_bytes;
} p25_trunking_preload_plan;

// With default lead_bytes=0, the ISP starts at the chosen native half's first
// bit and its logical first/second halves carry 288/28 meaningful bits. Optional
// 0x77 leading bytes reduce first_valid_bits and increase second_valid_bits;
// their sum remains 316. Nominal duration/ticks include the optional lead. The 72-byte
// transport holds 576 bits/60 ms if allowed to run to its end; that is NOT the ISP
// duration. A separately measured first-bit origin, PA window and independent
// hard cutoff are mandatory external controller contracts. These nominal
// dimensions never select an access slot or qualify start/end RF timing.
// Invalid input leaves the existing output unchanged. No heap or RF calls.
bool p25_trunking_preload_plan_make(p25_trunking_preload_plan *out,
                                   const p25_trunking_preload_config *config);
// Render the PHYSICAL native RAM image (half 0 then half 1). The caller must
// independently establish which half the hardware sends first. Prefix supplies
// exactly 316 meaningful bits packed MSB-first in 40 bytes: byte 39's low nibble
// is ignored. The remainder is the explicit fill_byte at native byte alignment,
// including that byte's LOW fill nibble; no 45-byte CAI protocol pad is emitted.
// Leading bytes are always 0x77, independently of fill_byte. The 16-byte maximum
// leaves all meaningful bits within the fixed immutable 72-byte native image.
// Filler can modulate RF if the PA remains enabled. Keep the prefix immutable
// through the call; output may overlap prefix because rendering uses local RAM.
// A forged/malformed plan or NULL input leaves output unchanged.
bool p25_trunking_preload_render(const p25_trunking_preload_plan *plan,
    const uint8_t prefix[P25_TRUNK_PRELOAD_PREFIX_BYTES],
    uint8_t out[P25_TRUNK_PRELOAD_RAM_BYTES]);
// Copy a fixed 72-byte laboratory phase marker, not a CAI/ISP packet. Every
// circular dibit-aligned 64-bit window is distinct, including the RAM wrap.
// Physical half/bit origin must still be established from captured RF; neither
// this image nor a native interrupt identifies the reader position. No RF or
// permission changes. NULL is refused; the caller owns the complete copy and
// must keep it immutable throughout its separately guarded measurement.
bool p25_trunking_preload_phase_image(uint8_t out[P25_TRUNK_PRELOAD_RAM_BYTES]);
#endif
