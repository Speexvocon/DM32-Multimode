// SPDX-License-Identifier: GPL-3.0-or-later
// Native endpoint adapter. The script VM never executes in the audio/IRQ path.
#ifndef P25_PCM_APPLET_H
#define P25_PCM_APPLET_H
static uint32_t pcm_last_input;
static bool pcm_dmr_seen_tx,pcm_wire_started,pcm_stop_received;
static const dmr_voice_source_t *pcm_dmr_source;
static volatile bool pcm_dmr_source_running;
static bool pcm_dmr_tail_drained;
static unsigned pcm_dmr_air_frames,pcm_dmr_tail_padding;
static bool pcm_dmr_rx_playing;
static void pcm_dmr_source_begin(void *ctx) {
    (void)ctx;pcm_dmr_air_frames=pcm_dmr_tail_padding=0;pcm_dmr_tail_drained=false;
    if(pcm_dmr_source && pcm_dmr_source->begin)pcm_dmr_source->begin(pcm_dmr_source->ctx);
    pcm_dmr_source_running=true;
}
static bool pcm_dmr_source_next(uint8_t *frame,void *ctx) {
    (void)ctx;
    if(pcm_dmr_source && pcm_dmr_source->next && pcm_dmr_source->next(frame,pcm_dmr_source->ctx)) {
        ++pcm_dmr_air_frames;return true;
    }
    if(!radio_pcm_engine_tx_eof(&pcm_engine))return false;
    if(pcm_dmr_tail_padding<3u) {
        static const uint8_t silence[9]={0xb9,0xe8,0x81,0x52,0x61,0x73,0,0x2a,0x6b};
        memcpy(frame,silence,sizeof silence);++pcm_dmr_tail_padding;
        if(pcm_dmr_tail_padding==3u)pcm_dmr_tail_drained=true;
        return true;
    }
    // Three extra silence frames force a stage request after the last real
    // frame's burst was accepted, regardless of its position within that burst.
    // Only silent padding can remain behind the native stop-at-boundary check.
    return false;
}
static void pcm_dmr_source_end(void *ctx) {
    (void)ctx;pcm_dmr_source_running=false;
    if(pcm_dmr_source && pcm_dmr_source->end)pcm_dmr_source->end(pcm_dmr_source->ctx);
}
static const dmr_voice_source_t pcm_dmr_serial_source={pcm_dmr_source_begin,pcm_dmr_source_next,pcm_dmr_source_end,NULL};
static uint32_t pcm_lock(void *ctx) {(void)ctx;return hrc_irq_save();}
static void pcm_unlock(void *ctx,uint32_t token) {(void)ctx;hrc_irq_restore(token);}
static size_t pcm_write(void *ctx,const uint8_t *p,size_t n) {(void)ctx;return pcm_binary ? dm32_pcm_uart_write(p,n):0;}
static void pcm_unkey(void *ctx) {
    (void)ctx;hardware_stop();pcmq.accepting=false;call_active=false;
}
static bool pcm_fm_pop(void *ctx,int16_t *p) {(void)ctx;return radio_pcm_engine_tx_pop(&pcm_engine,p);}
static bool pcm_fm_eof(void *ctx) {(void)ctx;return radio_pcm_engine_tx_eof(&pcm_engine);}
static bool pcm_fm_push(void *ctx,const int16_t *p) {(void)ctx;return hrc7000_prompt_push(dev,p);}
static bool pcm_fm_route(void *ctx,bool on) {(void)ctx;return dm32_pcm_fm_route(on);}
static void pcm_fm_irq(void) {
    hrc_timer_ack(SPEAKER_TIMER);
    if(!pcm_owner || !pcm_engine.tx_started)return;
    radio_pcm_fm_state state=radio_pcm_fm_tx_service(&pcm_fm,hrc_micros());
    if(state==RADIO_PCM_FM_FAULT)radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
}
static void pcm_dmr_block(const int16_t *mic,int16_t *speaker,void *ctx) {
    (void)ctx;int16_t source[160];
    const dmr_call_view_t *view=radio_dmr_view(&digital_dmr);
    memset(source,0,sizeof source);
    if(pcm_owner && pcm_engine.config.operations==RADIO_PCM_TX && pcm_dmr_source_running
       && radio_pcm_engine_tx_eof(&pcm_engine)) {
        memset(speaker,0,320);return; // Freeze encoding so the finite AMBE tail can drain.
    }
    if(pcm_owner && pcm_engine.config.operations==RADIO_PCM_TX && pcm_engine.tx_started
       && digital_dmr.tx_armed && pcm_dmr_source_running
       && !radio_pcm_engine_tx_eof(&pcm_engine))
        (void)radio_pcm_engine_tx_pop(&pcm_engine,source);
    if(pcm_dmr_callback)pcm_dmr_callback(pcm_owner ? source:mic,speaker,pcm_dmr_context);
    else memset(speaker,0,320);
    if(pcm_owner && pcm_engine.rx_started && pcm_dmr_rx_playing && view && !view->caller.encrypted)
        (void)radio_pcm_engine_rx_push(&pcm_engine,speaker,hal_millis());
    if(pcm_owner)memset(speaker,0,320); // Serial endpoint owns the output, not the local speaker.
}
static bool pcm_dmr_audio_start(audio_block_cb_t cb,void *ctx) {
    pcm_dmr_callback=cb;pcm_dmr_context=ctx;return board.audio->start(pcm_dmr_block,NULL);
}
static void pcm_dmr_audio_stop(void) {board.audio->stop();pcm_dmr_callback=NULL;pcm_dmr_context=NULL;}
static void pcm_dmr_speaker(bool on) {pcm_dmr_rx_playing=on;board.audio->speaker_pcm(pcm_owner ? false:on);}
static const hal_audio_t pcm_dmr_audio={pcm_dmr_audio_start,pcm_dmr_audio_stop,pcm_dmr_speaker};
static bool pcm_tx_allowed(void) {
    return !owner_tx_inhibit && !(pcm_saved_channel[12]&16u) && feature_tx_settings_valid()
        && bf_cal_valid() && channel_in_band(pcm_hz,true) && channel_in_band(frequency,false)
        && board.power->battery_mv()>=board.battery_critical_mv
        && hrc_pin_read(PIN_PTT) && !(board.input->scan()&ptt_mask);
}
static bool pcm_start_dmr(bool transmit) {
    pcm_dmr_rx_playing=false;
    digital_dmr.hal.audio=&pcm_dmr_audio;
    radio_dmr_config config={.rx_hz=pcm_hz,.tx_hz=pcm_hz,.source_id=control.source_id,
        .target_id=radio_channel_get_destination(channel_record),
        .cc=(uint8_t)radio_channel_get_color_code(channel_record),
        .ts=(uint8_t)radio_channel_get_timeslot(channel_record),
        .power=(uint8_t)feature_tx_power(),.tot_s=(uint16_t)feature_tx_tot(),
        .private_call=radio_channel_get_private(channel_record),.rmo=radio_channel_get_repeater(channel_record),
        .filter=rx_promiscuous ? RADIO_DMR_FILTER_PROM : rx_tg_filter ? RADIO_DMR_FILTER_TARGET : RADIO_DMR_FILTER_SLOT,
        .rx_only=!transmit,.owner_permission=transmit};
    if(!radio_dmr_start(&digital_dmr,&config))return false;
    if(transmit) {
        pcm_dmr_source=ambeVoiceSource();pcm_dmr_source_running=pcm_dmr_tail_drained=false;
        pcm_dmr_air_frames=pcm_dmr_tail_padding=0;
        if(!pcm_dmr_source || !pcm_dmr_source->next)return false;
        dmr_call_set_voice(ambeVoiceSink(),&pcm_dmr_serial_source);
    }
    // Clear the native release interlock without forwarding physical PTT.
    radio_dmr_poll(&digital_dmr,hal_millis(),false,transmit);
    return true;
}
static bool pcm_start_rx(void *ctx,const radio_pcm_config *c) {
    (void)ctx;
    bool ok=false;
    if(c->modulation==RADIO_PCM_P25) {mon_enabled=mon_audio_enabled=true;ok=mon_start();}
    else if(c->modulation==RADIO_PCM_DMR)ok=pcm_start_dmr(false);
    else {
        board.radio->set_mode(RADIO_MODE_FM);
        ok=board.radio->rx(pcm_hz,c->modulation==RADIO_PCM_FM ? RADIO_BW_25K:RADIO_BW_12K5,NULL);
        if(ok) {
            hardware_stop();memset(&same_rx,0,sizeof same_rx);
            hrc7000_fm_rx(dev,c->modulation==RADIO_PCM_FM);
            hrc7000_audio_bits(dev,0,C7_AUDIO_FM_PLAY);same_last_pcm_us=hrc_micros();
            uint32_t token=hrc_irq_save();pcm_raw_capture=true;
            wr(C7_SYS_INTERP_CLEAR,UINT32_MAX);wr(C7_SYS_INTERP_MASK,1u<<14);
            hrc_irq_enable(IRQ_MODEM_SYS,true);hrc_irq_restore(token);
        }
    }
    pcm_backend_started=ok;return ok;
}
static bool pcm_start_tx(void *ctx,const radio_pcm_config *c) {
    (void)ctx;if(!pcm_tx_allowed())return false;
    radio_inhibit(&control,false);control.cancel=false;
    if(!hard_guard_arm((c->tot_ms+999u)/1000u+2u))return false;
    bool ok=false;pcm_dmr_seen_tx=false;
    if(c->modulation==RADIO_PCM_P25)ok=begin_capture();
    else if(c->modulation==RADIO_PCM_DMR) {
        ok=pcm_start_dmr(true);
        if(ok)ok=hard_guard_arm((c->tot_ms+999u)/1000u+2u);
    }
    else {
        board.radio->set_mode(RADIO_MODE_FM);
        ok=dm32_pcm_fm_prepare(pcm_hz,c->modulation==RADIO_PCM_FM,(uint8_t)feature_tx_power());
        if(ok) {
            // Native prompt playback may contain a stopped speaker's tail.
            // Drain with the physical microphone and PA still disabled.
            vTaskDelay(pdMS_TO_TICKS(16));
            call_active=hardware_running=true;
            const radio_pcm_fm_hal hal={.pop=pcm_fm_pop,.eof=pcm_fm_eof,.prompt_push=pcm_fm_push,
                .route=pcm_fm_route,.unkey=pcm_unkey,.clock_us=dmr_clock_us};
            radio_pcm_fm_tx_init(&pcm_fm,&hal,NULL);
            ok=radio_pcm_fm_tx_start(&pcm_fm,c->modulation==RADIO_PCM_FM,hrc_micros());
            if(ok)ok=radio_pcm_fm_tx_service(&pcm_fm,hrc_micros())==RADIO_PCM_FM_RUNNING && pcm_fm.chunks>0;
            if(ok)ok=dm32_pcm_fm_key(); // FIFO is primed and the physical microphone stayed muted.
            if(ok) {hrc_irq_register(IRQ_TIMER4,pcm_fm_irq);hrc_irq_enable(IRQ_TIMER4,true);hrc_timer_periodic(SPEAKER_TIMER,2000u);}
        }
    }
    pcm_source_due=hrc_micros();pcm_backend_started=ok;return ok;
}
static void pcm_stop_all(void *ctx) {
    (void)ctx;uint32_t token=hrc_irq_save();pcm_raw_capture=false;
    hrc_timer_stop(SPEAKER_TIMER);hrc_irq_enable(IRQ_TIMER4,false);hardware_stop();hrc_irq_restore(token);
    if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
    pcm_dmr_source_running=pcm_dmr_rx_playing=false;pcm_dmr_source=NULL;
    digital_dmr.hal.audio=board.audio;
    if(mon_running)mon_stop("pcm_stop");
    radio_pcm_fm_tx_stop(&pcm_fm);
    audio_stop();
    if(prepared) {reason="cancelled";cleanup();}
    call_active=false;prepared=false;mon_enabled=false;pcm_backend_started=false;
    board.audio->stop();board.audio->speaker_pcm(false);board.radio->tx_off();board.radio->audio(false);board_rf_safe();
}
static void pcm_leave(bool resume) {
    radio_pcm_engine_stop(&pcm_engine);pcm_stop_all(NULL);
    // UART ring is bounded-drained before returning to legacy polling writes.
    (void)dm32_pcm_uart_baud(115200u);pcm_binary=pcm_owner=false;
    memcpy(channel_record,pcm_saved_channel,sizeof channel_record);feature_apply();
    mon_audio_enabled=pcm_saved_audio;applet_owns_radio=false;
    ptt_release_required=true;ptt_release_seen=false;command_used=0;command_overflow=false;
    if(resume)apps_radio_resume();
    screen("HOME");
}
static void pcm_poll(void) {
    uint32_t now=hal_millis();
    if(!pcm_binary) {
        if((int32_t)(hrc_micros()-pcm_baud_due)<0)return;
        if(!dm32_pcm_uart_baud(230400u)) {pcm_leave(true);send("APP PCM ERROR baud change failed\r\n");return;}
        pcm_binary=true;pcm_last_input=now;
    }
    // A P25 encode can occupy nearly 20 ms. Drain at least one complete
    // 347-byte PCM wire packet before the next codec pass; 128 bytes per
    // pass would cap input below the 16-kB/s audio payload and starve TX.
    // Retain the small stack buffer and a finite 512-byte task budget.
    uint8_t input[128];
    for(unsigned chunks=0;chunks<4u;++chunks) {
        size_t n=board.host_port->read(input,sizeof input);if(!n)break;
        pcm_last_input=now;radio_pcm_engine_feed(&pcm_engine,input,n,now);
        for(size_t i=0;i<n;++i)if(!input[i])pcm_wire_started=true;
        if(n<sizeof input || pcm_engine.state==RADIO_PCM_STOPPED || pcm_engine.state==RADIO_PCM_FAULT)break;
    }
    if(now-pcm_last_input>2000u && pcm_engine.state!=RADIO_PCM_STOPPED && pcm_engine.state!=RADIO_PCM_FAULT)
        radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_TIMEOUT);
    if(pcm_backend_started && pcm_engine.rx_started) {
        if(pcm_raw_capture) {
            // Snapshot the ISR timestamp before the clock. A just-published
            // timestamp can otherwise look like an unsigned multi-minute stall.
            uint32_t last_pcm_us=same_last_pcm_us;
            if((int32_t)(hrc_micros()-last_pcm_us)>200000)radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
            for(unsigned limit=0;limit<2u;++limit) {
                const radio_app_audio_block *b=radio_app_audio_peek(&same_rx.audio);if(!b)break;
                if(b->gap) {radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);break;}
                for(unsigned i=0;i<RADIO_APP_AUDIO_SAMPLES;++i) {
                    same_rx.pcm_frame[same_rx.pcm_position++]=b->pcm[i];
                    if(same_rx.pcm_position==160u) {
                        (void)radio_pcm_engine_rx_push(&pcm_engine,same_rx.pcm_frame,now);same_rx.pcm_position=0;
                    }
                }
                radio_app_audio_commit(&same_rx.audio);
            }
        } else if(pcm_engine.config.modulation==RADIO_PCM_P25) {
            mon_poll(false);
            if(!mon_running)radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
            // Existing 48-frame PCM ring absorbs the 9-frame LDU bursts. Move
            // one frame per poll only when the transport queue has room.
            if(monitor.pcm_head!=monitor.pcm_tail
               && mon_count(pcm_engine.rx.head,pcm_engine.rx.tail,RADIO_PCM_QUEUE)<RADIO_PCM_CAPACITY) {
                (void)radio_pcm_engine_rx_push(&pcm_engine,monitor.pcm[monitor.pcm_tail],now);
                mon_pcm_commit_samples(&monitor,160u);
            }
        }
    }
    if(pcm_backend_started && pcm_engine.config.modulation==RADIO_PCM_DMR && digital_dmr.running) {
        bool tx=pcm_engine.tx_started && !(radio_pcm_engine_tx_eof(&pcm_engine) && pcm_dmr_tail_drained);
        bool was=digital_dmr.tx_armed;
        radio_dmr_poll(&digital_dmr,now,tx,pcm_engine.config.operations==RADIO_PCM_TX && pcm_engine.tx_started);
        if(digital_dmr.tx_armed)pcm_dmr_seen_tx=true;
        call_active=hardware_running=digital_dmr.tx_armed;
        if(pcm_engine.config.operations==RADIO_PCM_TX && was && !digital_dmr.tx_armed) {
            if(radio_pcm_engine_tx_eof(&pcm_engine) && digital_dmr.tx_error==DMR_TX_OK)
                (void)radio_pcm_engine_tx_finish(&pcm_engine);
            else radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
        } else if(pcm_engine.tx_started && pcm_dmr_seen_tx && !digital_dmr.tx_armed)
            radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
    }
    if(pcm_backend_started && pcm_p25_tx() && pcm_engine.tx_started) {
        bool eof=radio_pcm_engine_tx_eof(&pcm_engine);
        if(!eof && (int32_t)(hrc_micros()-pcm_source_due)>=0) {
            int16_t block[160];
            if(hrc_micros()-pcm_source_due>60000u)radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
            else if(radio_pcm_engine_tx_pop(&pcm_engine,block)) {
                mic_queue_push_limit(&pcmq,block,hrc_micros(),call_capture_frames);last_pcm=hrc_micros();pcm_source_due+=20000u;
            }
        }
        if(pcm_engine.tx_started) {
            poll_call(!radio_pcm_engine_tx_eof(&pcm_engine));
            if(!call_active) {
                if(radio_pcm_engine_tx_eof(&pcm_engine) && live.timing.state==P25_TX_DONE)
                    (void)radio_pcm_engine_tx_finish(&pcm_engine);
                else radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_HAL);
            }
        }
    }
    if(pcm_backend_started && pcm_engine.tx_started && pcm_engine.config.modulation<=RADIO_PCM_NFM
       && pcm_fm.state==RADIO_PCM_FM_DONE)(void)radio_pcm_engine_tx_finish(&pcm_engine);
    if(pcm_engine.pending&(1u<<RADIO_PCM_STOP))pcm_stop_received=true;
    radio_pcm_engine_poll(&pcm_engine,now,pcm_wire_started ? RADIO_PCM_WRITE_BUDGET:0u);
    if(pcm_engine.state==RADIO_PCM_STOPPED || pcm_engine.state==RADIO_PCM_FAULT) {
        // END acknowledges completed airtime. Keep the binary link until the
        // client closes with STOP; changing baud immediately races its close.
        if(pcm_engine.state==RADIO_PCM_STOPPED && pcm_engine.end_received && !pcm_stop_received
           && now-pcm_last_input<2000u)return;
        if(!pcm_close_due)pcm_close_due=now+500u;
        if((radio_pcm_engine_output_idle(&pcm_engine) && dm32_pcm_uart_idle()) || (int32_t)(now-pcm_close_due)>=0)
            pcm_leave(true);
    }
}
static bool pcm_command(const char *line) {
    if(strncmp(line,"APP PCM",7))return false;
    if(trunk_enabled) {send("APP PCM ERROR stop Trunk RX first\r\n");return true;}
    char endpoint[8],mod[8],operation[8],tail;unsigned long hz;
    if(sscanf(line,"APP PCM OPEN %7s %7s %7s %lu %c",endpoint,mod,operation,&hz,&tail)!=4) {
        send("APP PCM ERROR use OPEN RAW|VOICE FM|NFM|P25|DMR RX|TX hz\r\n");return true;
    }
    int mode=!strcmp(endpoint,"RAW") ? RADIO_PCM_RAW:!strcmp(endpoint,"VOICE") ? RADIO_PCM_VOICE:-1;
    int modulation=!strcmp(mod,"FM") ? RADIO_PCM_FM:!strcmp(mod,"NFM") ? RADIO_PCM_NFM:
        !strcmp(mod,"P25") ? RADIO_PCM_P25:!strcmp(mod,"DMR") ? RADIO_PCM_DMR:-1;
    int op=!strcmp(operation,"RX") ? RADIO_PCM_RX:!strcmp(operation,"TX") ? RADIO_PCM_TX:0;
    if(mode<0 || modulation<0 || !op || (mode==RADIO_PCM_RAW && modulation>RADIO_PCM_NFM)
       || hz>UINT32_MAX || !channel_in_band((uint32_t)hz,op==RADIO_PCM_TX)) {
        send("APP PCM ERROR unsupported endpoint or frequency\r\n");return true;
    }
    if((modulation==RADIO_PCM_DMR && !feature_dmr()) || (modulation==RADIO_PCM_P25 && !feature_p25())) {
        send("APP PCM ERROR select a matching digital channel for NAC/TG/CC/slot settings\r\n");return true;
    }
    if(op==RADIO_PCM_TX && (owner_tx_inhibit || (channel_record[12]&16u) || !bf_cal_valid()
       || !feature_tx_settings_valid() || board.power->battery_mv()<board.battery_critical_mv)) {
        send("APP PCM ERROR TX policy refuses session\r\n");return true;
    }
    if(!applet_acquire(NULL)) {send("APP PCM ERROR radio busy or PTT held\r\n");return true;}
    memcpy(pcm_saved_channel,channel_record,sizeof channel_record);pcm_saved_audio=mon_audio_enabled;
    pcm_owner=true;applet_owns_radio=false;pcm_binary=pcm_backend_started=false;pcm_close_due=0;
    pcm_wire_started=pcm_stop_received=false;
    pcm_hz=(uint32_t)hz;
    pref_put(channel_record,pcm_hz);pref_put(channel_record+4,pcm_hz);channel_record[12]|=1u;
    (void)radio_channel_set_mode(channel_record,modulation==RADIO_PCM_P25 ? RADIO_CHANNEL_P25:
        modulation==RADIO_PCM_DMR ? RADIO_CHANNEL_DMR:RADIO_CHANNEL_FM);
    feature_apply();control.cancel=false;radio_complete(&control,false);
    radio_pcm_hal hal={.start_rx=pcm_start_rx,.start_tx=pcm_start_tx,.stop_tx=pcm_unkey,
        .stop_all=pcm_stop_all,.write=pcm_write,.lock=pcm_lock,.unlock=pcm_unlock};
    radio_pcm_engine_init(&pcm_engine,&hal);
    if(!++pcm_session)++pcm_session;
    radio_pcm_config config={.session=pcm_session,.tot_ms=feature_tx_tot()*1000u,
        .mode=(uint8_t)mode,.operations=(uint8_t)op,.modulation=(uint8_t)modulation};
    if(!radio_pcm_engine_open(&pcm_engine,&config,hal_millis())) {pcm_leave(true);send("APP PCM ERROR configuration\r\n");return true;}
    reason="pcm_engine";apps_screen();
    char reply[64];snprintf(reply,sizeof reply,"APP PCM READY 230400 %lu\r\n",(unsigned long)pcm_session);send(reply);
    pcm_baud_due=hrc_micros()+40000u;return true;
}
#endif
