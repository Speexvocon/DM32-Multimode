// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_DATA_H
#define P25_DATA_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Bounded conventional Phase 1 data profile: unconfirmed CAI PDU, SAP 4,
// IPv4/UDP 4007 Motorola TMS. Individual units, printable ASCII only.
// This is not a claim of generic P25 text-service or network interoperability.
#define P25_DATA_FRAME_BYTES 512u
#define P25_DATA_TEXT_BYTES 80u
#define P25_DATA_MAX_BLOCKS 18u
typedef struct {
    uint32_t source,destination;
    uint8_t sequence;
    bool acknowledgment,ack_requested;
    char text[P25_DATA_TEXT_BYTES+1u];
} p25_data_message;

// Produces a complete packed-dibit frame (MSB first), including sync, NID,
// status symbols and zero fill through the last 36-dibit microslot. No RF
// preamble is included. Returns byte count or zero; no partial output on error.
// TX requests no TMS acknowledgment. An on-air completion is not delivery.
size_t p25_data_build_tms(uint8_t *frame,size_t capacity,uint16_t nac,
    uint32_t source,uint32_t destination,uint8_t sequence,const char *text);
// Accepts exactly one complete unconfirmed frame. Validates header CRC, trellis,
// packet CRC, IP/UDP checksums, unfragmented IP, app framing and RF IP addresses.
// Confirmed, fragmented, extended-address, encrypted and other SAPs are refused.
// Outputs change only on success. No automatic RF acknowledgment is triggered.
bool p25_data_parse_tms(const uint8_t *frame,size_t length,p25_data_message *out);
// Header must include its 98 encoded dibits. Zero means invalid or unsupported;
// otherwise returns the full padded frame length, measured in dibits.
unsigned p25_data_header_symbols(const uint8_t *frame,size_t length);
#endif
