// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded lab burst geometry only. No RF permission or physical timing claim.
#ifndef P25_TRUNKING_BURST_H
#define P25_TRUNKING_BURST_H
#include <stdbool.h>
#include <stdint.h>

#define P25_TRUNK_BURST_VALID_BITS 316u
#define P25_TRUNK_BURST_PREFIX_BYTES 40u
#define P25_TRUNK_BURST_BLOCK_BYTES 36u
#define P25_TRUNK_BURST_MAX_TRANSPORT_BYTES 288u
// ceil(316 bits * 1,000,000 / 9600 bits/s), not a measured radio duration.
#define P25_TRUNK_BURST_NOMINAL_US 32917u

typedef struct {
    uint16_t lead_bytes;
    uint32_t packet_after_rf_us;
    uint16_t pa_lead_us;
    int16_t end_trim_us;
} p25_trunking_burst_config;

typedef struct {
    uint16_t lead_bytes,valid_bits,prefix_bytes,transport_bytes;
    uint32_t packet_after_rf_us,pa_after_rf_us,cut_after_rf_us;
} p25_trunking_burst_plan;

// Explicit lab ranges: lead72..240 bytes; packet30,000..220,000 us after the
// caller's RF event; PA lead0..2,000 us; cutoff trim-2,000..2,000 us. Computed
// cutoff is <=260,000 us and strictly after PA. This is a nominal schedule,
// never proof that RF first/last bits occur at those software timer offsets.
// Failure leaves output unchanged. No heap or persistent storage is used.
bool p25_trunking_burst_plan_make(p25_trunking_burst_plan *out,
                                 const p25_trunking_burst_config *config);
// Render one complete transport block from a borrowed immutable CAI prefix:
// lead0x77 bytes, first39 complete prefix bytes, prefix[39]'s high nibble, then
// low nibble0x7 and0x77 fill. The45-byte protocol padding is NEVER appended.
// prefix supplies exactly316 meaningful bits in40 packed bytes; its unused
// low nibble is ignored. Frame validity is the caller's separate contract.
// The caller keeps prefix stable and supplies a distinct output block. There
// are transport_bytes/36 blocks; an invalid plan/index leaves output unchanged.
bool p25_trunking_burst_render(const p25_trunking_burst_plan *plan,
                              const uint8_t prefix[P25_TRUNK_BURST_PREFIX_BYTES],
                              unsigned block_index,
                              uint8_t out[P25_TRUNK_BURST_BLOCK_BYTES]);
#endif
