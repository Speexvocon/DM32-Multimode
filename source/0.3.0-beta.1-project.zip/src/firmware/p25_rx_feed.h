// SPDX-License-Identifier: GPL-3.0-or-later
// Lean, continuous recorder feed. CPU/recorder metadata is not an RF clock.
#ifndef P25_RX_FEED_H
#define P25_RX_FEED_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define P25_RX_FEED_CHUNK_SAMPLES 16u
#define P25_RX_FEED_RING_ROWS 16u
#define P25_RX_FEED_ROW_BYTES 56u
#define P25_RX_FEED_STORAGE_BYTES (P25_RX_FEED_RING_ROWS*P25_RX_FEED_ROW_BYTES)
#define P25_RX_FEED_GUARD_US 2000u
#define P25_RX_FEED_MAX_AGE_US 16000u
#define P25_RX_FEED_FIRST_IRQ_TIMEOUT_US 200000u
enum { P25_RX_FEED_IDLE,P25_RX_FEED_WAIT_IRQ,P25_RX_FEED_RUNNING,
    P25_RX_FEED_DRAINING,P25_RX_FEED_COMPLETE,P25_RX_FEED_STOPPED,P25_RX_FEED_FAULT };
enum {
    P25_RX_FEED_BAD_IRQ=1u,P25_RX_FEED_IRQ_SEQUENCE=2u,
    P25_RX_FEED_IRQ_CLOCK=4u,P25_RX_FEED_MISSING_IRQ=8u,
    P25_RX_FEED_OVERWRITTEN=16u,P25_RX_FEED_TORN=32u,
    P25_RX_FEED_IRQ_READ=64u,P25_RX_FEED_RING_FULL=128u,
    P25_RX_FEED_STALE=256u,P25_RX_FEED_CLOCK=512u,
    P25_RX_FEED_COUNTER=1024u,P25_RX_FEED_META=2048u,
    P25_RX_FEED_BAD_IO=4096u
};
typedef enum { P25_RX_FEED_REVOKED=-1,P25_RX_FEED_WAIT=0,
    P25_RX_FEED_PUBLISHED=1 } p25_rx_feed_step_result;
typedef struct {
    uint16_t guard_us,max_age_us;
    uint32_t sample_limit; //0 continuous; otherwise256..8192, multiple256.
} p25_rx_feed_config;
typedef struct {
    void *context;
    uint8_t (*read_byte)(void *context,unsigned offset);
    uint32_t (*clock_us)(void *context);
    // Mandatory direct pending-half query; must not clear/consume the IRQ.
    bool (*half_pending)(void *context);
} p25_rx_feed_io;
typedef struct {
    int16_t samples[P25_RX_FEED_CHUNK_SAMPLES];
    uint32_t first_sample,read_begin_us,read_end_us,origin_irq_us,origin_irq_count;
    uint16_t sample_offset;
    uint8_t target_half,reserved;
} p25_rx_feed_chunk;
typedef struct {
    unsigned char *storage;
    uint32_t armed_us,last_step_us,stream_epoch,sample_limit;
    volatile uint32_t produced,consumed;
    // Observed CPU durations only; queue maximum includes a stale-fault check.
    // read_bytes saturates instead of wrapping during a long continuous session.
    uint32_t max_queue_us,max_read_us,read_calls,read_bytes;
    volatile uint32_t irq_serial,irq_count,last_irq_us,previous_irq_us;
    uint16_t guard_us,max_age_us,faults;
    volatile uint8_t last_half,state;
    bool have_step,pending_wait;
} p25_rx_feed;

void p25_rx_feed_init(p25_rx_feed *s);
bool p25_rx_feed_active(const p25_rx_feed *s);
bool p25_rx_feed_producing(const p25_rx_feed *s);
// Caller owns the recorder and serializes task operations against its producer.
// Initialize once, then use a strictly newer nonzero epoch for every restart.
// Config accepts guard2000..8000 and freshness1000..16000us. No total timeout.
// A finite limit stops publication at DRAINING; the final pop sets COMPLETE.
// Caller must still process that returned chunk before shutting down its worker.
// Storage is character-accessed, needs no alignment, and must not overlap state.
// Refused starts leave both state and storage unchanged. No storage clear/allocation.
bool p25_rx_feed_start(p25_rx_feed *s,void *storage,size_t bytes,
    const p25_rx_feed_config *config,uint32_t epoch,uint32_t now_us);
// Completed half1/2 alternates every30..34ms. First IRQ discards its completed
// half: ordinal0 starts in the opposite half that has just begun filling.
// Non-nesting producer IRQ only; no DSP, callbacks, hashes or source copies.
bool p25_rx_feed_irq(p25_rx_feed *s,unsigned completed_half,uint32_t now_us);
// At most48 source-byte reads: one high-low-high pass per16-sample chunk.
// Reject torn words, pending/new IRQ during read, stale/full queue or overwrite.
// A pending IRQ before the read merely waits for its handler; missing-IRQ and
// freshness deadlines still apply. No double pass, later readback or ledger.
p25_rx_feed_step_result p25_rx_feed_step(p25_rx_feed *s,
    const p25_rx_feed_io *io,uint32_t now_us);
// Output unchanged on refusal. Never skips samples to conceal stale work.
bool p25_rx_feed_pop(p25_rx_feed *s,p25_rx_feed_chunk *out,uint32_t now_us);
// Suggested next source deadline;0 when inactive,500us fallback for a pending
// boundary/tail/first IRQ. Actual periodic scheduling remains caller-owned.
uint32_t p25_rx_feed_next_delay(const p25_rx_feed *s,uint32_t now_us);
void p25_rx_feed_stop(p25_rx_feed *s);
// One pass can miss low-byte-only changes and ABA. A clear fault state does not
// certify an atomic sample, writer frontier, calibrated clock or RF origin.
#endif
