// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_pcm_engine.h"
#include <string.h>

#define HELLO_PENDING (1u<<9)
#define GAP_FLAG 1u
static uint16_t rd16(const uint8_t *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static uint32_t rd32(const uint8_t *p) {return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void wr16(uint8_t *p,uint16_t n) {p[0]=(uint8_t)n;p[1]=(uint8_t)(n>>8);}
static void wr32(uint8_t *p,uint32_t n) {for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(n>>(8u*i));}
static uint32_t crc_part(uint32_t c,const uint8_t *p,size_t n) {
    while(n--) {c^=*p++;for(unsigned i=0;i<8;++i)c=(c>>1)^((0u-(c&1u))&0xedb88320u);}
    return c;
}
uint32_t radio_pcm_engine_crc(const uint8_t *p,size_t n) {return ~crc_part(UINT32_MAX,p,n);}
static uint32_t lock(radio_pcm_engine *s) {return s->hal.lock ? s->hal.lock(s->hal.context):0;}
static void unlock(radio_pcm_engine *s,uint32_t token) {if(s->hal.unlock)s->hal.unlock(s->hal.context,token);}
static unsigned count(const radio_pcm_queue *q) {return (q->head+RADIO_PCM_QUEUE-q->tail)%RADIO_PCM_QUEUE;}
unsigned radio_pcm_engine_tx_credit(const radio_pcm_engine *s) {
    return s->config.operations==RADIO_PCM_TX ? RADIO_PCM_CAPACITY-count(&s->tx):0u;
}
static void ack_locked(radio_pcm_engine *s,unsigned type,uint32_t sequence) {
    s->ack_sequence[type]=sequence;s->pending|=(uint16_t)(1u<<type);
}
static void report(radio_pcm_engine *s,radio_pcm_error error) {
    uint32_t token=lock(s);++s->bad_frames;s->pending_error=error;s->pending|=1u<<RADIO_PCM_ERROR;unlock(s,token);
}
static void fault(radio_pcm_engine *s,radio_pcm_error error) {
    uint32_t token=lock(s);bool tx=s->tx_started;
    s->tx_started=false;s->rx_started=false;s->state=RADIO_PCM_FAULT;s->error=error;
    s->tx.head=s->tx.tail=0;s->stop_all_pending=true;s->pending_error=error;
    s->pending|=1u<<RADIO_PCM_ERROR;unlock(s,token);
    if(tx && s->hal.stop_tx)s->hal.stop_tx(s->hal.context);
}
void radio_pcm_engine_abort(radio_pcm_engine *s,radio_pcm_error error) {
    fault(s,error==RADIO_PCM_OK ? RADIO_PCM_HAL:error);
}
void radio_pcm_engine_init(radio_pcm_engine *s,const radio_pcm_hal *hal) {
    memset(s,0,sizeof *s);if(hal)s->hal=*hal;s->state=RADIO_PCM_CLOSED;
}
static bool config_valid(const radio_pcm_config *c) {
    return c && c->session && c->mode<=RADIO_PCM_VOICE &&
        (c->operations==RADIO_PCM_RX || c->operations==RADIO_PCM_TX) &&
        c->modulation<=RADIO_PCM_DMR &&
        (c->mode==RADIO_PCM_VOICE || c->modulation<=RADIO_PCM_NFM) &&
        c->tot_ms<=3600000u;
}
bool radio_pcm_engine_open(radio_pcm_engine *s,const radio_pcm_config *config,uint32_t now) {
    if(!config_valid(config) || (!!s->hal.lock != !!s->hal.unlock)
       || (s->state!=RADIO_PCM_CLOSED && s->state!=RADIO_PCM_STOPPED)
       || s->stop_all_pending || s->output_used!=s->output_sent || s->pending)return false;
    radio_pcm_hal hal=s->hal;radio_pcm_engine_init(s,&hal);s->config=*config;
    s->opened_ms=s->last_data_ms=now;s->state=RADIO_PCM_READY;
    s->pending=HELLO_PENDING;ack_locked(s,RADIO_PCM_HELLO,0);return true;
}
void radio_pcm_engine_stop(radio_pcm_engine *s) {
    uint32_t token=lock(s);bool tx=s->tx_started;
    s->tx_started=false;s->rx_started=false;s->state=RADIO_PCM_STOPPED;
    s->tx.head=s->tx.tail=0;s->stop_all_pending=true;
    // Unsent queued PCM can be replaced by the stop ACK. A partially sent
    // COBS frame must finish to preserve the receiver's framing boundary.
    if(!s->output_sent)s->output_used=0;
    s->pending=0;ack_locked(s,RADIO_PCM_STOP,0);unlock(s,token);
    if(tx && s->hal.stop_tx)s->hal.stop_tx(s->hal.context);
}
bool radio_pcm_engine_tx_finish(radio_pcm_engine *s) {
    uint32_t token=lock(s);
    bool ok=s->state==RADIO_PCM_DRAINING && s->end_received && s->tx_started && !count(&s->tx);
    if(ok) {s->tx_started=false;s->state=RADIO_PCM_STOPPED;s->stop_all_pending=true;
        ack_locked(s,RADIO_PCM_END,s->next_tx_sequence);}
    unlock(s,token);if(ok && s->hal.stop_tx)s->hal.stop_tx(s->hal.context);return ok;
}
bool radio_pcm_engine_tx_eof(const radio_pcm_engine *s) {
    return s->config.operations==RADIO_PCM_TX && s->end_received && !count(&s->tx);
}
bool radio_pcm_engine_tx_pop(radio_pcm_engine *s,int16_t pcm[160]) {
    uint32_t token=lock(s);
    if(!pcm || !s->tx_started || (s->state!=RADIO_PCM_RUNNING && s->state!=RADIO_PCM_DRAINING)) {
        unlock(s,token);return false;
    }
    if(!count(&s->tx)) {
        bool end=s->end_received;if(!end)++s->underruns;unlock(s,token);
        if(!end)fault(s,RADIO_PCM_UNDERRUN);
        return false;
    }
    memcpy(pcm,s->tx.pcm[s->tx.tail],RADIO_PCM_PAYLOAD);
    s->tx.tail=(uint8_t)((s->tx.tail+1u)%RADIO_PCM_QUEUE);++s->tx_frames;
    ack_locked(s,RADIO_PCM_DATA,s->next_tx_sequence-1u);unlock(s,token);return true;
}
bool radio_pcm_engine_rx_push(radio_pcm_engine *s,const int16_t pcm[160],uint32_t now) {
    uint32_t token=lock(s);
    if(!pcm || !s->rx_started || s->state!=RADIO_PCM_RUNNING || s->config.operations!=RADIO_PCM_RX) {
        unlock(s,token);return false;
    }
    uint32_t seq=s->rx_next_sequence++,index=s->rx_next_index;s->rx_next_index+=RADIO_PCM_SAMPLES;
    ++s->rx_frames;s->last_rx_ms=now;
    uint8_t next=(uint8_t)((s->rx.head+1u)%RADIO_PCM_QUEUE);
    if(next==s->rx.tail) {++s->dropped;unlock(s,token);return false;}
    memcpy(s->rx.pcm[s->rx.head],pcm,RADIO_PCM_PAYLOAD);
    s->rx_sequence[s->rx.head]=seq;s->rx_index[s->rx.head]=index;
    __asm__ volatile("" ::: "memory");s->rx.head=next;unlock(s,token);return true;
}
static size_t cobs_decode(uint8_t *p,size_t n) {
    size_t r=0,w=0;
    while(r<n) {
        unsigned code=p[r++];if(!code || (size_t)(code-1u)>n-r)return 0;
        for(unsigned i=1;i<code;++i)p[w++]=p[r++];
        if(code!=255u && r<n)p[w++]=0;
    }
    return w;
}
static size_t cobs_encode(const uint8_t *src,size_t n,uint8_t *out) {
    size_t w=1,code_at=0;unsigned code=1;
    for(size_t i=0;i<n;++i) {
        if(!src[i]) {out[code_at]=(uint8_t)code;code_at=w++;code=1;}
        else {out[w++]=src[i];if(++code==255u) {out[code_at]=(uint8_t)code;code_at=w++;code=1;}}
    }
    out[code_at]=(uint8_t)code;out[w++]=0;return w;
}
static void start(radio_pcm_engine *s,const uint8_t *p,uint32_t seq,uint32_t now) {
    uint32_t tot=rd32(p+4);
    if(p[0]!=s->config.mode || p[1]!=s->config.operations || p[2]!=s->config.modulation || p[3]
       || (tot && tot!=s->config.tot_ms)) {report(s,RADIO_PCM_BAD_CONFIG);return;}
    uint32_t token=lock(s);
    if(s->state==RADIO_PCM_RUNNING) {ack_locked(s,RADIO_PCM_START,seq);unlock(s,token);return;}
    if(s->state!=RADIO_PCM_READY || (s->config.operations==RADIO_PCM_TX && count(&s->tx)<RADIO_PCM_PREFILL)) {
        unlock(s,token);report(s,RADIO_PCM_BAD_CONFIG);return;
    }
    bool tx=s->config.operations==RADIO_PCM_TX;s->state=RADIO_PCM_RUNNING;
    s->started_ms=s->last_data_ms=now;s->tx_started=tx;s->rx_started=!tx;
    unlock(s,token);
    bool ok=tx ? s->hal.start_tx && s->hal.start_tx(s->hal.context,&s->config):
        s->hal.start_rx && s->hal.start_rx(s->hal.context,&s->config);
    if(!ok) {fault(s,RADIO_PCM_POLICY);return;}
    token=lock(s);if(s->state==RADIO_PCM_RUNNING)ack_locked(s,RADIO_PCM_START,seq);unlock(s,token);
}
static void packet(radio_pcm_engine *s,size_t n,uint32_t now) {
    uint8_t *p=s->input;
    if(n<RADIO_PCM_HEADER || p[0]!='D' || p[1]!='P' || p[2]!=1u || p[3]<RADIO_PCM_HELLO
       || p[3]>RADIO_PCM_ERROR || rd16(p+4) || rd16(p+6)!=n-RADIO_PCM_HEADER) {
        report(s,RADIO_PCM_BAD_FRAME);return;
    }
    uint32_t crc=crc_part(UINT32_MAX,p,20);crc=~crc_part(crc,p+24,n-24);
    if(crc!=rd32(p+20)) {report(s,RADIO_PCM_BAD_CRC);return;}
    if(rd32(p+8)!=s->config.session || s->state==RADIO_PCM_CLOSED) {report(s,RADIO_PCM_BAD_SESSION);return;}
    unsigned type=p[3];uint32_t seq=rd32(p+12),index=rd32(p+16);size_t bytes=n-24;
    if(type==RADIO_PCM_STOP && !bytes) {radio_pcm_engine_stop(s);s->ack_sequence[RADIO_PCM_STOP]=seq;return;}
    if(type==RADIO_PCM_HELLO && !bytes) {
        uint32_t token=lock(s);s->pending|=HELLO_PENDING;ack_locked(s,RADIO_PCM_HELLO,seq);unlock(s,token);return;
    }
    if(type==RADIO_PCM_STATUS && !bytes) {
        uint32_t token=lock(s);ack_locked(s,RADIO_PCM_STATUS,seq);unlock(s,token);return;
    }
    if(type==RADIO_PCM_START && bytes==8u && !index) {start(s,p+24,seq,now);return;}
    if(type==RADIO_PCM_DATA && bytes==RADIO_PCM_PAYLOAD && s->config.operations==RADIO_PCM_TX) {
        uint32_t token=lock(s);
        radio_pcm_error error=RADIO_PCM_OK;
        if(s->state!=RADIO_PCM_READY && s->state!=RADIO_PCM_RUNNING)error=RADIO_PCM_BAD_CONFIG;
        else if(s->end_received || seq!=s->next_tx_sequence || index!=seq*RADIO_PCM_SAMPLES)error=RADIO_PCM_BAD_SEQUENCE;
        else if(count(&s->tx)==RADIO_PCM_CAPACITY)error=RADIO_PCM_FULL;
        if(error!=RADIO_PCM_OK) {unlock(s,token);report(s,error);return;}
        for(unsigned i=0;i<RADIO_PCM_SAMPLES;++i)s->tx.pcm[s->tx.head][i]=(int16_t)rd16(p+24+2u*i);
        __asm__ volatile("" ::: "memory");s->tx.head=(uint8_t)((s->tx.head+1u)%RADIO_PCM_QUEUE);
        ++s->next_tx_sequence;s->last_data_ms=now;ack_locked(s,RADIO_PCM_DATA,seq);unlock(s,token);return;
    }
    if(type==RADIO_PCM_END && !bytes && s->config.operations==RADIO_PCM_TX) {
        uint32_t token=lock(s);
        bool ok=s->state==RADIO_PCM_RUNNING && seq==s->next_tx_sequence && index==seq*RADIO_PCM_SAMPLES;
        if(ok) {s->end_received=true;s->end_ms=now;s->state=RADIO_PCM_DRAINING;}
        else if(s->end_received && seq==s->next_tx_sequence && index==seq*RADIO_PCM_SAMPLES) {
            if(s->state==RADIO_PCM_STOPPED)ack_locked(s,RADIO_PCM_END,seq);
            if(s->state==RADIO_PCM_DRAINING || s->state==RADIO_PCM_STOPPED)ok=true;
        }
        unlock(s,token);if(!ok)report(s,RADIO_PCM_BAD_SEQUENCE);return;
    }
    report(s,RADIO_PCM_BAD_FRAME);
}
void radio_pcm_engine_feed(radio_pcm_engine *s,const uint8_t *bytes,size_t n,uint32_t now) {
    if(!bytes)return;
    while(n--) {
        uint8_t b=*bytes++;
        if(!b) {
            if(!s->input_discard && s->input_used) {
                size_t size=cobs_decode(s->input,s->input_used);
                if(size)packet(s,size,now);else report(s,RADIO_PCM_BAD_FRAME);
            }
            s->input_used=0;s->input_discard=false;
        } else if(!s->input_discard) {
            if(s->input_used>=sizeof s->input-1u) {s->input_discard=true;s->input_used=0;report(s,RADIO_PCM_BAD_FRAME);}
            else s->input[s->input_used++]=b;
        }
    }
}
static bool prepare_output(radio_pcm_engine *s) {
    uint8_t raw[RADIO_PCM_PACKET]={0};unsigned type=0,acked=0;size_t bytes=0;
    uint32_t seq=0,index=0;uint16_t flags=0;
    uint32_t token=lock(s);uint16_t pending=s->pending;
    if(pending&(1u<<RADIO_PCM_ERROR)) {type=RADIO_PCM_ERROR;acked=RADIO_PCM_ERROR;flags=(uint16_t)s->pending_error;}
    else if(pending&(1u<<RADIO_PCM_STOP)) {type=RADIO_PCM_ACK;acked=RADIO_PCM_STOP;}
    else if(pending&(1u<<RADIO_PCM_END)) {type=RADIO_PCM_ACK;acked=RADIO_PCM_END;}
    else if(pending&HELLO_PENDING) {
        type=RADIO_PCM_HELLO;bytes=16;s->pending&=(uint16_t)~HELLO_PENDING;
        wr32(raw+24,8000);wr16(raw+28,RADIO_PCM_SAMPLES);wr16(raw+30,RADIO_PCM_CAPACITY);
        wr16(raw+32,RADIO_PCM_PAYLOAD);raw[34]=s->config.modulation;
        raw[35]=(uint8_t)(s->config.modulation<=RADIO_PCM_NFM ? 3u:2u);
    } else {
        for(unsigned i=RADIO_PCM_HELLO;i<=RADIO_PCM_STATUS;++i)if(pending&(1u<<i)) {
            type=i==RADIO_PCM_STATUS ? RADIO_PCM_STATUS:RADIO_PCM_ACK;acked=i;break;
        }
    }
    if(acked) {
        s->pending&=(uint16_t)~(1u<<acked);seq=s->ack_sequence[acked];index=s->next_tx_sequence*RADIO_PCM_SAMPLES;
        bytes=24;raw[24]=(uint8_t)acked;raw[25]=(uint8_t)s->state;
        wr16(raw+26,(uint16_t)radio_pcm_engine_tx_credit(s));wr32(raw+28,s->rx_frames);
        wr32(raw+32,s->tx_frames);wr32(raw+36,s->dropped);wr32(raw+40,s->underruns);wr32(raw+44,s->next_tx_sequence);
    }
    if(!type && s->config.operations==RADIO_PCM_RX && count(&s->rx)) {
        type=RADIO_PCM_DATA;bytes=RADIO_PCM_PAYLOAD;
        unsigned tail=s->rx.tail;seq=s->rx_sequence[tail];index=s->rx_index[tail];
        // A sequence discontinuity exposes every dropped capture block.
        flags=seq!=s->rx_output_next_sequence ? GAP_FLAG:0u;s->rx_output_next_sequence=seq+1u;
        for(unsigned i=0;i<RADIO_PCM_SAMPLES;++i)wr16(raw+24+2u*i,(uint16_t)s->rx.pcm[tail][i]);
        s->rx.tail=(uint8_t)((tail+1u)%RADIO_PCM_QUEUE);
    }
    unlock(s,token);if(!type)return false;
    raw[0]='D';raw[1]='P';raw[2]=1;raw[3]=(uint8_t)type;wr16(raw+4,flags);wr16(raw+6,(uint16_t)bytes);
    wr32(raw+8,s->config.session);wr32(raw+12,seq);wr32(raw+16,index);
    uint32_t crc=crc_part(UINT32_MAX,raw,20);wr32(raw+20,~crc_part(crc,raw+24,bytes));
    s->output_used=(uint16_t)cobs_encode(raw,24+bytes,s->output);s->output_sent=0;return true;
}
void radio_pcm_engine_poll(radio_pcm_engine *s,uint32_t now,size_t budget) {
    if(s->tx_started) {
        // A credit-limited host cannot send while native DMR is still waiting
        // for repeater access and the queue is full. Start its producer grace
        // period only when space becomes available; RF/TOT remain independent.
        uint32_t held=lock(s);
        if(s->state==RADIO_PCM_RUNNING && count(&s->tx)==RADIO_PCM_CAPACITY)s->last_data_ms=now;
        unlock(s,held);
        if(s->config.tot_ms && now-s->started_ms>=s->config.tot_ms)fault(s,RADIO_PCM_TOT);
        else if(s->state==RADIO_PCM_DRAINING) {
            if(now-s->end_ms>=RADIO_PCM_DRAIN_TIMEOUT_MS)fault(s,RADIO_PCM_TIMEOUT);
        } else if(now-s->last_data_ms>=RADIO_PCM_TIMEOUT_MS)fault(s,RADIO_PCM_TIMEOUT);
    }
    uint32_t token=lock(s);bool stop=s->stop_all_pending;s->stop_all_pending=false;unlock(s,token);
    if(stop && s->hal.stop_all)s->hal.stop_all(s->hal.context);
    if(budget>RADIO_PCM_WRITE_BUDGET)budget=RADIO_PCM_WRITE_BUDGET;
    if(!budget || !s->hal.write)return;
    if(s->output_sent==s->output_used && !prepare_output(s))return;
    size_t n=s->output_used-s->output_sent;if(n>budget)n=budget;
    size_t wrote=s->hal.write(s->hal.context,s->output+s->output_sent,n);
    if(wrote>n) {fault(s,RADIO_PCM_HAL);return;}
    s->output_sent=(uint16_t)(s->output_sent+wrote);
}
bool radio_pcm_engine_output_idle(const radio_pcm_engine *s) {
    return s->output_sent==s->output_used && !s->pending &&
        (s->config.operations!=RADIO_PCM_RX || !count(&s->rx));
}
