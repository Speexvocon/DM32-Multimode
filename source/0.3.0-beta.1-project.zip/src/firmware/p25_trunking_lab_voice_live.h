// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit one-use laboratory grant/voice handoff. No automatic subscriber.
#ifndef P25_TRUNKING_LAB_VOICE_LIVE_H
#define P25_TRUNKING_LAB_VOICE_LIVE_H
#include "p25_trunking_lab_voice.h"

static p25_lab_voice trunk_lab_voice;
static struct {
    uint32_t rf_irq_us,published,consumed,blocks,underruns,timing;
    uint32_t captured,encoded,overflow,driver_loss;
    bool cleaning,full_rx;
    volatile bool ptt_down;
} trunk_lab_voice_io;
_Static_assert(sizeof trunk_lab_voice_io<=44u,"Finite voice trace exceeds its compact budget");

static bool trunk_lab_voice_owned(void) {
    // ARMED/GRANTED belong to the existing request/reply observer. Only a
    // spent action may take over the transmit queue and subsequent RX return.
    return trunk_lab_voice.needs_rf_off || (trunk_lab_voice.phase>=P25_LAB_VOICE_TAKEN
        && trunk_lab_voice.phase<=P25_LAB_VOICE_RETURN);
}
static bool trunk_lab_voice_preserve(void) {
    return trunk_lab_voice_io.cleaning || trunk_lab_voice_owned();
}
static bool trunk_lab_voice_prepare(uint8_t mode) {
    uint32_t lock=hrc_irq_save();
    bool okay=mode<=TRUNK_PRELOAD_VOICE_MIC
        && p25_lab_voice_arm(&trunk_lab_voice,mode!=TRUNK_PRELOAD_VOICE_OFF,&trunk_lab_exchange);
    if(okay)memset(&trunk_lab_voice_io,0,sizeof trunk_lab_voice_io);
    hrc_irq_restore(lock);return okay;
}
static void trunk_lab_voice_snapshot(void) {
    trunk_lab_voice_io.published=live.published;trunk_lab_voice_io.consumed=live.consumed;
    trunk_lab_voice_io.blocks=live.timing.blocks;trunk_lab_voice_io.underruns=live.underruns;
    trunk_lab_voice_io.timing=(uint32_t)live.timing.state;
    trunk_lab_voice_io.captured=pcmq.captured;trunk_lab_voice_io.encoded=encoded;
    trunk_lab_voice_io.overflow=pcmq.overflow;trunk_lab_voice_io.driver_loss=driver_loss;
}
static void trunk_lab_voice_release_tx(void) {
    // Shared cleanup must not invalidate the immutable grant while its queue
    // and board TX ownership are deliberately released for the control return.
    trunk_lab_voice_io.cleaning=true;cleanup();trunk_lab_voice_io.cleaning=false;
}
static void trunk_lab_voice_cancel(void) {
    uint32_t lock=hrc_irq_save();
    bool owned=trunk_lab_voice_owned();
    bool action=p25_lab_voice_owned(&trunk_lab_voice);
    if(action)trunk_lab_ptt_voice_cancelled();
    if(action) {ptt_release_required=true;ptt_release_seen=false;}
    p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_CANCEL);
    if(owned) {
        stop_call("cancelled",false);trunk_lab_voice_snapshot();
    }
    hrc_irq_restore(lock);
    if(owned) {
        if(mon_running)mon_stop("lab_voice_cancelled");
        trunk_lab_voice_release_tx();lock=hrc_irq_save();
        (void)p25_lab_voice_abort_off(&trunk_lab_voice,!hardware_running && !call_active && !prepared,hrc_micros());
        hrc_irq_restore(lock);
    }
    // Explicit STOP/input/profile cancellation does not manufacture a fresh
    // receive observation, nor start RX behind a STOP command.
    if(action)trunk_lab_voice_io.full_rx=false;
}
static void trunk_lab_voice_irq_abort(p25_lab_voice_reason why) {
    p25_lab_voice_cancel(&trunk_lab_voice,why);
    ptt_release_required=true;ptt_release_seen=false;
    stop_call("cancelled",false); // Immediate RF-safe; task releases board TX.
}
static bool trunk_lab_voice_irq_permission(void) {
    if(!trunk_lab_voice_owned())return true;
    uint32_t now=hrc_micros();p25_lab_voice_poll(&trunk_lab_voice,now);
    // No battery ADC, calibration reads, input-matrix scan, UART or tuning in
    // this IRQ predicate. Those checks run before setup and each task poll.
    bool ptt_okay=trunk_lab_ptt_selected()
        ? trunk_lab_ptt_voice_held(trunk_lab_voice.phase==P25_LAB_VOICE_TAKEN)
        : !trunk_lab_voice_io.ptt_down && hrc_pin_read(PIN_PTT);
    bool okay=trunk_lab_voice.needs_rf_off && ptt_okay && trunk_lab_return_identity()
        && !control.inhibit && !trunk_probe.active && !message_packet_tx
        && prepared && call_active && hardware_running
        && (trunk_lab_voice.phase==P25_LAB_VOICE_TAKEN
            || trunk_lab_voice.phase==P25_LAB_VOICE_VOICE || trunk_lab_voice.phase==P25_LAB_VOICE_DRAIN);
    if(!okay)trunk_lab_voice_irq_abort(P25_LAB_VOICE_PERMISSION);
    return okay;
}
static bool trunk_lab_voice_rf_started(void) {
    if(!p25_lab_voice_key_allowed(&trunk_lab_voice,hrc_micros())) {
        trunk_lab_voice_irq_abort(P25_LAB_VOICE_LEASE);return false;
    }
    trunk_lab_voice_io.rf_irq_us=hrc_micros();return true;
}
static bool trunk_lab_voice_pa_started(void) {
    if(trunk_lab_voice.phase==P25_LAB_VOICE_VOICE || trunk_lab_voice.phase==P25_LAB_VOICE_DRAIN)
        return false; // A stale PA IRQ cannot repeat the key operation.
    if(!p25_lab_voice_key_allowed(&trunk_lab_voice,hrc_micros())
       || !p25_lab_voice_rf_started(&trunk_lab_voice,hrc_micros()) || !trunk_lab_ptt_pa_started()) {
        trunk_lab_voice_irq_abort(P25_LAB_VOICE_LEASE);return false;
    }
    return true;
}
static bool trunk_lab_voice_start_rf(void) {
    uint32_t lock=hrc_irq_save(),now=hrc_micros();
    uint32_t elapsed=now-trunk_lab_voice.start_us;
    unsigned seconds=elapsed<P25_LAB_VOICE_RF_MAX_US
        ? (P25_LAB_VOICE_RF_MAX_US-elapsed)/1000000u : 0u;
    bool ptt_okay=trunk_lab_ptt_selected() ? trunk_lab_ptt_voice_held(true)
        : !trunk_lab_voice_io.ptt_down && hrc_pin_read(PIN_PTT);
    bool okay=trunk_lab_return_identity() && !control.inhibit && ptt_okay
        && p25_lab_voice_key_allowed(&trunk_lab_voice,now)
        && call_active && prepared && !hardware_running && !trunk_probe.active
        && live.count>=2u && seconds && p25_live_tx_start(&live,now) && hard_guard_arm(seconds);
    if(!okay) {hardware_stop();hrc_irq_restore(lock);return false;}
    // The integer guard is rounded DOWN from the remaining six-second lease.
    // Setup time can shorten the RF window, never extend its original bound.
    tx_write_half=1u;
    if(tx_dac_restore)hrc_dac_b_power(true);
    tx_dac.pre_rf=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PRE_RF;
    for(unsigned i=0;i<72u;++i)dev->buf[i]=0x77;
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);
    wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    wr(C7_SYS_INTERP_MASK,PHY_READY);
    hardware_running=true;pa_started=false;control.state=RADIO_TX_VOICE;
    hrc_irq_enable(IRQ_MODEM_SYS,true);hrc_irq_enable(IRQ_MODEM_TS_TX,true);hrc_irq_enable(IRQ_MODEM_TS_RX,true);
    hrc_irq_enable(IRQ_MODEM_RF_TX,true);hrc_irq_enable(IRQ_MODEM_RF_RX,true);
    wr(C7_LAYER2_CONTROL,0x82);hrc_irq_restore(lock);return true;
}
static bool trunk_lab_voice_return(void) {
    uint32_t lock=hrc_irq_save();
    trunk_lab_voice_snapshot();
    unsigned mic_target=trunk_lab_ptt_mic_target();
    unsigned expected_ldus=trunk_lab_ptt_selected()
        ? P25_LAB_VOICE_QUIET_LDUS+mic_target/9u:P25_LAB_VOICE_LDUS;
    bool success=live.timing.state==P25_TX_DONE && live.finished && !live.underruns
        && live.published==expected_ldus && live.consumed==expected_ldus;
    if(trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_MIC)
        success=success && (trunk_lab_ptt_selected() ? pcmq.captured<=mic_target
                : pcmq.captured==P25_LAB_VOICE_MIC_FRAMES)
            && encoded==mic_target && !pcmq.overflow && !driver_loss && !audio_on;
    // The generic engine can already be DONE when a delayed task records the
    // separate policy's drain. Its DONE evidence records that complete drain,
    // but cannot substitute for the separately observed PA transition (VOICE).
    if(success && trunk_lab_voice.phase==P25_LAB_VOICE_VOICE)
        (void)p25_lab_voice_drain(&trunk_lab_voice,hrc_micros());
    hardware_stop();call_active=false;pcmq.accepting=false;
    (void)p25_lab_voice_tx_done(&trunk_lab_voice,success,!hardware_running,hrc_micros());
    trunk_lab_ptt_voice_done(success);
    hrc_irq_restore(lock);
    reason=success ? "complete":"cancelled";trunk_lab_voice_release_tx();
    ptt_release_required=true;ptt_release_seen=false;
    if(trunk_lab_voice.phase!=P25_LAB_VOICE_RETURN || !trunk_lab_return_rf_off()) {
        trunk_lab_voice_cancel();return true;
    }
    mon_stop("lab_voice_return");
    mon_enabled=true;
    if(!mon_start()) {
        lock=hrc_irq_save();
        p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_TRANSPORT);
        (void)p25_lab_voice_abort_off(&trunk_lab_voice,true,hrc_micros());
        hrc_irq_restore(lock);
        mon_enabled=false;radio_complete(&control,true);radio_inhibit(&control,true);board_rf_safe();return true;
    }
    trunk_lab_stages.resume_epoch=trunk_stream_epoch;trunk_lab_stages.resume_us=hrc_micros();
    return true; // The old raw epoch must not be processed after this retune.
}
static bool trunk_lab_voice_mic_prime(void) {
    // The ordinary cold microphone waits360ms for two LDUs, exceeding this
    // grant's250ms key lease. Encode one actual zero-PCM frame before keying,
    // repeat its valid compressed word into a quiet pair, then stream live
    // microphone data behind it. No all-zero compressed payload or tone is
    // substituted, and slow initialization still expires the original lease.
    if(!imbe_bench_init())return false;
    int16_t quiet[160]={0};uint8_t ldu[216];
    uint32_t start=hrc_micros();imbe_bench_encode_pcm(quiet,payload[0]);
    if(!imbe_bench_ready())return false;
    max_encode=hrc_micros()-start;
    for(unsigned i=1;i<9u;++i)memcpy(payload[i],payload[0],sizeof payload[i]);
    for(unsigned i=0;i<P25_LAB_VOICE_QUIET_LDUS;++i) {
        start=hrc_micros();
        p25_live_ldu_template(ldu,(const uint8_t (*)[11])payload,
            i ? call_frames.ldu2:call_frames.ldu1);
        uint32_t elapsed=hrc_micros()-start;if(elapsed>max_pack)max_pack=elapsed;
        uint32_t lock=hrc_irq_save();
        bool okay=p25_live_tx_push(&live,ldu);
        hrc_irq_restore(lock);if(!okay)return false;
    }
    return true;
}
static bool trunk_lab_voice_mic_poll(void) {
    uint32_t blocks,under;hrc_audio_pcm_stats(&blocks,&driver_loss,&under);
    (void)blocks;(void)under;
    uint32_t lock=hrc_irq_save(),now=hrc_micros();
    bool accepting=pcmq.accepting;
    bool released=trunk_lab_ptt_released_voice();unsigned limit=trunk_lab_ptt_mic_target();
    bool okay=!driver_loss && !pcmq.overflow && imbe_bench_ready()
        && pcmq.captured<=P25_LAB_VOICE_MIC_FRAMES && encoded<=limit
        && (accepting || pcmq.captured==P25_LAB_VOICE_MIC_FRAMES || released)
        && (!accepting || now-last_pcm<200000u);
    int16_t pcm[160];bool have=okay && mic_queue_pop(&pcmq,pcm);
    bool padding=okay && !have && released && encoded<limit;
    if(padding) {memset(pcm,0,sizeof pcm);have=true;}
    hrc_irq_restore(lock);
    if(!okay)return false;
    if(!accepting)audio_stop();
    if(have) {
        if(encoded>=limit)return false;
        uint32_t start=hrc_micros();imbe_bench_encode_pcm(pcm,payload[encoded%9u]);
        if(!imbe_bench_ready())return false;
        uint32_t elapsed=hrc_micros()-start;if(elapsed>max_encode)max_encode=elapsed;
        for(unsigned i=0;i<11u;++i)payload_hash=(payload_hash^payload[encoded%9u][i])*16777619u;
        ++encoded;
        if(padding)trunk_lab_ptt_note_padding();
        if(encoded%9u==0u) {
            uint8_t ldu[216];start=hrc_micros();
            p25_live_ldu_template(ldu,(const uint8_t (*)[11])payload,
                ((encoded/9u)&1u) ? call_frames.ldu1:call_frames.ldu2);
            elapsed=hrc_micros()-start;if(elapsed>max_pack)max_pack=elapsed;
            lock=hrc_irq_save();
            if(okay)okay=call_active && hardware_running && p25_live_tx_push(&live,ldu);
            if(okay && encoded==limit)okay=p25_live_tx_finish(&live);
            hrc_irq_restore(lock);
        }
    }
    if(okay && released && encoded==limit && !live.finished) {
        lock=hrc_irq_save();okay=p25_live_tx_finish(&live);hrc_irq_restore(lock);
    }
    return okay;
}
static bool trunk_lab_voice_begin(void) {
    if(!trunk_preload.voice_enabled || trunk_lab_voice.phase!=P25_LAB_VOICE_ARMED)return false;
    uint32_t now=hrc_micros(),lock=hrc_irq_save();
    if(!p25_lab_voice_offer(&trunk_lab_voice,&trunk_lab_exchange,now)) {
        p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_CONFIG);hrc_irq_restore(lock);return false;
    }
    hrc_irq_restore(lock);
    p25_lab_exchange_owner owner=trunk_lab_return_owner();
    bool permission=trunk_lab_return_identity() && !control.inhibit && trunk_preload_warm_health()
        && board.power->switch_on();
    bool ptt_permitted=trunk_preload_task_ptt_released(false) || trunk_lab_ptt_voice_held(true);
    lock=hrc_irq_save();
    bool taken=p25_lab_voice_take(&trunk_lab_voice,&trunk_lab_exchange,&owner,trunk_stream_epoch,
        permission,ptt_permitted,trunk_lab_return_rf_off(),now);
    hrc_irq_restore(lock);if(!taken)return false;
    const p25_trunking_lab_profile *profile=p25_trunking_lab_get(trunk_lab_voice.owner.profile);
    trunk_lab_voice_io.ptt_down=false;
    if(!profile || !channel_in_band(profile->voice_tx_hz,true)
       || !p25_channel_build_group_options(&call_frames,trunk_lab_voice.owner.nac,trunk_lab_voice.owner.group,
            trunk_lab_voice.owner.radio_id,trunk_lab_voice.owner.expected_options)
       || !prepare_p25_tx_at(false,profile->voice_tx_hz)) {
        p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_TRANSPORT);return trunk_lab_voice_return();
    }
    p25_live_tx_init(&live);memcpy(live.hdu,call_frames.hdu,sizeof live.hdu);memcpy(live.tdu,call_frames.tdu,sizeof live.tdu);
    memset(&pcmq,0,sizeof pcmq);memset(payload,0,sizeof payload);message_packet_tx=false;
    encoded=target=max_encode=max_pack=driver_loss=rf_audio=0;payload_hash=2166136261u;
    if(!p25_live_tx_set_startup_extra(&live,tx_startup_extra)
       || !p25_live_tx_set_rf_limit(&live,P25_LAB_VOICE_RF_MAX_US)) {
        p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_TRANSPORT);return trunk_lab_voice_return();
    }
    bool microphone=trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_MIC;
    bool okay=true;
    if(microphone)okay=trunk_lab_voice_mic_prime();
    else {
        lock=hrc_irq_save();
        for(unsigned i=0;i<LIVE_BANKS && okay;++i)okay=p25_live_tx_push(&live,(i&1u) ? call_frames.ldu2:call_frames.ldu1);
        hrc_irq_restore(lock);
    }
    call_active=true;capture_started=last_pcm=hrc_micros();reason=microphone ? "lab_voice_mic":"lab_voice";
    control.state=RADIO_TX_PREPARE;call_tot_expired=false;
    if(okay && microphone) {
        call_capture_frames=P25_LAB_VOICE_MIC_FRAMES;call_soft_limit_us=P25_LAB_VOICE_RF_MAX_US;
        hrc_audio_pcm_reset_stats();pcmq.accepting=true;
        hrc7000_set_mic_gain(dev,(uint8_t)mic_gain_db);
        audio_on=board.audio->start(capture,NULL);okay=audio_on;
        pcm_mode=hrc7000_rd(dev,C7_WORK_MODE);pcm_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
    }
    if(!okay || (!trunk_preload_task_ptt_released(false) && !trunk_lab_ptt_voice_held(true)) || !trunk_preload_warm_health()
       || !trunk_lab_voice_start_rf()) {
        p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_TRANSPORT);return trunk_lab_voice_return();
    }
    return true;
}
static bool trunk_lab_voice_poll(bool down) {
    trunk_lab_voice_io.ptt_down=!trunk_preload_task_ptt_released(down);
    if(!trunk_lab_voice_owned())return false;
    bool ptt_okay=trunk_lab_ptt_selected()
        ? trunk_lab_ptt_voice_held(trunk_lab_voice.phase==P25_LAB_VOICE_TAKEN) : !trunk_lab_voice_io.ptt_down;
    if(!ptt_okay || !trunk_lab_return_identity() || control.inhibit
       || !trunk_preload_warm_health()) {trunk_lab_voice_cancel();return true;}
    uint32_t lock=hrc_irq_save();p25_lab_voice_poll(&trunk_lab_voice,hrc_micros());hrc_irq_restore(lock);
    if(!trunk_lab_voice_owned())return true;
    if(trunk_lab_voice.phase==P25_LAB_VOICE_RETURN) {
        if(!mon_running || mon_failed || mon_control_only || receiver_frequency()!=trunk_lab_voice.owner.control_rx_hz) {
            trunk_lab_voice_cancel();return true;
        }
        lock=hrc_irq_save();
        if(monitor.raw_blocks && p25_lab_voice_return_ready(&trunk_lab_voice,trunk_stream_epoch,true,
            trunk_lab_return_rf_off(),hrc_micros())) {
            trunk_lab_voice_io.full_rx=true;trunk_lab_ptt_return_ready();
        }
        hrc_irq_restore(lock);
        if(!trunk_lab_voice_owned())return true;
        return false; // Ordinary monitor supplies the first fresh raw block.
    }
    if(!call_active || !hardware_running || !p25_test_tx_active(&live.timing)
       || (trunk_lab_voice.phase!=P25_LAB_VOICE_TAKEN && trunk_lab_voice.phase!=P25_LAB_VOICE_VOICE
           && trunk_lab_voice.phase!=P25_LAB_VOICE_DRAIN))return trunk_lab_voice_return();
    bool microphone=trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_MIC;
    if(microphone && trunk_lab_ptt_selected() && !pcmq.accepting)trunk_lab_ptt_capture_stop();
    bool okay=!microphone || trunk_lab_voice_mic_poll();
    lock=hrc_irq_save();
    // Tone publishes at most one bank/task; MIC consumes at most one existing
    // 20ms PCM block/task. Encoding stays outside the IRQ lock and all IRQs.
    if(!microphone) {
        if(live.published<P25_LAB_VOICE_LDUS && live.count<LIVE_BANKS)
            okay=p25_live_tx_push(&live,(live.published&1u) ? call_frames.ldu2:call_frames.ldu1);
        if(okay && live.published==P25_LAB_VOICE_LDUS && !live.finished)okay=p25_live_tx_finish(&live);
    }
    p25_test_tx_poll_limit(&live.timing,hrc_micros(),true,P25_LAB_VOICE_RF_MAX_US);
    if(live.timing.state==P25_TX_DRAINING)(void)p25_lab_voice_drain(&trunk_lab_voice,hrc_micros());
    bool active=p25_test_tx_active(&live.timing);
    hrc_irq_restore(lock);
    if(!okay) {p25_lab_voice_cancel(&trunk_lab_voice,P25_LAB_VOICE_TRANSPORT);return trunk_lab_voice_return();}
    if(!active)return trunk_lab_voice_return();
    return true;
}
static int trunk_lab_voice_status_row(unsigned row,char *line,size_t capacity) {
    p25_lab_voice value;typeof(trunk_lab_voice_io) io;
    uint32_t lock=hrc_irq_save();value=trunk_lab_voice;io=trunk_lab_voice_io;hrc_irq_restore(lock);
    const p25_trunking_lab_profile *profile=p25_trunking_lab_get(value.owner.profile);
    const char *input=trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_MIC ? "MIC"
        : trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_TONE ? "TONE":"OFF";
    if(row==0u)return snprintf(line,capacity,"TRUNKVOICE configured=%u frozen=%u sequence=%lu phase=%u reason=%u source=%lu group=%u nac=%03x channel=%u options=%u profile=%s control_rx_hz=%lu voice_rx_hz=%lu voice_tx_hz=%lu pairs=10 max_rf_us=6000000 grant_lease_us=250000 lab_only=1 input=%s mic_limit=%u\r\n",
        (unsigned)trunk_preload_config.voice,(unsigned)trunk_preload.voice_enabled,(unsigned long)value.owner.sequence,
        (unsigned)value.phase,(unsigned)value.reason,(unsigned long)value.owner.radio_id,(unsigned)value.owner.group,
        (unsigned)value.owner.nac,(unsigned)value.owner.expected_channel,(unsigned)value.owner.expected_options,
        p25_trunking_lab_name(value.owner.profile),(unsigned long)value.owner.control_rx_hz,
        (unsigned long)(profile ? profile->voice_rx_hz:0u),(unsigned long)(profile ? profile->voice_tx_hz:0u),
        input,(unsigned)(trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_MIC ? P25_LAB_VOICE_MIC_FRAMES:0u));
    if(row==1u)return snprintf(line,capacity,"TRUNKVOICE_END sequence=%lu grant_us=%lu start_us=%lu rf_irq_us=%lu pa_us=%lu end_us=%lu return_us=%lu ready_us=%lu return_epoch=%lu published=%lu consumed=%lu blocks=%lu underruns=%lu timing=%lu full_rx=%u timestamps=software_not_air access=unqualified captured=%u encoded=%u overflow=%u driver_loss=%lu\r\n",
        (unsigned long)value.owner.sequence,(unsigned long)value.grant_us,(unsigned long)value.start_us,
        (unsigned long)io.rf_irq_us,(unsigned long)value.rf_us,(unsigned long)value.end_us,
        (unsigned long)value.return_us,(unsigned long)value.ready_us,(unsigned long)value.return_epoch,
        (unsigned long)io.published,(unsigned long)io.consumed,(unsigned long)io.blocks,(unsigned long)io.underruns,
        (unsigned long)io.timing,(unsigned)io.full_rx,(unsigned)io.captured,(unsigned)io.encoded,
        (unsigned)io.overflow,(unsigned long)io.driver_loss);
    return -1;
}
#endif
