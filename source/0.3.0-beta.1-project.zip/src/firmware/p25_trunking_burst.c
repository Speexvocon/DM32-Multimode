// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_burst.h"
#include <string.h>

bool p25_trunking_burst_plan_make(p25_trunking_burst_plan *out,
                                 const p25_trunking_burst_config *config) {
    if(!out || !config || config->lead_bytes<72u || config->lead_bytes>240u ||
       config->packet_after_rf_us<30000u || config->packet_after_rf_us>220000u ||
       config->pa_lead_us>2000u || config->end_trim_us< -2000 || config->end_trim_us>2000)return false;
    int64_t cut=(int64_t)config->packet_after_rf_us+P25_TRUNK_BURST_NOMINAL_US+config->end_trim_us;
    uint32_t pa=config->packet_after_rf_us-config->pa_lead_us;
    unsigned bytes=((config->lead_bytes+P25_TRUNK_BURST_PREFIX_BYTES+
        P25_TRUNK_BURST_BLOCK_BYTES-1u)/P25_TRUNK_BURST_BLOCK_BYTES)*P25_TRUNK_BURST_BLOCK_BYTES;
    if(cut>260000 || cut<=pa || bytes>P25_TRUNK_BURST_MAX_TRANSPORT_BYTES)return false;
    p25_trunking_burst_plan value={.lead_bytes=config->lead_bytes,
        .valid_bits=P25_TRUNK_BURST_VALID_BITS,.prefix_bytes=P25_TRUNK_BURST_PREFIX_BYTES,
        .transport_bytes=(uint16_t)bytes,.packet_after_rf_us=config->packet_after_rf_us,
        .pa_after_rf_us=pa,.cut_after_rf_us=(uint32_t)cut};
    *out=value;return true;
}
static bool valid_plan(const p25_trunking_burst_plan *plan) {
    if(!plan || plan->pa_after_rf_us>plan->packet_after_rf_us ||
       plan->packet_after_rf_us-plan->pa_after_rf_us>2000u)return false;
    int64_t trim=(int64_t)plan->cut_after_rf_us-plan->packet_after_rf_us-P25_TRUNK_BURST_NOMINAL_US;
    if(trim< -2000 || trim>2000)return false;
    p25_trunking_burst_config config={.lead_bytes=plan->lead_bytes,
        .packet_after_rf_us=plan->packet_after_rf_us,
        .pa_lead_us=(uint16_t)(plan->packet_after_rf_us-plan->pa_after_rf_us),.end_trim_us=(int16_t)trim};
    p25_trunking_burst_plan expected;
    return p25_trunking_burst_plan_make(&expected,&config) &&
        plan->valid_bits==expected.valid_bits && plan->prefix_bytes==expected.prefix_bytes &&
        plan->transport_bytes==expected.transport_bytes;
}
bool p25_trunking_burst_render(const p25_trunking_burst_plan *plan,
                              const uint8_t prefix[P25_TRUNK_BURST_PREFIX_BYTES],
                              unsigned block_index,uint8_t out[P25_TRUNK_BURST_BLOCK_BYTES]) {
    if(!prefix || !out || !valid_plan(plan) ||
       block_index>=plan->transport_bytes/P25_TRUNK_BURST_BLOCK_BYTES)return false;
    uint8_t block[P25_TRUNK_BURST_BLOCK_BYTES];
    for(unsigned i=0;i<sizeof block;++i) {
        unsigned pos=block_index*P25_TRUNK_BURST_BLOCK_BYTES+i;
        block[i]=0x77u;
        if(pos>=plan->lead_bytes) {
            unsigned packet=pos-plan->lead_bytes;
            if(packet<39u)block[i]=prefix[packet];
            else if(packet==39u)block[i]=(uint8_t)((prefix[39]&0xf0u)|7u);
        }
    }
    memcpy(out,block,sizeof block);return true;
}
