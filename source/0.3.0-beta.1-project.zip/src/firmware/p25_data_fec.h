// SPDX-License-Identifier: GPL-3.0-or-later
// CAI coding orientation independently checked against pinned OP25 p25craft.
#ifndef P25_DATA_FEC_H
#define P25_DATA_FEC_H
#include "p25_data.h"
#include <string.h>
static inline unsigned p25_data_get_dibit(const uint8_t *p,unsigned i) {
    return (p[i/4u]>>(6u-2u*(i%4u)))&3u;
}
static inline uint16_t p25_data_crc16(const uint8_t *p,unsigned n) {
    uint16_t c=0;
    for(unsigned i=0;i<n;++i)for(unsigned j=0;j<8;++j) {
        unsigned feedback=((c>>15)^(p[i]>>(7u-j)))&1u;
        c=(uint16_t)(c<<1);if(feedback)c^=0x1021u;
    }
    return (uint16_t)(c^0xffffu);
}
static const uint8_t p25_data_trellis[4][4]={
    {0x2,0xc,0x1,0xf},{0xe,0x0,0xd,0x3},
    {0x9,0x7,0xa,0x4},{0x5,0xb,0x6,0x8}
};
// Every emitted nibble identifies exactly one (previous,next) state pair.
// This inverse is checked against all sixteen encoder edges in host tests.
static const uint8_t p25_data_trellis_inverse[16]={
    5,2,0,7,11,12,14,9,15,8,10,13,1,6,4,3
};
// Index of an interleaved dibit in the un-interleaved 98-dibit block.
static inline unsigned p25_data_interleave_index(unsigned i) {
    unsigned pair=i/2u;
    if(pair<13u)return pair*8u+i%2u;
    pair-=13u;
    return (pair/12u+1u)*2u+(pair%12u)*8u+i%2u;
}
static inline unsigned p25_data_hamming4(unsigned v) {
    v=v-((v>>1)&5u);return (v&3u)+((v>>2)&3u);
}
// Full 4-state hard-decision Viterbi, forced zero start and tail. Packet CRCs
// provide integrity; excessive trellis damage is refused before app parsing.
static inline bool p25_data_decode_block(const uint8_t *frame,size_t bytes,
    unsigned block,uint8_t out[12]) {
    uint8_t received[98],predecessor[49][4];
    uint16_t metric[4]={0,0x3fff,0x3fff,0x3fff};
    for(unsigned i=0;i<98u;++i) {
        unsigned data=56u+block*98u+i,physical=data+data/35u;
        if(physical>=bytes*4u)return false;
        received[p25_data_interleave_index(i)]=(uint8_t)p25_data_get_dibit(frame,physical);
    }
    {
        // An exact zero-metric path is the unique Viterbi winner, provided
        // both forced endpoint states match. Use the existing predecessor
        // scratch: fallback overwrites every entry before its traceback.
        // Do not publish partial output or treat a clean codeword as a CRC.
        uint8_t *clean=(uint8_t *)predecessor;
        memset(clean,0,12u);
        unsigned state=0,t;
        for(t=0;t<49u;++t) {
            unsigned observed=(received[2u*t]<<2)|received[2u*t+1u];
            unsigned edge=p25_data_trellis_inverse[observed];
            if((edge>>2)!=state)break;
            state=edge&3u;
            if(t<48u)clean[t/4u]|=(uint8_t)(state<<(6u-2u*(t%4u)));
        }
        if(t==49u && state==0u) {memcpy(out,clean,12u);return true;}
    }
    for(unsigned t=0;t<49u;++t) {
        uint16_t next[4];unsigned observed=(received[2*t]<<2)|received[2*t+1];
        for(unsigned s=0;s<4u;++s) {
            unsigned best=0x3fff,prev=0;
            for(unsigned p=0;p<4u;++p) {
                unsigned distance=metric[p]+p25_data_hamming4(observed^p25_data_trellis[p][s]);
                if(distance<best) {best=distance;prev=p;}
            }
            next[s]=(uint16_t)best;predecessor[t][s]=(uint8_t)prev;
        }
        memcpy(metric,next,sizeof metric);
    }
    if(metric[0]>16u)return false;
    memset(out,0,12);unsigned state=0;
    for(unsigned t=49;t>0;--t) {
        if(t<49u)out[(t-1u)/4u]|=(uint8_t)(state<<(6u-2u*((t-1u)%4u)));
        state=predecessor[t-1u][state];
    }
    return state==0;
}
static inline unsigned p25_data_frame_symbols(const uint8_t *frame,size_t bytes,uint8_t header[12]) {
    if(!frame || bytes<40u || !p25_data_decode_block(frame,bytes,0,header))return 0;
    uint16_t crc=p25_data_crc16(header,10);
    if(header[10]!=(uint8_t)(crc>>8) || header[11]!=(uint8_t)crc)return 0;
    // Unconfirmed format, no ACK/protection flags, standard manufacturer,
    // SAP4 user data, full message, no fragment/extended-address header.
    if((header[0]&0xdfu)!=0x15u || header[1]!=0xc4u || header[2] ||
       !(header[6]&0x80u) || !(header[6]&0x7fu) ||
       (header[6]&0x7fu)>P25_DATA_MAX_BLOCKS || header[7]>11u || header[8] || header[9])return 0;
    unsigned data=56u+(1u+(header[6]&0x7fu))*98u;
    return ((data+34u)/35u)*36u;
}
#endif
