// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit finite REGISTER experiment. Received phase is a nominal projection,
// never a qualified sample/RF origin or permission for a future idle slot.
#ifndef P25_TRUNKING_CC_LIVE_H
#define P25_TRUNKING_CC_LIVE_H
#if DM32_TRUNK_SUBSCRIBER
enum {CC_IDLE,CC_WAIT,CC_LATCHED,CC_PREPARING,CC_START_WAIT,CC_CLOCK,CC_LAUNCHED,CC_FAILED,CC_DONE};
enum {CC_OK,CC_CONTEXT,CC_SOURCE,CC_PHASE,CC_EPOCH,CC_OWNER,CC_STALE,CC_START_LATE,CC_NATIVE,CC_TIMEOUT,CC_CANCELLED};
#define CC_WAIT_US 1000000u
#define CC_SOURCE_AGE_US 48000u
#define CC_PROJECT_US 225000u
#define CC_NATIVE_LEAD_US 120000u
#define CC_NATIVE_TOLERANCE_US 3000u
static struct {
    p25_trunking_slot slot;
    uint64_t source_first_tick,anchor_tick;
    uint32_t source_irq_us,callback_us,epoch,lane_epoch,anchor_us,anchor_age_us;
    uint32_t wait_deadline_us,target_us,clock_due_us;
    volatile uint32_t start_begin_us,start_end_us,edge_us;
    uint32_t source_id,group,period_ticks;
    volatile int32_t edge_error_us;
    volatile uint8_t state,reason;
    bool source_valid;
} trunk_preload_cc;
_Static_assert(sizeof trunk_preload_cc<=160u,"CC lab anchor exceeds its bounded trace");
static bool trunk_preload_cc_active(void) {
    return trunk_preload_cc.state>=CC_WAIT&&trunk_preload_cc.state<=CC_LAUNCHED;
}
static bool trunk_preload_cc_request_permission(void) {
    return trunk_preload_cc.state>=CC_PREPARING&&trunk_preload_cc.state<=CC_LAUNCHED
        &&trunk_preload_clock_compact_configured()
        &&control.source_id==trunk_preload_cc.source_id&&control.talkgroup==trunk_preload_cc.group
        &&!trunk_lab_attach_selected()&&!trunk_lab_ptt_selected()&&hrc_pin_read(PIN_PTT);
}
static bool trunk_preload_cc_defer_clock(void) {return trunk_preload_cc.state==CC_PREPARING;}
static void trunk_preload_cc_fail(unsigned reason_code) {
    trunk_preload_cc.reason=(uint8_t)reason_code;trunk_preload_cc.state=CC_FAILED;
    trunk_preload_cc.source_valid=false;
    if(trunk_preload_active())trunk_preload_abort("preload_cc_aborted",P25_TX_CANCELLED);
    hrc_timer_stop(TIMER_PA);
}
static void trunk_preload_cc_cancel(void) {
    if(trunk_preload_cc_active())trunk_preload_cc_fail(CC_CANCELLED);
}
static void trunk_preload_cc_receive_stop(void) {
    // PREPARING intentionally retires RX; it is the only frozen handoff.
    if(trunk_preload_cc.state==CC_WAIT||trunk_preload_cc.state==CC_LATCHED)
        trunk_preload_cc_fail(CC_EPOCH);
}
static void trunk_preload_cc_cleanup(void) {
    if(trunk_preload_cc.state==CC_LAUNCHED&&trunk_probe.result==TRUNK_PROBE_COMPLETE)
        trunk_preload_cc.state=CC_DONE;
    else if(trunk_preload_cc_active())trunk_preload_cc_fail(CC_CANCELLED);
}
static bool trunk_preload_cc_rx_valid(bool down) {
    return !down&&hrc_pin_read(PIN_PTT)&&!(board.input->scan()&ptt_mask)
        &&normal_mode&&features_ready&&feature_p25()&&trunk_enabled&&mon_running&&!mon_control_only
        &&trunk.phase==P25_TRUNKING_CONTROL&&receiver_frequency()==TRUNK_PROBE_RX_HZ
        &&trunk.control_hz==TRUNK_PROBE_RX_HZ&&trunk.have_site&&trunk.have_network
        &&trunk.learned_nac==TRUNK_PROBE_NAC&&trunk.system_id==TRUNK_PROBE_SYSTEM
        &&trunk.wacn==TRUNK_PROBE_WACN&&trunk.rfss==1u&&trunk.site==1u
        &&trunk_preload_clock_compact_configured()&&!trunk_session.running
        &&!trunk_rx_feed_selected()&&!trunk_rx_stream_owned&&!trunk_rx_progress_owned
        &&!mon_failed&&!monitor.gaps&&!monitor.raw_overflow&&!call_active&&!prepared&&!hardware_running
        // Passive Trunk RX deliberately inhibits the generic TX controller.
        // Recheck ordinary TX permission after its explicit RF-off handoff.
        &&!owner_tx_inhibit&&!(channel_record[12]&16u)&&!control.cancel&&control.state!=RADIO_FAULT
        &&control.split&&control.nac==TRUNK_PROBE_NAC&&control.source_id&&control.source_id<0xffffffu
        &&control.talkgroup&&control.talkgroup<=0xffffu&&!radio_channel_get_private(channel_record)
        &&!channel_scan.running&&!apps_active()&&!pcm_owner&&!applet_owns_radio
        &&!cps_active&&!cps_link&&!editing&&!menu_open&&!rx_lab&&!rx_job&&!broadcast_show&&!airband_show
        &&!digital_dmr.owned&&!analog_fm.owned&&!tx_fixed&&!armed&&!session_enabled
        &&dev&&hooks&&board.audio&&board.radio&&board.power->switch_on()
        &&feature_tx_settings_valid()&&feature_tx_power()==0u&&tx_writer==TX_WRITER_ALT1&&tx_dac_restore
        &&trunk_probe_mailbox_idle()&&!trunk_probe.active&&!trunk_lab_return_owned()
        &&!trunk_lab_attach_selected()&&!trunk_lab_ptt_selected()
        &&p25_trunking_lab_matches(P25_TRUNK_LAB_COMMONIQ1M,frequency,control.tx_frequency,control.nac);
}
static bool trunk_preload_cc_start(bool down) {
    if(trunk_preload_cc_active()||!trunk_preload_cc_rx_valid(down)||!trunk_preload_warm_health())return false;
    memset(&trunk_preload_cc,0,sizeof trunk_preload_cc);
    if(!p25_trunking_slot_init(&trunk_preload_cc.slot,3u,300u))return false;
    trunk_preload_cc.source_id=control.source_id;trunk_preload_cc.group=control.talkgroup;
    memcpy(trunk_preload_owner.channel,channel_record,32);memcpy(trunk_preload_owner.globals,global_record,32);
    // Finish the shared UART/PTT ACK before arming any autonomous transition.
    send("OK TRUNK PROBE PRELOAD CCSTART one-shot receive-anchor; RF timing unqualified\r\n");
    trunk_preload_cc.wait_deadline_us=hrc_micros()+CC_WAIT_US;trunk_preload_cc.state=CC_WAIT;
    return true;
}
static void trunk_preload_cc_block(uint64_t first_tick,uint32_t irq_us,bool valid) {
    trunk_preload_cc.source_valid=valid&&(trunk_preload_cc.state==CC_WAIT||trunk_preload_cc.state==CC_LATCHED);
    if(trunk_preload_cc.source_valid&&trunk_preload_cc.state==CC_WAIT) {
        trunk_preload_cc.source_first_tick=first_tick;trunk_preload_cc.source_irq_us=irq_us;
    }
}
static void trunk_preload_cc_status(const p25_demod_status *status) {
    if(trunk_preload_cc.state!=CC_WAIT&&trunk_preload_cc.state!=CC_LATCHED)return;
    if(!status||!trunk_preload_cc.source_valid)return;
    p25_trunking_slot_observation o={.sample_tick=status->sample_tick,.stream_epoch=status->stream_epoch,
        .lane_epoch=status->lane_epoch,.status=status->status,.selected=status->selected,
        .qualified=status->qualified&&status->duid==7u&&status->nac==TRUNK_PROBE_NAC};
    if(trunk_preload_cc.state==CC_LATCHED) {
        if(!o.selected||!o.qualified||!o.status||o.status==1u||o.stream_epoch!=trunk_preload_cc.epoch
           ||o.lane_epoch!=trunk_preload_cc.lane_epoch
           ||!p25_trunking_slot_observe(&trunk_preload_cc.slot,&o))trunk_preload_cc_fail(CC_PHASE);
        return;
    }
    const p25_trunking_slot *slot=&trunk_preload_cc.slot;
    bool chain=slot->have_boundary&&slot->have_status&&slot->status==2u&&slot->microslots==4u
        &&o.sample_tick>=slot->boundary_tick;
    uint64_t period=chain?o.sample_tick-slot->boundary_tick:0u;
    bool five=chain&&period>=1785u&&period<=1815u;
    if(!p25_trunking_slot_observe(&trunk_preload_cc.slot,&o)||o.status!=3u||!five)return;
    p25_trunking_slot_boundary_view boundary;
    if(!p25_trunking_slot_boundary(&trunk_preload_cc.slot,o.sample_tick,&boundary))return;
    uint64_t first=trunk_preload_cc.source_first_tick;
    if(first>UINT64_MAX-1536u||o.sample_tick>first+1536u) {trunk_preload_cc_fail(CC_SOURCE);return;}
    uint64_t delta=first+1536u-o.sample_tick;
    if(delta>2304u) {trunk_preload_cc_fail(CC_SOURCE);return;}
    uint32_t now=hrc_micros(),ago=(uint32_t)(delta*125u/6u);
    uint32_t anchor=trunk_preload_cc.source_irq_us-ago;
    if(now-anchor>CC_SOURCE_AGE_US) {trunk_preload_cc_fail(CC_STALE);return;}
    trunk_preload_cc.anchor_tick=o.sample_tick;trunk_preload_cc.epoch=o.stream_epoch;
    trunk_preload_cc.lane_epoch=o.lane_epoch;trunk_preload_cc.callback_us=now;
    trunk_preload_cc.anchor_us=anchor;trunk_preload_cc.anchor_age_us=now-anchor;
    trunk_preload_cc.period_ticks=(uint32_t)period;
    trunk_preload_cc.target_us=anchor+CC_PROJECT_US;
    trunk_preload_cc.clock_due_us=trunk_preload_cc.target_us-CC_NATIVE_LEAD_US;
    trunk_preload_cc.state=CC_LATCHED;
}
static bool trunk_preload_cc_irq_valid(void) {
    return trunk_preload_cc_request_permission()&&trunk_preload_warmed()
        &&normal_mode&&!trunk_enabled&&!mon_running&&!hardware_running&&prepared&&call_active
        &&control.state==RADIO_TX_PREPARE&&!control.cancel&&!control.inhibit&&!owner_tx_inhibit
        &&trunk_probe_profile_matches()&&trunk_preload_request_matches()
        &&!memcmp(channel_record,trunk_preload_owner.channel,32)&&!memcmp(global_record,trunk_preload_owner.globals,32)
        &&trunk_preload_owner.ram_hash==trunk_preload_ram_hash();
}
static bool trunk_preload_cc_timer(void) {
    if(trunk_preload_cc.state!=CC_START_WAIT)return false;
    uint32_t now=hrc_micros();
    if((int32_t)(now-trunk_preload_cc.clock_due_us)<0||now-trunk_preload_cc.clock_due_us>500u
       ||(int32_t)(now-trunk_preload.warm_deadline_us)>=0||!trunk_preload_cc_irq_valid()) {
        trunk_preload_cc_fail(CC_START_LATE);return true;
    }
    // Retire old native IRQ state immediately before this new RF-off clock.
    hrc7000_wr(dev,C7_SYS_INTERP_CLEAR,0xffffffffu);
    hrc7000_wr(dev,C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    trunk_preload_cc.start_begin_us=hrc_micros();trunk_preload_cc.state=CC_CLOCK;
    hrc7000_wr(dev,C7_LAYER2_CONTROL,0x82);
    trunk_preload_cc.start_end_us=hrc_micros();hrc_irq_enable(IRQ_MODEM_SYS,true);
    return true;
}
static bool trunk_preload_cc_native(uint32_t now,unsigned count) {
    if(trunk_preload_cc.state!=CC_CLOCK) {
        if(!trunk_preload_cc_active())return true;
        trunk_preload_cc_fail(CC_NATIVE);return false;
    }
    if(count==1u) {
        uint32_t age=now-trunk_preload_cc.start_end_us;
        if(age<27000u||age>33000u) {trunk_preload_cc_fail(CC_NATIVE);return false;}
    }
    if(count>4u) {trunk_preload_cc_fail(CC_NATIVE);return false;}
    if(count==4u) {
        int32_t error=(int32_t)(now-trunk_preload_cc.target_us);
        trunk_preload_cc.edge_us=now;trunk_preload_cc.edge_error_us=error;
        if(!trunk_preload_phase.pending||trunk_preload_phase.fire_ordinal!=3u
           ||error<-(int32_t)CC_NATIVE_TOLERANCE_US||error>(int32_t)CC_NATIVE_TOLERANCE_US) {
            trunk_preload_cc_fail(CC_NATIVE);return false;
        }
        trunk_preload_cc.state=CC_LAUNCHED;
    }
    return true;
}
static void trunk_preload_cc_poll(bool down) {
    if(trunk_preload_cc.state==CC_WAIT||trunk_preload_cc.state==CC_LATCHED) {
        uint32_t now=hrc_micros();
        if(!trunk_preload_cc_rx_valid(down)||control.source_id!=trunk_preload_cc.source_id
           ||control.talkgroup!=trunk_preload_cc.group
           ||memcmp(channel_record,trunk_preload_owner.channel,32)||memcmp(global_record,trunk_preload_owner.globals,32)) {
            trunk_preload_cc_fail(CC_OWNER);return;
        }
        if((int32_t)(now-trunk_preload_cc.wait_deadline_us)>=0) {trunk_preload_cc_fail(CC_TIMEOUT);return;}
        if(trunk_preload_cc.state!=CC_LATCHED)return;
        if(trunk_stream_epoch!=trunk_preload_cc.epoch||monitor.demod.lane_epoch!=trunk_preload_cc.lane_epoch) {
            trunk_preload_cc_fail(CC_EPOCH);return;
        }
        if(now-trunk_preload_cc.anchor_us>CC_SOURCE_AGE_US) {trunk_preload_cc_fail(CC_STALE);return;}
        // Decode has returned before this intentional, frozen RX handoff.
        trunk_preload_cc.state=CC_PREPARING;trunk_stop("cc_lab_prepare");normal_permission();
        if(!trunk_preload_prepare(false,true)) {trunk_preload_cc_fail(CC_CONTEXT);return;}
        now=hrc_micros();
        if((int32_t)(trunk_preload_cc.clock_due_us-now)<=0
           ||(int32_t)(trunk_preload_cc.target_us-trunk_preload.warm_deadline_us)>=0) {
            trunk_preload_cc_fail(CC_START_LATE);return;
        }
        uint32_t lock=hrc_irq_save();
        hrc_timer_ack(TIMER_PA);trunk_preload_cc.state=CC_START_WAIT;
        hrc_barrier();hrc_timer_oneshot(TIMER_PA,trunk_preload_cc.clock_due_us-now);
        hrc_irq_restore(lock);
    } else if(trunk_preload_cc.state==CC_START_WAIT||trunk_preload_cc.state==CC_CLOCK) {
        if(down||!trunk_preload_cc_request_permission()) {trunk_preload_cc_fail(CC_OWNER);return;}
        if(trunk_preload_cc.state==CC_CLOCK)(void)trunk_preload_clock_poll(trunk_probe.sequence,down);
    }
}
static int trunk_preload_cc_status_row(unsigned row,char *line,size_t capacity) {
    if(trunk_preload_cc.state==CC_IDLE)return 0;
    if(row==0u)return snprintf(line,capacity,
        "TRUNKPRELOAD_CC state=%u reason=%u anchor_tick_hex=%08lX%08lX epoch=%lu lane_epoch=%lu source_first_tick_hex=%08lX%08lX source_irq_us=%lu callback_us=%lu anchor_us=%lu anchor_age_us=%lu period_ticks=%lu mapping=nominal_half_end sample_origin_qualified=0\r\n",
        trunk_preload_cc.state,trunk_preload_cc.reason,(unsigned long)(trunk_preload_cc.anchor_tick>>32),
        (unsigned long)(uint32_t)trunk_preload_cc.anchor_tick,(unsigned long)trunk_preload_cc.epoch,
        (unsigned long)trunk_preload_cc.lane_epoch,(unsigned long)(trunk_preload_cc.source_first_tick>>32),
        (unsigned long)(uint32_t)trunk_preload_cc.source_first_tick,(unsigned long)trunk_preload_cc.source_irq_us,
        (unsigned long)trunk_preload_cc.callback_us,(unsigned long)trunk_preload_cc.anchor_us,
        (unsigned long)trunk_preload_cc.anchor_age_us,(unsigned long)trunk_preload_cc.period_ticks);
    if(row==1u)return snprintf(line,capacity,
        "TRUNKPRELOAD_CC_CLOCK target_us=%lu clock_due_us=%lu start_begin_us=%lu start_end_us=%lu edge_us=%lu edge_error_us=%ld projection_us=225000 native_lead_us=120000 edge_tolerance_us=3000 endpoint_ticks=1536 rate_qualified=0 start_edge_qualified=0 future_idle_observed=0\r\n",
        (unsigned long)trunk_preload_cc.target_us,(unsigned long)trunk_preload_cc.clock_due_us,
        (unsigned long)trunk_preload_cc.start_begin_us,(unsigned long)trunk_preload_cc.start_end_us,
        (unsigned long)trunk_preload_cc.edge_us,(long)trunk_preload_cc.edge_error_us);
    return -1;
}
#endif
#endif
