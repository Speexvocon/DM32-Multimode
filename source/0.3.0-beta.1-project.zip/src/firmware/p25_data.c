// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_data.h"
#include "p25_data_fec.h"
#include <string.h>

static uint16_t read16(const uint8_t *p) {return (uint16_t)((p[0]<<8)|p[1]);}
static uint32_t read32(const uint8_t *p) {return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static void write16(uint8_t *p,uint16_t v) {p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static void write32(uint8_t *p,uint32_t v) {p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static uint32_t crc32(const uint8_t *p,unsigned n) {
    uint32_t c=0;
    for(unsigned i=0;i<n;++i)for(unsigned j=0;j<8;++j) {
        unsigned feedback=((c>>31)^(p[i]>>(7u-j)))&1u;
        c<<=1;if(feedback)c^=0x04c11db7u;
    }
    return c^0xffffffffu;
}
static unsigned sum16(const uint8_t *p,unsigned n,unsigned sum) {
    while(n>=2u) {sum+=read16(p);p+=2;n-=2;}
    if(n)sum+=(unsigned)p[0]<<8;
    while(sum>>16)sum=(sum&0xffffu)+(sum>>16);
    return sum;
}
static uint16_t udp_checksum(const uint8_t *ip,unsigned n) {
    unsigned sum=sum16(ip+12,8,17u+n);
    return (uint16_t)~sum16(ip+20,n,sum);
}
static uint64_t nid(uint16_t v) {
    static const uint64_t g[16]={
        0x8000cd930bdd3b2a,0x4000ab5a8e33a6be,0x2000983e4cc4e874,0x10004c1f2662743a,
        0x0800eb9c98ec0136,0x0400b85d47ab3bb0,0x02005c2ea3d59dd8,0x01002e1751eaceec,
        0x0080170ba8f56776,0x0040c616dfa78890,0x0020630b6fd3c448,0x00103185b7e9e224,
        0x000818c2dbf4f112,0x0004c1f2662743a2,0x0002ad6a38ce9afb,0x00019b2617ba7657};
    uint64_t result=0;for(unsigned i=0;i<16;++i)if(v&(0x8000u>>i))result^=g[i];return result;
}
static void put_dibit(uint8_t *frame,unsigned data,unsigned value) {
    unsigned i=data+data/35u;
    frame[i/4u]|=(uint8_t)(value<<(6u-2u*(i%4u)));
}
static void encode_block(uint8_t *frame,unsigned block,const uint8_t data[12]) {
    uint8_t raw[98];unsigned prev=0;
    for(unsigned i=0;i<49u;++i) {
        unsigned value=i<48u?(data[i/4u]>>(6u-2u*(i%4u)))&3u:0;
        unsigned pair=p25_data_trellis[prev][value];raw[i*2]=(uint8_t)(pair>>2);raw[i*2+1]=(uint8_t)(pair&3u);prev=value;
    }
    for(unsigned i=0;i<98u;++i)put_dibit(frame,56u+block*98u+i,raw[p25_data_interleave_index(i)]);
}
size_t p25_data_build_tms(uint8_t *frame,size_t capacity,uint16_t nac,
    uint32_t source,uint32_t destination,uint8_t sequence,const char *text) {
    if(!frame || !text || nac>0xfffu || !source || source>0xffffffu || !destination || destination>0xffffffu)return 0;
    unsigned chars=0;
    while(chars<=P25_DATA_TEXT_BYTES && text[chars]) {
        if((unsigned char)text[chars]<32u || (unsigned char)text[chars]>126u)return 0;
        ++chars;
    }
    if(!chars || chars>P25_DATA_TEXT_BYTES)return 0;
    unsigned length=34u+chars*2u,blocks=(length+4u+11u)/12u,padded=blocks*12u;
    unsigned data_dibits=56u+(blocks+1u)*98u,symbols=((data_dibits+34u)/35u)*36u;
    size_t bytes=symbols/4u;
    if(blocks>P25_DATA_MAX_BLOCKS || bytes>capacity)return 0;
    uint8_t packet[P25_DATA_MAX_BLOCKS*12u]={0},header[12]={0x15,0xc4};
    packet[0]=0x45;write16(packet+2,(uint16_t)length);write16(packet+4,sequence);
    packet[8]=64;packet[9]=17;write32(packet+12,0xd0000001u|(source<<4));write32(packet+16,0xd0000001u|(destination<<4));
    write16(packet+20,4007);write16(packet+22,4007);write16(packet+24,(uint16_t)(length-20u));
    write16(packet+28,(uint16_t)(4u+chars*2u));packet[30]=0xa0;packet[32]=(uint8_t)(0x80u|(sequence&31u));packet[33]=4;
    for(unsigned i=0;i<chars;++i)packet[34u+i*2u]=(uint8_t)text[i];
    write16(packet+10,(uint16_t)~sum16(packet,20,0));
    uint16_t udp=udp_checksum(packet,length-20u);write16(packet+26,udp?udp:0xffffu);
    write32(packet+padded-4u,crc32(packet,padded-4u));
    // Subscriber-originated (I/O=0) uses the source LLID. Destination remains
    // explicit in IPv4; FNE-originated I/O=1 carries the destination LLID.
    header[3]=(uint8_t)(source>>16);header[4]=(uint8_t)(source>>8);header[5]=(uint8_t)source;
    header[6]=(uint8_t)(0x80u|blocks);header[7]=(uint8_t)(padded-length-4u);write16(header+10,p25_data_crc16(header,10));
    memset(frame,0,bytes);
    const uint64_t sync=UINT64_C(0x5575f5ff77ff),encoded=nid((uint16_t)((nac<<4)|12u));
    for(unsigned i=0;i<24u;++i)put_dibit(frame,i,(unsigned)((sync>>(46u-2u*i))&3u));
    for(unsigned i=0;i<32u;++i)put_dibit(frame,24u+i,(unsigned)((encoded>>(62u-2u*i))&3u));
    encode_block(frame,0,header);
    for(unsigned i=0;i<blocks;++i)encode_block(frame,i+1u,packet+i*12u);
    // 01 means unknown/inbound status. It carries no voice or delivery claim.
    for(unsigned i=35u;i<symbols;i+=36u)frame[i/4u]|=(uint8_t)(1u<<(6u-2u*(i%4u)));
    return bytes;
}
unsigned p25_data_header_symbols(const uint8_t *frame,size_t length) {
    uint8_t header[12];return p25_data_frame_symbols(frame,length,header);
}
bool p25_data_parse_tms(const uint8_t *frame,size_t length,p25_data_message *out) {
    uint8_t header[12],packet[P25_DATA_MAX_BLOCKS*12u];
    if(!out)return false;
    unsigned symbols=p25_data_frame_symbols(frame,length,header);
    if(!symbols || length!=symbols/4u)return false;
    static const uint8_t sync[6]={0x55,0x75,0xf5,0xff,0x77,0xff};
    if(memcmp(frame,sync,6))return false;
    uint64_t network=0;
    for(unsigned i=24;i<57u;++i)if(i!=35u)network=(network<<2)|p25_data_get_dibit(frame,i);
    if((network>>48&15u)!=12u || network!=nid((uint16_t)(network>>48)))return false;
    unsigned blocks=header[6]&0x7fu,padded=blocks*12u;
    if(padded<4u+header[7])return false;
    for(unsigned i=0;i<blocks;++i)if(!p25_data_decode_block(frame,length,i+1u,packet+i*12u))return false;
    if(read32(packet+padded-4u)!=crc32(packet,padded-4u))return false;
    unsigned n=padded-4u-header[7];
    if(n<33u || packet[0]!=0x45u || !packet[8] || packet[9]!=17u || (read16(packet+6)&0xbfffu) ||
       read16(packet+2)!=n || sum16(packet,20,0)!=0xffffu)return false;
    unsigned udp=read16(packet+24);
    if(udp!=n-20u || read16(packet+20)!=4007u || read16(packet+22)!=4007u ||
       (read16(packet+26) && udp_checksum(packet,udp)))return false;
    uint32_t src=read32(packet+12),dst=read32(packet+16);
    if((src&0xf000000fu)!=0xd0000001u || (dst&0xf000000fu)!=0xd0000001u)return false;
    src=(src>>4)&0xffffffu;dst=(dst>>4)&0xffffffu;
    uint32_t llid=((uint32_t)header[3]<<16)|((uint32_t)header[4]<<8)|header[5];
    // TIA-102 asymmetric LLID: inbound source, outbound destination.
    if(!src || !dst || llid!=((header[0]&0x20u)?dst:src))return false;
    const uint8_t *tms=packet+28;unsigned tmslen=n-28u;
    if(read16(tms)+2u!=tmslen || tms[3]!=0)return false;
    p25_data_message value={.source=src,.destination=dst};
    if(tmslen==5u && tms[2]==0xbfu && !(tms[4]&0xe0u)) {
        value.acknowledgment=true;value.sequence=tms[4];
    } else {
        if(tmslen<8u || (tms[2]!=0xa0u && tms[2]!=0xe0u) ||
           (tms[4]&0xe0u)!=0x80u || tms[5]!=4u || (tmslen-6u)%2u)return false;
        unsigned chars=(tmslen-6u)/2u;
        // Optional trailing UTF-16 NUL is accepted, interior NUL is refused.
        if(chars && !tms[6u+(chars-1u)*2u] && !tms[7u+(chars-1u)*2u])--chars;
        if(!chars || chars>P25_DATA_TEXT_BYTES)return false;
        for(unsigned i=0;i<chars;++i) {
            if(tms[7u+i*2u] || tms[6u+i*2u]<32u || tms[6u+i*2u]>126u)return false;
            value.text[i]=(char)tms[6u+i*2u];
        }
        value.sequence=tms[4]&31u;value.ack_requested=(tms[2]&0x40u)!=0;
    }
    *out=value;return true;
}
