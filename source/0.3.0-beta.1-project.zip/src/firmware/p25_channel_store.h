// SPDX-License-Identifier: GPL-3.0-or-later
// Dense, atomic snapshots in the existing 32 KiB DM32 settings window.
#ifndef P25_CHANNEL_STORE_H
#define P25_CHANNEL_STORE_H
#include "p25_preferences.h"
#include "radio_channel.h"
#include "radio_functions.h"

enum {
    P25_CS_RECORD_BYTES=32, P25_CS_RECORDS=499, P25_CS_V5_RECORDS=483, P25_CS_V4_RECORDS=387,
    P25_CS_CONTACT_BASE=387, P25_CS_CONTACTS=96, P25_CS_CONTACT_NAME_BYTES=24, P25_CS_CHANNELS=256,
    P25_CS_VFO_A=256, P25_CS_VFO_B=257, P25_CS_GLOBAL=258,
    P25_CS_ZONE_BASE=259, P25_CS_ZONES=16, P25_CS_SCAN_BASE=291,
    P25_CS_SCAN_LISTS=16, P25_CS_TG_CAPACITY=64,
    P25_CS_BANK_BYTES=16384, P25_CS_SLOTS=256, P25_CS_SLOT_BYTES=64,
    P25_CS_TRUNK_BASE=483, P25_CS_TRUNK_SYSTEMS=8, P25_CS_TRUNK_CONTROLS=8,
    P25_CS_PAYLOAD_OFFSET=128, P25_CS_PAYLOAD_BYTES=15968,
    P25_CS_USED_BYTES=16096, P25_CS_NO_SLOT=65535,
    P25_CS_LEGACY_RECORDS=35, P25_CS_LEGACY_GLOBAL=34
};
#define P25_CS_MAGIC 0x43533250u
#define P25_CS_V4_MAGIC 0x43533450u
#define P25_CS_V5_MAGIC 0x43533550u
#define P25_CS_V6_MAGIC 0x43533650u
#define P25_CS_VERSION 6u
// Nine append-only hot-selection records fit in the unused V6 bank tail.
// Snapshot CRCs deliberately continue to cover only the canonical records.
#define P25_CS_SELECTION_MAGIC 0x4c533650u
enum {P25_CS_SELECTION_BYTES=32,P25_CS_SELECTION_SLOTS=(P25_CS_BANK_BYTES-P25_CS_USED_BYTES)/P25_CS_SELECTION_BYTES};
enum { P25_CS_OCCUPIED=1u, P25_CS_FM=2u, P25_CS_PROM=4u,
       P25_CS_TG_FILTER=8u, P25_CS_RX_ONLY=16u, P25_CS_WIDE=32u, P25_CS_DMR=64u };
enum { P25_CS_SCAN_CHANNEL=0, P25_CS_SCAN_TG=1,
       P25_CS_REPLY_SELECTED=0, P25_CS_REPLY_LAST=1, P25_CS_REPLY_FIXED=2 };

// Contact identity is typed and scoped by protocol: a unit and a group may
// share an ID, while overlapping P25/DMR/Both aliases are rejected at commit.
enum {P25_CS_CONTACT_OCCUPIED=1u,P25_CS_CONTACT_P25=2u,P25_CS_CONTACT_DMR=4u,
      P25_CS_CONTACT_BOTH=6u,P25_CS_CONTACT_GROUP=8u};
static inline unsigned p25_cs_record_count(unsigned version) {return version<4u ? 35u : version==4u ? 387u : version==5u ? 483u : 499u;}
static inline unsigned p25_cs_used_bytes(unsigned version) {return 128u+32u*p25_cs_record_count(version);}
static inline uint32_t p25_cs_contact_id(const uint8_t *p) {return (uint32_t)p[1]|(uint32_t)p[2]<<8|(uint32_t)p[3]<<16;}
static inline bool p25_cs_contact_match(const uint8_t *p,unsigned protocol,bool group,uint32_t id) {
    return (p[0]&P25_CS_CONTACT_OCCUPIED) && (p[0]&protocol&P25_CS_CONTACT_BOTH)
        && ((p[0]&P25_CS_CONTACT_GROUP)!=0)==group && p25_cs_contact_id(p)==id;
}

typedef struct {
    const hal_flash_t *flash;
    uint32_t revision,legacy_addr;
    uint16_t legacy_slot[P25_CS_LEGACY_RECORDS];
    uint8_t staged[(P25_CS_RECORDS+7)/8];
    uint8_t active_bank,stage_bank,active_version;
    uint8_t selection[7],selection_next;
    bool selection_valid;
    bool writable,have_active,have_legacy,staging,opened;
} p25_cs_store;

static inline uint16_t p25_cs_get16(const uint8_t *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static inline void p25_cs_put16(uint8_t *p,uint16_t n) {p[0]=(uint8_t)n;p[1]=(uint8_t)(n>>8);}
static inline bool p25_cs_zero(const uint8_t *p,unsigned n) {while(n--)if(*p++)return false;return true;}
static inline bool p25_cs_ff(const uint8_t *p,unsigned n) {while(n--)if(*p++!=255)return false;return true;}
static inline bool p25_cs_map_test(const uint8_t *map,unsigned slot) {return slot<256u && (map[slot/8]&(1u<<(slot%8)))!=0;}
static inline void p25_cs_map_set(uint8_t *map,unsigned slot,bool present) {
    if(slot<256u) {uint8_t mask=(uint8_t)(1u<<(slot%8));map[slot/8]=(uint8_t)((map[slot/8]&~mask)|(present ? mask : 0u));}
}
static inline unsigned p25_cs_zone_key(unsigned zone) {return P25_CS_ZONE_BASE+2u*zone;}
static inline unsigned p25_cs_scan_key(unsigned list) {return P25_CS_SCAN_BASE+6u*list;}
static inline unsigned p25_cs_selection(const uint8_t *global,unsigned side) {
    return side<2u ? (unsigned)global[10+side]|(unsigned)global[24+side]<<8 : 0u;
}
static inline bool p25_cs_set_selection(uint8_t *global,unsigned side,unsigned selection) {
    if(side>=2u || selection>P25_CS_CHANNELS)return false;
    global[10+side]=(uint8_t)selection;global[24+side]=(uint8_t)(selection>>8);return true;
}
static inline void p25_cs_selection_pack(uint8_t *selection,const uint8_t *global) {
    selection[0]=global[9];selection[1]=global[10];selection[2]=global[11];
    memcpy(selection+3,global+24,4);
}
static inline void p25_cs_selection_apply(uint8_t *global,const uint8_t *selection) {
    global[9]=selection[0];global[10]=selection[1];global[11]=selection[2];
    memcpy(global+24,selection+3,4);
}
static inline bool p25_cs_selection_only(const uint8_t *a,const uint8_t *b) {
    for(unsigned i=0;i<32;++i)if(i!=9 && i!=10 && i!=11 && (i<24 || i>27) && a[i]!=b[i])return false;
    return true;
}
static inline bool p25_cs_name_valid(const uint8_t *p,unsigned bytes) {
    bool ended=false;
    for(unsigned i=0;i<bytes;++i) {if(!p[i])ended=true;else if(ended || p[i]<32 || p[i]>126)return false;}
    return true;
}
enum { P25_CS_TRUNK_RX_ONLY=0, P25_CS_TRUNK_EXPERIMENTAL=1 };
typedef struct {
    uint32_t control_hz[P25_CS_TRUNK_CONTROLS],wacn,source_id;
    uint16_t system_id,nac,talkgroup;
    uint8_t mode,control_count,rfss,site;
    char name[13];
} p25_cs_trunk_system;
_Static_assert(sizeof(p25_cs_trunk_system)==64,"Bounded selected trunk system cache");
static inline unsigned p25_cs_trunk_key(unsigned index) {return P25_CS_TRUNK_BASE+2u*index;}
static inline uint32_t p25_cs_get24(const uint8_t *p) {return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16;}
static inline bool p25_cs_trunk_descriptor_valid(const uint8_t *p) {
    if(!p[0])return p25_cs_zero(p,32);
    uint32_t wacn=p25_cs_get24(p+14);unsigned system=p25_cs_get16(p+17);
    return p25_cs_name_valid(p,12) && p[12]<=P25_CS_TRUNK_EXPERIMENTAL
        && p[13]>=1 && p[13]<=P25_CS_TRUNK_CONTROLS && wacn<=0xfffffu
        && system<=0xfffu && p25_cs_get16(p+19)<=0xfffu && p25_cs_get16(p+26)
        && (p[12]!=P25_CS_TRUNK_EXPERIMENTAL || (wacn && system && p25_cs_get24(p+23)!=0xffffffu)) && p25_cs_zero(p+28,4);
}
// No RF or qualification is implied by a persisted experimental intent.
static inline bool p25_cs_trunk_decode(const uint8_t *desc,const uint8_t *controls,p25_cs_trunk_system *out) {
    if(!desc || !controls || !out || !desc[0] || !p25_cs_trunk_descriptor_valid(desc))return false;
    p25_cs_trunk_system value={0};
    for(unsigned i=0;i<P25_CS_TRUNK_CONTROLS;++i) {
        uint32_t hz=pref_get(controls+4*i);
        if(i>=desc[13]) {if(hz)return false;continue;}
        if(hz<100000000u || hz>520000000u)return false;
        for(unsigned j=0;j<i;++j)if(value.control_hz[j]==hz)return false;
        value.control_hz[i]=hz;
    }
    memcpy(value.name,desc,12);value.mode=desc[12];value.control_count=desc[13];
    value.wacn=p25_cs_get24(desc+14);value.system_id=p25_cs_get16(desc+17);value.nac=p25_cs_get16(desc+19);
    value.rfss=desc[21];value.site=desc[22];value.source_id=p25_cs_get24(desc+23);value.talkgroup=p25_cs_get16(desc+26);
    *out=value;return true;
}
static inline bool p25_cs_tone_valid(uint16_t tone) {
    unsigned type=tone>>14,value=tone&0x3fffu;
    return type==0 ? value==0 : type==1 ? value>=600 && value<=2600 : value>=1 && value<=511;
}
static inline bool p25_cs_version(unsigned version) {return version>=1u && version<=P25_CS_VERSION;}
static inline bool p25_cs_record_valid_version(unsigned version,unsigned key,const uint8_t *p) {
    if(!p25_cs_version(version) || key>=p25_cs_record_count(version))return false;
    if(key==(version<4u ? 34u : P25_CS_GLOBAL)) {
        uint32_t id=pref_get(p);uint8_t functions[32];memcpy(functions,p,32);memset(functions+24,0,8);
        return id && id<=0xffffffu && p[4]<=42 && p25_cs_get16(p+5)<=600 && p25_cs_get16(p+7)<=600
            && p[9]<=1 && (version<4u ? p[10]<=32 && p[11]<=32 : p25_cs_selection(p,0)<=256 && p25_cs_selection(p,1)<=256)
            && p[12]<(version<4u ? 4u : 16u) && p[13]<=1
            && (version>=3u ? radio_functions_record_valid(functions) : p25_cs_zero(p+14,18))
            && (version>=5u || (p[16]<=8u && p[17]<=8u && p[18]<=8u && p[19]<=8u))
            && (version<4u ? p25_cs_zero(p+24,8) : p[26]<=16 && p[27]<=16
                && (version<6u ? p25_cs_zero(p+28,4) : p[28]<=8 && p[29]<=1 && (!p[29] || p[28]) && p25_cs_zero(p+30,2)));
    }
    if(version>=6u && key>=P25_CS_TRUNK_BASE)return (key-P25_CS_TRUNK_BASE)%2u ? true : p25_cs_trunk_descriptor_valid(p);
    if(version>=5u && key>=P25_CS_CONTACT_BASE && key<P25_CS_TRUNK_BASE) {
        if(!p[0])return p25_cs_zero(p,32);
        unsigned protocol=p[0]&P25_CS_CONTACT_BOTH;uint32_t id=p25_cs_contact_id(p);
        return (p[0]&P25_CS_CONTACT_OCCUPIED) && !(p[0]&~15u) && protocol && id
            && (!(p[0]&P25_CS_CONTACT_GROUP) || !(protocol&P25_CS_CONTACT_P25) || id<=65535u)
            && p[4] && p25_cs_name_valid(p+4,P25_CS_CONTACT_NAME_BYTES) && p25_cs_zero(p+28,4);
    }
    if(version>=4u && key>=P25_CS_ZONE_BASE) {
        if(key<P25_CS_SCAN_BASE) {
            return (key-P25_CS_ZONE_BASE)%2u ? true : p25_cs_name_valid(p,12) && p25_cs_zero(p+12,20);
        }
        if((key-P25_CS_SCAN_BASE)%6u)return true;
        if(p25_cs_zero(p,32))return true;
        unsigned base=p25_cs_get16(p+14),fixed=p25_cs_get16(p+16),dwell=p25_cs_get16(p+18),hold=p25_cs_get16(p+20);
        return p[0] && p25_cs_name_valid(p,12) && p[12]<=1 && p[13]<=2
            && (p[12]==P25_CS_SCAN_TG ? base>=1 && base<=256 : base==0)
            && (p[13]==P25_CS_REPLY_FIXED ? fixed>=1 && fixed<=256 : fixed==0)
            && dwell>=100 && dwell<=5000 && hold<=10000 && p[22]<=64
            && (p[12]==P25_CS_SCAN_TG || !p[22]) && p25_cs_zero(p+23,9);
    }
    if(!(p[12]&P25_CS_OCCUPIED))return p25_cs_zero(p,32);
    uint32_t rx=pref_get(p),tx=pref_get(p+4);
    if(rx<100000000u || rx>520000000u || tx<100000000u || tx>520000000u || p[12]&0x80u
       || (version==1u && (p[12]&P25_CS_DMR)) || ((p[12]>>2)&3u)>2
       || (version<4u ? p[13]>15 : p[13]!=0) || p[30]>9
       || (version>=3u ? p[31]>=RADIO_POWER_LEVELS : p[31]!=0) || !p25_cs_name_valid(p+14,12))return false;
    if(p[12]&P25_CS_DMR)return !(p[12]&(P25_CS_FM|P25_CS_WIDE)) && p[30]==5
        && radio_channel_get_destination(p) && !(p[11]&0x80u) && p25_cs_zero(p+26,4);
    if(p25_cs_get16(p+8)>0xfffu || !p25_cs_get16(p+10))return false;
    uint16_t tx_tone=p25_cs_get16(p+26),rx_tone=p25_cs_get16(p+28);
    if(!(p[12]&P25_CS_FM))return !(p[12]&P25_CS_WIDE)
        && (version>=5u && p[29]==1u ? radio_channel_get_destination(p)!=0 : !tx_tone && !rx_tone);
    return p25_cs_tone_valid(tx_tone) && p25_cs_tone_valid(rx_tone);
}
static inline bool p25_cs_record_valid(unsigned key,const uint8_t *p) {return p25_cs_record_valid_version(P25_CS_VERSION,key,p);}
static inline uint32_t p25_cs_crc_add(uint32_t crc,const uint8_t *p,unsigned n) {
    while(n--) {crc^=*p++;for(unsigned j=0;j<8;++j)crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);}return crc;
}
static inline uint32_t p25_cs_addr(const p25_cs_store *s,unsigned bank,unsigned slot) {
    return s->flash->map->settings_addr+bank*P25_CS_BANK_BYTES+slot*P25_CS_SLOT_BYTES;
}
static inline uint32_t p25_cs_record_addr(const p25_cs_store *s,unsigned bank,unsigned key) {
    return p25_cs_addr(s,bank,0)+P25_CS_PAYLOAD_OFFSET+key*P25_CS_RECORD_BYTES;
}
static inline bool p25_cs_read_slot(const p25_cs_store *s,unsigned bank,unsigned slot,uint8_t *b) {
    return s->flash->read(p25_cs_addr(s,bank,slot),b,64);
}
static inline bool p25_cs_committed(const uint8_t *b) {return !pref_get(b+60) && pref_get(b+56)==pref_crc(b,56);}
static inline bool p25_cs_prefix(const uint8_t *b,unsigned key) {
    return pref_get(b)==P25_CS_MAGIC && b[4]>=1 && b[4]<=3 && b[5]==key && p25_cs_get16(b+6)==32;
}
static inline bool p25_cs_data_slot(const uint8_t *b) {
    return b[5]<35 && p25_cs_prefix(b,b[5]) && p25_cs_zero(b+40,16) && p25_cs_committed(b)
        && p25_cs_record_valid_version(b[4],b[5],b+8);
}
static inline bool p25_cs_v4_prefix(const uint8_t *b) {
    return ((pref_get(b)==P25_CS_V4_MAGIC && b[4]==4) || (pref_get(b)==P25_CS_V5_MAGIC && b[4]==5)
        || (pref_get(b)==P25_CS_V6_MAGIC && b[4]==6))
        && !b[5] && p25_cs_get16(b+6)==32;
}
typedef bool (*p25_cs_reader)(const void *,unsigned,uint8_t *);
// Shared snapshot reference gate; no RF, allocation or writes. Called only on
// configuration publication/boot, never in the received-unit path.
static inline bool p25_cs_image_valid(p25_cs_reader read,const void *context) {
    uint8_t global[32],desc[32],map[32],record[32];
    for(unsigned key=0;key<P25_CS_RECORDS;++key)
        if(!read(context,key,record) || !p25_cs_record_valid(key,record))return false;
    if(!read(context,P25_CS_GLOBAL,global) || !p25_cs_record_valid(P25_CS_GLOBAL,global))return false;
    for(unsigned z=0;z<P25_CS_ZONES;++z) {
        if(!read(context,p25_cs_zone_key(z),desc) || !read(context,p25_cs_zone_key(z)+1,map)
           || !p25_cs_record_valid(p25_cs_zone_key(z),desc))return false;
        if(!desc[0] && !p25_cs_zero(map,32))return false;
        for(unsigned slot=0;slot<256;++slot)if(p25_cs_map_test(map,slot))
            if(!read(context,slot,record) || !(record[12]&P25_CS_OCCUPIED))return false;
    }
    for(unsigned side=0;side<2;++side) {
        unsigned selected=p25_cs_selection(global,side),zone=global[26+side];
        if(selected && (!read(context,selected-1,record) || !(record[12]&P25_CS_OCCUPIED)))return false;
        if(zone) {
            if(!read(context,p25_cs_zone_key(zone-1),desc) || !desc[0]
               || !read(context,p25_cs_zone_key(zone-1)+1,map) || (selected && !p25_cs_map_test(map,selected-1)))return false;
        }
    }
    for(unsigned list=0;list<P25_CS_SCAN_LISTS;++list) {
        unsigned key=p25_cs_scan_key(list);uint16_t groups[64];
        if(!read(context,key,desc) || !p25_cs_record_valid(key,desc) || !read(context,key+1,map))return false;
        for(unsigned part=0;part<4;++part) {
            if(!read(context,key+2+part,record))return false;
            for(unsigned i=0;i<16;++i)groups[part*16+i]=p25_cs_get16(record+2*i);
        }
        if(!desc[0]) {
            if(!p25_cs_zero(map,32))return false;
            for(unsigned i=0;i<64;++i)if(groups[i])return false;
            continue;
        }
        unsigned base=p25_cs_get16(desc+14),fixed=p25_cs_get16(desc+16);
        if(fixed && (!read(context,fixed-1,record) || !(record[12]&P25_CS_OCCUPIED)))return false;
        if(desc[12]==P25_CS_SCAN_TG) {
            if(!p25_cs_zero(map,32) || !read(context,base-1,record) || !(record[12]&P25_CS_OCCUPIED)
               || radio_channel_get_mode(record)!=RADIO_CHANNEL_P25 || radio_channel_get_private(record))return false;
        } else for(unsigned slot=0;slot<256;++slot)if(p25_cs_map_test(map,slot))
            if(!read(context,slot,record) || !(record[12]&P25_CS_OCCUPIED))return false;
        for(unsigned i=0;i<64;++i) {
            if(i>=desc[22]) {if(groups[i])return false;continue;}
            if(!groups[i])return false;
            for(unsigned j=0;j<i;++j)if(groups[j]==groups[i])return false;
        }
    }
    uint32_t contacts[P25_CS_CONTACTS];unsigned count=0;
    for(unsigned key=P25_CS_CONTACT_BASE;key<P25_CS_TRUNK_BASE;++key) {
        if(!read(context,key,record))return false;
        if(!record[0])continue;
        uint32_t identity=p25_cs_contact_id(record)|((uint32_t)record[0]<<24);
        for(unsigned i=0;i<count;++i)if((contacts[i]&0xffffffu)==(identity&0xffffffu)
            && ((contacts[i]^identity)&((uint32_t)P25_CS_CONTACT_GROUP<<24))==0
            && ((contacts[i]&identity)&((uint32_t)P25_CS_CONTACT_BOTH<<24)))return false;
        contacts[count++]=identity;
    }
    for(unsigned i=0;i<P25_CS_TRUNK_SYSTEMS;++i) {
        if(!read(context,p25_cs_trunk_key(i),desc) || !read(context,p25_cs_trunk_key(i)+1,map))return false;
        if(!desc[0]) {if(!p25_cs_zero(desc,32) || !p25_cs_zero(map,32))return false;}
        else {p25_cs_trunk_system system;if(!p25_cs_trunk_decode(desc,map,&system))return false;}
    }
    if(global[28] && (!read(context,p25_cs_trunk_key(global[28]-1u),desc) || !desc[0]))return false;
    return true;
}
typedef struct {const p25_cs_store *store;unsigned bank;bool *io_ok;unsigned version;} p25_cs_bank_reader;
static inline bool p25_cs_dense_read(const void *context,unsigned key,uint8_t *out) {
    const p25_cs_bank_reader *r=context;
    if(key>=P25_CS_RECORDS)return false;
    if(key>=p25_cs_record_count(r->version)){memset(out,0,32);return true;}
    bool ok=r->store->flash->read(p25_cs_record_addr(r->store,r->bank,key),out,32);
    if(!ok && r->io_ok)*r->io_ok=false;
    return ok;
}
static inline bool p25_cs_legacy_bank(const p25_cs_store *s,unsigned bank,uint16_t *index,uint32_t *revision,unsigned *version,bool *io_ok) {
    uint8_t b[64],record[32];uint32_t expected,bank_crc,crc=~0u;
    if(!p25_cs_read_slot(s,bank,0,b)) {*io_ok=false;return false;}
    if(!p25_cs_prefix(b,255) || !p25_cs_committed(b) || p25_cs_get16(b+16)!=35 || p25_cs_get16(b+18)!=32 || !p25_cs_zero(b+24,32))return false;
    *version=b[4];*revision=pref_get(b+8);expected=pref_get(b+12);bank_crc=pref_get(b+20);
    for(unsigned k=0;k<35;++k)index[k]=P25_CS_NO_SLOT;
    for(unsigned i=2;i<256;++i) {
        if(!p25_cs_read_slot(s,bank,i,b)) {*io_ok=false;return false;}
        if(p25_cs_data_slot(b) && b[4]==*version)index[b[5]]=(uint16_t)i;
    }
    for(unsigned k=0;k<35;++k) {
        if(index[k]==P25_CS_NO_SLOT)return false;
        if(!p25_cs_read_slot(s,bank,index[k],b)) {*io_ok=false;return false;}
        memcpy(record,b+8,32);crc=p25_cs_crc_add(crc,record,32);
    }
    if((crc^~0u)!=expected)return false;
    for(unsigned pane=0;pane<2;++pane)if(record[10+pane]) {
        if(!p25_cs_read_slot(s,bank,index[record[10+pane]-1u],b)) {*io_ok=false;return false;}
        if(!(b[20]&P25_CS_OCCUPIED))return false;
    }
    if(!p25_cs_read_slot(s,bank,1,b)) {*io_ok=false;return false;}
    p25_preferences legacy;if(!pref_blank(b) && !pref_unpack(b,&legacy))return false;
    return (p25_cs_crc_add(crc,b,64)^~0u)==bank_crc;
}
static inline bool p25_cs_dense_bank(const p25_cs_store *s,unsigned bank,uint32_t *revision,bool *io_ok) {
    uint8_t header[64],b[64];uint32_t crc=~0u;p25_cs_bank_reader reader={s,bank,io_ok,0};p25_preferences legacy;
    if(!p25_cs_read_slot(s,bank,0,header)) {*io_ok=false;return false;}
    reader.version=header[4];unsigned records=p25_cs_record_count(reader.version);
    if(!p25_cs_v4_prefix(header) || !p25_cs_committed(header) || p25_cs_get16(header+16)!=records
       || p25_cs_get16(header+18)!=records*32u || !p25_cs_zero(header+24,32))return false;
    for(unsigned key=0;key<records;++key) {
        if(!p25_cs_dense_read(&reader,key,b)) {*io_ok=false;return false;}
        if(!p25_cs_record_valid_version(reader.version,key,b))return false;
        crc=p25_cs_crc_add(crc,b,32);
    }
    if((crc^~0u)!=pref_get(header+12))return false;
    if(!p25_cs_read_slot(s,bank,1,b)) {*io_ok=false;return false;}
    if(!pref_blank(b) && !pref_unpack(b,&legacy))return false;
    if((p25_cs_crc_add(crc,b,64)^~0u)!=pref_get(header+20))return false;
    if(!p25_cs_image_valid(p25_cs_dense_read,&reader))return false;
    *revision=pref_get(header+8);return true;
}
static inline bool p25_cs_selection_refs(p25_cs_reader read,const void *context,const uint8_t *global) {
    uint8_t record[32],map[32];
    if(!p25_cs_record_valid(P25_CS_GLOBAL,global))return false;
    for(unsigned side=0;side<2;++side) {
        unsigned selected=p25_cs_selection(global,side),zone=global[26+side];
        if(selected && (!read(context,selected-1u,record) || !(record[12]&P25_CS_OCCUPIED)))return false;
        if(zone && (!read(context,p25_cs_zone_key(zone-1u),record) || !record[0]
            || !read(context,p25_cs_zone_key(zone-1u)+1u,map) || (selected && !p25_cs_map_test(map,selected-1u))))return false;
    }
    return true;
}
static inline bool p25_cs_selection_intent(const uint8_t *record,uint32_t revision) {
    uint8_t prefix[8];pref_put(prefix,P25_CS_SELECTION_MAGIC);pref_put(prefix+4,revision);
    if(!memcmp(record,prefix,8))return true;
    // Power loss while publishing the identifying prefix is recognizable too.
    for(unsigned n=1;n<8;++n)if(!memcmp(record,prefix,n) && p25_cs_ff(record+n,32u-n))return true;
    return false;
}
static inline bool p25_cs_selection_open(p25_cs_store *s,unsigned bank,uint32_t revision) {
    uint8_t record[32],global[32];bool io_ok=true;
    bool active=s->have_active && s->active_bank==bank && s->active_version==6;
    p25_cs_bank_reader reader={s,bank,&io_ok,6};
    if(active && !p25_cs_dense_read(&reader,P25_CS_GLOBAL,global))return false;
    for(unsigned slot=0;slot<P25_CS_SELECTION_SLOTS;++slot) {
        uint32_t addr=p25_cs_addr(s,bank,0)+P25_CS_USED_BYTES+slot*P25_CS_SELECTION_BYTES;
        if(!s->flash->read(addr,record,32))return false;
        if(p25_cs_ff(record,32))continue;
        if(!p25_cs_selection_intent(record,revision)) {s->writable=false;continue;}
        if(active)s->selection_next=(uint8_t)(slot+1u);
        if(!active || pref_get(record+28) || pref_get(record+24)!=pref_crc(record,24)
           || !p25_cs_zero(record+15,9))continue;
        uint8_t selected[32];memcpy(selected,global,32);p25_cs_selection_apply(selected,record+8);
        if(!p25_cs_selection_refs(p25_cs_dense_read,&reader,selected))continue;
        memcpy(s->selection,record+8,7);s->selection_valid=true;
    }
    return io_ok;
}
// Open is read-only. Recognized V4 intent identifies torn dense staging. Any
// unknown schema/data disables writes instead of guessing that it is free.
static inline bool p25_cs_open(p25_cs_store *s,const hal_flash_t *flash) {
    memset(s,0,sizeof *s);s->flash=flash;if(!pref_geometry(flash))return false;s->writable=true;
    uint16_t index[35];uint8_t b[64];uint32_t revision,latest=0;unsigned version;bool io_ok=true;
    for(unsigned bank=0;bank<2;++bank) {
        if(!p25_cs_read_slot(s,bank,0,b)) {s->writable=false;return false;}
        bool valid=false;version=4;
        if(p25_cs_v4_prefix(b)){version=b[4];valid=p25_cs_dense_bank(s,bank,&revision,&io_ok);}
        else valid=p25_cs_legacy_bank(s,bank,index,&revision,&version,&io_ok);
        if(valid && (!s->have_active || (int32_t)(revision-s->revision)>0)) {
            s->have_active=true;s->active_bank=(uint8_t)bank;s->revision=revision;s->active_version=(uint8_t)version;
            if(version<4)memcpy(s->legacy_slot,index,sizeof index);
        }
    }
    if(!io_ok) {s->writable=false;return false;}
    for(unsigned bank=0;bank<2;++bank) {
        if(!p25_cs_read_slot(s,bank,0,b)) {s->writable=false;return false;}
        bool dense=p25_cs_v4_prefix(b);unsigned dense_version=b[4];
        // A complete, CRC-valid header declaring another geometry is foreign
        // data, not an interrupted copy. Intent has an erased commit word.
        if(dense && p25_cs_committed(b) && (p25_cs_get16(b+16)!=p25_cs_record_count(dense_version)
           || p25_cs_get16(b+18)!=32u*p25_cs_record_count(dense_version) || !p25_cs_zero(b+24,32)))s->writable=false;
        if((pref_get(b)==P25_CS_V4_MAGIC || pref_get(b)==P25_CS_V5_MAGIC || pref_get(b)==P25_CS_V6_MAGIC) && !dense) {s->writable=false;dense=true;}
        if(dense && dense_version==6u) {
            if(!p25_cs_selection_open(s,bank,pref_get(b+8))) {s->writable=false;return false;}
        } else if(dense)for(unsigned off=p25_cs_used_bytes(dense_version);off<P25_CS_BANK_BYTES;off+=32) {
            if(!s->flash->read(p25_cs_addr(s,bank,0)+off,b,32)) {s->writable=false;return false;}
            if(!p25_cs_ff(b,32))s->writable=false;
        }
        for(unsigned slot=0;slot<256;++slot) {
            if(dense && slot!=1)continue;
            if(!p25_cs_read_slot(s,bank,slot,b)) {s->writable=false;return false;}
            if(pref_blank(b))continue;
            if(pref_get(b)==PREF_MAGIC && pref_version(pref_get(b+4))) {
                p25_preferences p;
                if(pref_unpack(b,&p) && (!s->have_legacy || (int32_t)(pref_get(b+8)-latest)>0)) {
                    latest=pref_get(b+8);s->have_legacy=true;s->legacy_addr=p25_cs_addr(s,bank,slot);
                }
            } else if(pref_get(b)==P25_CS_MAGIC && b[4]>=1 && b[4]<=3 && (b[5]<35 || (b[5]==255 && !slot)) && p25_cs_get16(b+6)==32) {
                // A recognized old append record may be torn; bank CRC decides visibility.
            } else s->writable=false;
        }
    }
    if(s->have_active) {
        if(!p25_cs_read_slot(s,s->active_bank,1,b)) {s->writable=false;return false;}
        p25_preferences p;s->have_legacy=pref_unpack(b,&p);s->legacy_addr=s->have_legacy ? p25_cs_addr(s,s->active_bank,1) : 0;
    } else if(s->have_legacy)s->revision=latest;
    s->opened=true;return true;
}
static inline bool p25_cs_old_read(const p25_cs_store *s,unsigned key,uint8_t *out) {
    if(s->have_active) {
        uint8_t b[64];
        if(key>=35 || s->legacy_slot[key]==P25_CS_NO_SLOT || !p25_cs_read_slot(s,s->active_bank,s->legacy_slot[key],b)
           || !p25_cs_data_slot(b) || b[5]!=key || b[4]!=s->active_version)return false;
        memcpy(out,b+8,32);return true;
    }
    p25_preferences p={0};uint8_t b[64];
    bool legacy=s->have_legacy && s->flash->read(s->legacy_addr,b,64) && pref_unpack(b,&p);
    if(s->have_legacy && !legacy)return false;
    memset(out,0,32);
    if(key==34) {pref_put(out,legacy ? p.id : 1u);out[4]=(uint8_t)(legacy ? p.mic_db : 11u);p25_cs_put16(out+5,60);p25_cs_put16(out+7,15);out[13]=(uint8_t)(legacy ? p.tx_inhibit : 0u);}
    else if(legacy && (key==32 || key==33)) {
        pref_put(out,p.rx);pref_put(out+4,p.tx);p25_cs_put16(out+8,(uint16_t)p.nac);p25_cs_put16(out+10,(uint16_t)p.tg);
        out[12]=(uint8_t)(P25_CS_OCCUPIED|(p.prom_mode ? P25_CS_PROM : 0));memcpy(out+14,key==32 ? "VFO A" : "VFO B",5);out[30]=5;
    }
    return true;
}
static inline bool p25_cs_read(const p25_cs_store *s,unsigned key,uint8_t *out) {
    if(!s->opened || !s->flash || key>=P25_CS_RECORDS || !pref_geometry(s->flash))return false;
    if(s->have_active && s->active_version>=4) {
        if(key>=p25_cs_record_count(s->active_version)){memset(out,0,32);return true;}
        if(!s->flash->read(p25_cs_record_addr(s,s->active_bank,key),out,32) || !p25_cs_record_valid(key,out))return false;
        if(key==P25_CS_GLOBAL && s->selection_valid)p25_cs_selection_apply(out,s->selection);
        return true;
    }
    memset(out,0,32);
    if(key<32 || (key>=P25_CS_VFO_A && key<=P25_CS_GLOBAL)) {
        unsigned oldkey=key<32 ? key : key-P25_CS_VFO_A+32;
        if(!p25_cs_old_read(s,oldkey,out))return false;
        if(key!=P25_CS_GLOBAL)out[13]=0;
        return true;
    }
    if((s->have_active || s->have_legacy) && key>=P25_CS_SCAN_BASE && key<P25_CS_SCAN_BASE+24) {
        unsigned list=(key-P25_CS_SCAN_BASE)/6,part=(key-P25_CS_SCAN_BASE)%6;
        if(!part) {memcpy(out,"Scan 1",6);out[5]=(uint8_t)('1'+list);out[13]=P25_CS_REPLY_LAST;p25_cs_put16(out+18,1000);p25_cs_put16(out+20,2000);}
        else if(part==1)for(unsigned slot=0;slot<32;++slot) {
            uint8_t record[32];if(!p25_cs_old_read(s,slot,record))return false;
            if((record[12]&P25_CS_OCCUPIED) && (record[13]&(1u<<list)))p25_cs_map_set(out,slot,true);
        }
    }
    return true;
}
static inline bool p25_cs_trunk_load(const p25_cs_store *s,unsigned selection,p25_cs_trunk_system *out) {
    uint8_t desc[32],controls[32];
    return selection>=1 && selection<=P25_CS_TRUNK_SYSTEMS
        && p25_cs_read(s,p25_cs_trunk_key(selection-1u),desc)
        && p25_cs_read(s,p25_cs_trunk_key(selection-1u)+1u,controls)
        && p25_cs_trunk_decode(desc,controls,out);
}
static inline bool p25_cs_begin(p25_cs_store *s,uint32_t expected_revision) {
    if(!s->opened || !s->writable || s->staging || expected_revision!=s->revision)return false;
    unsigned bank=s->have_active ? s->active_bank^1u : s->have_legacy ? ((s->legacy_addr-s->flash->map->settings_addr)/P25_CS_BANK_BYTES)^1u : 0u;
    uint8_t legacy[64],check[64],intent[8];memset(legacy,255,64);
    if(s->have_legacy && !s->flash->read(s->legacy_addr,legacy,64))return false;
    s->stage_bank=(uint8_t)bank;
    for(unsigned off=0;off<P25_CS_BANK_BYTES;off+=4096)if(!s->flash->erase(p25_cs_addr(s,bank,0)+off)) {s->writable=false;return false;}
    memset(intent,0,sizeof intent);pref_put(intent,P25_CS_V6_MAGIC);intent[4]=6;p25_cs_put16(intent+6,32);
    if(!s->flash->write(p25_cs_addr(s,bank,0),intent,8) || !p25_cs_read_slot(s,bank,0,check) || memcmp(intent,check,8)
       || (s->have_legacy && !s->flash->write(p25_cs_addr(s,bank,1),legacy,64))
       || !p25_cs_read_slot(s,bank,1,check) || memcmp(legacy,check,64)) {s->writable=false;return false;}
    memset(s->staged,0,sizeof s->staged);s->staging=true;return true;
}
static inline bool p25_cs_stage_read(const p25_cs_store *s,unsigned key,uint8_t *out) {
    if(!s->staging || key>=P25_CS_RECORDS)return false;
    if(!(s->staged[key/8]&(1u<<(key%8))))return p25_cs_read(s,key,out);
    return s->flash->read(p25_cs_record_addr(s,s->stage_bank,key),out,32) && p25_cs_record_valid(key,out);
}
static inline bool p25_cs_stage_write(p25_cs_store *s,unsigned key,const uint8_t *record) {
    if(!s->staging || !s->writable || !p25_cs_record_valid(key,record))return false;
    uint8_t check[32];uint32_t addr=p25_cs_record_addr(s,s->stage_bank,key);
    if(s->staged[key/8]&(1u<<(key%8)))return s->flash->read(addr,check,32) && !memcmp(record,check,32);
    if(!s->flash->write(addr,record,32) || !s->flash->read(addr,check,32) || memcmp(record,check,32)) {s->writable=false;s->staging=false;return false;}
    s->staged[key/8]|=(uint8_t)(1u<<(key%8));return true;
}
static inline bool p25_cs_stage_crc(const p25_cs_store *s,uint32_t *result) {
    uint8_t record[32];uint32_t crc=~0u;
    for(unsigned key=0;key<P25_CS_RECORDS;++key) {
        if(!(s->staging ? p25_cs_stage_read(s,key,record) : p25_cs_read(s,key,record)) || !p25_cs_record_valid(key,record))return false;
        crc=p25_cs_crc_add(crc,record,32);
    }
    *result=crc^~0u;return true;
}
static inline void p25_cs_abort(p25_cs_store *s) {s->staging=false;}
static inline bool p25_cs_stage_reader(const void *context,unsigned key,uint8_t *out) {return p25_cs_stage_read(context,key,out);}
static inline bool p25_cs_commit(p25_cs_store *s,uint32_t expected_crc) {
    uint8_t b[64],record[32],check[64];uint32_t crc;
    if(!s->staging || !s->writable || !p25_cs_stage_crc(s,&crc) || crc!=expected_crc || !p25_cs_image_valid(p25_cs_stage_reader,s))return false;
    for(unsigned key=0;key<P25_CS_RECORDS;++key)if(!(s->staged[key/8]&(1u<<(key%8))))
        if(!p25_cs_read(s,key,record) || !p25_cs_stage_write(s,key,record))return false;
    uint32_t confirmed;if(!p25_cs_stage_crc(s,&confirmed) || confirmed!=crc || !p25_cs_read_slot(s,s->stage_bank,1,b))return false;
    uint32_t bank_crc=p25_cs_crc_add(crc^~0u,b,64)^~0u;
    memset(b,0,64);pref_put(b,P25_CS_V6_MAGIC);b[4]=6;p25_cs_put16(b+6,32);pref_put(b+8,s->revision+1u);pref_put(b+12,crc);
    p25_cs_put16(b+16,P25_CS_RECORDS);p25_cs_put16(b+18,P25_CS_PAYLOAD_BYTES);pref_put(b+20,bank_crc);pref_put(b+56,pref_crc(b,56));
    uint32_t addr=p25_cs_addr(s,s->stage_bank,0);
    if(!s->flash->write(addr,b,60) || !s->flash->read(addr,check,60) || memcmp(b,check,60)
       || !s->flash->write(addr+60,b+60,4) || !p25_cs_read_slot(s,s->stage_bank,0,check) || memcmp(b,check,64)) {s->writable=false;s->staging=false;return false;}
    s->active_bank=s->stage_bank;s->active_version=6;s->revision++;s->have_active=true;s->staging=false;
    s->selection_valid=false;s->selection_next=0;
    if(s->have_legacy)s->legacy_addr=p25_cs_addr(s,s->active_bank,1);
    return true;
}
static inline bool p25_cs_selection_reader(const void *context,unsigned key,uint8_t *out) {return p25_cs_read(context,key,out);}
static inline bool p25_cs_save_selection(p25_cs_store *s,const uint8_t *global) {
    uint8_t previous[32],entry[32],check[32];
    if(!s->opened || !s->writable || s->staging || !p25_cs_read(s,P25_CS_GLOBAL,previous)
       || !p25_cs_selection_only(previous,global) || !p25_cs_selection_refs(p25_cs_selection_reader,s,global))return false;
    if(!memcmp(previous,global,32))return true;
    if(!s->have_active || s->active_version!=6 || s->selection_next>=P25_CS_SELECTION_SLOTS) {
        uint32_t crc;
        bool ok=p25_cs_begin(s,s->revision) && p25_cs_stage_write(s,P25_CS_GLOBAL,global)
            && p25_cs_stage_crc(s,&crc) && p25_cs_commit(s,crc);
        if(!ok)p25_cs_abort(s);
        return ok;
    }
    memset(entry,0,32);pref_put(entry,P25_CS_SELECTION_MAGIC);pref_put(entry+4,s->revision);
    p25_cs_selection_pack(entry+8,global);pref_put(entry+24,pref_crc(entry,24));
    uint32_t addr=p25_cs_addr(s,s->active_bank,0)+P25_CS_USED_BYTES+s->selection_next*P25_CS_SELECTION_BYTES;
    // Read once before programming; never overwrite an occupied/torn slot.
    if(!s->flash->read(addr,check,32) || !p25_cs_ff(check,32)) {s->writable=false;return false;}
    s->selection_next++;
    if(!s->flash->write(addr,entry,8) || !s->flash->write(addr+8,entry+8,20)
       || !s->flash->read(addr,check,28) || memcmp(check,entry,28)
       || !s->flash->write(addr+28,entry+28,4) || !s->flash->read(addr,check,32) || memcmp(check,entry,32)) {
        s->writable=false;return false;
    }
    memcpy(s->selection,entry+8,7);s->selection_valid=true;return true;
}
#endif
