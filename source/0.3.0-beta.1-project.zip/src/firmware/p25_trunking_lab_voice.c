// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_lab_voice.h"
#include <string.h>

_Static_assert(sizeof(p25_lab_voice)<=96u,"Finite lab voice exceeds compact RAM budget");

static bool within(uint32_t now,uint32_t then,uint32_t limit) {
    // Each interval is below INT32_MAX. Backwards/implausible clocks fail too;
    // ordinary modulo32 wrap is valid without treating timestamp zero as absent.
    return (uint32_t)(now-then)<limit;
}
static bool advanced(uint32_t now,uint32_t then) {
    return now && now!=then && within(now,then,0x80000000u);
}
static bool owner_valid(const p25_lab_exchange_owner *o) {
    return o && o->sequence && o->owner_tag && o->radio_id && o->radio_id<0xffffffu
        && o->request==P25_LAB_GROUP && o->group
        && o->wacn==P25_TRUNK_LAB_WACN && o->system==P25_TRUNK_LAB_SYSTEM
        && o->expected_channel==P25_LAB_VOICE_CHANNEL && o->expected_options==P25_LAB_VOICE_OPTIONS
        && p25_trunking_lab_matches(o->profile,o->control_rx_hz,o->control_tx_hz,o->nac);
}
bool p25_lab_voice_owned(const p25_lab_voice *s) {
    return s && ((s->phase>=P25_LAB_VOICE_ARMED && s->phase<=P25_LAB_VOICE_RETURN)
        || s->needs_rf_off);
}
static void fail(p25_lab_voice *s,p25_lab_voice_reason why) {
    s->phase=P25_LAB_VOICE_FAILED;s->reason=(uint8_t)why;s->finish_phase=P25_LAB_VOICE_FAILED;
}
bool p25_lab_voice_arm(p25_lab_voice *s,bool enabled,const p25_lab_exchange *e) {
    if(!s || !e || p25_lab_voice_owned(s) || e->phase!=P25_LAB_PREPARED
       || !e->owner.sequence || (s->owner.sequence && !advanced(e->owner.sequence,s->owner.sequence))
       || (enabled && !owner_valid(&e->owner)))return false;
    p25_lab_voice next={0};next.owner=e->owner;
    next.phase=enabled ? P25_LAB_VOICE_ARMED:P25_LAB_VOICE_IDLE;
    next.finish_phase=P25_LAB_VOICE_DONE;*s=next;return true;
}
static bool reply_matches(const p25_lab_voice *s,const p25_lab_exchange *e) {
    return e && owner_valid(&e->owner) && p25_lab_exchange_owner_matches(e,&s->owner)
        && e->phase==P25_LAB_REPLY && e->reason==P25_LAB_OK
        && e->reply_type==P25_TRUNK_OSP_GROUP_GRANT && !e->response
        && e->replies && e->replies<=P25_LAB_EXCHANGE_MAX_REPLIES
        && e->reply_source==s->owner.radio_id && e->reply_group==s->owner.group
        && e->reply_channel==s->owner.expected_channel && e->reply_options==s->owner.expected_options
        && advanced(e->rx_epoch,e->previous_epoch)
        && within(e->rx_ready_us,e->cutoff_us,P25_LAB_EXCHANGE_RETURN_US)
        && within(e->reply_us,e->rx_ready_us,P25_LAB_EXCHANGE_REPLY_US)
        && within(e->reply_us,e->cutoff_us,P25_LAB_EXCHANGE_REPLY_US);
}
bool p25_lab_voice_offer(p25_lab_voice *s,const p25_lab_exchange *e,uint32_t now) {
    if(!s || s->phase!=P25_LAB_VOICE_ARMED || !reply_matches(s,e))return false;
    if(!within(now,e->reply_us,P25_LAB_VOICE_LEASE_US)) {
        fail(s,P25_LAB_VOICE_LEASE);return false;
    }
    s->grant_epoch=e->rx_epoch;s->grant_us=e->reply_us;s->phase=P25_LAB_VOICE_GRANTED;return true;
}
bool p25_lab_voice_take(p25_lab_voice *s,const p25_lab_exchange *e,
    const p25_lab_exchange_owner *current,uint32_t epoch,bool permission,
    bool ptt_permitted,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_VOICE_GRANTED)return false;
    p25_lab_voice_reason why=P25_LAB_VOICE_OK;
    if(!reply_matches(s,e) || !current || !p25_lab_exchange_owner_matches(e,current)
       || e->reply_us!=s->grant_us || e->rx_epoch!=s->grant_epoch)why=P25_LAB_VOICE_OWNER;
    else if(epoch!=s->grant_epoch)why=P25_LAB_VOICE_EPOCH;
    else if(!permission)why=P25_LAB_VOICE_PERMISSION;
    else if(!ptt_permitted)why=P25_LAB_VOICE_PTT;
    else if(!off)why=P25_LAB_VOICE_RF_NOT_OFF;
    else if(!within(now,s->grant_us,P25_LAB_VOICE_LEASE_US))why=P25_LAB_VOICE_LEASE;
    if(why!=P25_LAB_VOICE_OK) {fail(s,why);return false;}
    // This transition spends the sole action BEFORE the adapter may key.
    s->start_us=now;s->needs_rf_off=1;s->phase=P25_LAB_VOICE_TAKEN;return true;
}
bool p25_lab_voice_key_allowed(const p25_lab_voice *s,uint32_t now) {
    return s && (s->phase==P25_LAB_VOICE_TAKEN || s->phase==P25_LAB_VOICE_VOICE) && s->needs_rf_off
        && within(now,s->grant_us,P25_LAB_VOICE_LEASE_US)
        && within(now,s->start_us,P25_LAB_VOICE_RF_MAX_US);
}
bool p25_lab_voice_rf_started(p25_lab_voice *s,uint32_t now) {
    if(!s || s->phase!=P25_LAB_VOICE_TAKEN)return false;
    if(!p25_lab_voice_key_allowed(s,now)) {fail(s,P25_LAB_VOICE_LEASE);return false;}
    s->rf_us=now;s->phase=P25_LAB_VOICE_VOICE;return true;
}
void p25_lab_voice_poll(p25_lab_voice *s,uint32_t now) {
    if(!s)return;
    if(s->phase==P25_LAB_VOICE_GRANTED || s->phase==P25_LAB_VOICE_TAKEN) {
        if(!within(now,s->grant_us,P25_LAB_VOICE_LEASE_US))fail(s,P25_LAB_VOICE_LEASE);
    } else if(s->phase==P25_LAB_VOICE_VOICE || s->phase==P25_LAB_VOICE_DRAIN) {
        if(!within(now,s->start_us,P25_LAB_VOICE_RF_MAX_US))fail(s,P25_LAB_VOICE_RF_LIMIT);
    } else if(s->phase==P25_LAB_VOICE_RETURN
              && !within(now,s->return_us,P25_LAB_VOICE_RETURN_US))fail(s,P25_LAB_VOICE_EPOCH);
}
bool p25_lab_voice_drain(p25_lab_voice *s,uint32_t now) {
    if(!s || s->phase!=P25_LAB_VOICE_VOICE)return false;
    p25_lab_voice_poll(s,now);if(s->phase!=P25_LAB_VOICE_VOICE)return false;
    s->phase=P25_LAB_VOICE_DRAIN;return true;
}
bool p25_lab_voice_tx_done(p25_lab_voice *s,bool success,bool off,uint32_t now) {
    if(!s || !s->needs_rf_off)return false;
    if(!off) {fail(s,P25_LAB_VOICE_RF_NOT_OFF);return false;}
    bool accepted=true;
    if(success) {
        p25_lab_voice_poll(s,now);
        if(s->phase!=P25_LAB_VOICE_DRAIN) {
            if(s->reason==P25_LAB_VOICE_OK)fail(s,P25_LAB_VOICE_TRANSPORT);
            accepted=false;
        }
    } else if(s->reason==P25_LAB_VOICE_OK)fail(s,P25_LAB_VOICE_TRANSPORT);
    s->end_us=now;s->return_us=now;s->needs_rf_off=0;s->phase=P25_LAB_VOICE_RETURN;
    return accepted;
}
bool p25_lab_voice_return_ready(p25_lab_voice *s,uint32_t epoch,bool raw,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_VOICE_RETURN)return false;
    if(!off) {fail(s,P25_LAB_VOICE_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    p25_lab_voice_poll(s,now);if(s->phase!=P25_LAB_VOICE_RETURN)return false;
    if(!raw || !advanced(epoch,s->grant_epoch))return false;
    s->return_epoch=epoch;s->ready_us=now;s->phase=s->finish_phase;return true;
}
void p25_lab_voice_cancel(p25_lab_voice *s,p25_lab_voice_reason why) {
    if(!p25_lab_voice_owned(s))return;
    s->reason=(uint8_t)(why==P25_LAB_VOICE_OK ? P25_LAB_VOICE_CANCEL:why);
    s->finish_phase=P25_LAB_VOICE_CANCELLED;
    if(s->phase!=P25_LAB_VOICE_RETURN)s->phase=P25_LAB_VOICE_CANCELLED;
}
bool p25_lab_voice_abort_off(p25_lab_voice *s,bool off,uint32_t now) {
    if(!s || !p25_lab_voice_owned(s))return false;
    if(!off) {fail(s,P25_LAB_VOICE_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    if(s->reason==P25_LAB_VOICE_OK)s->reason=P25_LAB_VOICE_CANCEL;
    s->end_us=now;s->needs_rf_off=0;s->finish_phase=P25_LAB_VOICE_CANCELLED;
    s->phase=P25_LAB_VOICE_CANCELLED;return true;
}
