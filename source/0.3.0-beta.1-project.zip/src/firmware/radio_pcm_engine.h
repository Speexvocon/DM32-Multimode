// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_PCM_ENGINE_H
#define RADIO_PCM_ENGINE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// DP v1: COBS packet followed by zero. Decoded bytes are magic 'D','P',
// version=1,type,flags:u16,payload_bytes:u16,session:u32,sequence:u32,
// sample_index:u32,crc32:u32,payload. Integers/PCM are little-endian.
// CRC32 (IEEE/zlib) covers decoded bytes [0,20) then payload [24,end).
// PCM is exactly 160 signed16 samples (20 ms at 8 kHz), never executable code.
#define RADIO_PCM_SAMPLES 160u
#define RADIO_PCM_PAYLOAD 320u
#define RADIO_PCM_HEADER 24u
#define RADIO_PCM_PACKET (RADIO_PCM_HEADER+RADIO_PCM_PAYLOAD)
#define RADIO_PCM_WIRE_MAX 347u
#define RADIO_PCM_QUEUE 8u
#define RADIO_PCM_CAPACITY 7u
#define RADIO_PCM_PREFILL 4u
#define RADIO_PCM_TIMEOUT_MS 200u
#define RADIO_PCM_DRAIN_TIMEOUT_MS 2500u
#define RADIO_PCM_WRITE_BUDGET 96u

typedef enum {RADIO_PCM_HELLO=1,RADIO_PCM_START,RADIO_PCM_DATA,RADIO_PCM_STOP,
              RADIO_PCM_END,RADIO_PCM_ACK,RADIO_PCM_STATUS,RADIO_PCM_ERROR} radio_pcm_type;
typedef enum {RADIO_PCM_RAW=0,RADIO_PCM_VOICE=1} radio_pcm_mode;
enum {RADIO_PCM_RX=1u,RADIO_PCM_TX=2u};
typedef enum {RADIO_PCM_FM=0,RADIO_PCM_NFM,RADIO_PCM_P25,RADIO_PCM_DMR} radio_pcm_modulation;
typedef enum {RADIO_PCM_CLOSED=0,RADIO_PCM_READY,RADIO_PCM_RUNNING,
              RADIO_PCM_DRAINING,RADIO_PCM_STOPPED,RADIO_PCM_FAULT} radio_pcm_state;
typedef enum {RADIO_PCM_OK=0,RADIO_PCM_BAD_FRAME,RADIO_PCM_BAD_CRC,
              RADIO_PCM_BAD_SESSION,RADIO_PCM_BAD_SEQUENCE,RADIO_PCM_BAD_CONFIG,
              RADIO_PCM_FULL,RADIO_PCM_POLICY,RADIO_PCM_UNDERRUN,
              RADIO_PCM_TIMEOUT,RADIO_PCM_TOT,RADIO_PCM_HAL} radio_pcm_error;

typedef struct {
    uint32_t session,tot_ms;
    uint8_t mode,operations,modulation;
} radio_pcm_config;

typedef struct {
    void *context;
    // Main context only. Root validates selected channel, TX permission and
    // independent RF guard; returning false never grants RF permission.
    bool (*start_rx)(void *,const radio_pcm_config *);
    bool (*start_tx)(void *,const radio_pcm_config *);
    // stop_tx must immediately unkey even when called by an audio ISR. Defer
    // any blocking teardown to the board service; stop_all is task-only.
    void (*stop_tx)(void *);
    void (*stop_all)(void *);
    // Nonblocking, may accept fewer bytes or zero. At most 96 per poll.
    size_t (*write)(void *,const uint8_t *,size_t);
    uint32_t (*lock)(void *);
    void (*unlock)(void *,uint32_t);
} radio_pcm_hal;

typedef struct {
    int16_t pcm[RADIO_PCM_QUEUE][RADIO_PCM_SAMPLES];
    volatile uint8_t head,tail;
} radio_pcm_queue;

typedef struct {
    radio_pcm_hal hal;
    radio_pcm_config config;
    // One half-duplex RF direction per session; these buffers never coexist.
    union {radio_pcm_queue rx,tx;};
    uint32_t rx_sequence[RADIO_PCM_QUEUE],rx_index[RADIO_PCM_QUEUE];
    uint32_t rx_frames,tx_frames,dropped,underruns,bad_frames;
    uint32_t next_tx_sequence,rx_next_sequence,rx_next_index,rx_output_next_sequence;
    uint32_t opened_ms,started_ms,last_data_ms,last_rx_ms,end_ms;
    uint32_t ack_sequence[9];
    volatile uint16_t pending;
    uint16_t output_used,output_sent,input_used;
    uint8_t input[RADIO_PCM_WIRE_MAX],output[RADIO_PCM_WIRE_MAX];
    volatile radio_pcm_state state;
    radio_pcm_error error,pending_error;
    bool input_discard;
    volatile bool tx_started,rx_started,end_received,stop_all_pending;
} radio_pcm_engine;

// No boot I/O or allocation. Feed/poll have one task owner. Optional HAL locks
// protect short queue copies/metadata, never RF/UART callbacks. Required when
// audio callbacks may preempt the owner. Callbacks may not reenter this engine.
// PCM push/pop only copy bounded data; no framing/UART/DSP.
void radio_pcm_engine_init(radio_pcm_engine *,const radio_pcm_hal *);
bool radio_pcm_engine_open(radio_pcm_engine *,const radio_pcm_config *,uint32_t now_ms);
void radio_pcm_engine_feed(radio_pcm_engine *,const uint8_t *,size_t,uint32_t now_ms);
void radio_pcm_engine_poll(radio_pcm_engine *,uint32_t now_ms,size_t write_budget);
bool radio_pcm_engine_rx_push(radio_pcm_engine *,const int16_t pcm[160],uint32_t now_ms);
bool radio_pcm_engine_tx_pop(radio_pcm_engine *,int16_t pcm[160]);
bool radio_pcm_engine_tx_eof(const radio_pcm_engine *);
// Called after native hardware's final drain / digital terminator,
// not immediately after copying the last queued frame into the hardware.
bool radio_pcm_engine_tx_finish(radio_pcm_engine *);
unsigned radio_pcm_engine_tx_credit(const radio_pcm_engine *);
// Immediate stop, with a STOP acknowledgment queued for normal poll output.
void radio_pcm_engine_stop(radio_pcm_engine *);
// IRQ-safe fault path: immediate unkey plus deferred task-context teardown.
void radio_pcm_engine_abort(radio_pcm_engine *,radio_pcm_error);
bool radio_pcm_engine_output_idle(const radio_pcm_engine *);
uint32_t radio_pcm_engine_crc(const uint8_t *,size_t);
#define radio_pcm_tx_take radio_pcm_engine_tx_pop
#define radio_pcm_rx_push radio_pcm_engine_rx_push

// HELLO payload16: rate:u32=8000,samples:u16=160,capacity:u16=7,
// maxpayload:u16=320,modulation:u8,supported_modes:u8 (RAW1/VOICE2),reserved:u32.
// ACK/STATUS/ERROR payload24: ack_type:u8,state:u8,tx_credit:u16,
// rx_frames:u32,tx_frames:u32,dropped:u32,underruns:u32,next_tx_sequence:u32.
// RX DATA flags bit0 marks a discontinuity relative to the previous output;
// sequence/sample_index also advance across dropped capture frames.
// ACK header sequence echoes last accepted input of its type; sample_index is
// next_tx_sequence*160 (wrapping). ERROR header flags contains radio_pcm_error.
// START payload8: mode:u8,operations:u8,modulation:u8,reserved=0,tot_ms:u32.
// Must match OPEN; zero TOT selects OPEN's channel TOT. TX DATA is accepted in
// READY before START, which requires four frames before starting native TX.
// DATA sequence starts at0, sample_index=sequence*160 wrapping. END has no
// payload, sequence=next_tx_sequence,sample_index=sequence*160; it stops only
// after queued PCM is consumed AND native owner calls tx_finish after final
// hardware/digital drain (bounded 2500 ms). Empty pop after END is not a fault
// and does not finish implicitly. ACK END is emitted after native unkey.
// STOP is always accepted for the current session regardless of its sequence.
#endif
