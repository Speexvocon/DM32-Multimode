// SPDX-License-Identifier: GPL-3.0-or-later
// One explicit laboratory PTT intent. No registration, affiliation, access-slot
// qualification or RF authority is established by this policy.
#ifndef P25_TRUNKING_LAB_PTT_H
#define P25_TRUNKING_LAB_PTT_H
#include "p25_trunking_lab_voice.h"

#define P25_LAB_PTT_ARM_US 60000000u
#define P25_LAB_PTT_REQUEST_US 10000000u
#define P25_LAB_PTT_VOICE_US P25_LAB_VOICE_RF_MAX_US
#define P25_LAB_PTT_RETURN_US P25_LAB_VOICE_RETURN_US

typedef enum {
    P25_LAB_PTT_IDLE,P25_LAB_PTT_ARMED,P25_LAB_PTT_REQUEST,
    P25_LAB_PTT_GRANTED,P25_LAB_PTT_VOICE,P25_LAB_PTT_DRAIN,
    P25_LAB_PTT_RETURN,P25_LAB_PTT_DONE,P25_LAB_PTT_CANCELLED,
    P25_LAB_PTT_FAILED
} p25_lab_ptt_phase;
typedef enum {
    P25_LAB_PTT_OK,P25_LAB_PTT_CONFIG,P25_LAB_PTT_OWNER,
    P25_LAB_PTT_EPOCH,P25_LAB_PTT_PERMISSION,P25_LAB_PTT_RELEASE,
    P25_LAB_PTT_EXPIRED,P25_LAB_PTT_TRANSPORT,P25_LAB_PTT_RF_NOT_OFF,
    P25_LAB_PTT_CANCEL
} p25_lab_ptt_reason;
typedef enum {
    P25_LAB_PTT_NONE,P25_LAB_PTT_SEND_REQUEST,P25_LAB_PTT_BEGIN_DRAIN,
    P25_LAB_PTT_ABORT
} p25_lab_ptt_action;
typedef struct {
    p25_lab_exchange_owner owner;
    uint32_t arm_epoch,request_epoch,grant_epoch,return_epoch;
    uint32_t arm_us,request_us,prepared_us,grant_us,voice_us,end_us,ready_us;
    uint8_t phase,reason,last_down,needs_rf_off,finish_phase,spent;
} p25_lab_ptt;

bool p25_lab_ptt_owned(const p25_lab_ptt *s);
// A forward sequence, released physical PTT and RF-off are mandatory. An
// unspent arm (no successful PREPARE binding) may reuse its future sequence.
// The entire exact GROUP owner is copied; later current-owner mutations fail.
bool p25_lab_ptt_arm(p25_lab_ptt *s,const p25_lab_exchange_owner *owner,
    uint32_t epoch,bool ptt_down,bool rf_off,uint32_t now_us);
// Called with a qualified physical input sample. SEND_REQUEST is returned once,
// on a new rising edge after ARM; releasing before actual voice cancels forever.
p25_lab_ptt_action p25_lab_ptt_input(p25_lab_ptt *s,
    const p25_lab_exchange_owner *current,bool ptt_down,bool permission,uint32_t now_us);
// PREPARE may stop the old recorder and advance its epoch. Bind its exact
// evidence once BEFORE FIRE, spending the sequence without rewriting the
// original ARM epoch or press timestamp.
bool p25_lab_ptt_bind_prepared(p25_lab_ptt *s,const p25_lab_exchange *prepared,
    const p25_lab_exchange_owner *current,uint32_t now_us);
// Exact already-native-validated exchange evidence is required in addition to
// the frozen owner, fresh recorder epoch and a still-held physical PTT sample.
bool p25_lab_ptt_grant(p25_lab_ptt *s,const p25_lab_exchange *reply,
    const p25_lab_exchange_owner *current,bool ptt_down,bool permission,uint32_t now_us);
// Read-only exception to a released-PTT gate, scoped to this exact live intent.
// It never substitutes for existing timing, lease, permission or RF-off gates.
bool p25_lab_ptt_allow_held(const p25_lab_ptt *s,
    const p25_lab_exchange_owner *current,bool ptt_down,uint32_t now_us);
// Actual PA observation, not dispatch or timer arm. Timestamp zero is valid.
bool p25_lab_ptt_voice_started(p25_lab_ptt *s,
    const p25_lab_exchange_owner *current,bool ptt_down,uint32_t now_us);
// Also used for the existing finite MIC cap while PTT remains held.
bool p25_lab_ptt_drain(p25_lab_ptt *s,uint32_t now_us);
bool p25_lab_ptt_tx_done(p25_lab_ptt *s,bool success,bool rf_off,uint32_t now_us);
bool p25_lab_ptt_return_ready(p25_lab_ptt *s,uint32_t epoch,bool raw_input,
    bool rf_off,uint32_t now_us);
void p25_lab_ptt_poll(p25_lab_ptt *s,uint32_t now_us);
void p25_lab_ptt_cancel(p25_lab_ptt *s,p25_lab_ptt_reason reason);
// Explicit STOP can relinquish a cancelled intent only after real RF-off,
// without inventing a normal return epoch or DONE observation.
bool p25_lab_ptt_abort_off(p25_lab_ptt *s,bool rf_off,uint32_t now_us);
#endif
