// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_backend.h"
#include <string.h>

_Static_assert(sizeof(p25_trunking_backend)<=80u,"Subscriber backend state exceeds budget");
static bool control_action(p25_trunking_access_action_type type) {
    return type==P25_TRUNK_ACTION_REGISTER||type==P25_TRUNK_ACTION_AFFILIATE
        ||type==P25_TRUNK_ACTION_GROUP_REQUEST||type==P25_TRUNK_ACTION_DEREGISTER;
}
static void revoke_anchor(p25_trunking_backend *b) {b->have_anchor=false;}
bool p25_trunking_backend_start(p25_trunking_backend *b,p25_trunking_session *s,
    const p25_trunking_session_config *config,p25_trunking_backend_mode mode,uint32_t now) {
    if(!b||!s||b->running||b->inflight||mode<P25_TRUNK_BACKEND_QUALIFIED
       ||mode>P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL||!p25_trunking_session_start(s,config,now))return false;
    memset(b,0,sizeof *b);b->mode=mode;b->running=true;b->skip_remaining=config->contention_skip;return true;
}
bool p25_trunking_backend_observe(p25_trunking_backend *b,p25_trunking_session *s,
    const p25_trunking_slot_observation *o,uint32_t now) {
    if(!b||!s||!b->running||b->suspended)return false;
    if(o&&(o->stream_epoch!=b->anchor_epoch||o->lane_epoch!=b->anchor_lane_epoch)) {
        revoke_anchor(b);b->have_anchor_used=false;b->anchor_epoch=o->stream_epoch;b->anchor_lane_epoch=o->lane_epoch;
    }
    const p25_trunking_slot *slot=&s->slot;
    bool chain=o&&slot->have_boundary&&slot->have_status&&slot->status==2u&&slot->microslots==4u
        &&o->sample_tick>=slot->boundary_tick;
    uint64_t period=chain?o->sample_tick-slot->boundary_tick:0u;
    bool valid=p25_trunking_session_observe(s,o);
    if(!valid||!s->slot.have_boundary||!s->slot.coherent) {
        revoke_anchor(b);b->skip_remaining=s->config.contention_skip;return valid;
    }
    if(b->mode!=P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL||b->inflight||!o||o->status!=3u)return valid;
    if(!chain||period<1785u||period>1815u) {revoke_anchor(b);return valid;}
    if(b->anchor_serial!=s->access.serial) {
        b->anchor_serial=s->access.serial;b->skip_remaining=s->config.contention_skip;
    }
    if(b->skip_remaining) {--b->skip_remaining;return valid;}
    b->anchor_tick=o->sample_tick;b->anchor_epoch=o->stream_epoch;b->anchor_lane_epoch=o->lane_epoch;
    b->anchor_ms=now;b->have_anchor=true;return valid;
}
bool p25_trunking_backend_consume_control(p25_trunking_backend *b,p25_trunking_session *s,
    uint16_t nac,uint32_t hz,uint32_t epoch,const uint8_t block[12],uint32_t now) {
    if(!b||!s||!b->running||!block)return false;
    p25_trunking_osp event;
    if(p25_trunking_osp_parse(block,&event)&&event.type!=P25_TRUNK_OSP_UNSUPPORTED) {
        // Replies from pre-request samples/epochs cannot acknowledge a later
        // transaction, even if their CRC and addresses happen to match.
        if(b->inflight||!b->reply_epoch||epoch!=b->reply_epoch||b->suspended)return false;
    }
    bool consumed=p25_trunking_session_consume_control(s,nac,hz,block,now);
    if(b->reacquiring&&s->site_qualified)b->reacquiring=false;
    return consumed;
}
void p25_trunking_backend_poll(p25_trunking_backend *b,p25_trunking_session *s,
    uint32_t now,const p25_trunking_session_clock *clock,bool allowed,bool ptt) {
    if(!b||!s||!b->running)return;
    if(b->receive_suspended||b->reacquiring) {
        s->access.ptt_down=ptt;s->access.release_required=true;s->access.action_eligible=false;
        s->access.idle=s->access.experimental_opportunity=false;s->opportunity=s->have_poll=false;
        if(b->reacquiring&&now-b->resume_ms>=P25_TRUNK_ACCESS_SITE_MS) {
            p25_trunking_access_fault(&s->access,P25_TRUNK_ACCESS_SITE_LOST,now);b->reacquiring=false;
        }
        return;
    }
    if(b->mode==P25_TRUNK_BACKEND_QUALIFIED) {
        p25_trunking_session_poll(s,now,clock,allowed,ptt);return;
    }
    p25_trunking_slot_boundary_view anchor={0};const p25_trunking_slot_boundary_view *available=NULL;
    if(b->have_anchor&&!b->inflight&&!b->suspended&&clock&&now-b->anchor_ms<=48u
       &&clock->stream_epoch==b->anchor_epoch&&clock->lane_epoch==b->anchor_lane_epoch
       &&clock->now_tick>=b->anchor_tick&&clock->now_tick-b->anchor_tick<=2304u
       &&(!b->have_anchor_used||b->last_anchor_used!=b->anchor_tick)
       &&b->anchor_tick<=UINT64_MAX-P25_TRUNK_SLOT_MIN_TICKS) {
        anchor.boundary_tick=b->anchor_tick;anchor.earliest_end_tick=b->anchor_tick+P25_TRUNK_SLOT_MIN_TICKS;
        anchor.stream_epoch=b->anchor_epoch;anchor.lane_epoch=b->anchor_lane_epoch;available=&anchor;
    } else if(b->have_anchor&&now-b->anchor_ms>48u)revoke_anchor(b);
    p25_trunking_session_poll_nominal(s,now,clock,allowed,ptt,available);
}
bool p25_trunking_backend_take(p25_trunking_backend *b,p25_trunking_session *s,
    p25_trunking_backend_action *out,uint32_t now,const p25_trunking_session_clock *clock) {
    if(!b||!s||!out||!b->running||b->receive_suspended||b->reacquiring)return false;
    bool cleanup=s->access.phase==P25_TRUNK_ACCESS_DRAIN||s->access.phase==P25_TRUNK_ACCESS_RETURN;
    if(b->inflight&&(!cleanup||s->access.outstanding))return false;
    p25_trunking_backend_action value={0};
    bool taken=b->mode==P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL
        ?p25_trunking_session_take_nominal(s,&value.session,now,clock)
        :p25_trunking_session_take(s,&value.session,now,clock);
    if(!taken)return false;
    value.experimental_nominal=b->mode==P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL;
    if(control_action(value.session.access.type)) {
        p25_trunking_preload_plan plan;p25_trunking_preload_config config={0,0,0};
        if(!p25_trunking_preload_plan_make(&plan,&config)
           ||!p25_trunking_preload_render(&plan,value.session.tsdu,value.native_ram)) {
            (void)p25_trunking_session_result(s,value.session.access.id,false,now);return false;
        }
        uint32_t hash=2166136261u;
        for(unsigned i=0;i<sizeof value.native_ram;++i)hash=(hash^value.native_ram[i])*16777619u;
        value.image_hash=hash;b->last_anchor_used=value.session.budget.observed.boundary_tick;b->have_anchor_used=true;
        b->reply_epoch=0;revoke_anchor(b);
    }
    b->action_id=value.session.access.id;b->action_type=value.session.access.type;
    b->dispatch_epoch=value.session.stream_epoch;b->inflight=true;b->suspended=false;
    *out=value;return true;
}
bool p25_trunking_backend_suspend(p25_trunking_backend *b,const p25_trunking_session *s,uint32_t id) {
    if(!b||!s||!b->running||!b->inflight||!id||id!=b->action_id
       ||s->access.outstanding_id!=id||s->access.outstanding!=b->action_type)return false;
    b->suspended=true;revoke_anchor(b);return true;
}
bool p25_trunking_backend_receive_suspend(p25_trunking_backend *b,p25_trunking_session *s) {
    if(!b||!s||!b->running||b->inflight||b->suspended||b->receive_suspended||b->reacquiring
       ||s->access.phase!=P25_TRUNK_ACCESS_READY||!s->access.registered||!s->access.affiliated
       ||s->access.ptt_down||s->access.outstanding||s->access.want_voice||s->access.voice_running)return false;
    b->receive_epoch=b->reply_epoch?b->reply_epoch:s->clock.stream_epoch;
    if(!b->receive_epoch)return false;
    b->receive_suspended=b->suspended=true;revoke_anchor(b);
    s->have_poll=s->opportunity=s->fit=false;s->access.action_eligible=false;
    s->access.idle=s->access.experimental_opportunity=false;p25_trunking_slot_lost(&s->slot);
    p25_trunking_slot_backoff_cancel(&s->backoff);return true;
}
bool p25_trunking_backend_receive_resume(p25_trunking_backend *b,p25_trunking_session *s,
    uint32_t epoch,uint32_t now) {
    if(!b||!s||!b->running||!b->receive_suspended||!b->suspended||b->inflight
       ||!epoch||epoch==b->receive_epoch)return false;
    b->reply_epoch=epoch;b->receive_suspended=b->suspended=false;b->reacquiring=true;b->resume_ms=now;
    s->have_site=s->have_network=s->site_qualified=false;s->map.have_site=s->map.have_network=false;
    s->have_poll=s->opportunity=s->fit=false;s->access.action_eligible=false;
    s->access.release_required=true;return true;
}
bool p25_trunking_backend_result(p25_trunking_backend *b,p25_trunking_session *s,
    uint32_t id,bool success,bool rf_off,bool rx_ready,uint32_t epoch,uint32_t now) {
    if(!b||!s||!b->running||!b->inflight||!id||id!=b->action_id
       ||id!=s->access.outstanding_id||s->access.outstanding!=b->action_type)return false;
    bool needs_rx=control_action(b->action_type)||b->action_type==P25_TRUNK_ACTION_RETURN_CONTROL;
    bool receipt=needs_rx?rf_off&&rx_ready&&epoch&&epoch!=b->dispatch_epoch
        :b->action_type==P25_TRUNK_ACTION_VOICE_STOP?rf_off:!rf_off&&!rx_ready;
    if((success&&!receipt)||(!success&&needs_rx&&!rf_off))return false;
    p25_trunking_access_action_type type=b->action_type;
    bool accepted=p25_trunking_session_result(s,id,success,now);
    if(!accepted)return false;
    b->inflight=s->access.outstanding_id==id;b->suspended=b->inflight;
    if(!b->inflight) {b->action_id=0;b->action_type=P25_TRUNK_ACTION_NONE;}
    if(success&&needs_rx)b->reply_epoch=epoch;
    revoke_anchor(b);
    if(success&&type==P25_TRUNK_ACTION_DEREGISTER) {
        p25_trunking_session_stop(s);b->running=false;b->suspended=false;
    }
    return true;
}
bool p25_trunking_backend_deregister(p25_trunking_backend *b,p25_trunking_session *s,uint32_t now) {
    if(!b||!s||!b->running||b->inflight||b->suspended||!p25_trunking_access_deregister(&s->access,now))return false;
    revoke_anchor(b);return true;
}
bool p25_trunking_backend_select_group(p25_trunking_backend *b,p25_trunking_session *s,uint16_t group,uint32_t now) {
    if(!b||!s||!b->running||b->inflight||b->suspended||!p25_trunking_session_select_group(s,group,now))return false;
    revoke_anchor(b);return true;
}
void p25_trunking_backend_cancel(p25_trunking_backend *b,p25_trunking_session *s,
    p25_trunking_access_reason why,uint32_t now) {
    if(!b||!s||!b->running)return;
    revoke_anchor(b);p25_trunking_access_fault(&s->access,why,now);
}
void p25_trunking_backend_lost(p25_trunking_backend *b,p25_trunking_session *s,uint32_t now) {
    if(!b||!s||!b->running)return;
    revoke_anchor(b);p25_trunking_session_lost(s,now);
}
bool p25_trunking_backend_stop(p25_trunking_backend *b,p25_trunking_session *s,bool rf_off) {
    if(!b||!s||!rf_off)return false;
    p25_trunking_session_stop(s);memset(b,0,sizeof *b);return true;
}
