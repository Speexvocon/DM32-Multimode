// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit finite laboratory preload. No subscriber or slotted-access authority.
#ifndef P25_TRUNKING_PRELOAD_LIVE_H
#define P25_TRUNKING_PRELOAD_LIVE_H
#if DM32_TRUNK_SUBSCRIBER
#include "p25_trunking_preload.h"
#include "p25_trunking_lab_exchange.h"

#define TRUNK_PRELOAD_ARM_CEILING_US 55000u
#define TRUNK_PRELOAD_RF_WAIT_US 50000u
#define TRUNK_PRELOAD_WARM_US 250000u
#define TRUNK_PRELOAD_CLOCK_LEAD_BYTES 16u
// Reproduce the measured marker condition for this explicit ISP comparison.
// This ordinal is not a native reader-half or control-channel-slot identity.
#define TRUNK_PRELOAD_CLOCK_FIRE_ORDINAL 3u
enum {TRUNK_PRELOAD_PHASE_ROW=5u,TRUNK_PRELOAD_CC_ROW=6u,TRUNK_PRELOAD_END_ROW=8u,TRUNK_PRELOAD_ROW_COUNT=9u};
// Both immutable lab profiles advertise identifier1/channel1 for the voice
// pair. This explicit observer does not resolve arbitrary site bandplans.
#define TRUNK_PRELOAD_GROUP_CHANNEL 0x1001u
#define TRUNK_PRELOAD_GROUP_OPTIONS 4u
enum {TRUNK_PRELOAD_VOICE_OFF,TRUNK_PRELOAD_VOICE_TONE,TRUNK_PRELOAD_VOICE_MIC};
static struct {
    uint32_t pa_delay_us,cut_delay_us;
    uint8_t first_half,lead_bytes,request,voice;
    bool rf_origin:1,configured:1,early:1,return_rx:1,phase:1,clock:1;
} trunk_preload_config;
_Static_assert(sizeof trunk_preload_config==16u,"Preload configuration grew its saved-owner copies");
static bool trunk_preload_clock_configured(void) {
    return trunk_preload_config.clock && trunk_preload_config.configured && !trunk_preload_config.phase
        && !trunk_preload_config.first_half && !trunk_preload_config.rf_origin
        && trunk_preload_config.pa_delay_us==5000u && trunk_preload_config.cut_delay_us==55000u
        && !trunk_preload_config.early && trunk_preload_config.return_rx
        && trunk_preload_config.lead_bytes==TRUNK_PRELOAD_CLOCK_LEAD_BYTES;
}
// A separate, manual REGISTER-only experiment. This is not accepted by the
// legacy predicate used by JOIN/PTT and does not qualify an access slot.
static bool trunk_preload_clock_compact_configured(void) {
    return trunk_preload_config.clock && trunk_preload_config.configured
        && !trunk_preload_config.phase && !trunk_preload_config.first_half
        && !trunk_preload_config.rf_origin && !trunk_preload_config.early
        && !trunk_preload_config.pa_delay_us && trunk_preload_config.cut_delay_us==37000u
        && trunk_preload_config.return_rx && !trunk_preload_config.lead_bytes
        && !trunk_preload_config.request && !trunk_preload_config.voice
        && trunk_lab_profile==P25_TRUNK_LAB_COMMONIQ1M
        && !trunk_lab_attach_selected() && !trunk_lab_ptt_selected();
}
enum {TRUNK_PRELOAD_CLOCK_NONE,TRUNK_PRELOAD_CLOCK_LEGACY,TRUNK_PRELOAD_CLOCK_COMPACT};
static volatile struct {
    uint32_t prepare_us,prepare_end_us,ack_end_us,switch_begin_us,switch_end_us,anchor_us;
    uint32_t requested_cut_us,cut_deadline_us,pa_deadline_us;
    uint32_t pa_irq_us,pa_late_us,cut_irq_us,cut_late_us,safe_us;
    uint32_t last_boundary_us;
    uint32_t warm_deadline_us,fire_begin_us,fire_gate_end_us;
    uint8_t boundaries,lead_bytes,request,voice_enabled,clock_profile;
    bool mode,guarded,anchored,shortened,early_requested,warmed,return_enabled,separate_warm;
} trunk_preload;
_Static_assert(sizeof trunk_preload<=96u,"Preload trace exceeds its compact budget");
enum {TRUNK_PRELOAD_NATIVE_ARM,TRUNK_PRELOAD_NATIVE_PHY_PRE,
    TRUNK_PRELOAD_NATIVE_PHY_POST,TRUNK_PRELOAD_NATIVE_CUT};
static volatile struct {
    uint32_t status[4],slots[4],valid;
} trunk_preload_native;
_Static_assert(sizeof trunk_preload_native==36u,"Preload native trace exceeds its separate budget");
// Explicit volatile RF-off timing experiment. A PHY ordinal is only a clock
// observation; the actual RAM reader position must be measured from RF.
static volatile struct {
    uint32_t image_us,first_us,last_us,launch_us,send_us,ram_hash;
    uint16_t count,fire_ordinal;
    bool selected,pending,marker;
    uint8_t owner;
} trunk_preload_phase;
_Static_assert(sizeof trunk_preload_phase<=32u,"Phase observer exceeds its compact budget");
enum {TRUNK_PRELOAD_OWNER_MANUAL,TRUNK_PRELOAD_OWNER_JOIN,TRUNK_PRELOAD_OWNER_PTT};
static void trunk_preload_phase_boundary(uint32_t now,unsigned source);
static void trunk_preload_native_snapshot(unsigned stage) {
    uint32_t bit=1u<<stage;
    if(trunk_preload_native.valid&bit)return;
    // Two passive MMIO loads, always in this order. They are not an atomic
    // hardware latch, a reader-half acknowledgement or an RF/sample origin.
    uint32_t status=hrc7000_rd(dev,C7_LAYER2_STATUS);
    uint32_t slots=hrc7000_rd(dev,C7_LAYER2_SLOTON);
    trunk_preload_native.status[stage]=status;trunk_preload_native.slots[stage]=slots;
    trunk_preload_native.valid|=bit; // Publish only after the complete pair.
}
// Warm preparation borrows the existing native TX mode and therefore STOPS
// reception. This lease is only a finite launch-cost experiment; it cannot
// observe a future control-channel slot or authorize automatic access.
static struct {
    uint8_t channel[32],globals[32];
    uint32_t ram_hash,talkgroup;
} trunk_preload_owner;
// Zero-initialized configuration remains REGISTER; no persisted selector or
// automatically operating subscriber state is introduced by this lab choice.
static uint8_t trunk_preload_request_kind(uint8_t choice) {
    return choice==0u ? P25_LAB_REGISTER : choice==1u ? P25_LAB_AFFILIATE
        : choice==2u ? P25_LAB_GROUP : 0u;
}
static bool trunk_preload_request_matches(void) {
    return trunk_preload.request==trunk_preload_config.request
        && trunk_preload_phase.selected==(trunk_preload_config.phase || trunk_preload_config.clock)
        && trunk_preload_phase.marker==trunk_preload_config.phase
        && trunk_preload.voice_enabled==trunk_preload_config.voice
        && trunk_preload.voice_enabled<=TRUNK_PRELOAD_VOICE_MIC
        && trunk_preload_request_kind(trunk_preload.request)!=0u
        && (trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT
            ? trunk_preload_clock_compact_configured()
                && trunk_preload_phase.owner==TRUNK_PRELOAD_OWNER_MANUAL
            : trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_LEGACY
                ? trunk_preload_clock_configured() : !trunk_preload_config.clock);
}
#include "p25_trunking_lab_exchange_live.h"

static bool trunk_preload_active(void) {return trunk_preload.mode && trunk_probe.active;}
static bool trunk_preload_warmed(void) {return trunk_preload_active() && trunk_preload.warmed;}
static void trunk_preload_timer_stop(void) {
    if(!trunk_preload.mode)return;
    trunk_preload.guarded=false;
    hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,false);
}
// The base cleanup clears trunk_probe.active first. Clear this flag regardless.
static void trunk_preload_cleanup(void) {
    trunk_preload_cc_cleanup();
    if(trunk_preload.mode)trunk_preload_timer_stop();
    trunk_preload.mode=false;trunk_preload.warmed=false;
    trunk_preload_phase.pending=false;
    trunk_lab_return_cleanup();
    if(!trunk_lab_return_preserve())memset(&trunk_preload_owner,0,sizeof trunk_preload_owner);
}
static bool trunk_preload_permitted(void) {
    return trunk_preload_active() && hardware_running && trunk_preload.guarded
        && normal_mode && !trunk_enabled && !control.cancel && control.tx_enabled
        && !control.inhibit && !owner_tx_inhibit && control.state!=RADIO_FAULT
        && trunk_probe_profile_matches()
        && trunk_preload_request_matches() && control.talkgroup>=1u && control.talkgroup<=0xffffu
        && control.talkgroup==trunk_preload_owner.talkgroup
        && control.nac==TRUNK_PROBE_NAC && control.source_id==trunk_probe.radio_id
        && !tx_fixed && (trunk_lab_ptt_selected()
            ? trunk_lab_ptt_request_held() : hrc_pin_read(PIN_PTT));
}
static void trunk_preload_abort(const char *why,p25_tx_reason code) {
    board_rf_safe();trunk_preload.safe_us=hrc_micros();
    if(trunk_preload_phase.selected) {trunk_preload.warmed=false;trunk_preload_phase.pending=false;}
    p25_test_tx_abort(&live.timing,code);reason=why;
    hardware_stop();call_active=false;pcmq.accepting=false;
}
static bool trunk_preload_schedule(uint32_t anchor) {
    uint32_t now=hrc_micros(),ceiling=trunk_probe.arm_us+TRUNK_PRELOAD_ARM_CEILING_US;
    uint32_t requested=anchor+trunk_preload_config.cut_delay_us;
    uint32_t cut=(int32_t)(requested-ceiling)>0 ? ceiling : requested;
    uint32_t pa=anchor+trunk_preload_config.pa_delay_us;
    if((int32_t)(cut-now)<=0 || (int32_t)(pa-cut)>=0)return false;
    trunk_preload.anchor_us=anchor;trunk_preload.anchored=true;
    trunk_preload.requested_cut_us=requested;trunk_preload.cut_deadline_us=cut;
    trunk_preload.pa_deadline_us=pa;trunk_preload.shortened=cut!=requested;
    // The independent cutoff is installed before any PA operation.
    hrc_timer_oneshot(TIMER_BOARD,cut-now);
    return true;
}
static void trunk_preload_pa(void) {
    hrc_timer_ack(TIMER_PA);hrc_timer_stop(TIMER_PA);
    if(!trunk_preload_active() || !hardware_running || !trunk_preload.guarded)return;
    if(trunk_probe.seen&PROBE_PA)return; // Stale PA IRQ never rekeys RF.
    uint32_t now=hrc_micros();trunk_preload.pa_irq_us=now;
    trunk_preload.pa_late_us=(int32_t)(now-trunk_preload.pa_deadline_us)>=0 ? now-trunk_preload.pa_deadline_us : 0u;
    if(!trunk_preload.anchored || !trunk_preload_permitted()
       || (int32_t)(now-trunk_preload.pa_deadline_us)<0
       || trunk_preload.pa_late_us>500u || (int32_t)(now-trunk_preload.cut_deadline_us)>=0) {
        trunk_preload_abort("probe_preload_pa_gate",P25_TX_LATE);return;
    }
    hooks->pa_on();tx_dac.pa=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PA;
    trunk_probe.pa_us=hrc_micros();trunk_probe.seen|=PROBE_PA;
}
static void trunk_preload_arm_pa(void) {
    uint32_t now=hrc_micros();
    if((int32_t)(now-trunk_preload.pa_deadline_us)>=0)trunk_preload_pa();
    else hrc_timer_oneshot(TIMER_PA,trunk_preload.pa_deadline_us-now);
}
static void trunk_preload_rf_irq(void) {
    if(!trunk_preload_active() || !hardware_running || !trunk_preload.guarded)return;
    if(trunk_probe.seen&PROBE_RF_IRQ)return; // Never extend an existing window.
    uint32_t now=hrc_micros();
    if(!trunk_preload_permitted() || now-trunk_probe.arm_us>TRUNK_PRELOAD_RF_WAIT_US
       || (int32_t)(now-trunk_preload.cut_deadline_us)>=0) {
        trunk_preload_abort("probe_preload_rf_gate",P25_TX_CANCELLED);return;
    }
    trunk_probe.rf_irq_us=now;trunk_probe.seen|=PROBE_RF_IRQ;
    if(trunk_preload_config.rf_origin) {
        if(!trunk_preload_schedule(now)) {
            trunk_preload_abort("probe_preload_window",P25_TX_TIMEOUT);return;
        }
        trunk_preload_arm_pa();
    }
}
static void trunk_preload_boundary(uint32_t now,unsigned source) {
    if(!trunk_preload_active() || !hardware_running || !trunk_preload.guarded)return;
    if(!trunk_preload_permitted() || (int32_t)(now-trunk_preload.cut_deadline_us)>=0) {
        trunk_preload_abort("probe_preload_boundary_gate",P25_TX_CANCELLED);return;
    }
    if(trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT
       && ((int32_t)(hrc_micros()-trunk_preload.cut_deadline_us)>=0
           || !(trunk_probe.seen&PROBE_PA))) {
        trunk_preload_abort("preload_compact_send_gate",P25_TX_CANCELLED);return;
    }
    // Startup TX/RX slot clocks can retain an unrelated phase. Keep those
    // observations in the diagnostic trace, but only PHY_READY describes the
    // selected physical feeder's heartbeat or requests its first send.
    if(source!=1u) {
        if(source==2u || source==3u)trunk_probe_boundary(now,source);
        return;
    }
    if(trunk_preload.boundaries) {
        uint32_t gap=now-trunk_preload.last_boundary_us;
        if(gap<15000u) {++live.timing.duplicate_irqs;return;}
        if(gap<27000u || gap>33000u) {
            ++live.timing.late_irqs;trunk_preload_abort("probe_preload_boundary_phase",P25_TX_LATE);return;
        }
        if(gap>live.timing.max_gap_us)live.timing.max_gap_us=gap;
    }
    // No IRQ proves a particular native half is no longer being prefetched.
    // Preserve both halves. The absolute 55-ms arm ceiling prevents an entire
    // nominal 60-ms RAM cycle; this third-boundary refusal is a second guard.
    if(trunk_preload.boundaries>=2u) {
        trunk_preload_abort("probe_preload_replay",P25_TX_CANCELLED);return;
    }
    bool first=trunk_preload.boundaries==0u;
    ++trunk_preload.boundaries;trunk_preload.last_boundary_us=now;
    live.timing.last_boundary_us=now;live.timing.have_boundary=true;
    live.timing.state=P25_TX_STREAMING;live.timing.blocks=trunk_preload.boundaries;
    trunk_probe_boundary(now,source);
    // The non-nesting modem ISR adds four fixed passive MMIO loads only on
    // this first PHY event. No formatting, UART, loops or new clock calls.
    if(first)trunk_preload_native_snapshot(TRUNK_PRELOAD_NATIVE_PHY_PRE);
    if(first && trunk_preload_phase.selected)trunk_preload_phase.send_us=hrc_micros();
    hrc7000_wr(dev,C7_LAYER2_TXRX_CTRL,0x80);
    if(first)trunk_preload_native_snapshot(TRUNK_PRELOAD_NATIVE_PHY_POST);
}
static void trunk_preload_cutoff(void) {
    hrc_timer_ack(TIMER_BOARD);
    // The same independent timer also revokes RF-off priming when no future
    // PHY arrives. A stalled task or missing clock cannot leave it leased.
    if(trunk_preload_phase.selected && trunk_preload_warmed() && !hardware_running) {
        trunk_preload_abort("preload_phase_lease",P25_TX_TIMEOUT);return;
    }
    if(!trunk_preload_active() || !hardware_running || !trunk_preload.guarded)return;
    uint32_t now=hrc_micros();trunk_preload.cut_irq_us=now;
    board_rf_safe();trunk_preload.safe_us=hrc_micros();
    // Kill PA/drive first, even for an early/failed cutoff. Read the remaining
    // native state before hardware_stop replaces it with passive settings.
    trunk_preload_native_snapshot(TRUNK_PRELOAD_NATIVE_CUT);
    trunk_preload.cut_late_us=(int32_t)(now-trunk_preload.cut_deadline_us)>=0 ? now-trunk_preload.cut_deadline_us : 0u;
    // ARM already schedules PA and the absolute cutoff without RF_TX. A
    // native PHY heartbeat can complete that finite software window when the
    // separate RF_TX callback never arrives. Slot IRQs are not PHY evidence;
    // rf_irq_us stays zero and no first-air-bit or packet claim follows.
    // RF-origin still needs its actual callback to establish the anchor.
    bool origin_ready=(trunk_probe.seen&PROBE_RF_IRQ)
        || (!trunk_preload_config.rf_origin && trunk_preload.boundaries>0u);
    bool done=trunk_preload_permitted() && trunk_preload.anchored
        && (trunk_probe.seen&PROBE_PA) && origin_ready
        && (int32_t)(now-trunk_preload.cut_deadline_us)>=0 && trunk_preload.cut_late_us<=500u;
    if(done) {live.timing.state=P25_TX_DONE;live.timing.reason=P25_TX_OK;reason=trunk_preload.shortened ? "preload_window_shortened" : "preload_window_complete";}
    else {p25_test_tx_abort(&live.timing,P25_TX_TIMEOUT);reason="probe_preload_cutoff";}
    trunk_lab_return_cutoff(done);
    hardware_stop();call_active=false;pcmq.accepting=false;
}
static uint32_t trunk_preload_ram_hash(void) {
    uint32_t hash=2166136261u;
    for(unsigned i=0;i<P25_TRUNK_PRELOAD_RAM_BYTES;++i)hash=(hash^dev->buf[i])*16777619u;
    return hash;
}
static bool trunk_preload_task_ptt_released(bool down) {
    // UART0 RX shares the PTT pin. Partial FIRE bytes can drive it LOW while
    // task polling runs, so only the board's shared-PTT filter describes the
    // key during this RF-OFF lease. FIRE/PA/IRQ gates still require raw HIGH.
    return ptt_mask && !down && !(board.input->scan()&ptt_mask);
}
static bool trunk_preload_warm_health(void) {
    return bf_cal_valid() && channel_in_band(frequency,false)
        && channel_in_band(control.tx_frequency,true)
        && board.power->battery_mv()>=board.battery_critical_mv;
}
static bool trunk_preload_warm_valid(bool down) {
    return trunk_preload_warmed() && (trunk_preload_task_ptt_released(down) || trunk_lab_ptt_request_held())
        // Battery ADC, calibration and band qualification ran in PREPARE and
        // run again from the task's warm poll. FIRE only revalidates immutable
        // profile ownership and immediate permissions within that 250-ms lease.
        && normal_mode && features_ready && feature_p25() && !trunk_enabled
        && trunk_probe_profile_matches()
        && control.split && control.nac==TRUNK_PROBE_NAC && control.source_id
        && control.source_id<0xffffffu && !radio_channel_get_private(channel_record)
        && !channel_scan.running && !apps_active() && !pcm_owner && !applet_owns_radio
        && !cps_active && !cps_link && !editing && !menu_open && !rx_lab && !rx_job
        && !broadcast_show && !airband_show && !digital_dmr.owned
        && dev && hooks && board.audio && board.radio && feature_tx_settings_valid()
        && feature_tx_power()==0u && tx_writer==TX_WRITER_ALT1 && tx_dac_restore
        && !tx_fixed && !control.cancel && !owner_tx_inhibit && !control.inhibit
        && control.tx_enabled && (!ptt_release_required || trunk_lab_ptt_request_held()
            || trunk_lab_attach_request_permission() || trunk_preload_cc_request_permission()) && !(channel_record[12]&16u)
        && board.power->switch_on()
        && control.source_id==trunk_probe.radio_id && control.talkgroup==trunk_preload_owner.talkgroup
        && control.talkgroup>=1u && control.talkgroup<=0xffffu && trunk_preload_request_matches()
        && prepared && call_active && message_packet_tx && !hardware_running
        && control.state==RADIO_TX_PREPARE && !mon_running && !analog_fm.owned
        && live.packet==message_packet && live.packet_length==40u && !live.packet_pos
        && !memcmp(channel_record,trunk_preload_owner.channel,32)
        && !memcmp(global_record,trunk_preload_owner.globals,32)
        && (int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0
        && trunk_preload_owner.ram_hash==trunk_preload_ram_hash();
}
static void trunk_preload_warm_poll(bool down) {
    // Do not call trunk_probe_context here: its ordinary transmit permission
    // includes a raw PTT check and would mistake a UART data bit for a key.
    if(!trunk_preload_warmed())return;
    if(trunk_preload_warm_valid(down) && trunk_preload_warm_health())return;
    // Validation above may span a fresh-PHY launch. A warm-only predicate
    // becoming false then is expected, not grounds to cancel the new TX.
    // Revoke a still-warm pending launch atomically; full task cleanup stays
    // outside this lock, as do input scanning, ADC and image validation.
    uint32_t lock=hrc_irq_save();
    bool cancel=trunk_preload_warmed();
    if(cancel)trunk_preload_phase.pending=false;
    hrc_irq_restore(lock);
    if(cancel)trunk_probe_cancel();
}
static bool trunk_preload_phase_owner_permitted(bool fire) {
    // Freeze who requested this image. Revoking a selected adapter must not
    // reinterpret its pending request as a raw-HIGH manual transaction.
    if(trunk_preload_phase.owner==TRUNK_PRELOAD_OWNER_JOIN)
        return trunk_lab_attach_selected() && !trunk_lab_ptt_selected() && hrc_pin_read(PIN_PTT)
            && (fire ? trunk_lab_attach_fire_permitted() : trunk_lab_attach_commit_permitted());
    if(trunk_preload_phase.owner==TRUNK_PRELOAD_OWNER_PTT)
        return trunk_lab_ptt_selected() && !trunk_preload_phase.marker
            && trunk_preload.request==2u && trunk_preload.voice_enabled==TRUNK_PRELOAD_VOICE_MIC
            && trunk_lab_exchange.phase==P25_LAB_PREPARED
            && trunk_lab_ptt_fire_permitted() && trunk_lab_attach_commit_permitted();
    return trunk_preload_phase.owner==TRUNK_PRELOAD_OWNER_MANUAL
        && !trunk_lab_attach_selected() && !trunk_lab_ptt_selected() && hrc_pin_read(PIN_PTT);
}
static bool trunk_preload_prepare(bool down,bool separate) {
    uint8_t owner=trunk_lab_ptt_request_held() ? TRUNK_PRELOAD_OWNER_PTT
        : trunk_lab_attach_internal() ? TRUNK_PRELOAD_OWNER_JOIN:TRUNK_PRELOAD_OWNER_MANUAL;
    bool clock_owner=(trunk_preload_config.request<=1u && !trunk_preload_config.voice
            && !trunk_lab_ptt_selected() && (!trunk_lab_attach_selected() || trunk_lab_attach_internal()))
        || (trunk_preload_config.request==2u && trunk_preload_config.voice==TRUNK_PRELOAD_VOICE_MIC
            && trunk_lab_ptt_selected() && trunk_lab_ptt_request_held() && trunk_lab_attach_fire_permitted());
    bool compact=trunk_preload_clock_compact_configured() && owner==TRUNK_PRELOAD_OWNER_MANUAL;
    if(((trunk_preload_config.phase || trunk_preload_config.clock) && (!separate || trunk_preload_config.first_half
            || trunk_preload_config.rf_origin || trunk_preload_config.early
            || (trunk_preload_config.phase && (trunk_preload_config.clock
                || trunk_preload_config.pa_delay_us!=5000u || trunk_preload_config.cut_delay_us!=55000u
                || trunk_preload_config.lead_bytes || trunk_preload_config.return_rx || trunk_preload_config.voice
                || trunk_lab_ptt_selected() || trunk_lab_attach_selected()))
            || (trunk_preload_config.clock && !compact && (!trunk_preload_clock_configured() || !clock_owner))))
       || trunk_lab_return_owned() || (trunk_preload_config.return_rx && !separate)
       || trunk_preload_config.voice>TRUNK_PRELOAD_VOICE_MIC
       || (trunk_preload_config.voice && (!separate || !trunk_preload_config.return_rx || trunk_preload_config.request!=2u))
       || !ptt_mask || !trunk_preload_config.configured || trunk_probe.active
       || ((down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)) && !trunk_lab_ptt_request_held())
       || call_active || prepared || hardware_running
       || radio_busy(&control) || rx_sampling || armed || session_enabled || !trunk_probe_mailbox_idle()
       || !trunk_probe_context() || control.talkgroup<1u || control.talkgroup>0xffffu
       || !trunk_preload_request_kind(trunk_preload_config.request) || (mon_running &&
           (mon_sync_active(hrc_micros()) || monitor.call.active || monitor.playing
            || mon_routed || mon_pcm_pending || monitor.pcm_head!=monitor.pcm_tail)))return false;
    uint8_t block[1][12],image[P25_TRUNK_PRELOAD_RAM_BYTES];
    const uint8_t request=trunk_preload_config.request;
    p25_trunking_preload_plan plan;
    p25_trunking_preload_config config={trunk_preload_config.first_half,compact ? 0u:0x77u,trunk_preload_config.lead_bytes};
    bool packet_ok=request==0u
        ? p25_trunking_isp_register(block[0],TRUNK_PROBE_WACN,TRUNK_PROBE_SYSTEM,control.source_id)
        : request==1u ? p25_trunking_isp_affiliate(block[0],TRUNK_PROBE_SYSTEM,(uint16_t)control.talkgroup,control.source_id)
        : p25_trunking_isp_group_request(block[0],(uint16_t)control.talkgroup,control.source_id,TRUNK_PRELOAD_GROUP_OPTIONS);
    if(!packet_ok
       || p25_tsdu_encode(message_packet,sizeof message_packet,TRUNK_PROBE_NAC,
           (const uint8_t (*)[12])block,1,P25_TRUNKING_ISP_STATUS)!=45u
       || !p25_trunking_preload_plan_make(&plan,&config)
       || !(trunk_preload_config.phase ? p25_trunking_preload_phase_image(image)
           : p25_trunking_preload_render(&plan,message_packet,image)))return false;
    uint32_t sequence=trunk_probe.sequence+1u;
    memset((void *)&trunk_probe,0,sizeof trunk_probe);
    memset((void *)&trunk_preload,0,sizeof trunk_preload);
    memset((void *)&trunk_preload_native,0,sizeof trunk_preload_native);
    memset((void *)&trunk_preload_phase,0,sizeof trunk_preload_phase);
    trunk_preload_phase.selected=trunk_preload_config.phase || trunk_preload_config.clock;
    trunk_preload_phase.marker=trunk_preload_config.phase;
    trunk_preload_phase.owner=owner;
    // Shared generic probe telemetry must not retain a previous BURST's IRQs.
    bool burst_configured=trunk_burst.configured;
    memset((void *)&trunk_burst,0,sizeof trunk_burst);
    trunk_burst.configured=burst_configured;
    trunk_probe.sequence=sequence ? sequence : 1u;trunk_probe.radio_id=control.source_id;
    trunk_probe.lab_profile=trunk_lab_profile;
    trunk_probe.active=true;trunk_probe.result=TRUNK_PROBE_ACTIVE;
    trunk_burst.short_mode=false;trunk_preload.mode=true;trunk_preload.prepare_us=hrc_micros();
    trunk_preload.lead_bytes=plan.lead_bytes;trunk_preload.request=request;
    trunk_preload.clock_profile=compact ? TRUNK_PRELOAD_CLOCK_COMPACT
        : trunk_preload_config.clock ? TRUNK_PRELOAD_CLOCK_LEGACY:TRUNK_PRELOAD_CLOCK_NONE;
    trunk_preload.return_enabled=trunk_preload_config.return_rx;trunk_preload.separate_warm=separate;
    trunk_preload.voice_enabled=trunk_preload_config.voice;
    trunk_preload.warm_deadline_us=trunk_preload.prepare_us+TRUNK_PRELOAD_WARM_US;
    trunk_preload.early_requested=trunk_preload_config.early;
    bool prepared_ok=prepare_p25_tx(true);trunk_preload.prepare_end_us=hrc_micros();
    if(!prepared_ok) {trunk_probe_finish(TRUNK_PROBE_FAILED,"preload_setup_failed");return false;}
    p25_live_tx_init(&live);
    if(!p25_live_tx_set_packet(&live,message_packet,40u) || !p25_live_tx_set_rf_limit(&live,TRUNK_PROBE_LIMIT_US)) {
        trunk_probe_finish(TRUNK_PROBE_FAILED,"preload_setup_failed");return false;
    }
    memset(&pcmq,0,sizeof pcmq);message_packet_tx=true;
    control.cancel=false;control.state=RADIO_TX_PREPARE;call_active=true;
    capture_started=hrc_micros();call_soft_limit_us=TRUNK_PROBE_LIMIT_US;
    // Populate the immutable native RAM before the preparation ACK. FIRE
    // neither renders a packet nor copies the image. Latches are also reset
    // again at FIRE because the native clocks may advance during the lease.
    uint32_t lock=hrc_irq_save();
    for(unsigned i=0;i<sizeof image;++i)dev->buf[i]=image[i];
    if(trunk_preload_phase.selected)trunk_preload_phase.image_us=hrc_micros();
    hrc7000_wr(dev,C7_LAYER2_TXRX_CTRL,0);
    hrc7000_wr(dev,C7_SYS_INTERP_CLEAR,0xffffffffu);
    hrc7000_wr(dev,C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    hrc7000_wr(dev,C7_SYS_INTERP_MASK,PHY_READY);
    hrc_irq_restore(lock);
    memcpy(trunk_preload_owner.channel,channel_record,32);
    memcpy(trunk_preload_owner.globals,global_record,32);
    trunk_preload_owner.talkgroup=control.talkgroup;
    trunk_preload_owner.ram_hash=trunk_preload_ram_hash();trunk_preload.warmed=true;
    if(trunk_preload_phase.selected) {
        trunk_preload_phase.ram_hash=trunk_preload_owner.ram_hash;
        // Start only native timing. TXRX remains zero, PA/drive remain off,
        // and the owner/image are published before SYS IRQ is unmasked.
        // This does not reset or acknowledge either native RAM reader half.
        uint32_t now=hrc_micros();
        if((int32_t)(trunk_preload.warm_deadline_us-now)<=0) {
            trunk_probe_cancel();return false;
        }
        hrc_irq_enable(IRQ_TIMER5,true);
        hrc_timer_oneshot(TIMER_BOARD,trunk_preload.warm_deadline_us-now);
        if(!trunk_preload_cc_defer_clock()) {
            hrc7000_wr(dev,C7_LAYER2_CONTROL,0x82);
            hrc_irq_enable(IRQ_MODEM_SYS,true);
        }
    }
    if(trunk_preload.return_enabled && !trunk_lab_return_prepare()) {
        trunk_probe_finish(TRUNK_PROBE_FAILED,"preload_return_setup_failed");return false;
    }
    if(trunk_lab_ptt_request_held() || trunk_lab_attach_internal() || trunk_preload_cc_request_permission()) {
        // Physical one-shot dispatch retains the same token and250ms FIRE
        // lease, with no UART ACK or wire-time dependency.
    } else if(separate) {
        char line[192];snprintf(line,sizeof line,"OK TRUNK PROBE PRELOAD PREPARE sequence=%lu lease_us=250000 rx=deaf RF=off access_timing=unqualified\r\n",(unsigned long)trunk_probe.sequence);
        send(line);
    } else send("OK TRUNK PROBE PRELOAD finite lab window; timestamps are software, RF timing unqualified\r\n");
    trunk_preload.ack_end_us=hrc_micros();
    if(!trunk_preload_warm_valid(down) || !trunk_preload_warm_health()) {
        trunk_probe_cancel();return false;
    }
    reason="preload_warmed_deaf";return true;
}
static bool trunk_preload_fire(uint32_t sequence,bool down) {
    // No serial reply precedes the timed launch. The PREPARE ACK contains the
    // one-use token; STATUS after cleanup reports the result and timestamps.
    if(!trunk_preload_warmed())return false;
    trunk_preload.fire_begin_us=hrc_micros();
    if(!sequence || sequence!=trunk_probe.sequence || !trunk_lab_ptt_fire_permitted() || !trunk_lab_attach_fire_permitted()
       || (trunk_preload_phase.selected && !trunk_preload_phase_owner_permitted(true))
       || (!hrc_pin_read(PIN_PTT) && !trunk_lab_ptt_request_held()) || !trunk_preload_warm_valid(down)) {
        if(trunk_preload_warmed())trunk_probe_cancel();
        return false;
    }
    trunk_preload.fire_gate_end_us=hrc_micros();
    if(trunk_preload_phase.selected) {
        uint32_t lock=hrc_irq_save(),now=hrc_micros();
        bool okay=!trunk_preload_phase.pending && trunk_preload_phase.count>=2u
            && (!trunk_preload_config.clock || trunk_preload_phase.count==TRUNK_PRELOAD_CLOCK_FIRE_ORDINAL)
            && now-trunk_preload_phase.last_us<=33000u
            && (int32_t)(now-trunk_preload.warm_deadline_us)<0;
        if(okay) {
            // Latch only. A subsequent fresh PHY owns the actual ARM; waiting
            // unkeyed consumes the original warm lease, never the RF budget.
            trunk_preload_phase.fire_ordinal=trunk_preload_phase.count;
            trunk_preload_phase.pending=true;
        }
        hrc_irq_restore(lock);
        if(!okay)trunk_probe_cancel();
        return okay;
    }
    uint32_t lock=hrc_irq_save();trunk_preload.warmed=false;
    bool okay=(int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0
        && p25_test_tx_start(&live.timing,hrc_micros(),true) && hard_guard_arm(2u);
    if(okay) {
        if(tx_dac_restore)hrc_dac_b_power(true);
        tx_dac.pre_rf=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PRE_RF;
        hrc7000_wr(dev,C7_SYS_INTERP_CLEAR,0xffffffffu);
        hrc7000_wr(dev,C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
        trunk_preload.guarded=true;trunk_preload.cut_deadline_us=hrc_micros()+150000u;
        hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,true);hrc_timer_oneshot(TIMER_BOARD,150000u);
        hardware_running=true;pa_started=true;control.state=RADIO_TX_VOICE;
        okay=trunk_preload_permitted() && (int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0;
        if(okay) {
            trunk_preload.switch_begin_us=hrc_micros();hooks->rf_switch(true);
            trunk_preload.switch_end_us=hrc_micros();
            okay=trunk_preload_permitted() && (int32_t)(hrc_micros()-trunk_preload.cut_deadline_us)<0;
        }
    }
    if(okay) {
        hrc_irq_enable(IRQ_MODEM_SYS,true);hrc_irq_enable(IRQ_MODEM_TS_TX,true);hrc_irq_enable(IRQ_MODEM_TS_RX,true);
        hrc_irq_enable(IRQ_MODEM_RF_TX,true);hrc_irq_enable(IRQ_MODEM_RF_RX,true);
        trunk_probe.arm_us=hrc_micros();trunk_probe.seen|=PROBE_ARM;
        okay=trunk_lab_return_tx_started();
        if(okay && trunk_preload_config.rf_origin) {
            trunk_preload.cut_deadline_us=trunk_probe.arm_us+TRUNK_PRELOAD_ARM_CEILING_US;
            hrc_timer_oneshot(TIMER_BOARD,TRUNK_PRELOAD_ARM_CEILING_US);
        } else if(okay)okay=trunk_preload_schedule(trunk_probe.arm_us);
        if(okay) {
            reason="preload_running";
            hrc7000_wr(dev,C7_LAYER2_CONTROL,0x82);
            // Explicit experiment only: this may still be ignored until a
            // native boundary. It does not assert an immediate first RF bit.
            if(trunk_preload.early_requested)hrc7000_wr(dev,C7_LAYER2_TXRX_CTRL,0x80);
            if(!trunk_preload_config.rf_origin)trunk_preload_arm_pa();
            // After the optional initial SEND path and, for ARM origin, PA
            // scheduling. Existing arm_us is a prior software anchor, not this
            // read time; zero ARM PA delay may already have keyed the radio.
            if(hardware_running && trunk_preload.guarded)
                trunk_preload_native_snapshot(TRUNK_PRELOAD_NATIVE_ARM);
        }
    }
    if(!okay)trunk_preload_abort("preload_setup_failed",P25_TX_CANCELLED);
    hrc_irq_restore(lock);
    if(!hardware_running) {trunk_probe_finish(TRUNK_PROBE_FAILED,"preload_setup_failed");return false;}
    return true;
}
static bool trunk_preload_clock_poll(uint32_t sequence,bool down) {
    // Internal callers already bound this one-use PREPARED exchange. Waiting
    // consumes the original RF-off lease; a task must catch ordinal3, then a
    // subsequent fresh PHY commits ARM. No task sleep, retry or UART is used.
    if(!trunk_preload_config.clock || !sequence || sequence!=trunk_probe.sequence)return false;
    trunk_preload_warm_poll(down);
    if(!trunk_probe.active)return false;
    bool owner_okay=trunk_preload_phase_owner_permitted(true);
    uint32_t lock=hrc_irq_save(),now=hrc_micros();
    // A PHY may have committed while task health/identity checks ran. Its
    // active/completed transport belongs to the ordinary exchange poll now.
    if(!trunk_preload_warmed()) {hrc_irq_restore(lock);return true;}
    unsigned count=trunk_preload_phase.count;
    bool pending=trunk_preload_phase.pending;
    bool okay=trunk_preload_phase.selected && !trunk_preload_phase.marker
        && owner_okay
        && (int32_t)(now-trunk_preload.warm_deadline_us)<0
        && (!count || now-trunk_preload_phase.last_us<=33000u)
        && count<=TRUNK_PRELOAD_CLOCK_FIRE_ORDINAL;
    if(!okay)trunk_preload_phase.pending=false;
    hrc_irq_restore(lock);
    if(!okay) {trunk_probe_cancel();return false;}
    if(!pending && count==TRUNK_PRELOAD_CLOCK_FIRE_ORDINAL)return trunk_preload_fire(sequence,down);
    return true;
}
static void trunk_preload_phase_boundary(uint32_t now,unsigned source) {
    if(source!=1u || !trunk_preload_phase.selected || !trunk_preload_warmed() || hardware_running)return;
    if((int32_t)(now-trunk_preload.warm_deadline_us)>=0) {
        trunk_preload_abort("preload_phase_lease",P25_TX_TIMEOUT);return;
    }
    if(trunk_preload_phase.count) {
        uint32_t gap=now-trunk_preload_phase.last_us;
        if(gap<15000u)return;
        if(gap<27000u || gap>33000u) {
            trunk_preload_abort("preload_phase_cadence",P25_TX_LATE);return;
        }
    } else trunk_preload_phase.first_us=now;
    trunk_preload_phase.last_us=now;++trunk_preload_phase.count;
    if(!trunk_preload_cc_native(now,trunk_preload_phase.count)) {
        trunk_preload_abort("preload_cc_native_edge",P25_TX_LATE);return;
    }
    if(!trunk_preload_phase.pending || trunk_preload_phase.count<=trunk_preload_phase.fire_ordinal)return;
    // Bounded ISR checks only: no ADC, input scan, allocation, formatting or
    // serial write. FIRE/task polling already qualified health within this
    // fixed lease. Recheck immediate permissions and immutable ownership.
    bool okay=normal_mode && features_ready && !trunk_enabled && !control.cancel
        && control.tx_enabled && !control.inhibit && !owner_tx_inhibit
        && control.state==RADIO_TX_PREPARE && prepared && call_active && message_packet_tx
        && !channel_scan.running && !apps_active() && !pcm_owner && !applet_owns_radio
        && !cps_active && !cps_link && !editing && !menu_open && !rx_lab && !rx_job
        && !broadcast_show && !airband_show && !digital_dmr.owned
        && !mon_running && !analog_fm.owned && !rx_sampling
        && !tx_fixed && trunk_preload_phase_owner_permitted(false)
        && trunk_probe_profile_matches()
        && control.source_id==trunk_probe.radio_id && control.talkgroup==trunk_preload_owner.talkgroup
        && trunk_preload_request_matches() && !memcmp(channel_record,trunk_preload_owner.channel,32)
        && !memcmp(global_record,trunk_preload_owner.globals,32)
        && trunk_preload_owner.ram_hash==trunk_preload_ram_hash();
    if(!okay) {trunk_preload_abort("preload_phase_owner",P25_TX_CANCELLED);return;}
    uint32_t lock=hrc_irq_save();
    trunk_preload.warmed=false;trunk_preload_phase.pending=false;trunk_preload_phase.launch_us=now;
    okay=(int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0
        && p25_test_tx_start(&live.timing,now,true) && hard_guard_arm(2u);
    if(okay) {
        trunk_probe.arm_us=now;trunk_probe.seen|=PROBE_ARM;
        // Deferred FIRE must leave the observer PREPARED until this actual
        // boundary. No RX startup or reply parsing occurs in this transition.
        okay=trunk_lab_return_tx_started();
    }
    if(okay) {
        if(tx_dac_restore)hrc_dac_b_power(true);
        tx_dac.pre_rf=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PRE_RF;
        trunk_preload.guarded=true;hardware_running=true;pa_started=true;control.state=RADIO_TX_VOICE;
        // Install the absolute cutoff before any RF path change. The master
        // clock and pending PHY latch are not reset at this boundary.
        okay=trunk_preload_schedule(now) && trunk_preload_permitted()
            && (int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0;
        if(okay) {
            trunk_preload.switch_begin_us=hrc_micros();hooks->rf_switch(true);
            trunk_preload.switch_end_us=hrc_micros();
            okay=trunk_preload_permitted()
                && (trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT
                    || (int32_t)(hrc_micros()-trunk_preload.pa_deadline_us)<0)
                && (int32_t)(hrc_micros()-trunk_preload.cut_deadline_us)<0
                && (int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0;
        }
        if(okay && trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT) {
            // ARM remains the fixed cutoff origin. Only this manual compact
            // profile keys PA immediately after a validated switch, BEFORE
            // native snapshots/SEND. Its PA origin is the separate software
            // switch completion; the existing500-us gate is unchanged.
            trunk_preload.pa_deadline_us=trunk_preload.switch_end_us;
            trunk_preload_pa();
            okay=hardware_running && trunk_preload.guarded && (trunk_probe.seen&PROBE_PA)
                && trunk_preload_permitted()
                && (int32_t)(hrc_micros()-trunk_preload.cut_deadline_us)<0
                && (int32_t)(hrc_micros()-trunk_preload.warm_deadline_us)<0;
        }
        if(okay) {
            hrc_irq_enable(IRQ_MODEM_RF_TX,true);hrc_irq_enable(IRQ_MODEM_RF_RX,true);
            trunk_preload_native_snapshot(TRUNK_PRELOAD_NATIVE_ARM);
            trunk_preload_boundary(now,1u);
            if(hardware_running && trunk_preload.guarded
               && trunk_preload.clock_profile!=TRUNK_PRELOAD_CLOCK_COMPACT)trunk_preload_arm_pa();
            reason=trunk_preload_phase.marker ? "preload_phase_running":"preload_clock_running";
        }
    }
    if(!okay)trunk_preload_abort("preload_phase_launch",P25_TX_CANCELLED);
    hrc_irq_restore(lock);
}
static bool trunk_preload_start(bool down) {
    return trunk_preload_prepare(down,false) && trunk_preload_fire(trunk_probe.sequence,down);
}
static bool trunk_preload_sequence_parse(const char *s,uint32_t *out) {
    uint32_t n=0;if(*s<'1' || *s>'9')return false;
    do {uint32_t d=(uint32_t)(*s++-'0');if(n>(UINT32_MAX-d)/10u)return false;n=n*10u+d;}while(*s>='0' && *s<='9');
    if(*s)return false;
    *out=n;return true;
}
static bool trunk_preload_parse(const char *s,unsigned *half,bool *rf,uint32_t *pa,uint32_t *cut) {
    if((s[0]!='0' && s[0]!='1') || s[1]!=' ')return false;
    *half=(unsigned)(s[0]-'0');s+=2;
    if(!strncmp(s,"ARM ",4)) {*rf=false;s+=4;}
    else if(!strncmp(s,"RF ",3)) {*rf=true;s+=3;}else return false;
    uint32_t value[2];
    for(unsigned i=0;i<2u;++i) {
        uint32_t n=0;if(*s<'0' || *s>'9')return false;
        do {unsigned d=(unsigned)(*s++-'0');if(n>(100000u-d)/10u)return false;n=n*10u+d;}while(*s>='0' && *s<='9');
        value[i]=n;if(i==0u) {if(*s++!=' ')return false;}else if(*s)return false;
    }
    if(value[0]>20000u || !value[1] || value[1]>100000u || value[1]<=value[0] || value[1]-value[0]>50000u)return false;
    *pa=value[0];*cut=value[1];return true;
}
static bool trunk_preload_command(const char *cmd,bool down) {
    static const char name[]="TRUNK PROBE PRELOAD";
    if(strncmp(cmd,name,sizeof name-1u) || (cmd[sizeof name-1u] && cmd[sizeof name-1u]!=' '))return false;
    if(!strcmp(cmd,"TRUNK PROBE PRELOAD STATUS")) {telemetry_request(TELEMETRY_PRELOAD);return true;}
    if(!strcmp(cmd,"TRUNK PROBE PRELOAD CCSTART")) {
        if(!trunk_preload_cc_start(down))send("ERR PRELOAD CCSTART requires compact COMMONIQ1M and ordinary qualified-site TRUNK RX; release PTT\r\n");
        return true;
    }
    if(!strcmp(cmd,"TRUNK PROBE PRELOAD STOP")) {trunk_lab_return_cancel();trunk_probe_cancel();send("OK TRUNK PROBE PRELOAD STOP\r\n");return true;}
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD CLOCK ",26)) {
        const char *value=cmd+26;
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running
           || trunk_lab_ptt_selected() || trunk_lab_attach_selected()
           || down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)
           || (strcmp(value,"ON") && strcmp(value,"OFF"))
           || (!strcmp(value,"ON") && trunk_preload_config.phase)) {
            send("ERR PRELOAD CLOCK idle only: ON | OFF; PHASE must be OFF\r\n");return true;
        }
        trunk_preload_config.clock=!strcmp(value,"ON");
        send("OK TRUNK PROBE PRELOAD CLOCK volatile finite REGISTER/AFFILIATE or bound JOIN/PTT; access timing unqualified\r\n");return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD PHASE ",26)) {
        const char *value=cmd+26;
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running
           || down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)
           || (strcmp(value,"ON") && strcmp(value,"OFF"))
           || (!strcmp(value,"ON") && trunk_preload_config.clock)) {
            send("ERR PRELOAD PHASE idle only: ON | OFF; CLOCK must be OFF\r\n");return true;
        }
        trunk_preload_config.phase=!strcmp(value,"ON");
        send("OK TRUNK PROBE PRELOAD PHASE volatile marker experiment; no subscriber request\r\n");return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD VOICE ",26)) {
        const char *value=cmd+26;
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running
           || down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)
           || (strcmp(value,"ON") && strcmp(value,"OFF") && strcmp(value,"MIC"))
           || (strcmp(value,"OFF") && (!trunk_preload_config.return_rx || trunk_preload_config.request!=2u))) {
            send("ERR PRELOAD VOICE idle only: ON|MIC requires GROUP+RETURN ON | OFF\r\n");return true;
        }
        trunk_preload_config.voice=!strcmp(value,"MIC") ? TRUNK_PRELOAD_VOICE_MIC
            : !strcmp(value,"ON") ? TRUNK_PRELOAD_VOICE_TONE:TRUNK_PRELOAD_VOICE_OFF;
        send("OK TRUNK PROBE PRELOAD VOICE volatile; one grant-bound finite source; PTT cancels; no subscriber state\r\n");return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD REQUEST ",28)) {
        const char *value=cmd+28;
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running
           || down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)
           || (strcmp(value,"REGISTER") && strcmp(value,"AFFILIATE") && strcmp(value,"GROUP"))) {
            send("ERR PRELOAD REQUEST idle only: REGISTER | AFFILIATE | GROUP\r\n");return true;
        }
        trunk_preload_config.request=!strcmp(value,"GROUP") ? 2u : !strcmp(value,"AFFILIATE");
        send("OK TRUNK PROBE PRELOAD REQUEST volatile; frozen at PREPARE; access timing unqualified\r\n");return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD RETURN ",27)) {
        const char *value=cmd+27;
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running
           || down || !hrc_pin_read(PIN_PTT) || (strcmp(value,"ON") && strcmp(value,"OFF"))) {
            send("ERR PRELOAD RETURN idle only: ON | OFF; WARM lab observer only\r\n");return true;
        }
        trunk_preload_config.return_rx=!strcmp(value,"ON");
        send("OK TRUNK PROBE PRELOAD RETURN volatile; WARM only; subscriber state unchanged\r\n");return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD LEAD ",25)) {
        uint32_t lead=0;const char *value=cmd+25;
        bool valid=!strcmp(value,"0") || trunk_preload_sequence_parse(value,&lead);
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running || down || !hrc_pin_read(PIN_PTT)
           || !valid || lead>P25_TRUNK_PRELOAD_MAX_LEAD_BYTES) {
            send("ERR PRELOAD LEAD idle only: bytes0..16; 0x77 preamble; RF timing unqualified\r\n");return true;
        }
        trunk_preload_config.lead_bytes=(uint8_t)lead;
        send("OK TRUNK PROBE PRELOAD LEAD volatile bytes0..16; existing RF caps unchanged\r\n");return true;
    }
    if(!strcmp(cmd,"TRUNK PROBE PRELOAD PREPARE")) {
        if(!trunk_preload_prepare(down,true))send("ERR PRELOAD PREPARE requires CONFIG and idle lab profile; RX stops; lease250000us\r\n");
        return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD FIRE",24)) {
        uint32_t sequence;
        if(cmd[24]!=' ' || !trunk_preload_sequence_parse(cmd+25,&sequence)) {
            if(trunk_preload_warmed())trunk_probe_cancel();
            send("ERR PRELOAD FIRE sequence required; warm lease discarded\r\n");
        } else if(!trunk_preload_fire(sequence,down))send("ERR PRELOAD FIRE stale, expired or changed owner; no RF\r\n");
        return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD LAUNCH ",27)) {
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running || down || !hrc_pin_read(PIN_PTT)
           || (strcmp(cmd+27,"EARLY") && strcmp(cmd+27,"BOUNDARY"))) {
            send("ERR PRELOAD LAUNCH idle only: EARLY | BOUNDARY\r\n");return true;
        }
        trunk_preload_config.early=!strcmp(cmd+27,"EARLY");
        send("OK TRUNK PROBE PRELOAD LAUNCH volatile; no RF; timing unqualified\r\n");return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PRELOAD CONFIG ",27)) {
        unsigned half;bool rf;uint32_t pa,cut;
        if(trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running || down || !hrc_pin_read(PIN_PTT)
           || !trunk_preload_parse(cmd+27,&half,&rf,&pa,&cut)) {
            send("ERR PRELOAD CONFIG idle only: half0/1 ARM|RF pa_us0..20000 cut_us1..100000; cut>pa; window<=50000\r\n");return true;
        }
        trunk_preload_config.first_half=(uint8_t)half;trunk_preload_config.rf_origin=rf;
        trunk_preload_config.pa_delay_us=pa;trunk_preload_config.cut_delay_us=cut;trunk_preload_config.configured=true;
        send("OK TRUNK PROBE PRELOAD CONFIG volatile; absolute arm ceiling55000us; RF timing unqualified\r\n");return true;
    }
    if(!strcmp(cmd,name)) {
        if(!trunk_preload_start(down))send("ERR PRELOAD requires CONFIG and idle TX-enabled selected lab profile P25 NAC293; release PTT\r\n");
        return true;
    }
    send("ERR TRUNK PROBE PRELOAD [CONFIG half ARM|RF pa_us cut_us | REQUEST REGISTER|AFFILIATE|GROUP | LEAD bytes0..16 | LAUNCH EARLY|BOUNDARY | RETURN ON|OFF | VOICE ON|MIC|OFF | PHASE ON|OFF | CLOCK ON|OFF | PREPARE | FIRE sequence | STATUS | STOP]\r\n");return true;
}
static int trunk_preload_status_row(unsigned row,char *line,size_t capacity) {
    if(row==0u)return snprintf(line,capacity,"TRUNKPRELOAD active=%u configured=%u sequence=%lu result=%u first_half=%u fill=%s origin=%s pa_delay_us=%lu cut_delay_us=%lu launch=%s early_requested=%u config=current valid_bits=%u ram_bytes=72 arm_ceiling_us=55000 rf_timing=unqualified profile=%s selected_profile=%s\r\n",
        (unsigned)trunk_preload_active(),(unsigned)trunk_preload_config.configured,(unsigned long)trunk_probe.sequence,
        (unsigned)trunk_probe.result,(unsigned)trunk_preload_config.first_half,trunk_preload_phase.marker ? "marker"
            : trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT ? "00":"77",trunk_preload_config.rf_origin ? "RF":"ARM",
        (unsigned long)trunk_preload_config.pa_delay_us,(unsigned long)trunk_preload_config.cut_delay_us,
        trunk_preload_config.early ? "EARLY":"BOUNDARY",(unsigned)trunk_preload.early_requested,
        trunk_preload_phase.marker ? 576u:316u,
        p25_trunking_lab_name(trunk_probe.sequence ? trunk_probe.lab_profile:trunk_lab_profile),
        p25_trunking_lab_name(trunk_lab_profile));
    if(row==1u)return snprintf(line,capacity,"TRUNKPRELOAD_TIMING prepare_us=%lu prepare_end_us=%lu ack_end_us=%lu switch_begin_us=%lu switch_end_us=%lu arm_us=%lu rf_irq_us=%lu anchor_us=%lu pa_deadline_us=%lu pa_irq_us=%lu pa_late_us=%lu pa_us=%lu%s timestamps=software_not_air\r\n",
        (unsigned long)trunk_preload.prepare_us,(unsigned long)trunk_preload.prepare_end_us,(unsigned long)trunk_preload.ack_end_us,
        (unsigned long)trunk_preload.switch_begin_us,(unsigned long)trunk_preload.switch_end_us,
        (unsigned long)trunk_probe.arm_us,(unsigned long)trunk_probe.rf_irq_us,(unsigned long)trunk_preload.anchor_us,
        (unsigned long)trunk_preload.pa_deadline_us,(unsigned long)trunk_preload.pa_irq_us,(unsigned long)trunk_preload.pa_late_us,(unsigned long)trunk_probe.pa_us,
        trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT ? " pa_origin=SWITCH_END":"");
    if(row==2u)return snprintf(line,capacity,"TRUNKPRELOAD_CUTOFF requested_us=%lu effective_us=%lu shortened=%u cut_irq_us=%lu cut_late_us=%lu safe_us=%lu guarded=%u boundaries=%u heartbeat=PHY_ONLY end_us=%lu full_isp=unmeasured cleanup_us=%lu cleaned_us=%lu setup_us=%lu tuned_us=%lu irq_us=%lu input_irq_us=%lu resume_us=%lu resume_epoch=%lu\r\n",
        (unsigned long)trunk_preload.requested_cut_us,(unsigned long)trunk_preload.cut_deadline_us,(unsigned)trunk_preload.shortened,
        (unsigned long)trunk_preload.cut_irq_us,(unsigned long)trunk_preload.cut_late_us,(unsigned long)trunk_preload.safe_us,
        (unsigned)trunk_preload.guarded,(unsigned)trunk_preload.boundaries,(unsigned long)trunk_probe.end_us,
        (unsigned long)trunk_lab_stages.cleanup_us,(unsigned long)trunk_lab_stages.cleaned_us,
        (unsigned long)trunk_lab_stages.setup_us,(unsigned long)trunk_lab_stages.tuned_us,
        (unsigned long)trunk_lab_stages.irq_us,(unsigned long)trunk_lab_stages.input_irq_us,
        (unsigned long)trunk_lab_stages.resume_us,(unsigned long)trunk_lab_stages.resume_epoch);
    if(row==3u)return snprintf(line,capacity,"TRUNKPRELOAD_REPLY lab_seq=%lu req=%u group=%u channel=%u source=%lu options=%u expected_channel=%u expected_options=%u lab_only=1\r\n",
        (unsigned long)trunk_lab_exchange.owner.sequence,(unsigned)trunk_lab_exchange.owner.request,
        (unsigned)trunk_lab_exchange.reply_group,(unsigned)trunk_lab_exchange.reply_channel,
        (unsigned long)trunk_lab_exchange.reply_source,(unsigned)trunk_lab_exchange.reply_options,
        (unsigned)trunk_lab_exchange.owner.expected_channel,(unsigned)trunk_lab_exchange.owner.expected_options);
    if(row==4u) {
        uint32_t status[4],slots[4],valid,sequence;
        uint32_t lock=hrc_irq_save();
        valid=trunk_preload_native.valid;sequence=trunk_probe.sequence;
        for(unsigned i=0;i<4u;++i) {status[i]=trunk_preload_native.status[i];slots[i]=trunk_preload_native.slots[i];}
        hrc_irq_restore(lock);
        return snprintf(line,capacity,"TRUNKPRELOAD_NATIVE sequence=%lu valid=%02lx arm_status=%08lx arm_slots=%08lx phy_pre_status=%08lx phy_pre_slots=%08lx phy_post_status=%08lx phy_post_slots=%08lx cut_status=%08lx cut_slots=%08lx stages=ARM_PATH_PHY_PRE_POST_CUT_SAFE timestamps=software_not_air reader_half=unknown\r\n",
            (unsigned long)sequence,(unsigned long)valid,
            (unsigned long)status[0],(unsigned long)slots[0],(unsigned long)status[1],(unsigned long)slots[1],
            (unsigned long)status[2],(unsigned long)slots[2],(unsigned long)status[3],(unsigned long)slots[3]);
    }
    if(row==TRUNK_PRELOAD_PHASE_ROW)return snprintf(line,capacity,"TRUNKPRELOAD_PHASE configured=%u selected=%u pending=%u clock_cfg=%u marker=%u count=%u fire_ordinal=%u image_us=%lu first_us=%lu last_us=%lu launch_us=%lu send_us=%lu image_hash=%08lx%s reader_half=unknown timestamps=software_not_air\r\n",
        (unsigned)trunk_preload_config.phase,(unsigned)trunk_preload_phase.selected,(unsigned)trunk_preload_phase.pending,
        (unsigned)trunk_preload_config.clock,(unsigned)trunk_preload_phase.marker,
        (unsigned)trunk_preload_phase.count,(unsigned)trunk_preload_phase.fire_ordinal,
        (unsigned long)trunk_preload_phase.image_us,(unsigned long)trunk_preload_phase.first_us,
        (unsigned long)trunk_preload_phase.last_us,(unsigned long)trunk_preload_phase.launch_us,
        (unsigned long)trunk_preload_phase.send_us,(unsigned long)trunk_preload_phase.ram_hash,
        trunk_preload.clock_profile==TRUNK_PRELOAD_CLOCK_COMPACT ? " clock_profile=compact-register":"");
    if(row==TRUNK_PRELOAD_END_ROW)return snprintf(line,capacity,"TRUNKPRELOAD_END result=%u timing=%u warmed=%u warm_deadline_us=%lu fire_begin_us=%lu fire_gate_end_us=%lu rx_during_prepare=deaf timestamps=software_not_air lead_bytes=%u return_cfg=%u return_frozen=%u lab_seq=%lu lab_phase=%u lab_reason=%u rx_epoch=%lu rx_ready_us=%lu reply_us=%lu reply_type=%u response=%u replies=%u lab_only=1 req_cfg=%u req=%u\r\n",(unsigned)trunk_probe.result,(unsigned)trunk_probe.timing_reason,(unsigned)trunk_preload_warmed(),(unsigned long)trunk_preload.warm_deadline_us,(unsigned long)trunk_preload.fire_begin_us,(unsigned long)trunk_preload.fire_gate_end_us,(unsigned)trunk_preload.lead_bytes,
        (unsigned)trunk_preload_config.return_rx,(unsigned)trunk_preload.return_enabled,
        (unsigned long)trunk_lab_exchange.owner.sequence,(unsigned)trunk_lab_exchange.phase,
        (unsigned)trunk_lab_exchange.reason,(unsigned long)trunk_lab_exchange.rx_epoch,
        (unsigned long)trunk_lab_exchange.rx_ready_us,(unsigned long)trunk_lab_exchange.reply_us,
        (unsigned)trunk_lab_exchange.reply_type,(unsigned)trunk_lab_exchange.response,(unsigned)trunk_lab_exchange.replies,
        (unsigned)trunk_preload_request_kind(trunk_preload_config.request),
        (unsigned)trunk_preload_request_kind(trunk_preload.request));
    if(row>=TRUNK_PRELOAD_CC_ROW && row<TRUNK_PRELOAD_END_ROW)
        return trunk_preload_cc_status_row(row-TRUNK_PRELOAD_CC_ROW,line,capacity);
    return -1;
}
#endif
#endif
