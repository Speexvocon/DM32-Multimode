// SPDX-License-Identifier: GPL-3.0-or-later
// Task-owned digital mailbox. Stable IDs, bounded storage, no heap or flash writes.
#ifndef RADIO_MESSAGES_H
#define RADIO_MESSAGES_H
#include "radio_call_services.h"
enum { RADIO_MAIL_CAPACITY=16, RADIO_MAIL_QUEUE_MS=120000u };
typedef enum {
    RADIO_MAIL_DRAFT, RADIO_MAIL_QUEUED, RADIO_MAIL_SENDING, RADIO_MAIL_SENT,
    RADIO_MAIL_DELIVERED, RADIO_MAIL_FAILED, RADIO_MAIL_RECEIVED
} radio_mail_state;
typedef enum { RADIO_MAIL_ERROR_NONE, RADIO_MAIL_ERROR_PERMISSION, RADIO_MAIL_ERROR_CHANNEL,
    RADIO_MAIL_ERROR_TIMEOUT, RADIO_MAIL_ERROR_TRANSPORT, RADIO_MAIL_ERROR_CANCELLED } radio_mail_error;
typedef struct {
    radio_message message;
    uint32_t id,stamp;
    uint8_t channel[32];
    uint8_t state,format,error;
    bool unread,ack,truncated;
} radio_mail_item;
typedef struct {
    radio_mail_item items[RADIO_MAIL_CAPACITY];
    uint32_t serial,next_id;
    uint8_t count;
} radio_mailbox;
static inline const char *radio_mail_state_name(unsigned state) {
    static const char *const names[]={"DRAFT","QUEUED","SENDING","SENT","DELIVERED","FAILED","RECEIVED"};
    return state<sizeof names/sizeof *names ? names[state] : "FAILED";
}
static inline bool radio_mail_pending(const radio_mail_item *m) {
    return m->state==RADIO_MAIL_QUEUED || m->state==RADIO_MAIL_SENDING;
}
static inline radio_mail_item *radio_mail_find(radio_mailbox *b,uint32_t id) {
    for(unsigned i=0;i<b->count;++i)if(b->items[i].id==id)return &b->items[i];
    return NULL;
}
static inline radio_mail_item *radio_mail_token(radio_mailbox *b,uint32_t token) {
    if(token)for(unsigned i=0;i<b->count;++i)
        if(b->items[i].message.token==token && b->items[i].state!=RADIO_MAIL_RECEIVED)return &b->items[i];
    return NULL;
}
static inline bool radio_mail_delete(radio_mailbox *b,uint32_t id) {
    for(unsigned i=0;i<b->count;++i)if(b->items[i].id==id) {
        if(radio_mail_pending(&b->items[i]))return false;
        memmove(b->items+i,b->items+i+1,(b->count-i-1u)*sizeof *b->items);
        --b->count;++b->serial;return true;
    }
    return false;
}
static inline radio_mail_item *radio_mail_insert(radio_mailbox *b,const radio_message *message,
        uint8_t state,uint8_t format,uint32_t now) {
    if(!radio_message_valid(message) || format>2u || state>RADIO_MAIL_RECEIVED)return NULL;
    // Never evict an unread received message or a pending transmission. Full is
    // an explicit refusal; a CPS user can read/export/delete to make room.
    if(b->count==RADIO_MAIL_CAPACITY) {
        unsigned i=b->count;
        while(i && (radio_mail_pending(&b->items[i-1]) || b->items[i-1].unread))--i;
        if(!i)return NULL;
        (void)radio_mail_delete(b,b->items[i-1].id);
    }
    memmove(b->items+1,b->items,b->count*sizeof *b->items);++b->count;
    radio_mail_item *m=b->items;memset(m,0,sizeof *m);m->message=*message;
    do {++b->next_id;}while(!b->next_id || radio_mail_find(b,b->next_id));
    m->id=b->next_id;m->stamp=now;m->state=state;m->format=format;
    m->unread=state==RADIO_MAIL_RECEIVED;++b->serial;return m;
}
static inline void radio_mail_set(radio_mailbox *b,radio_mail_item *m,unsigned state,unsigned error) {
    if(m && (m->state!=state || m->error!=error)) {m->state=(uint8_t)state;m->error=(uint8_t)error;++b->serial;}
}
static inline unsigned radio_mail_unread(const radio_mailbox *b) {
    unsigned n=0;for(unsigned i=0;i<b->count;++i)n+=b->items[i].unread;return n;
}
static inline bool radio_mail_read(radio_mailbox *b,uint32_t id) {
    radio_mail_item *m=radio_mail_find(b,id);if(!m)return false;
    if(m->unread) {m->unread=false;++b->serial;}return true;
}
static inline bool radio_mail_same(const radio_mail_item *old,const radio_message *m,unsigned format,bool ack) {
    return old && old->message.source==m->source && old->message.destination==m->destination
        && old->message.protocol==m->protocol && old->message.kind==m->kind
        && old->format==format && old->ack==ack && !strcmp(old->message.text,m->text);
}
#endif
