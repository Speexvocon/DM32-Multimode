// SPDX-License-Identifier: GPL-3.0-or-later
// Lean control-channel input. Packet consumers stay in the controller task.
#ifndef P25_RX_FEED_LIVE_H
#define P25_RX_FEED_LIVE_H
#if DM32_TRUNK_SUBSCRIBER
#include "p25_rx_feed.h"
static p25_rx_feed trunk_rx_feed;
static volatile bool trunk_rx_feed_owned,trunk_rx_feed_timer_running;
static bool trunk_rx_feed_frozen;
enum {FEED_FRAME_ROWS=4u,FEED_STATUS_ROWS=16u,
    FEED_FRAME_BYTES=sizeof(p25_rx)+4u,FEED_STATUS_BYTES=sizeof(p25_demod_status)+4u,
    FEED_STATUS_BASE=FEED_FRAME_ROWS*FEED_FRAME_BYTES};
enum {FEED_HANDOFF_FRAME_FULL=1u,FEED_HANDOFF_STATUS_FULL=2u,
    FEED_HANDOFF_STATUS_STALE=4u,FEED_HANDOFF_FRAME_STALE=8u};
_Static_assert(FEED_STATUS_BASE+FEED_STATUS_ROWS*FEED_STATUS_BYTES<=sizeof monitor.pcm,
    "Control handoff must borrow the inactive speaker arena");
_Static_assert(P25_RX_FEED_STORAGE_BYTES<=sizeof monitor.raw,"Feed exceeds existing raw arena");
static volatile uint8_t trunk_rx_feed_frame_head,trunk_rx_feed_frame_tail;
static volatile uint8_t trunk_rx_feed_status_head,trunk_rx_feed_status_tail;
static volatile bool trunk_rx_feed_handoff_fault;
static bool trunk_rx_feed_selected(void) {return trunk_rx_feed_owned;}
static bool trunk_rx_feed_terminal(void) {return trunk_rx_feed_owned&&trunk_rx_feed_frozen;}
static struct {
    uint32_t calls,total_us,max_us,yields,irq_calls,irq_us,irq_max_us;
    uint32_t frames,statuses,early,pairs,pair_us,pair_max_us;
    uint32_t status_age_us,status_age_max_us,early_age_us,early_age_max_us;
    uint32_t queue_max_us,consumer_max_us,last_sample,last_irq_us;
    uint32_t handoff_reason,handoff_age_us;
    uint32_t last_drain_us,max_controller_gap_us,max_frame_apply_us,max_indicator_us;
    uint32_t max_view_us,max_paint_us;
    uint8_t frame_high,status_high;
    uint32_t early_cpu_us;
    p25_demod_status early_status;
} trunk_rx_feed_work;
static void trunk_rx_feed_ui_cost(bool paint,uint32_t elapsed) {
    if(!trunk_rx_feed_owned||!trunk_rx_feed.sample_limit||trunk_rx_feed_frozen)return;
    // Caller ends the stage before the following controller checkpoint, so
    // a stale refusal/board cleanup cannot be attributed to view or painting.
    uint32_t *maximum=paint?&trunk_rx_feed_work.max_paint_us:&trunk_rx_feed_work.max_view_us;
    if(elapsed>*maximum)*maximum=elapsed;
}
static void trunk_rx_feed_handoff_fail(unsigned fault_reason,uint32_t age) {
    // Both the decoder worker and controller may refuse a handoff. Preserve
    // the actual refusal even if the higher-priority worker preempts a stale
    // controller pop; publish the stop flag only after its evidence is stored.
    uint32_t lock=hrc_irq_save();trunk_rx_feed_work.handoff_reason|=fault_reason;
    if(age>trunk_rx_feed_work.handoff_age_us)trunk_rx_feed_work.handoff_age_us=age;
    hrc_barrier();trunk_rx_feed_handoff_fault=true;hrc_irq_restore(lock);
}
static const p25_rx_feed_chunk *trunk_rx_feed_context;
static uint8_t *trunk_rx_feed_frame_row(unsigned index) {
    return (uint8_t *)monitor.pcm+index*FEED_FRAME_BYTES;
}
static uint8_t *trunk_rx_feed_status_row_data(unsigned index) {
    return (uint8_t *)monitor.pcm+FEED_STATUS_BASE+index*FEED_STATUS_BYTES;
}
static void trunk_rx_feed_timer_stop(void) {
    if(!trunk_rx_feed_timer_running)return;
    trunk_rx_feed_timer_running=false;hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,false);
}
static bool trunk_rx_feed_timer_active(void) {return trunk_rx_feed_timer_running;}
static void trunk_rx_feed_release(void) {
    if(!trunk_rx_feed_owned)return;
    uint32_t lock=hrc_irq_save();trunk_rx_feed_timer_stop();p25_rx_feed_stop(&trunk_rx_feed);
    trunk_rx_feed_owned=false;trunk_rx_feed_frozen=false;trunk_rx_feed.storage=NULL;
    trunk_rx_feed_frame_tail=trunk_rx_feed_frame_head;
    trunk_rx_feed_status_tail=trunk_rx_feed_status_head;hrc_irq_restore(lock);
}
static void trunk_rx_feed_irq(unsigned half,uint32_t now) {
    if(!trunk_rx_feed_owned)return;
    (void)p25_rx_feed_irq(&trunk_rx_feed,half,now);monitor.last_raw_us=now;
}
static void trunk_rx_feed_irq_cost(uint32_t begin) {
    if(!trunk_rx_feed_owned||trunk_rx_feed_frozen)return;
    uint32_t elapsed=hrc_micros()-begin;++trunk_rx_feed_work.irq_calls;
    trunk_rx_feed_work.irq_us+=elapsed;
    if(elapsed>trunk_rx_feed_work.irq_max_us)trunk_rx_feed_work.irq_max_us=elapsed;
}
static void trunk_rx_feed_timer_tick(void) {
    hrc_timer_ack(TIMER_BOARD);
    if(!trunk_rx_feed_timer_running)return;
    if(!trunk_rx_feed_owned||!trunk_enabled||!mon_running||mon_failed||control.cancel||!dev||!dev->buf) {
        p25_rx_feed_stop(&trunk_rx_feed);trunk_rx_feed_timer_stop();return;
    }
    p25_rx_feed_io io={.context=(void *)(dev->buf+C7_FM_RX_AUDIO),
        .read_byte=trunk_rx_progress_byte,.clock_us=trunk_rx_progress_clock,
        .half_pending=trunk_rx_progress_half_pending};
    p25_rx_feed_step_result result=p25_rx_feed_step(&trunk_rx_feed,&io,hrc_micros());
    if(result!=P25_RX_FEED_WAIT&&mon_task_handle) {
        BaseType_t woken=pdFALSE;vTaskNotifyGiveFromISR(mon_task_handle,&woken);portYIELD_FROM_ISR(woken);
    }
    if(!p25_rx_feed_producing(&trunk_rx_feed))trunk_rx_feed_timer_stop();
    else hrc_timer_oneshot(TIMER_BOARD,p25_rx_feed_next_delay(&trunk_rx_feed,hrc_micros()));
}
static void trunk_rx_feed_frame(const p25_rx *frame,void *context) {
    (void)context;if(frame->duid!=7u)return;
    unsigned next=(trunk_rx_feed_frame_head+1u)%FEED_FRAME_ROWS;
    if(next==trunk_rx_feed_frame_tail) {trunk_rx_feed_handoff_fail(FEED_HANDOFF_FRAME_FULL,0u);return;}
    uint8_t *row=trunk_rx_feed_frame_row(trunk_rx_feed_frame_head);uint32_t now=hrc_micros();
    memcpy(row,frame,sizeof *frame);memcpy(row+sizeof *frame,&now,4u);
    // Only this priority6 task writes rows. Publish after the immutable copy;
    // controller pop holds the IRQ lock against preemption by this worker.
    hrc_barrier();
    trunk_rx_feed_frame_head=(uint8_t)next;++trunk_rx_feed_work.frames;
    unsigned queued=(next+FEED_FRAME_ROWS-trunk_rx_feed_frame_tail)%FEED_FRAME_ROWS;
    if(queued>trunk_rx_feed_work.frame_high)trunk_rx_feed_work.frame_high=(uint8_t)queued;
}
static void trunk_rx_feed_status(const p25_demod_status *status,void *context) {
    (void)context;uint32_t now=hrc_micros();
    if(status->selected&&status->qualified&&status->duid==7u&&status->status&&trunk_rx_feed_context) {
        uint32_t age=now-trunk_rx_feed_context->read_end_us;
        ++trunk_rx_feed_work.statuses;trunk_rx_feed_work.status_age_us+=age;
        if(age>trunk_rx_feed_work.status_age_max_us)trunk_rx_feed_work.status_age_max_us=age;
        const p25_demod_status *early=&trunk_rx_feed_work.early_status;
        if(trunk_rx_feed_work.early_cpu_us&&early->sample_tick==status->sample_tick
           &&early->stream_epoch==status->stream_epoch&&early->lane_epoch==status->lane_epoch
           &&early->lane==status->lane&&early->nac==status->nac&&early->status==status->status) {
            uint32_t delta=now-trunk_rx_feed_work.early_cpu_us;
            ++trunk_rx_feed_work.pairs;trunk_rx_feed_work.pair_us+=delta;
            if(delta>trunk_rx_feed_work.pair_max_us)trunk_rx_feed_work.pair_max_us=delta;
            trunk_rx_feed_work.early_cpu_us=0;
        }
    }
    unsigned next=(trunk_rx_feed_status_head+1u)%FEED_STATUS_ROWS;
    if(next==trunk_rx_feed_status_tail) {trunk_rx_feed_handoff_fail(FEED_HANDOFF_STATUS_FULL,0u);return;}
    uint8_t *row=trunk_rx_feed_status_row_data(trunk_rx_feed_status_head);
    memcpy(row,status,sizeof *status);memcpy(row+sizeof *status,&now,4u);
    hrc_barrier();
    trunk_rx_feed_status_head=(uint8_t)next;
    unsigned queued=(next+FEED_STATUS_ROWS-trunk_rx_feed_status_tail)%FEED_STATUS_ROWS;
    if(queued>trunk_rx_feed_work.status_high)trunk_rx_feed_work.status_high=(uint8_t)queued;
}
static void trunk_rx_feed_early(const p25_demod_status *status,void *context) {
    (void)context;if(!trunk_rx_feed_context)return;
    uint32_t now=hrc_micros(),age=now-trunk_rx_feed_context->read_end_us;
    ++trunk_rx_feed_work.early;trunk_rx_feed_work.early_age_us+=age;
    if(age>trunk_rx_feed_work.early_age_max_us)trunk_rx_feed_work.early_age_max_us=age;
    trunk_rx_feed_work.early_status=*status;trunk_rx_feed_work.early_cpu_us=now;
    // Observation only. Never enqueue inherited context to the access gate.
}
static bool trunk_rx_feed_start(unsigned sample_limit,bool tracking) {
    if(!mon_running||mon_control_only||!trunk_enabled||receiver_frequency()!=trunk.control_hz
       ||trunk_rx_progress_owned||trunk_rx_stream_owned||trunk_rx_feed_owned)return false;
    p25_rx_feed_config cfg={P25_RX_FEED_GUARD_US,P25_RX_FEED_MAX_AGE_US,sample_limit};
    uint32_t lock=hrc_irq_save();
    if(++trunk_stream_epoch==0)++trunk_stream_epoch;
    bool ok=p25_rx_feed_start(&trunk_rx_feed,monitor.raw,sizeof monitor.raw,&cfg,trunk_stream_epoch,hrc_micros());
    if(ok) {
        p25_demod_init(&monitor.demod);p25_demod_control_tracking(&monitor.demod,tracking);
        monitor.demod.hunt_clock_us=hrc_micros;
        monitor.demod.rare_fec_clock_us=sample_limit?hrc_micros:NULL;
        memset(&trunk_rx_feed_work,0,sizeof trunk_rx_feed_work);
        if(sample_limit)trunk_rx_feed_work.last_drain_us=trunk_rx_feed.armed_us;
        trunk_rx_feed_frame_head=trunk_rx_feed_frame_tail=0;
        trunk_rx_feed_status_head=trunk_rx_feed_status_tail=0;trunk_rx_feed_handoff_fault=false;
        trunk_rx_feed_frozen=false;trunk_rx_feed_owned=true;trunk_rx_feed_timer_running=true;
        hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,true);hrc_timer_oneshot(TIMER_BOARD,500u);
    }
    hrc_irq_restore(lock);return ok;
}
static bool trunk_rx_feed_backlog(void) {
    return trunk_rx_feed_owned&&p25_rx_feed_active(&trunk_rx_feed)&&trunk_rx_feed.consumed<trunk_rx_feed.produced;
}
static void trunk_rx_feed_worker(void) {
    if(!trunk_rx_feed_owned||trunk_rx_feed_frozen)return;
    p25_rx_feed_chunk chunk;uint32_t begin=hrc_micros(),lock=hrc_irq_save();
    bool have=p25_rx_feed_pop(&trunk_rx_feed,&chunk,begin);hrc_irq_restore(lock);
    if(!have)return;
    uint32_t queued=begin-chunk.read_end_us;
    if(queued>trunk_rx_feed_work.queue_max_us)trunk_rx_feed_work.queue_max_us=queued;
    trunk_rx_feed_context=&chunk;
    for(unsigned i=0;i<P25_RX_FEED_CHUNK_SAMPLES;++i) {
        if(trunk_rx_feed.state==P25_RX_FEED_FAULT||trunk_rx_feed.state==P25_RX_FEED_STOPPED
           ||trunk_rx_feed_handoff_fault)break;
        (void)p25_demod_push_at_observed(&monitor.demod,chunk.samples[i],(uint64_t)(chunk.first_sample+i)*6u,
            trunk_rx_feed.stream_epoch,trunk_rx_feed_frame,trunk_rx_feed_status,trunk_rx_feed_early,NULL);
        trunk_rx_feed_work.last_sample=chunk.first_sample+i;trunk_rx_feed_work.last_irq_us=chunk.origin_irq_us;
    }
    trunk_rx_feed_context=NULL;uint32_t elapsed=hrc_micros()-begin;
    ++trunk_rx_feed_work.calls;trunk_rx_feed_work.total_us+=elapsed;
    if(elapsed>trunk_rx_feed_work.max_us)trunk_rx_feed_work.max_us=elapsed;
}
static void trunk_rx_feed_service(void) {
    if(!trunk_rx_feed_backlog())(void)ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(1));
    uint32_t begin=hrc_micros();
    for(unsigned i=0;i<8u;++i) {
        trunk_rx_feed_worker();if(!trunk_rx_feed_backlog())return;
        if(hrc_micros()-begin>=8000u)break;
    }
    ++trunk_rx_feed_work.yields;vTaskDelay(1);
}
static bool trunk_rx_feed_drain(bool down) {
    if(!trunk_rx_feed_owned||trunk_rx_feed_frozen)return false;
    // Finite diagnostics distinguish prompt source decoding from a blocked
    // controller. Count START-to-first-drain and empty drain intervals too;
    // the handoff age limit stays separate.
    if(trunk_rx_feed.sample_limit) {
        uint32_t now=hrc_micros(),previous=trunk_rx_feed_work.last_drain_us;
        if(previous) {
            uint32_t gap=now-previous;
            if(gap>trunk_rx_feed_work.max_controller_gap_us)trunk_rx_feed_work.max_controller_gap_us=gap;
        }
        trunk_rx_feed_work.last_drain_us=now;
    }
    bool bad=down||control.cancel||trunk_rx_feed_handoff_fault
        ||trunk_rx_feed.state==P25_RX_FEED_FAULT||trunk_rx_feed.state==P25_RX_FEED_STOPPED;
    if(bad) {
        uint32_t lock=hrc_irq_save();p25_rx_feed_stop(&trunk_rx_feed);
        trunk_rx_feed_timer_stop();trunk_rx_feed_frozen=true;hrc_irq_restore(lock);
        mon_failed=true;mon_stop("control_feed_fault");
        trunk_reason="control_feed_fault";ptt_release_required=true;ptt_release_seen=false;return false;
    }
    // No FEC, UI or follower mutations in the sample worker. Hand bounded
    // immutable packets and actually-qualified statuses to this sole controller.
    for(unsigned i=0;i<FEED_STATUS_ROWS;++i) {
        p25_demod_status status;uint32_t stamp=0,lock=hrc_irq_save();
        bool have=trunk_rx_feed_status_tail!=trunk_rx_feed_status_head;
        if(have) {uint8_t *row=trunk_rx_feed_status_row_data(trunk_rx_feed_status_tail);
            memcpy(&status,row,sizeof status);memcpy(&stamp,row+sizeof status,4u);
            trunk_rx_feed_status_tail=(uint8_t)((trunk_rx_feed_status_tail+1u)%FEED_STATUS_ROWS);}
        hrc_irq_restore(lock);if(!have)break;
        uint32_t age=hrc_micros()-stamp;
        if(age>trunk_rx_feed_work.consumer_max_us)trunk_rx_feed_work.consumer_max_us=age;
        if(age>P25_RX_FEED_MAX_AGE_US) {trunk_rx_feed_handoff_fail(FEED_HANDOFF_STATUS_STALE,age);break;}
        trunk_access_status_symbol(&status,NULL);
    }
    for(unsigned i=0;i<FEED_FRAME_ROWS&&!trunk_rx_feed_handoff_fault;++i) {
        p25_rx frame;uint32_t stamp=0,lock=hrc_irq_save();
        bool have=trunk_rx_feed_frame_tail!=trunk_rx_feed_frame_head;
        if(have) {uint8_t *row=trunk_rx_feed_frame_row(trunk_rx_feed_frame_tail);
            memcpy(&frame,row,sizeof frame);memcpy(&stamp,row+sizeof frame,4u);
            trunk_rx_feed_frame_tail=(uint8_t)((trunk_rx_feed_frame_tail+1u)%FEED_FRAME_ROWS);}
        hrc_irq_restore(lock);if(!have)break;
        uint32_t age=hrc_micros()-stamp;
        if(age>trunk_rx_feed_work.consumer_max_us)trunk_rx_feed_work.consumer_max_us=age;
        if(age>P25_RX_FEED_MAX_AGE_US) {trunk_rx_feed_handoff_fail(FEED_HANDOFF_FRAME_STALE,age);break;}
        if(trunk_rx_feed.sample_limit) {
            uint32_t begin=hrc_micros();mon_receive(&frame,NULL);
            uint32_t elapsed=hrc_micros()-begin;
            if(elapsed>trunk_rx_feed_work.max_frame_apply_us)trunk_rx_feed_work.max_frame_apply_us=elapsed;
        } else mon_receive(&frame,NULL);
        if(trunk.pending_hz&&!trunk_rx_feed.sample_limit)break;
    }
    trunk_sample_tick=(uint64_t)trunk_rx_feed_work.last_sample*6u;
    trunk_last_irq_us=trunk_rx_feed_work.last_irq_us;
    if(trunk_rx_feed_handoff_fault) {(void)trunk_rx_feed_drain(down);return false;}
    if(trunk_rx_feed.state==P25_RX_FEED_COMPLETE&&!trunk_rx_feed_frozen) {
        trunk_rx_feed_frozen=true;mon_stop("control_feed_complete");trunk_reason="control_feed_complete";
    }
    return true;
}
static void trunk_rx_feed_poll(bool down) {
    // The display service also drains these queues, without requesting another
    // frame or recursing through the indicator/graphics path.
    if(trunk_rx_feed_drain(down)) {
        if(trunk_rx_feed.sample_limit&&!trunk_rx_feed_frozen) {
            // Include view construction/contact lookup, not only gfx_flush.
            uint32_t begin=hrc_micros();mon_indicator();
            uint32_t elapsed=hrc_micros()-begin;
            if(elapsed>trunk_rx_feed_work.max_indicator_us)trunk_rx_feed_work.max_indicator_us=elapsed;
        } else mon_indicator();
    }
}
static int trunk_rx_feed_status_row(unsigned row,char *line,size_t capacity) {
    if(row==0u)return snprintf(line,capacity,
        "RXFEED schema=1 state=%u owned=%u frozen=%u limit=%lu produced=%lu consumed=%lu faults=%u guard_us=%u max_age_us=%u tracking_mask=%u frames=%lu statuses=%lu early=%lu queue_max_us=%lu consumer_max_us=%lu clock=unqualified\r\n",
        trunk_rx_feed.state,(unsigned)trunk_rx_feed_owned,(unsigned)trunk_rx_feed_frozen,
        (unsigned long)trunk_rx_feed.sample_limit,(unsigned long)trunk_rx_feed.produced,(unsigned long)trunk_rx_feed.consumed,
        trunk_rx_feed.faults,trunk_rx_feed.guard_us,trunk_rx_feed.max_age_us,
        p25_demod_control_tracking_lanes(&monitor.demod),(unsigned long)trunk_rx_feed_work.frames,
        (unsigned long)trunk_rx_feed_work.statuses,(unsigned long)trunk_rx_feed_work.early,
        (unsigned long)trunk_rx_feed_work.queue_max_us,(unsigned long)trunk_rx_feed_work.consumer_max_us);
    if(row==1u)return snprintf(line,capacity,
        "RXFEED_COST calls=%lu total_us=%lu max_us=%lu yields=%lu irq_calls=%lu irq_us=%lu irq_max_us=%lu parser_calls=%lu parser_us=%lu arbitration_us=%lu pairs=%lu pair_us=%lu pair_max_us=%lu status_age_us=%lu status_age_max_us=%lu early_age_us=%lu early_age_max_us=%lu cpu_utilization_measured=0\r\n",
        (unsigned long)trunk_rx_feed_work.calls,(unsigned long)trunk_rx_feed_work.total_us,
        (unsigned long)trunk_rx_feed_work.max_us,(unsigned long)trunk_rx_feed_work.yields,
        (unsigned long)trunk_rx_feed_work.irq_calls,(unsigned long)trunk_rx_feed_work.irq_us,
        (unsigned long)trunk_rx_feed_work.irq_max_us,(unsigned long)monitor.demod.parser_fec_calls,
        (unsigned long)monitor.demod.parser_fec_us,(unsigned long)monitor.demod.fec_us,
        (unsigned long)trunk_rx_feed_work.pairs,(unsigned long)trunk_rx_feed_work.pair_us,
        (unsigned long)trunk_rx_feed_work.pair_max_us,(unsigned long)trunk_rx_feed_work.status_age_us,
        (unsigned long)trunk_rx_feed_work.status_age_max_us,(unsigned long)trunk_rx_feed_work.early_age_us,
        (unsigned long)trunk_rx_feed_work.early_age_max_us);
    if(row==2u)return snprintf(line,capacity,
        "RXFEED_SOURCE epoch=%lu read_calls=%lu read_bytes=%lu max_read_us=%lu source_queue_max_us=%lu handoff_fault=%u handoff_reason=%lu handoff_age_us=%lu frame_high=%u status_high=%u fec_profiled=%u controller_gap_us=%lu frame_apply_us=%lu indicator_us=%lu view_us=%lu paint_us=%lu clock=unqualified\r\n",
        (unsigned long)trunk_rx_feed.stream_epoch,(unsigned long)trunk_rx_feed.read_calls,
        (unsigned long)trunk_rx_feed.read_bytes,(unsigned long)trunk_rx_feed.max_read_us,
        (unsigned long)trunk_rx_feed.max_queue_us,(unsigned)trunk_rx_feed_handoff_fault,
        (unsigned long)trunk_rx_feed_work.handoff_reason,(unsigned long)trunk_rx_feed_work.handoff_age_us,
        (unsigned)trunk_rx_feed_work.frame_high,(unsigned)trunk_rx_feed_work.status_high,
        (unsigned)(monitor.demod.rare_fec_clock_us!=NULL),
        (unsigned long)trunk_rx_feed_work.max_controller_gap_us,
        (unsigned long)trunk_rx_feed_work.max_frame_apply_us,(unsigned long)trunk_rx_feed_work.max_indicator_us,
        (unsigned long)trunk_rx_feed_work.max_view_us,(unsigned long)trunk_rx_feed_work.max_paint_us);
    if(row==3u)return snprintf(line,capacity,"RXFEED_END sample_origin_qualified=0 rf_dispatch_qualified=0\r\n");
    return -1;
}
static bool trunk_rx_feed_command(const char *cmd,bool down) {
    if(!strcmp(cmd,"TRUNK FEED STATUS")) {telemetry_request(TELEMETRY_RXFEED);return true;}
    if(!strncmp(cmd,"TRUNK FEED START ",17u)) {
        const char *text=cmd+17;unsigned values[2]={0};bool valid=true;
        for(unsigned i=0;i<2u;++i) {
            if(*text<'0'||*text>'9') {valid=false;break;}
            do {unsigned digit=(unsigned)(*text++-'0');
                if(values[i]>(8192u-digit)/10u) {valid=false;break;}
                values[i]=values[i]*10u+digit;
            } while(*text>='0'&&*text<='9');
            if(!valid)break;
            if(i==0u) {if(*text++!=' ')valid=false;}else if(*text)valid=false;
        }
        unsigned samples=values[0],tracking=values[1];
        if(!valid||tracking>1u
           ||samples<256u||samples>8192u||samples%256u||!trunk_rx_progress_context(down)||!trunk_start()) {
            send("ERR TRUNK FEED START samples256..8192 multiple256 tracking0..1; idle lab P25 required\r\n");return true;
        }
        trunk_rx_feed_release();
        if(!trunk_rx_feed_start(samples,tracking!=0u)) {trunk_stop("feed_setup_failed");send("ERR TRUNK FEED setup\r\n");}
        else send("OK TRUNK FEED START schema=1 finite receive-only; clock unqualified\r\n");
        return true;
    }
    return false;
}
#endif
#endif
