// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_lab_ptt.h"
#include <string.h>

_Static_assert(sizeof(p25_lab_ptt)<=88u,"Lab PTT exceeds compact intent budget");

static bool within(uint32_t now,uint32_t then,uint32_t limit) {
    return (uint32_t)(now-then)<limit;
}
static bool advanced(uint32_t now,uint32_t then) {
    return now && now!=then && within(now,then,0x80000000u);
}
static bool owner_valid(const p25_lab_exchange_owner *o) {
    return o && o->sequence && o->owner_tag && o->radio_id && o->radio_id<0xffffffu
        && o->request==P25_LAB_GROUP && o->group
        && o->wacn==P25_TRUNK_LAB_WACN && o->system==P25_TRUNK_LAB_SYSTEM
        && o->expected_channel==P25_LAB_VOICE_CHANNEL && o->expected_options==P25_LAB_VOICE_OPTIONS
        && p25_trunking_lab_matches(o->profile,o->control_rx_hz,o->control_tx_hz,o->nac);
}
static bool owner_matches(const p25_lab_exchange_owner *a,const p25_lab_exchange_owner *b) {
    return a && b && a->sequence==b->sequence && a->owner_tag==b->owner_tag
        && a->radio_id==b->radio_id && a->wacn==b->wacn
        && a->control_rx_hz==b->control_rx_hz && a->control_tx_hz==b->control_tx_hz
        && a->nac==b->nac && a->system==b->system && a->group==b->group
        && a->expected_channel==b->expected_channel && a->profile==b->profile
        && a->request==b->request && a->expected_options==b->expected_options;
}
static bool active(const p25_lab_ptt *s) {
    return s && s->phase>=P25_LAB_PTT_ARMED && s->phase<=P25_LAB_PTT_RETURN;
}
bool p25_lab_ptt_owned(const p25_lab_ptt *s) {
    return active(s) || (s && s->needs_rf_off);
}
static void fail(p25_lab_ptt *s,p25_lab_ptt_reason why) {
    s->reason=(uint8_t)why;s->phase=P25_LAB_PTT_FAILED;s->finish_phase=P25_LAB_PTT_FAILED;
}
bool p25_lab_ptt_arm(p25_lab_ptt *s,const p25_lab_exchange_owner *o,
    uint32_t epoch,bool down,bool off,uint32_t now) {
    if(!s || p25_lab_ptt_owned(s) || !owner_valid(o) || !epoch || down || !off
       || (s->owner.sequence && (o->sequence==s->owner.sequence ? s->spent
                                : !advanced(o->sequence,s->owner.sequence))))return false;
    p25_lab_ptt next={0};next.owner=*o;next.arm_epoch=epoch;next.arm_us=now;
    next.phase=P25_LAB_PTT_ARMED;next.finish_phase=P25_LAB_PTT_DONE;*s=next;return true;
}
void p25_lab_ptt_poll(p25_lab_ptt *s,uint32_t now) {
    if(!s)return;
    if(s->phase==P25_LAB_PTT_ARMED) {
        if(!within(now,s->arm_us,P25_LAB_PTT_ARM_US))fail(s,P25_LAB_PTT_EXPIRED);
    } else if(s->phase==P25_LAB_PTT_REQUEST || s->phase==P25_LAB_PTT_GRANTED) {
        if(!within(now,s->request_us,P25_LAB_PTT_REQUEST_US)
           || (s->phase==P25_LAB_PTT_GRANTED
               && !within(now,s->grant_us,P25_LAB_VOICE_LEASE_US)))fail(s,P25_LAB_PTT_EXPIRED);
    } else if(s->phase==P25_LAB_PTT_VOICE || s->phase==P25_LAB_PTT_DRAIN) {
        if(!within(now,s->voice_us,P25_LAB_PTT_VOICE_US))fail(s,P25_LAB_PTT_EXPIRED);
    } else if(s->phase==P25_LAB_PTT_RETURN
              && !within(now,s->end_us,P25_LAB_PTT_RETURN_US))fail(s,P25_LAB_PTT_EPOCH);
}
void p25_lab_ptt_cancel(p25_lab_ptt *s,p25_lab_ptt_reason why) {
    if(!p25_lab_ptt_owned(s))return;
    s->reason=(uint8_t)(why==P25_LAB_PTT_OK ? P25_LAB_PTT_CANCEL:why);
    s->finish_phase=P25_LAB_PTT_CANCELLED;
    if(s->phase!=P25_LAB_PTT_RETURN)s->phase=P25_LAB_PTT_CANCELLED;
}
p25_lab_ptt_action p25_lab_ptt_input(p25_lab_ptt *s,
    const p25_lab_exchange_owner *current,bool down,bool permission,uint32_t now) {
    if(!active(s))return P25_LAB_PTT_NONE;
    p25_lab_ptt_poll(s,now);if(!active(s))return P25_LAB_PTT_ABORT;
    if(!owner_matches(&s->owner,current)) {fail(s,P25_LAB_PTT_OWNER);return P25_LAB_PTT_ABORT;}
    if(!permission) {fail(s,P25_LAB_PTT_PERMISSION);return P25_LAB_PTT_ABORT;}
    bool rising=down && !s->last_down;s->last_down=(uint8_t)down;
    if(s->phase==P25_LAB_PTT_ARMED && rising) {
        // This consumes the only armed transaction before request setup/keying.
        s->phase=P25_LAB_PTT_REQUEST;s->request_us=now;s->needs_rf_off=1;
        return P25_LAB_PTT_SEND_REQUEST;
    }
    if(!down && (s->phase==P25_LAB_PTT_REQUEST || s->phase==P25_LAB_PTT_GRANTED)) {
        p25_lab_ptt_cancel(s,P25_LAB_PTT_RELEASE);return P25_LAB_PTT_ABORT;
    }
    if(!down && s->phase==P25_LAB_PTT_VOICE) {
        s->phase=P25_LAB_PTT_DRAIN;return P25_LAB_PTT_BEGIN_DRAIN;
    }
    return P25_LAB_PTT_NONE;
}
bool p25_lab_ptt_bind_prepared(p25_lab_ptt *s,const p25_lab_exchange *e,
    const p25_lab_exchange_owner *current,uint32_t now) {
    if(!s || s->phase!=P25_LAB_PTT_REQUEST || s->request_epoch)return false;
    p25_lab_ptt_poll(s,now);if(s->phase!=P25_LAB_PTT_REQUEST)return false;
    if(!e || e->phase!=P25_LAB_PREPARED || e->reason!=P25_LAB_OK
       || !owner_matches(&s->owner,current) || !owner_matches(&s->owner,&e->owner)
       || !e->previous_epoch || (e->previous_epoch!=s->arm_epoch && !advanced(e->previous_epoch,s->arm_epoch))
       || !within(e->prepared_us,s->request_us,P25_LAB_PTT_REQUEST_US)
       || !within(now,e->prepared_us,P25_LAB_PTT_REQUEST_US))return false;
    // A refused PREPARE has not reserved a probe sequence or permitted FIRE.
    // Bind spends that sequence; no subsequent ARM may reuse it.
    s->request_epoch=e->previous_epoch;s->prepared_us=e->prepared_us;s->spent=1;return true;
}
static bool reply_matches(const p25_lab_ptt *s,const p25_lab_exchange *e) {
    return e && owner_valid(&e->owner) && owner_matches(&s->owner,&e->owner)
        && e->phase==P25_LAB_REPLY && e->reason==P25_LAB_OK
        && e->reply_type==P25_TRUNK_OSP_GROUP_GRANT && !e->response
        && e->replies && e->replies<=P25_LAB_EXCHANGE_MAX_REPLIES
        && e->reply_source==s->owner.radio_id && e->reply_group==s->owner.group
        && e->reply_channel==s->owner.expected_channel && e->reply_options==s->owner.expected_options
        && s->request_epoch && e->previous_epoch==s->request_epoch
        && e->prepared_us==s->prepared_us && advanced(e->rx_epoch,s->request_epoch)
        && within(e->rx_ready_us,e->cutoff_us,P25_LAB_EXCHANGE_RETURN_US)
        && within(e->reply_us,e->rx_ready_us,P25_LAB_EXCHANGE_REPLY_US)
        && within(e->reply_us,e->cutoff_us,P25_LAB_EXCHANGE_REPLY_US)
        && within(e->prepared_us,s->request_us,P25_LAB_PTT_REQUEST_US)
        && within(e->reply_us,s->request_us,P25_LAB_PTT_REQUEST_US);
}
bool p25_lab_ptt_grant(p25_lab_ptt *s,const p25_lab_exchange *e,
    const p25_lab_exchange_owner *current,bool down,bool permission,uint32_t now) {
    if(!s || s->phase!=P25_LAB_PTT_REQUEST)return false;
    if(p25_lab_ptt_input(s,current,down,permission,now)==P25_LAB_PTT_ABORT)return false;
    if(s->phase!=P25_LAB_PTT_REQUEST || !reply_matches(s,e))return false;
    if(!within(now,e->reply_us,P25_LAB_VOICE_LEASE_US)) {fail(s,P25_LAB_PTT_EXPIRED);return false;}
    s->grant_epoch=e->rx_epoch;s->grant_us=e->reply_us;s->phase=P25_LAB_PTT_GRANTED;return true;
}
bool p25_lab_ptt_allow_held(const p25_lab_ptt *s,
    const p25_lab_exchange_owner *current,bool down,uint32_t now) {
    if(!s || !down || !s->last_down || !s->needs_rf_off || !owner_matches(&s->owner,current))return false;
    if(s->phase==P25_LAB_PTT_REQUEST)return within(now,s->request_us,P25_LAB_PTT_REQUEST_US);
    if(s->phase==P25_LAB_PTT_GRANTED)return within(now,s->request_us,P25_LAB_PTT_REQUEST_US)
        && within(now,s->grant_us,P25_LAB_VOICE_LEASE_US);
    return s->phase==P25_LAB_PTT_VOICE && within(now,s->voice_us,P25_LAB_PTT_VOICE_US);
}
bool p25_lab_ptt_voice_started(p25_lab_ptt *s,
    const p25_lab_exchange_owner *current,bool down,uint32_t now) {
    if(!s || s->phase!=P25_LAB_PTT_GRANTED)return false;
    if(p25_lab_ptt_input(s,current,down,true,now)==P25_LAB_PTT_ABORT)return false;
    if(!p25_lab_ptt_allow_held(s,current,down,now))return false;
    s->voice_us=now;s->phase=P25_LAB_PTT_VOICE;return true;
}
bool p25_lab_ptt_drain(p25_lab_ptt *s,uint32_t now) {
    if(!s || s->phase!=P25_LAB_PTT_VOICE)return false;
    p25_lab_ptt_poll(s,now);if(s->phase!=P25_LAB_PTT_VOICE)return false;
    s->phase=P25_LAB_PTT_DRAIN;return true;
}
bool p25_lab_ptt_tx_done(p25_lab_ptt *s,bool success,bool off,uint32_t now) {
    if(!s || !s->needs_rf_off)return false;
    if(!off) {fail(s,P25_LAB_PTT_RF_NOT_OFF);return false;}
    bool accepted=true;
    if(success) {
        p25_lab_ptt_poll(s,now);
        if(s->phase!=P25_LAB_PTT_DRAIN) {
            if(s->reason==P25_LAB_PTT_OK)fail(s,P25_LAB_PTT_TRANSPORT);
            accepted=false;
        }
    } else if(s->reason==P25_LAB_PTT_OK)fail(s,P25_LAB_PTT_TRANSPORT);
    s->end_us=now;s->needs_rf_off=0;s->phase=P25_LAB_PTT_RETURN;return accepted;
}
bool p25_lab_ptt_return_ready(p25_lab_ptt *s,uint32_t epoch,bool raw,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_PTT_RETURN)return false;
    if(!off) {fail(s,P25_LAB_PTT_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    p25_lab_ptt_poll(s,now);if(s->phase!=P25_LAB_PTT_RETURN)return false;
    uint32_t previous=s->grant_epoch ? s->grant_epoch:s->request_epoch ? s->request_epoch:s->arm_epoch;
    if(!raw || !advanced(epoch,previous))return false;
    s->return_epoch=epoch;s->ready_us=now;s->phase=s->finish_phase;return true;
}
bool p25_lab_ptt_abort_off(p25_lab_ptt *s,bool off,uint32_t now) {
    if(!s || !p25_lab_ptt_owned(s))return false;
    if(!off) {fail(s,P25_LAB_PTT_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    if(s->reason==P25_LAB_PTT_OK)s->reason=P25_LAB_PTT_CANCEL;
    s->end_us=now;s->needs_rf_off=0;s->finish_phase=P25_LAB_PTT_CANCELLED;
    s->phase=P25_LAB_PTT_CANCELLED;return true;
}
