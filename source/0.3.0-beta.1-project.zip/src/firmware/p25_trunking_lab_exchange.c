// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_lab_exchange.h"
#include <string.h>

_Static_assert(sizeof(p25_lab_exchange)<=112u,"Finite lab exchange exceeds compact RAM budget");
static bool owner_valid(const p25_lab_exchange_owner *o) {
    return o && o->sequence && o->owner_tag && o->radio_id && o->radio_id<0xffffffu
        && o->wacn && o->wacn<=0xfffffu && o->system && o->system<=0xfffu
        && o->nac<=0xfffu && o->group && o->control_rx_hz && o->control_tx_hz
        && o->control_rx_hz!=o->control_tx_hz
        && o->request>=P25_LAB_REGISTER && o->request<=P25_LAB_GROUP
        && (o->request==P25_LAB_GROUP ? o->expected_channel && !(o->expected_options&~0x87u)
            : !o->expected_channel && !o->expected_options);
}
bool p25_lab_exchange_active(const p25_lab_exchange *s) {
    return s && s->phase>=P25_LAB_PREPARED && s->phase<=P25_LAB_WAIT_REPLY;
}
bool p25_lab_exchange_owner_matches(const p25_lab_exchange *s,const p25_lab_exchange_owner *o) {
    return s && owner_valid(o) && o->sequence==s->owner.sequence && o->owner_tag==s->owner.owner_tag
        && o->radio_id==s->owner.radio_id && o->wacn==s->owner.wacn && o->system==s->owner.system
        && o->nac==s->owner.nac && o->group==s->owner.group && o->profile==s->owner.profile
        && o->request==s->owner.request && o->control_rx_hz==s->owner.control_rx_hz
        && o->control_tx_hz==s->owner.control_tx_hz && o->expected_channel==s->owner.expected_channel
        && o->expected_options==s->owner.expected_options;
}
bool p25_lab_exchange_prepare(p25_lab_exchange *s,const p25_lab_exchange_owner *o,
    uint32_t epoch,uint32_t now) {
    if(!s || !owner_valid(o) || p25_lab_exchange_active(s) || s->owner.sequence==o->sequence)return false;
    p25_lab_exchange value={0};value.owner=*o;value.previous_epoch=epoch;
    value.prepared_us=now;value.phase=P25_LAB_PREPARED;*s=value;return true;
}
void p25_lab_exchange_cancel(p25_lab_exchange *s,p25_lab_reason why) {
    if(!p25_lab_exchange_active(s))return;
    s->phase=P25_LAB_CANCELLED;s->reason=why;
}
static bool expired(p25_lab_exchange *s,uint32_t now,uint32_t start,uint32_t length) {
    if((uint32_t)(now-start)<length)return false;
    s->phase=P25_LAB_TIMEOUT;s->reason=P25_LAB_EXPIRED;return true;
}
void p25_lab_exchange_poll(p25_lab_exchange *s,uint32_t now) {
    if(!p25_lab_exchange_active(s))return;
    if(s->phase==P25_LAB_PREPARED)(void)expired(s,now,s->prepared_us,P25_LAB_EXCHANGE_WARM_US);
    else if(s->phase==P25_LAB_TX_ACTIVE)(void)expired(s,now,s->tx_started_us,P25_LAB_EXCHANGE_TX_US);
    else if(s->phase==P25_LAB_RETURN_PENDING || s->phase==P25_LAB_RX_STARTING)
        (void)expired(s,now,s->cutoff_us,P25_LAB_EXCHANGE_RETURN_US);
    else (void)expired(s,now,s->cutoff_us,P25_LAB_EXCHANGE_REPLY_US);
}
bool p25_lab_exchange_tx_started(p25_lab_exchange *s,uint32_t sequence,uint32_t now) {
    if(!s || s->phase!=P25_LAB_PREPARED || sequence!=s->owner.sequence)return false;
    if(expired(s,now,s->prepared_us,P25_LAB_EXCHANGE_WARM_US))return false;
    s->tx_started_us=now;s->phase=P25_LAB_TX_ACTIVE;return true;
}
bool p25_lab_exchange_tx_done(p25_lab_exchange *s,uint32_t sequence,bool success,uint32_t now) {
    if(!s || s->phase!=P25_LAB_TX_ACTIVE || sequence!=s->owner.sequence)return false;
    if(!success) {s->phase=P25_LAB_FAILED;s->reason=P25_LAB_TRANSPORT;return false;}
    if(expired(s,now,s->tx_started_us,P25_LAB_EXCHANGE_TX_US))return false;
    s->cutoff_us=now;s->deadline_us=now+P25_LAB_EXCHANGE_REPLY_US;
    s->phase=P25_LAB_RETURN_PENDING;return true;
}
bool p25_lab_exchange_begin_return(p25_lab_exchange *s,uint32_t sequence,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_RETURN_PENDING || sequence!=s->owner.sequence)return false;
    if(!off) {s->phase=P25_LAB_FAILED;s->reason=P25_LAB_RF_NOT_OFF;return false;}
    if(expired(s,now,s->cutoff_us,P25_LAB_EXCHANGE_RETURN_US))return false;
    s->return_begin_us=now;s->phase=P25_LAB_RX_STARTING;return true;
}
bool p25_lab_exchange_rx_ready(p25_lab_exchange *s,uint32_t sequence,bool off,uint32_t epoch,uint32_t now) {
    if(!s || s->phase!=P25_LAB_RX_STARTING || sequence!=s->owner.sequence)return false;
    if(!off) {s->phase=P25_LAB_FAILED;s->reason=P25_LAB_RF_NOT_OFF;return false;}
    if(!epoch || epoch==s->previous_epoch) {s->phase=P25_LAB_FAILED;s->reason=P25_LAB_EPOCH;return false;}
    if(expired(s,now,s->cutoff_us,P25_LAB_EXCHANGE_RETURN_US))return false;
    s->rx_epoch=epoch;s->rx_ready_us=now;s->phase=P25_LAB_WAIT_REPLY;return true;
}
static bool reply_matches(const p25_lab_exchange *s,const p25_trunking_osp *e) {
    unsigned service=s->owner.request==P25_LAB_REGISTER ? 0x2cu : s->owner.request==P25_LAB_AFFILIATE ? 0x28u:0u;
    if(e->type==P25_TRUNK_OSP_ACK || e->type==P25_TRUNK_OSP_QUEUED || e->type==P25_TRUNK_OSP_DENIED)
        return e->target==s->owner.radio_id && e->service==service
            && (!e->additional || e->extended || s->owner.request==P25_LAB_REGISTER || e->group==s->owner.group);
    if(s->owner.request==P25_LAB_REGISTER)
        return e->type==P25_TRUNK_OSP_REGISTRATION && e->target==s->owner.radio_id && e->system==s->owner.system
            && (e->response || e->assigned==s->owner.radio_id);
    if(s->owner.request==P25_LAB_AFFILIATE)
        return e->type==P25_TRUNK_OSP_AFFILIATION && e->target==s->owner.radio_id && e->group==s->owner.group;
    return e->type==P25_TRUNK_OSP_GROUP_GRANT && e->source==s->owner.radio_id && e->group==s->owner.group
        && e->channel==s->owner.expected_channel && !e->encrypted && !(e->options&~0x87u)
        && e->options==s->owner.expected_options;
}
bool p25_lab_exchange_consume(p25_lab_exchange *s,uint32_t sequence,uint32_t tag,uint32_t epoch,
    uint16_t nac,uint32_t hz,const uint8_t block[12],uint32_t now) {
    if(!s || s->phase!=P25_LAB_WAIT_REPLY || sequence!=s->owner.sequence || tag!=s->owner.owner_tag
       || epoch!=s->rx_epoch || nac!=s->owner.nac || hz!=s->owner.control_rx_hz)return false;
    if(expired(s,now,s->cutoff_us,P25_LAB_EXCHANGE_REPLY_US))return false;
    if((int32_t)(now-s->rx_ready_us)<0)return false;
    p25_trunking_osp event;if(!p25_trunking_osp_parse(block,&event) || !reply_matches(s,&event))return false;
    if(s->replies>=P25_LAB_EXCHANGE_MAX_REPLIES) {s->phase=P25_LAB_FAILED;s->reason=P25_LAB_REPLY_LIMIT;return false;}
    ++s->replies;s->reply_us=now;s->reply_type=(uint8_t)event.type;s->response=event.response;
    s->service=event.service;s->opcode=event.opcode;s->assigned=event.assigned;
    s->reply_group=event.group;s->reply_channel=event.channel;
    s->reply_source=event.source;s->reply_options=event.options;
    if(event.type!=P25_TRUNK_OSP_ACK && event.type!=P25_TRUNK_OSP_QUEUED)s->phase=P25_LAB_REPLY;
    return true;
}
