// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef DM32_RF_COMPAT_H
#define DM32_RF_COMPAT_H

// Experimental build only. The ordinary beta keeps the pinned board adapter.
#ifndef DM32_RF_B_EXPERIMENTAL
#define DM32_RF_B_EXPERIMENTAL 0
#endif
#if DM32_RF_B_EXPERIMENTAL != 0 && DM32_RF_B_EXPERIMENTAL != 1
#error DM32_RF_B_EXPERIMENTAL must be 0 or 1
#endif

// Read-only, no bus traffic: A = classic locked, B = fallback locked,
// '-' = neither locked and TX refused. Does not establish hardware qualification.
#if DM32_RF_B_EXPERIMENTAL
char dm32_rf_compat_setup(void);
#endif

#endif
