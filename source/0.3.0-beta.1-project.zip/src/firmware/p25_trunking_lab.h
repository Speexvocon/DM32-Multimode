// SPDX-License-Identifier: GPL-3.0-or-later
// Exact laboratory tuples only. These records confer no access/timing authority.
#ifndef P25_TRUNKING_LAB_H
#define P25_TRUNKING_LAB_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

enum {P25_TRUNK_LAB_LEGACY5M=0u,P25_TRUNK_LAB_COMMONIQ1M=1u,
      P25_TRUNK_LAB_PROFILE_COUNT=2u};
#define P25_TRUNK_LAB_NAC 0x293u
#define P25_TRUNK_LAB_WACN 0xabcdeu
#define P25_TRUNK_LAB_SYSTEM 0x123u
typedef struct {
    uint32_t control_rx_hz,control_tx_hz,voice_rx_hz,voice_tx_hz;
} p25_trunking_lab_profile;

static inline const p25_trunking_lab_profile *p25_trunking_lab_get(unsigned id) {
    static const p25_trunking_lab_profile profiles[P25_TRUNK_LAB_PROFILE_COUNT]={
        {440075000u,445075000u,440087500u,445087500u},
        {440075000u,441075000u,440087500u,441087500u}
    };
    return id<P25_TRUNK_LAB_PROFILE_COUNT ? &profiles[id] : NULL;
}
static inline const char *p25_trunking_lab_name(unsigned id) {
    return id==P25_TRUNK_LAB_LEGACY5M ? "LEGACY5M" :
        id==P25_TRUNK_LAB_COMMONIQ1M ? "COMMONIQ1M" : "INVALID";
}
static inline bool p25_trunking_lab_parse(const char *name,uint8_t *id) {
    if(!name || !id)return false;
    for(unsigned i=0;i<P25_TRUNK_LAB_PROFILE_COUNT;++i)
        if(!strcmp(name,p25_trunking_lab_name(i))) {*id=(uint8_t)i;return true;}
    return false;
}
static inline bool p25_trunking_lab_matches(unsigned id,uint32_t rx,uint32_t tx,uint16_t nac) {
    const p25_trunking_lab_profile *p=p25_trunking_lab_get(id);
    return p && rx==p->control_rx_hz && tx==p->control_tx_hz && nac==P25_TRUNK_LAB_NAC;
}
static inline bool p25_trunking_lab_frozen_matches(unsigned selected,unsigned frozen,
                                                uint32_t rx,uint32_t tx,uint16_t nac) {
    return selected==frozen && p25_trunking_lab_matches(frozen,rx,tx,nac);
}
#endif
