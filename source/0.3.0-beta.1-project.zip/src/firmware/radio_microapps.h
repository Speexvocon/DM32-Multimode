// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_MICROAPPS_H
#define RADIO_MICROAPPS_H

#include <stdbool.h>
#include <stdint.h>

#define RADIO_MICROAPPS_COMMAND_MAX 95u
#define RADIO_MICROAPPS_HEADER_MAX 252u
#define RADIO_MICROAPPS_SAME_DEFAULT_HZ 162550000u

typedef enum { RADIO_MICROAPP_NONE, RADIO_MICROAPP_SAME } radio_microapp_kind_t;

typedef struct {
    // Task context only. start_same must unwind partial setup before returning
    // false; stop restores the radio state saved by a successful start.
    bool (*start_same)(void *opaque,uint32_t hz);
    void (*stop)(void *opaque);
    // A bounded printable line, without CR/LF. Consume/copy before returning.
    // The owner may queue output here; it must not block the RF/audio service.
    void (*emit)(void *opaque,const char *line);
    // Optional task-context capture/decoder counters after generic STATUS.
    void (*status)(void *opaque);
} radio_microapps_hal_t;

typedef struct {
    radio_microapps_hal_t hal;
    void *opaque;
    radio_microapp_kind_t active;
    uint32_t frequency_hz,headers;
    bool watch,last_confirmed;
    char last[RADIO_MICROAPPS_HEADER_MAX+1u];
} radio_microapps_t;

// Initialize once while idle. No hardware access or output.
void radio_microapps_init(radio_microapps_t *apps,const radio_microapps_hal_t *hal,void *opaque);
bool radio_microapps_same_frequency_valid(uint32_t hz);
// Only consumes the exact APP/APPS namespace; unrelated CPS/STATUS/STOP lines
// return false. Caller supplies a NUL-terminated line. No heap or execution of
// supplied source: apps are compiled-in callbacks registered in this module.
bool radio_microapps_command(radio_microapps_t *apps,const char *line);
// Silent, idempotent stop for CPS takeover, local input or capture failure.
void radio_microapps_stop(radio_microapps_t *apps);
// Publish a decoder result from task context, never the capture ISR. This is
// bounded transport/storage, not a SAME protocol validator. Returns false on
// inactive app, empty/oversized input or non-printable ASCII. Last survives
// STOP; a successful new session clears last and the session event count.
bool radio_microapps_publish_same(radio_microapps_t *apps,const char *header,unsigned length,bool confirmed);

#endif
