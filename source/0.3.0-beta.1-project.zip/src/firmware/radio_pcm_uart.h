// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_PCM_UART_H
#define RADIO_PCM_UART_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Task-context ownership: normal host writes must be suspended during PCM.
// Supported rates only; drains at the old rate (bounded150ms), clears stale RX
// and IRQ TX bytes, verifies divisor, and restores receive interrupts. RF must
// already be off before restoring115200. False also reports a drain timeout;
// the requested divisor/reset is still attempted so stale bytes cannot leak.
bool dm32_pcm_uart_baud(uint32_t baud);
// Nonblocking single task producer; at most128 bytes accepted per invocation.
// A2048-byte ring is consumed by the existing UART IRQ,64 bytes per pass.
size_t dm32_pcm_uart_write(const uint8_t *data,size_t length);
bool dm32_pcm_uart_idle(void);
bool dm32_pcm_uart_drain(uint32_t timeout_ms);
#endif
