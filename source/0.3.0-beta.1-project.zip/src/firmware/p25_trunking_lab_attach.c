// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_lab_attach.h"
#include <string.h>

_Static_assert(sizeof(p25_lab_attach)<=112u,"Finite attach exceeds compact state budget");
static bool within(uint32_t now,uint32_t then,uint32_t limit) {return (uint32_t)(now-then)<limit;}
static bool advanced(uint32_t now,uint32_t then) {return now && now!=then && within(now,then,0x80000000u);}
static uint32_t next_sequence(uint32_t sequence) {++sequence;return sequence ? sequence:1u;}
static bool owner_matches(const p25_lab_exchange_owner *a,const p25_lab_exchange_owner *b) {
    return a && b && a->sequence==b->sequence && a->owner_tag==b->owner_tag
        && a->radio_id==b->radio_id && a->wacn==b->wacn
        && a->control_rx_hz==b->control_rx_hz && a->control_tx_hz==b->control_tx_hz
        && a->nac==b->nac && a->system==b->system && a->group==b->group
        && a->expected_channel==b->expected_channel && a->profile==b->profile
        && a->request==b->request && a->expected_options==b->expected_options;
}
static bool owner_valid(const p25_lab_exchange_owner *o) {
    return o && o->sequence && o->owner_tag && o->radio_id && o->radio_id<0xffffffu
        && o->request==P25_LAB_GROUP && o->group
        && o->wacn==P25_TRUNK_LAB_WACN && o->system==P25_TRUNK_LAB_SYSTEM
        && o->expected_channel==P25_LAB_VOICE_CHANNEL && o->expected_options==P25_LAB_VOICE_OPTIONS
        && p25_trunking_lab_matches(o->profile,o->control_rx_hz,o->control_tx_hz,o->nac);
}
static bool active(const p25_lab_attach *s) {
    return s && s->phase>=P25_LAB_ATTACH_REGISTER && s->phase<=P25_LAB_ATTACH_ARM_PTT;
}
bool p25_lab_attach_owned(const p25_lab_attach *s) {return active(s) || (s && s->needs_rf_off);}
static void fail(p25_lab_attach *s,p25_lab_attach_reason why) {
    s->phase=P25_LAB_ATTACH_FAILED;s->reason=(uint8_t)why;
}
bool p25_lab_attach_start(p25_lab_attach *s,const p25_lab_exchange_owner *o,
    uint32_t epoch,bool released,bool permission,bool off,uint32_t now) {
    if(!s || p25_lab_attach_owned(s) || !owner_valid(o) || !epoch || !released || !permission || !off
       || (s->used_sequence && !advanced(o->sequence,s->used_sequence)))return false;
    uint32_t used=s->used_sequence;p25_lab_attach next={0};next.owner=*o;
    next.start_epoch=epoch;next.start_us=now;next.used_sequence=used;
    next.phase=P25_LAB_ATTACH_REGISTER;*s=next;return true;
}
void p25_lab_attach_poll(p25_lab_attach *s,uint32_t now) {
    if(!active(s))return;
    if(!within(now,s->start_us,P25_LAB_ATTACH_TOTAL_US))fail(s,P25_LAB_ATTACH_EXPIRED);
    else if((s->phase==P25_LAB_ATTACH_WAIT_REG || s->phase==P25_LAB_ATTACH_WAIT_AFF)
            && !within(now,s->prepared_us,P25_LAB_ATTACH_LEG_US))fail(s,P25_LAB_ATTACH_EXPIRED);
    else if(s->phase==P25_LAB_ATTACH_RETURN
            && !within(now,s->return_us,P25_LAB_ATTACH_RETURN_US))fail(s,P25_LAB_ATTACH_EPOCH);
}
void p25_lab_attach_cancel(p25_lab_attach *s,p25_lab_attach_reason why) {
    if(!s || (!p25_lab_attach_owned(s) && s->phase!=P25_LAB_ATTACH_ARMED))return;
    s->phase=P25_LAB_ATTACH_CANCELLED;
    s->reason=(uint8_t)(why==P25_LAB_ATTACH_OK ? P25_LAB_ATTACH_CANCEL:why);
}
bool p25_lab_attach_input(p25_lab_attach *s,const p25_lab_exchange_owner *current,
    bool released,bool permission,uint32_t now) {
    if(!active(s))return false;
    p25_lab_attach_poll(s,now);if(!active(s))return false;
    if(!owner_matches(&s->owner,current)) {fail(s,P25_LAB_ATTACH_OWNER);return false;}
    if(!released) {p25_lab_attach_cancel(s,P25_LAB_ATTACH_PTT);return false;}
    if(!permission) {fail(s,P25_LAB_ATTACH_PERMISSION);return false;}
    return true;
}
static bool stage_owner(const p25_lab_attach *s,bool affiliation,p25_lab_exchange_owner *out) {
    if(!s || !out || !owner_valid(&s->owner))return false;
    p25_lab_exchange_owner value=s->owner;
    value.request=affiliation ? P25_LAB_AFFILIATE:P25_LAB_REGISTER;
    value.sequence=affiliation ? next_sequence(value.sequence):value.sequence;
    value.expected_channel=0;value.expected_options=0;*out=value;return true;
}
bool p25_lab_attach_leg_owner(const p25_lab_attach *s,p25_lab_exchange_owner *out) {
    if(!s || (s->phase!=P25_LAB_ATTACH_REGISTER && s->phase!=P25_LAB_ATTACH_AFFILIATE))return false;
    return stage_owner(s,s->phase==P25_LAB_ATTACH_AFFILIATE,out);
}
bool p25_lab_attach_ptt_owner(const p25_lab_attach *s,p25_lab_exchange_owner *out) {
    if(!s || !out || (s->phase!=P25_LAB_ATTACH_READY && s->phase!=P25_LAB_ATTACH_ARM_PTT
        && s->phase!=P25_LAB_ATTACH_ARMED) || !owner_valid(&s->owner))return false;
    p25_lab_exchange_owner value=s->owner;value.sequence=next_sequence(next_sequence(value.sequence));
    *out=value;return true;
}
bool p25_lab_attach_bind_prepared(p25_lab_attach *s,const p25_lab_exchange *e,
    const p25_lab_exchange_owner *current,uint32_t now) {
    if(!s || (s->phase!=P25_LAB_ATTACH_REGISTER && s->phase!=P25_LAB_ATTACH_AFFILIATE))return false;
    p25_lab_attach_poll(s,now);p25_lab_exchange_owner expected;
    if(!p25_lab_attach_leg_owner(s,&expected))return false;
    uint32_t epoch=s->registration.sequence ? s->registration.rx_epoch:s->start_epoch;
    uint32_t origin=s->registration.sequence ? s->registration.reply_us:s->start_us;
    if(!e || !owner_matches(&s->owner,current) || e->phase!=P25_LAB_PREPARED || e->reason!=P25_LAB_OK
       || !owner_matches(&expected,&e->owner) || !e->previous_epoch
       || (e->previous_epoch!=epoch && !advanced(e->previous_epoch,epoch))
       || !within(e->prepared_us,origin,P25_LAB_ATTACH_TOTAL_US)
       || !within(e->prepared_us,s->start_us,P25_LAB_ATTACH_TOTAL_US)
       || !within(now,e->prepared_us,P25_LAB_EXCHANGE_WARM_US)
       || (s->used_sequence && !advanced(expected.sequence,s->used_sequence)))return false;
    s->prepared_epoch=e->previous_epoch;s->prepared_us=e->prepared_us;
    s->used_sequence=expected.sequence;s->needs_rf_off=1;
    s->phase=s->phase==P25_LAB_ATTACH_REGISTER ? P25_LAB_ATTACH_WAIT_REG:P25_LAB_ATTACH_WAIT_AFF;
    return true;
}
static bool exchange_matches(const p25_lab_attach *s,const p25_lab_exchange *e,bool affiliation) {
    p25_lab_exchange_owner expected;
    if(!stage_owner(s,affiliation,&expected))return false;
    return e && owner_matches(&expected,&e->owner) && e->reason==P25_LAB_OK
        && e->previous_epoch==s->prepared_epoch && e->prepared_us==s->prepared_us
        && advanced(e->rx_epoch,s->prepared_epoch)
        && within(e->tx_started_us,e->prepared_us,P25_LAB_EXCHANGE_WARM_US)
        && within(e->cutoff_us,e->tx_started_us,P25_LAB_EXCHANGE_TX_US)
        && within(e->return_begin_us,e->cutoff_us,P25_LAB_EXCHANGE_RETURN_US)
        && within(e->rx_ready_us,e->return_begin_us,P25_LAB_EXCHANGE_RETURN_US)
        && within(e->rx_ready_us,e->cutoff_us,P25_LAB_EXCHANGE_RETURN_US)
        && within(e->reply_us,e->rx_ready_us,P25_LAB_EXCHANGE_REPLY_US)
        && within(e->reply_us,e->cutoff_us,P25_LAB_EXCHANGE_REPLY_US)
        && e->replies && e->replies<=P25_LAB_EXCHANGE_MAX_REPLIES
        && !e->response && (affiliation ?
            e->reply_type==P25_TRUNK_OSP_AFFILIATION && e->reply_group==s->owner.group :
            e->reply_type==P25_TRUNK_OSP_REGISTRATION && e->assigned==s->owner.radio_id);
}
bool p25_lab_attach_observe(p25_lab_attach *s,const p25_lab_exchange *e,
    const p25_lab_exchange_owner *current,bool released,bool permission,bool off,uint32_t now) {
    if(!s || (s->phase!=P25_LAB_ATTACH_WAIT_REG && s->phase!=P25_LAB_ATTACH_WAIT_AFF))return false;
    if(!p25_lab_attach_input(s,current,released,permission,now))return false;
    if(!e)return false;
    // ACK/queue keep waiting for the existing bounded exchange; neither may
    // become accepted registration/affiliation or restart the total deadline.
    if(e->phase==P25_LAB_WAIT_REPLY)return false;
    if(e->phase!=P25_LAB_REPLY || !exchange_matches(s,e,s->phase==P25_LAB_ATTACH_WAIT_AFF)
       || !within(now,e->reply_us,P25_LAB_EXCHANGE_REPLY_US)) {fail(s,P25_LAB_ATTACH_REPLY);return false;}
    if(!off) {fail(s,P25_LAB_ATTACH_RF_NOT_OFF);return false;}
    p25_lab_attach_receipt receipt={.sequence=e->owner.sequence,.rx_epoch=e->rx_epoch,.reply_us=e->reply_us,
        .assigned=e->assigned,.group=e->reply_group,.type=e->reply_type,.response=e->response};
    if(s->phase==P25_LAB_ATTACH_WAIT_REG) {s->registration=receipt;s->phase=P25_LAB_ATTACH_AFFILIATE;}
    else {s->affiliation=receipt;s->phase=P25_LAB_ATTACH_RETURN_PENDING;}
    s->needs_rf_off=0;return true;
}
bool p25_lab_attach_begin_return(p25_lab_attach *s,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_ATTACH_RETURN_PENDING)return false;
    p25_lab_attach_poll(s,now);if(s->phase!=P25_LAB_ATTACH_RETURN_PENDING)return false;
    if(!off) {fail(s,P25_LAB_ATTACH_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    s->return_us=now;s->phase=P25_LAB_ATTACH_RETURN;return true;
}
bool p25_lab_attach_ready(p25_lab_attach *s,uint32_t epoch,bool raw,bool released,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_ATTACH_RETURN)return false;
    p25_lab_attach_poll(s,now);if(s->phase!=P25_LAB_ATTACH_RETURN)return false;
    if(!released) {p25_lab_attach_cancel(s,P25_LAB_ATTACH_PTT);return false;}
    if(!off) {fail(s,P25_LAB_ATTACH_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    if(!raw || !advanced(epoch,s->affiliation.rx_epoch))return false;
    s->ready_us=now;s->ready_epoch=epoch;s->phase=P25_LAB_ATTACH_READY;return true;
}
bool p25_lab_attach_consume_ready(p25_lab_attach *s,const p25_lab_exchange_owner *current,
    uint32_t epoch,bool released,bool permission,bool off,uint32_t now) {
    if(!s || s->phase!=P25_LAB_ATTACH_READY)return false;
    if(!p25_lab_attach_input(s,current,released,permission,now))return false;
    if(epoch!=s->ready_epoch) {fail(s,P25_LAB_ATTACH_EPOCH);return false;}
    if(!off) {fail(s,P25_LAB_ATTACH_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    s->phase=P25_LAB_ATTACH_ARM_PTT;return true;
}
bool p25_lab_attach_armed(p25_lab_attach *s,const p25_lab_exchange_owner *o,bool success,uint32_t now) {
    if(!s || s->phase!=P25_LAB_ATTACH_ARM_PTT)return false;
    p25_lab_attach_poll(s,now);if(s->phase!=P25_LAB_ATTACH_ARM_PTT)return false;
    p25_lab_exchange_owner expected;
    if(!success || !p25_lab_attach_ptt_owner(s,&expected) || !owner_matches(&expected,o)) {
        fail(s,P25_LAB_ATTACH_TRANSPORT);return false;
    }
    s->phase=P25_LAB_ATTACH_ARMED;return true;
}
bool p25_lab_attach_abort_off(p25_lab_attach *s,bool off,uint32_t now) {
    (void)now;
    if(!s || !p25_lab_attach_owned(s))return false;
    if(!off) {fail(s,P25_LAB_ATTACH_RF_NOT_OFF);s->needs_rf_off=1;return false;}
    if(s->reason==P25_LAB_ATTACH_OK)s->reason=P25_LAB_ATTACH_CANCEL;
    s->needs_rf_off=0;s->phase=P25_LAB_ATTACH_CANCELLED;return true;
}
