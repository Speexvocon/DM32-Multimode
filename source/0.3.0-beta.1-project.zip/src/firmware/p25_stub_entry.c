// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_stub_entry.h"
#include "stubentry/stub_link.h"
#include <string.h>

// The native frame parser's callbacks have no context argument. Feed is called
// synchronously by the one serial-owner task; this pointer is never retained by
// the parser or accessed by an interrupt. Nested feeds are refused.
static p25_stub_entry *dispatch;

static uint32_t get32(const uint8_t *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static void fail(p25_stub_entry *s) {
    if(!p25_stub_entry_owned(s))return;
    s->state=P25_STUB_FAILED;s->load.armed=false;s->enter_replied=false;
    s->config.force_safe(s->config.context);
}
bool p25_stub_entry_owned(const p25_stub_entry *s) {
    return s && s->initialized && s->state!=P25_STUB_IDLE;
}
bool p25_stub_entry_init(p25_stub_entry *s,const p25_stub_config *c) {
    if(!s || !c)return false;
    memset(s,0,sizeof *s);
    if(!c->region || c->load_addr!=P25_STUB_LOAD_ADDR || c->region_bytes!=P25_STUB_REGION_BYTES
       || !c->board || strcmp(c->board,"DM-32UV") || !c->git || !c->admit || !c->quiesce
       || !c->safe || !c->force_safe || !c->write || !c->drain || !c->enter)return false;
    s->config=*c;
    dl_parser_init(&s->parser);s->parser.reply_cap=P25_STUB_REPLY_BYTES;
    stub_load_init(&s->load,c->region,c->region_bytes,c->load_addr);
    s->load.image_ok=c->image_ok;s->initialized=true;
    return true;
}
static size_t status(uint8_t *out,uint8_t value) {out[0]=value;return 1;}
// Validate BEGIN without touching its RAM. Native op_begin zeroes the image,
// which is only legal AFTER the unified controller has stopped and parked AMBE.
static uint8_t begin_valid(const p25_stub_entry *s,const uint8_t *req,uint16_t len) {
    if(len!=17u)return DL_ST_BAD_ARG;
    if(get32(req+1)!=STUB_MAGIC)return DL_ST_REFUSED;
    uint32_t total=get32(req+5),entry=get32(req+13);
    if(!total || total>s->config.region_bytes || entry<s->config.load_addr
       || entry-s->config.load_addr>=total)return DL_ST_BAD_ARG;
    return DL_ST_OK;
}
static size_t request(const uint8_t *req,uint16_t len,uint8_t *out,size_t cap) {
    p25_stub_entry *s=dispatch;
    if(!len)return status(out,DL_ST_BAD_ARG);
    // INFO is read-only in every state, including before BEGIN. In particular it
    // never calls board.system->stub_region(), which permanently parks AMBE.
    if(req[0]==STUB_OP_INFO) {
        bool enter=false;uint32_t entry=0;
        return stub_load_request(&s->load,req,len,out,cap,&enter,&entry);
    }
    if(s->state==P25_STUB_FAILED || s->state==P25_STUB_ENTERING)
        return status(out,DL_ST_REFUSED);
    if(s->state==P25_STUB_ENTER_PENDING)return status(out,DL_ST_BUSY);
    if(req[0]==STUB_OP_BEGIN) {
        uint8_t valid=begin_valid(s,req,len);
        if(valid!=DL_ST_OK)return status(out,valid);
        if(s->state==P25_STUB_IDLE) {
            if(!s->config.admit(s->config.context))return status(out,DL_ST_BUSY);
            // Ownership precedes quiesce: a failed/partial codec park is never
            // followed by a normal radio tick, PTT or codec invocation.
            s->state=P25_STUB_LOADING;s->started_ms=s->activity_ms=s->now_ms;
            if(!s->config.quiesce(s->config.context)) {fail(s);return status(out,DL_ST_REFUSED);}
        }
    } else if(s->state==P25_STUB_IDLE)return status(out,DL_ST_BAD_ARG);
    if(!s->config.safe(s->config.context)) {fail(s);return status(out,DL_ST_REFUSED);}
    bool enter=false;uint32_t entry=0;
    size_t n=stub_load_request(&s->load,req,len,out,cap,&enter,&entry);
    if(n && out[0]==DL_ST_OK) {
        s->activity_ms=s->now_ms;
        if(enter) {s->entry=entry;s->state=P25_STUB_ENTER_PENDING;s->enter_replied=false;}
    }
    return n;
}
static const char *codec(void) {
    p25_stub_entry *s=dispatch;
    return s->config.codec ? s->config.codec(s->config.context) : "none";
}
static size_t handle(uint8_t cmd,const uint8_t *req,uint16_t len,uint8_t *out,size_t cap) {
    stub_link_t link={.board=dispatch->config.board,.git=dispatch->config.git,.codec=codec,.stub=request};
    return stub_link_handle(&link,cmd,req,len,out,cap);
}
static void write_reply(const uint8_t *bytes,size_t length) {
    p25_stub_entry *s=dispatch;
    if(!s->config.write(s->config.context,bytes,length)) {fail(s);return;}
    if(s->state==P25_STUB_ENTER_PENDING && !s->enter_replied) {
        s->enter_replied=true;s->reply_ms=s->now_ms;
    }
}
bool p25_stub_entry_in_frame(p25_stub_entry *s,uint32_t now_ms) {
    return s && s->initialized && dl_parser_in_frame(&s->parser,now_ms);
}
size_t p25_stub_entry_feed(p25_stub_entry *s,const uint8_t *bytes,size_t length,uint32_t now_ms) {
    if(!s || !s->initialized || !bytes || !length || dispatch)return 0;
    s->now_ms=now_ms;
    if(p25_stub_entry_owned(s) && s->state!=P25_STUB_FAILED
       && (!s->config.safe(s->config.context) || now_ms-s->activity_ms>=P25_STUB_IDLE_MS
           || now_ms-s->started_ms>=P25_STUB_TOTAL_MS))fail(s);
    dispatch=s;
    size_t n=dl_parser_feed(&s->parser,bytes,length,now_ms,handle,write_reply,s->reply);
    dispatch=NULL;
    return n;
}
void p25_stub_entry_poll(p25_stub_entry *s,uint32_t now_ms) {
    if(!s || !s->initialized)return;
    (void)dl_parser_in_frame(&s->parser,now_ms);
    if(!p25_stub_entry_owned(s) || s->state==P25_STUB_FAILED || s->state==P25_STUB_ENTERING)return;
    if(!s->config.safe(s->config.context)) {fail(s);return;}
    if(now_ms-s->activity_ms>=P25_STUB_IDLE_MS || now_ms-s->started_ms>=P25_STUB_TOTAL_MS) {fail(s);return;}
    if(s->state!=P25_STUB_ENTER_PENDING || !s->enter_replied
       || now_ms-s->reply_ms<P25_STUB_ENTER_DELAY_MS)return;
    if(!s->config.drain(s->config.context) || !s->config.safe(s->config.context)) {fail(s);return;}
    s->config.force_safe(s->config.context);
    s->state=P25_STUB_ENTERING;
    // enter() executes the platform's RAM-only IRQ/watchdog/XIP transition. A
    // successful jump cannot return, whatever bool a faulty mock/port returns.
    (void)s->config.enter(s->config.context,s->entry);
    fail(s);
}
void p25_stub_entry_abort(p25_stub_entry *s) {
    if(!s || !s->initialized)return;
    dl_parser_init(&s->parser);s->parser.reply_cap=P25_STUB_REPLY_BYTES;
    fail(s);
}
