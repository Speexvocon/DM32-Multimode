// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded subscriber decisions only. No wire parsing, RF, storage or allocation.
#ifndef P25_TRUNKING_ACCESS_H
#define P25_TRUNKING_ACCESS_H
#include "p25_trunking_isp.h"
#include <stdbool.h>
#include <stdint.h>

#define P25_TRUNK_ACCESS_SITE_MS 3000u
#define P25_TRUNK_ACCESS_RESPONSE_MS 1500u
#define P25_TRUNK_ACCESS_ACTION_MS 2000u
#define P25_TRUNK_ACCESS_IDLE_MS 5000u
#define P25_TRUNK_ACCESS_QUEUE_MS 5000u
#define P25_TRUNK_ACCESS_RETRY_MS 250u
#define P25_TRUNK_ACCESS_ATTEMPTS 3u
#define P25_TRUNK_ACCESS_MAX_TOT_MS 600000u
#define P25_TRUNK_ACCESS_GRANT_MS 1500u

typedef enum {
    P25_TRUNK_ACCESS_OFF, P25_TRUNK_ACCESS_WAIT_SITE,
    P25_TRUNK_ACCESS_REGISTER, P25_TRUNK_ACCESS_WAIT_REG,
    P25_TRUNK_ACCESS_AFFILIATE, P25_TRUNK_ACCESS_WAIT_AFF,
    P25_TRUNK_ACCESS_READY, P25_TRUNK_ACCESS_REQUEST,
    P25_TRUNK_ACCESS_WAIT_GRANT, P25_TRUNK_ACCESS_GRANTED,
    P25_TRUNK_ACCESS_DRAIN, P25_TRUNK_ACCESS_RETURN, P25_TRUNK_ACCESS_FAILED,
    P25_TRUNK_ACCESS_DEREGISTER
} p25_trunking_access_phase;
typedef enum {
    P25_TRUNK_ACCESS_OK, P25_TRUNK_ACCESS_CONFIG,
    P25_TRUNK_ACCESS_SITE_LOST, P25_TRUNK_ACCESS_SITE_CHANGED,
    P25_TRUNK_ACCESS_MAPPING, P25_TRUNK_ACCESS_PERMISSION,
    P25_TRUNK_ACCESS_TIMEOUT, P25_TRUNK_ACCESS_TRANSPORT,
    P25_TRUNK_ACCESS_DENIED, P25_TRUNK_ACCESS_AUTH,
    P25_TRUNK_ACCESS_RELEASED, P25_TRUNK_ACCESS_TOT
} p25_trunking_access_reason;
typedef enum {
    P25_TRUNK_ACTION_NONE, P25_TRUNK_ACTION_REGISTER,
    P25_TRUNK_ACTION_AFFILIATE, P25_TRUNK_ACTION_GROUP_REQUEST,
    P25_TRUNK_ACTION_VOICE_START, P25_TRUNK_ACTION_VOICE_STOP,
    P25_TRUNK_ACTION_RETURN_CONTROL,P25_TRUNK_ACTION_DEREGISTER
} p25_trunking_access_action_type;
typedef struct {
    uint32_t wacn,radio_id,min_hz,max_hz,tot_ms;
    uint16_t system,nac,group;
    uint8_t rfss,site;
} p25_trunking_access_config;
typedef struct {
    uint32_t wacn,control_rx_hz,control_tx_hz;
    uint16_t system,nac;
    uint8_t rfss,site;
    bool fdma,control_pair_valid;
} p25_trunking_access_site;
typedef struct { uint32_t rx_hz,tx_hz; bool valid; } p25_trunking_access_pair;
typedef struct {
    p25_trunking_access_action_type type;
    uint32_t id,rx_hz,tx_hz,radio_id,tot_ms;
    uint16_t nac,group;
    // VOICE_START alone carries the accepted grant's immutable channel and
    // clear service options. Other action types leave both fields zero.
    uint16_t channel;
    uint8_t options;
} p25_trunking_access_action;
typedef struct {
    p25_trunking_access_config config;
    p25_trunking_access_site site;
    p25_trunking_access_pair voice;
    p25_trunking_access_phase phase;
    p25_trunking_access_reason reason;
    p25_trunking_access_action_type outstanding;
    uint32_t serial,outstanding_id,phase_ms,site_ms,sent_ms,action_ms;
    uint32_t retry_ms,voice_ms,gate_ms;
    uint16_t voice_channel;
    uint8_t voice_options;
    uint8_t attempts;
    bool have_site,registered,affiliated,release_required,ptt_down;
    bool want_voice,voice_running,queued,permit,idle,failure_return,action_eligible;
    bool experimental_opportunity;
} p25_trunking_access;

// init is for a quiescent platform owner. Never reinitialize with RF in flight.
void p25_trunking_access_init(p25_trunking_access *a);
// Reconfiguration is accepted only while OFF/FAILED with no outstanding action.
// Site identity and configured subscriber ID never silently change on the air.
bool p25_trunking_access_start(p25_trunking_access *a,
    const p25_trunking_access_config *config,uint32_t now_ms);
// The caller qualifies a complete site identity and the root's mapped control
// pair before reporting it. Missing/invalid input offsets never permit access.
bool p25_trunking_access_site_update(p25_trunking_access *a,
    const p25_trunking_access_site *site,uint32_t now_ms);
// Explicit quiescent group selection preserves registration only on the same
// fresh site. READY, accepted affiliation, released PTT and no in-flight action
// are mandatory. Refusal leaves the policy unchanged; selecting the same group
// is a no-op. A change revokes affiliation/grants and requires a new accepted
// affiliation plus a fresh PTT release before any GROUP request.
bool p25_trunking_access_select_group(p25_trunking_access *a,uint16_t group,uint32_t now_ms);
// Explicit quiescent logout. Completion reports a transmitted request and RF
// cleanup, not a network acknowledgement. No deregistration retry is implied.
bool p25_trunking_access_deregister(p25_trunking_access *a,uint32_t now_ms);
// tx_allowed is independent platform permission (ownership, band, calibration,
// battery, inhibit, fault). idle is the qualified inbound access opportunity;
// the policy does not implement status-symbol/slotted access timing itself.
// An RF action can be taken only at the same now_ms as its latest poll. Thus a
// previously observed idle opportunity cannot silently become a stored permit.
void p25_trunking_access_poll(p25_trunking_access *a,uint32_t now_ms,
                             bool ptt_down,bool tx_allowed,bool idle);
// Separate opt-in policy for an experimental nominal-clock backend. It keeps
// qualified idle=false and records its distinct provenance. The platform must
// still validate its frozen receive anchor/owner and all physical RF gates.
void p25_trunking_access_poll_nominal(p25_trunking_access *a,uint32_t now_ms,
                             bool ptt_down,bool tx_allowed,bool nominal_opportunity);
// One-shot actions carry a generation ID. A platform must recheck its physical
// permission before RF and acknowledge that exact ID. Success for a control
// action means RF has ended and control RX is ready, not merely queued bytes.
// VOICE_START success means keyed/started; STOP success means tail has drained.
bool p25_trunking_access_take(p25_trunking_access *a,
    p25_trunking_access_action *out,uint32_t now_ms);
bool p25_trunking_access_result(p25_trunking_access *a,uint32_t id,
                               bool success,uint32_t now_ms);
// Events are already CRC/MFID/protection qualified by the sibling wire parser.
// Origin NAC/carrier must be the current configured control downlink. A grant
// pair is mandatory for a source-addressed grant; source-free updates never
// produce a wire event that can authorize the subscriber's voice transmitter.
// Accepted grant metadata is frozen until its lease is revoked. A subsequent
// OSP cannot substitute channel/options during GRANTED or an outstanding start.
bool p25_trunking_access_consume(p25_trunking_access *a,
    const p25_trunking_osp *event,uint16_t nac,uint32_t control_rx_hz,
    const p25_trunking_access_pair *grant_pair,uint32_t now_ms);
// Platform fault/revocation invalidates pending permissions. While voice is
// running it emits STOP then RETURN; a platform must independently kill RF on
// a hard fault, and may acknowledge the STOP once that cleanup is complete.
void p25_trunking_access_fault(p25_trunking_access *a,
                              p25_trunking_access_reason reason,uint32_t now_ms);
// Stop invalidates all leases immediately. Caller must already have killed RF;
// unlike fault it does not request deferred stop/return hardware operations.
void p25_trunking_access_stop(p25_trunking_access *a);
#endif
