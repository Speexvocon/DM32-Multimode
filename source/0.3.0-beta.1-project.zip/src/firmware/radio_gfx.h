// SPDX-License-Identifier: GPL-3.0-or-later
// Cooperative display output; all drawing, flush and step calls share one task.
#ifndef RADIO_GFX_H
#define RADIO_GFX_H
#include <stdbool.h>

// Policy changes do no display work. Default and every gfx_init: blocking.
// Disabling preserves queued work; step can drain it, or the next gfx_flush
// synchronizes it with a blocking flush. No receiver callback is invoked.
void radio_gfx_defer(bool enable);
bool radio_gfx_deferred(void);
bool radio_gfx_pending(void);
// Return pending work after scanning <=max_scan_rows and sending <=max_rows.
// Either zero budget does no work. Each transfer finishes/releases its row.
// A redraw coalesces into the one existing framebuffer and requests another
// pass; an old frame is never reported complete while a newer flush is queued.
// This bounds row work, not wall-clock duration or rendering outside this API.
bool radio_gfx_step(unsigned max_rows,unsigned max_scan_rows);
#endif
