"""Generate one laboratory P25 registration request offline; opens no radio.

The 45-byte padded CAI and 316-valid-bit prefix are data artifacts only. They
do not establish compliant RF burst timing, slotted access or TX permission.
The radio ID is required explicitly; read the owner's retained test profile.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse
import contextlib
import importlib.util
import io
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("p25_access_reference_loader",
    Path(__file__).with_name("generate-p25-trunking-fixture.py"))
REFERENCE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(REFERENCE)
FILES = ("registration.bin", "registration-prefix.bin", "registration-mmdvm.bin")
VALID_BITS = 316


def make_exchange_fixture(*, radio_id, talkgroup, voice_channel=0x1001,
                          nac=0x293, wacn=0xABCDE, system_id=0x123, options=4):
    """Finite ISP/OSP oracle data, independently encoded by pinned OP25.

    Response field positions are checked against OP25 tk_p25::decode_tsbk.
    Queue/deny fields additionally match the primary sdrtrunk OSP parsers:
    service bits18..23, reason24..31, additional32..55, target56..79.
    Only clear half-duplex group voice is represented, never authentication.
    """
    REFERENCE.integer("radio_id", radio_id, 1, 0xFFFFFE)
    REFERENCE.integer("talkgroup", talkgroup, 1, 0xFFFF)
    REFERENCE.integer("voice_channel", voice_channel, 0, 0xFFFF)
    REFERENCE.integer("nac", nac, 0, 0xFFF)
    REFERENCE.integer("wacn", wacn, 1, 0xFFFFF)
    REFERENCE.integer("system_id", system_id, 1, 0xFFF)
    REFERENCE.integer("options", options, 0, 0xFF)
    if options & ~0x87:
        raise ValueError("Only clear half-duplex circuit voice options are supported")
    definitions = {
        "registration-request": ("ISP", 0x2C, wacn << 36 | system_id << 24 | radio_id),
        "affiliation-request": ("ISP", 0x28, system_id << 40 | talkgroup << 24 | radio_id),
        "voice-request": ("ISP", 0x00, options << 56 | talkgroup << 24 | radio_id),
        "registration-accepted": ("OSP", 0x2C, system_id << 48 | radio_id << 24 | radio_id),
        "affiliation-accepted": ("OSP", 0x28, talkgroup << 24 | radio_id),
        "voice-grant": ("OSP", 0x00, options << 56 | voice_channel << 40 | talkgroup << 24 | radio_id),
    }
    # Standard reason values: requesting unit unauthorized (deny0x11),
    # channel resources unavailable (queue0x40). No vendor interpretation.
    for stage, service in (("registration", 0x2C), ("affiliation", 0x28), ("voice", 0)):
        for label, opcode, reason in (("denied", 0x27, 0x11), ("queued", 0x21, 0x40)):
            definitions[stage + "-" + label] = ("OSP", opcode, service << 56 | reason << 48 | radio_id)
    reference = REFERENCE.load_reference()
    files, frames = {}, {}
    for label, (direction, opcode, argument) in definitions.items():
        wire, blocks = REFERENCE.encode_tsdu(reference, nac, [(opcode, argument)])
        name = label + ".bin"
        files[name] = wire
        frames[label] = {"file": name, "direction": direction, "opcode": opcode,
                         "argument_hex": f"{argument:016x}", "decoded_hex": blocks[0].hex(),
                         "bytes": len(wire), "sha256": REFERENCE.digest(wire)}
    return files, {
        "schema": "dm32-p25-access-exchange-v1", "units": len(files),
        "radio_id": radio_id, "talkgroup": talkgroup, "voice_channel": voice_channel,
        "nac": nac, "wacn": wacn, "system_id": system_id, "options": options,
        "frames": frames, "contains_voice": False, "transmission_authorized": False,
        "rf_timing_qualified": False,
        "reference": {"commit": REFERENCE.OP25_COMMIT,
                      "encoder_sha256_lf": REFERENCE.REFERENCE_SHA256_LF,
                      "encoder_url": f"https://github.com/boatbod/op25/blob/{REFERENCE.OP25_COMMIT}/op25/gr-op25_repeater/apps/tx/p25craft.py",
                      "osp_parser_url": f"https://github.com/boatbod/op25/blob/{REFERENCE.OP25_COMMIT}/op25/gr-op25_repeater/apps/tk_p25.py",
                      "queue_parser_url": "https://github.com/DSheirer/sdrtrunk/blob/v0.6.1/src/main/java/io/github/dsheirer/module/decode/p25/phase1/message/tsbk/standard/osp/QueuedResponse.java",
                      "deny_parser_url": "https://github.com/DSheirer/sdrtrunk/blob/v0.6.1/src/main/java/io/github/dsheirer/module/decode/p25/phase1/message/tsbk/standard/osp/DenyResponse.java"},
        "limits": "Offline packet data only; no access-slot, RF, network or subscriber authorization is implied",
    }


def make_fixture(*, radio_id, nac=0x293, wacn=0xABCDE, system_id=0x123):
    """Return ({filename: bytes}, manifest) using the reviewed OP25 factory."""
    REFERENCE.integer("radio_id", radio_id, 1, 0xFFFFFF)
    REFERENCE.integer("nac", nac, 0, 0xFFF)
    REFERENCE.integer("wacn", wacn, 1, 0xFFFFF)
    REFERENCE.integer("system_id", system_id, 1, 0xFFF)
    reference = REFERENCE.load_reference()
    output = io.BytesIO()
    reference["outfile"] = output
    with contextlib.redirect_stderr(io.StringIO()):
        reference["construct_u_reg_req"](nac, 2, wacn, system_id, radio_id)
    wire = output.getvalue()
    if len(wire) != 45 or wire[:6] != REFERENCE.SYNC:
        raise ValueError("Independent registration encoder returned an unexpected frame")
    argument = (wacn << 36) | (system_id << 24) | radio_id
    word = reference["construct_tsbk"](True, 0, 0x2C, 0, argument).to_bytes(12, "big")
    # 48 sync +64 NID +196 coded TSBK +4 inserted two-bit statuses =316 bits.
    # The byte container's unused low nibble is explicitly zero, not RF data.
    prefix = wire[:VALID_BITS//8] + bytes((wire[VALID_BITS//8] & 0xF0,))
    files = {FILES[0]: wire, FILES[1]: prefix, FILES[2]: REFERENCE.modem_packet(wire)}
    manifest = {
        "schema": "dm32-p25-access-fixture-v1",
        "purpose": "One finite laboratory subscriber unit-registration request",
        "units": 1, "contains_voice": False, "rf_verified": False,
        "rf_timing_qualified": False, "transmission_authorized": False,
        "nac": nac, "wacn": wacn, "system_id": system_id, "radio_id": radio_id,
        "symbol_rate": 4800, "bit_rate": 9600,
        "expected": {"direction": "ISP", "kind": "unit-registration-request",
            "nac": nac, "duid": 7, "opcode": 0x2C, "mfid": 0,
            "last": True, "protected": False, "status_dibit": 2,
            "wacn": wacn, "system_id": system_id, "radio_id": radio_id,
            "argument_hex": f"{argument:016x}", "decoded_hex": word.hex()},
        "prefix": {"file": FILES[1], "valid_bits": VALID_BITS,
            "valid_dibits": VALID_BITS//2, "packed_bytes": len(prefix),
            "ignored_low_bits_in_last_byte": 4, "unused_low_bits_value": 0,
            "sync_bits": 48, "nid_bits": 64, "trellis_bits": 196,
            "inserted_status_bits": 8, "status_symbols": 4,
            "nominal_seconds_without_preamble": VALID_BITS/9600,
            "note": "Leading CAI data only; not a complete padded TSDU or a qualified RF burst"},
        "padded": {"file": FILES[0], "bytes": len(wire), "bits": len(wire)*8,
            "status_symbols": 5, "additional_padding_and_status_bits": 44,
            "nominal_seconds_without_preamble": len(wire)/1200,
            "note": "Includes zero fill and final status through the fifth microslot"},
        "packing": "MSB-first packed CAI; only the prefix's explicit valid-bit count is meaningful",
        "serial": {"file": FILES[2], "protocol": 1, "command": 0x31, "control_byte": 0,
            "note": "Padded laboratory modem input only; this generator opens no modem"},
        "limits": "No preamble, PA ramp/tail, RX-to-TX turnaround, slot scheduling, backoff or controller is qualified",
        "reference": {"project": "boatbod/op25", "commit": REFERENCE.OP25_COMMIT,
            "source_sha256_lf": REFERENCE.REFERENCE_SHA256_LF,
            "path": "op25/gr-op25_repeater/apps/tx/p25craft.py",
            "factory": "construct_u_reg_req",
            "encoder_url": f"https://github.com/boatbod/op25/blob/{REFERENCE.OP25_COMMIT}/op25/gr-op25_repeater/apps/tx/p25craft.py"},
        "files": {name: {"bytes": len(data), "sha256": REFERENCE.digest(data)}
            for name, data in files.items()},
    }
    return files, manifest


def write_fixture(output, files, manifest):
    output = Path(output)
    if set(files) != set(FILES):
        raise ValueError("Unexpected access fixture files")
    output.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        (output / name).write_bytes(files[name])
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")


def load_fixture(directory):
    """Bounded loading plus exact regeneration, not a user-declared identity check."""
    directory = Path(directory)
    path = directory / "manifest.json"
    if path.stat().st_size > 16384:
        raise ValueError("Access manifest exceeds bounded size")
    metadata = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(metadata, dict) or metadata.get("schema") != "dm32-p25-access-fixture-v1":
        raise ValueError("Unknown access fixture schema")
    try:
        files, expected = make_fixture(radio_id=metadata["radio_id"], nac=metadata["nac"],
            wacn=metadata["wacn"], system_id=metadata["system_id"])
    except KeyError as error:
        raise ValueError("Incomplete access fixture identity") from error
    for name, data in files.items():
        if (directory/name).stat().st_size != len(data) or (directory/name).read_bytes() != data:
            raise ValueError("Access fixture data differs from independent regeneration")
    if metadata != expected:
        raise ValueError("Access fixture manifest differs from independent regeneration")
    return files, expected


def write_exchange_fixture(output, files, manifest):
    output = Path(output)
    expected_names = {item["file"] for item in manifest["frames"].values()}
    if manifest.get("schema") != "dm32-p25-access-exchange-v1" or set(files) != expected_names:
        raise ValueError("Unexpected finite exchange fixture files")
    output.mkdir(parents=True, exist_ok=True)
    for name, data in files.items():
        if Path(name).name != name:
            raise ValueError("Exchange fixture filename must be local")
        (output / name).write_bytes(data)
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def load_exchange_fixture(directory):
    directory = Path(directory)
    path = directory / "manifest.json"
    if path.stat().st_size > 16384:
        raise ValueError("Exchange manifest exceeds bounded size")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict) or manifest.get("schema") != "dm32-p25-access-exchange-v1":
        raise ValueError("Unknown exchange fixture schema")
    try:
        files, expected = make_exchange_fixture(**{key: manifest[key] for key in
            ("radio_id", "talkgroup", "voice_channel", "nac", "wacn", "system_id", "options")})
    except KeyError as error:
        raise ValueError("Incomplete exchange identity") from error
    if manifest != expected:
        raise ValueError("Exchange manifest differs from independent regeneration")
    for name, data in files.items():
        if (directory / name).stat().st_size != len(data) or (directory / name).read_bytes() != data:
            raise ValueError("Exchange fixture differs from independent regeneration")
    return files, expected


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"build/p25-access-fixture")
    parser.add_argument("--radio-id", type=REFERENCE.number, required=True,
        help="Explicit retained owner/test-profile RID; no default or radio writes")
    parser.add_argument("--exchange", action="store_true", help="Offline finite request/response oracle instead of one request")
    parser.add_argument("--talkgroup", type=REFERENCE.number, help="Required for --exchange")
    parser.add_argument("--voice-channel", type=REFERENCE.number, default=0x1001)
    parser.add_argument("--options", type=REFERENCE.number, default=4)
    for name, default in (("nac", 0x293), ("wacn", 0xABCDE), ("system-id", 0x123)):
        parser.add_argument("--"+name, type=REFERENCE.number, default=default)
    args = vars(parser.parse_args(argv))
    output = args.pop("output")
    exchange = args.pop("exchange")
    try:
        if exchange:
            files, manifest = make_exchange_fixture(**args)
        else:
            if args.pop("talkgroup") is not None or args.pop("voice_channel") != 0x1001 or args.pop("options") != 4:
                raise ValueError("Talkgroup/channel/options require --exchange")
            files, manifest = make_fixture(**args)
    except ValueError as error:
        parser.error(str(error))
    if exchange:
        write_exchange_fixture(output, files, manifest)
        print(json.dumps({"output": str(output), "units": len(files), "frames": manifest["frames"],
            "rf_timing_qualified": False, "transmission_authorized": False}))
    else:
        write_fixture(output, files, manifest)
        print(json.dumps({"output": str(output), "units": 1, "files": manifest["files"],
            "valid_prefix_bits": VALID_BITS, "rf_timing_qualified": False,
            "transmission_authorized": False}))


if __name__ == "__main__":
    main()
