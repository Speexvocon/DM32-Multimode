"""Generate the narrow, experimental FD6818 RF-B overlay from the reviewed pin.

The external checkout stays untouched. Original RF-A register tables, tune and
DMR interrupt sequences remain unchanged. Only the variant sleep words and the
task-level PLL probe from RadioFoundry PR #490 are added. The separately reviewed
fd6818_setup_b.c supplies the B tables from upstream f07134f2576f286e95a839b3e4cea791ce4f1a8d.
RF-B support is experimental; generating these sources does not qualify hardware.
"""
import argparse
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PINNED_SHA256 = {
    "drivers/rf/fd6818/fd6818.c": "451f8004097d4607edf0412a67a59e132851a5b8524b1fa5b39f460be21dd2cf",
    "drivers/rf/fd6818/fd6818.h": "72d0b31917b5f26851e5e5be69ee628a8ee656f12f3d3576ccea182c552a6796",
}


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Pinned FD6818 replacement is absent or ambiguous")
    return text.replace(old, new, 1)


def generate(path, text):
    text = text.replace("\r\n", "\n")
    if path not in PINNED_SHA256 or hashlib.sha256(text.encode()).hexdigest() != PINNED_SHA256[path]:
        raise ValueError("RF driver input does not match the reviewed upstream pin: " + path)
    if path.endswith(".h"):
        text = replace_once(text, "\t// Band words for a frequency", "\t// Variant-specific sleep words; sleep_wake == 0 preserves the original RF-A sequence.\n"
                            "\tuint16_t sleep_fm, sleep_dmr, sleep_wake;\n\t// Band words for a frequency")
        text = replace_once(text, "extern const fd6818_variant_t fd6818_variant_default;",
                            "extern const fd6818_variant_t fd6818_variant_default;\n"
                            "// Experimental RF-B setup, from upstream PR #490.\n"
                            "extern const fd6818_variant_t fd6818_variant_b;\n"
                            "extern const fd6818_variant_t fd6818_variant_b_dmr6943;")
        text = replace_once(text, "#define FD6818_REG_BAND_A", "#define FD6818_CSS_PLL_LOCK\t0x0200u\n"
                            "// Absolute poll bound, even if a caller passes UINT32_MAX.\n"
                            "#define FD6818_PLL_MAX_WAIT_MS\t20u\n#define FD6818_REG_BAND_A")
        text = replace_once(text, "void fd6818_set_bandwidth(fd6818_t *dev, uint16_t bw_reg);",
                            "// Task context only: immediate read, then at most min(timeout_ms, 20) one-ms waits.\n"
                            "// Never invoke from an RF/modem interrupt or DMR burst callback. With no delay hook,\n"
                            "// only the immediate lock sample is taken. This function never writes registers.\n"
                            "bool fd6818_pll_locked(fd6818_t *dev, uint32_t timeout_ms);\n"
                            "void fd6818_set_bandwidth(fd6818_t *dev, uint16_t bw_reg);")
        return text

    text = replace_once(text, "void fd6818_set_bandwidth(fd6818_t *dev, uint16_t bw_reg)\n",
                        "// Task-level boot qualification only; do not put a millisecond wait in burst/IRQ paths.\n"
                        "bool fd6818_pll_locked(fd6818_t *dev, uint32_t timeout_ms)\n"
                        "{\n"
                        "\tif (timeout_ms > FD6818_PLL_MAX_WAIT_MS) {\n"
                        "\t\ttimeout_ms = FD6818_PLL_MAX_WAIT_MS;\n"
                        "\t}\n"
                        "\tfor (uint32_t ms = 0; ms <= timeout_ms; ms++) {\n"
                        "\t\tif ((fd6818_read(dev, FD6818_REG_CSS_STATUS) & FD6818_CSS_PLL_LOCK) != 0u) {\n"
                        "\t\t\treturn true;\n"
                        "\t\t}\n"
                        "\t\tif (ms == timeout_ms || dev->bus->delay_ms == NULL) {\n"
                        "\t\t\treturn false;\n"
                        "\t\t}\n"
                        "\t\trfbus_delay_ms(dev->bus, 1u);\n"
                        "\t}\n"
                        "\treturn false;\n"
                        "}\n\n"
                        "void fd6818_set_bandwidth(fd6818_t *dev, uint16_t bw_reg)\n")
    text = replace_once(text,
                        "void fd6818_rx_sleep(fd6818_t *dev, bool sleep, fd6818_mode_t mode)\n{\n",
                        "void fd6818_rx_sleep(fd6818_t *dev, bool sleep, fd6818_mode_t mode)\n{\n"
                        "\tconst fd6818_variant_t *v = dev->variant;\n")
    text = replace_once(text,
                        "\t\tfd6818_write(dev, FD6818_REG_POWER, mode == FD6818_MODE_DMR ? 0x1D00 : 0x1D11);\n\t} else {\n",
                        "\t\tfd6818_write(dev, FD6818_REG_POWER, v->sleep_wake != 0u ?\n"
                        "\t\t\t(mode == FD6818_MODE_DMR ? v->sleep_dmr : v->sleep_fm) :\n"
                        "\t\t\t(mode == FD6818_MODE_DMR ? 0x1D00 : 0x1D11));\n"
                        "\t} else if (v->sleep_wake != 0u) {\n"
                        "\t\tfd6818_write(dev, FD6818_REG_POWER, v->sleep_wake);\n\t} else {\n")
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("relative_path", choices=PINNED_SHA256)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to((ROOT / "build").resolve()):
        parser.error("generated RF sources must remain under the ignored project build directory")
    generated = generate(args.relative_path, args.source.read_text())
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(generated, newline="\n")


if __name__ == "__main__":
    main()
