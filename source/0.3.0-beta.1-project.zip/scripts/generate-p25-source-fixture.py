"""Build the finite opaque SiteSim/MMDVM source comparison, entirely offline.

The pinned OP25 coding functions independently encode SiteSim RxOriginWitness
counters 1..192. This is laboratory identification data, not a site broadcast,
grant, voice call, synchronization authority or request to transmit.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "source_op25_encoder", Path(__file__).with_name("generate-p25-trunking-fixture.py"))
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

SCHEMA = "dm32-p25-source-fixture-v1"
FRAME_COUNT, FRAME_BYTES = 192, 45
NAC, DUID, OPCODE, MFID, TAG = 0x293, 7, 0x3F, 0x90, 0x4F524947
STATUSES = (3, 2, 2, 2, 2)
DEFAULT_OUTPUT = ROOT / "build/p25-source-fixture"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode_frame(reference, counter):
    """Use OP25's explicit MFID and actual BCH/CRC/trellis/interleave functions."""
    BASE.integer("counter", counter, 1, FRAME_COUNT)
    argument = (TAG << 32) | counter
    block = reference["construct_tsbk"](1, 0, OPCODE, MFID, argument)
    data = reference["start_packet"](NAC, DUID)
    data.extend(reference["data_interleave"](
        reference["trellis_1_2_encode"](reference["split_dibits"](block, 48))))
    dibits = reference["insert_status"](data, STATUSES)
    if len(dibits) != FRAME_BYTES * 4 or any(type(v) is not int or not 0 <= v <= 3 for v in dibits):
        raise ValueError("Pinned OP25 encoder produced unexpected padded dibits")
    wire = bytes(sum(dibits[i+j] << (6-2*j) for j in range(4))
                 for i in range(0, len(dibits), 4))
    if wire[:6] != BASE.SYNC:
        raise ValueError("Pinned OP25 encoder produced unexpected frame sync")
    return wire, block.to_bytes(12, "big")


def make_fixture():
    reference = BASE.load_reference()
    frames, entries = [], []
    for counter in range(1, FRAME_COUNT+1):
        frame, block = encode_frame(reference, counter)
        entries.append({"index": counter-1, "counter": counter,
                        "wire_offset": len(frames)*FRAME_BYTES,
                        "wire_bytes": FRAME_BYTES, "decoded_hex": block.hex()})
        frames.append(frame)
    wire = b"".join(frames)
    serial = b"".join(BASE.modem_packet(frame) for frame in frames)
    manifest = {
        "schema": SCHEMA,
        "purpose": "Finite identical opaque CAI input for SiteSim versus MMDVM source comparison",
        "nac": NAC, "duid": DUID, "opcode": OPCODE, "mfid": MFID,
        "payload_tag_hex": "%08x" % TAG, "counter_first": 1,
        "counter_last": FRAME_COUNT, "counter_bits": 32,
        "counter_byte_order": "big", "last_block": True, "protected": False,
        "status_symbols": list(STATUSES), "status_symbol_positions": [35, 71, 107, 143, 179],
        "frame_bytes": FRAME_BYTES, "units": FRAME_COUNT, "repetitions": 1,
        "symbol_rate": 4800, "bit_rate": 9600,
        "airtime_seconds_without_preamble": len(wire)/1200,
        "contains_voice": False, "contains_grants": False, "automatic_responses": False,
        "rf_verified": False, "sample_clock_qualified": False,
        "rf_origin_qualified": False, "access_slot_qualified": False,
        "reference": {"project": "boatbod/op25", "commit": BASE.OP25_COMMIT,
                      "path": "op25/gr-op25_repeater/apps/tx/p25craft.py",
                      "source_sha256_lf": BASE.REFERENCE_SHA256_LF},
        "sitesim_identity": "lab::RxOriginWitness::next, counters1..192, opaque ORIG tag",
        "packing": "MSB-first CAI, sync/NID/trellis/CRC/statuses and zero padding included",
        "serial": {"protocol": 1, "command": 0x31, "control_byte": 0},
        "files": {name: {"bytes": len(data), "sha256": digest(data)}
                  for name, data in (("control.bin", wire), ("control-mmdvm.bin", serial))},
        "frames": entries,
    }
    return frames, manifest


def write_fixture(output, frames, manifest):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "control.bin").write_bytes(b"".join(frames))
    (output / "control-mmdvm.bin").write_bytes(b"".join(map(BASE.modem_packet, frames)))
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args(argv)
    frames, manifest = make_fixture()
    write_fixture(args.output, frames, manifest)
    print(json.dumps({"output": str(args.output), "units": FRAME_COUNT,
                      "airtime_seconds_without_preamble": 7.2,
                      "files": manifest["files"], "rf_verified": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
