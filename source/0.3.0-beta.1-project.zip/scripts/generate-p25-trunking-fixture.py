"""Create a finite Phase 1 control-channel fixture offline; opens no radio link.

Uses the pinned OP25 p25craft encoder for BCH, CRC, trellis, interleave and
status/padding. Files are test inputs, not a transmission request or firmware.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse
import ast
import contextlib
import hashlib
import io
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "research/references/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py"
OP25_COMMIT = "3f44d43eb449bb4753247ce848bb42a403823dea"
REFERENCE_SHA256_LF = "27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9"
DEFAULT_OUTPUT = ROOT / "build/p25-trunking-fixture"
SYNC = bytes.fromhex("5575f5ff77ff")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_reference(path=REFERENCE):
    """Load reviewed functions only, skipping OP25's top-level p25.out open."""
    source = Path(path).read_text(encoding="utf-8")
    if digest(source.encode()) != REFERENCE_SHA256_LF:
        raise ValueError("OP25 p25craft source differs from the reviewed pin")
    tree = ast.parse(source, filename=str(path))
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    namespace = {"sys": sys, "struct": struct, "quiet": True,
                 "flip": 0, "outfile": None}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), "exec"), namespace)
    # The pinned text_out writes even with quiet=True; keep its diagnostics out
    # of the manifest and command output without replacing its coding routines.
    namespace["text_out"] = lambda text: None
    return namespace


def integer(name, value, lower, upper):
    if type(value) is not int or not lower <= value <= upper:
        raise ValueError(f"{name} must be an integer in {lower}..{upper}")
    return value


def band(frequency):
    integer("frequency", frequency, 1, 0xFFFFFFFF)
    for name, low, high in (("VHF", 144000000, 148000000),
                            ("UHF", 420000000, 450000000)):
        if low <= frequency <= high:
            return name
    raise ValueError("Fixture frequencies must be in the supported VHF/UHF bench ranges")


def modem_packet(frame):
    """Protocol 1: type31, discarded zero control byte, complete CAI wire unit."""
    if len(frame) not in (45, 72, 90) or frame[:6] != SYNC:
        raise ValueError("Expected one complete padded 1..3-block TSDU")
    return bytes((0xE0, len(frame) + 4, 0x31, 0)) + frame


def encode_tsdu(reference, nac, blocks):
    """blocks contains (opcode, 64-bit argument); return wire and CRC words."""
    if not 1 <= len(blocks) <= 3:
        raise ValueError("TSDU must contain 1..3 blocks")
    output = io.BytesIO()
    previous = reference["outfile"]
    reference["outfile"] = output
    try:
        with contextlib.redirect_stderr(io.StringIO()):
            reference["construct_tsdu3"](nac, 2, len(blocks), 0,
                                         [item[0] for item in blocks],
                                         [item[1] for item in blocks])
        words = [reference["construct_tsbk"](index == len(blocks)-1, 0, opcode, 0, argument)
                 .to_bytes(12, "big")
                 for index, (opcode, argument) in enumerate(blocks)]
    finally:
        reference["outfile"] = previous
    wire = output.getvalue()
    if len(wire) != {1: 45, 2: 72, 3: 90}[len(blocks)] or wire[:6] != SYNC:
        raise ValueError("Independent OP25 encoder returned an unexpected wire unit")
    return wire, words


def make_fixture(*, control_frequency=430100000, voice_frequency=430112500,
                 talkgroup=1, nac=0x293, wacn=0xABCDE, system_id=0x123,
                 rfss=1, site=1, source_id=1, identifier=1,
                 spacing_hz=12500, repetitions=20):
    """Return (wire_frames, manifest); opens only the local encoder reference."""
    frequency_band = band(control_frequency)
    if band(voice_frequency) != frequency_band or control_frequency == voice_frequency:
        raise ValueError("Control and voice frequencies must differ within the same band")
    integer("spacing_hz", spacing_hz, 125, 1023*125)
    if spacing_hz % 125 or control_frequency % 5 or voice_frequency % 5:
        raise ValueError("Spacing must be in 125-Hz steps and frequencies in 5-Hz steps")
    base = min(control_frequency, voice_frequency)
    if abs(control_frequency-voice_frequency) % spacing_hz:
        raise ValueError("Both frequencies must fit the selected channel spacing")
    integer("talkgroup", talkgroup, 1, 0xFFFF)
    integer("nac", nac, 0, 0xFFF)
    integer("wacn", wacn, 0, 0xFFFFF)
    integer("system_id", system_id, 0, 0xFFF)
    integer("rfss", rfss, 1, 0xFF)
    integer("site", site, 1, 0xFF)
    integer("source_id", source_id, 1, 0xFFFFFF)
    integer("identifier", identifier, 0, 15)
    integer("repetitions", repetitions, 1, 200)
    cc_number = integer("control channel number", (control_frequency-base)//spacing_hz, 0, 4095)
    vc_number = integer("voice channel number", (voice_frequency-base)//spacing_hz, 0, 4095)
    cc, vc = (identifier << 12) | cc_number, (identifier << 12) | vc_number
    reference = load_reference()

    # IDEN_UP_VU field positions match OP25 trunking.py::decode_tsbk (0x34).
    # 5 denotes 12.5-kHz bandwidth; zero offset describes this receive-only
    # fixture's simplex channel plan. No subscriber uplink is requested.
    iden_argument = ((identifier << 60) | (5 << 56) |
                     ((spacing_hz//125) << 32) | (base//5))
    site_blocks = [
        (0x34, iden_argument),
        reference["format_rfss_status_broadcast"](0, 1, 1, system_id, rfss, site, cc, 0x70),
        reference["format_network_status_broadcast"](0, wacn, system_id, cc, 0x70),
    ]
    # Group voice grant: service options, channel, group, source (8/16/16/24).
    grant = (0x00, (vc << 40) | (talkgroup << 24) | source_id)
    update = reference["format_group_voice_channel_grant_update"](vc, talkgroup, vc, talkgroup)
    cycle = []
    for label, blocks in (("site", site_blocks), ("grant", [grant]),
                          ("grant-update", [update, grant])):
        frame, words = encode_tsdu(reference, nac, blocks)
        cycle.append((label, frame, blocks, words))

    frames, entries = [], []
    wire_offset, serial_offset = 0, 0
    for repetition in range(repetitions):
        for label, frame, blocks, words in cycle:
            packet = modem_packet(frame)
            entries.append({"index": len(frames), "cycle": repetition,
                            "kind": label, "wire_offset": wire_offset,
                            "wire_bytes": len(frame), "serial_offset": serial_offset,
                            "serial_bytes": len(packet), "nac": nac, "duid": 7,
                            "blocks": [{"opcode": opcode, "mfid": 0,
                                        "argument_hex": f"{argument:016x}",
                                        "decoded_hex": word.hex(),
                                        "last": index == len(blocks)-1}
                                       for index, ((opcode, argument), word)
                                       in enumerate(zip(blocks, words))]})
            frames.append(frame)
            wire_offset += len(frame)
            serial_offset += len(packet)
    wire = b"".join(frames)
    serial = b"".join(modem_packet(frame) for frame in frames)
    manifest = {
        "schema": "dm32-p25-trunking-fixture-v1",
        "purpose": "Finite offline Phase1 control-channel/site/grant fixture",
        "rf_verified": False, "contains_voice": False,
        "control_frequency_hz": control_frequency, "voice_frequency_hz": voice_frequency,
        "band": frequency_band, "nac": nac, "wacn": wacn,
        "system_id": system_id, "rfss": rfss, "site": site,
        "talkgroup": talkgroup, "source_id": source_id,
        "bandplan": {"identifier": identifier, "base_frequency_hz": base,
                     "spacing_hz": spacing_hz, "bandwidth_hz": 12500,
                     "transmit_offset_hz": 0,
                     "control_channel": cc, "voice_channel": vc},
        "repetitions": repetitions, "units": len(frames),
        "symbol_rate": 4800, "bit_rate": 9600,
        "airtime_seconds_without_preamble": len(wire)/1200,
        "packing": "MSB-first CAI units including sync/NID/status/padding; frame offsets below",
        "serial": {"protocol": 1, "command": 0x31, "control_byte": 0,
                   "note": "Serialized test input only; this generator opens no modem or network"},
        "expected": {"control_frequency_hz": control_frequency,
                     "grant_voice_frequency_hz": voice_frequency,
                     "grant_talkgroup": talkgroup, "grant_source_id": source_id,
                     "opcodes_per_cycle": [0x34, 0x3A, 0x3B, 0x00, 0x02, 0x00]},
        "reference": {"project": "boatbod/op25", "commit": OP25_COMMIT,
                      "path": "op25/gr-op25_repeater/apps/tx/p25craft.py",
                      "source_sha256_lf": REFERENCE_SHA256_LF,
                      "encoder_url": f"https://github.com/boatbod/op25/blob/{OP25_COMMIT}/op25/gr-op25_repeater/apps/tx/p25craft.py",
                      "field_reference_url": f"https://github.com/boatbod/op25/blob/{OP25_COMMIT}/op25/gr-op25_repeater/apps/trunking.py"},
        "files": {name: {"bytes": len(data), "sha256": digest(data)}
                  for name, data in (("control.bin", wire), ("control-mmdvm.bin", serial))},
        "frames": entries,
    }
    return frames, manifest


def write_fixture(output, frames, manifest):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "control.bin").write_bytes(b"".join(frames))
    (output / "control-mmdvm.bin").write_bytes(b"".join(map(modem_packet, frames)))
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")


def number(text):
    return int(text, 0)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    for flag, default in (("control-frequency", 430100000), ("voice-frequency", 430112500),
                          ("talkgroup", 1), ("nac", 0x293), ("wacn", 0xABCDE),
                          ("system-id", 0x123), ("rfss", 1), ("site", 1),
                          ("source-id", 1), ("identifier", 1), ("spacing-hz", 12500),
                          ("repetitions", 20)):
        parser.add_argument("--"+flag, type=number, default=default)
    args = vars(parser.parse_args(argv))
    output = args.pop("output")
    try:
        frames, manifest = make_fixture(**args)
    except ValueError as error:
        parser.error(str(error))
    write_fixture(output, frames, manifest)
    print(json.dumps({"output": str(output), "units": len(frames),
                      "airtime_seconds_without_preamble": manifest["airtime_seconds_without_preamble"],
                      "files": manifest["files"], "rf_verified": False}))


if __name__ == "__main__":
    main()
