"""Add channel-cancellation to a checked generated copy of the native service.

The pinned service preserves pending requests across Init(), appropriate for its
stock single-mode host. Our shared-mode host must discard retries and ACKs when
the channel or RF permission changes. The original tree remains untouched.
"""
import argparse
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIN = "6faf0395607dd76aed985016aafcdfd6392a55b77046199640333666c2d81b35"
HOOK = r'''
// Project host extension: call only after the native call stack has been stopped
// (and its active list's done callback has run). Keep received-message dedup and
// the inbox, but never replay old-channel outgoing traffic after a mode change.
void dm32_dmr_data_cancel(bool reset_receive)
{
    txPending = txRunning = false;
    txBurstCount = 0;
    txEnded = txEndStamp = false;
    replyReadIdx = replyWriteIdx = 0;
    tmsAckPending = csbkAnswerPending = false;
    mailbox.smsPending = mailbox.sigPending = false;
    channel.canTransmit = false;
    if (sms.state == DMR_REQ_QUEUED || sms.state == DMR_REQ_SENDING)
        smsFinish(DMR_REQ_FAILED);
    ipx.state = IPX_IDLE;
    ipx.sms = false;
    ipx.l4 = NULL;
    sms.waiting = sig.waiting = false;
    emg.active = false;
    if (reset_receive) {
        blockWindowValid = false;
        dmrDataRxReset();
    }
}
'''


def generate(text):
    text = text.replace("\r\n", "\n")
    if hashlib.sha256(text.encode()).hexdigest() != PIN:
        raise ValueError("DMR data service does not match the reviewed upstream pin")
    end = text.rfind("\n#endif")
    if end < 0:
        raise ValueError("missing data service feature guard")
    return text[:end] + "\n" + HOOK + text[end:]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    out = args.output.resolve()
    if not out.is_relative_to((ROOT / "build").resolve()):
        parser.error("generated DMR service must remain under the ignored build directory")
    content = generate(args.source.read_text())
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, newline="\n")


if __name__ == "__main__":
    main()
