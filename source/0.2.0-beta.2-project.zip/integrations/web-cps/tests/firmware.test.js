// SPDX-License-Identifier: GPL-3.0-or-later
// Exercise the browser client against the actual application parser and store.
import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {fileURLToPath} from 'node:url';
import {CpsClient} from '../transport.js';
import {decodePayload, encodePayload, crc32, createScanList, upgradeModel} from '../model.js';

const library = process.env.CPS_ADAPTER_LIBRARY;
const bridge = fileURLToPath(new URL('../../../tests/web_cps_bridge.py', import.meta.url));

function fixture() {
  const child = spawn(process.env.CPS_TEST_PYTHON || 'python', ['-u', bridge, library], {stdio: ['pipe', 'pipe', 'pipe']});
  const waiting = [];
  let stderr = '';
  child.stderr.on('data', data => { stderr += data; });
  createInterface({input: child.stdout}).on('line', line => {
    const current = waiting.shift();
    if (!current) return;
    try { const value = JSON.parse(line); if (value.error) current.reject(new Error(value.error)); else current.resolve(value); }
    catch (error) { current.reject(error); }
  });
  child.on('error', error => { while (waiting.length) waiting.shift().reject(error); });
  child.on('exit', code => { while (waiting.length) waiting.shift().reject(new Error(`C bridge exited ${code}: ${stderr}`)); });
  const rpc = request => new Promise((resolve, reject) => {
    waiting.push({resolve, reject});
    child.stdin.write(JSON.stringify(request) + '\n');
  });
  const commands = [];
  const port = {
    dropCommitReply: false,
    async open(options) {
      assert.equal(options.baudRate, 115200);
      this.readable = new ReadableStream({start: controller => { this.controller = controller; }});
      this.writable = new WritableStream({write: async data => {
        const command = new TextDecoder().decode(data).trim();
        assert.match(command, /^CPS (HELLO|GET|BEGIN|PUT|COMMIT|ABORT)( |$)/);
        commands.push(command);
        const {reply} = await rpc({action: 'command', command});
        if (this.dropCommitReply && command.startsWith('CPS COMMIT ')) return;
        const bytes = new TextEncoder().encode(reply);
        // Serial chunks are independent of the line/request boundary.
        for (let offset = 0; offset < bytes.length; offset += 7) this.controller.enqueue(bytes.slice(offset, offset + 7));
      }});
    },
    async close() { this.readable = this.writable = null; },
    getInfo() { return {}; }
  };
  const serial = {requestPort: async () => port};
  // Include process startup/scheduler cost; use the real client's request budget.
  const client = new CpsClient({serial, timeoutMs: 3000});
  return {client, port, rpc, commands, stop: () => { child.stdin.end(); child.kill(); }};
}

test('browser client uploads mixed P25/DMR/FM fields through real C parser and retains them on reboot', {skip: !library}, async t => {
  const f = fixture();
  t.after(async () => { await f.client.disconnect().catch(() => {}); f.stop(); });
  await f.client.connect();
  const original = await f.client.read();
  const model = decodePayload(original.payload);
  model.channels[0] = {...structuredClone(model.vfos[0]), name: 'P25 TEST', nac: 0x2a3, talkgroup: 123,
    filter: 'NAC+TG', scanLists: []};
  model.channels[1] = {...structuredClone(model.vfos[0]), name: 'FM TEST', mode: 'NFM', rxHz: 446000000,
    txHz: 446000000, rxOnly: true, scanLists: [], txTone: {type: 'ctcss', value: 885},
    rxTone: {type: 'dcs-inv', value: 0o23}, squelch: 4};
  // The actual C HAL fixture deliberately advertises only its UHF test band.
  model.channels[2] = {name:'DMR TEST', mode:'DMR', rxHz:440075000, txHz:440075000,
    destinationId:0x123456, colorCode:15, timeslot:2, privateCall:true, repeater:true, filter:'PROM', rxOnly:false, scanLists:[], powerLevel:8};
  model.channels[0].powerLevel = 4;
  model.channels[255] = {...structuredClone(model.channels[0]), name:'LAST P25'};
  model.zones[15] = {name:'ZONE LAST', channels:[1, 256]};
  model.scanLists[0] = {...createScanList('Mixed scan'), channels:[1, 2, 3, 256]};
  model.scanLists[15] = {...createScanList('P25 TG', 'p25-tg', 256), reply:'fixed', replyChannel:256, talkgroups:[1, 10, 100, 1000, 65535]};
  Object.assign(model.settings, {selectionA: 1, selectionB: 2, screenSeconds: 45, keypadSeconds: 10, scanList: 2,
    totSeconds:180, p1Action:4, p2Action:7, sk1Action:6, sk2Action:8, broadcastKHz:101700,
    selectionA:256, zoneA:16, zoneB:0, scanList:15});
  const payload = encodePayload(model);
  for (let key = 0; key < payload.length / 32; key++) {
    const record = Buffer.from(payload.slice(key * 32, key * 32 + 32)).toString('hex');
    assert.equal((await f.rpc({action: 'validate', key, record})).valid, true);
  }
  const written = await f.client.write(payload, original);
  assert.equal(written.revision, original.revision + 1);
  assert.equal(written.crc, crc32(payload));
  assert.equal(f.commands.filter(c => c.startsWith('CPS COMMIT ')).length, 1);
  const active = await f.rpc({action: 'active'});
  assert.deepEqual(Uint8Array.from(Buffer.from(active.payload, 'hex')), payload);
  await f.rpc({action: 'reboot'});
  const readback = await f.client.read();
  assert.equal(readback.revision, written.revision);
  assert.deepEqual(readback.payload, payload);
  assert.deepEqual(decodePayload(readback.payload), model);
});

test('explicit JS legacy upgrade equals the actual C legacy projection byte for byte', {skip:!library}, async t => {
  const f=fixture();t.after(()=>f.stop());
  const legacy=await f.rpc({action:'legacy'}),active=await f.rpc({action:'active'});
  const original=Uint8Array.from(Buffer.from(legacy.payload,'hex'));
  assert.equal(original.length,1120);
  assert.deepEqual(encodePayload(upgradeModel(decodePayload(original,3))),Uint8Array.from(Buffer.from(active.payload,'hex')));
});

test('lost COMMIT acknowledgement is uncertain once; reconnect/read recovers actual committed C image', {skip: !library}, async t => {
  const f = fixture();
  t.after(async () => { await f.client.disconnect().catch(() => {}); f.stop(); });
  await f.client.connect();
  const original = await f.client.read();
  const model = decodePayload(original.payload);
  model.settings.keypadSeconds = 20;
  const payload = encodePayload(model);
  f.port.dropCommitReply = true;
  await assert.rejects(f.client.write(payload, original), /commit|uncertain|confirm|read|timeout|timed out/i);
  assert.equal(f.commands.filter(c => c.startsWith('CPS COMMIT ')).length, 1);
  const active = await f.rpc({action: 'active'});
  assert.equal(active.revision, original.revision + 1);
  assert.deepEqual(Uint8Array.from(Buffer.from(active.payload, 'hex')), payload);
  await assert.rejects(f.client.write(payload, original));
  assert.equal(f.commands.filter(c => c.startsWith('CPS COMMIT ')).length, 1);
  f.port.dropCommitReply = false;
  await f.client.disconnect();
  await f.rpc({action: 'reboot'});
  await f.client.connect();
  const recovered = await f.client.read();
  assert.deepEqual(recovered.payload, payload);
  assert.equal(recovered.revision, original.revision + 1);
});
