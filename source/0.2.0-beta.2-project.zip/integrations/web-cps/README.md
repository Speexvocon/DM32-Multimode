# DM32 unified browser CPS

This is the primary programming interface for the custom DM32 P25/DMR/FM firmware.
The owner selected the RadioFoundry-style browser editor instead of continuing
CHIRP integration. The existing CHIRP module and its historical download evidence
remain in the repository; they are not required to use this editor.

## Start locally

From the repository root:

```powershell
python scripts/serve-web-cps.py
```

Open **http://127.0.0.1:8765/** in Chrome or Edge. The server listens on loopback
and serves this folder only. It has no serial, firmware-write or upload API;
Web Serial connects directly from the browser after you click Connect. Localhost
is a secure context for Web Serial. Nothing is sent to a remote service and no
additional JavaScript packages or CDN are needed.

The editor works offline with a sample codeplug or saved JSON file. Protocol 1 supports P25/FM, protocol 2 adds DMR, protocol 3 adds programmable power and radio functions, and protocol 4 adds 256 channels, zones and independent scan definitions. The client identifies the connected firmware before reading or writing. A legacy upload is allowed only when every new power/function field retains its reserved zero default; DMR cannot be uploaded to protocol 1. Unsupported edits are refused before a transaction starts. Editing a field does not install firmware or establish RF qualification.

## Program the radio

1. Power on normally, release PTT, connect the programming cable and close other
   applications using COM8. The radio remains on its normal application firmware.
2. Click **Connect** and select the programming cable. This identifies the custom
   firmware; it does not grant permission to overwrite settings.
3. Click **Read radio**. This obtains a complete revision/CRC-qualified snapshot.
   Save a codeplug file before changing it.
4. Edit channels, VFO A/B, zones, scan lists, radio settings or the separate **Functions** tab. To apply an offline file,
   read the radio first, then open the file; file metadata alone never qualifies
   a write. Editing, importing and loading a sample never write the radio.
5. Review **Problems** and resolve errors. Click **Review & write**, review the
   proposed changes, then explicitly start the transfer. The firmware stages the
   complete snapshot and publishes it after validation and CRC verification.
6. After a first real upload, read the configuration back and confirm the values
   survive a normal power-off/restart. Browser and simulated-parser checks alone
   do not establish a hardware upload pass.

The firmware pauses reception and PTT during programming. An idle read link
expires after three seconds; abandoned staging expires after 60 seconds.
If the radio changed since the read, the write is refused. If a commit reply is
lost, the outcome is uncertain: reconnect and read again before another write.
The client never repeats a commit automatically.

## Current fields

- **Channel mode** recalls one of 256 named channel memories on V4 firmware (32 on legacy firmware). **Frequency mode** uses an editable VFO A/B profile. The two sides share one RF receiver; choose the active side and each side's starting mode in Radio settings.
- P25, DMR, narrow FM and wide FM, independent RX/TX frequencies and receive-only. DMR requires the unified V2 firmware.
- P25 NAC, transmit talkgroup and PROM/NAC/NAC+TG filtering per channel.
- DMR 24-bit destination, group/private calls, color code, timeslot and direct/repeater framing. The global source ID is shared by both digital modes.
- DMR CC/all destinations, CC+destination or PROM on the selected timeslot. PROM does not monitor both slots or decode encrypted voice.
- Independent analog RX/TX CTCSS or normal/inverse DCS and squelch.
- Nine calibrated power levels per memory/VFO, from L− through H. These are hardware levels, not a claim of measured watts.
- Radio ID, shared P25/DMR microphone gain, active A/B selections and scan list.
- **Functions → Transmit:** a 15–600-second time-out timer (TOT), default 30 seconds, and optional owner TX inhibit.
- **Functions → Programmable buttons:** independent P1, P2, SK1 and SK2 choices for no action, Frequency / Channel, A/B, scan, power cycling, FM broadcast, status or keypad lock. Assign **Frequency / Channel** to SK1 or SK2 for a side-key mode switch. Default shortcuts are P1 = Frequency / Channel, P2 = status, SK1 = FM broadcast and SK2 = A/B.
- **Functions → FM broadcast:** a receive-only tuner frequency from 65–108 MHz in 0.05-MHz steps, default 87.500 MHz. This is separate from two-way FM channels and never enables broadcast-band transmission.
- **Functions → Display & keypad:** independent screen/keypad-light timeouts. Zero keeps a light on; reception wakes the screen.

Names hold 12 printable ASCII characters. Frequencies are entered as MHz, NACs
as three hexadecimal digits, CTCSS in Hz and DCS in octal. Adjustable microphone
gain applies to P25 and DMR; analog FM retains its native gain. A/B share one RF receiver.
DMR controls are specific to the unified candidate; native DMR RF/audio and mixed-mode switching need hardware qualification before they can be described as validated. Contact/alias tables remain a later feature.

The Frequency / Channel button action keeps its existing numeric ID `2`.
This terminology update does not change the record layout, protocol or saved JSON
keys: older codeplugs with the former VFO / memory action import without changes.

## Files, compatibility and provenance

New `.json` drafts use a version-4 `DM32P25-CPS` envelope with all 387
canonical records (12,384 bytes), CRC and origin metadata. The client pins the
radio's HELLO version and channel geometry for the entire connection. Legacy
V1/V2/V3 files and radios remain supported with exactly 35 records; opening a
legacy file does not change its payload bytes or CRC. Click **Upgrade codeplug**
explicitly to expand a legacy working copy and convert its four membership bits
into Scan 1–4 with Last heard reply, matching the firmware's migration projection. Save an original file for any
legacy radios: V4 data is never truncated to fit old firmware, and legacy drafts
must be explicitly upgraded before writing to V4 firmware. Unknown future
versions are refused.

V1/V2 reserved fields remain zero defaults: 30-second TOT, default button
shortcuts, lowest power and 87.500-MHz broadcast reception. Origin metadata from
a file cannot substitute for reading the connected radio. Undo/redo operates on
the working draft, not the device.

### Zones and two scan types

V4 has **16 named zones** and **16 named scan lists**. Zones select which saved
channels are available to each side; zero means All channels. Select the side's
zone and its starting memory in Radio settings. A selected memory must belong
to that zone. Zone membership follows global channel order.

**Channel scan (CH SCAN)** visits the selected channel configurations. Compatible
co-channel P25 memories share continuous acquisition. **P25 talkgroup scan
(TG SCAN)** stays on one occupied P25 base channel's receive frequency/NAC and
accepts a separate list of up to 64 unique decimal talkgroups. It does not need
duplicate channel memories and enforces its TG list independently of the base
channel's normal receive filter. Encrypted and unsupported calls remain muted.
Each list has a 12-character name, 100–5000-ms channel dwell, 0–10000-ms post-call
hold and a reply policy: Selected/base channel, Last heard, or Fixed reply
channel. Last-heard TG replies are temporary and do not rewrite saved TX TGs.
Empty named lists can be saved but cannot start scanning.

### Bulk editing and channel CSV

**Bulk edit** applies one field to all selected memories atomically. An invalid
or incompatible mode field refuses the entire edit. **Move** moves the selected
record to a channel number, shifts intervening records and rewrites every zone,
scan membership, base-channel, fixed-reply and side-selection reference to follow
the original channel identity. Clearing a channel removes memberships and side
selections; a TG list losing its base is removed, and a fixed reply losing its
channel reverts to Selected. These changes remain part of the reviewed draft.

**Export CSV** produces the exact header required by **Import CSV**. CSV contains
channel records only; JSON remains the complete backup for zones, lists and radio
settings. Channel numbers are one-based, frequencies are integer Hz, NAC is
decimal, booleans are `true`/`false`, CTCSS values are integer tenths of Hz, and DCS
values are decimal wire codes. Tone type names are `none`, `ctcss`, `dcs` and
`dcs-inv`; filter names are `NAC`, `PROM` and `NAC+TG`. Legacy `scanLists` CSV cells
use semicolon-separated zero-based list IDs. V4 cells are empty because membership
lives in separate scan definitions. Unused mode-specific columns must be empty.

CSV import replaces only listed slots in a clone, preserving absent records and
all other configuration. Duplicate slots, malformed values and broken references
refuse the complete import without partial changes. Review the changes before
writing; imports never connect or upload automatically.

This is a P25-aware adaptation of RadioFoundry's editor approach, with our existing
logical transport and atomic storage. RadioFoundry's stock web editor, its binary
codeplug files and qdmr transport are not interchangeable with this firmware.
See [upstream provenance](UPSTREAM.md) and the
[logical protocol specification](../../docs/CPS_PROTOCOL.md). The protocol
has no program-flash, bootloader, calibration, raw-address or transmit commands.
Backup, firmware installation and recovery remain separate tools.

## Checks

```powershell
./scripts/test-web-cps.ps1
```

This builds the real application parser/store behind the existing host HAL,
then runs the browser codec/client through both fake serial streams and that
actual C implementation. The bridge never opens a serial port. It checks mixed
P25/DMR/FM fields, atomic reboot retention, revision/CRC guards and uncertain commit
handling. Pure JavaScript tests can also run with `node --test` inside this folder;
the actual-C bridge cases require the library built by the PowerShell script.

First physical browser read/write and FM/mixed-scan observations remain separate
from offline and browser preview checks. Extended RF soak/repeat qualification is
still deferred at the owner's request.

Optional desktop-browser checks, using an already installed Chrome or Edge:

```powershell
# Leave the local server running in another terminal.
python scripts/serve-web-cps.py
# In the second terminal, from the repository root:
node tests/web_cps_browser.mjs
```

This launches its own hidden headless browser and injects a simulated Web Serial
peer before loading the editor. It never opens a real programming cable. It
checks local file round trips, form edits, reviewed uploads, stale revisions and
lost commit acknowledgements, and captures desktop/mobile screenshots under
`build/web-cps-browser-qa`. Set `CHROME_PATH` if the installed browser is not found
automatically; no browser package is downloaded. `CPS_URL` may select another
loopback server address.
