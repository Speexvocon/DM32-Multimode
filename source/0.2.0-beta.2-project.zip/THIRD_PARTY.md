# Third-party provenance

This repository contains selected unmodified source snapshots, not one uniformly
licensed codebase. Keep upstream notices and licenses with derived implementations.
No blanket license is assigned to the project by this initial research commit.

| Source | Snapshot location | Upstream license notices |
|---|---|---|
| RadioFoundry/RadioFoundry | research/references/RadioFoundry | MIT; included LICENSE |
| RadioFoundry browser editor undo/redo | integrations/web-cps/vendor | MIT; pinned editor source, adapted model, retained notice and LICENSE.RadioFoundry; see integrations/web-cps/UPSTREAM.md |
| nostar/imbe_vocoder | research/references/nostar/imbe_vocoder | GPL-3.0-or-later in source headers |
| g4klx/MMDVM | research/references/g4klx/MMDVM | GPL-2.0-or-later in source headers |
| g4klx/MMDVMHost | Local build/mmdvm-fec-audit; not vendored | GPL-2.0-or-later; pinned audit provenance in research/analysis/mmdvm-p25-fec-crosscheck.json |
| boatbod/op25 | research/references/boatbod/op25 | GPL notices in source headers |

Exact upstream revisions are in `research/references/UPSTREAMS.json`. Full licensed
trees can be fetched with `scripts/clone-upstreams.ps1`. Combining code requires
choosing compatible terms and preserving all applicable notices; private status
does not change third-party provenance.

Proprietary stock/OpenDM32 firmware inputs and extracted codec binaries remain
local ignored files. The repository versions research findings and provenance,
without distributing those firmware images. Binary disassembly excerpts are
research evidence and are not an open-source license grant for the firmware.
