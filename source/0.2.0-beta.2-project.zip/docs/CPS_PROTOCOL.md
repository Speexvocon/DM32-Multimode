# Logical CPS protocol, version 3 candidate

This API programs the custom unified DM32 P25/DMR/FM firmware's settings. It contains no address-based reads/writes, calibration operations, firmware update or transmit command. The primary client is the [browser CPS](../integrations/web-cps/README.md). The earlier CHIRP module remains historical integration code. Version3 is the production-functions candidate; it is not an installation claim. The installed `05c4965` baseline advertises version 2.

## Transport and identity

Normal application boot, 115200 baud, 8 data bits, no parity, one stop bit. Every command and reply is printable ASCII ending CRLF, at most **120 bytes including CRLF**. There is one bounded reply per command; there is no automatic write retry. Transactions, CRCs and record hex strings are emitted as uppercase hexadecimal. Indices and revisions are unsigned decimal. A transaction ID is exactly eight hexadecimal digits; the driver chooses a nonzero random 32-bit ID.

The candidate advertises version 3 with the same bounded geometry:

```text
CPS HELLO
CPS HELLO DM32P25 3 32 2 <revision> <CRC32>
```

The updated browser also accepts protocol 1/2 for existing firmware, pins the protocol for each connection and validates records under that version's rules. V1 cannot store DMR. V1/V2 cannot store nonzero V3 power/function fields; clients must refuse unsupported uploads before BEGIN. Older clients that accept only earlier protocols reject version 3 at HELLO. Model identity remains DM32P25 for continuity; it does not select the RF mode.

The firmware refuses CPS while PTT is held, transmit/preparation is active or an incompatible job owns the radio. Opening a CPS session pauses receive monitoring. Read sessions expire after three idle seconds; staged transactions abort after 60 idle seconds. COMMIT/ABORT close the transaction. The normal held-PTT boot guard and transmit permissions remain radio policy. HELLO during an active staged transaction is rejected rather than mixing the active revision with a staged checksum.

## Commands

| Request | Successful reply | Effect |
|---|---|---|
| `CPS HELLO` | `CPS HELLO DM32P25 3 32 2 rev crc` | Identify and obtain the active snapshot revision/CRC |
| `CPS GET i` | `CPS DATA i hex64` | Read one active 32-byte record, `i=0..34` |
| `CPS BEGIN tid rev` | `CPS OK BEGIN tid` | Check the active revision and stage a full copy of the active settings |
| `CPS PUT tid i hex64` | `CPS OK PUT tid i` | Validate one record and change only the staged snapshot |
| `CPS COMMIT tid crc` | `CPS OK COMMIT tid newrev crc` | Validate the whole snapshot and checksum, durably publish it atomically, then apply it |
| `CPS ABORT tid` | `CPS OK ABORT tid` | Discard staging; active settings remain unchanged |

Errors have the form `CPS ERR CODE`; the driver treats every such reply as a failure. BUSY/PTT errors grant no permission to bypass the radio state. Bad identity/version/geometry stops the host before BEGIN. BEGIN rejects a stale revision. Invalid records, transaction IDs, CRCs and references to empty selected memories cannot commit.

The client downloads all 35 records between two matching HELLO responses and verifies the CRC. Upload also checks the original download revision/CRC against HELLO, sends all 35 staged records, then sends COMMIT once. An unchanged upload performs no write. After COMMIT it verifies the acknowledgement and a new HELLO. A missing/invalid commit acknowledgement is uncertain because the radio may have committed; the host never repeats COMMIT and requires a fresh download.

## Canonical payload and checksum

The logical payload is exactly **1120 bytes**: 35 records × 32 bytes in index order. Indices 0–31 are memories 1–32, index 32 is VFO A, 33 is VFO B and 34 is global settings. All integer fields are little endian. CRC is standard CRC-32/IEEE, polynomial `0xEDB88320`, initial `0xFFFFFFFF`, final XOR `0xFFFFFFFF`, over these 1120 bytes only. Flash-bank metadata, legacy preference records, CHIRP's image header and CHIRP metadata are excluded.

Empty channel/VFO records are all zero. An occupied record uses the following layout:

| Offset | Size | Field |
|---|---|---|
| 0 | 4 | Receive frequency in Hz |
| 4 | 4 | Transmit frequency in Hz; retained even for receive-only profiles |
| 8 | 2 | P25 NAC, 0–0xFFF |
| 10 | 2 | P25 transmit talkgroup, 1–65535 |
| 12 | 1 | Flags below |
| 13 | 1 | Scan membership bits 0–3; remaining bits zero |
| 14 | 12 | Printable ASCII name, zero padded; no nonzero byte after a zero |
| 26 | 2 | FM transmit tone word |
| 28 | 2 | FM receive tone word |
| 30 | 1 | FM squelch, 0–9 |
| 31 | 1 | V3 calibrated power index, 0–8; zero in V1/V2 |

Flags: bit 0 occupied; bit 1 FM; bits2–3 receive filter; bit 4 receive only; bit 5 wide FM; bit 6 DMR (V2/V3); bit 7 zero. FM and DMR bits are mutually exclusive. With neither mode bit set, the channel is P25. Wide mode is valid only for FM. Both tone words must be zero for P25 and DMR.

P25/FM retain their exact V1 byte layout above. DMR replaces bytes 8–11 with:

| Offset | Size | DMR field |
|---|---|---|
| 8 | 3 | Destination ID, little endian, 1–0xFFFFFF |
| 11 | 1 | Bits 0–3 color code (0–15); bit 4 timeslot (0=1, 1=2); bit 5 private call (0=group); bit 6 repeater/hotspot framing (0=direct); bit 7 zero |
| 26–29 | 4 | Unused, zero |
| 30 | 1 | Canonical unused squelch value, 5 |
| 31 | 1 | V3 calibrated power index, 0–8; zero in V1/V2 |

DMR source ID uses the existing global 24-bit ID. Direct/repeater framing is explicit and is not derived from equal RX/TX frequencies. A simplex hotspot may require repeater framing. Power indices0–8 use the board's labels L−, L, L+, L++, M, M+, M++, H− and H. They select factory-calibrated drive settings, not measured watt values; old index 0 remains the same minimum setting.

Filter bits are `0=NAC/all talkgroups`, `1=PROM`, `2=NAC+TG`, `3=invalid` for P25. For DMR they mean `0=configured CC/all destinations`, `1=any CC/all destinations on the selected timeslot`, `2=configured CC+destination`. DMR PROM does not monitor both timeslots. PROM does not enable encrypted voice decoding.

Tone words use their top two bits for type: `0=none`, `1=CTCSS`, `2=DCS`, `3=inverse DCS`. None requires value zero. CTCSS's low 14 bits are tenths of Hz, 600–2600 inclusive. DCS's low bits are the 9-bit code value, 1–511: the familiar octal code `023` is stored as decimal 19. CHIRP converts its octal-looking decimal representation automatically.

Storage validates frequencies structurally from 100 to 520 MHz; the driver advertises the DM32 board's 136–174 and 400–480 MHz ranges. Radio tuning and transmit permission also enforce board bands. This storage envelope does not grant out-of-band operation.

The global record is:

| Offset | Size | Field |
|---|---|---|
| 0 | 4 | Shared digital source/radio ID, 1–0xFFFFFF |
| 4 | 1 | Shared P25/DMR digital microphone gain, 0–42 dB; analog FM uses its native gain |
| 5 | 2 | Screen timeout, 0–600 seconds; zero always on |
| 7 | 2 | Keypad light timeout, 0–600 seconds; zero always on |
| 9 | 1 | Active VFO, 0=A / 1=B |
| 10 | 1 | A selection, 0=VFO A / 1–32=memory |
| 11 | 1 | B selection, 0=VFO B / 1–32=memory |
| 12 | 1 | Active scan list, 0–3 |
| 13 | 1 | Owner TX inhibit, 0–1 |
| 14 | 2 | V3 transmit timeout in seconds: raw 0 means default 30; otherwise15–600 |
| 16 | 1 | V3 P1 action |
| 17 | 1 | V3 P2 action |
| 18 | 1 | V3 SK1 action |
| 19 | 1 | V3 SK2 action |
| 20 | 4 | V3 broadcast receiver frequency in kHz: raw 0 means 87500; otherwise65000–108000 on a 50-kHz grid |
| 24–31 | 8 | Reserved, zero |

V1/V2 require global bytes14–31 and channel byte 31 to remain zero. Effective defaults are applied on read without changing those bytes or the snapshot CRC. Raw TOT zero is a default encoding, **not an unlimited-transmit setting**. Action codes are:

| Code | Action |
|---|---|
| 0 | Default: P1=VFO/memory, P2=Radio status, SK1=Broadcast FM, SK2=A/B |
| 1 | None |
| 2 | VFO/memory |
| 3 | A/B |
| 4 | Scan start/stop |
| 5 | Cycle channel transmit power |
| 6 | Broadcast FM |
| 7 | Radio status |
| 8 | Keypad lock |

Selected memory references must point to occupied records. An unconfigured VFO may be zero. Active A/B selection uses one RF chain; it does not imply simultaneous reception. Independent transmit-cutoff enforcement remains firmware policy and cannot be disabled by a codeplug. Broadcast reception uses a separate receiver; storing its frequency does not make it a transmit channel.

## Persistence and verification scope

Storage reads V1/V2/V3 bank snapshots without writing or normalizing their raw default encodings. A deliberate save or upload writes V3 records to the inactive bank, preserving the original snapshot until the new bank header is durable. Every selected data record must match its bank version; mixed-version/torn data cannot publish a partial snapshot. Unknown future versions disable writes. Older firmware may read a prior supported bank or retained V1–V3 legacy preference-ring profile read-only; that fallback is not necessarily the latest channel database. Legacy preference-ring version 3 is a separate format from channel-bank version 3.

Staging may write the inactive settings bank, but the active bank remains authoritative until the complete snapshot's commit is durable. Aborted, interrupted and bad-CRC transactions must recover the previous whole snapshot after restart. The firmware owns bank layout, fallback and protected-region enforcement; none are exposed as CHIRP EEPROM addresses.

The browser's complete JSON codeplug wraps the canonical payload in a versioned
`DM32P25-CPS` envelope, version 3, with CRC and optional origin revision/CRC. Earlier files import under strict version-specific validation and retain their exact canonical bytes. A V1 envelope cannot contain DMR, and V1/V2 cannot contain V3 function/power data. File origin
metadata never qualifies a write; the connected client must first read the radio.
The earlier CHIRP `.img` format prefixes the logical payload with `DM32P25\0`,
protocol LE32 and payload length LE32, then uses CHIRP's metadata trailer. Neither
format is a stock firmware/codeplug dump, and the logical API has no raw-flash
capability.

Browser codec/transport tests and a bridge into the actual C parser/storage
exercise this API without hardware. Earlier CHIRP core/C-parser tests and a
real read-only CH340 download also passed. Physical browser GUI/read/write
qualification remains separate; simulated tests do not establish a hardware
upload pass. CHIRP qualification is no longer the primary workstream.
