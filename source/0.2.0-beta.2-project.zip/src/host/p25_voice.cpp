// SPDX-License-Identifier: GPL-3.0-or-later
// Offline PCM/IMBE/P25 bridge using pinned nostar and OP25 implementations.
// Fixed clear-call control fields come from the independently checked fixtures.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>
#include "imbe.h"
#include "imbe_vocoder.h"
#include "op25_imbe_frame.h"
#include "p25_test_vectors.h"

using Bytes = std::vector<uint8_t>;
static void require(bool ok, const char* message) {
    if (!ok) throw std::runtime_error(message);
}
static Bytes read(const char* path) {
    std::ifstream file(path, std::ios::binary);
    require(bool(file), "Cannot open input");
    file.seekg(0,std::ios::end);
    const auto size=file.tellg();
    require(size>0 && size<=161280,"Input empty or exceeds 10.08-second PCM limit");
    file.seekg(0,std::ios::beg);
    Bytes bytes((std::istreambuf_iterator<char>(file)), {});
    require(!file.bad(), "Input read failed");
    // This bench tool deliberately bounds allocations and call duration.
    require(bytes.size()==static_cast<size_t>(size), "Input changed or truncated during read");
    return bytes;
}
static void append(Bytes& dst, const uint8_t* src, size_t count) {
    dst.insert(dst.end(), src, src + count);
}
static bit_vector bits(const uint8_t* bytes) {
    bit_vector result(1728);
    for (size_t b=0; b<result.size(); ++b) result[b]=(bytes[b/8]>>(7-b%8))&1;
    return result;
}
static void append_bits(Bytes& dst, const bit_vector& frame) {
    for (size_t b=0; b<frame.size(); b+=8) {
        uint8_t value=0;
        for (size_t j=0; j<8; ++j) value=uint8_t((value<<1)|frame[b+j]);
        dst.push_back(value);
    }
}
static Bytes codec(const Bytes& input, bool encode) {
    const size_t stride=encode ? 320 : 11;
    require(input.size()%stride==0, "Incomplete PCM or IMBE frame");
    require(input.size()/stride<=504, "Too many speech frames");
    imbe_vocoder vocoder;
    Bytes output;
    for (size_t offset=0; offset<input.size(); offset+=stride) {
        int16_t pcm[160];
        uint8_t payload[11];
        if (encode) {
            for (size_t i=0; i<160; ++i) {
                const unsigned value=input[offset+i*2]|(unsigned(input[offset+i*2+1])<<8);
                pcm[i]=static_cast<int16_t>(value<32768 ? int(value) : int(value)-65536);
            }
            vocoder.encode_4400(pcm,payload);
            append(output,payload,11);
        } else {
            std::copy_n(input.data()+offset,11,payload);
            vocoder.decode_4400(pcm,payload);
            for (int16_t sample:pcm) {
                const auto value=static_cast<uint16_t>(sample);
                output.push_back(uint8_t(value)); output.push_back(uint8_t(value>>8));
            }
        }
    }
    return output;
}
static Bytes frame(const Bytes& payloads) {
    require(payloads.size()%(18*11)==0 && payloads.size()<=504*11,
            "Framing requires 18..504 speech frames in multiples of 18; encode PCM padding first");
    Bytes output(240,0x77);
    append(output,p25_test_hdu,sizeof p25_test_hdu);
    for (size_t offset=0,ldu=0; offset<payloads.size(); offset+=99,++ldu) {
        auto body=bits(ldu%2 ? p25_test_ldu2 : p25_test_ldu1);
        for (size_t f=0; f<9; ++f) {
            packed_codeword packed(payloads.begin()+offset+f*11,payloads.begin()+offset+(f+1)*11);
            uint32_t u[8]={};
            imbe_unpack(packed,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
            // OP25 unpack returns seven low bits, while header_encode expects
            // those bits shifted left one, as returned by header_decode.
            u[7]<<=1;
            voice_codeword cw(144);
            imbe_header_encode(cw,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
            imbe_interleave(body,cw,static_cast<uint32_t>(f));
        }
        append_bits(output,body);
    }
    append(output,p25_test_tdu,sizeof p25_test_tdu);
    return output;
}
static Bytes extract(const Bytes& stream) {
    constexpr size_t prefix=240+99, suffix=18;
    require(stream.size()>=prefix+432+suffix && (stream.size()-prefix-suffix)%432==0,
            "Expected complete paired-LDU call with preamble/HDU/TDU");
    require(stream.size()<=12453,"Call exceeds fixture duration limit");
    require(std::all_of(stream.begin(),stream.begin()+240,[](uint8_t b){return b==0x77;}),"Bad preamble");
    require(std::equal(stream.begin()+240,stream.begin()+prefix,p25_test_hdu),"Unexpected HDU/control fields");
    require(std::equal(stream.end()-suffix,stream.end(),p25_test_tdu),"Unexpected terminator");
    Bytes output;
    for (size_t offset=prefix,ldu=0; offset<stream.size()-suffix; offset+=216,++ldu) {
        auto body=bits(stream.data()+offset);
        auto control=body;
        const auto reference=bits(ldu%2 ? p25_test_ldu2 : p25_test_ldu1);
        for (unsigned f=0; f<9; ++f) {
            voice_codeword cw(144), rebuilt(144), template_cw(144);
            imbe_deinterleave(body,cw,f);
            uint32_t u[8]={},e0=0,errors=0;
            imbe_header_decode(cw,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7],e0,errors);
            imbe_header_encode(rebuilt,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
            require(!errors && rebuilt==cw,"Damaged speech codeword (strict offline check)");
            packed_codeword packed;
            imbe_pack(packed,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
            append(output,packed.data(),packed.size());
            imbe_deinterleave(reference,template_cw,f);
            imbe_interleave(control,template_cw,f);
        }
        require(control==reference,"Unexpected LDU control/status bits");
    }
    return output;
}
int main(int argc,char** argv) {
    try {
        require(argc==4,"Usage: p25_voice encode|decode|frame|extract INPUT OUTPUT (8-kHz mono s16le / 11-byte IMBE / packed P25)");
        const auto input=read(argv[2]);
        const std::string mode=argv[1];
        Bytes output;
        if (mode=="encode") output=codec(input,true);
        else if (mode=="decode") output=codec(input,false);
        else if (mode=="frame") output=frame(input);
        else if (mode=="extract") output=extract(input);
        else throw std::runtime_error("Unknown mode");
        std::ofstream file(argv[3],std::ios::binary);
        file.write(reinterpret_cast<const char*>(output.data()),static_cast<std::streamsize>(output.size()));
        file.close();
        require(bool(file),"Output write failed");
        std::printf("{\"mode\":\"%s\",\"input_bytes\":%zu,\"output_bytes\":%zu}\n",mode.c_str(),input.size(),output.size());
    } catch (const std::exception& error) {
        std::fprintf(stderr,"%s\n",error.what()); return 1;
    }
}
