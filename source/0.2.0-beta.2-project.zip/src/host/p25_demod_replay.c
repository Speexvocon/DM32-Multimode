// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_demod.h"
#include <stdio.h>
static unsigned units,voices,corrected;
static void frame(const p25_rx *r,void *context) {
    FILE *out=context;++units;
    if(r->duid!=5 && r->duid!=10) return;
    for(unsigned i=0;i<9;++i) {
        uint8_t payload[11];unsigned e;
        if(!p25_rx_voice(r->frame,i,payload,&e))return;
        if(fwrite(payload,1,11,out)!=11)return;
        ++voices;corrected+=e;
    }
}
int main(int argc,char **argv) {
    if(argc!=3)return 2;
    FILE *in=fopen(argv[1],"rb"),*out=fopen(argv[2],"wb");if(!in||!out)return 3;
    p25_demod d;p25_demod_init(&d);int a,b;
    while((a=fgetc(in))!=EOF) {
        b=fgetc(in);if(b==EOF)return 4;
        p25_demod_push(&d,(int16_t)((unsigned)a*256+(unsigned)b),frame,out);
    }
    for(unsigned i=0;i<32;++i)p25_demod_push(&d,0,frame,out);
    fclose(in);if(fclose(out))return 5;
    printf("units=%u voice_frames=%u corrected_voice_bits=%u acquisitions=%u state_bytes=%u\n",units,voices,corrected,d.acquisitions,(unsigned)sizeof d);
    return voices?0:6;
}
