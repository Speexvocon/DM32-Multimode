// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_dmr.h"
#include "radio_dmr_metrics.h"
#include "dmr/ambe/ambeVoice.h"
#include <string.h>

static radio_dmr *owner;

static void diagnostics_begin(radio_dmr *d, uint32_t now)
{
    ambe_voice_stats_t voice;
    dmr_call_stats_t call;
    ambeVoiceGetStats(&voice);
    dmr_call_get_stats(&call);
    d->diag_frames_base = voice.tx_frames;
    d->diag_repeats_base = voice.tx_repeats;
    d->diag_overflows_base = voice.tx_overflows;
    d->diag_calls_base = call.tx_calls;
    d->diag_denied_base = call.tx_denied;
    d->diag_underruns_base = call.tx_underruns;
    d->diag_events_base = call.evq_overflows;
    if (d->hal.tx_diag) d->hal.tx_diag(&d->diag_native_base, d->hal.ctx);
    memset(&d->diagnostics, 0, sizeof(d->diagnostics));
    d->diag_poll_seen = false;
    d->diagnostics.poll_timing_valid = d->hal.clock_us != NULL;
    d->diagnostics.start_ms = now;
    d->diagnostics.result = RADIO_DMR_TX_ACTIVE;
    d->tx_error = DMR_TX_OK;
}

static void native_diagnostics_end(radio_dmr *d)
{
    radio_dmr_diagnostics *diag = &d->diagnostics;
    if (!d->hal.tx_diag || diag->native_metrics_valid) return;
    radio_dmr_native_tx_diag_t native;
    d->hal.tx_diag(&native, d->hal.ctx);
    diag->native_tx_bursts = native.tx_bursts - d->diag_native_base.tx_bursts;
    diag->native_tx_underruns = native.tx_underruns - d->diag_native_base.tx_underruns;
    diag->native_tx_rejected = native.tx_rejected - d->diag_native_base.tx_rejected;
    diag->native_tx_done = native.tx_done - d->diag_native_base.tx_done;
    diag->native_event_overflows = native.event_overflows - d->diag_native_base.event_overflows;
    diag->native_metrics_valid = true;
}

static void diagnostics_end(radio_dmr *d, uint32_t now,
                            const dmr_call_view_t *view, radio_dmr_tx_result result)
{
    ambe_voice_stats_t voice;
    dmr_call_stats_t call;
    ambeVoiceGetStats(&voice);
    dmr_call_get_stats(&call);
    radio_dmr_diagnostics *diag = &d->diagnostics;
    diag->end_ms = now;
    diag->calls = call.tx_calls - d->diag_calls_base;
    diag->denied = call.tx_denied - d->diag_denied_base;
    diag->encoded_frames = voice.tx_frames - d->diag_frames_base;
    diag->encoded_repeats = voice.tx_repeats - d->diag_repeats_base;
    diag->encoded_overflows = voice.tx_overflows - d->diag_overflows_base;
    diag->source_underruns = call.tx_underruns - d->diag_underruns_base;
    diag->event_overflows = call.evq_overflows - d->diag_events_base;
    native_diagnostics_end(d);
    // The native mic summary resets on the first callback of a transmission,
    // not source.begin(). An access denial must not inherit the previous mic.
    if (diag->encoded_frames || diag->encoded_overflows) {
        diag->mic_peak = voice.tx_mic_peak;
        diag->mic_blocks = voice.tx_mic_blocks;
        diag->mic_level_db = voice.tx_mic_level_db;
        diag->mic_spread_db = voice.tx_mic_spread_db;
        diag->mic_zc = voice.tx_mic_zc;
    }
    if (view) { d->tx_error = view->tx_error; diag->phase = view->phase; }
    diag->tx_error = d->tx_error;
    diag->backend_error = d->error;
    if (result == RADIO_DMR_TX_COMPLETE && !diag->calls)
        result = RADIO_DMR_TX_CANCELLED; // PTT released during access/wake-up
    diag->result = result;
    diag->metrics_valid = true;
}

void radio_dmr_init(radio_dmr *d, const radio_dmr_hal *hal)
{
    if (!d || owner == d) return;
    memset(d, 0, sizeof(*d));
    if (hal) d->hal = *hal;
    d->release_required = true;
}

bool radio_dmr_config_valid(const radio_dmr_config *c)
{
    return c && c->rx_hz >= 100000000u && c->rx_hz <= 520000000u
        && c->tx_hz >= 100000000u && c->tx_hz <= 520000000u
        && c->source_id && c->source_id <= 0xffffffu
        && c->target_id && c->target_id <= 0xffffffu
        && c->cc <= 15 && (c->ts == 1 || c->ts == 2)
        && c->filter >= RADIO_DMR_FILTER_TARGET && c->filter <= RADIO_DMR_FILTER_PROM;
}

static bool hal_valid(const radio_dmr_hal *h)
{
    return h->radio && h->radio->set_mode && h->radio->rx && h->radio->tx
        && h->radio->tx_off && h->radio->audio && h->modem
        && h->modem->start && h->modem->stop && h->modem->configure
        && h->modem->rx_lock_slot && h->modem->set_cc_filter
        && h->modem->tx_begin && h->modem->tx_queue && h->modem->tx_queue_space
        && h->modem->tx_end && h->modem->tx_abort && h->modem->set_embedded_lc
        && h->modem->is_transmitting && h->audio && h->audio->start
        && h->audio->stop && h->audio->speaker_pcm
        && h->vocoder && h->vocoder->present && h->vocoder->reset
        && h->vocoder->encode && h->vocoder->decode && h->acquire && h->release;
}

void radio_dmr_stop(radio_dmr *d)
{
    if (!d || owner != d) return;
    bool aborted = d->diagnostics.result == RADIO_DMR_TX_ACTIVE;
    uint8_t native_error = dmr_call_view()->tx_error;
    uint8_t native_phase = dmr_call_view()->phase;
    hrc_audio_pcm_output_abort();
    // Preserve live engine counters before stop() may halt or reset it; audio
    // counters below are collected after the producer has been drained.
    if (aborted) native_diagnostics_end(d);
    dmr_call_ptt(false);
    dmr_call_stop();
    ambeVoiceStop();
    if (aborted) {
        // stop() drains the audio callback before collecting final mic/queue
        // totals. The native call view may already have returned to idle.
        d->tx_error = native_error;
        d->diagnostics.phase = native_phase;
        diagnostics_end(d, d->last_poll_ms, NULL, RADIO_DMR_TX_ABORTED);
    }
    d->hal.radio->audio(false);
    d->hal.radio->tx_off();
    // set_mode(FM) must invoke the native leave hook while ownership is held.
    d->hal.radio->set_mode(RADIO_MODE_FM);
    d->running = d->tx_armed = d->ptt_last = false;
    d->release_required = true;
    d->hal.release(d->hal.ctx);
    d->owned = false;
    owner = NULL;
}

bool radio_dmr_start(radio_dmr *d, const radio_dmr_config *c)
{
    if (!d) return false;
    if (owner || d->owned || d->running) { d->error = RADIO_DMR_BUSY; return false; }
    if (!radio_dmr_config_valid(c)) { d->error = RADIO_DMR_BAD_CONFIG; return false; }
    if (!hal_valid(&d->hal)) { d->error = RADIO_DMR_NO_HAL; return false; }
    // No native loading/calls while another mode still owns hardware/audio.
    d->error = RADIO_DMR_OK;
    if (!d->hal.acquire(d->hal.ctx)) {
        // The platform may distinguish an unavailable native slot from a busy
        // owner while acquiring its shared codec arena.
        if (d->error == RADIO_DMR_OK) d->error = RADIO_DMR_NO_OWNERSHIP;
        return false;
    }
    owner = d;
    d->owned = true;
    d->config = *c;
    d->error = RADIO_DMR_OK;
    // Mode/menu/CPS handoffs may restart the native singleton before STATUS.
    // Preserve the last attempt's evidence until a genuinely fresh PTT edge.
    // P25 also uses the board's DMR RF frontend. Force a real leave/enter
    // transition: set_mode(DMR) alone could otherwise be a board-level no-op.
    d->hal.radio->audio(false);
    d->hal.radio->tx_off();
    d->hal.radio->set_mode(RADIO_MODE_FM);
    if (!d->hal.vocoder->present()) {
        d->error = RADIO_DMR_NO_CODEC;
        // Stack not bound yet: release without touching a previous stack owner.
        d->hal.release(d->hal.ctx); d->owned = false; owner = NULL;
        return false;
    }
    dmr_call_init(d->hal.modem);
    ambeVoiceInit(d->hal.audio, d->hal.vocoder);
    ambeVoiceSetMixer(NULL);
    ambeVoiceSetTestSignal(false);
    ambeVoiceSetMicGain(5); // hardware gain remains the common controller's setting
    dmr_call_set_voice(ambeVoiceSink(), ambeVoiceSource());
    d->hal.radio->audio(false);
    d->hal.radio->set_mode(RADIO_MODE_DMR);
    if (!d->hal.radio->rx(c->rx_hz, RADIO_BW_12K5, NULL)) {
        d->error = RADIO_DMR_RX_FAILED; radio_dmr_stop(d); return false;
    }
    dmr_call_config_t cfg;
    dmr_call_config_default(&cfg);
    cfg.own_id = c->source_id; cfg.cc = c->cc; cfg.ts = c->ts; cfg.rmo = c->rmo;
    cfg.talk_target.id = c->target_id; cfg.talk_target.private_call = c->private_call;
    cfg.listen.hear_all = c->filter != RADIO_DMR_FILTER_TARGET;
    cfg.listen.any_cc = c->filter == RADIO_DMR_FILTER_PROM;
    cfg.tot_s = c->tot_s;
    dmr_call_configure(&cfg);
    if (!dmr_call_start()) {
        d->error = RADIO_DMR_MODEM_FAILED; radio_dmr_stop(d); return false;
    }
    d->running = true; d->ptt_last = false; d->release_required = true;
    hrc_audio_pcm_output_resume();
    return true;
}

static bool tx_phase(uint8_t phase)
{
    return phase == DMR_CALL_PHASE_TX_ACCESS || phase == DMR_CALL_PHASE_TX_WAKEUP
        || phase == DMR_CALL_PHASE_TX_VOICE || phase == DMR_CALL_PHASE_TX_ENDING
        || phase == DMR_CALL_PHASE_TX_DATA;
}

void radio_dmr_poll(radio_dmr *d, uint32_t now, bool down, bool allowed)
{
    if (!d || owner != d || !d->running) return;
    uint32_t poll_started = d->hal.clock_us ? d->hal.clock_us(d->hal.ctx) : 0;
    bool was_active = d->diagnostics.result == RADIO_DMR_TX_ACTIVE;
    d->last_poll_ms = now;
    bool permitted = allowed && d->config.owner_permission && !d->config.rx_only;
    if (!down) d->release_required = false;
    else if (!permitted) d->release_required = true;
    bool edge = down && !d->ptt_last && !d->release_required && permitted;
    if (edge) {
        d->error = RADIO_DMR_OK;
        diagnostics_begin(d, now);
        // Mute queued RX before the board can key RF, including access/wake-up
        // and a first transmission that starts the native audio task later.
        hrc_audio_pcm_output_abort();
        if (!d->hal.radio->tx(d->config.tx_hz, RADIO_BW_12K5, d->config.power, NULL)) {
            d->hal.radio->tx_off();
            hrc_audio_pcm_output_resume();
            d->error = RADIO_DMR_TX_REFUSED;
            d->release_required = true;
            // Native PTT was never invoked: its previous view is not this
            // board-level refusal's native error or phase.
            diagnostics_end(d, now, NULL, RADIO_DMR_TX_FAILED);
        } else {
            d->tx_armed = true;
            dmr_call_ptt(true);
        }
    } else if (!down || !permitted) dmr_call_ptt(false);
    dmr_call_poll(now);
    const dmr_call_view_t *view = dmr_call_view();
    if (d->tx_armed) {
        d->diagnostics.phase = view->phase;
        if (tx_phase(view->phase)) d->diagnostics.last_tx_phase = view->phase;
    }
    if (d->tx_armed && !tx_phase(view->phase)) {
        diagnostics_end(d, now, view, view->tx_error == DMR_TX_OK
            ? RADIO_DMR_TX_COMPLETE : RADIO_DMR_TX_FAILED);
        d->hal.radio->tx_off();
        hrc_audio_pcm_output_resume();
        d->tx_armed = false;
        if (down) d->release_required = true;
    }
    d->ptt_last = down;
    if (d->hal.clock_us && (edge || was_active)) {
        radio_dmr_diagnostics *diag = &d->diagnostics;
        if (d->diag_poll_seen) {
            uint32_t gap = poll_started - d->diag_poll_last_us;
            if (gap > diag->poll_gap_max_us) diag->poll_gap_max_us = gap;
        }
        d->diag_poll_last_us = poll_started;
        d->diag_poll_seen = true;
        // Completion snapshots happen above, but its finishing poll includes
        // the board's unkey and RX-output resume as well as the stack work.
        radio_dmr_cost_record(&diag->poll_cost, d->hal.clock_us(d->hal.ctx) - poll_started);
    }
}

const dmr_call_view_t *radio_dmr_view(const radio_dmr *d)
{
    return d && owner == d && d->running ? dmr_call_view() : NULL;
}

bool radio_dmr_get_diagnostics(const radio_dmr *d, radio_dmr_diagnostics *out)
{
    if (!d || !out) return false;
    *out = d->diagnostics;
    return true;
}

bool radio_dmr_scan_hold(const dmr_call_view_t *view)
{
    return view && view->state == DMR_CALL_STATE_RX
        && view->phase == DMR_CALL_PHASE_RX_VOICE && !view->caller.encrypted;
}

const char *radio_dmr_error_name(radio_dmr_error e)
{
    static const char *const names[] = { "ok", "bad_channel", "no_dmr_hal", "no_ambe_codec",
        "dmr_busy", "radio_owned", "dmr_rx_failed", "dmr_start_failed", "dmr_tx_refused" };
    return (unsigned)e < sizeof(names) / sizeof(names[0]) ? names[e] : "dmr_error";
}

const char *radio_dmr_tx_error_name(uint8_t e)
{
    static const char *const names[] = { "ok", "no_modem", "busy", "no_repeater",
        "rejected", "timeout", "stalled" };
    return e < sizeof(names) / sizeof(names[0]) ? names[e] : "unknown";
}

const char *radio_dmr_tx_result_name(radio_dmr_tx_result r)
{
    static const char *const names[] = { "none", "active", "complete", "failed", "aborted", "cancelled" };
    return (unsigned)r < sizeof(names) / sizeof(names[0]) ? names[r] : "unknown";
}
