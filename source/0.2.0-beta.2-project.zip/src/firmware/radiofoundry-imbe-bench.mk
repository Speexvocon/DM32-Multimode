# SPDX-License-Identifier: GPL-3.0-or-later
ifndef PROJECT_ROOT
$(error PROJECT_ROOT must name the project checkout)
endif
# The normal radio excludes retained captures and experimental bench paths.
# Opt in explicitly for an engineering image: DM32_LAB_DIAGNOSTICS=1.
DM32_LAB_DIAGNOSTICS ?= 0
ifneq ($(words $(DM32_LAB_DIAGNOSTICS)),1)
$(error DM32_LAB_DIAGNOSTICS must be 0 or 1)
endif
ifneq ($(filter $(DM32_LAB_DIAGNOSTICS),0 1),$(DM32_LAB_DIAGNOSTICS))
$(error DM32_LAB_DIAGNOSTICS must be 0 or 1)
endif
include Makefile
CFLAGS_APP += -DDM32_LAB_DIAGNOSTICS=$(DM32_LAB_DIAGNOSTICS)
ifneq ($(BOARD),dm32)
$(error IMBE benchmark is prepared for dm32 only)
endif
IMBE_DIR := $(PROJECT_ROOT)/research/references/nostar/imbe_vocoder
IMBE_SRC := $(filter-out $(IMBE_DIR)/imbe_vocoder.cc,$(wildcard $(IMBE_DIR)/*.cc))
IMBE_UNITY_NAMES := basicop2 math_sub aux_sub dsp_sub dc_rmv pe_lpf pitch_est pitch_ref v_uv_det qnt_sub sa_encode ch_encode encode
IMBE_SRC := $(filter-out $(addprefix $(IMBE_DIR)/,$(addsuffix .cc,$(IMBE_UNITY_NAMES))),$(IMBE_SRC))
IMBE_OBJ := $(patsubst $(IMBE_DIR)/%.cc,$(BUILD)/imbe/%.o,$(IMBE_SRC))
IMBE_OBJ += $(BUILD)/imbe/encoder_unity.o
BENCH_OBJ := $(BUILD)/imbe/bench.o $(BUILD)/imbe/app.o $(BUILD)/imbe/mic.o $(BUILD)/imbe/live_frame.o
BENCH_APP_SOURCE := dm32_imbe_bench
ifeq ($(BENCH_LIVE_RF),1)
BENCH_APP_SOURCE := dm32_p25_live
BENCH_OBJ := $(filter-out $(BUILD)/imbe/mic.o,$(BENCH_OBJ)) $(BUILD)/imbe/live_tx.o $(BUILD)/imbe/test_tx.o $(BUILD)/imbe/rx.o
BENCH_OBJ += $(BUILD)/imbe/demod.o
ifeq ($(DM32_LAB_DIAGNOSTICS),1)
BENCH_OBJ += $(BUILD)/imbe/receive_bench.o
endif
BENCH_OBJ += $(BUILD)/imbe/call.o
LDFLAGS += -Wl,--wrap=hrc_dmr_enter -Wl,--wrap=hrc_dmr_leave
# The normal live path does not call the optional size-report API. Retain its
# read-only class-size evidence explicitly for the post-link memory audit.
LDFLAGS += -Wl,--undefined=imbe_codec_object_bytes
# Only the unified application shares the software object with native AMBE.
# The standalone benchmark keeps its original fixed static codec allocation.
BENCH_ARENA_FLAGS := -DBENCH_SHARED_CODEC=1
MULTIMODE_DIR := $(BUILD)/multimode
MULTIMODE_GEN := $(PROJECT_ROOT)/build/generated-multimode/$(notdir $(BUILD))
MULTIMODE_OBJ := $(MULTIMODE_DIR)/radio_dmr.o $(MULTIMODE_DIR)/codec_workspace.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/vocoder.o $(MULTIMODE_DIR)/audio_pcm.o $(MULTIMODE_DIR)/dmr_glue.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/dmr_call.o $(MULTIMODE_DIR)/hrc7000_dmr.o
OBJ := $(filter-out $(BUILD)/platform/hrc7000/vocoder.o $(BUILD)/platform/hrc7000/audio_pcm.o $(BUILD)/platform/hrc7000/dmr_glue.o,$(OBJ))
OBJ := $(filter-out $(BUILD)/core/dmr/call/dmr_call.o $(BUILD)/drivers/modem/hrc7000/hrc7000_dmr.o,$(OBJ))
OBJ += $(MULTIMODE_OBJ)
$(TARGET).elf: $(MULTIMODE_OBJ)
DMR_BACKPORT_GEN := $(MULTIMODE_GEN)/dmr-backports
DMR_BACKPORT_SRC := core/dmr/call/dmr_call.c core/dmr/call/dmr_call.h drivers/modem/hrc7000/hrc7000_dmr.c
DMR_BACKPORT_PATCHES := $(wildcard $(PROJECT_ROOT)/src/firmware/radiofoundry-patches/*.patch)
$(addprefix $(DMR_BACKPORT_GEN)/,$(DMR_BACKPORT_SRC)): $(DMR_BACKPORT_GEN)/%: % $(PROJECT_ROOT)/scripts/generate-dmr-backports.py $(DMR_BACKPORT_PATCHES)
	python3 $(PROJECT_ROOT)/scripts/generate-dmr-backports.py $* $< $@
# Preserve the native object basenames, especially hrc7000_dmr.o: the linker
# selects the complete IRQ slot engine into startup-copied RAM by filename.
$(MULTIMODE_DIR)/dmr_call.o: $(DMR_BACKPORT_GEN)/core/dmr/call/dmr_call.c $(DMR_BACKPORT_GEN)/core/dmr/call/dmr_call.h
	@mkdir -p $(dir $@)
	$(CC) -I$(DMR_BACKPORT_GEN)/core $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_DIR)/hrc7000_dmr.o: $(DMR_BACKPORT_GEN)/drivers/modem/hrc7000/hrc7000_dmr.c
	@mkdir -p $(dir $@)
	$(CC) -Idrivers/modem/hrc7000 $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_GEN)/vocoder.c: platform/hrc7000/vocoder.c $(PROJECT_ROOT)/scripts/generate-shared-vocoder.py
	python3 $(PROJECT_ROOT)/scripts/generate-shared-vocoder.py $< $@
$(MULTIMODE_GEN)/audio_pcm.c: platform/hrc7000/audio_pcm.c $(PROJECT_ROOT)/scripts/generate-drained-audio.py
	python3 $(PROJECT_ROOT)/scripts/generate-drained-audio.py $< $@
$(MULTIMODE_GEN)/dmr_glue.c: platform/hrc7000/dmr_glue.c $(PROJECT_ROOT)/scripts/generate-drained-dmr.py
	python3 $(PROJECT_ROOT)/scripts/generate-drained-dmr.py $< $@
$(MULTIMODE_DIR)/vocoder.o: $(MULTIMODE_GEN)/vocoder.c $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/audio_pcm.o: $(MULTIMODE_GEN)/audio_pcm.c $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h $(PROJECT_ROOT)/src/firmware/radio_pcm_output.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
# Keep the dmr_glue.o basename: the pinned linker script places this complete
# deferred modem/IRQ host in startup-copied RAM using its filename pattern.
$(MULTIMODE_DIR)/dmr_glue.o: $(MULTIMODE_GEN)/dmr_glue.c $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_dmr.o: $(PROJECT_ROOT)/src/firmware/radio_dmr.c $(PROJECT_ROOT)/src/firmware/radio_dmr.h $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/codec_workspace.o: $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.c $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
endif
OBJ += $(IMBE_OBJ) $(BENCH_OBJ)
LDFLAGS += -Wl,--wrap=app_start -Wl,--wrap=hrc_dmr_board_init
# Only the codec changes optimization level; HAL, RTOS and the measuring app
# retain the baseline flags. Preserve integer semantics and avoid fast-math.
IMBE_OPT ?= -O3
IMBE_PROFILE_FLAGS := -DIMBE_PITCH_SPECIALIZE=1 -DBENCH_MICROPHONE=1 -I$(abspath $(BUILD)/imbe)
# Encoder stage callbacks are only useful for the standalone/lab benchmark.
ifneq ($(BENCH_LIVE_RF):$(DM32_LAB_DIAGNOSTICS),1:0)
IMBE_PROFILE_FLAGS += -DIMBE_STAGE_PROFILE=1
endif
DIAGNOSTICS_PROFILE_STAMP := $(BUILD)/dm32-diagnostics-profile
$(shell mkdir -p $(BUILD); printf '%s\n' '$(BENCH_LIVE_RF):$(DM32_LAB_DIAGNOSTICS)' | cmp -s - $(DIAGNOSTICS_PROFILE_STAMP) || printf '%s\n' '$(BENCH_LIVE_RF):$(DM32_LAB_DIAGNOSTICS)' > $(DIAGNOSTICS_PROFILE_STAMP))
$(IMBE_OBJ) $(BENCH_OBJ) $(MULTIMODE_OBJ): $(DIAGNOSTICS_PROFILE_STAMP)
BENCH_CXXFLAGS := -DDM32_LAB_DIAGNOSTICS=$(DM32_LAB_DIAGNOSTICS) $(filter-out -Os -O0 -O1 -O2 -O3 -Og -Ofast,$(COMMON)) $(IMBE_OPT) -std=gnu++17 -fwrapv -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-use-cxa-atexit -fstack-usage -nostdinc++ -I$(PROJECT_ROOT)/src/firmware/freestanding-cxx -I$(IMBE_DIR) -I$(PROJECT_ROOT)/src/firmware
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/p25_preferences.h $(PROJECT_ROOT)/src/firmware/p25_channel_store.h $(PROJECT_ROOT)/src/firmware/radio_channel.h $(PROJECT_ROOT)/src/firmware/p25_fm.h $(PROJECT_ROOT)/src/firmware/radio_ux.h $(PROJECT_ROOT)/src/firmware/p25_radio_features.h $(PROJECT_ROOT)/src/firmware/radio_dmr.h $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h $(PROJECT_ROOT)/src/firmware/radio_service_schedule.h $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_signal_meter.h $(PROJECT_ROOT)/src/firmware/p25_diagnostics.h $(PROJECT_ROOT)/src/firmware/p25_pcm_trace.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_functions.h $(PROJECT_ROOT)/src/firmware/radio_broadcast.h $(PROJECT_ROOT)/src/firmware/radio_tx_guard.h $(PROJECT_ROOT)/src/firmware/imbe_mic_queue.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_broadcast_input.h
$(TARGET).elf: $(IMBE_OBJ) $(BENCH_OBJ)
$(BUILD)/imbe/imbe_encode_profile.cc: $(IMBE_DIR)/encode.cc $(PROJECT_ROOT)/scripts/generate-imbe-profile.py
	python3 $(PROJECT_ROOT)/scripts/generate-imbe-profile.py $< $@
$(BUILD)/imbe/imbe_pitch_specialized.cc: $(IMBE_DIR)/pitch_est.cc $(PROJECT_ROOT)/scripts/generate-imbe-pitch.py
	python3 $(PROJECT_ROOT)/scripts/generate-imbe-pitch.py $< $@
$(BUILD)/imbe/encoder_unity.o: $(PROJECT_ROOT)/src/firmware/imbe_encoder_unity.cpp $(addprefix $(IMBE_DIR)/,$(addsuffix .cc,$(IMBE_UNITY_NAMES))) $(BUILD)/imbe/imbe_encode_profile.cc $(BUILD)/imbe/imbe_pitch_specialized.cc
	@mkdir -p $(dir $@)
	$(CROSS)g++ $(BENCH_CXXFLAGS) $(IMBE_PROFILE_FLAGS) -c $< -o $@
$(BUILD)/imbe/%.o: $(IMBE_DIR)/%.cc
	@mkdir -p $(dir $@)
	$(CROSS)g++ $(BENCH_CXXFLAGS) -c $< -o $@
$(BUILD)/imbe/bench.o: $(PROJECT_ROOT)/src/firmware/imbe_bench.cpp $(PROJECT_ROOT)/src/firmware/imbe_bench.h $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h
	@mkdir -p $(dir $@)
	$(CROSS)g++ $(BENCH_CXXFLAGS) $(BENCH_ARENA_FLAGS) -Wall -Wextra -Werror -c $< -o $@
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/$(BENCH_APP_SOURCE).c $(PROJECT_ROOT)/src/firmware/imbe_bench.h $(PROJECT_ROOT)/src/firmware/imbe_stream.h $(PROJECT_ROOT)/src/firmware/radio_control.h $(PROJECT_ROOT)/src/firmware/rx_capture.h $(PROJECT_ROOT)/src/firmware/p25_monitor.h $(PROJECT_ROOT)/src/firmware/p25_call.h $(PROJECT_ROOT)/src/firmware/p25_receive_policy.h $(PROJECT_ROOT)/src/firmware/p25_voice_policy.h $(PROJECT_ROOT)/src/firmware/p25_radio_ui.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) $(IMBE_PROFILE_FLAGS) -Werror -DBENCH_CLOCK_REGISTERS=1 -DBENCH_GIT=\"$(shell git -C $(PROJECT_ROOT) rev-parse --short HEAD)\" -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/mic.o: $(PROJECT_ROOT)/src/firmware/dm32_imbe_mic.c $(PROJECT_ROOT)/src/firmware/imbe_mic.h $(PROJECT_ROOT)/src/firmware/imbe_mic_queue.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -DBENCH_GIT=\"$(shell git -C $(PROJECT_ROOT) rev-parse --short HEAD)\" -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/live_frame.o: $(PROJECT_ROOT)/src/firmware/p25_live_frame.c $(PROJECT_ROOT)/src/firmware/p25_live_frame.h $(PROJECT_ROOT)/src/firmware/p25_interleave.h $(PROJECT_ROOT)/src/firmware/p25_channel_masks.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@
$(BUILD)/imbe/live_tx.o: $(PROJECT_ROOT)/src/firmware/p25_live_tx.c $(PROJECT_ROOT)/src/firmware/p25_live_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@
$(BUILD)/imbe/test_tx.o: $(PROJECT_ROOT)/src/firmware/p25_test_tx.c $(PROJECT_ROOT)/src/firmware/p25_test_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@

RX_CFLAGS := $(filter-out -Os -O0 -O1 -O2 -O3 -Og -Ofast,$(CFLAGS_APP)) -O3 -fstack-usage

$(BUILD)/imbe/rx.o: $(PROJECT_ROOT)/src/firmware/p25_rx.c $(PROJECT_ROOT)/src/firmware/p25_rx.h $(PROJECT_ROOT)/src/firmware/p25_rx_golay.h
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

$(BUILD)/imbe/call.o: $(PROJECT_ROOT)/src/firmware/p25_call.c $(PROJECT_ROOT)/src/firmware/p25_call.h
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

$(BUILD)/imbe/demod.o: $(PROJECT_ROOT)/src/firmware/p25_demod.c $(PROJECT_ROOT)/src/firmware/p25_demod.h $(PROJECT_ROOT)/src/firmware/p25_demod_filter.h $(PROJECT_ROOT)/src/firmware/p25_demod_math.h
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/receive_bench.o: $(PROJECT_ROOT)/src/firmware/p25_receive_bench.c $(PROJECT_ROOT)/src/firmware/p25_receive_bench.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
