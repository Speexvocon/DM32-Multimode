// SPDX-License-Identifier: GPL-3.0-or-later
// Fixed storage, explicit construction, no heap or static constructors.
#include "imbe_bench.h"
#include "imbe_vocoder_impl.h"
#ifndef BENCH_SHARED_CODEC
#define BENCH_SHARED_CODEC 0
#endif
#if BENCH_SHARED_CODEC
#include "radio_codec_workspace.h"
#else
alignas(imbe_vocoder_impl) static unsigned char state[sizeof(imbe_vocoder_impl)];
#endif
inline void* operator new(__SIZE_TYPE__, void* p) noexcept { return p; }
static imbe_vocoder_impl* encoder;
static bool codec_ready;
static int16_t pcm[160];
static uint32_t noise;
// Retained through state_bytes(), so the live build analyzer can read the
// actual class size even when its storage is the shared native arena.
extern "C" const uint32_t imbe_codec_object_bytes=sizeof(imbe_vocoder_impl);
static bool codec_begin(void) {
#if BENCH_SHARED_CODEC
    if (!radio_codec_begin(RADIO_CODEC_P25)) {codec_ready=false;return false;}
#endif
    return true;
}
static void codec_end(void) {
#if BENCH_SHARED_CODEC
    radio_codec_end(RADIO_CODEC_P25);
#endif
}
extern "C" bool imbe_bench_init(void) {
    codec_ready=false;
#if BENCH_SHARED_CODEC
    static_assert(sizeof(imbe_vocoder_impl)<=RADIO_CODEC_P25_STORAGE_BYTES,"IMBE exceeds dedicated P25 codec storage");
    static_assert(alignof(imbe_vocoder_impl)<=8,"IMBE exceeds shared codec alignment");
    if (!radio_codec_acquire(RADIO_CODEC_P25) || !codec_begin())return false;
    void *state=radio_codec_storage(RADIO_CODEC_P25,sizeof(imbe_vocoder_impl));
    if (!state) {codec_end();return false;}
#endif
    if (encoder) encoder->~imbe_vocoder_impl();
    encoder=new (state) imbe_vocoder_impl();
    noise=0x293;
    codec_ready=true;codec_end();return true;
}
extern "C" bool imbe_bench_ready(void) {
#if BENCH_SHARED_CODEC
    return codec_ready && encoder && radio_codec_owner()==RADIO_CODEC_P25;
#else
    return codec_ready && encoder;
#endif
}
extern "C" bool imbe_bench_release(void) {
#if BENCH_SHARED_CODEC
    if(radio_codec_owner()!=RADIO_CODEC_P25)return encoder==nullptr;
    if(!codec_begin())return false;
#endif
    codec_ready=false;
    if(encoder)encoder->~imbe_vocoder_impl();
    encoder=nullptr;codec_end();
#if BENCH_SHARED_CODEC
    return radio_codec_release(RADIO_CODEC_P25);
#else
    return true;
#endif
}
extern "C" void imbe_bench_prepare(uint32_t frame) {
    for (uint32_t i=0;i<160;++i) {
        if (frame<100) pcm[i]=0;
        else if (frame<200) {
            uint32_t phase=((frame-100)*160+i)%80;
            pcm[i]=static_cast<int16_t>((phase<40 ? int(phase) : 80-int(phase))*400-8000);
        } else {
            noise^=noise<<13; noise^=noise>>17; noise^=noise<<5;
            pcm[i]=static_cast<int16_t>(int(noise&32767)-16384);
        }
    }
}
extern "C" void imbe_bench_encode(uint8_t payload[11]) { imbe_bench_encode_pcm(pcm,payload); }
extern "C" void imbe_bench_source(unsigned frame,int16_t *output) {
    imbe_bench_prepare(frame % 300u); memcpy(output,pcm,sizeof pcm);
}
extern "C" void imbe_bench_encode_pcm(int16_t *input,uint8_t *payload) {
    if(!imbe_bench_ready() || !codec_begin()) {memset(payload,0,11);return;}
    encoder->encode_4400(input,payload);
    codec_end();
}
extern "C" size_t imbe_bench_state_bytes(void) {
    const uint32_t *size=&imbe_codec_object_bytes;
    __asm__ volatile("" : "+r"(size));
    return *size;
}
extern "C" void imbe_bench_decode_pcm(const uint8_t *payload,int16_t *output) {
    if(!imbe_bench_ready() || !codec_begin()) {memset(output,0,320);return;}
    uint8_t copy[11];memcpy(copy,payload,sizeof copy);
    encoder->decode_4400(output,copy);
    codec_end();
}
