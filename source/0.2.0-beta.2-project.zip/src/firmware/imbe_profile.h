// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef IMBE_PROFILE_H
#define IMBE_PROFILE_H
#ifdef __cplusplus
extern "C" {
#endif
// Ordered boundaries: preprocessing, pitch, window+FFT, pitch refinement,
// voicing, spectral quantization, frame-vector packing, end.
void imbe_profile_mark(unsigned stage);
#ifdef __cplusplus
}
#endif
#endif
