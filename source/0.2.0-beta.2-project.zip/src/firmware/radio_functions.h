// SPDX-License-Identifier: GPL-3.0-or-later
// V3 function settings. Zero encodings retain legacy records and their CRCs.
#ifndef RADIO_FUNCTIONS_H
#define RADIO_FUNCTIONS_H
#include <stdint.h>
#include <stdbool.h>

#define RADIO_POWER_LEVELS 9u
#define RADIO_TOT_DEFAULT_SECONDS 30u
#define RADIO_TOT_MIN_SECONDS 15u
#define RADIO_TOT_MAX_SECONDS 600u
#define RADIO_BCAST_DEFAULT_KHZ 87500u
#define RADIO_BCAST_MIN_KHZ 65000u
#define RADIO_BCAST_MAX_KHZ 108000u
#define RADIO_BCAST_STEP_KHZ 50u

typedef enum {
    RADIO_FUNCTION_DEFAULT=0, RADIO_FUNCTION_NONE, RADIO_FUNCTION_MEMORY,
    RADIO_FUNCTION_AB, RADIO_FUNCTION_SCAN, RADIO_FUNCTION_POWER,
    RADIO_FUNCTION_BROADCAST, RADIO_FUNCTION_STATUS, RADIO_FUNCTION_LOCK,
    RADIO_FUNCTION_COUNT
} radio_function_action;
typedef enum {
    RADIO_FUNCTION_P1=0, RADIO_FUNCTION_P2, RADIO_FUNCTION_SK1,
    RADIO_FUNCTION_SK2, RADIO_FUNCTION_KEYS
} radio_function_key;

static inline unsigned radio_functions_get_power(const uint8_t *channel) {return channel[31];}
static inline bool radio_functions_set_power(uint8_t *channel,unsigned level) {
    if(!channel || level>=RADIO_POWER_LEVELS)return false;
    channel[31]=(uint8_t)level;return true;
}
static inline unsigned radio_functions_tot_raw(const uint8_t *global) {
    return (unsigned)global[14]|(unsigned)global[15]<<8;
}
static inline bool radio_functions_tot_valid(unsigned seconds) {
    return !seconds || (seconds>=RADIO_TOT_MIN_SECONDS && seconds<=RADIO_TOT_MAX_SECONDS);
}
static inline unsigned radio_functions_get_tot_seconds(const uint8_t *global) {
    unsigned seconds=radio_functions_tot_raw(global);
    return seconds ? seconds : RADIO_TOT_DEFAULT_SECONDS;
}
static inline bool radio_functions_set_tot_seconds(uint8_t *global,unsigned seconds) {
    if(!global || !radio_functions_tot_valid(seconds))return false;
    global[14]=(uint8_t)seconds;global[15]=(uint8_t)(seconds>>8);return true;
}
static inline unsigned radio_functions_get_action_raw(const uint8_t *global,radio_function_key key) {
    return (unsigned)key<RADIO_FUNCTION_KEYS ? global[16u+(unsigned)key] : RADIO_FUNCTION_NONE;
}
static inline radio_function_action radio_functions_get_action(const uint8_t *global,radio_function_key key) {
    unsigned action=radio_functions_get_action_raw(global,key);
    if(action>=RADIO_FUNCTION_COUNT)return RADIO_FUNCTION_NONE;
    if(action)return (radio_function_action)action;
    switch(key) {
    case RADIO_FUNCTION_P1:return RADIO_FUNCTION_MEMORY;
    case RADIO_FUNCTION_P2:return RADIO_FUNCTION_STATUS;
    case RADIO_FUNCTION_SK1:return RADIO_FUNCTION_BROADCAST;
    case RADIO_FUNCTION_SK2:return RADIO_FUNCTION_AB;
    default:return RADIO_FUNCTION_NONE;
    }
}
static inline bool radio_functions_set_action(uint8_t *global,radio_function_key key,radio_function_action action) {
    if(!global || (unsigned)key>=RADIO_FUNCTION_KEYS || (unsigned)action>=RADIO_FUNCTION_COUNT)return false;
    global[16u+(unsigned)key]=(uint8_t)action;return true;
}
static inline uint32_t radio_functions_broadcast_raw(const uint8_t *global) {
    return (uint32_t)global[20]|(uint32_t)global[21]<<8|(uint32_t)global[22]<<16|(uint32_t)global[23]<<24;
}
static inline bool radio_functions_broadcast_valid(uint32_t khz) {
    return !khz || (khz>=RADIO_BCAST_MIN_KHZ && khz<=RADIO_BCAST_MAX_KHZ && !(khz%RADIO_BCAST_STEP_KHZ));
}
static inline uint32_t radio_functions_get_broadcast_khz(const uint8_t *global) {
    uint32_t khz=radio_functions_broadcast_raw(global);return khz ? khz : RADIO_BCAST_DEFAULT_KHZ;
}
static inline bool radio_functions_set_broadcast_khz(uint8_t *global,uint32_t khz) {
    if(!global || !radio_functions_broadcast_valid(khz))return false;
    global[20]=(uint8_t)khz;global[21]=(uint8_t)(khz>>8);global[22]=(uint8_t)(khz>>16);global[23]=(uint8_t)(khz>>24);return true;
}
static inline bool radio_functions_record_valid(const uint8_t *global) {
    if(!radio_functions_tot_valid(radio_functions_tot_raw(global))
       || !radio_functions_broadcast_valid(radio_functions_broadcast_raw(global)))return false;
    for(unsigned i=16;i<20;++i)if(global[i]>=RADIO_FUNCTION_COUNT)return false;
    for(unsigned i=24;i<32;++i)if(global[i])return false;
    return true;
}
#endif
