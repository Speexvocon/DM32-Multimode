// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_DIAGNOSTICS_H
#define P25_DIAGNOSTICS_H

// Normal firmware keeps bounded operational counters, but no retained voice,
// raw capture or experimental playback/RF paths. Engineering builds opt in.
#ifndef DM32_LAB_DIAGNOSTICS
#define DM32_LAB_DIAGNOSTICS 0
#endif
#if DM32_LAB_DIAGNOSTICS != 0 && DM32_LAB_DIAGNOSTICS != 1
#error DM32_LAB_DIAGNOSTICS must be 0 or 1
#endif

#endif
