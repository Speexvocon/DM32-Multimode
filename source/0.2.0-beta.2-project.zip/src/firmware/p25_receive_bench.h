// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_RECEIVE_BENCH_H
#define P25_RECEIVE_BENCH_H
#include <stdint.h>
#include <stddef.h>
typedef struct {
    uint32_t units, voices, corrected, pcm_hash, elapsed_us, decode_us;
    uint32_t max_decode_us, max_block_us, state_bytes, active_us;
    uint32_t fir_us, sync_us, fec_us, symbol_us, sync_tests, fec_candidates, fec_skipped;
} p25_receive_result;
// Known-clear bench capture only. Does not infer encryption state or drive audio/RF.
void p25_receive_bench(const uint8_t *be16,size_t samples,uint16_t nac,
    uint32_t (*clock_us)(void),void (*decode)(const uint8_t *,int16_t *),
    void (*yield_block)(void),p25_receive_result *result);
// Optional stage timing adds clock-call overhead; ordinary benchmark stays unprofiled.
void p25_receive_bench_profile(const uint8_t *be16,size_t samples,uint16_t nac,
    uint32_t (*clock_us)(void),void (*decode)(const uint8_t *,int16_t *),
    void (*yield_block)(void),p25_receive_result *result,int profile);
#endif
