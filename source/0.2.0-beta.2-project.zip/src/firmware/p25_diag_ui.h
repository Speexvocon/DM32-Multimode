// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (c) 2026 DM32 P25 research contributors
#ifndef P25_DIAG_UI_H
#define P25_DIAG_UI_H
#include "p25_test_tx.h"
#include "ui/gfx.h"
#include <stdio.h>
#include <string.h>

typedef struct {
    p25_test_tx tx;
    uint32_t frequency, arm_seconds;
    uint16_t battery_mv, critical_mv;
    bool armed, starting, setup_failed, arm_expired, calibration_valid;
    const char *calibration, *git;
} p25_diag_view;

static const char *p25_diag_reason(p25_tx_reason reason)
{
    switch (reason) {
    case P25_TX_RELEASED: return "PTT released";
    case P25_TX_LATE: return "Buffer service was late";
    case P25_TX_STALLED: return "No modem buffer event";
    case P25_TX_TIMEOUT: return "Maximum TX time reached";
    case P25_TX_CANCELLED: return "Stopped from PC";
    case P25_TX_NOT_ARMED: return "Arming required";
    default: return "Check PC diagnostic log";
    }
}

// Coordinates are relative to the panel's safe area (220 x 310 on DM32).
// Render only with RF stopped. The transmitting view is flushed BEFORE RF setup.
static void p25_diag_draw(const p25_diag_view *view)
{
    const color_t bg=RGB565(8,16,28), panel=RGB565(20,32,48);
    const color_t white=RGB565(240,248,255), muted=RGB565(152,176,196);
    const color_t cyan=RGB565(64,212,232), amber=RGB565(255,196,72);
    const color_t green=RGB565(96,224,152), red=RGB565(255,112,112);
    color_t accent=cyan;
    const char *title="DISARMED", *detail="Arm from PC to begin";
    const char *hint="PTT alone will not transmit";
    char line[48], countdown[40];
    bool running=view->starting || p25_test_tx_active(&view->tx);
    if (!view->calibration_valid) {
        title="CAL MISSING"; detail="TX locked: no calibration";
        hint="Check original radio data"; accent=red;
    } else if (running) {
        title="TRANSMITTING"; detail="1011 Hz / about 10.4 seconds";
        hint="Release PTT to stop"; accent=red;
    } else if (view->armed) {
        title="ARMED"; detail="Press and hold PTT";
        (void)snprintf(countdown, sizeof countdown, "Expires in %lu s / one call", (unsigned long)view->arm_seconds);
        hint=countdown; accent=amber;
    } else if (view->setup_failed) {
        title="TX REFUSED"; accent=red;
        detail=view->battery_mv < view->critical_mv ? "Battery below TX threshold" : "Radio setup did not complete";
        hint="Check PC log before rearming";
    } else if (view->arm_expired) {
        title="ARM EXPIRED"; detail="No PTT press within 30 s";
        hint="Arm again from PC"; accent=amber;
    } else if (view->tx.state == P25_TX_DONE) {
        title="STREAM COMPLETE"; detail="Verify tone on your receiver";
        hint="RF decode is not measured here"; accent=green;
    } else if (view->tx.state == P25_TX_ABORTED) {
        title="TEST STOPPED"; detail=p25_diag_reason(view->tx.reason);
        hint="Release PTT; rearm from PC";
        accent=view->tx.reason == P25_TX_RELEASED || view->tx.reason == P25_TX_CANCELLED ? amber : red;
    }
    gfx_frame_begin();
    gfx_clear(bg);
    gfx_text(&font_8x16, 8, 10, "P25 / BENCH", white);
    gfx_text(&font_6x12, 166, 12, "1011 Hz", cyan);
    gfx_text(&font_6x12, 8, 31, "PHASE 1 / CLEAR VOICE / TEST ONLY", muted);
    gfx_round_fill(8, 56, 204, 88, panel);
    gfx_fill(8, 64, 3, 72, accent);
    gfx_text(&font_12x24, 18, 68, title, accent);
    gfx_text(&font_6x12, 18, 102, detail, white);
    gfx_text(&font_6x12, 18, 122, hint, muted);
    gfx_text(&font_6x12, 12, 158, "TEST FREQUENCY", muted);
    if (view->frequency == 0) (void)snprintf(line, sizeof line, "---.------");
    else (void)snprintf(line, sizeof line, "%lu.%06lu", (unsigned long)(view->frequency/1000000u),
                        (unsigned long)(view->frequency%1000000u));
    gfx_text(&font_12x24, 12, 175, line, white);
    gfx_text(&font_6x12, 144, 185, "MHz", muted);
    gfx_text(&font_6x12, 12, 207, "NAC 293 / TG 1 / POWER L-", muted);
    gfx_hline(12, 228, 196, panel);
    uint32_t total=(p25_test_tx_stream_bytes()+P25_TX_BLOCK_BYTES-1u)/P25_TX_BLOCK_BYTES;
    uint32_t blocks=view->armed || view->starting ? 0 : (view->tx.blocks > total ? total : view->tx.blocks);
    if (running) (void)snprintf(line, sizeof line, "Live progress on PC / PTT stops");
    else (void)snprintf(line, sizeof line, "%lu / %lu blocks  |  %lu%%", (unsigned long)blocks,
                        (unsigned long)total, (unsigned long)(total ? blocks*100u/total : 0));
    gfx_text(&font_6x12, 12, 238, line, white);
    gfx_fill(12, 256, 196, 4, panel);
    if (!running && total != 0 && blocks != 0) gfx_fill(12, 256, (int)(196u*blocks/total), 4, accent);
    (void)snprintf(line, sizeof line, "CAL %s", view->calibration);
    gfx_text(&font_6x12, 12, 273, line, view->calibration_valid ? muted : red);
    (void)snprintf(line, sizeof line, "%u.%02u V", (unsigned)(view->battery_mv/1000u),
                   (unsigned)((view->battery_mv%1000u)/10u));
    gfx_text(&font_6x12, 166, 273, line, view->battery_mv < view->critical_mv ? amber : muted);
    gfx_text(&font_6x12, 12, 296, "EXPERIMENTAL", cyan);
    (void)snprintf(line, sizeof line, "%.12s", view->git);
    gfx_text(&font_6x12, 208-(int)strlen(line)*6, 296, line, muted);
    gfx_flush();
}
#endif
