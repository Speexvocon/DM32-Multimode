// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_codec_workspace.h"
#include <stdint.h>
#ifndef RADIO_CODEC_HOST_TEST
#include "platform.h"
#define LOCK() hrc_irq_save()
#define UNLOCK(s) hrc_irq_restore(s)
#else
extern uint32_t radio_codec_test_lock(void);
extern void radio_codec_test_unlock(uint32_t);
#define LOCK() radio_codec_test_lock()
#define UNLOCK(s) radio_codec_test_unlock(s)
#endif
// IMBE stays live alongside P25 RX. DMR instead borrows inactive RX storage;
// allocating its larger state a second time would exceed this radio's RAM.
static uint8_t codec_workspace[RADIO_CODEC_P25_STORAGE_BYTES] __attribute__((aligned(8)));
static uint8_t *dmr_storage;
static size_t dmr_capacity;
const uint32_t radio_codec_dmr_borrowed_bytes=RADIO_CODEC_WORKSPACE_BYTES;
static volatile radio_codec_owner_t owner;
static volatile bool busy;
static bool valid(radio_codec_owner_t who) { return who==RADIO_CODEC_P25 || who==RADIO_CODEC_DMR; }
static size_t borrowed_bytes(void) {
    const uint32_t *size=&radio_codec_dmr_borrowed_bytes;
    __asm__ volatile("" : "+r"(size));
    return *size;
}
bool radio_codec_bind_dmr(void *storage,size_t bytes) {
    uintptr_t p=(uintptr_t)storage,own=(uintptr_t)codec_workspace;
    size_t used=borrowed_bytes();
    bool bounds=p && !(p&7u) && bytes>=used && bytes<=UINTPTR_MAX-p
        && !(p<own+sizeof codec_workspace && own<p+used);
    uint32_t s=LOCK();bool ok=owner==RADIO_CODEC_NONE && !busy && bounds;
    if(ok) {dmr_storage=storage;dmr_capacity=bytes;}
    UNLOCK(s);return ok;
}
bool radio_codec_unbind_dmr(void) {
    uint32_t s=LOCK();bool ok=owner==RADIO_CODEC_NONE && !busy;
    if(ok) {dmr_storage=NULL;dmr_capacity=0;}
    UNLOCK(s);return ok;
}
bool radio_codec_acquire(radio_codec_owner_t who) {
    uint32_t s=LOCK();bool ok=valid(who) && (owner==RADIO_CODEC_NONE || owner==who)
        && (who!=RADIO_CODEC_DMR || (dmr_storage && dmr_capacity>=RADIO_CODEC_WORKSPACE_BYTES));
    if(ok)owner=who;
    UNLOCK(s);return ok;
}
bool radio_codec_release(radio_codec_owner_t who) {
    uint32_t s=LOCK();bool ok=valid(who) && owner==who && !busy;
    if(ok)owner=RADIO_CODEC_NONE;
    UNLOCK(s);return ok;
}
bool radio_codec_begin(radio_codec_owner_t who) {
    uint32_t s=LOCK();bool ok=valid(who) && owner==who && !busy;
    if(ok)busy=true;
    UNLOCK(s);return ok;
}
void radio_codec_end(radio_codec_owner_t who) {
    uint32_t s=LOCK();if(valid(who) && owner==who)busy=false;UNLOCK(s);
}
radio_codec_owner_t radio_codec_owner(void) { return owner; }
bool radio_codec_busy(radio_codec_owner_t who) { return valid(who) && owner==who && busy; }
void *radio_codec_storage(radio_codec_owner_t who,size_t bytes) {
    uint32_t s=LOCK();void *p=NULL;
    if(owner==who) {
        if(who==RADIO_CODEC_P25 && bytes<=sizeof codec_workspace)p=codec_workspace;
        else if(who==RADIO_CODEC_DMR && dmr_storage && bytes<=RADIO_CODEC_WORKSPACE_BYTES
                && dmr_capacity>=RADIO_CODEC_WORKSPACE_BYTES)p=dmr_storage;
    }
    UNLOCK(s);return p;
}
void *radio_codec_dmr_storage(radio_codec_dmr_slice_t slice) {
    static const uint16_t offsets[]={0,6144,13312,13456};
    uint8_t *p=radio_codec_storage(RADIO_CODEC_DMR,RADIO_CODEC_WORKSPACE_BYTES);
    return p && (unsigned)slice<sizeof offsets/sizeof offsets[0] ? p+offsets[slice] : NULL;
}
