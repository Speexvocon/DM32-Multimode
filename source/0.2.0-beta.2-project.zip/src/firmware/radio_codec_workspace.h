// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_CODEC_WORKSPACE_H
#define RADIO_CODEC_WORKSPACE_H
#include <stdbool.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
#define RADIO_CODEC_WORKSPACE_BYTES 13776u
#define RADIO_CODEC_P25_STORAGE_BYTES 5736u
typedef enum { RADIO_CODEC_NONE=0, RADIO_CODEC_P25=1, RADIO_CODEC_DMR=2 } radio_codec_owner_t;
typedef enum { RADIO_CODEC_DMR_DEC=0, RADIO_CODEC_DMR_ENC,
               RADIO_CODEC_DMR_BITS, RADIO_CODEC_DMR_PCM } radio_codec_dmr_slice_t;
// Task context. Ownership never transfers implicitly. The caller stops audio,
// drains callbacks and destroys any C++ object before releasing its ownership.
bool radio_codec_acquire(radio_codec_owner_t owner);
// Bind an inactive receive/capture region for DMR. The controller stops all
// users and invalidates its retained evidence before acquiring DMR ownership.
bool radio_codec_bind_dmr(void *storage, size_t bytes);
bool radio_codec_unbind_dmr(void);
bool radio_codec_release(radio_codec_owner_t owner);
bool radio_codec_begin(radio_codec_owner_t owner);
void radio_codec_end(radio_codec_owner_t owner);
radio_codec_owner_t radio_codec_owner(void);
bool radio_codec_busy(radio_codec_owner_t owner);
void *radio_codec_storage(radio_codec_owner_t owner, size_t bytes);
void *radio_codec_dmr_storage(radio_codec_dmr_slice_t slice);
// Generated native host extensions. Stop its audio callback before quiesce.
// park() remains permanent; resume cannot undo entry into the RAM monitor.
bool hrc_vocoder_quiesce(void);
bool hrc_vocoder_resume(void);
#ifdef __cplusplus
}
#endif
#endif
