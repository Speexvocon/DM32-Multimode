// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_PCM_TRACE_H
#define P25_PCM_TRACE_H
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "p25_diagnostics.h"
#if DM32_LAB_DIAGNOSTICS
#define PCM_TRACE_FRAMES 112u
#define PCM_TRACE_PAYLOADS 512u
// Main-task-only evidence, read over UART only with the monitor stopped.
typedef struct {
    int16_t pcm[PCM_TRACE_FRAMES][160];
    uint8_t payload[PCM_TRACE_PAYLOADS][11];
    uint32_t frames,hash;
    bool from_hdu,tone_substituted;
} p25_pcm_trace;
static inline void pcm_trace_init(p25_pcm_trace *t,bool from_hdu) {
    t->frames=0;t->hash=2166136261u;t->from_hdu=from_hdu;t->tone_substituted=false;
}
static inline unsigned pcm_trace_kept(const p25_pcm_trace *t) {
    return t->frames<PCM_TRACE_FRAMES ? (unsigned)t->frames : PCM_TRACE_FRAMES;
}
static inline void pcm_trace_record(p25_pcm_trace *t,const uint8_t bits[11],const int16_t pcm[160]) {
    memcpy(t->pcm[t->frames%PCM_TRACE_FRAMES],pcm,320);
    if(t->frames<PCM_TRACE_PAYLOADS)memcpy(t->payload[t->frames],bits,11);
    for(unsigned i=0;i<160;++i) {
        uint16_t x=(uint16_t)pcm[i];
        t->hash=(t->hash^(x&255u))*16777619u;
        t->hash=(t->hash^(x>>8))*16777619u;
    }
    ++t->frames;
}
#endif // DM32_LAB_DIAGNOSTICS
#endif
