// SPDX-License-Identifier: GPL-3.0-or-later
// Unified channel/CPS/UX adapter, included after the live controller globals.
#ifndef P25_RADIO_FEATURES_H
#define P25_RADIO_FEATURES_H
static p25_cs_store channel_store;
static uint8_t channel_record[32],channel_saved[32],global_record[32],global_saved[32];
static radio_ux radio_lights;
static radio_scan channel_scan;
// Build compact receiver descriptors once per scan start. Received-unit paths
// only inspect RAM; hopping reads just the profile being loaded, never scans
// flash quadratically to rediscover identical carriers.
static struct {
    uint32_t carrier_hz[P25_CS_CHANNELS];
    uint16_t nac[P25_CS_CHANNELS],group[P25_CS_CHANNELS],talkgroups[P25_CS_TG_CAPACITY];
    uint8_t representative[P25_CS_CHANNELS],kind[P25_CS_CHANNELS];
    uint8_t listed[32],members[32],visits[32],descriptor[32];
    uint16_t received_slot,received_group,selected_key;
    uint8_t tg_count;
    bool ready,dwelling,grace_used;
} feature_scan_cache;
static p25_fm analog_fm;
static bool features_ready,rx_tg_filter,cps_active,cps_link;
static uint32_t cps_transaction,cps_activity_us;
static uint32_t light_keys,lock_mask,lock_select_mask;
static uint8_t light_screen_level=255,light_key_level=255;
static char channel_label[24];
// Last channel per side is a convenience cache; persisted selection remains the
// existing 0=Frequency / 1..32=Channel codeplug field.
static uint16_t feature_last_memory[2];
static uint8_t feature_zone_map[32],feature_zone_loaded=255;
static char feature_zone_name[13];
static bool feature_temporary_tg;
static uint16_t feature_u16(const uint8_t *p) {return (uint16_t)(p[0]|(uint16_t)p[1]<<8);}
static void feature_put16(uint8_t *p,unsigned value) {p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8);}
static bool feature_fm(void) {return (channel_record[12]&2u)!=0;}
static bool feature_dmr(void) {return radio_channel_get_mode(channel_record)==RADIO_CHANNEL_DMR;}
static bool feature_p25(void) {return radio_channel_get_mode(channel_record)==RADIO_CHANNEL_P25;}
static unsigned feature_tx_power(void) {return radio_functions_get_power(channel_record);}
static unsigned feature_tx_tot(void) {return radio_functions_get_tot_seconds(global_record);}
static bool feature_tx_settings_valid(void) {
    return feature_tx_power()<board.power_count && radio_functions_tot_valid(feature_tx_tot());
}
static const char *feature_mode_name(void) {return feature_dmr() ? "DMR" : feature_fm() ? "FM" : "P25";}
static unsigned feature_filter(void) {return rx_promiscuous ? 1u : rx_tg_filter ? 2u : 0u;}
static bool feature_scan_tg(void) {return channel_scan.running && feature_scan_cache.descriptor[12]==1u;}
static bool feature_scan_group_allows(uint16_t group) {
    if(!channel_scan.running || !feature_scan_cache.ready || !feature_p25())return group==control.talkgroup;
    if(feature_scan_tg()) {
        for(unsigned i=0;i<feature_scan_cache.tg_count;++i)if(feature_scan_cache.talkgroups[i]==group)return true;
        return false;
    }
    if(!rx_tg_filter)return true;
    for(unsigned slot=0;slot<P25_CS_CHANNELS;++slot)
        if(p25_cs_map_test(feature_scan_cache.members,slot) && feature_scan_cache.group[slot]==group)return true;
    return false;
}
static void feature_scan_match_group(uint16_t group) {
    if(!channel_scan.running || !feature_scan_cache.ready || !feature_p25())return;
    if(!feature_scan_group_allows(group))return;
    feature_scan_cache.received_group=group;
    if(feature_scan_tg() || !rx_tg_filter) {feature_scan_cache.received_slot=(uint16_t)(channel_scan.cursor+1u);return;}
    // If several memories name the same destination, keep the current base
    // profile where possible; TX power/split and channel names remain local.
    unsigned base=channel_scan.cursor;
    if(p25_cs_map_test(feature_scan_cache.members,base) && feature_scan_cache.group[base]==group) {
        feature_scan_cache.received_slot=(uint16_t)(base+1u);return;
    }
    for(unsigned slot=0;slot<P25_CS_CHANNELS;++slot)
        if(p25_cs_map_test(feature_scan_cache.members,slot) && feature_scan_cache.group[slot]==group) {
            feature_scan_cache.received_slot=(uint16_t)(slot+1u);return;
        }
}
static unsigned feature_scan_received_slot(void) {
    return channel_scan.running ? feature_scan_cache.received_slot : 0u;
}
static unsigned feature_scan_received_group(void) {
    return channel_scan.running ? feature_scan_cache.received_group : 0u;
}
static unsigned feature_scan_group_size(void) {
    if(!channel_scan.running || !feature_scan_cache.ready || !feature_p25())return 0u;
    if(feature_scan_tg())return feature_scan_cache.tg_count;
    unsigned count=0;
    for(unsigned i=0;i<P25_CS_CHANNELS;++i)if(p25_cs_map_test(feature_scan_cache.members,i))++count;
    return count;
}
static unsigned feature_vfo(void) {return global_record[9]&1u;}
static unsigned feature_memory(void) {return p25_cs_selection(global_record,feature_vfo());}
static unsigned feature_key(void) {unsigned slot=feature_memory();return slot ? slot-1u : P25_CS_VFO_A+feature_vfo();}
static unsigned feature_zone(void) {return global_record[26+feature_vfo()];}
static bool feature_zone_load(void) {
    unsigned zone=feature_zone();
    if(feature_zone_loaded==zone)return true;
    memset(feature_zone_map,zone ? 0 : 255,sizeof feature_zone_map);memset(feature_zone_name,0,sizeof feature_zone_name);
    if(zone) {
        uint8_t record[32];unsigned key=p25_cs_zone_key(zone-1u);
        if(!p25_cs_read(&channel_store,key,record) || !record[0]
           || !p25_cs_read(&channel_store,key+1u,feature_zone_map))return false;
        memcpy(feature_zone_name,record,12);
    } else memcpy(feature_zone_name,"All channels",12);
    feature_zone_loaded=(uint8_t)zone;return true;
}
static void feature_mirror_store(void) {
    pref_store.have=channel_store.have_active || channel_store.have_legacy;
    pref_store.writable=channel_store.writable;pref_store.seq=channel_store.revision;
}
static void feature_apply(void) {
    feature_temporary_tg=false;
    if(features_ready && !feature_zone_load())reason="channel_read_failed";
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,hrc_micros());
    ui_rssi_valid=false;ui_rssi_bars=0;
    uint32_t rx=pref_get(channel_record),tx=pref_get(channel_record+4);
    bool occupied=(channel_record[12]&1u)!=0;
    frequency=occupied && channel_in_band(rx,false) ? rx : 0;
    control.tx_frequency=frequency ? tx : 0;control.split=rx!=tx;
    control.nac=occupied && !feature_dmr() ? feature_u16(channel_record+8) : 0x293u;
    control.talkgroup=occupied && !feature_dmr() ? feature_u16(channel_record+10) : 1u;
    control.source_id=pref_get(global_record);mic_gain_db=global_record[4];
    owner_tx_inhibit=global_record[13]!=0;
    unsigned filter=(channel_record[12]>>2)&3u;rx_promiscuous=filter==1u;rx_tg_filter=filter==2u;
    radio_lights.screen_seconds=feature_u16(global_record+5);
    radio_lights.keypad_seconds=feature_u16(global_record+7);
    if(feature_memory())snprintf(channel_label,sizeof channel_label,"%c M%03u %.12s",'A'+feature_vfo(),feature_memory()%(P25_CS_CHANNELS+1u),(const char *)channel_record+14);
    else snprintf(channel_label,sizeof channel_label,"Frequency %c",'A'+feature_vfo());
}
static void feature_capture(void) {
    if(frequency) {
        pref_put(channel_record,frequency);pref_put(channel_record+4,control.tx_frequency);
        if(!feature_dmr()) {feature_put16(channel_record+8,control.nac);if(!feature_temporary_tg)feature_put16(channel_record+10,control.talkgroup);}
        // TG scanning overrides the receive policy only for the running list.
        if(!feature_scan_tg())channel_record[12]=(uint8_t)((channel_record[12]&0x72u)|1u|(feature_filter()<<2));
    }
    pref_put(global_record,control.source_id);global_record[4]=(uint8_t)mic_gain_db;
    global_record[13]=(uint8_t)owner_tx_inhibit;
    feature_put16(global_record+5,radio_lights.screen_seconds);
    feature_put16(global_record+7,radio_lights.keypad_seconds);
}
static bool feature_commit(unsigned key,const uint8_t record[32],bool save_globals) {
    if(!features_ready || !channel_store.writable || cps_active || channel_store.staging)return false;
    if(!p25_cs_begin(&channel_store,channel_store.revision))return false;
    bool ok=(key>=P25_CS_RECORDS || p25_cs_stage_write(&channel_store,key,record))
        && (!save_globals || p25_cs_stage_write(&channel_store,P25_CS_GLOBAL,global_record));
    uint32_t crc=0;
    ok=ok && p25_cs_stage_crc(&channel_store,&crc) && p25_cs_commit(&channel_store,crc);
    if(!ok)p25_cs_abort(&channel_store);
    feature_mirror_store();return ok;
}
static void preferences_restore(void) {
    radio_ux_init(&radio_lights,hrc_micros());
    memset(&channel_scan,0,sizeof channel_scan);memset(&feature_scan_cache,0,sizeof feature_scan_cache);
    memset(&analog_fm,0,sizeof analog_fm);
    cps_active=cps_link=false;features_ready=false;
    memset(feature_last_memory,0,sizeof feature_last_memory);
    feature_zone_loaded=255;feature_temporary_tg=false;
    memset(channel_record,0,32);memset(global_record,0,32);
    pref_put(global_record,1);global_record[4]=11;feature_put16(global_record+5,60);feature_put16(global_record+7,15);
    bool opened=p25_cs_open(&channel_store,board.flash);
    features_ready=opened && p25_cs_read(&channel_store,P25_CS_GLOBAL,global_record);
    if(features_ready) {
        unsigned key=feature_key();
        if(!p25_cs_read(&channel_store,key,channel_record) || !(channel_record[12]&1u)) {
            p25_cs_set_selection(global_record,feature_vfo(),0);
            (void)p25_cs_read(&channel_store,P25_CS_VFO_A+feature_vfo(),channel_record);
        }
        feature_apply();
    } else {feature_apply();channel_store.writable=false;}
    for(unsigned side=0;side<2;++side)feature_last_memory[side]=(uint16_t)p25_cs_selection(global_record,side);
    feature_mirror_store();pref_store.flash=board.flash;
    memcpy(channel_saved,channel_record,32);memcpy(global_saved,global_record,32);
    pref_saved=pref_current();pref_dirty=false;
    pref_state=!pref_store.writable ? "read_only" : pref_store.have ? "saved" : "defaults";
    control.inhibit=true;control.tx_enabled=false;
}
static void preferences_poll(bool down) {
    if(!features_ready)return;
    if(normal_mode || !strcmp(pref_state,"pending"))feature_capture();
    pref_dirty=memcmp(channel_record,channel_saved,32) || memcmp(global_record,global_saved,32);
    p25_preferences current=pref_current();
    if(!pref_dirty && pref_store.have && !strcmp(pref_state,"pending") && pref_values(&current))pref_state=pref_store.writable ? "saved" : "read_only";
    if(!pref_dirty || down || mon_running || analog_fm.running || digital_dmr.running || rx_job || prepared || editing || armed
       || audio_on || hardware_running || call_active || broadcast.busy || channel_scan.running || cps_active)return;
    if(!pref_store.writable) {pref_state="read_only";return;}
    if(!strcmp(pref_state,"save_failed"))return;
    if(feature_commit(feature_key(),channel_record,true)) {
        memcpy(channel_saved,channel_record,32);memcpy(global_saved,global_record,32);
        pref_saved=pref_current();pref_dirty=false;pref_state="saved";
    } else pref_state="save_failed";
}
static void feature_pause(void) {
    if(broadcast.owned)radio_broadcast_stop(&broadcast);
    if(broadcast_show) {editing=false;digit_count=0;edit_from_menu=false;}
    broadcast_show=false;
    if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
    if(mon_running)mon_stop("profile_change");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
}
static bool feature_stop_scan(bool adopt) {
    bool running=channel_scan.running;
    unsigned slot=channel_scan.cursor;
    unsigned received=feature_scan_received_slot();
    unsigned reply=feature_scan_cache.descriptor[13];
    unsigned reply_key=reply==2u ? feature_u16(feature_scan_cache.descriptor+16)-1u
        : reply==1u && received ? received-1u : feature_scan_cache.selected_key;
    unsigned temporary=feature_scan_tg() && reply==1u && received ? feature_scan_cache.received_group : 0u;
    channel_scan.running=channel_scan.holding=false;
    memset(&feature_scan_cache,0,sizeof feature_scan_cache);
    if(!running)return true;
    if(!adopt) {
        unsigned filter=(channel_record[12]>>2)&3u;rx_promiscuous=filter==1u;rx_tg_filter=filter==2u;
        return true;
    }
    bool ok=true;
    if(reply_key!=slot) {
        // Adoption is task-context work. The callback only selected a slot;
        // stop RX before touching flash or changing any TX/profile settings.
        feature_pause();uint8_t record[32];
        if(reply_key<P25_CS_GLOBAL && p25_cs_read(&channel_store,reply_key,record) && (record[12]&1u)
           && channel_in_band(pref_get(record),false)) {
            memcpy(channel_record,record,32);memcpy(channel_saved,record,32);
            slot=reply_key;
        } else {reason="channel_read_failed";ok=false;} // Keep the valid base/key together.
    }
    channel_scan.cursor=(uint16_t)slot;
    unsigned selection=slot<P25_CS_CHANNELS ? slot+1u : 0u;
    if(selection && !p25_cs_map_test(feature_zone_map,selection-1u)) {
        global_record[26+feature_vfo()]=0;feature_zone_loaded=255;
    }
    p25_cs_set_selection(global_record,feature_vfo(),selection);
    if(selection)feature_last_memory[feature_vfo()]=(uint16_t)selection;
    feature_apply();normal_permission();
    if(ok && temporary && feature_p25()) {control.talkgroup=temporary;feature_temporary_tg=true;}
    return ok;
}
static bool feature_load_key(unsigned key) {
    uint8_t record[32];
    if(!features_ready || key>=P25_CS_GLOBAL || !p25_cs_read(&channel_store,key,record) || !(record[12]&1u)
       || !channel_in_band(pref_get(record),false))return false;
    feature_pause();memcpy(channel_record,record,32);feature_apply();
    memcpy(channel_saved,channel_record,32); // Recall does not rewrite the memory.
    mon_enabled=true;mon_reason="ready";reason="listening";
    radio_complete(&control,false);normal_permission();return true;
}
// Finish the current profile before selecting another. The channel-number
// editor may be open, but it has not changed the current channel itself.
static bool feature_selection_ready(void) {
    if(!feature_stop_scan(true))return false;
    feature_pause();
    bool was_editing=editing;editing=false;preferences_poll(false);editing=was_editing;
    if(pref_dirty) {reason="save_failed";return false;}
    return true;
}
static bool feature_channel_available(unsigned slot) {
    uint8_t record[32];
    return slot>=1u && slot<=P25_CS_CHANNELS && p25_cs_map_test(feature_zone_map,slot-1u) && p25_cs_read(&channel_store,slot-1u,record)
        && (record[12]&1u) && channel_in_band(pref_get(record),false);
}
static bool feature_select_channel(unsigned slot) {
    if(!feature_channel_available(slot)) {reason="channel_empty";return false;}
    if(!feature_selection_ready())return false;
    if(!feature_load_key(slot-1u)) {reason="channel_read_failed";return false;}
    p25_cs_set_selection(global_record,feature_vfo(),slot);feature_last_memory[feature_vfo()]=(uint16_t)slot;
    feature_apply();pref_state="pending";return true;
}
static bool feature_recall(int direction) {
    if(!direction)return false;
    feature_pause();
    uint8_t occupied[32]={0};unsigned count=0;
    for(unsigned slot=1;slot<=P25_CS_CHANNELS;++slot)if(feature_channel_available(slot)) {occupied[(slot-1u)/8u]|=(uint8_t)(1u<<((slot-1u)%8u));++count;}
    if(!count) {reason="no_memories";return false;}
    if(!feature_selection_ready())return false;
    unsigned current=feature_memory();
    unsigned slot=current ? current-1u : direction>0 ? P25_CS_CHANNELS-1u : 0u;
    // Preserve all accumulated encoder detents without intermediate flash
    // commits. Bound traversal even if an input driver reports a large delta.
    unsigned steps=direction>0 ? (unsigned)direction : 0u-(unsigned)direction;
    steps=(steps-1u)%count+1u;
    while(steps) {
        slot=(slot+(direction>0 ? 1u : P25_CS_CHANNELS-1u))%P25_CS_CHANNELS;
        if(p25_cs_map_test(occupied,slot))--steps;
    }
    if(!feature_load_key(slot)) {reason="channel_read_failed";return false;}
    p25_cs_set_selection(global_record,feature_vfo(),slot+1u);feature_last_memory[feature_vfo()]=(uint16_t)(slot+1u);
    feature_apply();pref_state="pending";return true;
}
static bool feature_select_vfo(bool other) {
    if(!feature_selection_ready())return false;
    unsigned previous=feature_memory();
    if(previous)feature_last_memory[feature_vfo()]=(uint16_t)previous;
    unsigned next_vfo=other ? feature_vfo()^1u : feature_vfo();
    unsigned selected=other ? p25_cs_selection(global_record,next_vfo) : 0;
    unsigned key=selected ? selected-1u : P25_CS_VFO_A+next_vfo;uint8_t record[32];
    if(!p25_cs_read(&channel_store,key,record) || ((record[12]&1u) && !channel_in_band(pref_get(record),false)))return false;
    if(selected && !(record[12]&1u)) {
        selected=0;key=P25_CS_VFO_A+next_vfo;
        if(!p25_cs_read(&channel_store,key,record) || ((record[12]&1u) && !channel_in_band(pref_get(record),false)))return false;
    }
    global_record[9]=(uint8_t)next_vfo;p25_cs_set_selection(global_record,next_vfo,selected);memcpy(channel_record,record,32);
    if(selected)feature_last_memory[next_vfo]=(uint16_t)selected;
    feature_apply();memcpy(channel_saved,channel_record,32);pref_state="pending";reason="listening";
    mon_enabled=channel_in_band(frequency,false);mon_reason=mon_enabled ? "ready" : "no_channel";
    radio_complete(&control,false);normal_permission();return true;
}
static bool feature_toggle_mode(void) {
    if(feature_memory())return feature_select_vfo(false);
    feature_pause();
    unsigned last=feature_last_memory[feature_vfo()];
    if(feature_channel_available(last))return feature_select_channel(last);
    return feature_recall(1);
}
static bool feature_save_memory(unsigned slot) {
    if(slot<1 || slot>P25_CS_CHANNELS || !frequency)return false;
    feature_capture();uint8_t saved[32];memcpy(saved,channel_record,32);
    if(!saved[14])snprintf((char *)saved+14,12,"CH %03u",slot);
    if(!feature_commit(slot-1u,saved,false))return false;
    reason="memory_saved";return true;
}
static bool feature_zone_next(void) {
    if(!feature_selection_ready())return false;
    unsigned current=feature_zone(),next=current;uint8_t record[32];
    for(unsigned i=1;i<=P25_CS_ZONES+1u;++i) {
        next=(current+i)%(P25_CS_ZONES+1u);
        if(!next)break;
        if(!p25_cs_read(&channel_store,p25_cs_zone_key(next-1u),record))return false;
        if(record[0])break;
    }
    global_record[26+feature_vfo()]=(uint8_t)next;feature_zone_loaded=255;
    if(!feature_zone_load()) {
        global_record[26+feature_vfo()]=(uint8_t)current;feature_zone_loaded=255;(void)feature_zone_load();
        reason="channel_read_failed";return false;
    }
    if(feature_memory() && !p25_cs_map_test(feature_zone_map,feature_memory()-1u)) {
        bool found=false;
        for(unsigned slot=1;slot<=P25_CS_CHANNELS;++slot)if(feature_channel_available(slot)) {
            if(!feature_load_key(slot-1u)) {
                global_record[26+feature_vfo()]=(uint8_t)current;feature_zone_loaded=255;(void)feature_zone_load();
                reason="channel_read_failed";return false;
            }
            p25_cs_set_selection(global_record,feature_vfo(),slot);feature_last_memory[feature_vfo()]=(uint16_t)slot;found=true;break;
        }
        if(!found) {
            if(!p25_cs_read(&channel_store,P25_CS_VFO_A+feature_vfo(),record)) {
                global_record[26+feature_vfo()]=(uint8_t)current;feature_zone_loaded=255;(void)feature_zone_load();
                reason="channel_read_failed";return false;
            }
            memcpy(channel_record,record,32);memcpy(channel_saved,record,32);p25_cs_set_selection(global_record,feature_vfo(),0);
        }
    }
    feature_apply();pref_state="pending";return true;
}
static void feature_scan_description(uint8_t descriptor[32]) {
    if(!p25_cs_read(&channel_store,p25_cs_scan_key(global_record[12]),descriptor))memset(descriptor,0,32);
}
static void feature_scan_next(void) {
    uint8_t descriptor[32];unsigned current=global_record[12];
    for(unsigned i=1;i<=P25_CS_SCAN_LISTS;++i) {
        unsigned next=(current+i)%P25_CS_SCAN_LISTS;
        if(!p25_cs_read(&channel_store,p25_cs_scan_key(next),descriptor)) {reason="channel_read_failed";return;}
        if(descriptor[0]) {global_record[12]=(uint8_t)next;pref_state="pending";return;}
    }
    reason="empty_scan_list";
}
static bool feature_scan_member(const uint8_t record[32],unsigned slot) {
    return (record[12]&1u) && p25_cs_map_test(feature_scan_cache.listed,slot) && channel_in_band(pref_get(record),false);
}
static bool feature_scan_same_receiver(unsigned a,unsigned b) {
    return feature_scan_cache.kind[a]==feature_scan_cache.kind[b]
        && (feature_scan_cache.kind[a]&3u)==RADIO_CHANNEL_P25
        && feature_scan_cache.carrier_hz[a]==feature_scan_cache.carrier_hz[b]
        && feature_scan_cache.nac[a]==feature_scan_cache.nac[b];
}
static void feature_scan_members(void) {
    memset(feature_scan_cache.members,0,32);
    unsigned base=channel_scan.cursor;
    for(unsigned slot=0;slot<P25_CS_CHANNELS;++slot)
        if(p25_cs_map_test(feature_scan_cache.listed,slot)
           && (slot==base || feature_scan_same_receiver(base,slot)))
            feature_scan_cache.members[slot/8u]|=(uint8_t)(1u<<(slot%8u));
    feature_scan_cache.dwelling=feature_scan_cache.grace_used=false;
}
static bool feature_scan_has_other(void) {
    for(unsigned i=0;i<32;++i)if(feature_scan_cache.listed[i] & (uint8_t)~feature_scan_cache.members[i])return true;
    return false;
}
static bool feature_scan_build(void) {
    uint8_t record[32];
    for(unsigned slot=0;slot<P25_CS_CHANNELS;++slot) {
        if(!p25_cs_map_test(feature_scan_cache.listed,slot))continue;
        if(!p25_cs_read(&channel_store,slot,record) || !feature_scan_member(record,slot))return false;
        feature_scan_cache.carrier_hz[slot]=pref_get(record);
        feature_scan_cache.nac[slot]=feature_u16(record+8);feature_scan_cache.group[slot]=feature_u16(record+10);
        feature_scan_cache.kind[slot]=(uint8_t)(radio_channel_get_mode(record)|(((record[12]>>2)&3u)<<2));
        unsigned representative=slot;
        for(unsigned prior=0;prior<slot;++prior)
            if(p25_cs_map_test(feature_scan_cache.listed,prior) && feature_scan_same_receiver(slot,prior)) {
                representative=feature_scan_cache.representative[prior];break;
            }
        feature_scan_cache.representative[slot]=(uint8_t)representative;
        if(representative==slot)feature_scan_cache.visits[slot/8u]|=(uint8_t)(1u<<(slot%8u));
    }
    feature_scan_cache.ready=true;return true;
}
static bool feature_scan_acquiring(uint32_t now) {
    if(!feature_p25() || !mon_running)return false;
    // Known excluded traffic must not hold this carrier. A matching-NAC NID
    // may earn only one short grace period while its HDU/LDU finishes, so an
    // endless stream of partial units cannot pin a multi-frequency scan.
    if(rx_tg_filter && monitor.call.group_valid && !feature_scan_group_allows(monitor.call.group))return false;
    if(monitor.call.active && monitor.call.state!=P25_RX_WAIT_METADATA && monitor.call.state!=P25_RX_CLEAR)return false;
    if(mon_have_sync && now-mon_sync_us<600000u && monitor.call.active && monitor.call.state==P25_RX_WAIT_METADATA)return true;
    const p25_demod *demod=&monitor.demod;
    if(demod->pending_ticks && (rx_promiscuous || demod->pending.nac==control.nac)
       && (demod->pending.duid==0 || demod->pending.duid==5 || demod->pending.duid==10))return true;
    for(unsigned i=0;i<10u;++i) {
        const p25_rx *unit=&demod->lane[i].rx;
        if(unit->expected && unit->symbols>=57u && (rx_promiscuous || unit->nac==control.nac)
           && (unit->duid==0 || unit->duid==5 || unit->duid==10))return true;
    }
    return false;
}
static bool feature_scan_start(void) {
    if(channel_scan.running && !feature_stop_scan(true))return false;
    feature_pause();preferences_poll(false);if(pref_dirty)return false;
    memset(&feature_scan_cache,0,sizeof feature_scan_cache);
    unsigned key=p25_cs_scan_key(global_record[12]);uint8_t record[32];
    if(!p25_cs_read(&channel_store,key,feature_scan_cache.descriptor)) {reason="channel_read_failed";return false;}
    uint8_t *descriptor=feature_scan_cache.descriptor;
    if(!descriptor[0]) {reason="empty_scan_list";return false;}
    unsigned found=P25_CS_CHANNELS;
    feature_scan_cache.selected_key=(uint16_t)feature_key();
    if(descriptor[12]==1u) {
        unsigned base=feature_u16(descriptor+14);
        if(!base || base>P25_CS_CHANNELS || !descriptor[22]) {reason="empty_scan_list";return false;}
        found=base-1u;feature_scan_cache.selected_key=(uint16_t)found;
        p25_cs_map_set(feature_scan_cache.listed,found,true);
        feature_scan_cache.tg_count=descriptor[22];
        for(unsigned part=0;part<4;++part) {
            if(!p25_cs_read(&channel_store,key+2u+part,record)) {reason="channel_read_failed";return false;}
            for(unsigned i=0;i<16;++i)feature_scan_cache.talkgroups[part*16u+i]=feature_u16(record+2u*i);
        }
    } else {
        if(!p25_cs_read(&channel_store,key+1u,feature_scan_cache.listed)) {reason="channel_read_failed";return false;}
        for(unsigned i=0;i<P25_CS_CHANNELS;++i)if(p25_cs_map_test(feature_scan_cache.listed,i)) {found=i;break;}
    }
    if(found==P25_CS_CHANNELS) {reason="empty_scan_list";return false;}
    radio_scan_start(&channel_scan,hrc_micros(),(uint16_t)found,global_record[12]);
    channel_scan.dwell_us=(uint32_t)feature_u16(descriptor+18)*1000u;
    channel_scan.hold_us=(uint32_t)feature_u16(descriptor+20)*1000u;
    if(!feature_scan_build()) {feature_stop_scan(false);reason="channel_read_failed";return false;}
    if(!feature_load_key(found)) {feature_stop_scan(false);return false;}
    feature_scan_members();
    if(feature_scan_tg()) {rx_promiscuous=false;rx_tg_filter=true;}
    channel_scan.due_us=hrc_micros()+channel_scan.dwell_us;
    snprintf(channel_label,sizeof channel_label,"%s %.12s",feature_scan_tg() ? "TG SCAN" : "CH SCAN",(const char *)descriptor);return true;
}
static void feature_scan_poll(void) {
    if(!channel_scan.running)return;
    uint32_t now=hrc_micros();
    bool ready=feature_dmr() ? digital_dmr.running : feature_fm() ? analog_fm.running : mon_running;
    if(!ready) {feature_scan_cache.dwelling=false;return;}
    if(!feature_scan_cache.dwelling) {
        feature_scan_cache.dwelling=true;channel_scan.due_us=now+channel_scan.dwell_us;
    }
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    bool signal=feature_dmr() ? radio_dmr_scan_hold(dv)
        : feature_fm() ? analog_fm.have_status && analog_fm.audio_open
        : mon_have_sync && now-mon_sync_us<600000u && monitor.call.state==P25_RX_CLEAR
          && (!rx_tg_filter || (monitor.call.group_valid && feature_scan_group_allows(monitor.call.group)));
    if(!signal && (int32_t)(now-channel_scan.due_us)>=0 && !feature_scan_cache.grace_used
       && feature_scan_cache.ready && feature_scan_has_other()
       && feature_scan_acquiring(now)) {
        feature_scan_cache.grace_used=true;channel_scan.due_us=now+400000u;return;
    }
    if(!radio_scan_due(&channel_scan,now,signal))return;
    // Every listed destination belongs to this receiver configuration. Keep
    // the demodulator, call metadata and speaker alive indefinitely; periodic
    // dwell expiry must not turn a one-carrier scan into self-retuning.
    if(feature_scan_cache.ready && !feature_scan_has_other())return;
    for(unsigned step=1;step<=P25_CS_CHANNELS;++step) {
        unsigned slot=(channel_scan.cursor+step)%P25_CS_CHANNELS;
        if(feature_scan_cache.ready && !p25_cs_map_test(feature_scan_cache.visits,slot))continue;
        if(p25_cs_map_test(feature_scan_cache.listed,slot)) {
            if(feature_load_key(slot)) {
                channel_scan.cursor=(uint16_t)slot;
                feature_scan_members();
                channel_scan.due_us=hrc_micros()+channel_scan.dwell_us;
                snprintf(channel_label,sizeof channel_label,"CH SCAN %.12s",(const char *)feature_scan_cache.descriptor);
            } else {feature_stop_scan(true);reason="channel_read_failed";}
            return;
        }
    }
    feature_stop_scan(true);
}
static bool feature_keys(uint32_t keys) {
    uint32_t now=hrc_micros(),other=keys&~ptt_mask;
    bool down=(keys&ptt_mask)!=0;
    if(other!=light_keys || down)radio_ux_activity(&radio_lights,now,other!=0);
    light_keys=other;
    if(!lock_mask)for(unsigned i=0;i<board.keymap_len;++i) {
        if(board.keymap[i].short_action==ACT_QUICK)lock_mask|=1u<<board.keymap[i].bit;
        if(board.keymap[i].short_action==ACT_SELECT)lock_select_mask|=1u<<board.keymap[i].bit;
    }
    bool chord=lock_mask && lock_select_mask && (keys&lock_mask) && (keys&lock_select_mask);
    bool toggled=radio_ux_lock_chord(&radio_lights,now,chord,other!=0,!down && !call_active && !prepared);
    if(toggled) {
        editing=menu_open=rx_lab=false;edit_from_menu=diag_from_menu=false;digit_count=0;
        reason=radio_lights.locked ? "keypad_locked" : "listening";home_hint_refresh();
    }
    return !radio_lights.locked && !radio_lights.consume_release && !chord;
}
static void feature_lights(void) {
    uint32_t now=hrc_micros();
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    bool receiving=feature_dmr() ? dv && dv->state==DMR_CALL_STATE_RX
        : feature_fm() ? analog_fm.audio_open : mon_running && mon_have_sync && now-mon_sync_us<400000u;
    if(receiving)radio_ux_rx_activity(&radio_lights,now);
    radio_ux_idle(&radio_lights,now,call_active);
    uint8_t screen_level=radio_lights.screen_on ? 80 : 0,key_level=(uint8_t)radio_lights.keypad_on;
    if(screen_level!=light_screen_level && board.display && board.display->set_backlight) {
        board.display->set_backlight(screen_level);light_screen_level=screen_level;
    }
    if(key_level!=light_key_level) {hrc_pin_write(PIN_KEY_BACKLIGHT,key_level!=0);light_key_level=key_level;}
}
static subtone_t feature_tone(unsigned offset) {
    uint16_t packed=feature_u16(channel_record+offset);
    return (subtone_t){.type=(uint8_t)(packed>>14),.value=(uint16_t)(packed&0x3fffu)};
}
static void feature_tone_label(unsigned offset,char *line,size_t n) {
    subtone_t tone=feature_tone(offset);
    if(tone.type==TONE_NONE)snprintf(line,n,"None");
    else if(tone.type==TONE_CTCSS)snprintf(line,n,"CTCSS %u.%u Hz",tone.value/10u,tone.value%10u);
    else snprintf(line,n,"DCS %03o%s",tone.value,tone.type==TONE_DCS_INV ? " I" : " N");
}
static void feature_fm_tick(bool down,bool was_down) {
    bool home=!menu_open && !editing && !rx_lab && !rx_job && !cps_link && !cps_active;
    if(!normal_mode || !feature_fm() || !mon_enabled || !frequency || !home) {
        if(analog_fm.owned && !analog_fm.transmitting)p25_fm_stop(&analog_fm);
        return;
    }
    if(mon_running)mon_stop("analog_fm");
    if(!analog_fm.owned && control.state!=RADIO_FAULT) {
        p25_fm_config config={.rx_hz=frequency,.tx_hz=control.tx_frequency,
            .bandwidth=(channel_record[12]&32u) ? RADIO_BW_25K : RADIO_BW_12K5,
            .rx_tone=feature_tone(28),.tx_tone=feature_tone(26),
            .squelch=channel_record[30],.volume=100,.power=(uint8_t)feature_tx_power()};
        if(!feature_tx_settings_valid() || !p25_fm_start(&analog_fm,board.radio,board.audio,&config,hrc_micros())
           || !p25_fm_set_tot_seconds(&analog_fm,feature_tx_tot())) {
            reason="fm_setup_failed";radio_complete(&control,true);normal_permission();screen("HOME");return;
        }
        reason="listening";radio_receive_state(&control,true,true,false,false);screen("HOME");
    }
    if(ptt_start_requested(down,was_down) && radio_request_tx(&control,down,was_down,true)) {
        feature_stop_scan(true);screen("VOICE CALL");
        if(hrc_pin_read(PIN_PTT)) {
            radio_complete(&control,false);normal_permission();reason="released_before_rf";
            ptt_release_required=true;ptt_release_seen=false;screen("HOME");return;
        }
        hrc7000_set_mic_gain(dev,11); // Restore the native analog path's verified gain.
        call_active=hardware_running=true;control.cancel=false;
        if(!hard_guard_arm(feature_tx_tot()+2u)) {hardware_stop();call_active=false;return;}
        if(!p25_fm_tx_begin(&analog_fm,hrc_micros()) || !hardware_running) {
            hardware_stop();call_active=false;p25_fm_stop(&analog_fm);
            reason="fm_tx_failed";radio_complete(&control,true);normal_permission();return;
        }
        control.state=RADIO_TX_VOICE;reason="voice_call";
    }
    bool was_tx=analog_fm.transmitting,was_audio=analog_fm.audio_open;
    if(analog_fm.transmitting && (!down || control.cancel || !call_active))p25_fm_tx_end(&analog_fm,hrc_micros());
    p25_fm_poll(&analog_fm,hrc_micros());
    if(was_tx && !analog_fm.transmitting) {
        bool timeout=analog_fm.timed_out || !strcmp(reason,"hard_timeout");
        hrc_timer_stop(HARD_TIMER);hardware_stop();call_active=false;control.cancel=false;
        if(timeout) {ptt_release_required=true;ptt_release_seen=false;}
        radio_complete(&control,false);reason=timeout ? "time_limit" : "listening";
        normal_permission();radio_receive_state(&control,true,true,false,false);screen("HOME");
    }
    if(!analog_fm.transmitting) {
        radio_receive_state(&control,true,analog_fm.running,analog_fm.audio_open,analog_fm.audio_open);
        if(was_audio!=analog_fm.audio_open)screen("HOME");
        board.power->led(LED_GREEN,analog_fm.audio_open);
    }
}
static bool feature_hex(const char *text,uint8_t *out,unsigned bytes) {
    if(strlen(text)!=bytes*2u)return false;
    for(unsigned i=0;i<bytes;++i) {
        unsigned v=0;
        for(unsigned j=0;j<2;++j) {char c=text[i*2+j];unsigned n=c>='0'&&c<='9' ? (unsigned)(c-'0') : c>='A'&&c<='F' ? (unsigned)(c-'A'+10) : c>='a'&&c<='f' ? (unsigned)(c-'a'+10) : 16u;if(n>15)return false;v=(v<<4)|n;}
        out[i]=(uint8_t)v;
    }
    return true;
}
static bool feature_number(const char *text,unsigned base,unsigned exact_digits,bool nonzero,uint32_t *out) {
    size_t count=strlen(text);if(!count || (exact_digits && count!=exact_digits) || count>10u)return false;
    uint32_t value=0;
    for(size_t i=0;i<count;++i) {
        char c=text[i];unsigned n=c>='0' && c<='9' ? (unsigned)(c-'0') : c>='A' && c<='F' ? (unsigned)(c-'A'+10) : c>='a' && c<='f' ? (unsigned)(c-'a'+10) : 16u;
        if(n>=base || value>(UINT32_MAX-n)/base)return false;
        value=value*base+n;
    }
    if(nonzero && !value)return false;
    *out=value;return true;
}
static bool feature_image_bands(void) {
    uint8_t record[32];
    for(unsigned i=0;i<P25_CS_GLOBAL;++i) {
        if(!p25_cs_stage_read(&channel_store,i,record))return false;
        if((record[12]&1u) && (radio_functions_get_power(record)>=board.power_count || !channel_in_band(pref_get(record),false)
           || (!(record[12]&16u) && !channel_in_band(pref_get(record+4),true))))return false;
    }
    return true;
}
static void feature_cps_error(const char *code) {char line[48];snprintf(line,sizeof line,"CPS ERR %s\r\n",code);send(line);}
static bool feature_cps(bool down) {
    if(strncmp(command,"CPS ",4))return false;
    char line[120],extra;unsigned key;uint32_t tid,revision,crc;uint8_t record[32];
    char tid_text[10],revision_text[12],crc_text[10];
    if(call_active || prepared || hardware_running || audio_on || rx_job || rx_sampling || down || !hrc_pin_read(PIN_PTT)) {feature_cps_error("BUSY");return true;}
    if(!features_ready) {feature_cps_error("STORAGE");return true;}
    if(!strcmp(command,"CPS HELLO")) {
        if(cps_active) {feature_cps_error("TRANSACTION");return true;}
        feature_stop_scan(true);feature_pause();preferences_poll(false);
        cps_link=true;cps_activity_us=hrc_micros();
        uint32_t check=0;
        if(!p25_cs_stage_crc(&channel_store,&check)) {feature_cps_error("STORAGE");return true;}
        screen("HOME");snprintf(line,sizeof line,"CPS HELLO DM32P25 4 256 2 %lu %08lX\r\n",(unsigned long)channel_store.revision,(unsigned long)check);send(line);return true;
    }
    if(sscanf(command,"CPS GET %u %c",&key,&extra)==1) {
        if(key>=P25_CS_RECORDS || !p25_cs_read(&channel_store,key,record)) {feature_cps_error("RECORD");return true;}
        int n=snprintf(line,sizeof line,"CPS DATA %u ",key);
        for(unsigned i=0;i<32;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02X",record[i]);
        cps_activity_us=hrc_micros();snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);return true;
    }
    if(sscanf(command,"CPS BEGIN %9s %11s %c",tid_text,revision_text,&extra)==2) {
        if(!feature_number(tid_text,16,8,true,&tid) || !feature_number(revision_text,10,0,false,&revision)) {feature_cps_error("TRANSACTION");return true;}
        feature_stop_scan(true);feature_pause();
        if(cps_active || !p25_cs_begin(&channel_store,(uint32_t)revision)) {feature_cps_error("REVISION");return true;}
        cps_active=cps_link=true;cps_transaction=(uint32_t)tid;cps_activity_us=hrc_micros();
        snprintf(line,sizeof line,"CPS OK BEGIN %08lX\r\n",(unsigned long)tid);send(line);return true;
    }
    if(!cps_active) {feature_cps_error("TRANSACTION");return true;}
    char encoded_record[65];
    if(sscanf(command,"CPS PUT %9s %u %64s %c",tid_text,&key,encoded_record,&extra)==3) {
        if(!feature_number(tid_text,16,8,true,&tid) || tid!=cps_transaction || key>=P25_CS_RECORDS || !feature_hex(encoded_record,record,32)) {feature_cps_error("RECORD");return true;}
        if(!p25_cs_stage_write(&channel_store,key,record)) {feature_cps_error("INVALID");return true;}
        cps_activity_us=hrc_micros();snprintf(line,sizeof line,"CPS OK PUT %08lX %u\r\n",(unsigned long)tid,key);send(line);return true;
    }
    if(sscanf(command,"CPS ABORT %9s %c",tid_text,&extra)==1 && feature_number(tid_text,16,8,true,&tid) && tid==cps_transaction) {
        p25_cs_abort(&channel_store);cps_active=cps_link=false;
        screen("HOME");
        snprintf(line,sizeof line,"CPS OK ABORT %08lX\r\n",(unsigned long)tid);send(line);return true;
    }
    if(sscanf(command,"CPS COMMIT %9s %9s %c",tid_text,crc_text,&extra)==2 && feature_number(tid_text,16,8,true,&tid)
       && tid==cps_transaction && feature_number(crc_text,16,8,false,&crc)) {
        if(!feature_image_bands() || !p25_cs_commit(&channel_store,crc)) {feature_cps_error("COMMIT");return true;}
        cps_active=false;preferences_restore();(void)normal_resume();screen("HOME");
        snprintf(line,sizeof line,"CPS OK COMMIT %08lX %lu %08lX\r\n",(unsigned long)tid,(unsigned long)channel_store.revision,(unsigned long)crc);send(line);return true;
    }
    feature_cps_error("COMMAND");return true;
}
#endif
