// SPDX-License-Identifier: GPL-3.0-or-later
// Finite microphone bring-up: no tune, tx, flash write or speaker routing.
#include "imbe_mic.h"
#include "imbe_mic_queue.h"
#include "imbe_bench.h"
#include "p25_live_frame.h"
#include "board.h"
#include "platform.h"
#include "pins.h"
#include "audio_pcm.h"
#include "dmr_glue.h"
#include <stdio.h>
static imbe_mic_queue queue;
static uint8_t payloads[MIC_FRAMES+MIC_PAD][11];
static unsigned encoded, max_encode_us;
static uint32_t begun, hash, driver_overruns;
static uint32_t ldu_hash, max_pack_us;
static unsigned ldus;
static bool initialized, active, audio_on, done;
static bool waiting;
static uint32_t capture_at;
static hrc7000_t *mic_modem;
static uint32_t capture_mode, capture_audio, capture_adc_ctl, capture_txrx;
static uint8_t capture_adc, capture_aicr, capture_mic2, capture_gain, capture_mix;
static const char *reason="idle";
// Do not create the normal DMR engine or its TX interrupt handlers.
void __wrap_hrc_dmr_board_init(hrc7000_t *m,const hrc_dmr_board_t *hooks) { mic_modem=m; (void)hooks; }
static void capture_snapshot(void) {
    capture_mode=hrc7000_rd(mic_modem,C7_WORK_MODE);
    capture_audio=hrc7000_rd(mic_modem,C7_AUDIO_CONTROL);
    capture_adc_ctl=hrc7000_rd(mic_modem,C7_ADC_CONTROL);
    capture_txrx=hrc7000_rd(mic_modem,C7_LAYER2_TXRX_CTRL);
    capture_adc=hrc7000_codec_rd(mic_modem,C7_CODEC_CR_ADC);
    capture_aicr=hrc7000_codec_rd(mic_modem,C7_CODEC_AICR_ADC);
    capture_mic2=hrc7000_codec_rd(mic_modem,C7_CODEC_CR_MIC2);
    capture_gain=hrc7000_codec_rd(mic_modem,C7_CODEC_GCR_ADCL);
    capture_mix=hrc7000_codec_rd(mic_modem,C7_CODEC_CR_MIX);
}
static void send(const char *s) { board.host_port->write((const uint8_t *)s,strlen(s)); }
static void capture(const int16_t *pcm,int16_t *speaker,void *ctx) {
    (void)ctx; memset(speaker,0,320);
    uint32_t lock=hrc_irq_save();
    mic_queue_push(&queue,pcm,hrc_micros());
    hrc_irq_restore(lock);
}
static void audio_stop(void) {
    if (audio_on) { board.audio->stop(); audio_on=false; }
    if (mic_modem) {
        hrc7000_wr(mic_modem,C7_LAYER2_TXRX_CTRL,0);
        hrc7000_wr(mic_modem,C7_WORK_MODE,C7_WORK_MODE_FM);
    }
    board_rf_safe();
}
void imbe_mic_stop(void) {
    uint32_t lock=hrc_irq_save(); queue.accepting=false; hrc_irq_restore(lock);
    audio_stop(); active=false; waiting=false;
    if (!done && (!strcmp(reason,"running") || !strcmp(reason,"waiting"))) reason="cancelled";
}
static bool begin_capture(void) {
    begun=hrc_micros(); reason="running"; queue.accepting=true;
    audio_on=board.audio->start(capture,NULL);
    capture_snapshot();
    if (!audio_on) { reason="audio_start"; imbe_mic_stop(); return false; }
    return true;
}
static bool start_mode(uint32_t mode,bool delayed) {
    if (active || !board.audio || !board.radio) return false;
    board_rf_safe();
    if (!initialized) { board.radio->init(); initialized=true; }
    if (!mic_modem) return false;
    board_rf_safe(); board.radio->audio(false);
    // Only the modem work mode varies. No board set_mode(), tune or TX calls:
    // those bring up the DMR engine/PA path. Keep both layer-2 and PIC RF gates off.
    hrc_irq_enable(IRQ_MODEM_SYS,false);
    hrc_irq_enable(IRQ_MODEM_TS_TX,false); hrc_irq_enable(IRQ_MODEM_TS_RX,false);
    hrc_irq_enable(IRQ_MODEM_RF_TX,false); hrc_irq_enable(IRQ_MODEM_RF_RX,false);
    hrc7000_wr(mic_modem,C7_SYS_INTERP_MASK,0);
    hrc7000_wr(mic_modem,C7_LAYER2_TXRX_CTRL,0);
    hrc7000_wr(mic_modem,C7_LAYER2_CONTROL,0xc0);
    hrc7000_wr(mic_modem,C7_FM_PTT,0);
    hrc7000_wr(mic_modem,C7_WORK_MODE,C7_WORK_MODE_FM);
    if (mode!=C7_WORK_MODE_FM) hrc7000_wr(mic_modem,C7_WORK_MODE,mode);
    hrc_pin_write(PIN_MIC_PATH,false); // mic into the modem codec, not analog FM
    imbe_bench_init();
    memset(&queue,0,sizeof queue); memset(payloads,0,sizeof payloads);
    encoded=max_encode_us=driver_overruns=0; hash=2166136261u; done=false;
    ldus=max_pack_us=0; ldu_hash=2166136261u;
    hrc_audio_pcm_reset_stats();
    active=true; waiting=delayed;
    if (delayed) {
        capture_at=hrc_micros()+20000000u; reason="waiting";
        capture_snapshot(); return true;
    }
    return begin_capture();
}
bool imbe_mic_start(void) { return start_mode(C7_WORK_MODE_FM,false); }
bool imbe_mic_start_digital(void) { return start_mode(C7_WORK_MODE_DMR,false); }
bool imbe_mic_start_delayed(void) { return start_mode(C7_WORK_MODE_DMR,true); }
// Exact mode used by the scanner-verified variant-1 P25 PHY transmitter.
// Keep layer-2 timing, RF requests and PA disabled for this PCM-only check.
bool imbe_mic_start_phy_delayed(void) { return start_mode(0x02u,true); }
unsigned imbe_mic_wait_seconds(void) {
    if (!active || !waiting) return 0;
    int32_t left=(int32_t)(capture_at-hrc_micros());
    return left>0 ? ((uint32_t)left+999999u)/1000000u : 0;
}
bool imbe_mic_poll(void) {
    if (!active) return false;
    if (waiting) {
        if ((int32_t)(hrc_micros()-capture_at)<0) return true;
        waiting=false;
        return begin_capture(); // Watchdog starts with PCM, not with the countdown.
    }
    uint32_t blocks,under;
    hrc_audio_pcm_stats(&blocks,&driver_overruns,&under);
    (void)blocks; (void)under;
    if (driver_overruns || queue.overflow || hrc_micros()-begun>8000000u) {
        reason=driver_overruns ? "driver_overrun" : queue.overflow ? "queue_overflow" : "timeout";
        imbe_mic_stop(); return false;
    }
    int16_t pcm[160];
    uint32_t lock=hrc_irq_save();
    bool have=mic_queue_pop(&queue,pcm), finished=queue.captured==MIC_FRAMES;
    hrc_irq_restore(lock);
    if (finished) audio_stop();
    if (!have && finished && encoded<MIC_FRAMES+MIC_PAD) { memset(pcm,0,sizeof pcm); have=true; }
    if (have) {
        uint32_t start=hrc_micros();
        imbe_bench_encode_pcm(pcm,payloads[encoded]);
        uint32_t elapsed=hrc_micros()-start;
        if (elapsed>max_encode_us) max_encode_us=elapsed;
        for (unsigned i=0;i<11;++i) hash=(hash^payloads[encoded][i])*16777619u;
        ++encoded;
        if (encoded%9u==0) {
            uint8_t ldu[216];
            start=hrc_micros();
            p25_live_ldu(ldu,(const uint8_t (*)[11])&payloads[encoded-9u],(ldus&1u)!=0);
            elapsed=hrc_micros()-start;
            if (elapsed>max_pack_us) max_pack_us=elapsed;
            for(unsigned i=0;i<sizeof ldu;++i) ldu_hash=(ldu_hash^ldu[i])*16777619u;
            ++ldus;
        }
    }
    if (encoded==MIC_FRAMES+MIC_PAD) { done=true; reason="complete"; imbe_mic_stop(); }
    return active;
}
void imbe_mic_status(void) {
    char line[320];
    uint32_t lock=hrc_irq_save();
    unsigned captured=queue.captured, count=queue.count, high=queue.high, ov=queue.overflow;
    unsigned peak=queue.peak, clipped=queue.clipped;
    uint64_t sum=queue.sum_abs;
    uint32_t span=queue.last_us-queue.first_us;
    hrc_irq_restore(lock);
    snprintf(line,sizeof line,"MIC git=%s running=%u captured=%u encoded=%u pcm=%u high=%u overflow=%u driver_overruns=%lu done=%u reason=%s peak=%u mean_abs=%lu clipped=%u span_us=%lu max_encode_us=%u hash=%08lx rf=disabled\r\n",
        BENCH_GIT,(unsigned)active,captured,encoded,count,high,ov,(unsigned long)driver_overruns,
        (unsigned)done,reason,peak,(unsigned long)(captured ? sum/(captured*160u) : 0),clipped,
        (unsigned long)span,max_encode_us,(unsigned long)hash);
    send(line);
    snprintf(line,sizeof line,"MIC_HW snapshot=start mode=%08lx audio=%08lx adc_ctl=%08lx txrx=%08lx cr_adc=%02x aicr_adc=%02x mic2=%02x gain=%02x mix=%02x\r\n",
        (unsigned long)capture_mode,(unsigned long)capture_audio,(unsigned long)capture_adc_ctl,
        (unsigned long)capture_txrx,(unsigned)capture_adc,(unsigned)capture_aicr,(unsigned)capture_mic2,
        (unsigned)capture_gain,(unsigned)capture_mix);
    send(line);
    snprintf(line,sizeof line,"MIC_FRAMING ldus=%u max_pack_us=%lu hash=%08lx sink=none\r\n",
        ldus,(unsigned long)max_pack_us,(unsigned long)ldu_hash);
    send(line);
}
void imbe_mic_dump(void) {
    if (active || !done) { send("ERR MIC dump requires completed capture\r\n"); return; }
    char line[64];
    for (unsigned f=0;f<MIC_FRAMES+MIC_PAD;++f) {
        int n=snprintf(line,sizeof line,"MIC_DATA %u ",f);
        for (unsigned i=0;i<11;++i) n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x",payloads[f][i]);
        snprintf(line+n,sizeof line-(unsigned)n,"\r\n"); send(line);
    }
    send("OK MIC_DUMP\r\n");
}
