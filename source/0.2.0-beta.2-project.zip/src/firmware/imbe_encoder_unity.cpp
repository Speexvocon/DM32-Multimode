// SPDX-License-Identifier: GPL-3.0-or-later
// Compile the unchanged encoder and its fixed-point helpers together so GCC
// can inline arithmetic in inner loops without LTO or hand-rewritten math.
// Original source copyright/license notices remain in the included files.
#include "basicop2.cc"
#include "math_sub.cc"
#include "aux_sub.cc"
#include "dsp_sub.cc"
#include "dc_rmv.cc"
#include "pe_lpf.cc"
#ifdef IMBE_PITCH_SPECIALIZE
#include "imbe_pitch_specialized.cc"
#else
#include "pitch_est.cc"
#endif
#include "pitch_ref.cc"
#include "v_uv_det.cc"
#include "qnt_sub.cc"
#include "sa_encode.cc"
#include "ch_encode.cc"
#ifdef IMBE_STAGE_PROFILE
#include "imbe_encode_profile.cc"
#else
#include "encode.cc"
#endif
