// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_PREFERENCES_H
#define P25_PREFERENCES_H
#include "hal_flash.h"
#include <string.h>
#define PREF_MAGIC 0x50353250u
#define PREF_SLOT 64u
#define PREF_VERSION 3u
// Explicit little-endian, versioned records; commit word is programmed last.
typedef struct { uint32_t rx,tx,nac,tg,id,split,mic_db,tx_inhibit,prom_mode; } p25_preferences;
typedef struct { const hal_flash_t *flash; uint32_t seq,slot; bool have,writable; } p25_pref_store;
static inline uint32_t pref_get(const uint8_t *p) {return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static inline void pref_put(uint8_t *p,uint32_t n) {for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(n>>(8*i));}
static inline uint32_t pref_crc(const uint8_t *p,unsigned n) {
 uint32_t c=~0u;while(n--) {c^=*p++;for(unsigned j=0;j<8;++j)c=(c>>1)^((0u-(c&1u))&0xedb88320u);}return ~c;
}
static inline bool pref_blank(const uint8_t *p) {for(unsigned i=0;i<PREF_SLOT;++i)if(p[i]!=255)return false;return true;}
static inline bool pref_version(uint32_t version) {return version==1 || version==2 || version==PREF_VERSION;}
static inline bool pref_values(const p25_preferences *p) {
 return p->rx>=100000000 && p->rx<=520000000 && p->tx>=100000000 && p->tx<=520000000 && p->nac<=4095 && p->tg && p->tg<=65535 && p->id && p->id<=0xffffff && p->split<=1 && p->mic_db<=42 && p->tx_inhibit<=1 && p->prom_mode<=1 && (p->split || p->rx==p->tx);
}
static inline void pref_pack(uint8_t *b,const p25_preferences *p,uint32_t seq) {
 memset(b,0,PREF_SLOT);pref_put(b,PREF_MAGIC);pref_put(b+4,PREF_VERSION);pref_put(b+8,seq);
 pref_put(b+12,p->rx);pref_put(b+16,p->tx);pref_put(b+20,p->nac);pref_put(b+24,p->tg);pref_put(b+28,p->id);pref_put(b+32,p->split);pref_put(b+36,p->mic_db);
 pref_put(b+40,p->tx_inhibit);pref_put(b+44,p->prom_mode);
 pref_put(b+56,pref_crc(b,56));pref_put(b+60,0);
}
static inline bool pref_unpack(const uint8_t *b,p25_preferences *p) {
 uint32_t version=pref_get(b+4);
 if(pref_get(b)!=PREF_MAGIC || !pref_version(version) || pref_get(b+60) || pref_get(b+56)!=pref_crc(b,56))return false;
 if(version==3 && (pref_get(b+48) || pref_get(b+52)))return false;
 p->rx=pref_get(b+12);p->tx=pref_get(b+16);p->nac=pref_get(b+20);p->tg=pref_get(b+24);p->id=pref_get(b+28);p->split=pref_get(b+32);p->mic_db=pref_get(b+36);
 // Legacy records use normal TX and filtered RX defaults; loading never writes.
 p->tx_inhibit=version==1 ? 0u : pref_get(b+40);
 p->prom_mode=version<3 ? 0u : pref_get(b+44);return pref_values(p);
}
static inline bool pref_geometry(const hal_flash_t *f) {
 // This overlay owns only the DM32's designated settings ring, never calibration.
 return f && f->map && f->read && f->write && f->erase && f->erase_size==4096 && f->size>=0x719000 && f->map->settings_addr==0x711000 && f->map->settings_size==0x8000;
}
static inline bool pref_load(p25_pref_store *s,const hal_flash_t *f,p25_preferences *out) {
 memset(s,0,sizeof *s);s->flash=f;if(!pref_geometry(f))return false;s->writable=true;
 uint8_t b[PREF_SLOT];p25_preferences p;
 for(uint32_t i=0;i<f->map->settings_size/PREF_SLOT;++i) {
  if(!f->read(f->map->settings_addr+i*PREF_SLOT,b,sizeof b)) {s->writable=false;return false;}
  if(pref_blank(b))continue;
  // Never claim foreign/unknown-version data. Torn records with our header are skipped.
  if(pref_get(b)!=PREF_MAGIC || !pref_version(pref_get(b+4)))s->writable=false;
  if(pref_unpack(b,&p) && (!s->have || (int32_t)(pref_get(b+8)-s->seq)>0)) {s->have=true;s->seq=pref_get(b+8);s->slot=i;*out=p;}
 }
 return s->have;
}
static inline bool pref_save(p25_pref_store *s,const p25_preferences *p) {
 const hal_flash_t *f=s->flash;if(!s->writable || !pref_geometry(f) || !pref_values(p))return false;
 uint8_t b[PREF_SLOT],verify[PREF_SLOT];uint32_t count=f->map->settings_size/PREF_SLOT,next=s->have ? (s->slot+1)%count : 0;
 bool found=false;
 for(uint32_t n=0;n<count;++n) {
  uint32_t i=(next+n)%count;if(!f->read(f->map->settings_addr+i*PREF_SLOT,b,sizeof b))return false;
  if(pref_blank(b)) {next=i;found=true;break;}
 }
 if(!found) {
  if(!s->have)return false;
  next=((s->slot/64+1)%8)*64; // never erase the sector holding the latest record
  if(!f->erase(f->map->settings_addr+next*PREF_SLOT))return false;
 }
 uint32_t addr=f->map->settings_addr+next*PREF_SLOT;
 pref_pack(b,p,s->seq+1);
 if(!f->write(addr,b,60) || !f->read(addr,verify,60) || memcmp(b,verify,60))return false;
 if(!f->write(addr+60,b+60,4) || !f->read(addr,verify,64) || memcmp(b,verify,64))return false;
 s->seq++;s->slot=next;s->have=true;return true;
}
#endif
