// SPDX-License-Identifier: GPL-3.0-or-later
// Hardware-independent ownership for the first unified, TX-capable radio.
#ifndef RADIO_CONTROL_H
#define RADIO_CONTROL_H
#include <stdbool.h>
#include <stdint.h>
typedef enum { RADIO_RX_UNAVAILABLE, RADIO_TX_PREPARE, RADIO_TX_VOICE,
               RADIO_TX_DRAIN, RADIO_FAULT, RADIO_RX_IDLE, RADIO_RX_SYNC,
               RADIO_RX_VOICE, RADIO_RX_RESTORE, RADIO_RX_PAUSED } radio_state;
typedef struct {
    uint32_t frequency, tx_frequency;
    uint32_t nac, talkgroup, source_id;
    bool split;
    volatile bool tx_enabled;
    radio_state state;
    bool inhibit, cancel;
} radio_control;
static inline bool radio_busy(const radio_control *r) {
    return r->state==RADIO_TX_PREPARE || r->state==RADIO_TX_VOICE || r->state==RADIO_TX_DRAIN;
}
static inline bool radio_configure(radio_control *r,uint32_t hz,bool valid) {
    if(!valid || radio_busy(r)) return false;
    r->frequency=hz;
    if(!r->split) r->tx_frequency=hz;
    r->tx_enabled=!r->inhibit && r->state!=RADIO_FAULT;
    return true;
}
static inline bool radio_request_tx(radio_control *r,bool down,bool was_down,bool available) {
    if(!down || was_down || !available || r->inhibit || !r->tx_enabled
       || radio_busy(r) || r->state==RADIO_FAULT) return false;
    r->cancel=false; r->state=RADIO_TX_PREPARE; return true;
}
static inline void radio_complete(radio_control *r,bool fault) {
    r->cancel=false;
    r->state=fault ? RADIO_FAULT : RADIO_RX_UNAVAILABLE;
    if(fault) r->tx_enabled=false;
}
static inline void radio_inhibit(radio_control *r,bool inhibit) {
    r->inhibit=inhibit;
    r->tx_enabled=!inhibit && r->frequency && r->state!=RADIO_FAULT;
}
static inline void radio_receive_state(radio_control *r,bool enabled,bool running,bool sync,bool voice) {
    if(radio_busy(r) || r->state==RADIO_FAULT)return;
    r->state=!enabled ? RADIO_RX_UNAVAILABLE : !running ? RADIO_RX_RESTORE
             : voice ? RADIO_RX_VOICE : sync ? RADIO_RX_SYNC : RADIO_RX_IDLE;
}
#endif
