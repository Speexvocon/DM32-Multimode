// SPDX-License-Identifier: GPL-3.0-or-later
// Independent one-second hardware-IRQ countdown. Never waits on a radio task.
#ifndef RADIO_TX_GUARD_H
#define RADIO_TX_GUARD_H
#include <stdbool.h>
#include <stdint.h>
#define RADIO_TX_GUARD_PERIOD_US 1000000u
#define RADIO_TX_GUARD_MAX_SECONDS 610u
typedef struct { volatile uint16_t remaining; } radio_tx_guard;
static inline void radio_tx_guard_stop(radio_tx_guard *g) { g->remaining=0; }
static inline bool radio_tx_guard_start(radio_tx_guard *g,unsigned seconds) {
    if(!seconds || seconds>RADIO_TX_GUARD_MAX_SECONDS) {radio_tx_guard_stop(g);return false;}
    g->remaining=(uint16_t)seconds;return true;
}
// True once on expiry. A spurious interrupt while disarmed does nothing.
static inline bool radio_tx_guard_tick(radio_tx_guard *g) {
    if(!g->remaining)return false;
    --g->remaining;return g->remaining==0;
}
#endif
