// SPDX-License-Identifier: GPL-3.0-or-later
// Private C fragment for generate-drained-audio.py's pinned native PCM host.
// Included after the native microphone ISR, with that host's queue/state in
// scope. No codec or board routing runs in the consumed-buffer ISR.
#ifndef RADIO_PCM_OUTPUT_H
#define RADIO_PCM_OUTPUT_H
#ifndef HRC_AUDIO_PCM_OUTPUT_WINDOW
#define HRC_AUDIO_PCM_OUTPUT_WINDOW ((volatile uint8_t *)C7_PCM_SPK_ADDR)
#endif
#define OUTPUT_HALF 80u
#define OUTPUT_PREFILL (2u * AUDIO_BLOCK_SAMPLES)
#define OUTPUT_TIMEOUT_US 30000u
_Static_assert(AUDIO_BLOCK_SAMPLES == 2u * OUTPUT_HALF && C7_PCM_SAMPLES == OUTPUT_HALF,
               "native speaker output requires two 80-sample halves per block");
static volatile uint32_t output_epoch;
static uint32_t worker_epoch, output_last_irq_us;
static volatile bool output_pending, output_wanted, output_starved;
static volatile bool output_blocked = true;

static unsigned speaker_output_queued(void)
{
    unsigned ready = (spk_head + SPK_BLOCKS - spk_tail) % SPK_BLOCKS;
    return ready * AUDIO_BLOCK_SAMPLES - spk_pos;
}

// Called with interrupts masked, or by the non-nesting PCM consumed ISR.
static void speaker_output_disable(void)
{
    hrc_irq_enable(IRQ_PCM_RD, false);
    hrc7000_audio_bits(modem, 0, C7_AUDIO_PCM_SPK);
    hrc7000_wr(modem, C7_INTERP_CLEAR, C7_INT_PCM_RD);
    output_pending = false;
}

static void speaker_output_cancel(void)
{
    // Submitted but unacknowledged samples are included in cancellation; the
    // peripheral does not expose how much of its current half already played.
    audio_diag.output_discarded += speaker_output_queued() + (output_pending ? OUTPUT_HALF : 0u);
    speaker_output_disable();
    spk_head = spk_tail = spk_pos = 0;
    output_starved = false;
}

static void speaker_output_load(void)
{
    volatile uint8_t *window = HRC_AUDIO_PCM_OUTPUT_WINDOW;
    const int16_t *samples = &spk_q[spk_tail][spk_pos];
    for (unsigned i = 0; i < OUTPUT_HALF; ++i) {
        uint16_t sample = (uint16_t)samples[i];
        window[2u*i] = (uint8_t)sample;
        window[2u*i+1u] = (uint8_t)(sample >> 8);
    }
    hrc_barrier();
    spk_pos = (uint8_t)(spk_pos + OUTPUT_HALF);
    if (spk_pos == AUDIO_BLOCK_SAMPLES) {
        spk_pos = 0;
        spk_tail = (uint8_t)((spk_tail + 1u) % SPK_BLOCKS);
    }
    audio_diag.output_submitted += OUTPUT_HALF;
    output_pending = true;
}

static void isr_pcm_rd(void)
{
    hrc7000_wr(modem, C7_INTERP_CLEAR, C7_INT_PCM_RD);
    if (!running || stopping || output_blocked || fifo_held || !spk_routed || !output_pending) {
        speaker_output_disable();
        return;
    }
    uint32_t now = hal_micros(), gap = now - output_last_irq_us;
    if (gap > audio_diag.output_irq_gap_max_us) audio_diag.output_irq_gap_max_us = gap;
    output_last_irq_us = now;
    ++audio_diag.output_irqs;
    audio_diag.output_consumed += OUTPUT_HALF;
    output_pending = false;
    if (speaker_output_queued() >= OUTPUT_HALF) speaker_output_load();
    else {
        speaker_output_disable();
        if (output_wanted) {
            ++audio_diag.output_starvations;
            output_starved = true;
        }
    }
    if (task != NULL) {
        BaseType_t woken = pdFALSE;
        vTaskNotifyGiveFromISR(task, &woken);
        portYIELD_FROM_ISR(woken);
    }
}

void hrc_audio_pcm_output_abort(void)
{
    uint32_t s = hrc_irq_save();
    ++output_epoch;
    output_blocked = true;
    // Keep the logical RX request for a board-level PTT refusal: AMBE may not
    // emit another speaker-on edge for that still-live call. Stop clears it.
    speaker_output_cancel();
    hrc_irq_restore(s);
    // The native worker is the sole route-on/drain writer. Join it before the
    // controller's immediate route-off, so a preempted board hook cannot turn
    // the amplifier back on after this API returns. No board SPI is IRQ-locked.
    if (xTaskGetCurrentTaskHandle() != task)
        while (worker_active) vTaskDelay(1);
    s = hrc_irq_save();
    bool off = spk_routed;
    spk_routed = false;
    hrc_irq_restore(s);
    if (off && speaker_pcm_cb != NULL) speaker_pcm_cb(false);
}

void hrc_audio_pcm_output_resume(void)
{
    uint32_t s = hrc_irq_save();
    ++output_epoch;
    output_blocked = false;
    hrc_irq_restore(s);
    // The next microphone notification services the preserved logical route.
    // Never run a competing controller-task board hook here.
}

static void speaker_output_service(void)
{
    bool off = false;
    uint32_t s = hrc_irq_save();
    if (!running || stopping || output_blocked || fifo_held) {
        hrc_irq_restore(s);
        return;
    }
    if (!spk_routed && output_wanted) {
        hrc_irq_restore(s);
        if (speaker_pcm_cb != NULL) speaker_pcm_cb(true);
        s = hrc_irq_save();
        // Record the physical hook even if a controller closed admission
        // during it; abort/stop wait for this worker before their final off.
        spk_routed = true;
        if (!running || stopping || output_blocked || fifo_held) {
            hrc_irq_restore(s);
            return;
        }
    }
    if (!spk_routed) { hrc_irq_restore(s); return; }
    // Board routing/TX-off may restore RING: never play both sources.
    hrc7000_audio_bits(modem, 0, C7_AUDIO_RING_PLAY | C7_AUDIO_FM_PLAY);
    uint32_t now = hal_micros();
    if (output_pending && now - output_last_irq_us > OUTPUT_TIMEOUT_US) {
        ++audio_diag.output_timeouts;
        // An unacknowledged hardware half makes the queued tail's playback
        // continuity unknown. Drop that finite tail and re-prime from fresh
        // callbacks instead of getting stuck below the two-block prefill.
        speaker_output_cancel();
        output_starved = true;
    }
    unsigned queued = speaker_output_queued();
    if (!output_pending && (queued >= OUTPUT_PREFILL || (!output_wanted && queued >= OUTPUT_HALF))) {
        speaker_output_load(); // Prime RAM before starting the hardware consumer.
        output_last_irq_us = now;
        if (output_starved) ++audio_diag.output_restarts;
        output_starved = false;
        hrc7000_wr(modem, C7_INTERP_CLEAR, C7_INT_PCM_RD);
        hrc_irq_enable(IRQ_PCM_RD, true);
        hrc7000_audio_bits(modem, C7_AUDIO_PCM_SPK, C7_AUDIO_RING_PLAY | C7_AUDIO_FM_PLAY);
    } else if (!output_wanted && !output_pending && !queued) {
        spk_routed = false;
        off = true;
        ++audio_diag.output_drains;
    }
    hrc_irq_restore(s);
    if (off && speaker_pcm_cb != NULL) speaker_pcm_cb(false);
}

static void speaker_output_publish(const int16_t *samples, uint32_t epoch)
{
    uint32_t s = hrc_irq_save();
    if (running && !stopping && !output_blocked && !fifo_held && output_wanted && epoch == output_epoch) {
        uint8_t next = (uint8_t)((spk_head + 1u) % SPK_BLOCKS);
        if (next == spk_tail) {
            ++audio_diag.output_overflows;
            audio_diag.output_discarded += AUDIO_BLOCK_SAMPLES;
        } else {
            memcpy(spk_q[spk_head], samples, sizeof spk_q[spk_head]);
            hrc_barrier();
            spk_head = next;
            unsigned queued = speaker_output_queued();
            if (queued > audio_diag.output_queue_max) audio_diag.output_queue_max = queued;
        }
    }
    hrc_irq_restore(s);
}
#endif
