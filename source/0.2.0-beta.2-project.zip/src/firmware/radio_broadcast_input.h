// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_BROADCAST_INPUT_H
#define RADIO_BROADCAST_INPUT_H
#include <stdbool.h>
#include <stdint.h>
#include "radio_functions.h"

// Keypad input in MHz, or a digits-only shorthand. Scaling by exact powers
// of ten is unambiguous because the broadcast band spans less than a decade.
// The caller supplies the bounded input length; no terminator is required.
static inline bool radio_broadcast_input_khz(const char *text,unsigned length,uint32_t *khz) {
    if(!text || !khz || !length || length>7u)return false;
    unsigned point=length;
    uint32_t whole=0,fraction=0;
    for(unsigned i=0;i<length;++i) {
        char c=text[i];
        if(c=='.') {
            if(!i || point!=length)return false;
            point=i;continue;
        }
        if(c<'0' || c>'9')return false;
        // At most seven decimal digits fit comfortably in uint32_t.
        if(point==length)whole=whole*10u+(unsigned)(c-'0');
        else fraction=fraction*10u+(unsigned)(c-'0');
    }
    uint32_t value=whole;
    if(point<length) {
        unsigned places=length-point-1u;
        if(places>3u)return false;
        while(places++<3u)fraction*=10u;
        // A decimal point leaves at most six whole digits within length 7.
        value=whole*1000u+fraction;
    } else {
        // Do not turn an accidental partial entry such as 1 into 100 MHz.
        if(value<RADIO_BCAST_MIN_KHZ/1000u)return false;
        while(value>RADIO_BCAST_MAX_KHZ) {
            if(value%10u)return false; // Never truncate significant digits.
            value/=10u;
        }
        while(value<RADIO_BCAST_MIN_KHZ)value*=10u;
    }
    if(value<RADIO_BCAST_MIN_KHZ || value>RADIO_BCAST_MAX_KHZ || value%RADIO_BCAST_STEP_KHZ)return false;
    *khz=value;return true;
}
#endif
