// SPDX-License-Identifier: GPL-3.0-or-later
// Task-context ownership of the separate broadcast receiver. No RF TX calls.
#ifndef RADIO_BROADCAST_H
#define RADIO_BROADCAST_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "hal_bcast.h"
#include "radio_functions.h"

// The DM32's physical volume knob remains the listening control. Set the
// receiver's upstream level to full scale, rather than adding a second volume.
#define RADIO_BROADCAST_VOLUME BCAST_VOLUME_MAX

typedef struct {
    const hal_bcast_t *hal;
    bcast_status_t status;
    uint32_t khz;
    bool owned,running,busy,audio_open,have_status,failed;
} radio_broadcast;

static inline bool radio_broadcast_frequency_valid(const hal_bcast_t *hal,uint32_t khz) {
    return hal && hal->grid_khz && hal->lo_khz<=hal->hi_khz
        && khz && radio_functions_broadcast_valid(khz)
        && khz>=hal->lo_khz && khz<=hal->hi_khz && !(khz%hal->grid_khz);
}
static inline void radio_broadcast_audio(radio_broadcast *b,bool on) {
    if(b->audio_open!=on) {b->hal->audio(on);b->audio_open=on;}
}
// Only the owner touches the shared speaker route. Mute before power-off, even
// while a tune/seek is pending; an unowned second stop is hardware-idempotent.
static inline void radio_broadcast_stop(radio_broadcast *b) {
    if(!b || !b->owned)return;
    b->hal->audio(false);b->audio_open=false;
    if(!b->hal->power(false))b->failed=true;
    b->owned=b->running=b->busy=b->have_status=false;
}
static inline bool radio_broadcast_fail(radio_broadcast *b) {
    b->failed=true;radio_broadcast_stop(b);return false;
}
// Caller pauses the channel receiver and its audio producer before start.
// A zero frequency means the effective legacy/default 87.5 MHz setting.
static inline bool radio_broadcast_start(radio_broadcast *b,const hal_bcast_t *hal,uint32_t khz) {
    if(!b || b->owned || !hal || !hal->power || !hal->tune || !hal->seek
       || !hal->volume || !hal->status || !hal->audio)return false;
    if(!khz)khz=RADIO_BCAST_DEFAULT_KHZ;
    if(!radio_broadcast_frequency_valid(hal,khz))return false;
    memset(b,0,sizeof *b);b->hal=hal;b->owned=true;b->khz=khz;
    hal->audio(false);
    if(!hal->power(true))return radio_broadcast_fail(b);
    hal->volume(RADIO_BROADCAST_VOLUME);
    if(!hal->tune(khz))return radio_broadcast_fail(b);
    b->running=b->busy=true;return true;
}
static inline bool radio_broadcast_tune(radio_broadcast *b,uint32_t khz) {
    if(!b || !b->owned || !b->running || b->busy || !radio_broadcast_frequency_valid(b->hal,khz))return false;
    radio_broadcast_audio(b,false);
    if(!b->hal->tune(khz))return radio_broadcast_fail(b);
    b->khz=khz;b->busy=true;b->have_status=false;return true;
}
static inline bool radio_broadcast_seek(radio_broadcast *b,bool up) {
    if(!b || !b->owned || !b->running || b->busy)return false;
    radio_broadcast_audio(b,false);
    if(!b->hal->seek(up))return radio_broadcast_fail(b);
    b->busy=true;b->have_status=false;return true;
}
// Caller schedules bounded task-context polling (e.g. every100 ms), not from
// an audio ISR. A completed unsuccessful seek is still a valid tuner status.
static inline bool radio_broadcast_poll(radio_broadcast *b) {
    if(!b || !b->owned || !b->running)return false;
    bcast_status_t next;
    if(!b->hal->status(&next) || !radio_broadcast_frequency_valid(b->hal,next.khz))return radio_broadcast_fail(b);
    b->status=next;b->khz=next.khz;b->busy=next.tuning;b->have_status=true;
    radio_broadcast_audio(b,!next.tuning);return true;
}
#endif
