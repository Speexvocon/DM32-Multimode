// SPDX-License-Identifier: GPL-3.0-or-later
// Canonical 32-byte channel helpers shared by storage and the radio controller.
#ifndef RADIO_CHANNEL_H
#define RADIO_CHANNEL_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
typedef enum { RADIO_CHANNEL_P25, RADIO_CHANNEL_FM, RADIO_CHANNEL_DMR } radio_channel_mode_t;
static inline radio_channel_mode_t radio_channel_get_mode(const uint8_t *p) {
    return p[12]&0x40u ? RADIO_CHANNEL_DMR : p[12]&2u ? RADIO_CHANNEL_FM : RADIO_CHANNEL_P25;
}
static inline uint32_t radio_channel_get_destination(const uint8_t *p) {
    if(radio_channel_get_mode(p)==RADIO_CHANNEL_DMR)return (uint32_t)p[8]|(uint32_t)p[9]<<8|(uint32_t)p[10]<<16;
    return (uint32_t)p[10]|(uint32_t)p[11]<<8;
}
static inline bool radio_channel_set_destination(uint8_t *p,uint32_t id) {
    if(!id || id>(radio_channel_get_mode(p)==RADIO_CHANNEL_DMR ? 0xffffffu : 0xffffu))return false;
    if(radio_channel_get_mode(p)==RADIO_CHANNEL_DMR){p[8]=(uint8_t)id;p[9]=(uint8_t)(id>>8);p[10]=(uint8_t)(id>>16);}
    else {p[10]=(uint8_t)id;p[11]=(uint8_t)(id>>8);}return true;
}
static inline unsigned radio_channel_get_color_code(const uint8_t *p) {return p[11]&15u;}
static inline bool radio_channel_set_color_code(uint8_t *p,unsigned cc) {
    if(radio_channel_get_mode(p)!=RADIO_CHANNEL_DMR || cc>15u)return false;
    p[11]=(uint8_t)((p[11]&0xf0u)|cc);return true;
}
static inline unsigned radio_channel_get_timeslot(const uint8_t *p) {return p[11]&16u ? 2u : 1u;}
static inline bool radio_channel_set_timeslot(uint8_t *p,unsigned slot) {
    if(radio_channel_get_mode(p)!=RADIO_CHANNEL_DMR || slot<1u || slot>2u)return false;
    p[11]=(uint8_t)((p[11]&~16u)|(slot==2u ? 16u : 0u));return true;
}
static inline bool radio_channel_get_private(const uint8_t *p) {return (p[11]&32u)!=0;}
static inline void radio_channel_set_private(uint8_t *p,bool on) {
    if(radio_channel_get_mode(p)==RADIO_CHANNEL_DMR)p[11]=(uint8_t)((p[11]&~32u)|(on ? 32u : 0u));
}
static inline bool radio_channel_get_repeater(const uint8_t *p) {return (p[11]&64u)!=0;}
static inline void radio_channel_set_repeater(uint8_t *p,bool on) {
    if(radio_channel_get_mode(p)==RADIO_CHANNEL_DMR)p[11]=(uint8_t)((p[11]&~64u)|(on ? 64u : 0u));
}
static inline bool radio_channel_set_mode(uint8_t *p,radio_channel_mode_t mode) {
    if(mode!=RADIO_CHANNEL_P25 && mode!=RADIO_CHANNEL_FM && mode!=RADIO_CHANNEL_DMR)return false;
    radio_channel_mode_t old=radio_channel_get_mode(p);if(old==mode)return true;
    // Mode changes are deliberate: retain common fields, reset incompatible
    // union/filter/tone settings. Source ID lives in the separate global record.
    p[12]&=0x11u;
    if(mode==RADIO_CHANNEL_DMR){memset(p+8,0,4);p[8]=1;p[11]=1;p[12]|=0x40u;}
    else {
        if(old==RADIO_CHANNEL_DMR){p[8]=0x93;p[9]=2;p[10]=1;p[11]=0;}
        if(mode==RADIO_CHANNEL_FM)p[12]|=2u;
    }
    memset(p+26,0,4);p[30]=5;return true; // Retain common power byte 31.
}
#endif
