// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_MONITOR_H
#define P25_MONITOR_H
#include "p25_demod.h"
#include "p25_diagnostics.h"
#include "p25_pcm_trace.h"
#include "p25_receive_policy.h"
#include "p25_voice_policy.h"
#include <string.h>
#include <stddef.h>
#define MON_RAW_BLOCKS 16u
#define MON_PCM_FRAMES 48u
#define MON_PREFILL 18u
// Raw ISR->task ring and decoded task->speaker-task ring. Caller serializes
// publish/pop with the platform interrupt lock. No decode or I/O under lock.
typedef struct {
    p25_demod demod;
    uint8_t raw[MON_RAW_BLOCKS][512];
    int16_t pcm[MON_PCM_FRAMES][160];
    volatile unsigned raw_head,raw_tail,pcm_head,pcm_tail;
    unsigned pcm_pos,last_half;
    uint32_t last_raw_us,last_voice_us;
    uint32_t raw_blocks,raw_high,pcm_high,raw_overflow,pcm_overflow,gaps;
    uint32_t units,voices,corrected,rejected,played,starved,max_block_us;
    bool playing,ending,have_raw;
    // Fits inside the existing raw-capture union; never allocate a second call.
    p25_receive_policy call;
    p25_voice_policy quality;
    int16_t last_good_pcm[160];
    uint32_t metadata_bad,encrypted_units,unsupported_units,unqualified_units;
    uint32_t repeated,muted,nid_recovered,discarded_pcm;
#if DM32_LAB_DIAGNOSTICS
    p25_pcm_trace trace;
#endif
} p25_monitor;
static inline unsigned mon_count(unsigned head,unsigned tail,unsigned size) {return (head+size-tail)%size;}
static inline void mon_init(p25_monitor *m) {
    memset(m,0,sizeof *m);p25_demod_init(&m->demod);
#if DM32_LAB_DIAGNOSTICS
    pcm_trace_init(&m->trace,false);
#endif
}
// Replay resets queues/counters while keeping retained decoder evidence intact.
#if DM32_LAB_DIAGNOSTICS
static inline void mon_init_replay(p25_monitor *m) {
    memset(m,0,offsetof(p25_monitor,trace));p25_demod_init(&m->demod);
}
#endif
static inline bool mon_raw_push(p25_monitor *m,volatile const uint8_t *ram,unsigned half,uint32_t now) {
    if(half!=1 && half!=2) {++m->gaps;return false;}
    if(m->have_raw && (half==m->last_half || now-m->last_raw_us>48000u)) {++m->gaps;return false;}
    unsigned next=(m->raw_head+1)%MON_RAW_BLOCKS;
    if(next==m->raw_tail) {++m->raw_overflow;return false;}
    for(unsigned i=0;i<512;++i)m->raw[m->raw_head][i]=ram[(half-1)*512+i];
    m->last_half=half;m->last_raw_us=now;m->have_raw=true;++m->raw_blocks;
    m->raw_head=next;unsigned n=mon_count(next,m->raw_tail,MON_RAW_BLOCKS);
    if(n>m->raw_high)m->raw_high=n;
    return true;
}
static inline bool mon_raw_pop(p25_monitor *m,uint8_t out[512]) {
    if(m->raw_tail==m->raw_head)return false;
    memcpy(out,m->raw[m->raw_tail],512);m->raw_tail=(m->raw_tail+1)%MON_RAW_BLOCKS;return true;
}
static inline bool mon_pcm_push(p25_monitor *m,const int16_t pcm[160]) {
    unsigned next=(m->pcm_head+1)%MON_PCM_FRAMES;
    if(next==m->pcm_tail) {++m->pcm_overflow;return false;}
    memcpy(m->pcm[m->pcm_head],pcm,320);m->pcm_head=next;
    unsigned n=mon_count(next,m->pcm_tail,MON_PCM_FRAMES);if(n>m->pcm_high)m->pcm_high=n;
    return true;
}
// Peek/commit lets a full hardware FIFO retry without losing samples.
static inline const int16_t *mon_pcm_peek(p25_monitor *m) {
    unsigned n=mon_count(m->pcm_head,m->pcm_tail,MON_PCM_FRAMES);
    if(!m->playing && (n>=MON_PREFILL || (m->ending && n)))m->playing=true;
    if(!n) {
        if(m->playing && !m->ending)++m->starved;
        m->playing=false;return NULL;
    }
    return m->playing ? &m->pcm[m->pcm_tail][m->pcm_pos] : NULL;
}
// Caller chooses one backend while stopped: 32-sample FIFO or 80-sample PCM.
// Both divide a frame exactly; switching mid-frame is forbidden by the adapter.
static inline void mon_pcm_commit_samples(p25_monitor *m,unsigned samples) {
    m->pcm_pos+=samples;
    if(m->pcm_pos==160) {m->pcm_pos=0;m->pcm_tail=(m->pcm_tail+1)%MON_PCM_FRAMES;++m->played;}
}
static inline void mon_pcm_commit(p25_monitor *m) {mon_pcm_commit_samples(m,32);}
#endif
