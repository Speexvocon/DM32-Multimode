// Host-only integration probe for the GPL IMBE reference implementation.
// No radio access. This checks the PCM/payload boundary, not over-air interoperability.
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include "imbe.h"
#include "imbe_vocoder.h"
#include "imbe_vocoder_impl.h"

struct GuardedPayload {
    uint8_t before[8];
    uint8_t bytes[11];
    uint8_t after[8];
};

int main() {
    imbe_vocoder enc, enc_check, dec;
    constexpr int frames = 100, samples = 160, rate = 8000;
    int16_t pcm[samples], pcm_check[samples], recovered[samples];
    unsigned peak = 0;
    GuardedPayload payload;
    uint8_t reference[11];
    auto start = std::chrono::steady_clock::now();
    for (int f = 0; f < frames; ++f) {
        for (int i = 0; i < samples; ++i) {
            double t = double(f * samples + i) / rate;
            // Silence first, then a voiced-like harmonic signal. Not a speech-quality test.
            pcm[i] = f < 10 ? 0 : int16_t(4500 * std::sin(2 * 3.141592653589793 * 140 * t)
                     + 2200 * std::sin(2 * 3.141592653589793 * 280 * t)
                     + 1100 * std::sin(2 * 3.141592653589793 * 420 * t));
        }
        std::memcpy(pcm_check, pcm, sizeof pcm);
        std::memset(&payload, 0xA5, sizeof payload);
        enc.encode_4400(pcm, payload.bytes);
        enc_check.encode_4400(pcm_check, reference);
        if (std::memcmp(reference, payload.bytes, 11) != 0) return 2;
        for (uint8_t v : payload.before) if (v != 0xA5) return 3;
        for (uint8_t v : payload.after) if (v != 0xA5) return 4;
        dec.decode_4400(recovered, payload.bytes);
        for (int16_t v : recovered) peak = std::max(peak, unsigned(std::abs(int(v))));
    }
    double ms = std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    if (peak == 0) return 5;
    std::printf("{\n  \"frames\": %d,\n  \"pcm_samples_per_frame\": %d,\n"
                "  \"pcm_rate_hz\": %d,\n  \"packed_imbe_bytes\": 11,\n"
                "  \"implementation_state_bytes_host\": %zu,\n  \"decoded_peak\": %u,\n"
                "  \"determinism_and_payload_guards\": true,\n"
                "  \"host_elapsed_ms_two_encoders_one_decoder\": %.3f\n}\n",
                frames,samples,rate,sizeof(imbe_vocoder_impl),peak,ms);
}
