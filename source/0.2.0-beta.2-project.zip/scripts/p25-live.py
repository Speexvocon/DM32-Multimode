"""Inspect, stop, or enable bounded physical-PTT live-voice tests; never flashes."""
import argparse
import json
from pathlib import Path
import time


def fields(line):
    return dict(x.split('=', 1) for x in line.split()[1:] if '=' in x)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port', required=True)
    p.add_argument('--log', required=True, type=Path)
    action = p.add_mutually_exclusive_group()
    action.add_argument('--arm', action='store_true')
    action.add_argument('--session', action='store_true')
    action.add_argument('--stop', action='store_true')
    p.add_argument('--frequency', type=int)
    p.add_argument('--allow-rf', action='store_true')
    a = p.parse_args()
    if (a.arm or a.session) and (not a.allow_rf or a.frequency is None or not (
            136000000 <= a.frequency <= 174000000 or 400000000 <= a.frequency <= 480000000)):
        p.error('--arm/--session requires --allow-rf and --frequency in the board TX range')
    import serial
    a.log.parent.mkdir(parents=True, exist_ok=True)
    with a.log.open('x', encoding='utf-8') as log, serial.Serial(a.port, 115200, timeout=.25, write_timeout=1) as port:
        def line():
            s = port.readline().decode('ascii', errors='replace').strip()
            if s:
                print(s, flush=True)
                log.write(json.dumps({'time_utc_epoch': time.time(), 'line': s})+'\n')
                log.flush()
            return s

        def wait(expected):
            deadline = time.monotonic()+4
            while time.monotonic() < deadline:
                s = line()
                if s.startswith('ERR'): raise RuntimeError(s)
                if s.startswith(expected): return s
            raise RuntimeError('Missing response: '+expected)

        # STOP must work during a call, when status deliberately avoids long UART output.
        if a.stop:
            port.write(b'STOP\n'); wait('OK STOP'); return
        port.write(b'STATUS\n')
        identity = fields(wait('LIVE git='))
        if identity.get('active') != '0' or identity.get('rf') != '0':
            raise RuntimeError('Expected idle LIVE firmware')
        if not (a.arm or a.session):
            wait('LIVE_AUDIO ')
            return
        if identity.get('cal') not in ('factory', 'copy'):
            raise RuntimeError('Expected valid factory or saved calibration')
        try:
            verb = 'SESSION' if a.session else 'ARM'
            port.write(f'{verb} {a.frequency} ALLOW_RF\n'.encode('ascii'))
            wait('OK LIVE SESSION; fresh PTT per call; STOP or power off ends' if a.session
                 else 'OK LIVE ARMED 30s; unplug cable then fresh PTT')
        except BaseException:
            port.write(b'STOP\n'); wait('OK STOP'); raise
        # Detach after ACK. Session survives normal calls, but not faults or power-off.
        # The radio has its own finite capture, fault shutdown and hard RF timer.
        print('Session enabled: unplug cable; fresh PTT per call. STOP or power off ends session.' if a.session
              else 'Armed once: unplug cable, then press and hold PTT. Reconnect after CALL STOPPED.', flush=True)


if __name__ == '__main__': main()
