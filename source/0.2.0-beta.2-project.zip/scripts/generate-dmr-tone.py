"""Generate/check a finite DMR 1031-Hz reference call; no hardware or RF.

Constants and the center-overlay procedure derive from Jonathan Naylor G4KLX,
Colin Durbridge G4EML and contributors' CalDMR.cpp (GPL-2.0-or-later). See the
fixture manifest for the exact upstream commit, file hash and source link.
"""
# SPDX-License-Identifier: GPL-2.0-or-later
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "fixtures/dmr-1031"
MMDVM_COMMIT = "046e1df16105cbc33de3da7b7d6a03af402ed81d"
CALDMR_SHA256_LF = "9c25168363bb449255ade80c39e00bb3eb378f13bf923758af783c4731d7c5d9"
VOICE_BURSTS = 84  # Fourteen complete A-F superframes, 252 * 20 ms = 5.04 s.

# The first 00 is CalDMR's host control byte; it is not transmitted on air.
VH_DMO1K = bytes.fromhex("00 00200808023815002ca01460846d5d7f77fd757e30300110014003c013c11e806f")
VT_DMO1K = bytes.fromhex("00 004f08dc028815782cd014c084ad5d7f77fd75796524022806200f801bc107805c")
VOICE_1K = bytes.fromhex("00 cea8fe83acc458200acea8fe83a000000000000cc458200acea8fe83acc458200a")
SYNCEMB_DMO1K = (
    bytes.fromhex("07 f7 d5 dd 57 df d0"),
    bytes.fromhex("01 30 00 00 90 09 10"),
    bytes.fromhex("01 70 00 90 00 07 40"),
    bytes.fromhex("01 70 00 31 40 07 40"),
    bytes.fromhex("01 50 a1 71 d1 70 70"),
    bytes.fromhex("01 10 00 00 00 0e 20"),
)
TONE_AMBE_FRAME = bytes.fromhex("cea8fe83acc458200a")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def reference_arrays(text):
    """Read only the four reviewed CalDMR arrays, refusing structural drift."""
    arrays = {}
    for name in ("VH_DMO1K", "VT_DMO1K", "VOICE_1K", "SYNCEMB_DMO1K"):
        match = re.search(r"const uint8_t " + name + r"\s*(?:\[[^\]]*\])+\s*=\s*\{(.*?)\};", text, re.S)
        if not match:
            raise ValueError("Missing CalDMR array: " + name)
        arrays[name] = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-fA-F]+)U?", match[1]))
    return arrays


def validate_reference(path):
    text = path.read_text(encoding="utf-8")
    if digest(text.encode()) != CALDMR_SHA256_LF:
        raise ValueError("CalDMR source differs from the reviewed pin")
    arrays = reference_arrays(text)
    expected = {"VH_DMO1K": VH_DMO1K, "VT_DMO1K": VT_DMO1K, "VOICE_1K": VOICE_1K,
                "SYNCEMB_DMO1K": b"".join(SYNCEMB_DMO1K)}
    if arrays != expected:
        raise ValueError("Generator constants differ from pinned CalDMR")


def voice_burst(index):
    """Replicate CalDMR::createDataDMO1k, including boundary nibble masks."""
    if not 0 <= index < 6:
        raise ValueError("Voice position must be A-F (0..5)")
    framed = bytearray(VOICE_1K)
    middle = SYNCEMB_DMO1K[index]
    framed[15:20] = middle[1:6]
    framed[14] = (framed[14] & 0xF0) | (middle[0] & 0x0F)
    framed[20] = (framed[20] & 0x0F) | (middle[6] & 0xF0)
    return bytes(framed[1:])


def original_call():
    # Native dmrdmo1k sends one header and one terminator and stops at F. We
    # choose a finite fourteen-superframe duration instead of its PTT loop.
    frames = [VH_DMO1K[1:]] + [voice_burst(i % 6) for i in range(VOICE_BURSTS)] + [VT_DMO1K[1:]]
    if any(len(frame) != 33 for frame in frames):
        raise ValueError("Unexpected CalDMR burst length")
    return b"".join(frames)


@lru_cache(maxsize=2)
def retarget_call(talkgroup):
    """Rebuild every LC copy with the actual pinned C encoders, offline only."""
    if talkgroup not in (9, 98638):
        raise ValueError("Only the two named reference talkgroups are supported")
    compiler = shutil.which("gcc") or shutil.which("cc")
    if not compiler:
        raise RuntimeError("Host C compiler required to retarget the reference LC")
    upstream = ROOT / "external/RadioFoundry/RadioFoundry"
    sources = [upstream / name for name in ("core/dmr/call/dmr_lc.c", "core/dmr/fec/dmrFec.c")]
    with tempfile.TemporaryDirectory(prefix="dmr-tone-lc-") as temporary:
        folder = Path(temporary);source = folder / "retarget.c";binary = folder / "retarget.exe"
        source.write_text(RETARGET_C)
        compiled = subprocess.run([compiler, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
                                   "-I", str(upstream / "core"), str(source), *map(str, sources),
                                   "-o", str(binary)], capture_output=True)
        if compiled.returncode:
            raise RuntimeError("Pinned C link-control encoder compilation failed: " + compiled.stderr.decode(errors="replace"))
        original = original_call()
        def encode(tg):
            return subprocess.run([str(binary), str(tg)], input=original, capture_output=True, check=True).stdout
        # Independent encoding must reproduce all original CalDMR RF bytes,
        # including full LC parity and every embedded LC/EMB nibble.
        if encode(9) != original:
            raise ValueError("Native C encoders do not reproduce the original TG9 fixture")
        output = encode(talkgroup)
    if len(output) != len(original) or voice_payload(output) != voice_payload(original):
        raise ValueError("Retargeting altered tone audio or burst inventory")
    return output


def voice_payload(call):
    """216 AMBE bits per voice burst, excluding the 48 signaling bits."""
    return b"".join(b[:13] + bytes(((b[13] & 0xf0) | (b[19] & 0x0f),)) + b[20:]
                    for b in (call[i*33:(i+1)*33] for i in range(1,85)))


def make_fixture(talkgroup=9):
    if talkgroup not in (9, 98638):
        raise ValueError("Only TG9 and TG98638 are named tone references")
    call = original_call() if talkgroup == 9 else retarget_call(talkgroup)
    controls = [0x41] + [0x20 if i % 6 == 0 else i % 6 for i in range(VOICE_BURSTS)] + [0x42]
    manifest = {
        "schema": "dm32-dmr-tone-v1",
        "purpose": "Finite known 1031-Hz DMR receive reference; not firmware or a transmission request",
        "color_code": 1, "timeslot": 2, "source_id": 1, "talkgroup": talkgroup,
        "private_call": False, "encrypted": False, "family": "ms",
        "tone_hz": 1031, "symbol_rate": 4800, "bit_rate": 9600,
        "burst_bytes": 33, "burst_count": len(call)//33, "burst_interval_ms": 60,
        "headers": 1, "voice_bursts": VOICE_BURSTS, "terminators": 1,
        "superframes": VOICE_BURSTS // 6, "voice_frames_20ms": VOICE_BURSTS * 3,
        "voice_seconds": VOICE_BURSTS * 0.06, "call_seconds": len(call)//33 * 0.06,
        "packing": "Concatenated 33-byte MSB-first RF bursts; no control, serial framing, CACH, RSSI or preamble bytes",
        "controls": controls,
        "transport_note": "For simplex MMDVM_HS, each burst is E0 25 1A <control> <33 RF bytes>; use fresh slot-2 FIFO space and a finite drain deadline. This file opens no transport.",
        "timeslot_note": "DMR_DATA2 selects the simplex DMO queue; MS-synced RF bursts contain no CACH timeslot field.",
        "ambe_frame_hex": TONE_AMBE_FRAME.hex(),
        "sources": {
            "mmdvm_commit": MMDVM_COMMIT,
            "caldmr_path": "CalDMR.cpp",
            "caldmr_sha256_lf": CALDMR_SHA256_LF,
            "caldmr_url": "https://github.com/g4klx/MMDVM/blob/" + MMDVM_COMMIT + "/CalDMR.cpp",
            "procedure": "VH_DMO1K, VOICE_1K overlaid by createDataDMO1k's SYNCEMB_DMO1K[0..5], VT_DMO1K",
            "license": "GPL-2.0-or-later; Jonathan Naylor G4KLX, Colin Durbridge G4EML and contributors",
        },
        "files": {"call.bin": {"bytes": len(call), "sha256": digest(call)}},
        "rf_verified": False,
    }
    if talkgroup != 9:
        encoder_names = ("core/dmr/call/dmr_lc.c", "core/dmr/call/dmr_lc.h",
                         "core/dmr/fec/dmrFec.c", "core/dmr/fec/dmrFec.h")
        manifest["retargeting"] = {
            "original_talkgroup": 9,
            "updated_talkgroup": talkgroup,
            "fields_rebuilt": ["header_full_LC_RS_BPTC", "terminator_full_LC_RS_BPTC",
                               "all_14_embedded_LCs_and_EMB"],
            "native_encoder_reference": "RadioFoundry/RadioFoundry 75c46ea46d5ebf6406f5b4ce0bbe2443b7649f91",
            "native_encoder_source_sha256_lf": {name: digest((ROOT / "external/RadioFoundry/RadioFoundry" / name).read_text().encode())
                                                 for name in encoder_names},
            "encoder_tg9_matches_original_byte_for_byte": True,
            "all_voice_payload_bytes_preserved": True,
            "retarget_helper_sha256": digest(RETARGET_C.encode()),
        }
    return call, manifest


def validate_fixture(call, manifest):
    expected_call, expected_manifest = make_fixture(manifest.get("talkgroup"))
    if call != expected_call or manifest != expected_manifest:
        raise ValueError("DMR fixture differs from the finite pinned CalDMR reference")
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--talkgroup", type=int, choices=(9, 98638), default=9)
    parser.add_argument("--check", action="store_true", help="Verify existing fixture without changing it")
    parser.add_argument("--reference", type=Path, help="Optionally compare the exact local pinned CalDMR.cpp")
    args = parser.parse_args()
    if args.reference:
        validate_reference(args.reference)
    output = args.output or (OUT if args.talkgroup == 9 else OUT / "tg98638")
    call, manifest = make_fixture(args.talkgroup)
    if args.check:
        validate_fixture((output / "call.bin").read_bytes(),
                         json.loads((output / "manifest.json").read_text()))
    else:
        output.mkdir(parents=True, exist_ok=True)
        (output / "call.bin").write_bytes(call)
        (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))


RETARGET_C = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif
#include "dmr/call/dmr_lc.h"
#include "dmr/fec/dmrFec.h"
static void full_lc(uint8_t *b,const uint8_t lc[9],uint8_t dt,uint8_t mask) {
    uint8_t info[12];dmr_lc_encode_full(lc,mask,info);
    dmrFecBptcEncode(info,b);dmrFecSlotTypeEncode(1,dt,b);
}
static void center(uint8_t *b,const uint8_t middle[6]) {
    b[13]=(uint8_t)((b[13]&0xf0)|(middle[0]>>4));
    for(unsigned j=0;j<5;++j)b[14+j]=(uint8_t)((middle[j]<<4)|(middle[j+1]>>4));
    b[19]=(uint8_t)((b[19]&0x0f)|(middle[5]<<4));
}
int main(int argc,char **argv) {
    assert(argc==2);char *tail=0;unsigned long tg=strtoul(argv[1],&tail,10);
    assert(tail && !*tail && (tg==9 || tg==98638));
#ifdef _WIN32
    assert(_setmode(_fileno(stdin),_O_BINARY)!=-1);
    assert(_setmode(_fileno(stdout),_O_BINARY)!=-1);
#endif
    uint8_t call[86][33];assert(fread(call,33,86,stdin)==86 && fgetc(stdin)==EOF);
    uint8_t lc[9]={0,0,0,(uint8_t)(tg>>16),(uint8_t)(tg>>8),(uint8_t)tg,0,0,1};
    full_lc(call[0],lc,1,0x96);full_lc(call[85],lc,2,0x99);
    uint8_t fragments[4][4];dmr_emb_lc_encode(lc,fragments);
    for(unsigned i=0;i<84;++i) {
        unsigned n=i%6;if(!n)continue; // A's MS voice sync remains byte-exact.
        uint8_t middle[6]={0};uint16_t emb=dmrFecEmbEncode(1,false,dmr_emb_lcss((uint8_t)n));
        middle[0]=(uint8_t)(emb>>8);middle[5]=(uint8_t)emb;
        if(n<=4)memcpy(middle+1,fragments[n-1],4);
        center(call[i+1],middle);
    }
    assert(fwrite(call,33,86,stdout)==86);return 0;
}
'''


if __name__ == "__main__":
    main()
