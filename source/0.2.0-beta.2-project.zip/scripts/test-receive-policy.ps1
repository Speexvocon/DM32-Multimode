$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$build=Join-Path $root 'build/receive-policy'
New-Item -ItemType Directory -Force $build | Out-Null
Push-Location $root
try {
    & python tests/test_p25_call.py
    if($LASTEXITCODE -ne 0){throw 'Independent metadata FEC/classification vectors failed'}
    & gcc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Isrc/firmware -Ifixtures/p25-1011 tests/test_p25_voice_policy.c src/firmware/p25_rx.c -o "$build/voice.exe"
    if($LASTEXITCODE -ne 0){throw 'Voice quality policy build failed'}
    & "$build/voice.exe"
    if($LASTEXITCODE -ne 0){throw 'Bounded concealment/quality policy failed'}
    & gcc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Isrc/firmware tests/test_p25_receive_policy.c src/firmware/p25_call.c -o "$build/call-state.exe"
    if($LASTEXITCODE -ne 0){throw 'Receive lifecycle policy build failed'}
    & "$build/call-state.exe"
    if($LASTEXITCODE -ne 0){throw 'Receive lifecycle/qualification failed'}
    & gcc -std=c11 -O2 -Wall -Wextra -Werror -Isrc/firmware -c src/firmware/p25_rx.c -o "$build/rx.o"
    if($LASTEXITCODE -ne 0){throw 'NID recovery build failed'}
    $op25='external/boatbod/op25/op25/gr-op25_repeater/lib'
    # Pinned third-party oracle is compiled unchanged; strict production flags above.
    & g++ -std=c++17 -O2 -Wall -Wextra -Isrc/firmware "-I$op25" tests/test_p25_nid.cpp "$op25/bch.cc" "$build/rx.o" -o "$build/nid.exe"
    if($LASTEXITCODE -ne 0){throw 'Independent NID BCH oracle build failed'}
    & "$build/nid.exe"
    if($LASTEXITCODE -ne 0){throw 'Bounded NID recovery/refusal failed'}
} finally {Pop-Location}
