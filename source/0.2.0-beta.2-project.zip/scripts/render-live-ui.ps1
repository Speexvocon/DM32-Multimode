param(
    [string]$OutputDirectory = '',
    [string]$Compiler = 'gcc',
    [switch]$ViewOnly
)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$upstream = Join-Path $root 'external/RadioFoundry/RadioFoundry'
$output = if ($OutputDirectory) { [IO.Path]::GetFullPath($OutputDirectory) } else { Join-Path $root 'build/live-ui-preview' }
New-Item -ItemType Directory -Force -Path $output | Out-Null
$includes = @('hal','core','drivers','boards/dm32','platform/hrc7000','platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include') | ForEach-Object { '-I' + (Join-Path $upstream $_) }
& $Compiler -std=gnu11 -O1 -ffunction-sections -fdata-sections '-Wl,--gc-sections' -Wall -Wextra -Werror -Wno-unused-parameter -DDM32_LAB_DIAGNOSTICS=1 -DCONFIG_DMR=1 -DCONFIG_FONT_AA=1 -DGFX_INDEXED=1 -DGFX_FIT_TRACE=1 -DGFX_MAX_ROWS=320 -DGFX_FB_BYTES=40960 '-DBENCH_GIT="preview"' -I (Join-Path $root 'tests/diag-stubs') @includes -I (Join-Path $root 'src/firmware') (Join-Path $root 'tests/render_live_ui.c') (Join-Path $root 'tests/diag-stubs/radio_dmr_stub.c') (Join-Path $upstream 'core/ui/gfx.c') (Join-Path $upstream 'core/ui/fonts.c') -o (Join-Path $output 'render.exe')
if ($LASTEXITCODE -ne 0) { throw 'Live renderer build failed' }
if ($ViewOnly) { & (Join-Path $output 'render.exe') $output --view-only }
else { & (Join-Path $output 'render.exe') $output }
$renderExit = $LASTEXITCODE
if ($renderExit -ne 0) { throw 'Live renderer layout checks failed; see layout-issues.tsv' }
if (-not $IsWindows) {
    Write-Host "PPM previews and layout report: $output (PNG gallery requires Windows)"
    return
}

# The PPMs are the actual indexed framebuffer expanded through its own RGB565
# palette. This Windows presentation step converts those pixels, without drawing
# replacement text. It does not require Python/Pillow or access the radio.
Add-Type -AssemblyName System.Drawing
if (-not ('LiveUiPreviewImages' -as [type])) {
    $drawingReferences = @('System.Drawing.Common','System.Drawing.Primitives') + @(
        'System.Private.Windows.GdiPlus.dll','System.Private.Windows.Core.dll' | ForEach-Object {
            $assembly = Join-Path $PSHOME $_
            if (Test-Path -LiteralPath $assembly) { $assembly }
        })
    Add-Type -ReferencedAssemblies $drawingReferences -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
public static class LiveUiPreviewImages {
    public static void ConvertPpm(string input, string output) {
        byte[] raw = File.ReadAllBytes(input);
        byte[] header = System.Text.Encoding.ASCII.GetBytes("P6\n240 320\n255\n");
        if (raw.Length != header.Length + 240 * 320 * 3) throw new Exception("Unexpected framebuffer length");
        for (int i = 0; i < header.Length; i++) if (raw[i] != header[i]) throw new Exception("Unexpected PPM header");
        using (Bitmap bitmap = new Bitmap(240, 320, PixelFormat.Format24bppRgb)) {
            BitmapData data = bitmap.LockBits(new Rectangle(0, 0, 240, 320), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
            try {
                byte[] bgr = new byte[data.Stride * 320];
                for (int y = 0; y < 320; y++) for (int x = 0; x < 240; x++) {
                    int src = header.Length + (y * 240 + x) * 3, dst = y * data.Stride + x * 3;
                    bgr[dst] = raw[src + 2]; bgr[dst + 1] = raw[src + 1]; bgr[dst + 2] = raw[src];
                }
                Marshal.Copy(bgr, 0, data.Scan0, bgr.Length);
            } finally { bitmap.UnlockBits(data); }
            bitmap.Save(output, ImageFormat.Png);
        }
    }
    public static void ContactSheet(string[] paths, string[] labels, string output) {
        const int cols = 4, cellw = 260, cellh = 356;
        int rows = (paths.Length + cols - 1) / cols;
        using (Bitmap sheet = new Bitmap(cols * cellw, rows * cellh))
        using (Graphics graphics = Graphics.FromImage(sheet))
        using (Font font = new Font("Segoe UI", 10))
        using (Brush brush = new SolidBrush(Color.FromArgb(226, 234, 242))) {
            graphics.Clear(Color.FromArgb(21, 28, 39));
            for (int n = 0; n < paths.Length; n++) {
                int x = (n % cols) * cellw + 10, y = (n / cols) * cellh + 6;
                graphics.DrawString(labels[n], font, brush, new RectangleF(x, y, 242, 28));
                using (Image image = Image.FromFile(paths[n])) graphics.DrawImageUnscaled(image, x, y + 27);
            }
            sheet.Save(output, ImageFormat.Png);
        }
    }
    public static void PreviewStrip(string[] paths, string output) {
        using (Bitmap strip = new Bitmap(paths.Length * 240, 320))
        using (Graphics graphics = Graphics.FromImage(strip)) {
            for (int n = 0; n < paths.Length; n++)
                using (Image image = Image.FromFile(paths[n])) graphics.DrawImageUnscaled(image, n * 240, 0);
            strip.Save(output, ImageFormat.Png);
        }
    }
}
'@
}
$cases = @(Get-Content (Join-Path $output 'cases.tsv') | ForEach-Object {
    $parts = $_ -split "\t", 2
    $png = [IO.Path]::ChangeExtension($parts[0], '.png')
    [LiveUiPreviewImages]::ConvertPpm((Join-Path $output $parts[0]), (Join-Path $output $png))
    [pscustomobject]@{ Png = $png; Name = $parts[1] }
})
$featuredNames = @('listening-ptt-ready','rx-call-identity','named-memory-maximum-name','vfo-b',
    'menu-root-bottom','menu-memory-save','menu-scan-list-four','menu-display-600-seconds',
    'menu-fm-bandwidth','menu-fm-bottom','fm-narrow-listening','fm-wide-dcs-inverted',
    'fm-receiving-ctcss','fm-transmitting-dcs','scan-holding-p25','scan-holding-fm',
    'keypad-locked','edit-memory-save-32','edit-memory-recall-01','edit-screen-timeout-600',
    'dmr-24bit-destination','dmr-private-call','dmr-encrypted-muted','dmr-prom-reception')
$featured = @($featuredNames | ForEach-Object { $name = $_; $cases | Where-Object Name -EQ $name })
if (-not $featured.Count) { $featured = $cases }
[LiveUiPreviewImages]::ContactSheet([string[]]@($featured | ForEach-Object { Join-Path $output $_.Png }),
    [string[]]@($featured | ForEach-Object Name), (Join-Path $output 'gallery.png'))
$previewNames = @('named-memory-maximum-name','fm-receiving-ctcss','menu-root-bottom')
$preview = @($previewNames | ForEach-Object { $name = $_; $cases | Where-Object Name -EQ $name })
if ($preview.Count -eq 3) {
    [LiveUiPreviewImages]::PreviewStrip([string[]]@($preview | ForEach-Object { Join-Path $output $_.Png }),
        (Join-Path $output 'preview.png'))
}
$cards = $cases | ForEach-Object {
    $name = [System.Net.WebUtility]::HtmlEncode($_.Name)
    '<figure><img src="' + $_.Png + '" width="240" height="320" alt="' + $name + '"><figcaption>' + $name + '</figcaption></figure>'
}
$html = @'
<!doctype html><meta charset="utf-8"><title>DM32 P25 real framebuffer gallery</title>
<style>body{margin:24px;background:#151c27;color:#e2eaf2;font:16px system-ui}h1{font-size:24px}main{display:grid;grid-template-columns:repeat(auto-fill,260px);gap:16px}figure{margin:0;padding:10px;background:#202c3b;border-radius:8px}img{display:block;image-rendering:pixelated}figcaption{font-size:13px;margin-top:8px;overflow-wrap:anywhere}a{color:#4bd6e4}</style>
<h1>DM32 P25/DMR/FM firmware screen gallery</h1><p>Actual 4-bpp firmware framebuffer and upstream anti-aliased fonts. Panel 240×320; safe area 220×310. Includes memories, VFO A/B, scan lists, keypad lock, lighting and DMR call contexts.</p>
<p><a href="layout-report.json">Layout report</a> · <a href="layout-issues.tsv">Bounds and text overlap issues</a> · <a href="gallery.png">Featured contact sheet</a></p><main>
'@
[IO.File]::WriteAllText((Join-Path $output 'index.html'), $html + ($cards -join [Environment]::NewLine) + '</main>')
Write-Host "Gallery: $(Join-Path $output 'index.html')"
