"""Capture six seconds of live IMBE, RF disabled; save payloads for offline listening."""
import argparse
import json
from pathlib import Path
import time
import subprocess
import tempfile
import wave


def fields(line):
    return dict(item.split('=', 1) for item in line.split()[1:] if '=' in item)


def validate(status, payloads):
    if not (status.get('running') == '0' and status.get('rf') == 'disabled'
            and status.get('done') == '1' and status.get('reason') == 'complete'
            and status.get('captured') == '300' and status.get('encoded') == '306'
            and status.get('overflow') == '0' and status.get('driver_overruns') == '0'
            and status.get('pcm') == '0' and len(payloads) == 306 * 11):
        raise ValueError('Incomplete microphone capture or audio loss')
    checksum = 2166136261
    for byte in payloads:
        checksum = ((checksum ^ byte) * 16777619) & 0xffffffff
    if f'{checksum:08x}' != status.get('hash'):
        raise ValueError('Payload download checksum mismatch')
    # 299 intervals between 300 callbacks; timestamp reflects deferred callback
    # scheduling, so this is a broad sanity gate, not a sample-clock measurement.
    if not 5800000 <= int(status['span_us']) <= 6200000:
        raise ValueError('Unexpected microphone callback cadence')
    return {'transport_pass': True, 'status': status,
            'audio_present': int(status['peak']) > 0,
            'limitation': 'Real microphone encoding; no scheduled RF sink. Listen to decoded audio to assess routing and intelligibility.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', required=True)
    parser.add_argument('--log', required=True, type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--download-only', action='store_true', help='Retrieve the completed stored capture without starting another')
    mode.add_argument('--start-only', action='store_true', help='Start the finite capture and detach after ACK; reconnect with --download-only')
    parser.add_argument('--digital', action='store_true', help='Use passive digital modem mode for the no-RF PCM comparison')
    parser.add_argument('--delay', action='store_true', help='Wait 20 seconds before digital capture; radio displays countdown')
    parser.add_argument('--phy', action='store_true', help='Wait 20 seconds then capture in raw P25 PHY mode, RF disabled')
    parser.add_argument('--voice-tool', type=Path, default=Path(__file__).resolve().parents[1]/'build/host-voice/p25_voice.exe')
    args = parser.parse_args()
    import serial
    args.log.parent.mkdir(parents=True, exist_ok=True)
    payload_path = args.log.with_suffix('.imbe')
    summary_path = args.log.with_suffix('.summary.json')
    wav_path = args.log.with_suffix('.wav')
    if not args.start_only and not args.voice_tool.is_file():
        raise FileNotFoundError('Build the reference decoder first: scripts/build-host-voice.ps1')
    if any(p.exists() for p in (payload_path, summary_path, wav_path)):
        raise FileExistsError('Choose a fresh capture name')
    with args.log.open('x', encoding='utf-8') as log, serial.Serial(args.port, 115200, timeout=.25, write_timeout=1) as port:
        def read():
            line = port.readline().decode('ascii', errors='replace').strip()
            if line:
                print(line, flush=True)
                log.write(json.dumps({'time_utc_epoch': time.time(), 'line': line})+'\n')
                log.flush()
            return line
        port.write(b'STATUS\n')
        identity = {}
        deadline = time.monotonic()+4
        while time.monotonic() < deadline:
            line = read()
            if line.startswith(('IMBE git=', 'STREAM git=', 'MIC git=')):
                identity = fields(line)
                break
        if identity.get('rf') != 'disabled' or identity.get('running') != '0':
            raise RuntimeError('Expected idle RF-disabled benchmark')
        if args.download_only and (identity.get('done') != '1' or not line.startswith('MIC git=')):
            raise RuntimeError('No completed microphone capture to download')
        status, framing, hardware = (identity if args.download_only else {}), {}, {}
        acknowledged = args.download_only
        try:
            if not args.download_only: port.write(b'MIC_PHY\n' if args.phy else b'MIC_WAIT\n' if args.delay else b'MIC_DMR\n' if args.digital else b'MIC\n')
            deadline = time.monotonic()+(32 if args.delay or args.phy else 12)
            while time.monotonic() < deadline:
                line = read()
                if line == ('OK MIC_PHY 20 seconds' if args.phy else 'OK MIC_WAIT 20 seconds' if args.delay else 'OK MIC 300 live frames'):
                    acknowledged = True
                    if args.start_only: return # Firmware stops itself after six seconds (8-s watchdog).
                if line.startswith('ERR'): raise RuntimeError(line)
                if acknowledged and line.startswith('MIC git='):
                    status = fields(line)
                if acknowledged and line.startswith('MIC_HW '): hardware = fields(line)
                if acknowledged and line.startswith('MIC_FRAMING '):
                    framing = fields(line)
                    if status.get('running') == '0': break
        finally:
            if not (args.start_only and acknowledged):
                port.write(b'STOP\n')
                deadline = time.monotonic()+3
                stopped = False
                while time.monotonic() < deadline:
                    if read() == 'OK STOP':
                        stopped = True
                        break
                if not stopped: raise RuntimeError('STOP acknowledgement missing; capture log retained')
        if status.get('done') != '1':
            raise RuntimeError('Microphone did not complete; inspect capture log')
        port.write(b'MIC_DUMP\n')
        payloads = bytearray()
        deadline = time.monotonic()+8
        dumped = False
        while time.monotonic() < deadline:
            line = read()
            if line == 'OK MIC_DUMP':
                dumped = True
                break
            if line.startswith('ERR'): raise RuntimeError(line)
            if line.startswith('MIC_DATA '):
                _, index, data = line.split()
                frame = bytes.fromhex(data)
                if int(index) != len(payloads)//11 or len(frame) != 11 or len(payloads) >= 306*11:
                    raise ValueError('Missing, duplicate or malformed payload')
                payloads.extend(frame)
        if not dumped: raise RuntimeError('Payload download incomplete')
        report = validate(status, payloads)
        with payload_path.open('xb') as output: output.write(payloads)
        with tempfile.TemporaryDirectory() as folder:
            pcm, framed = Path(folder)/'audio.s16le', Path(folder)/'call.bin'
            for mode, destination in (('decode', pcm), ('frame', framed)):
                subprocess.run([str(args.voice_tool.resolve()), mode, str(payload_path.resolve()), str(destination)], check=True)
            body = framed.read_bytes()[339:-18]
            checksum = 2166136261
            for byte in body: checksum = ((checksum ^ byte)*16777619)&0xffffffff
            if len(body) != 34*216 or framing.get('ldus') != '34' or framing.get('hash') != f'{checksum:08x}':
                raise ValueError('MCU LDU framing does not match independent host framing')
            decoded = pcm.read_bytes()
            if len(decoded) != 306*320: raise ValueError('Unexpected decoded audio length')
            with wav_path.open('xb') as output, wave.open(output, 'wb') as wav:
                wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(8000)
                wav.writeframes(decoded)
        report['framing'] = framing
        report['hardware'] = hardware
        report['framing_matches_reference'] = True
        report['decoded_wav'] = str(wav_path)
        with summary_path.open('x', encoding='utf-8') as output: json.dump(report, output, indent=2)
        print(json.dumps(report, indent=2))


if __name__ == '__main__': main()
