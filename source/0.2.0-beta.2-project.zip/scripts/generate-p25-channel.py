"""Generate sparse linear control-field masks from pinned OP25; no hardware access.

NID BCH and HDU/LC RS + Golay/Hamming are binary-linear for these fixed clear
conventional-group formats. Store XOR deltas from the verified default call.
Voice positions, status symbols and all other fields remain untouched.
"""
from pathlib import Path
import importlib.util
import hashlib
import sys
import os
import tempfile
ROOT=Path(__file__).resolve().parents[1]
CRAFT=ROOT/'research/references/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py'
def reference():
    spec=importlib.util.spec_from_file_location('p25craft',CRAFT)
    m=importlib.util.module_from_spec(spec)
    # The pinned module opens p25.out at import; isolate and close that side effect.
    previous=os.getcwd()
    with tempfile.TemporaryDirectory() as temporary:
        try:
            os.chdir(temporary);spec.loader.exec_module(m)
            m.outfile.close();m.outfile=None
        finally:os.chdir(previous)
    m.text_out=lambda text:None
    return m

def call(m,nac,tg,src):
    frames=[]
    def output(dibits):
        assert len(dibits)%4==0
        frames.append(bytes(sum(dibits[i+j]<<(6-2*j) for j in range(4)) for i in range(0,len(dibits),4)))
    m.print_spec=output
    tone=0x38928490d433c0be1b91844ff058a589d839
    m.construct_hdu(nac,0,0,0,0x80,0,tg)
    m.construct_ldu1(nac,0,tone,0,0,0,0,0,tg,0,src)
    m.construct_ldu2(nac,0,tone,0,0,0x80,0)
    m.construct_stdu(nac,0)
    assert list(map(len,frames))==[99,216,216,18]
    return b''.join(frames)

def main():
    m=reference();base=call(m,0x293,1,1)
    fixture=(ROOT/'fixtures/p25-1011/call.bin').read_bytes()
    assert base==fixture[:531]+fixture[-18:]
    masks=[];index=[0]
    for field,width in enumerate((12,16,24)):
        for bit in range(width):
            args=[0x293,1,1];args[field]^=1<<bit
            delta=call(m,*args)
            masks.extend((i<<8)|(a^b) for i,(a,b) in enumerate(zip(base,delta)) if a!=b)
            index.append(len(masks))
    lines=['// SPDX-License-Identifier: GPL-3.0-or-later',
           '// Generated from pinned GPL-2.0-or-later OP25 p25craft.py; see THIRD_PARTY.md.',
           '// Generator: scripts/generate-p25-channel.py; do not edit.',
           '// Reference SHA256: '+hashlib.sha256(CRAFT.read_bytes()).hexdigest(),
           '#pragma once','#include <stdint.h>',
           'static const uint16_t p25_channel_index[53] = {',
           ', '.join(map(str,index))+'};',
           'static const uint32_t p25_channel_masks[] = {']
    lines += ['    '+', '.join(f'0x{x:06x}u' for x in masks[i:i+8])+',' for i in range(0,len(masks),8)]
    lines+=['};']
    content='\n'.join(lines)+'\n'
    path=ROOT/'src/firmware/p25_channel_masks.h'
    if '--check' in sys.argv:
        if path.read_text()!=content:raise ValueError('Channel masks differ from pinned reference')
    else:path.write_text(content)
    print(f'{len(masks)} sparse XOR entries, {len(masks)*4+106} bytes of tables')
if __name__=='__main__':main()
