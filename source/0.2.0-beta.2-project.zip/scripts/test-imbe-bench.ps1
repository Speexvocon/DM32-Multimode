param([ValidateSet('-Os','-O2','-O3')][string]$Optimization = '-O3')
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$codec = Join-Path $root 'research/references/nostar/imbe_vocoder'
$build = Join-Path $root 'build/imbe-bench-host'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$sources = @(Get-ChildItem -LiteralPath $codec -Filter '*.cc' -File | Where-Object Name -ne 'imbe_vocoder.cc' | ForEach-Object FullName)
$referenceSources = @($sources)
$unity = Join-Path $root 'src/firmware/imbe_encoder_unity.cpp'
$merged = @(Select-String -Path $unity -Pattern '^#include "(.+\.cc)"' | ForEach-Object { $_.Matches[0].Groups[1].Value })
$sources = @($sources | Where-Object { (Split-Path $_ -Leaf) -notin $merged }) + @($unity)
& python (Join-Path $root 'scripts/generate-imbe-profile.py') (Join-Path $codec 'encode.cc') (Join-Path $build 'imbe_encode_profile.cc')
if ($LASTEXITCODE -ne 0) { throw 'Profile generation failed' }
$sources += Join-Path $root 'tests/imbe_profile_probe.cpp'
& python (Join-Path $root 'scripts/generate-imbe-pitch.py') (Join-Path $codec 'pitch_est.cc') (Join-Path $build 'imbe_pitch_specialized.cc')
if ($LASTEXITCODE -ne 0) { throw 'Pitch specialization generation failed' }
$profileFlags = @('-DIMBE_STAGE_PROFILE=1', '-DIMBE_PITCH_SPECIALIZE=1', '-I' + $build, '-I' + (Join-Path $root 'src/firmware'))
& g++ -std=c++17 $Optimization @profileFlags -fwrapv -fno-exceptions -fno-rtti -fno-threadsafe-statics -nostdinc++ -I (Join-Path $root 'src/firmware/freestanding-cxx') -I $codec -I (Join-Path $root 'src/firmware') (Join-Path $root 'src/firmware/imbe_bench.cpp') (Join-Path $root 'tests/imbe_bench_probe.cpp') @sources -o (Join-Path $build 'probe.exe')
if ($LASTEXITCODE -ne 0) { throw 'Fixed-storage benchmark build failed' }
& (Join-Path $build 'probe.exe') (Join-Path $build 'payloads.bin')
if ($LASTEXITCODE -ne 0) { throw 'Fixed-storage benchmark probe failed' }
& python (Join-Path $root 'tests/check_imbe_bench.py')
if ($LASTEXITCODE -ne 0) { throw 'Benchmark reference mismatch' }
& g++ -std=c++17 $Optimization @profileFlags -fwrapv -fno-exceptions -fno-rtti -I $codec (Join-Path $root 'tests/imbe_unity_probe.cpp') @sources -o (Join-Path $build 'unity-probe.exe')
if ($LASTEXITCODE -ne 0) { throw 'Unity comparison build failed' }
& python (Join-Path $root 'tests/check_imbe_unity.py')
if ($LASTEXITCODE -ne 0) { throw 'Unity extended reference mismatch' }
& python (Join-Path $root 'tests/generate_pitch_cache_probe.py')
if ($LASTEXITCODE -ne 0) { throw 'Pitch cache probe generation failed' }
& g++ -std=c++17 $Optimization @profileFlags -fwrapv -I $codec (Join-Path $build 'pitch-cache-probe.cpp') @sources -o (Join-Path $build 'pitch-cache-probe.exe')
if ($LASTEXITCODE -ne 0) { throw 'Pitch cache probe build failed' }
& (Join-Path $build 'pitch-cache-probe.exe')
if ($LASTEXITCODE -ne 0) { throw 'Pitch cache result/flag comparison failed' }
& gcc -std=c11 -O2 -Wall -Wextra -Werror -I (Join-Path $root 'src/firmware') (Join-Path $root 'tests/test_imbe_stream.c') -o (Join-Path $build 'stream-model.exe')
if ($LASTEXITCODE -ne 0) { throw 'Streaming model build failed' }
& (Join-Path $build 'stream-model.exe')
if ($LASTEXITCODE -ne 0) { throw 'Streaming model failed' }
& gcc -std=c11 -O2 -Wall -Wextra -Werror -DSTREAM_RESERVE_US=0 -I (Join-Path $root 'src/firmware') (Join-Path $root 'tests/test_imbe_stream.c') -o (Join-Path $build 'stream-no-reserve.exe')
if ($LASTEXITCODE -ne 0) { throw 'No-reserve regression model build failed' }
& (Join-Path $build 'stream-no-reserve.exe')
if ($LASTEXITCODE -ne 0) { throw 'No-reserve boundary regression check failed' }
& g++ -std=c++17 $Optimization @profileFlags -fwrapv -I $codec -I (Join-Path $root 'src/firmware') (Join-Path $root 'tests/imbe_stream_probe.cpp') (Join-Path $root 'src/firmware/imbe_bench.cpp') @sources -o (Join-Path $build 'stream-probe.exe')
if ($LASTEXITCODE -ne 0) { throw 'Streaming codec build failed' }
& (Join-Path $build 'stream-probe.exe') (Join-Path $build 'stream.s16le') (Join-Path $build 'stream.imbe')
if ($LASTEXITCODE -ne 0) { throw 'Streaming codec probe failed' }
& g++ -std=c++17 -O2 -fwrapv -I $codec (Join-Path $root 'tests/imbe_unity_probe.cpp') @referenceSources -o (Join-Path $build 'stream-reference.exe')
if ($LASTEXITCODE -ne 0) { throw 'Independent long-stream reference build failed' }
& (Join-Path $build 'stream-reference.exe') (Join-Path $build 'stream.s16le') (Join-Path $build 'stream-reference.imbe')
if ($LASTEXITCODE -ne 0) { throw 'Streaming reference encode failed' }
if ((Get-FileHash (Join-Path $build 'stream.imbe')).Hash -ne (Get-FileHash (Join-Path $build 'stream-reference.imbe')).Hash) { throw 'Streaming reference mismatch including silence padding' }
& python (Join-Path $root 'tests/check_imbe_stream.py')
if ($LASTEXITCODE -ne 0) { throw 'Full-stream checksum gate failed' }
$upstream = Join-Path $root 'external/RadioFoundry/RadioFoundry'
$includes = @('hal','core','drivers','boards/dm32','platform/hrc7000','platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include') | ForEach-Object { '-I' + (Join-Path $upstream $_) }
& gcc -std=gnu11 -O1 -Wall -Wextra -Werror -Wno-unused-parameter -I (Join-Path $root 'tests/diag-stubs') '-DBENCH_GIT="host-bench-test"' -DCONFIG_DMR=1 @includes -I (Join-Path $root 'src/firmware') (Join-Path $root 'tests/test_imbe_benchmark.c') -o (Join-Path $build 'model.exe')
if ($LASTEXITCODE -ne 0) { throw 'Benchmark model build failed' }
& (Join-Path $build 'model.exe')
if ($LASTEXITCODE -ne 0) { throw 'Benchmark model checks failed' }
& python (Join-Path $root 'tests/test_imbe_host.py')
if ($LASTEXITCODE -ne 0) { throw 'Benchmark host control checks failed' }
& gcc -std=gnu11 -O1 -Wall -Wextra -Werror -Wno-unused-parameter -I (Join-Path $root 'tests/diag-stubs') '-DBENCH_GIT="host-mic-test"' -DCONFIG_DMR=1 @includes -I (Join-Path $root 'src/firmware') -I (Join-Path $root 'fixtures/p25-1011') (Join-Path $root 'tests/test_imbe_mic.c') (Join-Path $root 'src/firmware/p25_live_frame.c') -o (Join-Path $build 'mic-model.exe')
if ($LASTEXITCODE -ne 0) { throw 'Microphone model build failed' }
& (Join-Path $build 'mic-model.exe')
if ($LASTEXITCODE -ne 0) { throw 'Microphone model checks failed' }
& gcc -std=c11 -O2 -Wall -Wextra -Werror -I (Join-Path $root 'src/firmware') -I (Join-Path $root 'fixtures/p25-1011') -c (Join-Path $root 'src/firmware/p25_live_frame.c') -o (Join-Path $build 'live-frame.o')
if ($LASTEXITCODE -ne 0) { throw 'Live framing C build failed' }
& g++ -std=c++17 -O2 -I (Join-Path $root 'src/firmware') -I (Join-Path $root 'fixtures/p25-1011') -I (Join-Path $root 'research/references/boatbod/op25/op25/gr-op25_repeater/lib') (Join-Path $root 'tests/test_p25_live_frame.cpp') (Join-Path $build 'live-frame.o') -o (Join-Path $build 'live-frame.exe')
if ($LASTEXITCODE -ne 0) { throw 'Live framing comparison build failed' }
& (Join-Path $build 'live-frame.exe')
if ($LASTEXITCODE -ne 0) { throw 'Live framing reference mismatch' }
& python (Join-Path $root 'tests/test_imbe_mic_host.py')
if ($LASTEXITCODE -ne 0) { throw 'Microphone host checks failed' }
