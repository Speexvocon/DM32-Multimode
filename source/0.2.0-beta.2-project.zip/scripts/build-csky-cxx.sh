#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-or-later
# Add only GCC's C++ frontend; no libstdc++, exceptions or target runtime needed.
set -euo pipefail
prefix="$HOME/toolchains/csky-elf"
src="$HOME/toolchains/cxx-src"
export PATH="$prefix/bin:$PATH"
if command -v csky-elf-g++ >/dev/null && test -f "$(csky-elf-g++ -print-prog-name=cc1plus)"; then exit 0; fi
mkdir -p "$src"
cd "$src"
curl -fL --retry 3 -o gcc-14.2.0.tar.xz https://ftp.gnu.org/gnu/gcc/gcc-14.2.0/gcc-14.2.0.tar.xz
echo 'a7b39bc69cbf9e25826c5a60ab26477001f7c08d85cec04bc0e29cabed6f3cc9  gcc-14.2.0.tar.xz' | sha256sum -c -
tar xf gcc-14.2.0.tar.xz
mkdir -p build
cd build
../gcc-14.2.0/configure --target=csky-elf --prefix="$prefix" --enable-languages=c,c++ \
  --without-headers --with-newlib --disable-nls --disable-shared --disable-threads \
  --disable-libssp --disable-libquadmath --disable-libgomp --disable-libatomic
make -j"$(nproc)" all-gcc
make install-strip-gcc
csky-elf-g++ --version
