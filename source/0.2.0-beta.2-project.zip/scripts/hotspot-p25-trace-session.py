#!/usr/bin/env python3
"""Prepare (default), or explicitly run a bounded receive-only MMDVMHost trace.

Run on the Linux hotspot as root. Original configuration is never edited.
Private config/log files may contain credentials: only report.json is sanitized.
"""
import argparse
import configparser
import hashlib
import io
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

UNITS = ("pistar-watchdog.timer", "pistar-watchdog.service", "mmdvmhost.timer",
         "p25gateway.timer", "mmdvmhost.service", "p25gateway.service")
MODES = {"d-star", "dstar", "dmr", "system fusion", "ysf", "nxdn", "pocsag",
         "fm", "ax.25", "m17"}
PROFILE_KEYS = {
    "General": ("Callsign", "Id", "Duplex"),
    "Info": ("RXFrequency", "TXFrequency"),
    "Modem": ("RXFrequency", "TXFrequency", "RXOffset", "TXOffset", "RXLevel",
              "TXLevel", "P25TXLevel", "RXInvert", "TXInvert", "PTTInvert",
              "RFLevel", "Protocol"),
    "P25": ("NAC", "SelfOnly", "OverrideUIDCheck", "RemoteGateway"),
}
CALL_FLUSH_SECONDS = 1.25
LOG_MESSAGE = re.compile(r"^M:\s+\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3}\s+(.*)$")
RF_START = re.compile(r"^P25, received RF voice transmission from (.+?) to (.+)$")
RF_END = re.compile(r"^P25, received RF end of voice transmission from (.+?) to (.+?), "
                    r"\d+(?:\.\d+)? seconds, BER: \d+(?:\.\d+)?%$")
RF_LOST = re.compile(r"^P25, RF transmission lost, \d+(?:\.\d+)? seconds, BER: \d+(?:\.\d+)?%$")
RF_LOST_IDENTITY = re.compile(r"^P25, transmission lost from (.+?) to (.+?), "
                              r"\d+(?:\.\d+)? seconds, BER: \d+(?:\.\d+)?%$")


class RFCallCompletion:
    """Recognize one known voice start followed by its real RF end or loss.

    Network/other-mode logs, raw trace labels and generic shutdown text never
    arm or complete this state. Unknown/ambiguous starts retain the deadline.
    """
    def __init__(self):
        self.identity = None
        self.ambiguous_start = False
        self.termination = None

    def feed(self, line):
        match = LOG_MESSAGE.fullmatch(line.rstrip("\r\n"))
        if not match or self.termination is not None:
            return None
        body = match[1]
        start = RF_START.fullmatch(body)
        if start:
            if self.identity is not None:
                self.ambiguous_start = True
                return None
            self.identity = start.groups()
            return "start"
        if self.identity is None or self.ambiguous_start:
            return None
        end = RF_END.fullmatch(body)
        lost = RF_LOST_IDENTITY.fullmatch(body)
        if end and end.groups() == self.identity:
            self.termination = "end"
        elif (lost and lost.groups() == self.identity) or RF_LOST.fullmatch(body):
            self.termination = "lost"
        return self.termination


def capture_until_call(child, logfile, seconds):
    """Poll only our private stdout; hard deadline includes any flush linger."""
    deadline = time.monotonic() + seconds
    completion = RFCallCompletion()
    terminal_seen = None
    buffer = b""
    reason = "capture_deadline"
    linger_complete = False
    with open(logfile, "rb") as observed:
        while True:
            if child.poll() is not None:
                reason = "host_exited"
                break
            buffer += observed.read()
            complete_lines = buffer.split(b"\n")
            buffer = complete_lines.pop()
            if len(buffer) > 1024 * 1024:
                raise RuntimeError("Host stdout has an oversized incomplete line")
            for line in complete_lines:
                event = completion.feed(line.decode("utf-8", errors="replace"))
                if event == "start":
                    print(json.dumps({"event": "rf_call_started", "epoch": time.time()}), flush=True)
                elif event in ("end", "lost") and terminal_seen is None:
                    terminal_seen = time.monotonic()
                    print(json.dumps({"event": "rf_call_terminal", "termination": event,
                                      "flush_linger_seconds": CALL_FLUSH_SECONDS,
                                      "epoch": time.time()}), flush=True)
            now = time.monotonic()
            if now >= deadline:
                break
            if terminal_seen is not None and now - terminal_seen >= CALL_FLUSH_SECONDS:
                reason = "rf_call_" + completion.termination
                linger_complete = True
                break
            wait = min(0.1, deadline - now)
            if terminal_seen is not None:
                wait = min(wait, CALL_FLUSH_SECONDS - (now - terminal_seen))
            time.sleep(wait)
    return {"duration_limit_reached": reason == "capture_deadline",
            "stop_reason": reason, "stop_after_call_satisfied": linger_complete,
            "rf_call_started": completion.identity is not None,
            "rf_call_termination": completion.termination,
            "rf_call_ambiguous_start": completion.ambiguous_start,
            "flush_linger_seconds": CALL_FLUSH_SECONDS,
            "flush_linger_completed": linger_complete}


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def error_metadata(error):
    """Keep filesystem error facts without paths, command text or credentials."""
    result = {"error_type": type(error).__name__}
    if isinstance(getattr(error, "errno", None), int):
        result["error_errno"] = error.errno
    return result


def transform_config(raw, output):
    config = configparser.ConfigParser(interpolation=None, strict=True)
    config.optionxform = str
    config.read_string(raw)
    if not all(s in config for s in ("General", "Modem", "P25")):
        raise ValueError("Missing required General, Modem or P25 section")
    # Match installed host's case-sensitive key spelling, and reject ambiguous
    # differently-cased duplicates rather than accidentally retaining Enable=1.
    for section in config.sections():
        names = [k.casefold() for k in config[section]]
        if len(names) != len(set(names)):
            raise ValueError("Ambiguous duplicate configuration keys")

    def put(section, key, value):
        if section not in config:
            config.add_section(section)
        for old in list(config[section]):
            if old.casefold() == key.casefold():
                config.remove_option(section, old)
        config.set(section, key, str(value))

    for section in config.sections():
        normalized = section.casefold().replace(" ", "")
        if (section.casefold() in MODES or "network" in normalized or
                normalized in ("cwid", "remotecontrol", "transparent") or
                (section != "P25" and any(key.casefold() == "enable" for key in config[section]))):
            # Disable unknown/optional enabled subsystems too. This is a host
            # receive trace, so no auxiliary mode, remote command or network
            # may initiate a transmission. Display extras can stay disabled.
            put(section, "Enable", 0)
    put("P25", "Enable", 1)
    put("CW Id", "Enable", 0)
    put("P25 Network", "Enable", 0)
    put("General", "Daemon", 0)
    put("Modem", "Trace", 1)
    put("Log", "FileLevel", 1)
    put("Log", "DisplayLevel", 1)
    put("Log", "FilePath", str(output))
    put("Log", "FileRoot", "trace")
    profile = {section: {key: config[section][key] for key in keys
                         if section in config and key in config[section]}
               for section, keys in PROFILE_KEYS.items()}
    buffer = io.StringIO()
    config.write(buffer, space_around_delimiters=False)
    return buffer.getvalue(), profile


class System:
    def active(self, unit):
        result = subprocess.run(["systemctl", "is-active", "--quiet", unit],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                timeout=15)
        if result.returncode not in (0, 3, 4):
            raise RuntimeError("Cannot query service state")
        return result.returncode == 0

    def service(self, action, unit):
        subprocess.run(["systemctl", action, unit], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)

    def manual_hosts(self):
        found = []
        for entry in Path("/proc").iterdir():
            if not entry.name.isdigit():
                continue
            try:
                command = (entry / "cmdline").read_bytes().split(b"\0")[0]
                if Path(os.fsdecode(command)).name == "MMDVMHost":
                    found.append(int(entry.name))
            except (FileNotFoundError, ProcessLookupError):
                continue
        return found

    def run_host(self, binary, config, seconds, output, stop_after_call=False):
        # A new process group allows bounded cleanup of descendants as well.
        with open(output / "host-stdout.log", "xb") as log:
            child = subprocess.Popen([str(binary), str(config)], stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            timed_out = False
            call_result = {}
            try:
                startup_deadline = time.monotonic() + 25
                ready = False
                while time.monotonic() < startup_deadline:
                    if child.poll() is not None:
                        raise RuntimeError("Host exited during initialization")
                    with open(output / "host-stdout.log", "rb") as observed:
                        observed.seek(max(0, os.fstat(observed.fileno()).st_size - 65536))
                        ready = any(b"MMDVMHost" in line and b"is running" in line
                                    for line in observed.read().splitlines())
                    if ready:
                        break
                    time.sleep(0.1)
                if not ready:
                    raise RuntimeError("Host initialization deadline exceeded")
                # The physical transmit cue follows this event. Count the
                # finite receive window from readiness, not process startup.
                print(json.dumps({"event": "host_ready", "capture_seconds": seconds,
                                  "stop_after_call": stop_after_call,
                                  "epoch": time.time()}), flush=True)
                if stop_after_call:
                    call_result = capture_until_call(child, output / "host-stdout.log", seconds)
                    timed_out = call_result["duration_limit_reached"]
                else:
                    try:
                        child.wait(timeout=seconds)
                    except subprocess.TimeoutExpired:
                        timed_out = True
            finally:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=3)
            return {"exit_status": child.returncode, "duration_limit_reached": timed_out,
                    "host_ready": ready, **call_result}


def execute_capture(system, binary, alternate, source, output, seconds, report,
                    stop_after_call=False):
    """Always restore the complete original active set, including start failures."""
    report["active_before"] = {unit: system.active(unit) for unit in UNITS}
    report["cleanup_errors"] = []
    report["command"] = [str(binary), str(alternate)]
    report["host"] = {"exit_status": None, "duration_limit_reached": False}
    try:
        for unit in UNITS:
            system.service("stop", unit)
        if any(system.active(unit) for unit in UNITS):
            raise RuntimeError("A managed service remains active")
        if system.manual_hosts():
            raise RuntimeError("Unmanaged MMDVMHost process present; capture refused")
        if stop_after_call:
            report["host"] = system.run_host(binary, alternate, seconds, output, stop_after_call=True)
        else:
            report["host"] = system.run_host(binary, alternate, seconds, output)
        call_finished = stop_after_call and report["host"].get("stop_after_call_satisfied", False)
        if not report["host"]["duration_limit_reached"] and not call_finished:
            raise RuntimeError("Host exited before requested capture duration")
    finally:
        # Timers are restored last, after their services. Inactive units were
        # stopped above; leave them inactive instead of enabling extra services.
        for unit in reversed(UNITS):
            if report["active_before"][unit]:
                try:
                    system.service("start", unit)
                except BaseException as error:
                    report["cleanup_errors"].append(type(error).__name__ + ": start " + unit)
        report["active_after"] = {}
        for unit in UNITS:
            try:
                report["active_after"][unit] = system.active(unit)
            except BaseException as error:
                report["active_after"][unit] = None
                report["cleanup_errors"].append(type(error).__name__ + ": query " + unit)
        report["services_restored"] = report["active_before"] == report["active_after"]
        try:
            report["original_config_unchanged"] = digest(source) == report["original_config_sha256"]
        except BaseException as error:
            report["original_config_unchanged"] = None
            report["config_verification_error"] = error_metadata(error)
            raise


def checked_file(value, executable=False):
    path = Path(value)
    if not path.is_absolute() or path.is_symlink() or path.resolve() != path:
        raise ValueError("Input paths must be absolute, canonical and not symlinks")
    if not path.is_file() or (executable and not os.access(path, os.X_OK)):
        raise ValueError("Input file missing or not executable")
    return path


def options(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="/etc/mmdvmhost")
    parser.add_argument("--binary", default="/usr/local/bin/MMDVMHost")
    parser.add_argument("--output", required=True,
                        help="new absolute private directory; must not already exist")
    parser.add_argument("--capture", type=int, metavar="SECONDS",
                        help="explicitly run host for 5..180 seconds (up to 600 with --stop-after-call); default prepare only")
    parser.add_argument("--stop-after-call", action="store_true",
                        help="receive-only: stop after one RF voice call ends/is lost and a 1.25-second flush linger")
    args = parser.parse_args(argv)
    if args.stop_after_call and args.capture is None:
        parser.error("--stop-after-call requires --capture")
    limit = 600 if args.stop_after_call else 180
    if args.capture is not None and not 5 <= args.capture <= limit:
        parser.error("--capture must be 5.." + str(limit) + " seconds")
    return args


def main(argv=None):
    args = options(argv)
    if os.name != "posix" or not hasattr(os, "geteuid") or os.geteuid() != 0:
        argparse.ArgumentParser(description=__doc__).error("Run on the Linux hotspot with sudo/root")
    report = {"mode": "capture" if args.capture else "prepare",
              "requested_seconds": args.capture, "stop_after_call": args.stop_after_call,
              "started_epoch": time.time()}
    output = None
    try:
        source = checked_file(args.config)
        binary = checked_file(args.binary, executable=True)
        output = Path(args.output)
        if (not output.is_absolute() or output.exists() or output.is_symlink() or
                output.parent.resolve() != output.parent or not output.parent.is_dir()):
            raise ValueError("Output must be a new directory below a canonical existing parent")
        # Lock is shared across prepare/capture runs and held until restoration.
        import fcntl
        with open("/run/lock/dm32-p25-session.lock", "a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            os.umask(0o077)
            output.mkdir(mode=0o700)
            original = source.read_bytes()
            report["original_config_sha256"] = hashlib.sha256(original).hexdigest()
            report["binary_sha256"] = digest(binary)
            prepared, report["selected_profile"] = transform_config(original.decode("utf-8"), output)
            (output / "original-config.private.ini").write_bytes(original)
            alternate = output / "trace-config.private.ini"
            alternate.write_text(prepared, encoding="utf-8")
            if args.capture:
                def interrupted(signum, frame):
                    # One signal enters orderly cleanup; repeated signals must
                    # not interrupt restoration of the owner's services.
                    for pending in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
                        signal.signal(pending, signal.SIG_IGN)
                    raise InterruptedError("Signal " + str(signum))
                for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
                    signal.signal(signum, interrupted)
                try:
                    execute_capture(System(), binary, alternate, source, output,
                                    args.capture, report, stop_after_call=args.stop_after_call)
                finally:
                    # Ignore repeated termination signals while report is saved.
                    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
                        signal.signal(signum, signal.SIG_IGN)
            else:
                report["original_config_unchanged"] = digest(source) == report["original_config_sha256"]
            report["result"] = "complete"
    except BaseException as error:
        # Exception messages from configparser or commands may reveal secrets.
        report["result"] = "failed"
        report.update(error_metadata(error))
    finally:
        report["finished_epoch"] = time.time()
    okay = (report.get("result") == "complete" and report.get("original_config_unchanged") and
            not report.get("cleanup_errors") and report.get("services_restored", True))
    report["result"] = "complete" if okay else "failed"
    report_written = False
    if output is not None and "original_config_sha256" in report:
        try:
            if not output.is_dir():
                raise FileNotFoundError()
            (output / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
            report_written = True
        except BaseException as error:
            # Cleanup/call evidence must still reach stdout if storage fails.
            report["result"] = "failed"
            report["report_write_error"] = error_metadata(error)
            okay = False
    summary = {"result": report["result"], "mode": report["mode"],
               "report_written": report_written}
    for key in ("services_restored", "original_config_unchanged", "error_type", "error_errno",
                "config_verification_error", "report_write_error"):
        if key in report:
            summary[key] = report[key]
    if "host" in report:
        # Fixed fields keep the fallback bounded and exclude log identities.
        summary["host"] = {key: report["host"][key] for key in (
            "exit_status", "duration_limit_reached", "host_ready", "stop_reason",
            "stop_after_call_satisfied", "rf_call_started", "rf_call_termination",
            "rf_call_ambiguous_start", "flush_linger_seconds", "flush_linger_completed")
            if key in report["host"]}
    print(json.dumps(summary), flush=True)
    return 0 if okay else 1


if __name__ == "__main__":
    sys.exit(main())
