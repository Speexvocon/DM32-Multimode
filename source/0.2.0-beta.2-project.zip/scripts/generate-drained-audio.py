"""Generate a drained native audio host with a consumed-IRQ PCM speaker backend.

The microphone path, codec callback and public HAL retain their upstream roles;
the prompt FIFO speaker consumer is deliberately replaced with the validated
80-sample dedicated PCM window and consumed interrupt. Mode handoffs drain task
work without editing the pinned RadioFoundry checkout or IRQ-masking codec and
board routing. A callback may stop itself but cannot restart its own worker.
"""
import argparse
import hashlib
from pathlib import Path

PINNED_SOURCE_SHA256 = "54930930e331ff24e2bf8946529657a85720cac38566d77f8e3d9b11729073af"


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Pinned PCM wrapper structure changed: " + old[:70])
    return text.replace(old, new, 1)


def generate(text):
    text = text.replace("\r\n", "\n")
    if hashlib.sha256(text.encode()).hexdigest() != PINNED_SOURCE_SHA256:
        raise ValueError("PCM driver source does not match the reviewed upstream pin")
    speaker_comment = text.index("// HR_C7000 PCM audio")
    meter_comment = text.index("// Mic level for VOX", speaker_comment)
    text = text[:speaker_comment] + '''// Generated native audio host: upstream microphone PCM and task codec callback,
// with the speaker prompt FIFO replaced by the dedicated little-endian PCM
// window at C7_PCM_SPK_ADDR. PCM_RD acknowledges each consumed 80-sample half;
// only task context runs codecs and board routing. See radio_pcm_output.h.
// The original source remains SHA-pinned by generate-drained-audio.py.
//
''' + text[meter_comment:]
    text = replace_once(text, '#include "audio_pcm.h"', '#include "audio_pcm.h"\n#include "hal_time.h"\n#include "radio_dmr_metrics.h"')
    text = replace_once(text, "static volatile bool running;", """static volatile bool running;
// Covers the complete task work unit: output, callback, publication and output.
// stop closes admission under the same short interrupt lock, then drains it.
static volatile bool worker_active;
static volatile bool stopping;""")
    text = replace_once(text, "static uint8_t spk_pos;", "static volatile uint8_t spk_pos;")
    text = replace_once(text, "static bool spk_routed;", "static volatile bool spk_routed;")
    text = replace_once(text, "static bool isr_registered;", """static bool isr_registered;
static radio_dmr_audio_diag_t audio_diag;
static uint32_t service_last_us, callback_last_us;
static bool service_seen, callback_seen;

void hrc_audio_pcm_diag(radio_dmr_audio_diag_t *out)
{
    if (out == NULL) return;
    uint32_t s = hrc_irq_save();
    *out = audio_diag;
    out->blocks = blocks;
    out->overruns = overruns;
    out->underruns = underruns;
    hrc_irq_restore(s);
}""")
    start = text.index("// Push 32-sample chunks")
    end = text.index("\nvoid hrc_audio_pcm_attach", start)
    text = text[:start] + '''#include "radio_pcm_output.h"

static void audio_work_once(void)
{
    static int16_t mic[AUDIO_BLOCK_SAMPLES];
    static int16_t speaker_block[AUDIO_BLOCK_SAMPLES];
    uint32_t started = hal_micros();
    uint32_t s = hrc_irq_save();
    if (!running || stopping) { hrc_irq_restore(s); return; }
    worker_active = true;
    worker_epoch = output_epoch;
    int8_t idx = mic_ready;
    audio_block_cb_t cb = block_cb;
    void *ctx = block_ctx;
    if (idx >= 0) {
        memcpy(mic, mic_blk[idx], sizeof mic);
        mic_ready = -1;
    }
    hrc_irq_restore(s);
    if (service_seen) {
        uint32_t gap = started - service_last_us;
        if (gap > audio_diag.service_gap_max_us) audio_diag.service_gap_max_us = gap;
    }
    service_last_us = started;
    service_seen = true;
    speaker_output_service();
    if (idx >= 0 && cb != NULL && running && !stopping) {
        uint32_t callback_started = hal_micros();
        if (callback_seen) {
            uint32_t gap = callback_started - callback_last_us;
            if (gap > audio_diag.callback_gap_max_us) audio_diag.callback_gap_max_us = gap;
        }
        callback_last_us = callback_started;
        callback_seen = true;
        cb(mic, speaker_block, ctx);
        speaker_output_publish(speaker_block, worker_epoch);
        blocks++;
        radio_dmr_cost_record(&audio_diag.callback, hal_micros() - callback_started);
    }
    if (running && !stopping) speaker_output_service();
    radio_dmr_cost_record(&audio_diag.service, hal_micros() - started);
    s = hrc_irq_save();
    worker_active = false;
    hrc_irq_restore(s);
}
static void audio_task(void *arg)
{
    (void)arg;
    for (;;) {
        ulTaskNotifyTake(pdTRUE, spk_routed ? pdMS_TO_TICKS(2) : portMAX_DELAY);
        audio_work_once();
    }
}
''' + text[end:]
    text = replace_once(text, "\tfifo_held = on;", """    uint32_t s = hrc_irq_save();
    fifo_held = on;
    ++output_epoch;
    if (on) speaker_output_cancel();
    hrc_irq_restore(s);""")
    start = text.index("static bool start(audio_block_cb_t cb, void *ctx)")
    end = text.index("\nstatic void stop(void)", start)
    text = text[:start] + '''static void stream_stop(bool block_output);
static bool start(audio_block_cb_t cb, void *ctx)
{
    // Waiting here from inside our callback would deadlock on ourselves.
    // Stream replacement/mode ownership belongs to the controller task.
    if (cb == NULL || (worker_active && xTaskGetCurrentTaskHandle() == task)) return false;
    stream_stop(false);
    if (task == NULL) {
        isr_register();
        if (xTaskCreate(audio_task, "audio", AUDIO_TASK_STACK, NULL, AUDIO_TASK_PRIORITY, &task) != pdPASS) {
            task = NULL;
            return false;
        }
    }
    uint32_t s = hrc_irq_save();
    // P25 replaces this vector; rebind it on every native stream start.
    hrc_irq_register(IRQ_PCM_RD, isr_pcm_rd);
    hrc_irq_enable(IRQ_PCM_RD, false);
    block_ctx = ctx;
    block_cb = cb;
    mic_fill = mic_half = 0;
    mic_ready = -1;
    spk_head = spk_tail = spk_pos = 0;
    output_pending = output_wanted = output_starved = false;
    // Keep costs across a TX-to-RX stream restart. Stopped time is not a gap.
    service_seen = callback_seen = false;
    stopping = false;
    running = true;
    hrc7000_wr(modem, C7_INTERP_CLEAR, C7_INT_PCM_WR);
    hrc_irq_enable(IRQ_PCM_WR, true);
    hrc7000_audio_bits(modem, C7_AUDIO_PCM_MIC, 0);
    hrc_irq_restore(s);
    return true;
}
''' + text[end:]
    text = replace_once(text, "static void stop(void)\n{", "static void stream_stop(bool block_output)\n{")
    text = replace_once(text, "\trunning = false;\n\tblock_cb = NULL;", """\tstopping = true;
    running = false;
    block_cb = NULL;
    ++output_epoch;
    if (block_output) output_blocked = true;
    output_wanted = false;
    speaker_output_cancel();
    // The route closes after any in-flight worker finishes its board hook.""")
    text = replace_once(text, "\thrc_irq_restore(s);\n}\n\n// Speaker PCM:", '''\thrc_irq_restore(s);
    // A callback may stop itself. It cannot drain its own stack, so the worker
    // suppresses the remainder and a new start is refused until it unwinds.
    if (xTaskGetCurrentTaskHandle() != task)
        while (worker_active) vTaskDelay(1);
    s = hrc_irq_save();
    bool off = spk_routed;
    spk_routed = false;
    hrc_irq_restore(s);
    if (off && speaker_pcm_cb != NULL) speaker_pcm_cb(false);
}
static void stop(void) { stream_stop(true); }

// Speaker PCM:''')
    start = text.index("// Speaker PCM:")
    end = text.index("\nconst hal_audio_t hrc_audio_pcm", start)
    text = text[:start] + '''// Native routing is requested by callbacks and applied by the audio task;
// ordinary call end drains its finite PCM tail. A stopped native host forwards
// external P25 route hooks without owning that mode's consumed interrupt.
static void speaker_pcm(bool on)
{
    bool in_worker = worker_active && xTaskGetCurrentTaskHandle() == task;
    uint32_t s = hrc_irq_save();
    if (in_worker && (stopping || worker_epoch != output_epoch)) {
        hrc_irq_restore(s);
        return;
    }
    if (in_worker && running) {
        // Ordinary call end drains every published sample, including the
        // current hardware half; the amplifier changes in task context.
        output_wanted = on;
        hrc_irq_restore(s);
        return;
    }
    if (running && !on) {
        output_wanted = false;
        hrc_irq_restore(s);
        hrc_audio_pcm_output_abort();
        return;
    }
    if (running && output_blocked) { hrc_irq_restore(s); return; }
    if (running && on) {
        output_wanted = true;
        hrc_irq_restore(s);
        return;
    }
    bool changed = on != spk_routed;
    spk_routed = on;
    hrc_irq_restore(s);
    // External P25 routing uses this hook with native streaming stopped.
    // Its dedicated consumer retains all PCM IRQ/playback-bit ownership.
    if (changed && speaker_pcm_cb != NULL) speaker_pcm_cb(on);
}
''' + text[end:]
    return '// Generated by scripts/generate-drained-audio.py; do not edit.\n' + text


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    a = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = a.output.resolve()
    if not output.is_relative_to((root / "build").resolve()):
        p.error("generated PCM driver must be under the ignored project build directory")
    generated = generate(a.source.read_text())
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(generated, newline="\n")


if __name__ == "__main__":
    main()
