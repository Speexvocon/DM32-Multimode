"""Move all codec object code and constant sections into startup-copied RAM."""
import argparse
from pathlib import Path
import struct
import subprocess

def sections(data):
    if data[:6] != b'\x7fELF\x01\x01' or struct.unpack_from('<H', data, 18)[0] != 252:
        raise ValueError('Expected ELF32 little-endian C-SKY object')
    offset = struct.unpack_from('<I', data, 32)[0]
    size, count, strings = struct.unpack_from('<HHH', data, 46)
    headers = [struct.unpack_from('<10I', data, offset + i * size) for i in range(count)]
    table = headers[strings]
    names = data[table[4]:table[4] + table[5]]
    result = []
    for header in headers:
        name = names[header[0]:].split(b'\0', 1)[0].decode('ascii')
        if header[5] and header[2] & 2 and any(name == prefix or name.startswith(prefix + '.') for prefix in ('.text', '.rodata', '.srodata')):
            result.append(name)
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('objcopy')
    parser.add_argument('object', type=Path)
    args = parser.parse_args()
    names = sections(args.object.read_bytes())
    if names:
        command = [args.objcopy]
        for name in names:
            command += ['--rename-section', name + '=.ramfunc.imbe_all' + name]
        subprocess.run(command + [str(args.object)], check=True)
        if sections(args.object.read_bytes()):
            raise ValueError('Codec code/constant sections remain outside RAM placement')
    print(f'{args.object.name}: relocated {len(names)} code/constant sections')
