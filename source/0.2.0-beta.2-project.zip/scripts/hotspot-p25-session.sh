#!/bin/bash
# Temporary local test session; run on WPSD as root. Restore previously active
# services on success, error, or normal shell termination. No persistent config edits.
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [[ ${EUID} -ne 0 ]]; then echo 'Run with sudo' >&2; exit 1; fi
if [[ $# -lt 1 || $# -gt 3 || ! $1 =~ ^[0-9]+$ ]]; then echo 'Usage: hotspot-p25-session.sh FREQUENCY_HZ [LEAD_IN_SECONDS [NAMED_CASE]]' >&2; exit 1; fi
lead_in=${2:-0}
if [[ ! $lead_in =~ ^([0-9]|[12][0-9]|30)$ ]]; then echo 'Lead-in must be 0..30 seconds' >&2; exit 1; fi
fixture_case=${3:-clear}
case "$fixture_case" in
    clear) fixture=call.bin ;;
    encrypted-hdu|unsupported-lc|damaged-hdu|damaged-lc|damaged-ess|late-entry) fixture="$fixture_case.bin" ;;
    *) echo 'Unknown named fixture case' >&2; exit 1 ;;
esac
# Validate the pinned bytes offline before stopping or querying any service.
python3 hotspot-p25-replay.py --fixture "$fixture" --case "$fixture_case" --pairs 14
units=(pistar-watchdog.timer pistar-watchdog.service mmdvmhost.timer p25gateway.timer mmdvmhost.service p25gateway.service)
active=()
for unit in "${units[@]}"; do
    if systemctl is-active --quiet "$unit"; then active+=("$unit"); fi
done
stamp=$(date -u +%Y%m%dT%H%M%SZ)
mkdir -m 700 "session-$stamp"
cp /etc/mmdvmhost /etc/p25gateway "session-$stamp/"
sha256sum /etc/mmdvmhost /etc/p25gateway > "session-$stamp/config-before.sha256"
printf '%s\n' "${active[@]}" > "session-$stamp/active-services.txt"
restore() {
    result=$?
    trap - EXIT
    # Allow the modem watchdog and remaining finite buffers to settle.
    sleep 3
    for ((i=${#active[@]}-1; i>=0; i--)); do
        systemctl start "${active[i]}" || result=1
    done
    sha256sum -c "session-$stamp/config-before.sha256" || result=1
    exit "$result"
}
trap restore EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP
for unit in "${units[@]}"; do systemctl stop "$unit"; done
timeout --signal=TERM --kill-after=3 "$((25 + lead_in))" python3 hotspot-p25-replay.py \
    --fixture "$fixture" --case "$fixture_case" --pairs 14 --frequency "$1" --rf-power 10 --lead-in-seconds "$lead_in" --transmit \
    2>&1 | tee "session-$stamp/replay.jsonl"
