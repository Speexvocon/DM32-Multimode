$ErrorActionPreference='Stop'
$build='build/p25-rx'
New-Item -ItemType Directory -Force $build | Out-Null
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -c src/firmware/p25_rx.c -o "$build/rx.o"
if($LASTEXITCODE -ne 0){throw 'RX FEC build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/test_demod_math.c -o "$build/demod-math.exe"
if($LASTEXITCODE -ne 0){throw 'Demod arithmetic build failed'}
& "$build/demod-math.exe"
if($LASTEXITCODE -ne 0){throw 'Demod arithmetic differential test failed'}
foreach($name in @('p25_demod','p25_receive_bench')) {
    & gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -c "src/firmware/$name.c" -o "$build/$name.o"
    if($LASTEXITCODE -ne 0){throw "Build failed: $name"}
}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware src/host/p25_demod_replay.c "$build/p25_demod.o" "$build/rx.o" -o "$build/demod.exe"
if($LASTEXITCODE -ne 0){throw 'Demod replay build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/test_p25_demod.c "$build/p25_demod.o" "$build/rx.o" -o "$build/demod-test.exe"
if($LASTEXITCODE -ne 0){throw 'Demod discontinuity test build failed'}
& "$build/demod-test.exe"
if($LASTEXITCODE -ne 0){throw 'Demod discontinuity test failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -Ifixtures/p25-1011 tests/test_demod_candidates.c src/firmware/p25_live_frame.c "$build/rx.o" -o "$build/demod-candidates.exe"
if($LASTEXITCODE -ne 0){throw 'Demod candidate arbitration build failed'}
& "$build/demod-candidates.exe"
if($LASTEXITCODE -ne 0){throw 'Demod candidate arbitration regression failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/test_receive_bench.c "$build/p25_receive_bench.o" "$build/p25_demod.o" "$build/rx.o" -o "$build/receive-test.exe"
if($LASTEXITCODE -ne 0){throw 'Receive yield test build failed'}
& "$build/receive-test.exe"
if($LASTEXITCODE -ne 0){throw 'Receive yield/time accounting test failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Itests/reference -Isrc/firmware src/host/p25_demod_replay.c tests/reference/p25_demod_reference.c tests/reference/p25_rx_reference.c -o "$build/demod-reference.exe"
if($LASTEXITCODE -ne 0){throw 'Frozen demod reference build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/demod_frame_probe.c "$build/p25_demod.o" "$build/rx.o" -o "$build/demod-frames.exe"
if($LASTEXITCODE -ne 0){throw 'Complete-frame demod probe build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Itests/reference -Isrc/firmware tests/demod_frame_probe.c tests/reference/p25_demod_reference.c tests/reference/p25_rx_reference.c -o "$build/demod-frames-reference.exe"
if($LASTEXITCODE -ne 0){throw 'Frozen complete-frame demod probe build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -Dp25_rx_init=reference_init -Dp25_rx_gap=reference_gap -Dp25_rx_push=reference_push -Dp25_rx_voice=reference_voice -c tests/reference/p25_rx_reference.c -o "$build/rx-reference.o"
if($LASTEXITCODE -ne 0){throw 'FEC reference build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/test_rx_equivalence.c "$build/rx.o" "$build/rx-reference.o" -o "$build/rx-equivalence.exe"
if($LASTEXITCODE -ne 0){throw 'FEC differential build failed'}
& "$build/rx-equivalence.exe"
if($LASTEXITCODE -ne 0){throw 'FEC differential test failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -DDM32_LAB_DIAGNOSTICS=1 tests/test_p25_monitor.c "$build/p25_demod.o" "$build/rx.o" -o "$build/monitor-test.exe"
if($LASTEXITCODE -ne 0){throw 'Monitor queue build failed'}
& "$build/monitor-test.exe"
if($LASTEXITCODE -ne 0){throw 'Monitor queue regression failed'}
$codec='research/references/nostar/imbe_vocoder'
$sources=@(Get-ChildItem $codec -Filter '*.cc' | Where-Object Name -ne 'imbe_vocoder.cc' | ForEach-Object FullName)
& g++ -std=c++17 -O2 -fwrapv -I $codec -Isrc/firmware src/host/p25_receive_replay.cpp src/firmware/imbe_bench.cpp "$build/p25_receive_bench.o" "$build/p25_demod.o" "$build/rx.o" @sources -o "$build/receive.exe"
if($LASTEXITCODE -ne 0){throw 'Receive benchmark build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -c src/firmware/p25_call.c -o "$build/call.o"
if($LASTEXITCODE -ne 0){throw 'Receive metadata build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware -c tests/p25_rx_exact_nid.c -o "$build/rx-exact-nid.o"
if($LASTEXITCODE -ne 0){throw 'Test-only exact-NID baseline build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware src/host/p25_demod_replay.c "$build/p25_demod.o" "$build/rx-exact-nid.o" -o "$build/demod-exact-nid.exe"
if($LASTEXITCODE -ne 0){throw 'Exact-NID payload differential build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/demod_frame_probe.c "$build/p25_demod.o" "$build/rx-exact-nid.o" -o "$build/demod-frames-exact-nid.exe"
if($LASTEXITCODE -ne 0){throw 'Exact-NID complete-frame differential build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/demod_nid_probe.c "$build/p25_demod.o" "$build/rx.o" "$build/call.o" -o "$build/demod-nid-probe.exe"
if($LASTEXITCODE -ne 0){throw 'Corrected NID/source qualification probe build failed'}
& gcc -std=c11 -O3 -Wall -Wextra -Werror -Isrc/firmware tests/demod_nid_probe.c "$build/p25_demod.o" "$build/rx-exact-nid.o" "$build/call.o" -o "$build/demod-nid-probe-exact.exe"
if($LASTEXITCODE -ne 0){throw 'Exact NID/source qualification probe build failed'}
& g++ -std=c++17 -O2 -fwrapv -I $codec -Isrc/firmware src/host/p25_qualified_replay.cpp src/firmware/imbe_bench.cpp "$build/rx.o" "$build/call.o" @sources -o "$build/qualified-replay.exe"
if($LASTEXITCODE -ne 0){throw 'Qualified receive replay build failed'}
# Caller selects a Python environment with numpy and scipy.
$python=if(Test-Path 'build/sdr-venv/Scripts/python.exe'){'build/sdr-venv/Scripts/python.exe'}else{'python'}
& $python tests/check_stream_demod.py
if($LASTEXITCODE -ne 0){throw 'Streaming demodulator validation failed'}
& python tests/check_qualified_receive.py
if($LASTEXITCODE -ne 0){throw 'Qualified real-codec receive validation failed'}

& g++ -std=c++17 -O2 -fwrapv -I $codec -Isrc/firmware src/host/p25_pcm_replay.cpp src/firmware/imbe_bench.cpp @sources -o "$build/pcm-replay.exe"
if($LASTEXITCODE -ne 0){throw 'PCM evidence replay build failed'}
