"""Configure volatile TX source/alignment; dry-run by default, never flashes."""
import argparse
import json
from pathlib import Path
import time


def options(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port', default='COM8')
    p.add_argument('--source', choices=('MIC', 'FIXED1011'), default='FIXED1011')
    p.add_argument('--pairs', type=int, choices=range(1, 29), default=14)
    p.add_argument('--startup-extra', type=int, choices=range(36), default=0)
    p.add_argument('--writer', choices=('DUP', 'ALT0', 'ALT1'),
                   help='optional modem writer selection; requires TXPATH-capable firmware')
    p.add_argument('--dac', choices=('KEEP', 'RESTORE'),
                   help='optional DAC preparation; requires TXPATH-capable firmware')
    p.add_argument('--apply', action='store_true', help='configure the connected, idle radio')
    p.add_argument('--session', action='store_true', help='enable fresh physical PTT after setup')
    p.add_argument('--frequency', type=int)
    p.add_argument('--allow-rf', action='store_true')
    p.add_argument('--log', type=Path)
    a = p.parse_args(argv)
    if a.apply and a.log is None:
        p.error('--apply requires a new --log path')
    if a.session and (not a.apply or not a.allow_rf or a.frequency is None or not (
            136000000 <= a.frequency <= 174000000 or 400000000 <= a.frequency <= 480000000)):
        p.error('--session requires --apply --allow-rf and a supported --frequency')
    if a.allow_rf and not a.session:
        p.error('--allow-rf requires --session')
    if a.frequency is not None and not a.session:
        p.error('--frequency applies only to --session; this tool otherwise retains the profile')
    return a


def fields(line):
    return dict(v.split('=', 1) for v in line.split()[1:] if '=' in v)


def configure(port, log, args):
    def wait(prefix, timeout=5):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            line = port.readline().decode('ascii', errors='replace').strip()
            if not line:
                continue
            log.write(json.dumps({'time_utc_epoch': time.time(), 'line': line})+'\n')
            log.flush()
            print(line, flush=True)
            if line.startswith('ERR') or line.startswith('LIVE BUSY'):
                raise RuntimeError(line)
            if line.startswith(prefix):
                return line
        raise TimeoutError('Missing response: '+prefix)

    def command(value, response):
        port.write((value+'\n').encode('ascii'))
        return wait(response)

    # Prove this is the new idle application before issuing STOP/configuration.
    needs_path = args.writer is not None or args.dac is not None
    port.write(b'STATUS\n')
    if needs_path:
        path = fields(wait('TXPATH '))
        if path.get('writer') not in ('DUP', 'ALT0', 'ALT1') or path.get('dac') not in ('KEEP', 'RESTORE'):
            raise RuntimeError('Unsupported TXPATH status; no settings changed')
    wait('TXDIAG ')
    identity = fields(wait('LIVE git='))
    if identity.get('active') != '0' or identity.get('rf') != '0':
        raise RuntimeError('Expected idle firmware')
    wait('LIVE_AUDIO ')
    command('STOP', 'OK STOP')
    try:
        if args.writer is not None:
            command('TXWRITER '+args.writer, 'OK TXWRITER')
        if args.dac is not None:
            command('TXDAC '+args.dac, 'OK TXDAC')
        command('TXSOURCE '+args.source, 'OK TXSOURCE')
        command('TXPAIRS '+str(args.pairs), 'OK TXPAIRS')
        command('TXALIGN '+str(args.startup_extra), 'OK TXALIGN')
        port.write(b'STATUS\n')
        if needs_path:
            path = fields(wait('TXPATH '))
            if (args.writer is not None and path.get('writer') != args.writer
                    or args.dac is not None and path.get('dac') != args.dac):
                raise RuntimeError('TXPATH settings readback mismatch')
        selected = fields(wait('TXDIAG '))
        if (selected.get('source') != args.source or selected.get('pairs') != str(args.pairs)
                or selected.get('startup_extra') != str(args.startup_extra)):
            raise RuntimeError('Diagnostic settings readback mismatch')
        wait('LIVE_AUDIO ')
        if args.session:
            command(f'SESSION {args.frequency} ALLOW_RF', 'OK LIVE SESSION;')
    except BaseException:
        command('STOP', 'OK STOP')
        raise


def main(argv=None):
    a = options(argv)
    print(json.dumps({'apply': a.apply, 'source': a.source, 'pairs': a.pairs,
                      'startup_extra': a.startup_extra, 'session': a.session,
                      'frequency': a.frequency, 'writer': a.writer, 'dac': a.dac}), flush=True)
    if not a.apply:
        return
    import serial
    a.log.parent.mkdir(parents=True, exist_ok=True)
    with a.log.open('x') as log, serial.Serial(a.port, 115200, timeout=.25, write_timeout=1) as port:
        configure(port, log, a)


if __name__ == '__main__':
    main()
