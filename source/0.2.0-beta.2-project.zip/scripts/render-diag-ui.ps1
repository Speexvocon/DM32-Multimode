$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$upstream = Join-Path $projectRoot 'external/RadioFoundry/RadioFoundry'
$output = Join-Path $projectRoot 'build/ui-preview'
New-Item -ItemType Directory -Force -Path $output | Out-Null
Push-Location $projectRoot
try {
    $includes = @('hal','core') | ForEach-Object { '-I' + (Join-Path $upstream $_) }
    & gcc -std=c11 -Wall -Wextra -Werror -DCONFIG_FONT_AA=1 -DGFX_INDEXED=1 -DGFX_MAX_ROWS=320 -DGFX_FB_BYTES=40960 @includes -Isrc/firmware -Ifixtures/p25-1011 tests/render_diag_ui.c src/firmware/p25_test_tx.c (Join-Path $upstream 'core/ui/gfx.c') (Join-Path $upstream 'core/ui/fonts.c') -o (Join-Path $output 'render.exe')
    if ($LASTEXITCODE -ne 0) { throw 'UI renderer build failed' }
    & (Join-Path $output 'render.exe') $output
    if ($LASTEXITCODE -ne 0) { throw 'UI renderer failed' }
} finally { Pop-Location }
