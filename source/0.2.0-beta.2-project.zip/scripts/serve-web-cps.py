"""Serve the local browser CPS on loopback; no serial access or write API."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse


class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Permissions-Policy', 'serial=(self)')
        super().end_headers()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error('Choose an unprivileged port from 1024 through 65535')
    folder = Path(__file__).resolve().parents[1] / 'integrations/web-cps'
    with ThreadingHTTPServer(('127.0.0.1', args.port), partial(Handler, directory=str(folder))) as server:
        print(f'DM32 P25 browser CPS: http://127.0.0.1:{args.port}/', flush=True)
        print('Files stay local. The browser connects to serial only when Connect is clicked.', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
