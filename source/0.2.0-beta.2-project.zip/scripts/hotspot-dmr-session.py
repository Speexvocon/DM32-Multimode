"""Guard one finite local DMR/P25 replay and restore original hotspot services.

Default validates the fixture offline. --transmit explicitly isolates the
modem, with all networks/beacons disabled in a private config, then restores
the original active service set. Original configuration is never edited.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import importlib.util


def sibling(name, key):
    spec = importlib.util.spec_from_file_location(key, Path(__file__).with_name(name))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


REPLAY = sibling('hotspot-dmr-replay.py', 'guarded_dmr_replay')
ENGINE = REPLAY.TRACE.ENGINE
SETTLE_SECONDS = 3


def fixture_frames(mode, fixture, manifest):
    if mode == 'dmr':
        return REPLAY.load_frames(fixture, manifest)
    frames = REPLAY.BASE.load_frames(fixture, 14, 'clear')
    return frames, {'fixture_sha256': REPLAY.BASE.FIXTURE_SHA, 'units': len(frames),
                    'voice_frames': 252, 'voice_s': 5.04, 'nac': '293', 'tg': 1,
                    'source': 1, 'rf_decode_verified': False}


def effective_power(mode, power):
    if not isinstance(power, int) or not 1 <= power <= 10:
        raise ValueError('RF power must be 1..10 uncalibrated percent')
    # The unchanged P25 tool rounds its RF word. Nine percent encodes 23/255,
    # safely below the 10% cap; its 10% input would round to 26/255. Do not
    # claim an identical RF word to DMR's floor-coded 25/255 comparison.
    return min(power, 9) if mode == 'p25' else power


def configuration(mode, source, frequency, power):
    power = effective_power(mode, power)
    if mode == 'dmr':
        return REPLAY.configuration(source, frequency, power)
    cfg = REPLAY.configparser.ConfigParser(interpolation=None, strict=True)
    if not cfg.read(source) or frequency != REPLAY.FREQUENCY or cfg.getint('General', 'Duplex') != 0:
        raise ValueError('P25 comparison requires existing 145700000-Hz simplex configuration')
    if any(cfg.getint('Info', key) != frequency for key in ('RXFrequency', 'TXFrequency')):
        raise ValueError('Configured RF frequency differs; no retuning authorized')
    if cfg['Modem'].get('Protocol', 'serial').casefold() not in ('uart', 'serial'):
        raise ValueError('Only local serial modem transport is supported')
    return REPLAY.BASE.configuration(source, frequency, power)


def private_configuration(mode, raw, output):
    # First disable all networks and DMR beacons using the same reviewed
    # transform; P25 then swaps the sole enabled digital mode back to P25.
    prepared, profile = REPLAY.TRACE.transform_config(raw, output)
    if mode == 'p25':
        return REPLAY.TRACE.BASE_TRANSFORM(prepared, output)
    return prepared, profile


def execute_session(system, operation, source, report, settle=time.sleep, begin_cleanup=lambda: None):
    report['active_before'] = {unit: system.active(unit) for unit in ENGINE.UNITS}
    report['cleanup_errors'] = []
    try:
        for unit in ENGINE.UNITS:
            system.service('stop', unit)
        if any(system.active(unit) for unit in ENGINE.UNITS):
            raise RuntimeError('Managed service remains active')
        if system.manual_hosts():
            raise RuntimeError('Unmanaged modem host present')
        report['replay'] = operation()
    finally:
        begin_cleanup()
        # The child is already gone. Give finite modem buffers/watchdog time
        # to settle before a restored host can touch the shared serial link.
        try:
            settle(SETTLE_SECONDS)
        except BaseException as error:
            report['cleanup_errors'].append(type(error).__name__+': settle')
        for unit in reversed(ENGINE.UNITS):
            if report['active_before'][unit]:
                try:
                    system.service('start', unit)
                except BaseException as error:
                    report['cleanup_errors'].append(type(error).__name__+': start '+unit)
        report['active_after'] = {}
        for unit in ENGINE.UNITS:
            try:
                report['active_after'][unit] = system.active(unit)
            except BaseException as error:
                report['active_after'][unit] = None
                report['cleanup_errors'].append(type(error).__name__+': query '+unit)
        report['services_restored'] = report['active_before'] == report['active_after']
        report['original_config_unchanged'] = ENGINE.digest(source) == report['original_config_sha256']


def child_command(alternate, fixture, manifest, frequency, power, mode='dmr'):
    tool = REPLAY if mode == 'dmr' else REPLAY.BASE
    command = [sys.executable, '-u', str(Path(tool.__file__).resolve()),
               '--config', str(alternate), '--fixture', str(fixture),
               '--frequency', str(frequency), '--rf-power', str(effective_power(mode, power)), '--transmit']
    command += ['--manifest', str(manifest)] if mode == 'dmr' else ['--case', 'clear', '--pairs', '14']
    return command


def child_replay(alternate, fixture, manifest, frequency, power, output, mode='dmr'):
    command = child_command(alternate, fixture, manifest, frequency, power, mode)
    with (output/'replay.jsonl').open('xb') as log:
        child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            child.wait(timeout=20)
            if child.returncode:
                raise RuntimeError('Replay child failed')
        finally:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=3)
    records = [json.loads(line) for line in (output/'replay.jsonl').read_text().splitlines()]
    result = records[-1]
    if result.get('units_sent') != (86 if mode == 'dmr' else 30) or result.get('tx_observed') is not True:
        raise RuntimeError('Incomplete replay result')
    return result


def write_report(output, report):
    # Restoration evidence must still reach stdout if the hotspot's filesystem
    # fails again. Error metadata excludes private paths and config contents.
    try:
        (output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
        return True
    except BaseException as error:
        report['result'] = 'failed'
        report['report_write_error'] = ENGINE.error_metadata(error)
        return False


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    p.add_argument('--mode', choices=('dmr', 'p25'), default='dmr')
    p.add_argument('--fixture', type=Path)
    p.add_argument('--manifest', type=Path)
    p.add_argument('--config', default='/etc/mmdvmhost')
    p.add_argument('--frequency', type=int)
    p.add_argument('--rf-power', type=int, default=10)
    p.add_argument('--output', type=Path)
    p.add_argument('--transmit', action='store_true')
    a = p.parse_args(argv)
    a.fixture = a.fixture or root/('fixtures/dmr-1031/call.bin' if a.mode == 'dmr' else 'fixtures/p25-1011/call.bin')
    a.manifest = a.manifest or root/'fixtures/dmr-1031/manifest.json'
    frames, fixture_report = fixture_frames(a.mode, a.fixture, a.manifest)
    if not a.transmit:
        print(json.dumps({'dry_run': True, **fixture_report}), flush=True)
        return 0
    if os.name != 'posix' or os.geteuid() != 0:
        p.error('Transmission sessions must run as root on the Linux hotspot')
    if a.output is None:
        p.error('--transmit requires a new absolute --output directory')
    source = ENGINE.checked_file(a.config)
    fixture = ENGINE.checked_file(str(a.fixture.resolve()))
    manifest = ENGINE.checked_file(str(a.manifest.resolve())) if a.mode == 'dmr' else None
    configuration(a.mode, source, a.frequency, a.rf_power)
    output = a.output
    if (not output.is_absolute() or output.exists() or output.is_symlink()
            or output.parent.resolve() != output.parent or not output.parent.is_dir()):
        p.error('Output requires a new directory under a canonical existing parent')
    import fcntl
    power = effective_power(a.mode, a.rf_power)
    report = {'mode': 'finite-local-'+a.mode.upper()+'-replay', 'frequency_hz': a.frequency,
              'rf_power_percent': power, 'requested_rf_power_percent': a.rf_power,
              'effective_rf_power_percent': power, 'rf_power_cap_percent': 10,
              'rf_level_byte': power*255//100 if a.mode == 'dmr' else int(power*255/100+0.5),
              'fixture': fixture_report,
              'started_epoch': time.time(), 'rf_decode_verified': False}
    # Shared with both DMR and P25 trace sessions. Held through restoration.
    with open('/run/lock/dm32-p25-session.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        os.umask(0o077); output.mkdir(mode=0o700)
        original = source.read_bytes()
        report['original_config_sha256'] = hashlib.sha256(original).hexdigest()
        (output/'original-config.private.ini').write_bytes(original)
        prepared, report['selected_profile'] = private_configuration(a.mode, original.decode(), output)
        alternate = output/'replay-config.private.ini'; alternate.write_text(prepared)
        def interrupted(signum, frame):
            for pending in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
                signal.signal(pending, signal.SIG_IGN)
            raise InterruptedError('Interrupted guarded session')
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            signal.signal(signum, interrupted)
        try:
            operation = lambda: child_replay(alternate, fixture, manifest, a.frequency, a.rf_power, output, a.mode)
            def begin_cleanup():
                for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
                    signal.signal(signum, signal.SIG_IGN)
            execute_session(ENGINE.System(), operation, source, report, begin_cleanup=begin_cleanup)
            report['result'] = 'complete'
        except BaseException as error:
            report['result'] = 'failed'; report.update(ENGINE.error_metadata(error))
        finally:
            for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
                signal.signal(signum, signal.SIG_IGN)
            report['finished_epoch'] = time.time()
        okay = (report.get('result') == 'complete' and report.get('services_restored')
                and report.get('original_config_unchanged') and not report.get('cleanup_errors'))
        report['result'] = 'complete' if okay else 'failed'
        report_written = write_report(output, report)
        okay = okay and report_written
    print(json.dumps({key: report[key] for key in ('result', 'services_restored',
                    'original_config_unchanged', 'rf_decode_verified', 'report_write_error') if key in report}
                     | {'report_written': report_written}), flush=True)
    return 0 if okay else 1


if __name__ == '__main__':
    raise SystemExit(main())
