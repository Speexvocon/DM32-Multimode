"""Validate decoded calibration audio and write a listenable WAV (standard library only)."""
from pathlib import Path
import array
import cmath
import json
import math
import sys
import wave

root = Path(__file__).resolve().parents[1]
build = root / "build/p25-1011"
raw = (build / "decoded.s16le").read_bytes()
pcm = array.array("h", raw)
if sys.byteorder != "little":
    pcm.byteswap()
if len(pcm) != 28 * 18 * 160:
    raise ValueError("Unexpected sample count")
# Analyze a whole second after codec startup. A DFT recurrence avoids dependencies.
segment = pcm[8000:16000]
power = {}
for hz in range(950, 1071):
    rotation = cmath.exp(-2j * math.pi * hz / 8000)
    phase, total = 1+0j, 0j
    for sample in segment:
        total += sample * phase
        phase *= rotation
    power[hz] = abs(total) ** 2
peak_hz = max(power, key=power.get)
peak = max(abs(x) for x in pcm)
if not 1005 <= peak_hz <= 1017 or peak == 0:
    raise ValueError(f"Unexpected reconstructed tone: {peak_hz} Hz, peak {peak}")
with wave.open(str(build / "decoded-1011.wav"), "wb") as out:
    out.setnchannels(1)
    out.setsampwidth(2)
    out.setframerate(8000)
    out.writeframes(raw)
result = {"samples": len(pcm), "sample_rate": 8000, "seconds": len(pcm)/8000,
          "peak_sample": peak, "dominant_hz_in_950_1070_search": peak_hz,
          "passed": True, "rf_verified": False}
(root / "fixtures/p25-1011/audio-validation.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
