"""One finite local DMR tone call; offline validation is the default.

Protocol: juribeparada/MMDVM_HS 7e16099 SerialPort.cpp / DMRDMOTX.cpp.
Only normal simplex DMR_DATA2 is used, never calibration or continuous TX.
Run through hotspot-dmr-session.py for service isolation and restoration.
"""
import argparse
import configparser
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import time


def sibling(name, key):
    spec = importlib.util.spec_from_file_location(key, Path(__file__).with_name(name))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


BASE = sibling('hotspot-p25-replay.py', 'dmr_replay_link')
TRACE = sibling('hotspot-dmr-trace-session.py', 'dmr_replay_services')
packet = BASE.packet
FREQUENCY = 145700000
FIXTURE_SHA256 = 'b159eec00cbcabd265d606cd30329f7176cd48a475e3ab61d802df692339509e'
FIXTURE_TARGETS = {
    FIXTURE_SHA256: 9,
    '41d6a62d6e20013fa5aeae510a9730773d95c4c8906611c230e920544ace1757': 98638,
}
CONTROLS = [0x41] + [0x20, 1, 2, 3, 4, 5] * 14 + [0x42]


def load_frames(path, manifest):
    raw = Path(path).read_bytes()
    info = json.loads(Path(manifest).read_text())
    digest = hashlib.sha256(raw).hexdigest()
    target = FIXTURE_TARGETS.get(digest)
    if target is None or len(raw) != len(CONTROLS) * 33:
        raise ValueError('Unexpected finite DMR fixture bytes')
    # The fixed byte hash is the authority. The adjacent manifest is checked
    # independently as an operator-facing declaration of what will be sent.
    expected = {'schema': 'dm32-dmr-tone-v1', 'burst_bytes': 33, 'burst_count': 86,
                'voice_bursts': 84, 'voice_frames_20ms': 252, 'voice_seconds': 5.04,
                'color_code': 1, 'timeslot': 2, 'source_id': 1, 'talkgroup': target, 'family': 'ms'}
    if (any(info.get(key) != value for key, value in expected.items())
            or info.get('files', {}).get('call.bin', {}).get('sha256') != digest
            or info.get('controls') != CONTROLS):
        raise ValueError('Fixture manifest identity/controls mismatch')
    frames = [packet(0x1a, bytes((control,)) + raw[i*33:(i+1)*33])
              for i, control in enumerate(CONTROLS)]
    return frames, {'fixture_sha256': digest, 'bursts': len(frames),
                    'voice_bursts': 84, 'voice_frames': 252, 'voice_s': 5.04,
                    'cc': 1, 'source': 1, 'tg': target, 'sync': 'MS',
                    'rf_decode_verified': False}


def configuration(path, frequency, power):
    if frequency != FREQUENCY:
        raise ValueError('This controlled session requires 145700000 Hz')
    if not isinstance(power, int) or not 1 <= power <= 10:
        raise ValueError('RF power must be 1..10 uncalibrated percent')
    cfg = configparser.ConfigParser(interpolation=None, strict=True)
    if not cfg.read(path):
        raise ValueError('Cannot read modem configuration')
    if cfg.getint('General', 'Duplex') != 0 or cfg.getint('DMR', 'ColorCode') != 1:
        raise ValueError('Fixture requires simplex and color code 1')
    for key in ('RXFrequency', 'TXFrequency'):
        if cfg.getint('Info', key) != frequency:
            raise ValueError('Configured RF frequency differs; no retuning authorized')
    m = cfg['Modem']
    protocol = m.get('Protocol', 'serial').casefold()
    if protocol not in ('uart', 'serial'):
        raise ValueError('Only local serial modem transport is supported')
    port = m.get('UARTPort') if protocol == 'uart' else m.get('Port')
    if not port:
        raise ValueError('Missing modem port')
    baud = int(m.get('UARTSpeed', '115200'))
    offsets = [int(m.get(key, '0')) for key in ('RXOffset', 'TXOffset')]
    if any(abs(offset) > 100000 for offset in offsets):
        raise ValueError('Unexpected frequency offset')
    # Round down: the encoded RF-level fraction never exceeds the requested
    # cap. This is an RF-level setting, not a calibrated power measurement.
    freq = packet(4, b'\0' + struct.pack('<II', frequency+offsets[0], frequency+offsets[1])
                  + bytes((power*255//100,)))
    flags = 0x80
    for bit, key in enumerate(('RXInvert', 'TXInvert', 'PTTInvert')):
        flags |= (int(m.get(key, '0')) != 0) << bit
    def level(key):
        value = float(m.get(key, '50'))
        if not 0 <= value <= 100:
            raise ValueError('Invalid modem level')
        return int(value*255/100+0.5)
    delay = int(m.get('TXDelay', '100')) // 10
    if not 0 <= delay <= 50:
        raise ValueError('TXDelay exceeds modem range')
    config = packet(2, bytes((flags, 2, delay, 0, level('RXLevel'),
                             0, 1, 0, 128, 0, level('DMRTXLevel'), 0, 0)))
    return port, baud, freq, config, 0.5 + delay*0.01


class Link(BASE.Link):
    def status(self):
        value = self.query(1)
        if len(value) < 9:
            raise RuntimeError('Short DMR modem status')
        if value[5] & 0x0e:
            raise RuntimeError('Modem overflow/lockout')
        return {'dmr': value[3] == 2, 'mode': value[4],
                'tx': bool(value[5] & 1), 'space': value[8]}


def replay(link, frames, lead, clock=time.monotonic, sleep=time.sleep):
    start = clock()
    deadline = start + len(frames)*0.06 + lead + 8
    sent = 0; saw_tx = False; last_send = start
    while clock() < deadline:
        state = link.status()
        if not state['dmr'] or state['mode'] not in (0, 2):
            raise RuntimeError('Modem left normal DMR/idle mode')
        saw_tx |= state['tx']
        # A fresh status for every write; preserve one FIFO slot, as the host
        # does. The finite fixture inventory is the maximum transmitted data.
        if sent < len(frames) and state['space'] > 1:
            link.send(frames[sent]); sent += 1; last_send = clock()
        elif sent == len(frames) and saw_tx and not state['tx'] and clock()-last_send > 0.5:
            return {'units_sent': sent, 'elapsed_s': round(clock()-start, 3),
                    'tx_observed': True, 'rf_decode_verified': False}
        sleep(0.02)
    raise TimeoutError('Finite DMR replay/drain deadline exceeded')


def require_exclusive_services():
    system = TRACE.ENGINE.System()
    if any(system.active(unit) for unit in TRACE.ENGINE.UNITS):
        raise RuntimeError('Managed service remains active; use the session guard')
    if system.manual_hosts():
        raise RuntimeError('Unmanaged MMDVMHost present')


def transmit(config_path, frequency, power, frames):
    port, baud, freq, config, lead = configuration(config_path, frequency, power)
    require_exclusive_services()
    import serial
    with serial.Serial(port, baud, timeout=0.02, write_timeout=1, exclusive=True) as device:
        link = Link(device)
        version = link.query(0)
        if (len(version) < 5 or version[3] != 1 or b'MMDVM_HS' not in version[4:]
                or b'7e16099' not in version[4:].lower()):
            raise RuntimeError('Only reviewed MMDVM_HS 7e16099 protocol 1 is supported')
        if link.status()['tx']:
            raise RuntimeError('Modem is already transmitting')
        try:
            link.command(freq); link.command(config)
            return replay(link, frames, lead)
        finally:
            # Idle is best effort, not a guaranteed FIFO flush. No more data
            # follows a failure; the finite inventory and watchdog bound RF.
            try:
                link.command(packet(3, b'\0'))
            except (RuntimeError, TimeoutError, OSError):
                pass


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    default = Path(__file__).resolve().parents[1]/'fixtures/dmr-1031'
    p.add_argument('--fixture', type=Path, default=default/'call.bin')
    p.add_argument('--manifest', type=Path, default=default/'manifest.json')
    p.add_argument('--config', default='/etc/mmdvmhost')
    p.add_argument('--frequency', type=int)
    p.add_argument('--rf-power', type=int, default=10)
    p.add_argument('--transmit', action='store_true')
    a = p.parse_args(argv)
    frames, report = load_frames(a.fixture, a.manifest)
    print(json.dumps({'dry_run': not a.transmit, **report}), flush=True)
    if a.transmit:
        result = transmit(a.config, a.frequency, a.rf_power, frames)
        print(json.dumps(result), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
