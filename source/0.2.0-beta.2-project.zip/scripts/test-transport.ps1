$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$upstream = Join-Path $projectRoot 'external/RadioFoundry/RadioFoundry'
$build = Join-Path $projectRoot 'build/transport'
New-Item -ItemType Directory -Force -Path $build | Out-Null
Push-Location $projectRoot
try {
    & gcc -std=c11 -Wall -Wextra -Werror -pedantic -Isrc/firmware -Ifixtures/p25-1011 tests/test_p25_tx.c src/firmware/p25_test_tx.c -o (Join-Path $build 'test_p25_tx.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Portable transport build failed' }
    & (Join-Path $build 'test_p25_tx.exe') fixtures/p25-1011/tx-stream.bin
    if ($LASTEXITCODE -ne 0) { throw 'Portable transport checks failed' }
    if (-not (Test-Path (Join-Path $upstream 'third_party/FreeRTOS-Kernel/include/FreeRTOS.h'))) {
        throw 'Initialize the pinned FreeRTOS submodule in the RadioFoundry clone first'
    }
    $includes = @('hal','core','drivers','boards/dm32','platform/hrc7000','platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include') | ForEach-Object { '-I' + (Join-Path $upstream $_) }
    & gcc -std=gnu11 -O1 -g -Wall -Wextra -Werror -Wno-unused-parameter -ffunction-sections -fdata-sections '-Wl,--gc-sections' -Itests/diag-stubs -DCONFIG_P25_TEST_TX=1 '-DP25_PROJECT_GIT="host-adapter-test"' -DCONFIG_DMR=1 @includes -Isrc/firmware -Ifixtures/p25-1011 tests/test_diag_adapter.c src/firmware/p25_test_tx.c -o (Join-Path $build 'test_diag_adapter.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Hardware adapter model build failed' }
    & (Join-Path $build 'test_diag_adapter.exe') fixtures/p25-1011/tx-stream.bin
    if ($LASTEXITCODE -ne 0) { throw 'Hardware adapter model checks failed' }
    & gcc -std=c11 -Wall -Wextra -Werror -pedantic -Isrc/firmware -Ifixtures/p25-1011 tests/test_p25_live_tx.c src/firmware/p25_live_tx.c src/firmware/p25_test_tx.c -o (Join-Path $build 'test_p25_live_tx.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Live transport build failed' }
    & (Join-Path $build 'test_p25_live_tx.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Live transport checks failed' }
    & gcc -std=gnu11 -O1 -g -Wall -Wextra -Werror -Wno-unused-parameter -Itests/diag-stubs -DDM32_LAB_DIAGNOSTICS=1 '-DBENCH_GIT="host-live-test"' -DCONFIG_DMR=1 @includes -Isrc/firmware -Ifixtures/p25-1011 tests/test_live_adapter.c tests/diag-stubs/radio_dmr_stub.c src/firmware/p25_demod.c src/firmware/p25_receive_bench.c src/firmware/p25_rx.c src/firmware/p25_call.c src/firmware/p25_live_tx.c src/firmware/p25_live_frame.c src/firmware/p25_test_tx.c -o (Join-Path $build 'test_live_adapter.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Live adapter build failed' }
    & (Join-Path $build 'test_live_adapter.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Live adapter checks failed' }
    & python scripts/generate-p25-channel.py --check
    if ($LASTEXITCODE -ne 0) { throw 'Channel mask provenance mismatch' }
    & python tests/test_p25_channel.py
    if ($LASTEXITCODE -ne 0) { throw 'Channel framing reference checks failed' }
    & python tests/test_p25_live_host.py
    if ($LASTEXITCODE -ne 0) { throw 'Live host checks failed' }
    & python -m unittest discover -s tests -p test_tx_diagnostic_host.py -v
    if ($LASTEXITCODE -ne 0) { throw 'TX diagnostic setup checks failed' }
    & python tests/test_export_p25_fixed.py
    if ($LASTEXITCODE -ne 0) { throw 'Fixed TX reference export checks failed' }
    & python tests/test_rx_capture_host.py
    if ($LASTEXITCODE -ne 0) { throw 'RX capture download checks failed' }
} finally { Pop-Location }

& python tests/test_pcm_download.py
if ($LASTEXITCODE -ne 0) { throw 'PCM download protocol checks failed' }

& gcc -std=c11 -O2 -Wall -Wextra -Werror -Isrc/firmware tests/test_test_tone.c -lm -o build/transport/test_test_tone.exe
if ($LASTEXITCODE -ne 0) { throw 'Diagnostic oscillator build failed' }
& build/transport/test_test_tone.exe
if ($LASTEXITCODE -ne 0) { throw 'Diagnostic oscillator continuity checks failed' }

& gcc -std=c11 -Wall -Wextra -Werror -Isrc/firmware -Iexternal/RadioFoundry/RadioFoundry/hal tests/test_p25_preferences.c -o build/transport/test_p25_preferences.exe
if ($LASTEXITCODE -ne 0) { throw 'Preferences model build failed' }
& build/transport/test_p25_preferences.exe
if ($LASTEXITCODE -ne 0) { throw 'Preferences fault injection failed' }
& python tests/test_p25_settings_host.py
if ($LASTEXITCODE -ne 0) { throw 'Settings host profile validation failed' }

& gcc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Isrc/firmware ('-I' + (Join-Path $upstream 'hal')) tests/test_p25_fm.c -o build/transport/test_p25_fm.exe
if ($LASTEXITCODE -ne 0) { throw 'FM backend model build failed' }
& build/transport/test_p25_fm.exe
if ($LASTEXITCODE -ne 0) { throw 'FM ownership, squelch and shutdown checks failed' }

& gcc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Isrc/firmware ('-I' + (Join-Path $upstream 'hal')) tests/test_p25_channel_store.c -o build/transport/test_p25_channel_store.exe
if ($LASTEXITCODE -ne 0) { throw 'Channel store model build failed' }
& build/transport/test_p25_channel_store.exe
if ($LASTEXITCODE -ne 0) { throw 'Channel store atomicity and migration checks failed' }

& gcc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Isrc/firmware tests/test_radio_ux.c -o build/transport/test_radio_ux.exe
if ($LASTEXITCODE -ne 0) { throw 'Radio UX policy model build failed' }
& build/transport/test_radio_ux.exe
if ($LASTEXITCODE -ne 0) { throw 'Radio light, lock and scan policy checks failed' }

& gcc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Isrc/firmware tests/test_tx_limits.c -o build/transport/test_tx_limits.exe
if ($LASTEXITCODE -ne 0) { throw 'TX timeout and microphone bounds build failed' }
& build/transport/test_tx_limits.exe
if ($LASTEXITCODE -ne 0) { throw 'TX timeout and microphone bounds checks failed' }
& python tests/test_radio_broadcast.py
if ($LASTEXITCODE -ne 0) { throw 'Broadcast radio ownership checks failed' }
& python tests/test_radio_broadcast_input.py
if ($LASTEXITCODE -ne 0) { throw 'Broadcast keypad frequency checks failed' }
& python tests/test_minimal_diagnostics.py
if ($LASTEXITCODE -ne 0) { throw 'Normal/engineering diagnostics profile checks failed' }
