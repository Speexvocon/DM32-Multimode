"""Arm or inspect the experimental diagnostic build; never flashes firmware."""
import argparse
import json
from pathlib import Path
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", help="Programming-cable port, for example COM5")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--arm", action="store_true", help="Allow one physical PTT-triggered call")
    action.add_argument("--stop", action="store_true", help="Disarm and stop immediately")
    parser.add_argument("--frequency", type=int, help="Test frequency in Hz; required when arming")
    parser.add_argument("--variant", type=int, default=1,
                        help="PHY experiment bits: b0 continuous, b1 autotest, b3:2 half policy (default 1)")
    parser.add_argument("--invert", action="store_true", help="Toggle RF_MODE polarity relative to board setup")
    parser.add_argument("--allow-rf", action="store_true", help="Explicitly authorize the arm command")
    parser.add_argument("--seconds", type=float, default=45, help="Monitor duration after command (default 45 s)")
    parser.add_argument("--log", type=Path, help="Save received diagnostics as JSON lines")
    parser.add_argument("--dry-run", action="store_true", help="Print commands without opening any port")
    args = parser.parse_args()
    if not 0 <= args.variant <= 11:
        parser.error("variant must be 0..11")
    if not 0 < args.seconds <= 120:
        parser.error("seconds must be in (0,120]")
    if args.arm:
        if not args.allow_rf:
            parser.error("--arm requires --allow-rf")
        if args.frequency is None or not (136000000 <= args.frequency <= 174000000
                                         or 400000000 <= args.frequency <= 480000000):
            parser.error("arming requires a frequency in the DM32 board's transmit ranges")
        command = f"ARM {args.frequency} {args.variant} {int(args.invert)} ALLOW_RF"
    else:
        command = "STOP" if args.stop else "STATUS"
    if args.dry_run:
        print(command)
        if args.arm:
            print("Monitor; physical PTT required; send STOP on exit")
        return
    if not args.port:
        parser.error("--port is required unless --dry-run is used")
    try:
        import serial
    except ImportError:
        parser.error("install pyserial: python -m pip install -r requirements-bench.txt")
    logger = None
    try:
        if args.log:
            args.log.parent.mkdir(parents=True, exist_ok=True)
            logger = args.log.open("a", encoding="utf-8")
        with serial.Serial(args.port, 115200, timeout=0.25, write_timeout=1) as port:
            # Verify the diagnostic identity before sending an ARM command.
            port.write(b"STATUS\n")
            deadline = time.monotonic() + 3
            identified = False
            while time.monotonic() < deadline:
                line = port.readline().decode("ascii", errors="replace").strip()
                if line:
                    print(line)
                    if line.startswith("P25 git="):
                        identified = True
                        break
            if not identified:
                raise RuntimeError("No P25 diagnostic identity received; refusing to send commands")
            try:
                port.write((command + "\n").encode("ascii"))
                if args.arm:
                    print("Release PTT, wait for OK ARMED, then press and hold for one call.")
                deadline = time.monotonic() + args.seconds
                while time.monotonic() < deadline:
                    line = port.readline().decode("ascii", errors="replace").strip()
                    if line:
                        print(line)
                        if logger:
                            logger.write(json.dumps({"time_utc_epoch": time.time(), "line": line})+"\n")
                            logger.flush()
            finally:
                if args.arm:
                    port.write(b"STOP\n")
                    port.flush()
    finally:
        if logger:
            logger.close()


if __name__ == "__main__":
    main()
