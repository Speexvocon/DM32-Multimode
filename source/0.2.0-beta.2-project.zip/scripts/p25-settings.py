"""Restore an owner channel profile without enabling RF; verify RAM and saved state."""
import argparse
import json
from pathlib import Path
import re
import time


def command_for(profile):
    if 'tx_inhibit' in profile:
        raise ValueError('tx_inhibit is not supported by CHANNEL; change retained TX permission on the radio')
    if 'prom_mode' in profile:
        raise ValueError('prom_mode is not supported by CHANNEL; change the retained RX filter on the radio')
    names=('rx_hz','tx_hz','nac','talkgroup','source_id','mic_gain_db')
    values=[profile[k] for k in names]
    if any(type(v) is not int for v in values):
        raise ValueError('Profile values must be integers')
    rx,tx,nac,tg,source,gain=values
    in_band=lambda f: 136000000<=f<=174000000 or 400000000<=f<=480000000
    if not (in_band(rx) and in_band(tx) and 0<=nac<=4095 and 1<=tg<=65535 and 1<=source<=0xffffff and 0<=gain<=42):
        raise ValueError('Profile outside supported range')
    if profile.get('split',rx!=tx)!=(rx!=tx):
        raise ValueError('Split flag disagrees with frequencies')
    return 'CHANNEL '+' '.join(map(str,values))


def status_profile(rows):
    """Validate the complete idle snapshot before trusting it or changing settings."""
    def number(row, key, base=10):
        value=rows.get(row,{}).get(key,'')
        pattern=r'[0-9a-fA-F]+' if base==16 else r'[0-9]+'
        if not re.fullmatch(pattern,value):
            raise RuntimeError(f'Missing or malformed {row} {key}')
        return int(value,base)

    def flag(row,key):
        value=number(row,key)
        if value not in (0,1):raise RuntimeError(f'Malformed {row} {key}')
        return value

    busy=any([flag('LIVE',k) for k in ('active','rf','armed','session')])
    busy|=any([flag('RXCAP',k) for k in ('pending','sampling')])
    # RXMON is emitted only after monitor storage has been used.
    if rows['RXCAP'].get('reason')=='monitor_storage' and 'RXMON' not in rows:
        raise RuntimeError('Missing RXMON status')
    if 'RXMON' in rows:
        busy|=any([flag('RXMON',k) for k in ('running','enabled')])
    if busy:raise RuntimeError('Stop RX/TX and release PTT before restoring settings')
    pref=rows.get('PREF',{})
    if not pref.get('state'):raise RuntimeError('Missing or malformed PREF state')
    flag('PREF','dirty')
    flag('RADIO','inhibit')
    if 'version' in pref:
        version=number('PREF','version')
        if version not in (1,2,3):raise RuntimeError('Unsupported PREF version')
        if version>=2 or 'tx_inhibit' in pref:flag('PREF','tx_inhibit')
        if version>=3 or 'prom_mode' in pref:flag('PREF','prom_mode')
    elif 'tx_inhibit' in pref or 'prom_mode' in pref:
        raise RuntimeError('Missing PREF version for retained radio settings')
    operating=rows.get('OPERATING')
    if operating is not None:
        if operating.get('mode') not in ('RADIO','BENCH'):
            raise RuntimeError('Missing or malformed OPERATING mode')
        owner=flag('OPERATING','owner_inhibit')
        if flag('OPERATING','ptt_release'):
            raise RuntimeError('Release PTT before restoring settings')
        if 'tx_inhibit' in pref and owner!=number('PREF','tx_inhibit'):
            raise RuntimeError('Retained TX permission status disagrees')
        if 'prom' in operating or pref.get('version')=='3':
            prom=flag('OPERATING','prom')
            if 'prom_mode' in pref and prom!=number('PREF','prom_mode'):
                raise RuntimeError('Retained RX filter status disagrees')
    if 'prom' in rows['RADIO']:
        prom=flag('RADIO','prom')
        if 'prom_mode' in pref and prom!=number('PREF','prom_mode'):
            raise RuntimeError('Radio RX filter status disagrees')
    current=dict(rx_hz=number('RADIO','rx_hz'),tx_hz=number('RADIO','tx_hz'),
                 nac=number('RADIO','nac',16),talkgroup=number('RADIO','tg'),
                 source_id=number('RADIO','source'),mic_gain_db=number('PREF','mic_db'),
                 split=bool(flag('RADIO','split')))
    in_band=lambda f: f==0 or 136000000<=f<=174000000 or 400000000<=f<=480000000
    # Unset frequencies and equal-frequency split mode are valid existing states,
    # even though restoring a desired profile normalizes the split flag.
    if not (in_band(current['rx_hz']) and in_band(current['tx_hz'])
            and 0<=current['nac']<=4095 and 1<=current['talkgroup']<=65535
            and 1<=current['source_id']<=0xffffff and 0<=current['mic_gain_db']<=42):
        raise RuntimeError('Malformed channel status')
    return current


def configure(port,log,profile):
    command=command_for(profile)
    expected={k:profile[k] for k in ('rx_hz','tx_hz','nac','talkgroup','source_id','mic_gain_db')}
    expected['split']=profile['rx_hz']!=profile['tx_hz']

    def wait(end):
        rows={};deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            line=port.readline().decode('ascii',errors='replace').strip()
            if not line:continue
            print(line,flush=True);log.write(json.dumps({'time':time.time(),'line':line})+'\n');log.flush()
            if line.startswith('ERR') or line.startswith('LIVE BUSY'):raise RuntimeError(line)
            words=line.split();name=words[0]
            if name in ('OPERATING','LIVE','RXCAP','RXMON','RADIO','PREF','LIVE_AUDIO'):
                fields={}
                for word in words[1:]:
                    key,separator,value=word.partition('=')
                    if not separator or not key or not value or key in fields:
                        raise RuntimeError('Malformed status row: '+line)
                    fields[key]=value
                if name in rows:raise RuntimeError('Duplicate status row: '+name)
                rows[name]=fields
            if line.startswith(end):return rows
        raise TimeoutError(end)

    port.write(b'STATUS\n');before=wait('LIVE_AUDIO ')
    current=status_profile(before)
    def saved(rows):
        pref=rows['PREF']
        return pref['state']=='saved' and pref['dirty']=='0' and rows['RADIO']['inhibit']=='1'

    if current==expected and saved(before):
        print('Profile already saved and verified; no settings written. TX is currently inhibited; retained TX permission and RX filter unchanged.')
        return before
    if before.get('OPERATING',{}).get('mode','BENCH')!='BENCH':
        raise RuntimeError('Select Bench / stop radio before restoring settings')
    port.write((command+'\n').encode('ascii'));wait('OK CHANNEL;')
    port.write(b'STATUS\n');after=wait('LIVE_AUDIO ')
    if status_profile(after)!=expected:raise RuntimeError('Channel readback mismatch')
    if after.get('OPERATING',{}).get('mode','BENCH')!='BENCH':
        raise RuntimeError('Radio resumed during settings restoration')
    prior_permission=before['PREF'].get('tx_inhibit')
    if prior_permission is not None and after['PREF'].get('tx_inhibit')!=prior_permission:
        raise RuntimeError('Retained TX permission changed or could not be verified')
    prior_filter=before['PREF'].get('prom_mode')
    if prior_filter is not None and after['PREF'].get('prom_mode')!=prior_filter:
        raise RuntimeError('Retained RX filter changed or could not be verified')
    if not saved(after):
        raise RuntimeError('RAM profile set but persistent save not verified; inspect PREF status')
    print('Profile saved and read back. TX is currently inhibited; retained TX permission and RX filter unchanged. Power-cycle verification remains.')
    return after


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',required=True)
    parser.add_argument('--profile',type=Path,required=True)
    parser.add_argument('--log',type=Path,required=True)
    a=parser.parse_args();profile=json.loads(a.profile.read_text());command_for(profile)
    import serial
    a.log.parent.mkdir(parents=True,exist_ok=True)
    with a.log.open('x') as log, serial.Serial(a.port,115200,timeout=.2,write_timeout=1) as port:
        configure(port,log,profile)

if __name__=='__main__':main()
