"""Inspect or run the synthetic no-RF IMBE benchmark; never flashes or arms RF."""
import argparse
import json
from pathlib import Path
import time


def fields(line):
    return dict(token.split("=", 1) for token in line.split()[1:] if "=" in token)


def summarize(status, cases):
    complete = (status.get("frames") == "300" and status.get("running") == "0"
                and status.get("rf") == "disabled" and set(cases) == {0, 1, 2}
                and all(c.get("frames") == "100" for c in cases.values()))
    return {"complete": complete, "payload_matches": complete and status.get("match") == "1",
            "within_15ms_budget": complete and all(int(c["over_15ms"]) == 0 for c in cases.values()),
            "within_20ms_deadline": complete and all(int(c["over_20ms"]) == 0 for c in cases.values()),
            "status": status, "cases": cases,
            "limitation": "Synthetic codec timing with RTOS interrupts; no microphone/PHY service load"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True)
    parser.add_argument("--run", action="store_true", help="Start one 300-frame benchmark; default is STATUS only")
    parser.add_argument("--stream", action="store_true", help="Run paced no-RF queues: 3000 speech frames plus six encoded padding frames")
    parser.add_argument("--seconds", type=int, default=120)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    if args.run and args.stream:
        parser.error("choose --run or --stream")
    if not 1 <= args.seconds <= 300:
        parser.error("seconds must be 1..300")
    import serial
    args.log.parent.mkdir(parents=True, exist_ok=True)
    status, cases, stages, started = {}, {}, {}, False
    timing = {}
    with args.log.open("x", encoding="utf-8") as log:
        with serial.Serial(args.port, 115200, timeout=0.25, write_timeout=1) as port:
            def read():
                line = port.readline().decode("ascii", errors="replace").strip()
                if line:
                    print(line, flush=True)
                    log.write(json.dumps({"time_utc_epoch": time.time(), "line": line}) + "\n")
                    log.flush()
                return line
            port.write(b"STATUS\n")
            deadline = time.monotonic() + 4
            while time.monotonic() < deadline:
                line = read()
                if line.startswith(("IMBE git=", "STREAM git=")):
                    status = fields(line)
                    break
            if status.get("rf") != "disabled":
                raise RuntimeError("No no-RF IMBE identity; refusing RUN")
            if not (args.run or args.stream):
                return
            if status.get("running") != "0":
                raise RuntimeError("Benchmark already running")
            try:
                port.write(b"STREAM\n" if args.stream else b"RUN\n")
                deadline = time.monotonic() + args.seconds
                status = {}
                while time.monotonic() < deadline:
                    line = read()
                    if line.startswith("OK STREAM " if args.stream else "OK RUN "):
                        started = True
                    elif line.startswith("ERR"):
                        raise RuntimeError(line)
                    elif started and args.stream and line.startswith("STREAM git="):
                        status=fields(line)
                    elif started and args.stream and line.startswith("STREAM_TIMING "):
                        timing=fields(line)
                        if status.get("running")=="0":
                            break
                    elif started and line.startswith("IMBE git="):
                        status = fields(line)
                        cases = {}  # Keep each status/case group together.
                        stages = {}
                    elif started and line.startswith("IMBE_STAGE "):
                        stage = fields(line)
                        stages[stage["case"] + ":" + stage["stage"]] = stage
                    elif started and line.startswith("IMBE_CASE "):
                        case = fields(line)
                        cases[int(case["index"])] = case
                        if summarize(status, cases)["complete"]:
                            break
            finally:
                port.write(b"STOP\n")
                port.flush()
                # Record acknowledgement instead of assuming the stop was parsed.
                stop_deadline = time.monotonic() + 3
                while time.monotonic() < stop_deadline:
                    if read() == "OK STOP":
                        break
            report = summarize(status, cases)
            if args.stream:
                complete=(status.get("done")=="1" and status.get("running")=="0"
                          and status.get("rf")=="disabled"
                          and all(status.get(k)=="3006" for k in ("captured","encoded","consumed")))
                report={"complete":complete,
                        "payload_matches":complete and status.get("match")=="1",
                        "queue_pass":complete and status.get("overflow")=="0" and status.get("underrun")=="0",
                        "status":status,"timing":timing,
                        "limitation":"Paced synthetic arrivals and simulated 20-ms sink; two nine-payload banks, no RF framing/PHY or microphone DMA"}
            if stages:
                report["stages"] = stages
                report["stage_timing_limitation"] = "Instrumented boundaries add overhead and may change code layout; compare uninstrumented timing separately"
            report_path = args.log.with_suffix(args.log.suffix + ".summary.json")
            with report_path.open("x", encoding="utf-8") as out:
                json.dump(report, out, indent=2)
            print(json.dumps(report, indent=2))
            if not report["payload_matches"]:
                raise RuntimeError("Benchmark incomplete or codec checksum mismatch; inspect saved report")


if __name__ == "__main__":
    main()
