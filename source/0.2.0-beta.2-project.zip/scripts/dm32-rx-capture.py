"""Capture raw 8-kHz big-endian FM RX samples; this does not decode P25.

Use --start HZ to schedule reception, or omit it to retrieve an existing capture.
Radio firmware must implement RXCAP/RXREAD. No flash operations or RF TX commands.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time
import wave


def receive_until(port, prefix, timeout):
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        line = port.readline().decode('ascii', errors='strict').strip()
        if line.startswith('ERR '):
            raise RuntimeError(line)
        if line.startswith(prefix):
            return line
    raise TimeoutError('Waiting for ' + prefix)


def decode_record(line, block, part):
    fields = line.split()
    if len(fields)!=6 or fields[0]!='RXDATA' or int(fields[1])!=block or int(fields[2])!=part:
        raise ValueError('Mismatched RXDATA response')
    data = bytes.fromhex(fields[5])
    stamp, half = int(fields[3]), int(fields[4])
    if len(data)!=64 or half not in (1,2) or not 0<=stamp<=0xffffffff:
        raise ValueError('Malformed capture data/metadata')
    return data, stamp, half


def decode_signal(line,index):
    fields=line.split()
    if len(fields)!=5 or fields[0]!='RXSIGNAL' or int(fields[1])!=index:
        raise ValueError('Mismatched RXSIGNAL response')
    us,dbm,noise=map(int,fields[2:])
    if not 0<=us<=7000000 or not -200<=dbm<=100 or not 0<=noise<=255:
        raise ValueError('Malformed signal telemetry')
    return {'elapsed_us':us,'rssi_dbm_estimate':dbm,'noise':noise}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', default='COM8')
    parser.add_argument('--start', type=int, metavar='HZ')
    parser.add_argument('--delay-ms', type=int, default=20000)
    parser.add_argument('--profile', type=int, choices=range(8), help='bits: 0=wide, 1=band-pass off, 2=DMR RF frontend; with --start')
    parser.add_argument('--telemetry', action='store_true', help='Download RSSI and routing from telemetry-capable firmware')
    parser.add_argument('--output', required=True, type=Path, help='New output directory')
    args = parser.parse_args()
    if not 0<=args.delay_ms<=30000:
        parser.error('delay must be 0..30000 ms')
    if args.profile is not None and args.start is None:
        parser.error('--profile requires --start')
    args.output.mkdir(parents=True, exist_ok=False)
    import serial
    with serial.Serial(args.port,115200,timeout=0.25,write_timeout=2) as port:
        if args.profile is not None:
            port.write(f'RXPROFILE {args.profile}\n'.encode())
            receive_until(port,'OK RXPROFILE',3)
        if args.start is not None:
            port.write(f'RXCAP {args.start} {args.delay_ms}\n'.encode())
            print(receive_until(port,'OK RXCAP',3),flush=True)
            # Avoid UART traffic while IRQ capture is active.
            time.sleep(args.delay_ms/1000+6.5)
        port.write(b'STATUS\n')
        status = receive_until(port,'RXCAP ',4)
        values = dict(item.split('=',1) for item in status.split()[1:])
        if values['pending']!='0' or values['sampling']!='0':
            raise RuntimeError('Capture still active')
        count = int(values['blocks'])
        if not 1<=count<=144:
            raise RuntimeError('No captured samples')
        telemetry=None
        if args.telemetry:
            port.write(b'RXMETA\n')
            meta=receive_until(port,'RXMETA ',3)
            telemetry=dict(item.split('=',1) for item in meta.split()[1:])
            signal_count=int(telemetry['samples'])
            if not 0<=signal_count<=60:raise ValueError('Invalid telemetry count')
            measurements=[]
            for index in range(signal_count):
                port.write(f'RXSIGNAL {index}\n'.encode())
                measurements.append(decode_signal(receive_until(port,'RXSIGNAL ',3),index))
            telemetry['measurements']=measurements
        raw = bytearray()
        metadata = []
        for block in range(count):
            first = None
            for part in range(8):
                port.write(f'RXREAD {block} {part}\n'.encode())
                data, stamp, half = decode_record(receive_until(port,'RXDATA ',3),block,part)
                if first is None:first=(stamp,half)
                if first!=(stamp,half):raise RuntimeError('Capture changed during download')
                raw.extend(data)
            metadata.append({'block':block,'timestamp_us':first[0],'half':first[1]})
    (args.output/'rx.be16').write_bytes(raw)
    little = bytearray(raw)
    little[0::2],little[1::2] = raw[1::2],raw[0::2]
    with wave.open(str(args.output/'rx.wav'),'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(8000);wav.writeframes(little)
    report = {'status':values,'blocks':metadata,'telemetry':telemetry,'sample_rate_assumed':8000,
              'raw_sha256':hashlib.sha256(raw).hexdigest(),
              'note':'Demodulated FM input, not decoded P25 voice; gaps are not repaired.'}
    (args.output/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'bytes':len(raw),'output':str(args.output),'status':values}))


if __name__=='__main__':main()
