$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$build=Join-Path $root 'build/p25-rx'
New-Item -ItemType Directory -Force $build | Out-Null
& gcc -std=c11 -O2 -Wall -Wextra -Werror -Isrc/firmware -Ifixtures/p25-1011 tests/test_p25_rx.c src/firmware/p25_rx.c src/firmware/p25_live_frame.c -o "$build/test.exe"
if($LASTEXITCODE -ne 0){throw 'RX model build failed'}
& "$build/test.exe"
if($LASTEXITCODE -ne 0){throw 'RX model failed'}
& gcc -std=c11 -O2 -Isrc/firmware -c src/firmware/p25_rx.c -o "$build/rx.o"
if($LASTEXITCODE -ne 0){throw 'RX core build failed'}
$codec=Join-Path $root 'research/references/nostar/imbe_vocoder'
$sources=@(Get-ChildItem $codec -Filter '*.cc' | Where-Object Name -ne 'imbe_vocoder.cc' | ForEach-Object FullName)
& g++ -std=c++17 -O2 -fwrapv -I $codec -Isrc/firmware src/host/p25_rx_replay.cpp "$build/rx.o" @sources -o "$build/replay.exe"
if($LASTEXITCODE -ne 0){throw 'RX replay build failed'}

& python (Join-Path $root 'tests/check_p25_rx_replay.py')
if($LASTEXITCODE -ne 0){throw 'RX replay reference failed'}
