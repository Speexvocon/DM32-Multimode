from pathlib import Path
import argparse,json,time,serial
p=argparse.ArgumentParser(description='Run receive timing on a retained known-clear bench capture; no RF or speaker output.')
p.add_argument('--output',type=Path,required=True)
p.add_argument('--expect-git',required=True)
p.add_argument('--profile',action='store_true')
a=p.parse_args()
if a.output.exists():raise RuntimeError('Evidence file already exists')
lines=[]
with serial.Serial('COM8',115200,timeout=.5,write_timeout=2) as port:
 port.write(b'STATUS\n');deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  line=port.readline().decode('ascii').strip()
  if line:lines.append(line)
  if line.startswith('LIVE_AUDIO '):break
 live=next((s for s in lines if s.startswith('LIVE ')),None)
 cap=next((s for s in lines if s.startswith('RXCAP ')),None)
 if live is None or cap is None:raise RuntimeError('No idle status received')
 state=dict(v.split('=',1) for v in live.split()[1:]);capture=dict(v.split('=',1) for v in cap.split()[1:])
 if state['git']!=a.expect_git or state['rf']!='0' or state['active']!='0':raise RuntimeError('Unexpected firmware/state')
 if capture['blocks']!='144' or any(capture[k]!='0' for k in ('pending','sampling','invalid','repeats','gaps')):raise RuntimeError('Capture not complete and gap-free')
 port.write(b'RXDEMOD CLEAR PROFILE\n' if a.profile else b'RXDEMOD CLEAR\n');deadline=time.monotonic()+180;result=None;stages=None
 while time.monotonic()<deadline:
  line=port.readline().decode('ascii').strip()
  if not line:continue
  print(line,flush=True);lines.append(line)
  if line.startswith('#RD0FAULT') or line.startswith('LIVE git='):
   a.output.parent.mkdir(parents=True,exist_ok=True)
   with a.output.open('x') as f:json.dump({'lines':lines,'failed':True},f,indent=2)
   raise RuntimeError('Target fault or restart; evidence saved')
  if line.startswith('ERR '):raise RuntimeError(line)
  if line.startswith('RXDEMOD '):result=dict(v.split('=',1) for v in line.split()[1:])
  if line.startswith('RXSTAGES '):
   stages=dict(v.split('=',1) for v in line.split()[1:]);break
 if result is None or stages is None:raise TimeoutError('Receive benchmark/stage response timeout')
a.output.parent.mkdir(parents=True,exist_ok=True)
with a.output.open('x') as f:json.dump({'firmware':a.expect_git,'profiled':a.profile,'stages':stages,'known_clear_bench':True,'lines':lines,'result':result},f,indent=2)
