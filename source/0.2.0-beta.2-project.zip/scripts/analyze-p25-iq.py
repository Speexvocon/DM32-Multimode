import json
from pathlib import Path
import numpy as np
from scipy import signal
import argparse
parser=argparse.ArgumentParser(description='Preliminary P25 C4FM deviation and sync analysis; not full-stream BER')
parser.add_argument('capture',type=Path)
parser.add_argument('--start',type=float,default=13)
parser.add_argument('--end',type=float,default=25)
parser.add_argument('--target',type=int,default=440075000)
a=parser.parse_args()
p=a.capture
m=json.loads(p.with_suffix(p.suffix+'.json').read_text());fs=m['sample_rate']
assert fs==1024000 and a.end-a.start>=11, 'This validated profile uses 1.024 MS/s and >=11 seconds'
assert not m['test_counter']
base=p.with_suffix('')
raw=np.memmap(p,dtype=np.uint8,mode='r').reshape(-1,2)[int(a.start*fs):int(a.end*fs)]
x=(raw[:,0].astype(np.float32)-127.5)+1j*(raw[:,1].astype(np.float32)-127.5)
x*=np.exp(2j*np.pi*(m['center_hz']-a.target)/fs*np.arange(len(x)))
x=signal.resample_poly(x,3,64) # 48 kHz
x=signal.sosfiltfilt(signal.butter(6,8500,fs=48000,output='sos'),x)
d=np.angle(x[1:]*x[:-1].conj())*48000/(2*np.pi)
# Unit-DC moving average implements receive sinc compensation, one symbol long.
d=signal.fftconvolve(d,np.ones(10)/10,mode='same')

levels=np.array([-3,-1,1,3]);best=None
for phase in np.arange(0,10,.1):
 y=np.interp(np.arange(phase+48000,phase+48000*10,10),np.arange(len(d)),d)
 centers=np.array([-1800,-600,600,1800.])+np.median(y)
 for _ in range(12):
  lab=np.argmin(abs(y[:,None]-centers),axis=1)
  centers=np.array([np.mean(y[lab==i]) for i in range(4)])
 rms=np.sqrt(np.mean((y-centers[lab])**2))
 if best is None or rms<best[0]:best=(rms,phase,centers)
print('best',best)
rms,phase,centers=best
syms=np.interp(np.arange(phase,len(d)-1,10),np.arange(len(d)),d)
lab=np.argmin(abs(syms[:,None]-centers),axis=1)
dibits=np.array([3,2,0,1])[lab]
dibits.astype(np.uint8).tofile(str(base)+"-dibits.bin")
sync=np.array([(v>>shift)&3 for v in bytes.fromhex('5575f5ff77ff') for shift in (6,4,2,0)])
windows=np.lib.stride_tricks.sliding_window_view(dibits,len(sync))
errors=np.sum(windows!=sync,axis=1);hits=np.flatnonzero(errors<=2)
records=[]
for i in hits:
 nid=dibits[i+24:i+32];v=0
 for q in nid:v=(v<<2)|int(q)
 records.append({'time_s':a.start+(phase+i*10)/48000,'symbol':int(i),'sync_symbol_errors':int(errors[i]),'sync_bit_errors':int(np.array([0,1,1,2])[dibits[i:i+24]^sync].sum()),'nac':f'{v>>4:03x}','duid':int(v&15)})
print('hits',len(records),records[:8]);print('spacing',np.unique(np.diff(hits),return_counts=True))
r={'centers_hz':centers.tolist(),'mean_center_hz':float(np.mean(centers)),'centered_levels_hz':(centers-np.mean(centers)).tolist(),'rms_cluster_hz':float(rms),'phase_samples':float(phase),'sync_hits':records}
r.update(capture_sha256=m['sha256'],method='48 kHz quadrature discriminator; 8.5 kHz channel LPF; unit-DC 10-sample receive averaging; four-cluster timing search',
         limitations=['Preliminary receiver-dependent estimate, not service-monitor conformance', 'RTL sample-clock accuracy not independently calibrated', 'No full-stream BER reference for live speech', 'Cluster RMS is not a standardized modulation-fidelity metric'],
         symbol_spacing_counts={str(int(k)):int(v) for k,v in zip(*np.unique(np.diff(hits),return_counts=True))})
Path(str(base)+'-symbols.json').write_text(json.dumps(r,indent=2))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(2,1,figsize=(10,8))
y=syms[4800:48000]-np.mean(centers)
ax[0].hist(y,bins=np.arange(-2600,2601,25),color='steelblue')
for v in [-1800,-600,600,1800]:ax[0].axvline(v,color='black',ls='--',alpha=.6)
for v in centers-np.mean(centers):ax[0].axvline(v,color='red',alpha=.8)
ax[0].set(title='Recovered symbol samples: nominal (dashed) and fitted (red)',xlabel='Frequency relative to fitted center (Hz)',ylabel='Samples')
for i in range(5000,5300):
 t=np.arange(-10,10.01,.25)
 yy=np.interp(phase+i*10+t,np.arange(len(d)),d)-np.mean(centers)
 ax[1].plot(t/10,yy,color='steelblue',alpha=.05)
ax[1].set(xlabel='Symbol periods from sampling instant',ylabel='Frequency (Hz)',ylim=(-3000,3000),title='Two-symbol eye, 300 overlaid traces')
fig.tight_layout();fig.savefig(str(base)+'-symbols.png')
