"""Build an offline clear P25 call from 8-kHz mono PCM16 WAV. Never opens a radio."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import wave

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, help="New output directory; refuses an existing directory")
    parser.add_argument("--tool", type=Path, default=ROOT / "build/host-voice/p25_voice.exe")
    args = parser.parse_args()
    with wave.open(str(args.input), "rb") as source:
        if (source.getnchannels(), source.getsampwidth(), source.getframerate(), source.getcomptype()) != (1, 2, 8000, "NONE"):
            parser.error("Input must be uncompressed 8-kHz mono signed 16-bit PCM WAV")
        samples = source.getnframes()
        if not 0 < samples <= 80640:
            parser.error("Input must contain more than zero and at most 10.08 seconds of audio")
        pcm = source.readframes(samples)
        if len(pcm) != samples * 2:
            parser.error("Truncated WAV data")
    if not args.tool.is_file():
        parser.error("Build the tool first with scripts/build-host-voice.ps1")
    # Pad PCM, never packed codec bytes. Keep a stateful encoder across the call.
    padded_samples = ((samples + 2879) // 2880) * 2880
    pcm += bytes((padded_samples - samples) * 2)
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "input.s16le").write_bytes(pcm)
    for mode, source, dest in [("encode", "input.s16le", "voice.imbe"),
                               ("frame", "voice.imbe", "tx-stream.bin"),
                               ("extract", "tx-stream.bin", "recovered.imbe"),
                               ("decode", "recovered.imbe", "decoded.s16le")]:
        subprocess.run([str(args.tool.resolve()), mode, str(args.output / source), str(args.output / dest)], check=True)
    if (args.output / "voice.imbe").read_bytes() != (args.output / "recovered.imbe").read_bytes():
        raise RuntimeError("Speech payload changed during framing/extraction")
    with wave.open(str(args.output / "decoded.wav"), "wb") as preview:
        preview.setparams((1, 2, 8000, 0, "NONE", "not compressed"))
        preview.writeframes((args.output / "decoded.s16le").read_bytes())
    artifacts = {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                 for p in sorted(args.output.iterdir()) if p.is_file()}
    manifest = {"purpose": "Offline variable-audio P25 call; not flashable firmware",
                "input_samples": samples, "padding_samples": padded_samples - samples,
                "speech_frames_20ms": padded_samples // 160, "ldu_pairs": padded_samples // 2880,
                "nac_hex": "293", "talkgroup": 1, "source_id": 1, "algid_hex": "80",
                "pcm_rate_hz": 8000, "payload_bytes_per_frame": 11,
                "packing": "MSB-first; status symbols included; concatenate before 36-byte transport chunking",
                "payload_roundtrip_exact": True, "hardware_access": False,
                "codec_interoperability_verified": False,
                "tool_sha256": hashlib.sha256(args.tool.read_bytes()).hexdigest(),
                "source_pins": json.loads((ROOT / "research/references/UPSTREAMS.json").read_text()),
                "files": artifacts}
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"Created {args.output}: {padded_samples // 160} voice frames; listen to decoded.wav")


if __name__ == "__main__":
    main()
