$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$codec = Join-Path $projectRoot 'research/references/nostar/imbe_vocoder'
$op25 = Join-Path $projectRoot 'research/references/boatbod/op25/op25/gr-op25_repeater/lib'
$build = Join-Path $projectRoot 'build/host-voice'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$sources = @(Get-ChildItem -LiteralPath $codec -Filter '*.cc' -File | ForEach-Object FullName)
& g++ -std=c++17 -O2 -fwrapv -I $codec -I $op25 -I (Join-Path $projectRoot 'fixtures/p25-1011') (Join-Path $projectRoot 'src/host/p25_voice.cpp') @sources -o (Join-Path $build 'p25_voice.exe')
if ($LASTEXITCODE -ne 0) { throw 'Host voice build failed' }
& python (Join-Path $projectRoot 'tests/test_host_voice.py') (Join-Path $build 'p25_voice.exe')
if ($LASTEXITCODE -ne 0) { throw 'Host voice validation failed' }
