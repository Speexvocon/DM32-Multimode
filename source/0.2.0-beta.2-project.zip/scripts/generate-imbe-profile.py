"""Generate an instrumented encoder copy; never modify the reference source."""
import argparse
from pathlib import Path

def generate(source):
    markers = [
        'for(i = 0; i < PITCH_EST_BUF_SIZE - FRAME; i++)',
        'pitch_est(imbe_param, pitch_est_buf);',
        'wr_ptr  = (Word16 *)wr;',
        'pitch_ref(imbe_param, fft_buf);',
        'v_uv_det(imbe_param, fft_buf);',
        'sa_encode(imbe_param);',
        'encode_frame_vector(imbe_param, frame_vector);',
    ]
    result = source
    for stage, marker in enumerate(markers):
        if result.count(marker) != 1:
            raise ValueError(f'Expected exactly one stage anchor: {marker}')
        result = result.replace(marker, f'imbe_profile_mark({stage});\n\t' + marker)
    result = result.replace(markers[-1], markers[-1] + '\n\timbe_profile_mark(7);')
    return '#include "imbe_profile.h"\n' + result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(generate(args.source.read_text()), encoding='utf-8')
