"""Extract the fixed P25 voice interleave map from the pinned OP25 reference."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
source = root/'research/references/boatbod/op25/op25/gr-op25_repeater/lib/op25_imbe_frame.h'
text = source.read_text()
body = re.search(r'voice_codeword_bits\[nof_voice_codewords\]\[voice_codeword_sz\] = (\{.*?\});', text, re.S).group(1)
values = [int(x) for x in re.findall(r'\b\d+\b', re.sub(r'//[^\n]*', '', body))]
assert len(values) == 9*144 and len(set(values)) == len(values) and max(values) < 1728
out = '// SPDX-License-Identifier: GPL-3.0-or-later\n// Generated from pinned OP25 op25_imbe_frame.h; see research/references/UPSTREAMS.json.\n'
out += 'static const uint16_t p25_voice_bits[9][144] = '+body+';\n'
(root/'src/firmware/p25_interleave.h').write_text(out, newline='\n')
