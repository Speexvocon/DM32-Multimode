#!/usr/bin/env python3
"""Preserve protocol-1 MMDVMHost P25 RX trace dumps before host FEC repair.

Only complete, contiguous CUtils hexadecimal dumps are accepted. Correction
counts are host FEC estimates, not measured raw speech BER. Optional references
must be the exact transmitted 216-byte LDUs, including NAC/control/status bits.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


class TraceError(ValueError):
    """A requested P25 trace is malformed or incomplete."""


STAMP = re.compile(r"[A-Z]:\s+(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?)\s+(.*)$")
LABEL = re.compile(r"^RX P25 (Header|LDU|Lost)$")
ROW = re.compile(r"^\s*([0-9a-fA-F]{4}):\s+(.*)$")
CORRECTION = re.compile(r"P25, LDU([12]) audio, errs:\s*(\d+)/(\d+)(?:\s+\(([^)]*)\))?")
RF_LOST_IDENTITY = re.compile(r"^P25, transmission lost from .+? to .+?, "
                              r"\d+(?:\.\d+)? seconds, BER: \d+(?:\.\d+)?%$")
TYPES = {"Header": 0x30, "LDU": 0x31, "Lost": 0x32}
DUID_NAMES = {0: "HDU", 3: "TDU", 5: "LDU1", 7: "TSDU", 10: "LDU2", 12: "PDU", 15: "TDULC"}


def log_body(line: str) -> tuple[str | None, str]:
    match = STAMP.search(line.rstrip("\r\n"))
    return (match[1], match[2]) if match else (None, line.strip())


def decode_frame(raw: bytes, label: str, timestamp: str | None, line: int) -> dict:
    if len(raw) < 3 or raw[0] != 0xE0:
        raise TraceError(f"line {line}: expected protocol-1 E0 serial envelope")
    if raw[1] != len(raw) or raw[2] != TYPES[label]:
        raise TraceError(f"line {line}: serial length/type does not match {label} dump")
    result = {"line": line, "timestamp": timestamp, "label": label,
              "serial_type": f"{raw[2]:02X}", "serial_length": len(raw), "serial_hex": raw.hex()}
    if label == "Lost":
        if len(raw) != 3:
            raise TraceError(f"line {line}: protocol-1 P25 Lost must contain exactly 3 bytes")
        return result
    if label == "LDU":
        if len(raw) not in (220, 222):
            raise TraceError(f"line {line}: LDU must contain flag + 216 RF bytes, optionally 2 RSSI bytes")
        rf = raw[4:220]
        result["ldu_hex"] = rf.hex()
        result["rssi_raw"] = int.from_bytes(raw[220:222], "big") if len(raw) == 222 else None
    else:
        # Header serial messages also transport terminators/control units. Preserve
        # their payload without requiring an undamaged DUID to match their size.
        if len(raw) - 4 not in (18, 45, 54, 99):
            raise TraceError(f"line {line}: unsupported P25 Header RF payload length {len(raw) - 4}")
        rf = raw[4:]
    result.update({"sync_flag": raw[3], "rf_length": len(rf), "rf_hex": rf.hex(),
                   "raw_nac_hex": f"{((rf[6] << 4) | (rf[7] >> 4)):03X}",
                   "raw_duid": rf[7] & 15, "raw_duid_name": DUID_NAMES.get(rf[7] & 15, "UNKNOWN")})
    return result


def event_kind(body: str) -> tuple[str, str] | None:
    if not body.startswith("P25,"):
        return None
    lower = body.lower()
    if "network" in lower:
        if "end of" in lower:
            return "network", "end"
        if "lost" in lower or "watchdog" in lower:
            return "network", "lost"
        if "received network transmission" in lower:
            return "network", "start"
    if RF_LOST_IDENTITY.fullmatch(body):
        return "rf", "lost"
    if "rf" in lower:
        if "end of" in lower:
            return "rf", "end"
        if "lost" in lower:
            return "rf", "lost"
        if re.search(r"received RF (?:voice|data|header|late entry|late-entry) transmission", body, re.I):
            return "rf", "start"
    return None


def compare_reference(frame: dict, reference: bytes) -> dict:
    if len(reference) != 216:
        raise TraceError("known LDU reference must contain exactly 216 bytes")
    observed = bytes.fromhex(frame["ldu_hex"])
    positions = [i * 8 + bit for i in range(6, 216)
                 for bit in range(8) if (observed[i] ^ reference[i]) & (0x80 >> bit)]
    return {"reference_sha256": hashlib.sha256(reference).hexdigest(),
            "excluded_rf_bit_ranges": [[0, 48]], "compared_bits": 1680,
            "bit_errors": len(positions), "rf_bit_positions_msb_first": positions,
            "error_fraction": len(positions) / 1680,
            "scope": "exact supplied LDU reference, excluding 48 sync bits; no alignment search"}


def parse_trace(text: str, references: dict[int, bytes] | None = None,
                expected_calls: int | None = None) -> dict:
    frames, corrections, events = [], [], []
    pending = None
    just_completed = False
    claimed_frames = set()
    for line_number, line in enumerate(text.splitlines(), 1):
        timestamp, body = log_body(line)
        label = LABEL.fullmatch(body)
        row = ROW.fullmatch(body)
        if pending is not None and not row:
            raise TraceError(f"line {line_number}: incomplete {pending['label']} dump from line {pending['line']}")
        if label:
            if timestamp is None:
                raise TraceError(f"line {line_number}: P25 dump is missing its log timestamp")
            pending = {"label": label[1], "line": line_number, "timestamp": timestamp, "data": bytearray()}
            just_completed = False
            continue
        if row and pending is not None:
            offset = int(row[1], 16)
            data = pending["data"]
            if offset != len(data):
                raise TraceError(f"line {line_number}: non-contiguous offset {offset:04X}, expected {len(data):04X}")
            hex_part = row[2].split("*", 1)[0].strip()
            tokens = hex_part.split()
            if not 1 <= len(tokens) <= 16 or any(not re.fullmatch(r"[0-9a-fA-F]{2}", item) for item in tokens):
                raise TraceError(f"line {line_number}: malformed hexadecimal dump row")
            data.extend(int(item, 16) for item in tokens)
            if len(data) < 3:
                raise TraceError(f"line {line_number}: first dump row lacks serial envelope")
            expected = data[1]
            if data[0] != 0xE0 or expected < 3:
                raise TraceError(f"line {line_number}: invalid protocol-1 serial envelope")
            if len(data) > expected:
                raise TraceError(f"line {line_number}: dump exceeds declared serial length {expected}")
            if len(data) < expected and len(tokens) != 16:
                raise TraceError(f"line {line_number}: short non-final dump row")
            if len(data) == expected:
                frame = decode_frame(bytes(data), pending["label"], pending["timestamp"], pending["line"])
                frame["index"] = len(frames)
                frames.append(frame)
                pending = None
                just_completed = True
            continue
        if row and just_completed:
            raise TraceError(f"line {line_number}: extra row after completed P25 dump")
        just_completed = False
        if "P25, LDU" in body and "audio, errs:" in body:
            match = CORRECTION.search(body)
            if match is None or int(match[3]) != 1233 or int(match[2]) > 1233:
                raise TraceError(f"line {line_number}: malformed P25 voice correction count")
            duid = 5 if match[1] == "1" else 10
            candidate = next((f["index"] for f in reversed(frames) if f["label"] == "LDU"
                              and f["raw_duid"] == duid and f["index"] not in claimed_frames), None)
            if candidate is not None:
                claimed_frames.add(candidate)
            corrections.append({"line": line_number, "timestamp": timestamp, "ldu": int(match[1]),
                                "corrected_bits": int(match[2]), "protected_bits": 1233,
                                "reported_percent_text": match[4], "candidate_frame_index": candidate,
                                "association": "nearest preceding unmatched trace with matching raw DUID; tentative",
                                "log": body})
        kind = event_kind(body)
        if kind:
            events.append({"line": line_number, "timestamp": timestamp,
                           "direction": kind[0], "kind": kind[1], "log": body})
    if pending is not None:
        raise TraceError(f"end of log: incomplete {pending['label']} dump from line {pending['line']}")
    if references:
        for frame in frames:
            if frame["label"] == "LDU" and frame["raw_duid"] in references:
                frame["known_reference"] = compare_reference(frame, references[frame["raw_duid"]])
    counts = Counter(f["label"] for f in frames)
    duids = Counter(f.get("raw_duid_name") for f in frames if "raw_duid_name" in f)
    event_counts = Counter(f"{e['direction']}_{e['kind']}" for e in events)
    bits = sum(c["corrected_bits"] for c in corrections)
    protected = 1233 * len(corrections)
    summary = {"trace_frames": len(frames), "serial_counts": dict(counts), "raw_duid_counts": dict(duids),
               "event_counts": dict(event_counts), "host_corrected_bits": bits,
               "host_protected_voice_bits": protected,
               "host_correction_fraction": bits / protected if protected else None,
               "unassociated_correction_records": sum(c["candidate_frame_index"] is None for c in corrections),
               "expected_rf_calls": expected_calls, "rf_acquisition_events": event_counts["rf_start"],
               "no_acquisition_observed": event_counts["rf_start"] == 0,
               "status": "parsed" if frames else "no_trace_frames"}
    if expected_calls is not None:
        summary["expected_acquisition_count_matched"] = event_counts["rf_start"] == expected_calls
    return {"schema": "mmdvm-p25-trace-v1", "summary": summary, "frames": frames,
            "corrections": corrections, "events": events,
            "limitations": ["Protocol-1 hard decisions only; no analog deviation or calibrated RSSI.",
                "Raw NAC/DUID fields are uncorrected observations, not validated call metadata.",
                "Host correction fraction covers protected voice bits of processed LDUs, not raw speech BER.",
                "Initial modem sync may have been canonicalized; sync is excluded from reference comparisons.",
                "Correction/trace association is tentative and can be ambiguous after malformed NID or filtered units."]}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ldu-output", type=Path, help="exclusively create concatenated raw 216-byte LDUs in trace order")
    parser.add_argument("--allow-empty", action="store_true", help="save explicit no-trace/no-acquisition result")
    parser.add_argument("--expected-calls", type=int)
    parser.add_argument("--reference-ldu1", type=Path, help="exact transmitted 216-byte LDU1, only for known-pattern calls")
    parser.add_argument("--reference-ldu2", type=Path, help="exact transmitted 216-byte LDU2, only for known-pattern calls")
    args = parser.parse_args(argv)
    try:
        if args.expected_calls is not None and args.expected_calls < 0:
            raise TraceError("--expected-calls must be nonnegative")
        paths = [args.input.resolve(), args.output.resolve()]
        if args.ldu_output:
            paths.append(args.ldu_output.resolve())
        if len(set(paths)) != len(paths):
            raise TraceError("input, JSON output and binary LDU output must be different files")
        raw = args.input.read_bytes()
        refs = {duid: path.read_bytes() for duid, path in ((5, args.reference_ldu1), (10, args.reference_ldu2)) if path}
        if any(len(value) != 216 for value in refs.values()):
            raise TraceError("known LDU references must contain exactly 216 bytes")
        result = parse_trace(raw.decode("utf-8-sig"), refs, args.expected_calls)
        if not result["frames"] and not args.allow_empty:
            raise TraceError("no P25 trace frames found; use --allow-empty to preserve a no-acquisition attempt")
        result["input"] = {"path": str(args.input), "sha256": hashlib.sha256(raw).hexdigest()}
        if args.ldu_output:
            payload = b"".join(bytes.fromhex(frame["ldu_hex"]) for frame in result["frames"] if frame["label"] == "LDU")
            args.ldu_output.parent.mkdir(parents=True, exist_ok=True)
            with args.ldu_output.open("xb") as stream:
                stream.write(payload)
            result["ldu_output"] = {"path": str(args.ldu_output), "length": len(payload),
                                    "sha256": hashlib.sha256(payload).hexdigest()}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result["summary"], sort_keys=True))
        return 0
    except (OSError, UnicodeError, TraceError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
