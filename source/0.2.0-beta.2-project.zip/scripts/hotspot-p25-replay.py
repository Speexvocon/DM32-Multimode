"""Bounded, named local P25 fixture replay for MMDVM_HS protocol 1.

Default is offline validation. --transmit requires exclusive modem ownership.
Protocol reference: juribeparada/MMDVM_HS commit 7e16099, SerialPort/P25TX.
No persistent settings, network traffic, firmware flashing or service changes.
"""
import argparse
import configparser
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import time

SYNC = bytes.fromhex('5575f5ff77ff')
FIXTURE_SHA = 'd058dc3d06eaf3d249decb885466a3d35ed6d796993a653557e116e7741a4d06'
CASES = {
    'clear': {'path': 'fixtures/p25-1011/call.bin', 'sha256': FIXTURE_SHA,
              'stored_pairs': 28, 'kind': 'clear-group-voice', 'expected': 'Decoded clear tone (9 voice frames per LDU)'},
    'encrypted-hdu': {'path': 'fixtures/p25-rx-qualification/encrypted-hdu.bin',
                      'sha256': '50436bd6e166994cd5648b7a702e4edbd6d63eb5ae6d0d63614d6c2dd9f60fc5',
                      'stored_pairs': 14, 'kind': 'encrypted-metadata-negative-control',
                      'expected': 'No decoded voice or speaker PCM, including PROM'},
    'unsupported-lc': {'path': 'fixtures/p25-rx-qualification/unsupported-lc.bin',
                       'sha256': '42bebe17cab0153c0dd4b6db9fd9bfdd549416abf55caac9896d3dd746c473d8',
                       'stored_pairs': 14, 'kind': 'unsupported-lc-negative-control',
                       'expected': 'No decoded voice or speaker PCM, including PROM'},
    'damaged-hdu': {'path': 'fixtures/p25-rx-qualification/damaged-hdu.bin',
                    'sha256': 'a5b6a968a94c3b978ff4a170278b1737735e992c0e1bf3718617348604f4ba8a',
                    'stored_pairs': 14, 'kind': 'damaged-header-recovery-control',
                    'expected': 'Reject invalid HDU; withhold first pair; qualify 234 clear voice frames'},
    'damaged-lc': {'path': 'fixtures/p25-rx-qualification/damaged-lc.bin',
                   'sha256': '2aef0d87f968d2449f90e7b92563272b537f047de75550b90773a546a98edaeb',
                   'stored_pairs': 14, 'kind': 'damaged-link-control-recovery',
                   'expected': 'Reject pair-8 LC; flush pending audio; qualify 234 frames and recover'},
    'damaged-ess': {'path': 'fixtures/p25-rx-qualification/damaged-ess.bin',
                    'sha256': '7baa34d2f94f904dd8f7430c1d565fd811a045d911d0d536b7880930a6426d8e',
                    'stored_pairs': 14, 'kind': 'damaged-encryption-sync-recovery',
                    'expected': 'Reject pair-8 ESS; flush pending audio; qualify 225 frames and recover'},
    'late-entry': {'path': 'fixtures/p25-rx-qualification/late-entry.bin',
                   'sha256': '9f3a6e8cb3835b628f84929aa0dccc2a1aef086ca60488c8012e8fb66ff771df',
                   'stored_pairs': 14, 'has_hdu': False, 'kind': 'clear-late-entry-without-header',
                   'expected': 'Withhold first LDU1/LDU2; qualify 234 clear voice frames'},
}


def packet(command, payload=b''):
    if len(payload) > 252:
        raise ValueError('Protocol-1 packet too large')
    return bytes((0xE0, len(payload) + 3, command)) + payload


def load_frames(path, pairs, case='clear'):
    if case not in CASES:
        raise ValueError('Unknown named fixture case')
    if not 1 <= pairs <= 28:
        raise ValueError('Select 1..28 LDU pairs (0.36..10.08 seconds of voice)')
    if case != 'clear' and pairs != 14:
        raise ValueError('Qualification controls require exactly 14 pairs (5.04 seconds)')
    definition = CASES[case]
    data = Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest() != definition['sha256']:
        raise ValueError('Fixture hash differs from selected named case: ' + case)
    header_bytes = 99 if definition.get('has_hdu', True) else 0
    if len(data) != header_bytes + definition['stored_pairs']*432 + 18:
        raise ValueError('Unexpected pinned fixture length')
    frames = [data[:header_bytes]] if header_bytes else []
    frames += [data[header_bytes+i*216:header_bytes+(i+1)*216] for i in range(2*pairs)]
    frames += [data[-18:]]
    if any(f[:6] != SYNC for f in frames):
        raise ValueError('Bad frame sync')
    # The leading zero is modem control data, stripped by CP25TX::writeData.
    return [packet(0x30 if header_bytes and i == 0 else 0x31, b'\0' + f)
            for i, f in enumerate(frames)]


def configuration(path, frequency, power):
    cfg = configparser.ConfigParser(interpolation=None, strict=False)
    if not cfg.read(path):
        raise ValueError('Cannot read MMDVMHost configuration')
    if cfg.getint('General', 'Duplex') != 0:
        raise ValueError('Only simplex MMDVM_HS is supported')
    modem = cfg['Modem']
    port = modem.get('UARTPort') if modem.get('Protocol') == 'uart' else modem['Port']
    if not port:
        raise ValueError('No serial port configured')
    baud = int(modem.get('UARTSpeed', '115200'))
    if not (144000000 <= frequency <= 148000000 or 420000000 <= frequency <= 450000000):
        raise ValueError('Frequency outside this bench tool\'s VHF/UHF ham ranges')
    if not 0 < power <= 100:
        raise ValueError('RF power must be 1..100 percent (not calibrated watts)')
    rx = frequency + int(modem.get('RXOffset', '0'))
    tx = frequency + int(modem.get('TXOffset', '0'))
    freq = packet(4, b'\0' + struct.pack('<II', rx, tx) + bytes((int(power*255/100+0.5),)))
    flags = 0x80
    for bit, name in enumerate(('RXInvert', 'TXInvert', 'PTTInvert')):
        flags |= (int(modem.get(name, '0')) != 0) << bit
    def level(name):
        value = float(modem.get(name, '50'))
        if not 0 <= value <= 100:
            raise ValueError('Invalid level: ' + name)
        return int(value*255/100+0.5)
    delay = int(modem.get('TXDelay', '100')) // 10
    if not 0 <= delay <= 50:
        raise ValueError('TXDelay exceeds modem range')
    # Minimal supported HS configuration: P25 only, idle, simplex.
    config = packet(2, bytes((flags, 8, delay, 0, level('RXLevel'),
                            0, 1, 0, 128, 0, 0, 0, level('P25TXLevel'))))
    return port, baud, freq, config, 0.05 + delay*0.01


class Link:
    def __init__(self, serial):
        self.serial = serial
        self.pending = bytearray()

    def send(self, data):
        if self.serial.write(data) != len(data):
            raise RuntimeError('Short serial write')

    def receive(self, timeout=1.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            while self.pending:
                if self.pending[0] != 0xE0:
                    del self.pending[0]
                    continue
                if len(self.pending) < 2:
                    break
                size = self.pending[1]
                if size < 3:
                    raise RuntimeError('Invalid protocol-1 response length')
                if len(self.pending) < size:
                    break
                result = bytes(self.pending[:size])
                del self.pending[:size]
                if result[2] == 0x7F:
                    raise RuntimeError('Modem NAK: ' + result.hex())
                return result
            self.pending.extend(self.serial.read(256))
        raise TimeoutError('Modem response timeout')

    def query(self, command):
        self.send(packet(command))
        deadline = time.monotonic() + 1.0
        while time.monotonic() < deadline:
            response = self.receive(max(0.001, deadline-time.monotonic()))
            if response[2] == command:
                return response
        raise TimeoutError('Missing query response')

    def command(self, data):
        self.send(data)
        deadline = time.monotonic() + 1.0
        while time.monotonic() < deadline:
            response = self.receive(max(0.001, deadline-time.monotonic()))
            if response[2] == 0x70 and response[3:] == data[2:3]:
                return
        raise TimeoutError('Missing command ACK')

    def status(self):
        value = self.query(1)
        if len(value) < 11:
            raise RuntimeError('Short modem status')
        if value[5] & 0x0E:
            raise RuntimeError('Modem overflow/lockout: ' + value.hex())
        return {'p25': bool(value[3] & 8), 'mode': value[4],
                'tx': bool(value[5] & 1), 'space': value[10]}


def require_exclusive_services():
    for name in ('mmdvmhost', 'p25gateway', 'mmdvmhost.timer', 'p25gateway.timer',
                 'pistar-watchdog', 'pistar-watchdog.timer'):
        result = subprocess.run(['systemctl', 'is-active', name],
                                capture_output=True, text=True, timeout=5)
        if result.stdout.strip() not in ('inactive', 'failed'):
            raise RuntimeError('Stop/isolate service before modem access: ' + name)
    # Also reject manually launched hosts, including those outside systemd.
    result = subprocess.run(['pgrep', '-x', 'MMDVMHost'], capture_output=True, timeout=5)
    if result.returncode != 1:
        raise RuntimeError('MMDVMHost still running or process check failed')


def replay(link, frames, lead, clock=time.monotonic, sleep=time.sleep):
    start = clock()
    duration = sum(len(f)-4 for f in frames) / 1200 + lead
    sent = 0
    saw_tx = False
    last_send = start
    while clock() - start < duration + 8:
        status = link.status()
        if not status['p25'] or status['mode'] not in (0, 4):
            raise RuntimeError('Modem left P25/idle state')
        saw_tx |= status['tx']
        # One unit per fresh status, reserving a whole LDU slot like MMDVMHost.
        if sent < len(frames) and status['space'] > 1:
            link.send(frames[sent])
            sent += 1
            last_send = clock()
        elif sent == len(frames) and saw_tx and not status['tx'] and clock()-last_send > 0.5:
            return {'units_sent': sent, 'elapsed_s': round(clock()-start, 3),
                    'tx_observed': True, 'rf_decode_verified': False}
        sleep(0.02)
    raise TimeoutError('Replay/drain deadline exceeded; no more data will be sent')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', choices=tuple(CASES), default='clear',
                        help='Pinned fixture identity; negative controls label clear tone bits, not ciphertext')
    parser.add_argument('--fixture', type=Path, help='Optional relocated file; its hash must match --case')
    parser.add_argument('--pairs', type=int, default=14)
    parser.add_argument('--config', default='/etc/mmdvmhost')
    parser.add_argument('--frequency', type=int, help='Explicit test frequency in Hz')
    parser.add_argument('--rf-power', type=int, default=10, help='Uncalibrated percent')
    parser.add_argument('--transmit', action='store_true')
    parser.add_argument('--lead-in-seconds', type=int, choices=range(31), default=0,
                        help='Wait after modem identification before configuration/TX (0..30 seconds)')
    args = parser.parse_args()
    definition = CASES[args.case]
    fixture = args.fixture or Path(__file__).resolve().parents[1]/definition['path']
    frames = load_frames(fixture, args.pairs, args.case)
    print(json.dumps({'dry_run': not args.transmit, 'units': len(frames),
                      'voice_s': args.pairs*0.36, 'voice_frames': args.pairs*18,
                      'nac': '293', 'tg': 1, 'source': 1,
                      'fixture_sha256': definition['sha256'], 'case': args.case,
                      'kind': definition['kind'], 'expected': definition['expected'],
                      'negative_control_not_ciphertext': args.case != 'clear'}), flush=True)
    if not args.transmit:
        return
    if args.frequency is None:
        parser.error('--transmit requires --frequency')
    port, baud, freq, config, lead = configuration(args.config, args.frequency, args.rf_power)
    require_exclusive_services()
    import serial  # Optional dependency: needed only for explicit hardware operation.
    with serial.Serial(port, baud, timeout=0.02, write_timeout=1, exclusive=True) as device:
        link = Link(device)
        version = link.query(0)
        if len(version) < 5 or version[3] != 1 or b'MMDVM_HS' not in version[4:]:
            raise RuntimeError('Only identified MMDVM_HS protocol 1 is supported')
        print(json.dumps({'modem': version[4:].split(b'\0')[0].decode('ascii'),
                          'frequency_hz': args.frequency, 'rf_power_percent': args.rf_power}), flush=True)
        if link.status()['tx']:
            raise RuntimeError('Modem is already transmitting')
        # Wait before configuring the modem, so no RF or FIFO data is pending.
        if args.lead_in_seconds:
            time.sleep(args.lead_in_seconds)
        link.command(freq)
        link.command(config)
        try:
            print(json.dumps(replay(link, frames, lead)), flush=True)
        finally:
            # Idle is best-effort, NOT a guaranteed hardware FIFO flush.
            # On failure cease commands/data; the modem watchdog is the fallback.
            try:
                link.command(packet(3, b'\0'))
            except (RuntimeError, TimeoutError, OSError):
                pass


if __name__ == '__main__':
    main()
