param([string]$Python = 'python', [string]$Compiler = 'gcc', [string]$Node = 'node')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$upstream = Join-Path $projectRoot 'external/RadioFoundry/RadioFoundry'
$build = Join-Path $projectRoot 'build/web-cps-validation'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$originalLibrary = $env:CPS_ADAPTER_LIBRARY
$originalPython = $env:CPS_TEST_PYTHON
Push-Location $projectRoot
try {
    $includes = @('hal','core','drivers','boards/dm32','platform/hrc7000','platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include') | ForEach-Object { '-I' + (Join-Path $upstream $_) }
    $arguments = @('-std=gnu11','-O1','-g','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
        '-Itests/diag-stubs','-DBENCH_GIT="host-web-cps-test"','-DDM32_LAB_DIAGNOSTICS=1','-DCONFIG_DMR=1') + $includes + @(
        '-Isrc/firmware','-Ifixtures/p25-1011','tests/test_cps_adapter.c','tests/diag-stubs/radio_dmr_stub.c',
        'src/firmware/p25_demod.c','src/firmware/p25_receive_bench.c','src/firmware/p25_rx.c',
        'src/firmware/p25_call.c','src/firmware/p25_live_tx.c','src/firmware/p25_live_frame.c','src/firmware/p25_test_tx.c')
    & $Compiler @arguments -o (Join-Path $build 'test_cps_adapter.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Actual CPS parser build failed' }
    & (Join-Path $build 'test_cps_adapter.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Actual CPS parser checks failed' }
    $library = Join-Path $build $(if ($IsWindows) { 'cps_adapter.dll' } else { 'cps_adapter.so' })
    $shared = @('-shared')
    if (-not $IsWindows) { $shared += '-fPIC' }
    & $Compiler @arguments @shared -o $library
    if ($LASTEXITCODE -ne 0) { throw 'Actual CPS shared bridge build failed' }
    $env:CPS_ADAPTER_LIBRARY = $library
    $env:CPS_TEST_PYTHON = $Python
    $tests = Get-ChildItem -LiteralPath (Join-Path $projectRoot 'integrations/web-cps/tests') -Filter '*.test.js' | ForEach-Object FullName
    & $Node --test @tests 2>&1 | Tee-Object -FilePath (Join-Path $build 'tests.tap')
    if ($LASTEXITCODE -ne 0) { throw 'Browser CPS codec/transport/real parser checks failed' }
} finally {
    $env:CPS_ADAPTER_LIBRARY = $originalLibrary
    $env:CPS_TEST_PYTHON = $originalPython
    Pop-Location
}
