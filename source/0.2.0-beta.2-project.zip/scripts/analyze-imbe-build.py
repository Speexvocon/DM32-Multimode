"""Audit a downloaded benchmark artifact without accessing hardware."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import runpy
import struct

ROOT = Path(__file__).resolve().parents[1]


def symbol_records(text):
    return [(int(address, 16), int(size, 16), kind, name) for address, size, kind, name in
            re.findall(r'^([0-9a-fA-F]+) ([0-9a-fA-F]+) ([A-Za-z]) (\S+)$', text, re.M)]


def symbol_bytes(elf, address, size):
    if len(elf) < 52:
        raise ValueError('Truncated ELF size evidence')
    offset = struct.unpack_from('<I', elf, 32)[0]
    stride, count = struct.unpack_from('<HH', elf, 46)
    if stride != 40 or not count or offset+stride*count > len(elf):
        raise ValueError('Invalid ELF section table for size evidence')
    matches = []
    for index in range(count):
        _, kind, flags, base, file_offset, length, _, _, _, _ = struct.unpack_from('<10I', elf, offset+index*stride)
        if kind == 1 and flags & 2 and base <= address and address+size <= base+length:
            begin = file_offset+address-base
            if file_offset+length > len(elf):
                raise ValueError('Codec size evidence exceeds ELF data')
            matches.append(elf[begin:begin+size])
    if len(matches) != 1 or len(matches[0]) != size:
        raise ValueError('Codec size evidence lacks a unique file-backed section')
    return matches[0]


def executable_ram_symbol(elf, address, size):
    offset = struct.unpack_from('<I', elf, 32)[0]
    stride, count = struct.unpack_from('<HH', elf, 46)
    if not size or stride != 40 or offset+stride*count > len(elf):
        raise ValueError('Invalid deferred DMR symbol evidence')
    for index in range(count):
        _, kind, flags, base, _, length, _, _, _, _ = struct.unpack_from('<10I', elf, offset+index*stride)
        if kind == 1 and flags & 6 == 6 and 0x10000 <= base <= address and address+size <= base+length <= 0x43a00:
            return True
    raise ValueError('Deferred DMR drain is not fully inside executable startup RAM')


def generated_live_objects(map_text):
    marker = 'Linker script and memory map'
    if marker not in map_text:
        raise ValueError('Missing linked-map object evidence')
    linked = map_text.split(marker, 1)[1]
    sections = re.findall(r'^ (\.[^\s]+)\s+0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)\s+([^\s]+\.o)', linked, re.M)
    result = {}
    names = ('vocoder', 'audio_pcm', 'dmr_glue', 'radio_dmr', 'codec_workspace')
    for name in names:
        total = sum(int(length, 16) for section, _, length, owner in sections if
                    owner.replace('\\', '/').endswith('/multimode/'+name+'.o') and
                    section.startswith(('.text', '.rodata', '.srodata', '.data', '.bss', '.ramfunc', '.ram_lo')))
        if not total:
            raise ValueError('Missing linked generated/glue object: '+name)
        result[name] = {'linked_input_section_bytes': total, 'owner_suffix': '/multimode/'+name+'.o'}
    for section, _, length, owner in sections:
        if int(length, 16) and section.startswith(('.text', '.rodata', '.srodata', '.data', '.bss', '.ramfunc', '.ram_lo')) and any(
                owner.replace('\\', '/').endswith('/platform/hrc7000/'+name+'.o') for name in names[:3]):
            raise ValueError('Unreplaced pinned live object: '+owner)
    return result


def codec_storage(elf, symbols, live, lab_diagnostics=True):
    records = symbol_records(symbols)
    def one(name, kinds):
        found = [row for row in records if row[3] == name and row[2] in kinds]
        if len(found) != 1:
            raise ValueError('Missing or duplicated codec storage evidence: '+name)
        return found[0]
    if not live:
        state = one('_ZL5state', 'bB')
        return {'kind': 'standalone_static', 'software_object_bytes': state[1], 'workspace_bytes': state[1]}
    arena = one('codec_workspace', 'bB')
    if arena[1] != 5736 or arena[0] % 8 or not 0x10000 <= arena[0] < arena[0]+arena[1] <= 0x43a00:
        raise ValueError('P25 codec store size/alignment differs')
    duplicates = [name for _, size, kind, name in records if size and kind in 'bBdD' and
                  name in ('_ZL5state', 'dec_state', 'enc_state', 'bitbuf', 'pcmbuf')]
    if duplicates:
        raise ValueError('Duplicate live codec allocation: '+', '.join(duplicates))
    evidence = one('imbe_codec_object_bytes', 'rRtT')
    if evidence[1] != 4:
        raise ValueError('Invalid software codec class-size constant')
    software_bytes = int.from_bytes(symbol_bytes(elf, evidence[0], 4), 'little')
    if not 0 < software_bytes <= arena[1]:
        raise ValueError('Software codec object exceeds dedicated P25 store')
    receive = one('rx_storage', 'bB')
    borrowed = one('radio_codec_dmr_borrowed_bytes', 'rRtT')
    if borrowed[1] != 4:
        raise ValueError('Missing native borrowed-window size constant')
    borrowed_bytes = int.from_bytes(symbol_bytes(elf, borrowed[0], 4), 'little')
    minimum_receive = 74476 if lab_diagnostics else 28808
    if borrowed_bytes != 13776 or receive[0] % 8 or receive[1] < minimum_receive or not (
            0x10000 <= receive[0] < receive[0]+receive[1] <= 0x43a00):
        raise ValueError('Receive/capture union size/alignment or native borrowed prefix differs')
    if not lab_diagnostics:
        retained = [name for _, size, kind, name in records if size and kind in 'bBdD' and name in ('mon_perf', 'rx_signals')]
        if receive[1] >= 30000 or retained:
            raise ValueError('Normal profile retains a large capture, trace or diagnostic history')
    if arena[0] < receive[0]+receive[1] and receive[0] < arena[0]+arena[1]:
        raise ValueError('P25 codec state overlaps receive/capture union')
    required = ('radio_codec_acquire', 'radio_codec_release', 'radio_codec_begin', 'radio_codec_end',
                'radio_codec_dmr_storage', 'hrc_vocoder_quiesce', 'hrc_vocoder_resume', 'imbe_bench_release',
                'radio_dmr_start', 'radio_dmr_stop', 'radio_dmr_poll', 'hrc_dmr_deferred_drain', 'radio_codec_bind_dmr')
    for name in required:
        one(name, 'tT')
    drain = one('hrc_dmr_deferred_drain', 'tT')
    executable_ram_symbol(elf, drain[0], drain[1])
    return {'kind': 'dmr_overlay_on_p25_receive_union', 'address': hex(arena[0]), 'workspace_bytes': arena[1],
            'software_object_bytes': software_bytes, 'class_size_evidence': 'imbe_codec_object_bytes in linked ELF',
            'receive_capture_union': {'address': hex(receive[0]), 'bytes': receive[1], 'minimum_preserved_bytes': minimum_receive, 'lab_diagnostics': lab_diagnostics},
            'native_borrowed_window': {'address': hex(receive[0]), 'bytes': borrowed_bytes, 'offset': 0,
                'size_evidence': 'radio_codec_dmr_borrowed_bytes in linked ELF', 'binding_execution_measured': False},
            'native_slices_bytes': {'decoder': 6144, 'encoder': 7168, 'bits': 144, 'pcm': 320},
            'duplicate_static_allocations_absent': True, 'handoff_symbols_present': list(required),
            'dmr_deferred_drain_ram': {'address': hex(drain[0]), 'bytes': drain[1]},
            'runtime_handoff_qualified': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--require-pitch-ram", action="store_true")
    parser.add_argument("--require-codec-ram", action="store_true")
    parser.add_argument("--live", action="store_true", help="Audit live RF app with only PCM encode entry retained")
    parser.add_argument("--lab-diagnostics", action="store_true", help="Expect retained engineering capture/trace storage in a live image")
    args = parser.parse_args()
    directory = args.directory
    elf = (directory / "imbe-bench-dm32.elf").read_bytes()
    if elf[:6] != b"\x7fELF\x01\x01" or struct.unpack_from("<H", elf, 18)[0] != 252:
        raise ValueError("Not a little-endian 32-bit C-SKY ELF")
    if struct.unpack_from("<I", elf, 24)[0] != 0x0300C000:
        raise ValueError("Unexpected application entry")
    symbols = (directory / "imbe-symbols.txt").read_text()
    placement = {}
    if args.require_pitch_ram or args.require_codec_ram:
        # Check actual linked sections, not just a successful objcopy invocation.
        shoff = struct.unpack_from("<I", elf, 32)[0]
        shsize, shnum, shstr = struct.unpack_from("<HHH", elf, 46)
        sections = [struct.unpack_from("<10I", elf, shoff + i * shsize) for i in range(shnum)]
        names_section = sections[shstr]
        names = elf[names_section[4]:names_section[4] + names_section[5]]
        ram = next(s for s in sections if names[s[0]:].split(b"\0", 1)[0] == b".ramfunc")
        if not (ram[2] & 4 and 0x10000 <= ram[3] < ram[3] + ram[5] <= 0x43a00):
            raise ValueError("Invalid executable RAM section")
        for name in ("_ZN17imbe_vocoder_impl9pitch_estEP10IMBE_PARAMPs", "_ZN17imbe_vocoder_impl3e_pEPsS0_"):
            match = re.search(r"^([0-9a-f]+) ([0-9a-f]+) [tT] " + name + r"$", symbols, re.M)
            if not match:
                raise ValueError("Missing hot routine: " + name)
            address, size = (int(value, 16) for value in match.groups())
            if not (size and ram[3] <= address < address + size <= ram[3] + ram[5]):
                raise ValueError("Hot routine is not fully inside .ramfunc: " + name)
            placement[name] = {"address": hex(address), "bytes": size}
        # Confirm the startup copy has its initial bytes in the application bin.
        phoff = struct.unpack_from("<I", elf, 28)[0]
        phsize, phnum = struct.unpack_from("<HH", elf, 42)
        segments = [struct.unpack_from("<8I", elf, phoff + i * phsize) for i in range(phnum)]
        segment = next(p for p in segments if p[0] == 1 and p[2] <= ram[3] and ram[3] + ram[5] <= p[2] + p[4])
        load = segment[3] + ram[3] - segment[2]
        raw = (directory / "imbe-bench-dm32.bin").read_bytes()
        offset = load - 0x0300c000
        if offset < 0 or raw[offset:offset + ram[5]] != elf[ram[4]:ram[4] + ram[5]]:
            raise ValueError("RAM initialization bytes missing from application image")
        placement["ramfunc_load"] = hex(load)
        if args.require_codec_ram:
            map_text = (directory / "imbe-bench-dm32.map").read_text().split('Linker script and memory map', 1)[1]
            entries = re.findall(r'^ (\.[^\s]+)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\s]+/imbe/[^\s]+\.o)', map_text, re.M)
            moved, total = 0, 0
            for section, addr, length, owner in entries:
                if owner.endswith('/app.o'):
                    continue
                address, size = int(addr, 16), int(length, 16)
                if not size:
                    continue
                if section.startswith(('.text', '.rodata', '.srodata')):
                    raise ValueError('Unrelocated codec section: ' + owner + ' ' + section)
                if section.startswith('.ramfunc.imbe_all'):
                    if not (ram[3] <= address < address + size <= ram[3] + ram[5]):
                        raise ValueError('Codec section outside RAM: ' + section)
                    moved += 1
                    total += size
            if moved < 10:
                raise ValueError('Missing full-codec placement evidence')
            placement['all_codec_sections'] = moved
            placement['all_codec_bytes'] = total
    for name in ("__wrap_app_start", "imbe_bench_init", "imbe_bench_encode_pcm" if args.live else "imbe_bench_encode"):
        if not re.search(r"\b" + name + r"$", symbols, re.M):
            raise ValueError("Missing linked symbol: " + name)
    storage = codec_storage(elf, symbols, args.live, args.lab_diagnostics)
    generated = generated_live_objects((directory/'imbe-bench-dm32.map').read_text()) if args.live else None
    log = (directory / "imbe-benchmark.log").read_text()
    if "warning:" in log:
        raise ValueError("Compiler warning in benchmark build")
    memory = [line.strip() for line in log.splitlines() if re.search(r"\b(?:FLASH|RAM|RAM_LO):", line)]
    # Reuse the pinned MIT parser; report unresolved library stack explicitly.
    upstream = ROOT / "external/RadioFoundry/RadioFoundry"
    module = runpy.run_path(str(upstream / "tools/stack_check.py"))
    graph = module["Graph"]()
    count = graph.load_dir(str(directory / "imbe-stack"))
    if not count:
        raise ValueError("Missing stack graph")
    unknown, cycles = set(), set()
    def chain(node, path=()):
        if node in path:
            cycles.add(node)
            return 0, []
        function = graph.funcs.get(node)
        if function is None or function.frame is None:
            unknown.add(node)
        children = [chain(child, path + (node,)) for child, _ in graph.edges.get(node, [])]
        best = max(children, key=lambda pair: pair[0], default=(0, []))
        own_frame = function.frame if function is not None and function.frame is not None else 0
        return own_frame + best[0], [node] + best[1]
    stacks = {}
    stack_entries = ("imbe_bench_init", "imbe_bench_encode_pcm", "imbe_bench_decode_pcm", "p25_demod_push") if args.live else ("imbe_bench_init", "imbe_bench_encode", "imbe_bench_encode_pcm")
    if args.live and args.lab_diagnostics:
        stack_entries += ("p25_receive_bench",)
    for name in stack_entries:
        entries = [name] if graph.defined(name) else graph.lookup(name)
        if not entries:
            raise ValueError("Missing stack entry: " + name)
        depth, path = max((chain(entry) for entry in entries), key=lambda pair: pair[0])
        stacks[name] = {"known_chain_bytes": depth, "path": path}
    report = {"entry": "0x0300c000", "codec_state_bytes": storage['software_object_bytes'], 'codec_storage': storage,
              "task_stack_allocated_bytes": 16384, "memory_summary": memory,
              "stack": stacks, "unmeasured_library_stack": sorted(unknown), "cycles": sorted(cycles),
              "stack_limitation": "Known compiler-reported direct chains only; external library and ISR/RTOS overhead not included. Confirm runtime high-water mark.",
              "files": {name: {"bytes": (directory / name).stat().st_size,
                                  "sha256": hashlib.sha256((directory / name).read_bytes()).hexdigest()}
                        for name in ("imbe-bench-dm32.bin", "imbe-bench-dm32.elf", "imbe-bench-dm32.map")},
              "hardware_timing_measured": False}
    if placement:
        report["pitch_ram_placement"] = placement
    if generated:
        report['generated_live_objects'] = generated
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
