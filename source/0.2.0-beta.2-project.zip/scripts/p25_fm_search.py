"""Exploratory 8-kHz FM sample slicer; fixed clock, no adaptive equalizer.

Extracted unchanged from the first hardware capture analysis so validation
exercises the same search. This is not a production P25 demodulator.
"""
import numpy as np
from scipy import signal

def search(samples, clock_ppm=0):
    if not np.isfinite(clock_ppm) or abs(clock_ppm)>1000:raise ValueError('Clock offset must be within +/-1000 ppm')
    step=10*(1+clock_ppm*1e-6)
    x=np.asarray(samples,dtype=float).copy()
    if x.size<2000 or not np.all(np.isfinite(x)):raise ValueError("Need at least 2000 finite samples")
    x-=np.mean(x)
    sync=np.array([(v>>shift)&3 for v in bytes.fromhex('5575f5ff77ff') for shift in (6,4,2,0)])
    biterr=np.array([0,1,1,2])
    best=None
    for treatment in ('raw','average','preemphasis','preemphasis_average'):
        d=signal.resample_poly(x,6,1)
        if 'preemphasis' in treatment:d=d+np.r_[0,np.diff(d)]*48000*75e-6
        if 'average' in treatment:d=signal.fftconvolve(d,np.ones(10)/10,mode='same')
        for phase in np.arange(0,10,0.25):
            y=np.interp(np.arange(phase,len(d)-1,step),np.arange(len(d)),d)
            fit=y[1000:]
            centers=np.quantile(fit,[.1,.35,.65,.9])
            for _ in range(10):
                lab=np.argmin(abs(fit[:,None]-centers),axis=1)
                centers=np.array([fit[lab==i].mean() if np.any(lab==i) else centers[i] for i in range(4)])
            lab=np.argmin(abs(y[:,None]-centers),axis=1)
            for inverted in (False,True):
                db=np.array([3,2,0,1],dtype=np.uint8)[3-lab if inverted else lab]
                win=np.lib.stride_tricks.sliding_window_view(db,len(sync))
                errors=biterr[win^sync].sum(axis=1)
                hits=np.flatnonzero(errors<=2)
                valid=[]
                for i in hits:
                    if i+32<=len(db):
                        v=0
                        for q in db[i+24:i+32]:v=(v<<2)|int(q)
                        if v>>4==0x293 and v&15 in (0,3,5,10):valid.append(int(i))
                score=(len(valid),len(hits),-int(errors.min()))
                if best is None or score>best[0]:
                    best=(score,dict(treatment=treatment,phase=float(phase),clock_ppm=float(clock_ppm),inverted=inverted,
                                    centers=centers.tolist(),sync_hits=hits.tolist(),matching_nac_duid=valid,
                                    minimum_sync_bit_errors=int(errors.min())),db.copy())
    return best[1],best[2]

if __name__ == '__main__':
    import argparse
    import hashlib
    import json
    from pathlib import Path
    import subprocess
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path,help='Big-endian signed 16-bit mono FM samples at 8 kHz')
    parser.add_argument('--output',type=Path,required=True,help='New evidence directory')
    args=parser.parse_args()
    raw=args.input.read_bytes()
    if len(raw)%2:parser.error('Input has an incomplete sample')
    args.output.mkdir(parents=True,exist_ok=False)
    details,dibits=search(np.frombuffer(raw,dtype='>i2'))
    path=args.output/'dibits.bin'
    dibits.tofile(path)
    replay=Path(__file__).resolve().parents[1]/'build/p25-rx/replay.exe'
    result=subprocess.run([str(replay),str(path),str(args.output/'decoded.s16le')],
                          capture_output=True,text=True)
    # The bench replay explicitly returns 6 when it decoded no voice frames.
    if result.returncode not in (0,6):result.check_returncode()
    report=dict(input_sha256=hashlib.sha256(raw).hexdigest(),search=details,
                replay_stdout=result.stdout,replay_exit_code=result.returncode,
                limitation='Exploratory fixed-clock search. No analog-path equalization, adaptive clock recovery or measured RF BER.')
    (args.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(result.stdout.strip())
