"""Specialize correlation shifts without changing reference arithmetic/order."""
import argparse
from pathlib import Path


def generate(source):
    start = source.index('Word32 imbe_vocoder_impl::autocorr(')
    end = source.index('\nvoid imbe_vocoder_impl::e_p(', start)
    original = source[start:end]
    loop = ('for(i = 0; i < PITCH_EST_FRAME - shift; i++)\n'
            '\t\tL_sum = L_add(L_sum, L_shr(L_mult(sigin[i], sigin[i + shift]), scale_shift) );')
    if original.count(loop) != 1:
        raise ValueError('Reference correlation anchor changed')
    # Keep every saturating operation, accumulation order and flag side effect.
    # Only move selection of invariant shift outside the sample loop. Retain
    # the generic path for every other shift value.
    branches = ('if (scale_shift == 0) {\n\t\t' + loop.replace('scale_shift)', '0)') +
                '\n\t} else if (scale_shift == 5) {\n\t\t' + loop.replace('scale_shift)', '5)') +
                '\n\t} else {\n\t\t' + loop + '\n\t}')
    result = source[:start] + original.replace(loop, branches) + source[end:]
    declarations = '''// Exact memoization for the single-threaded benchmark codec.
// Key includes every input sample and both fixed-point arithmetic flags.
struct ImbePitchCacheEntry {
    bool valid;
    Flag input_overflow, input_carry, output_overflow, output_carry;
    Word16 input[PITCH_EST_FRAME], output[203];
};
static ImbePitchCacheEntry imbe_pitch_cache[3];
static unsigned imbe_pitch_cache_next;
'''
    anchor = 'void imbe_vocoder_impl::pitch_est_init(void)\n{'
    if result.count(anchor) != 1:
        raise ValueError('Pitch initialization anchor changed')
    result = result.replace(anchor, declarations + '\n' + anchor + '''
    for (unsigned slot=0; slot<3; ++slot) imbe_pitch_cache[slot].valid=false;
    imbe_pitch_cache_next=0;
''')
    anchor = 'void imbe_vocoder_impl::e_p(Word16 *sigin, Word16 *res_buf)\n{'
    if result.count(anchor) != 1:
        raise ValueError('Pitch energy entry anchor changed')
    result = result.replace(anchor, anchor + '''
    const Flag input_overflow=Overflow, input_carry=Carry;
    for (unsigned slot=0; slot<3; ++slot) {
        const ImbePitchCacheEntry &cached=imbe_pitch_cache[slot];
        if (cached.valid && cached.input_overflow==input_overflow &&
            cached.input_carry==input_carry &&
            memcmp(cached.input,sigin,sizeof cached.input)==0) {
            memcpy(res_buf,cached.output,sizeof cached.output);
            Overflow=cached.output_overflow;
            Carry=cached.output_carry;
            return;
        }
    }
''')
    end = result.index('\nvoid imbe_vocoder_impl::pitch_est(IMBE_PARAM')
    close = result.rfind('}', 0, end)
    result = result[:close] + '''
    ImbePitchCacheEntry &cached=imbe_pitch_cache[imbe_pitch_cache_next];
    imbe_pitch_cache_next=(imbe_pitch_cache_next+1)%3;
    memcpy(cached.input,sigin,sizeof cached.input);
    memcpy(cached.output,res_buf,sizeof cached.output);
    cached.input_overflow=input_overflow;
    cached.input_carry=input_carry;
    cached.output_overflow=Overflow;
    cached.output_carry=Carry;
    cached.valid=true;
''' + result[close:]
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(generate(args.source.read_text()), encoding='utf-8')
