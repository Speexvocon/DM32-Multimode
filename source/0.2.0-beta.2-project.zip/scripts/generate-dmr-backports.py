"""Apply two reviewed upstream DMR fixes to generated copies of the pinned tree.

The external checkout remains untouched. Input and patch digests fail closed;
only the selected call-stack, header, slot-engine and upstream host tests can
be generated, and output is confined to this project's ignored build tree.
"""
import argparse
import hashlib
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PATCH_DIR = ROOT / "src/firmware/radiofoundry-patches"
PATCH_SHA256 = {
    "b5d025d0ce.patch": "4339a81c8aaaecc735bb9eda9fc395d3d05e2b7487aac55fda35d01abbb7fc03",
    "4ba400af7a.patch": "8dc0cf5a129a541afe469a2286cbcaa25bddd4ba5997713c7c2036eb309d0161",
}
PINNED_SHA256 = {
    "drivers/modem/hrc7000/hrc7000_dmr.c": "d6ce1b60b31b5ded74cba707744c54d4bae8c83d9a4fcd832f2d04067631cc55",
    "tests/host/hrc7000DmrTest.c": "32a70819ddf922cd4a4fe0d6a5a287369053657105259d7b7e8456e7314ad368",
    "core/dmr/call/dmr_call.c": "9d50aba4827f7d4565b31c9a02d1f3bad2e5a045506579d2c3de36c09356ca29",
    "core/dmr/call/dmr_call.h": "047372c1082fe4b0f0867b5da48b9fbb1eca8b65461b215244ae4c4d952054c8",
    "tests/host/dmrCallTest.c": "f287cb87509085a8186d74044ee1ffecbbf16091763f78bb872bc383c8becd22",
}


def patches():
    """Read selected unified hunks without accepting arbitrary paths or commands."""
    result = {}
    for name, digest in PATCH_SHA256.items():
        text = (PATCH_DIR / name).read_text().replace("\r\n", "\n")
        if hashlib.sha256(text.encode()).hexdigest() != digest:
            raise ValueError("Reviewed DMR patch changed: " + name)
        path = None
        hunk = None
        for line in text.splitlines(keepends=True):
            if line.startswith("--- a/"):
                path = line[len("--- a/"):].strip()
                if path not in PINNED_SHA256:
                    raise ValueError("Unreviewed DMR patch path: " + path)
                result.setdefault(path, [])
                hunk = None
            elif line.startswith("+++ b/"):
                if line[len("+++ b/"):].strip() != path:
                    raise ValueError("DMR patches cannot rename files")
            elif line.startswith("@@ "):
                match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n?", line)
                if path is None or match is None:
                    raise ValueError("Malformed DMR patch hunk")
                hunk = {"old": [], "new": [], "counts": (int(match[2] or 1), int(match[4] or 1))}
                result[path].append(hunk)
            elif hunk is not None:
                if line[:1] not in (" ", "+", "-"):
                    raise ValueError("Malformed DMR patch line")
                if line[0] in " -":
                    hunk["old"].append(line[1:])
                if line[0] in " +":
                    hunk["new"].append(line[1:])
    if set(result) != set(PINNED_SHA256):
        raise ValueError("Incomplete reviewed DMR patch set")
    for hunks in result.values():
        for hunk in hunks:
            if (len(hunk["old"]), len(hunk["new"])) != hunk["counts"]:
                raise ValueError("Truncated DMR patch hunk")
    return result


def generate(path, text):
    text = text.replace("\r\n", "\n")
    if path not in PINNED_SHA256 or hashlib.sha256(text.encode()).hexdigest() != PINNED_SHA256[path]:
        raise ValueError("DMR input does not match the reviewed upstream pin: " + path)
    for hunk in patches()[path]:
        old, new = "".join(hunk["old"]), "".join(hunk["new"])
        if text.count(old) != 1:
            raise ValueError("Pinned DMR hunk is absent or ambiguous: " + path)
        text = text.replace(old, new, 1)
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("relative_path", choices=PINNED_SHA256)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to((ROOT / "build").resolve()):
        parser.error("generated DMR sources must remain under the ignored project build directory")
    generated = generate(args.relative_path, args.source.read_text())
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(generated, newline="\n")


if __name__ == "__main__":
    main()
