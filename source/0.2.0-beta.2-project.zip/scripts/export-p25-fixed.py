#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Export an exact fixed-tone P25 call for offline MMDVM comparisons.

Uses the pinned OP25 reference through generate-p25-channel.py. This script has
no radio, serial, or network access and never changes the firmware mask tables.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("fixed_channel_reference", ROOT / "scripts/generate-p25-channel.py")
channel_ref = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(channel_ref)


def bounded(value: int, label: str, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label} must be an integer in {low}..{high}")
    return value


def export(output: Path, *, nac: int = 0x293, talkgroup: int = 10,
           source_id: int = 1234567, pairs: int = 14, startup_extra: int = 0) -> dict:
    """Exclusively create output with protocol units and their physical stream."""
    bounded(nac, "NAC", 0, 0xFFF)
    bounded(talkgroup, "talkgroup", 0, 0xFFFF)
    bounded(source_id, "source ID", 0, 0xFFFFFF)
    bounded(pairs, "LDU pairs", 1, 28)
    bounded(startup_extra, "startup extra bytes", 0, 35)
    output = Path(output)
    if output.exists():
        raise FileExistsError(f"output directory already exists: {output}")

    provenance = json.loads((ROOT / "fixtures/p25-1011/manifest.json").read_text(encoding="utf-8"))["sources"]
    craft_hash = hashlib.sha256(channel_ref.CRAFT.read_bytes()).hexdigest()
    if craft_hash != provenance["p25craft_sha256"]:
        raise ValueError("OP25 p25craft.py does not match the pinned fixture reference")
    units = channel_ref.call(channel_ref.reference(), nac, talkgroup, source_id)
    if len(units) != 549:
        raise ValueError("reference did not produce HDU99/LDU216/LDU216/TDU18")
    hdu, ldu1, ldu2, tdu = units[:99], units[99:315], units[315:531], units[531:]
    call = hdu + (ldu1 + ldu2) * pairs + tdu
    preamble_bytes = 240 + startup_extra
    stream = b"\x77" * preamble_bytes + call
    tail_bytes = (-len(stream)) % 36
    files = {"hdu.bin": hdu, "ldu1.bin": ldu1, "ldu2.bin": ldu2, "tdu.bin": tdu,
             "call.bin": call, "tx-stream.bin": stream,
             "transport.bin": stream + b"\x77" * tail_bytes}
    ldu_offset = preamble_bytes + len(hdu)
    manifest = {
        "schema": "p25-fixed-export-v1",
        "purpose": "Exact fixed 1011-Hz P25 references; offline data, not flashable firmware",
        "nac_hex": f"{nac:03X}", "nac": nac, "talkgroup": talkgroup, "source_id": source_id,
        "algid_hex": "80", "ldu_pairs": pairs, "voice_frames_20ms": pairs * 18,
        "voice_seconds": pairs * 0.36, "startup_extra_bytes": startup_extra,
        "preamble_bytes": preamble_bytes, "fill_byte_hex": "77",
        "hdu_bytes": 99, "ldu_bytes": 216, "tdu_bytes": 18,
        "transport_block_bytes": 36, "transport_tail_bytes": tail_bytes,
        "ldu_first_byte_offset": ldu_offset, "ldu_phase_mod36": ldu_offset % 36,
        "ldu_last_byte_phase_mod36": (ldu_offset + 215) % 36,
        "symbol_rate": 4800, "bit_rate": 9600,
        "packing": "MSB first; four dibits per byte; status symbols included",
        "transport_note": "Only startup fill changes alignment. No padding between units; physical tail follows the complete TDU.",
        "sources": {"op25_commit": provenance["op25_commit"], "p25craft_sha256": craft_hash,
                    "channel_generator_sha256": hashlib.sha256((ROOT / "scripts/generate-p25-channel.py").read_bytes()).hexdigest()},
        "files": {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                  for name, data in files.items()},
    }
    # Generate and validate everything before claiming the new output directory.
    output.mkdir(parents=True, exist_ok=False)
    for name, data in files.items():
        with (output / name).open("xb") as stream_file:
            stream_file.write(data)
    with (output / "manifest.json").open("x", encoding="utf-8", newline="\n") as manifest_file:
        json.dump(manifest, manifest_file, indent=2)
        manifest_file.write("\n")
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nac", type=lambda value: int(value, 16), default=0x293,
                        help="NAC in hexadecimal (default: 293)")
    parser.add_argument("--tg", type=int, default=10, help="decimal talkgroup (default: 10)")
    parser.add_argument("--source", type=int, default=1234567, help="decimal source ID (default: 1234567)")
    parser.add_argument("--pairs", type=int, default=14, help="alternating LDU1/LDU2 pairs, 1..28 (default: 14)")
    parser.add_argument("--startup-extra", type=int, default=0, help="additional startup fill bytes, 0..35")
    parser.add_argument("--output", type=Path, required=True, help="new directory; existing directories are refused")
    args = parser.parse_args(argv)
    try:
        result = export(args.output, nac=args.nac, talkgroup=args.tg, source_id=args.source,
                        pairs=args.pairs, startup_extra=args.startup_extra)
    except (OSError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    print(json.dumps({"output": str(args.output), "nac_hex": result["nac_hex"],
                      "talkgroup": result["talkgroup"], "source_id": result["source_id"],
                      "ldu_pairs": result["ldu_pairs"], "startup_extra_bytes": result["startup_extra_bytes"],
                      "ldu_phase_mod36": result["ldu_phase_mod36"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
