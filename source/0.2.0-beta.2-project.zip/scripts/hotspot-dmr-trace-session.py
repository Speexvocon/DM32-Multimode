"""Prepare, or explicitly run, a bounded receive-only simplex DMR host trace.

Run on the Linux hotspot beside hotspot-p25-trace-session.py. The reviewed P25
session engine supplies process/service cleanup and the shared session lock.
No network is enabled, no replay is sent, and original configuration is untouched.
Use --capture SECONDS to execute; the default only prepares private files.
"""
import configparser
import importlib.util
import io
from pathlib import Path
import re
import sys


def load_engine():
    path = Path(__file__).with_name("hotspot-p25-trace-session.py")
    spec = importlib.util.spec_from_file_location("dm32_dmr_trace_engine", path)
    engine = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(engine)
    return engine


ENGINE = load_engine()
BASE_TRANSFORM = ENGINE.transform_config
# Verified on the owner's hotspot. Timers stop first and restart last.
ENGINE.UNITS = ("pistar-watchdog.timer", "pistar-watchdog.service", "mmdvmhost.timer",
                "p25gateway.timer", "dmrgateway.timer", "p25parrot.timer",
                "mmdvmhost.service", "p25gateway.service", "dmrgateway.service", "p25parrot.service")

# Verified against this hotspot's installed MMDVMHost binary format strings.
START = re.compile(r"^DMR Slot ([12]), received RF voice header from (.+?) to (.+)$")
TAIL = r", \d+(?:\.\d+)? seconds, BER: \d+(?:\.\d+)?%(?:, RSSI: -\d+/-\d+/-\d+ dBm)?$"
END = re.compile(r"^DMR Slot ([12]), received RF end of voice transmission from (.+?) to (.+?)" + TAIL)
LOST = re.compile(r"^DMR Slot ([12]), RF voice transmission lost from (.+?) to (.+?)" + TAIL)


class RFCallCompletion:
    """Only one identified RF voice header followed by its same-slot identity."""
    def __init__(self):
        self.identity = None
        self.ambiguous_start = False
        self.termination = None

    def feed(self, line):
        match = ENGINE.LOG_MESSAGE.fullmatch(line.rstrip("\r\n"))
        if not match or self.termination is not None:
            return None
        body = match[1]
        start = START.fullmatch(body)
        if start:
            if self.identity is not None:
                self.ambiguous_start = True
                return None
            self.identity = start.groups()
            return "start"
        if self.identity is None or self.ambiguous_start:
            return None
        for pattern, event in ((END, "end"), (LOST, "lost")):
            end = pattern.fullmatch(body)
            if end and end.groups() == self.identity:
                self.termination = event
                return event
        return None


def transform_config(raw, output):
    # Reuse the reviewed duplicate-key rejection, network/auxiliary disabling,
    # trace/log preparation and preservation of RF calibration settings.
    text, _ = BASE_TRANSFORM(raw, output)
    cfg = configparser.ConfigParser(interpolation=None, strict=True)
    cfg.optionxform = str
    cfg.read_string(text)
    if "DMR" not in cfg or cfg.getint("General", "Duplex", fallback=-1) != 0:
        raise ValueError("A configured simplex DMR hotspot is required")
    cc = cfg.getint("DMR", "ColorCode", fallback=-1)
    own = cfg.getint("General", "Id", fallback=0)
    if not 0 <= cc <= 15 or not 0 < own <= 0xffffff:
        raise ValueError("Invalid DMR color code or host ID")
    # SET_CONFIG and the installed host remain responsible for modem framing.
    # Simplex is mandatory: an RF call must never be repeated by this trace host.
    cfg["P25"]["Enable"] = "0"
    cfg["DMR"]["Enable"] = "1"
    cfg["DMR"]["Beacons"] = "0"
    cfg["DMR"]["BeaconInterval"] = "0"
    profile_keys = {
        "General": ("Callsign", "Id", "Duplex"),
        "Info": ("RXFrequency", "TXFrequency"),
        "Modem": ("Protocol", "Port", "UARTPort", "UARTSpeed", "RXOffset", "TXOffset",
                  "RXLevel", "DMRTXLevel", "RFLevel", "RXInvert", "TXInvert", "PTTInvert"),
        "DMR": ("ColorCode", "SelfOnly", "EmbeddedLCOnly", "DumpTAData", "Beacons"),
    }
    profile = {s: {k: cfg[s][k] for k in keys if s in cfg and k in cfg[s]}
               for s, keys in profile_keys.items()}
    stream = io.StringIO()
    cfg.write(stream, space_around_delimiters=False)
    return stream.getvalue(), profile


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ENGINE.transform_config = transform_config
    ENGINE.RFCallCompletion = RFCallCompletion
    # All modem access uses the same reviewed lock as P25 trace sessions.
    return ENGINE.main(argv)


if __name__ == "__main__":
    sys.exit(main())
