"""Generate a fixed 1011-Hz P25 call; no hardware access or RF transmission.

Uses pinned GPL-2.0-or-later OP25/MMDVM reference material; preserve their notices.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "fixtures/p25-1011"
REF = ROOT / "research/references"
PINS = json.loads((REF / "UPSTREAMS.json").read_text())
PAIRS = 28  # 28 * 360 ms = 10.08 seconds of voice
SYNC = bytes.fromhex("5575f5ff77ff")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    craft = REF / "boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py"
    cal = REF / "g4klx/MMDVM/CalP25.cpp"
    with tempfile.TemporaryDirectory() as temp:
        dest = Path(temp) / "call.bin"
        subprocess.run([sys.executable, str(craft), "--superframes", str(PAIRS),
                        "--1011", "--nac", "0x293", "--ss", "0", "--tgid", "1",
                        "--src", "1", "--algid", "0x80", "--output-file", str(dest)],
                       cwd=temp, check=True, stdout=subprocess.DEVNULL)
        call = dest.read_bytes()

    # OP25 produces HDU + alternating LDU1/LDU2 + simple TDU, including status symbols.
    if len(call) != 99 + 432 * PAIRS + 18:
        raise ValueError("Unexpected call length")
    hdu, pair, tdu = call[:99], call[99:531], call[-18:]
    text = cal.read_text(encoding="utf-8")
    for i, name in enumerate(("LDU1_1K", "LDU2_1K")):
        match = re.search(r"unsigned char " + name + r"\[\]\s*=\s*\{(.*?)\};", text, re.S)
        if match is None:
            raise ValueError("Missing MMDVM vector: " + name)
        framed = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-fA-F]+)", match[1]))
        if len(framed) != 217 or framed[0] != 0:
            raise ValueError("Unexpected MMDVM host framing")
        # MMDVM's leading 0x00 is a host-control byte, not an over-air byte.
        if framed[1:] != pair[i * 216:(i + 1) * 216]:
            raise ValueError("OP25/MMDVM LDU mismatch: " + name)
    if call[99:-18] != pair * PAIRS:
        raise ValueError("Voice data does not repeat expected pair")
    for frame in (hdu, pair[:216], pair[216:], tdu):
        if frame[:6] != SYNC:
            raise ValueError("Bad frame sync")

    preamble = bytes([0x77]) * 240  # MMDVM's default 200-ms startup pattern
    stream = preamble + call
    OUT.mkdir(parents=True, exist_ok=True)
    artifacts = {"call.bin": call, "voice-ldu-pair.bin": pair, "tx-stream.bin": stream}
    for name, data in artifacts.items():
        (OUT / name).write_bytes(data)
    # Firmware-sized constant vectors. Repeat the pair; no live IMBE required.
    header = ["// Derived from pinned GPL-2.0-or-later OP25/MMDVM test vectors.",
              "// See THIRD_PARTY.md and fixtures/p25-1011/manifest.json.",
              "#pragma once", "#include <stdint.h>",
              "#define P25_TEST_PAIR_REPEATS 28u", "#define P25_TEST_PREAMBLE_BYTES 240u"]
    for name, data in (("hdu", hdu), ("ldu1", pair[:216]), ("ldu2", pair[216:]), ("tdu", tdu)):
        header.append(f"static const uint8_t p25_test_{name}[{len(data)}] = {{")
        header.extend("    " + ", ".join(f"0x{x:02x}" for x in data[j:j+12]) + ","
                      for j in range(0, len(data), 12))
        header.append("};")
    (OUT / "p25_test_vectors.h").write_text("\n".join(header) + "\n", encoding="utf-8")
    manifest = {
        "purpose": "Fixed P25 Phase 1 1011-Hz encoded voice TX fixture, not flashable firmware",
        "nac_hex": "293", "source_id": 1, "talkgroup": 1, "algid_hex": "80",
        "symbol_rate": 4800, "bit_rate": 9600,
        "packing": "MSB first, four dibits per byte; status symbols already included",
        "voice_seconds": PAIRS * 0.36, "voice_frames_20ms": PAIRS * 18,
        "preamble_bytes": len(preamble), "preamble_byte_hex": "77",
        "hdu_bytes": 99, "ldu_bytes": 216, "ldu_pairs": PAIRS, "tdu_bytes": 18,
        "stream_seconds": len(stream) * 8 / 9600,
        "transport_block_bytes": 36, "full_blocks": len(stream) // 36,
        "last_block_valid_bytes": len(stream) % 36,
        "transport_note": "Concatenate before chunking. Never pad between data units. Final partial block needs an explicit driver tail policy.",
        "op25_mmdvm_ldu_byte_equality": True,
        "sources": {"op25_commit": PINS["boatbod/op25"], "mmdvm_commit": PINS["g4klx/MMDVM"],
                    "p25craft_sha256": digest(craft.read_bytes()), "calp25_sha256": digest(cal.read_bytes())},
        "files": {name: {"bytes": len(data), "sha256": digest(data)} for name, data in artifacts.items()},
        "rf_verified": False,
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
