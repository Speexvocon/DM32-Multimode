#!/usr/bin/env bash
set -euo pipefail
project_root=$(cd "$(dirname "$0")/.." && pwd)
upstream="$project_root/external/RadioFoundry/RadioFoundry"
out="$project_root/build/firmware"
export PATH="$HOME/toolchains/csky-elf/bin:$PATH"
lab_diagnostics="${DM32_LAB_DIAGNOSTICS:-0}"
case "$lab_diagnostics" in 0|1) ;; *) echo 'DM32_LAB_DIAGNOSTICS must be 0 or 1' >&2; exit 1;; esac
mkdir -p "$out"
printf '%s\n' "$lab_diagnostics" > "$out/lab-diagnostics.txt"
test "$(git -C "$upstream" rev-parse HEAD)" = 75c46ea46d5ebf6406f5b4ce0bbe2443b7649f91
test -z "$(git -C "$upstream" status --porcelain --untracked-files=no)"
# The upstream CPS response embeds __DATE__/__TIME__; use the source commit's time
# for all three builds so the disabled-overlay comparison is meaningful.
export SOURCE_DATE_EPOCH="$(git -C "$upstream" show -s --format=%ct HEAD)"
printf '%s\n' "$SOURCE_DATE_EPOCH" > "$out/source-date-epoch.txt"
csky-elf-gcc --version > "$out/compiler.txt"
git rev-parse HEAD > "$out/project-commit.txt"
git -C "$upstream" rev-parse HEAD > "$out/upstream-commit.txt"
git -C "$upstream" submodule status > "$out/submodules.txt"
make -C "$upstream" BOARD=dm32 -j"$(nproc)" > "$out/baseline.log" 2>&1
for extension in bin elf map; do
    cp "$upstream/build/dm32/rfoundry_dm32.$extension" "$out/baseline-dm32.$extension"
done
sha256sum "$out"/baseline-dm32.* > "$out/SHA256SUMS"
if test -f "$project_root/src/firmware/radiofoundry-diag.mk"; then
    make -C "$upstream" -f "$project_root/src/firmware/radiofoundry-diag.mk" \
        BOARD=dm32 BUILD=build/dm32-p25 CONFIG_P25_TEST_TX=1 PROJECT_ROOT="$project_root" \
        -j"$(nproc)" > "$out/diagnostic.log" 2>&1
    for extension in bin elf map; do
        cp "$upstream/build/dm32-p25/rfoundry_dm32.$extension" "$out/p25-test-dm32.$extension"
    done
    make -C "$upstream" -f "$project_root/src/firmware/radiofoundry-diag.mk" \
        BOARD=dm32 BUILD=build/dm32-p25-disabled CONFIG_P25_TEST_TX=0 PROJECT_ROOT="$project_root" \
        -j"$(nproc)" > "$out/diagnostic-disabled.log" 2>&1
    cp "$upstream/build/dm32-p25-disabled/rfoundry_dm32.bin" "$out/disabled-dm32.bin"
    cp "$upstream/build/dm32-p25-disabled/rfoundry_dm32.map" "$out/disabled-dm32.map"
    cmp "$out/baseline-dm32.bin" "$out/disabled-dm32.bin" > "$out/equivalence.txt"
    printf 'Feature-disabled image equals baseline byte for byte.\n' > "$out/equivalence.txt"
    sha256sum "$out"/p25-test-dm32.* >> "$out/SHA256SUMS"
    if grep -n 'warning:' "$out/baseline.log" "$out/diagnostic.log" "$out/diagnostic-disabled.log"; then
        echo 'Firmware compiler warnings detected' >&2
        exit 1
    fi
fi
if test -f "$project_root/src/firmware/radiofoundry-imbe-bench.mk"; then
    csky-elf-g++ --version > "$out/cxx-compiler.txt"
    make -C "$upstream" -f "$project_root/src/firmware/radiofoundry-imbe-bench.mk" \
        BOARD=dm32 BUILD=build/dm32-imbe-bench PROJECT_ROOT="$project_root" \
        -j"$(nproc)" > "$out/imbe-benchmark.log" 2>&1
    for extension in bin elf map; do
        cp "$upstream/build/dm32-imbe-bench/rfoundry_dm32.$extension" "$out/imbe-bench-dm32.$extension"
    done
    mkdir -p "$out/imbe-stack"
    find "$upstream/build/dm32-imbe-bench/imbe" -type f \( -name '*.su' -o -name '*.ci' \) -exec cp {} "$out/imbe-stack/" \;
    csky-elf-nm -S --size-sort "$out/imbe-bench-dm32.elf" > "$out/imbe-symbols.txt"
    sha256sum "$out"/imbe-bench-dm32.* >> "$out/SHA256SUMS"
    python3 "$project_root/scripts/analyze-imbe-build.py" "$out" \
        --output "$out/imbe-build-analysis.json" > "$out/imbe-build-analysis.log"
    if grep -n 'warning:' "$out/imbe-benchmark.log"; then
        echo 'Benchmark compiler warnings detected' >&2
        exit 1
    fi
fi
if test -f "$project_root/src/firmware/dm32_p25_live.c"; then
    mkdir -p "$out/live/imbe-stack"
    make -C "$upstream" -f "$project_root/src/firmware/radiofoundry-imbe-bench.mk" \
        BOARD=dm32 BUILD=build/dm32-p25-live BENCH_LIVE_RF=1 DM32_LAB_DIAGNOSTICS="$lab_diagnostics" PROJECT_ROOT="$project_root" \
        -j"$(nproc)" > "$out/live/imbe-benchmark.log" 2>&1
    for extension in bin elf map; do
        cp "$upstream/build/dm32-p25-live/rfoundry_dm32.$extension" "$out/live/imbe-bench-dm32.$extension"
    done
    find "$upstream/build/dm32-p25-live/imbe" "$upstream/build/dm32-p25-live/multimode" \
        -type f \( -name '*.su' -o -name '*.ci' \) -exec cp {} "$out/live/imbe-stack/" \;
    csky-elf-nm -S --size-sort "$out/live/imbe-bench-dm32.elf" > "$out/live/imbe-symbols.txt"
    analyzer_profile=()
    if test "$lab_diagnostics" = 1; then analyzer_profile+=(--lab-diagnostics); fi
    python3 "$project_root/scripts/analyze-imbe-build.py" "$out/live" --live "${analyzer_profile[@]}" \
        --output "$out/live/imbe-build-analysis.json" > "$out/live/imbe-build-analysis.log"
    sha256sum "$out"/live/imbe-bench-dm32.* >> "$out/SHA256SUMS"
    if grep -n 'warning:' "$out/live/imbe-benchmark.log"; then
        echo 'Live firmware compiler warnings detected' >&2
        exit 1
    fi
fi
test -z "$(git -C "$upstream" diff --name-only -- . ':!tools/rfoundry/rfoundry/registry.json')"
printf 'Built unmodified DM32 baseline; no stock codec merged and no hardware accessed.\n'
