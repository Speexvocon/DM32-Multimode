"""Generate a live-only DMR glue copy with drained deferred-event ownership.

The pinned slot engine and call stack remain unchanged. Stop/reinitialization
closes the deferred worker before draining it, so neither queued old events nor
an in-flight callback can cross a mode or call-stack handoff.
"""
import argparse
import hashlib
from pathlib import Path

PINNED_SOURCE_SHA256="fdaf4867bd26e17a75fb14242d006a9037363d447fa25b66e6f58b3104ee4154"


def replace_once(text,old,new):
    if text.count(old)!=1:
        raise ValueError("Pinned DMR glue structure changed: "+old[:70])
    return text.replace(old,new,1)


def generate(text):
    text=text.replace("\r\n","\n")
    if hashlib.sha256(text.encode()).hexdigest()!=PINNED_SOURCE_SHA256:
        raise ValueError("DMR glue does not match the reviewed upstream pin")
    text=replace_once(text,'#include "dmr_glue.h"','#include "dmr_glue.h"\n#include "radio_dmr_metrics.h"')
    start=text.index("static void dmr_task(void *arg)")
    end=text.index("\n// --- The radio's interface ---",start)
    text=text[:start]+'''// BEGIN GENERATED DEFERRED OWNERSHIP
static volatile bool deferred_closed = true;
static volatile bool deferred_active;
// Task-context diagnostics: copy existing state once, without touching modem
// registers or dispatching/clearing events. No instrumentation is added to IRQs.
void hrc_dmr_rx_diag(radio_dmr_rx_diag_t *out)
{
    if (out == NULL) return;
    uint32_t s = hrc_irq_save();
    out->sys_ints = eng.st.sys_ints;
    out->ts_rx_ints = eng.st.ts_rx_ints;
    out->ts_tx_ints = eng.st.ts_tx_ints;
    out->ticks = eng.st.ticks;
    out->rx_voice = eng.st.rx_voice;
    out->rx_lc_header = eng.st.rx_lc_header;
    out->rx_terminator = eng.st.rx_terminator;
    out->rx_crc_err = eng.st.rx_crc_err;
    out->rx_unusable = eng.st.rx_unusable;
    out->late_entry = eng.st.late_entry;
    out->ev_overflow = eng.st.ev_overflow;
    out->last_rx_type_info = eng.st.last_rx_type_info;
    out->last_sys_list = eng.st.last_sys_list;
    out->last_l2_status = eng.st.last_l2_status;
    out->last_cc = eng.st.last_cc;
    out->last_ts = eng.st.last_ts;
    out->active = active;
    out->callback_bound = stack_cb != NULL;
    out->deferred_closed = deferred_closed;
    out->deferred_active = deferred_active;
    hrc_irq_restore(s);
}
void hrc_dmr_tx_diag(radio_dmr_native_tx_diag_t *out)
{
    if (out == NULL) return;
    uint32_t s = hrc_irq_save();
    out->tx_bursts = eng.st.tx_bursts;
    out->tx_underruns = eng.st.tx_underrun;
    out->tx_rejected = eng.st.tx_rejected;
    out->tx_done = eng.st.tx_done;
    out->event_overflows = eng.st.ev_overflow;
    hrc_irq_restore(s);
}
// Public/non-inline so the linked-image audit can prove this host is selected.
__attribute__((noinline)) void hrc_dmr_deferred_drain(void)
{
    uint32_t s = hrc_irq_save();
    deferred_closed = true;
    hrc_irq_restore(s);
    // A callback can stop its own producer without waiting on its own stack.
    // Starting/reinitializing from that stack is refused until it unwinds.
    if (xTaskGetCurrentTaskHandle() != task)
        while (deferred_active) vTaskDelay(1);
}
static void dmr_deferred_once(void)
{
    uint32_t s = hrc_irq_save();
    if (!active || deferred_closed) { hrc_irq_restore(s); return; }
    deferred_active = true;
    hrc_irq_restore(s);
    dmr_event_t ev;
    dmr_burst_t burst;
    hrc7000_dmr_poll(&eng);
    while (active && !deferred_closed && hrc7000_dmr_pop(&eng, &ev, &burst)) {
        dmr_event_cb_t cb = stack_cb;
        void *ctx = stack_ctx;
        if (cb != NULL && active && !deferred_closed) cb(&ev, ctx);
    }
    s = hrc_irq_save();
    deferred_active = false;
    hrc_irq_restore(s);
}
static void dmr_task(void *arg)
{
    (void)arg;
    for (;;) {
        ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(DMR_POLL_MS));
        dmr_deferred_once();
    }
}
// END GENERATED DEFERRED OWNERSHIP
''' + text[end:]
    text=replace_once(text,"void hrc_dmr_board_init(hrc7000_t *modem, const hrc_dmr_board_t *hooks)\n{",'''void hrc_dmr_board_init(hrc7000_t *modem, const hrc_dmr_board_t *hooks)
{
    if (deferred_active && xTaskGetCurrentTaskHandle() == task) return;
    hrc_dmr_deferred_drain();
    if (active) hrc_dmr_leave();
    uint32_t s = hrc_irq_save();
    active = false;''')
    text=replace_once(text,"\tirqs_enable(false);\n\tif (task == NULL)","\tirqs_enable(false);\n    hrc_irq_restore(s);\n\tif (task == NULL)")
    text=replace_once(text,"void hrc_dmr_leave(void)\n{","void hrc_dmr_leave(void)\n{\n    hrc_dmr_deferred_drain();")
    text=replace_once(text,"static bool start(const dmr_config_t *cfg, dmr_event_cb_t cb, void *ctx)\n{",'''static bool start(const dmr_config_t *cfg, dmr_event_cb_t cb, void *ctx)
{
    if (task == NULL) return false; // no worker: do not claim a running modem
    if (deferred_active && xTaskGetCurrentTaskHandle() == task) return false;
    hrc_dmr_deferred_drain();''')
    text=replace_once(text,"\tstack_cb = cb;\n\treturn true;",'''\tstack_cb = cb;
    uint32_t s = hrc_irq_save();
    deferred_closed = false;
    hrc_irq_restore(s);
\treturn true;''')
    text=replace_once(text,"static void stop(void)\n{\n\tstack_cb = NULL;","static void stop(void)\n{\n    hrc_dmr_deferred_drain();\n\tstack_cb = NULL;")
    return '// Generated by scripts/generate-drained-dmr.py; do not edit.\n'+text


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("source",type=Path);p.add_argument("output",type=Path)
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    output=a.output.resolve()
    if not output.is_relative_to((root/"build").resolve()):
        p.error("generated DMR glue must remain under the ignored project build directory")
    generated=generate(a.source.read_text());output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(generated,newline="\n")


if __name__=="__main__":main()
