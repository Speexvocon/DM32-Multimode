"""Download stopped RX PCM evidence; never starts RX, keys RF, or flashes."""
import argparse
import json
from pathlib import Path
import time
import wave


def fields(line):
    return dict(part.split('=', 1) for part in line.split()[1:] if '=' in part)


def download(port, log):
    def query(command, prefix):
        port.write((command+'\n').encode('ascii'))
        deadline = time.monotonic()+5
        while time.monotonic() < deadline:
            line = port.readline().decode('ascii', errors='strict').strip()
            if not line:
                continue
            log.write(json.dumps({'time': time.time(), 'line': line})+'\n')
            log.flush()
            if line.startswith('ERR'):
                raise RuntimeError(line)
            if line.startswith(prefix):
                return line
        raise RuntimeError('Missing '+prefix)

    # Drain a complete status response before issuing any data requests.
    port.write(b'STATUS\n')
    status = {}
    deadline = time.monotonic()+5
    while time.monotonic() < deadline:
        line = port.readline().decode('ascii', errors='strict').strip()
        if line:
            log.write(json.dumps({'time': time.time(), 'line': line})+'\n')
            status[line.split()[0]] = fields(line)
            if line.startswith('LIVE_AUDIO '):
                break
    else:
        raise RuntimeError('Incomplete status')
    live, monitor, trace = (status.get(k, {}) for k in ('LIVE', 'RXMON', 'RXTRACE'))
    if live.get('active') != '0' or live.get('rf') != '0' or monitor.get('running') != '0' or monitor.get('enabled') != '0':
        raise RuntimeError('Stop RX/TX before downloading evidence')
    frames, kept, payloads = (int(trace[k]) for k in ('frames', 'kept', 'payloads'))
    if not 0 < kept <= 112 or kept != min(frames, 112) or payloads != min(frames, 512):
        raise RuntimeError('Invalid or empty trace')
    pcm, bits = bytearray(), bytearray()
    for index in range(kept):
        for section in range(5):
            words = query(f'RXPCM {index} {section}', 'RXPCM ').split()
            if len(words) != 5 or list(map(int, words[1:4])) != [index, section, frames-kept+index]:
                raise RuntimeError('PCM response index mismatch')
            data = bytes.fromhex(words[4])
            if len(data) != 64:
                raise RuntimeError('PCM response length mismatch')
            pcm.extend(data)
    for index in range(payloads):
        words = query(f'RXBITS {index}', 'RXBITS ').split()
        if len(words) != 3 or int(words[1]) != index:
            raise RuntimeError('Payload response index mismatch')
        data = bytes.fromhex(words[2])
        if len(data) != 11:
            raise RuntimeError('Payload response length mismatch')
        bits.extend(data)
    return status, bytes(pcm), bytes(bits)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    import serial
    args.output.mkdir(parents=True, exist_ok=False)
    with (args.output/'serial.jsonl').open('x') as log, serial.Serial(args.port, 115200, timeout=.25, write_timeout=1) as port:
        status, pcm, bits = download(port, log)
    (args.output/'decoded-tail.s16le').write_bytes(pcm)
    (args.output/'payloads.bin').write_bytes(bits)
    with wave.open(str(args.output/'decoded-tail.wav'), 'wb') as wav:
        wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(8000)
        wav.writeframes(pcm)
    (args.output/'status.json').write_text(json.dumps(status, indent=2)+'\n')
    print(json.dumps({'pcm_bytes': len(pcm), 'payload_bytes': len(bits), 'trace': status['RXTRACE']}))


if __name__ == '__main__':
    main()
