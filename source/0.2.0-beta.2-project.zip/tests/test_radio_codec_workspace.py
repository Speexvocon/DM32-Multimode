"""Execute the actual arena, generated AMBE host and IMBE lifetime gates on the host."""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/firmware"
UPSTREAM = ROOT / "external/RadioFoundry/RadioFoundry"
spec = importlib.util.spec_from_file_location("shared_vocoder", ROOT / "scripts/generate-shared-vocoder.py")
GEN = importlib.util.module_from_spec(spec)
spec.loader.exec_module(GEN)


class WorkspaceTest(unittest.TestCase):
    def setUp(self):
        self.cc = shutil.which("gcc") or shutil.which("cc")
        self.cxx = shutil.which("g++") or shutil.which("c++")
        if not self.cc or not self.cxx:
            self.skipTest("host C/C++ compiler unavailable")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.d = Path(self.tmp.name)
        self.common = ["-O2", "-Wall", "-Wextra", "-Werror", "-DRADIO_CODEC_HOST_TEST=1", "-I", str(SOURCE)]
        self.obj = self.d / "workspace.o"
        subprocess.run([self.cc, *self.common, "-c", str(SOURCE / "radio_codec_workspace.c"), "-o", str(self.obj)], check=True, capture_output=True)

    def run_program(self, source, cpp=False, includes=(), shared=True):
        f = self.d / ("test.cpp" if cpp else "test.c")
        f.write_text(source)
        exe = self.d / "test.exe"
        cmd = [self.cxx if cpp else self.cc, *self.common, "-I", str(self.d)]
        for path in includes:
            cmd += ["-I", str(path)]
        if cpp:
            cmd += ["-std=c++11", "-DBENCH_SHARED_CODEC=" + str(int(shared)), str(SOURCE / "imbe_bench.cpp")]
        objects = [str(self.obj)] if shared else []
        subprocess.run([*cmd, str(f), *objects, "-o", str(exe)], check=True, capture_output=True)
        subprocess.run([str(exe)], check=True, capture_output=True)

    def test_exclusive_arena_and_busy_release(self):
        self.run_program(r'''
#include "radio_codec_workspace.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>
uint32_t radio_codec_test_lock(void) { return 0; }
void radio_codec_test_unlock(uint32_t s) { (void)s; }
int main(void) {
    static unsigned char receive[74480] __attribute__((aligned(8)));
    assert(radio_codec_owner()==RADIO_CODEC_NONE);
    assert(!radio_codec_acquire(RADIO_CODEC_NONE));
    assert(!radio_codec_acquire(RADIO_CODEC_DMR));
    assert(!radio_codec_bind_dmr(NULL,sizeof receive));
    assert(!radio_codec_bind_dmr(receive+1,sizeof receive-1));
    assert(!radio_codec_bind_dmr(receive,RADIO_CODEC_WORKSPACE_BYTES-1));
    assert(!radio_codec_bind_dmr((void *)(UINTPTR_MAX&~(uintptr_t)7),74480));
    memset(receive,0xCC,sizeof receive);
    assert(radio_codec_bind_dmr(receive,sizeof receive));
    assert(!radio_codec_begin(RADIO_CODEC_DMR));
    assert(radio_codec_acquire(RADIO_CODEC_P25));
    unsigned char *p=radio_codec_storage(RADIO_CODEC_P25,RADIO_CODEC_P25_STORAGE_BYTES);
    assert(p && !((uintptr_t)p&7));memset(p,0xA5,RADIO_CODEC_P25_STORAGE_BYTES);
    assert(!radio_codec_storage(RADIO_CODEC_P25,RADIO_CODEC_P25_STORAGE_BYTES+1));
    assert(!radio_codec_bind_dmr(receive,sizeof receive));
    assert(!radio_codec_unbind_dmr());
    assert(!radio_codec_dmr_storage(RADIO_CODEC_DMR_DEC));
    assert(!radio_codec_acquire(RADIO_CODEC_DMR));
    assert(radio_codec_begin(RADIO_CODEC_P25));
    assert(!radio_codec_begin(RADIO_CODEC_P25));
    assert(!radio_codec_release(RADIO_CODEC_P25));
    radio_codec_end(RADIO_CODEC_DMR);assert(radio_codec_busy(RADIO_CODEC_P25));
    radio_codec_end(RADIO_CODEC_P25);assert(radio_codec_release(RADIO_CODEC_P25));
    assert(!radio_codec_bind_dmr(p,74480)); // must not alias the live IMBE object
    assert(radio_codec_acquire(RADIO_CODEC_DMR));
    assert(radio_codec_dmr_storage(RADIO_CODEC_DMR_DEC)==receive);
    assert(radio_codec_dmr_storage(RADIO_CODEC_DMR_ENC)==receive+6144);
    assert(radio_codec_dmr_storage(RADIO_CODEC_DMR_BITS)==receive+13312);
    assert(radio_codec_dmr_storage(RADIO_CODEC_DMR_PCM)==receive+13456);
    assert(!radio_codec_storage(RADIO_CODEC_DMR,RADIO_CODEC_WORKSPACE_BYTES+1));
    assert(!radio_codec_unbind_dmr());
    assert(!radio_codec_dmr_storage((radio_codec_dmr_slice_t)4));
    for(unsigned i=0;i<RADIO_CODEC_P25_STORAGE_BYTES;i++)assert(p[i]==0xA5);
    for(unsigned i=0;i<sizeof receive;i++)assert(receive[i]==0xCC);
    assert(radio_codec_begin(RADIO_CODEC_DMR));
    assert(!radio_codec_unbind_dmr() && !radio_codec_bind_dmr(receive,sizeof receive));
    memset(radio_codec_dmr_storage(RADIO_CODEC_DMR_DEC),0x11,6144);
    memset(radio_codec_dmr_storage(RADIO_CODEC_DMR_ENC),0x22,7168);
    memset(radio_codec_dmr_storage(RADIO_CODEC_DMR_BITS),0x33,144);
    memset(radio_codec_dmr_storage(RADIO_CODEC_DMR_PCM),0x44,320);
    radio_codec_end(RADIO_CODEC_DMR);
    for(unsigned i=0;i<RADIO_CODEC_P25_STORAGE_BYTES;i++)assert(p[i]==0xA5);
    for(unsigned i=RADIO_CODEC_WORKSPACE_BYTES;i<sizeof receive;i++)assert(receive[i]==0xCC);
    assert(!radio_codec_release(RADIO_CODEC_P25));
    assert(radio_codec_release(RADIO_CODEC_DMR));
    assert(radio_codec_unbind_dmr());assert(!radio_codec_acquire(RADIO_CODEC_DMR));
    return 0;
}
''')

    def native_host_setup(self, generated=None):
        if generated is None:
            generated = GEN.generate((UPSTREAM / "platform/hrc7000/vocoder.c").read_text())
        (self.d / "vocoder_shared.c").write_text(generated)
        (self.d / "config.h").write_text('#define CONFIG_DMR 1\n#define RFOUNDRY_BOARD_ID "dm32"\n')
        (self.d / "FreeRTOS.h").write_text("")
        (self.d / "hal_time.h").write_text("#include <stdint.h>\nuint32_t hal_micros(void);\n")
        (self.d / "task.h").write_text("void vTaskDelay(unsigned ticks);\n")
        (self.d / "platform.h").write_text('''#include <stdint.h>
uint32_t radio_codec_test_lock(void); void radio_codec_test_unlock(uint32_t);
static inline uint32_t hrc_irq_save(void) { return radio_codec_test_lock(); }
static inline void hrc_irq_restore(uint32_t s) { radio_codec_test_unlock(s); }
static inline void hrc_barrier(void) { __asm__ volatile("" ::: "memory"); }
''')

    def test_generated_native_host_quiesces_before_release(self):
        self.native_host_setup()
        self.run_program(r'''
#include <assert.h>
#include "vocoder_shared.c"
const uint8_t __codec_run_lo[4]={0},__codec_run_hi[4]={0},__codec_tab_lo[4]={0},__codec_tab_hi[4]={0};
const uint8_t __codec_slot[128]={0},__codec_slot_end[4]={0};
static unsigned waits;
uint32_t hal_micros(void) { return 0; }
uint32_t radio_codec_test_lock(void) { return 0; }
void radio_codec_test_unlock(uint32_t s) { (void)s; }
void vTaskDelay(unsigned n) {
    assert(n==1 && quiescing);waits++;
    uint8_t bits[49]={0};int16_t out[160];memset(out,0xA5,sizeof out);
    decode(bits,out);for(unsigned i=0;i<160;i++)assert(out[i]==0);
    busy=false;radio_codec_end(RADIO_CODEC_DMR);
}
int main(void) {
    static uint8_t receive[74480] __attribute__((aligned(8)));
    assert(radio_codec_bind_dmr(receive,sizeof receive));
    presence=1;
    assert(radio_codec_acquire(RADIO_CODEC_P25));
    uint8_t *p=radio_codec_storage(RADIO_CODEC_P25,5736);memset(p,0xA5,5736);
    uint8_t bits[49];int16_t pcm[160]={0};memset(bits,0xA5,sizeof bits);
    encode(pcm,bits);for(unsigned i=0;i<49;i++)assert(bits[i]==0);
    reset();assert(!hrc_vocoder_resume());
    for(unsigned i=0;i<5736;i++)assert(p[i]==0xA5);
    assert(radio_codec_release(RADIO_CODEC_P25));
    assert(hrc_vocoder_resume());assert(radio_codec_owner()==RADIO_CODEC_DMR);
    assert(!ready && !quiescing);
    assert(radio_codec_begin(RADIO_CODEC_DMR));busy=true;
    assert(hrc_vocoder_quiesce());assert(waits==1 && radio_codec_owner()==RADIO_CODEC_NONE);
    // Stale native callbacks remain blocked after another mode owns the arena.
    assert(radio_codec_acquire(RADIO_CODEC_P25));memset(p,0x5A,5736);reset();
    for(unsigned i=0;i<5736;i++)assert(p[i]==0x5A);
    assert(radio_codec_release(RADIO_CODEC_P25));assert(hrc_vocoder_resume());
    hrc_vocoder_park();assert(parked && radio_codec_owner()==RADIO_CODEC_NONE);
    assert(!hrc_vocoder_resume());return 0;
}
''', includes=(UPSTREAM / "platform/hrc7000", UPSTREAM / "hal", UPSTREAM / "drivers"))

    def test_native_metrics_measure_wall_time_rejection_and_owner_scope(self):
        generated = GEN.generate((UPSTREAM / "platform/hrc7000/vocoder.c").read_text())
        # Keep the generated ownership/measurement wrappers real. Substitute only
        # the proprietary entry execution, which a host CPU cannot run.
        for name, body in (("reset_run", "ready=true; fake_now+=1000u;"),
                           ("encode_run", "(void)pcm; memset(bits,1,VOCODER_BITS); fake_now+=17500u;"),
                           ("decode_run", "(void)bits; for(unsigned i=0;i<VOCODER_FRAME_SAMPLES;i++) pcm[i]=123; fake_now+=13000u;")):
            start = generated.index("static void " + name + "(")
            opening = generated.index("{", start)
            end = opening + 1
            depth = 1
            while depth:
                if generated[end] == "{": depth += 1
                elif generated[end] == "}": depth -= 1
                end += 1
            generated = generated[:opening] + "{ " + body + " }" + generated[end:]
        self.native_host_setup(generated)
        self.run_program(r'''
#include <assert.h>
#include <stdint.h>
static uint32_t fake_now;
#include "vocoder_shared.c"
const uint8_t __codec_run_lo[4]={0},__codec_run_hi[4]={0},__codec_tab_lo[4]={0},__codec_tab_hi[4]={0};
const uint8_t __codec_slot[128]={0},__codec_slot_end[4]={0};
uint32_t radio_codec_test_lock(void) {return 0;}
void radio_codec_test_unlock(uint32_t s) {(void)s;}
void vTaskDelay(unsigned n) {(void)n;assert(0);}
uint32_t hal_micros(void) {return fake_now;}
int main(void) {
    (void)entry;(void)h16;
    static uint8_t receive[74480] __attribute__((aligned(8)));
    assert(radio_codec_bind_dmr(receive,sizeof receive));presence=1;
    assert(hrc_vocoder_resume());
    uint8_t bits[49];int16_t pcm[160]={0};radio_dmr_vocoder_diag_t d;
    fake_now=UINT32_MAX-10000u;encode(pcm,bits);
    for(unsigned i=0;i<49;i++)assert(bits[i]==1);
    reset();decode(bits,pcm);for(unsigned i=0;i<160;i++)assert(pcm[i]==123);
    encode(pcm,bits);hrc_vocoder_diag(&d);
    assert(d.encode.calls==2 && d.encode.total_us==35000 && d.encode.max_us==17500);
    assert(d.reset.calls==1 && d.reset.total_us==1000);
    assert(d.decode.calls==1 && d.decode.total_us==13000);
    assert(d.encode.saturated==0 && d.encode_rejected==0);
    assert(hrc_vocoder_quiesce());encode(pcm,bits);reset();decode(bits,pcm);
    for(unsigned i=0;i<49;i++)assert(bits[i]==0);
    for(unsigned i=0;i<160;i++)assert(pcm[i]==0);
    hrc_vocoder_diag(&d);hrc_vocoder_diag(NULL);
    assert(d.encode.calls==2 && d.encode_rejected==1 && d.reset_rejected==1 && d.decode_rejected==1);
    assert(hrc_vocoder_resume());hrc_vocoder_diag(&d);
    assert(d.encode.calls==0 && d.encode_rejected==0 && d.reset.calls==0 && d.decode.calls==0);
    radio_dmr_cost_t cost={UINT32_MAX,UINT32_MAX-1u,0,0};
    radio_dmr_cost_record(&cost,5u);
    assert(cost.calls==UINT32_MAX && cost.total_us==UINT32_MAX && cost.max_us==5 && cost.saturated==3);
    return 0;
}
''', includes=(UPSTREAM / "platform/hrc7000", UPSTREAM / "hal", UPSTREAM / "drivers"))

    def test_imbe_construct_destroy_and_busy_failures(self):
        (self.d / "imbe_vocoder_impl.h").write_text(r'''
#include <stdint.h>
#include <cstring>
extern unsigned constructs,destructs;
class imbe_vocoder_impl {
  unsigned marker;
public:
  imbe_vocoder_impl():marker(0x12345678) {constructs++;}
  ~imbe_vocoder_impl() {destructs++;}
  void encode_4400(int16_t *,uint8_t *out) {for(unsigned i=0;i<11;i++)out[i]=marker&255;}
  void decode_4400(int16_t *out,uint8_t *) {for(unsigned i=0;i<160;i++)out[i]=marker&32767;}
};
''')
        self.run_program(r'''
#include "radio_codec_workspace.h"
#include "imbe_bench.h"
#include <assert.h>
#include <cstring>
unsigned constructs,destructs;
extern "C" uint32_t radio_codec_test_lock(void) { return 0; }
extern "C" void radio_codec_test_unlock(uint32_t s) { (void)s; }
int main(void) {
    static uint8_t receive[74480] __attribute__((aligned(8)));
    assert(radio_codec_bind_dmr(receive,sizeof receive));
    int16_t pcm[160]={0};uint8_t bits[11];memset(bits,0xA5,sizeof bits);
    imbe_bench_encode_pcm(pcm,bits);for(unsigned i=0;i<11;i++)assert(bits[i]==0);
    assert(imbe_bench_init() && imbe_bench_ready() && constructs==1);
    imbe_bench_encode_pcm(pcm,bits);assert(bits[0]==0x78);
    assert(!radio_codec_acquire(RADIO_CODEC_DMR));
    assert(radio_codec_begin(RADIO_CODEC_P25));
    assert(!imbe_bench_release() && destructs==0 && !imbe_bench_ready());
    assert(radio_codec_owner()==RADIO_CODEC_P25);
    radio_codec_end(RADIO_CODEC_P25);
    assert(imbe_bench_init() && constructs==2 && destructs==1);
    assert(imbe_bench_release() && destructs==2 && !imbe_bench_ready());
    assert(imbe_bench_release() && destructs==2);
    assert(radio_codec_acquire(RADIO_CODEC_DMR));
    assert(!imbe_bench_init());
    memset(pcm,0xA5,sizeof pcm);imbe_bench_decode_pcm(bits,pcm);
    for(unsigned i=0;i<160;i++)assert(pcm[i]==0);
    assert(constructs==2 && destructs==2);
    assert(radio_codec_release(RADIO_CODEC_DMR));
    assert(imbe_bench_init() && constructs==3);
    assert(imbe_bench_release() && destructs==3);return 0;
}
''', cpp=True)

    def test_standalone_imbe_keeps_private_storage_without_arena_linkage(self):
        (self.d / "imbe_vocoder_impl.h").write_text(r'''
#include <stdint.h>
#include <cstring>
class imbe_vocoder_impl {
    unsigned state[40];
public:
    imbe_vocoder_impl() {state[0]=123;}
    void encode_4400(int16_t *,uint8_t *p) {for(unsigned i=0;i<11;i++)p[i]=state[0];}
    void decode_4400(int16_t *p,uint8_t *) {for(unsigned i=0;i<160;i++)p[i]=state[0];}
};
''')
        self.run_program(r'''
#include "imbe_bench.h"
#include <assert.h>
int main(void) {
    assert(imbe_bench_state_bytes()==160);
    assert(imbe_bench_init() && imbe_bench_ready());
    uint8_t bits[11];int16_t pcm[160];imbe_bench_encode(bits);assert(bits[0]==123);
    imbe_bench_decode_pcm(bits,pcm);assert(pcm[0]==123);
    assert(imbe_bench_release() && !imbe_bench_ready());
    assert(imbe_bench_init());return 0;
}
''', cpp=True, shared=False)


class GeneratorTest(unittest.TestCase):
    def test_refuses_changed_upstream(self):
        original = (UPSTREAM / "platform/hrc7000/vocoder.c").read_text()
        with self.assertRaises(ValueError):
            GEN.generate(original.replace("HALF", "CHANGED", 1))


if __name__ == "__main__":
    unittest.main()
