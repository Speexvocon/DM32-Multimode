"""Receive-only alternate configuration and restoration fault regression tests."""
import configparser
from contextlib import redirect_stdout, redirect_stderr
import importlib.util
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("trace_session", ROOT / "scripts/hotspot-p25-trace-session.py")
trace = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(trace)
HELPER_SPEC = importlib.util.spec_from_file_location("trace_operator", ROOT / "scripts/run-hotspot-p25-trace.py")
operator = importlib.util.module_from_spec(HELPER_SPEC)
HELPER_SPEC.loader.exec_module(operator)

START = "M: 2026-11-03 03:41:28.655 P25, received RF voice transmission from N0CALL to TG 10\n"
END = "M: 2026-11-03 03:41:33.695 P25, received RF end of voice transmission from N0CALL to TG 10, 5.0 seconds, BER: 3.8%\n"
LOST = "M: 2026-11-03 03:41:33.695 P25, RF transmission lost, 0.5 seconds, BER: 1.4%\n"
LOST_IDENTITY = "M: 2026-11-03 04:54:04.961 P25, transmission lost from N0CALL to TG 10, 5.4 seconds, BER: 3.5%\n"


class FakeClock:
    def __init__(self, hook=None):
        self.now = 0.0
        self.hook = hook
    def monotonic(self): return self.now
    def sleep(self, seconds):
        self.now += seconds
        if self.hook: self.hook(self.now)

CONFIG = """[General]
Callsign=N0CALL
Id=1234567
Daemon=1
[Modem]
RXOffset=-123
TXOffset=250
RXLevel=50
P25TXLevel=52
RXInvert=1
[Info]
RXFrequency=145700000
TXFrequency=145700000
[P25]
Enable=0
NAC=293
[DMR]
Enable=1
[System Fusion]
Enable=1
[P25 Network]
Enable=1
Password=secret-value
[DMR Network]
Enable=1
[CW Id]
Enable=1
[Remote Control]
Enable=1
[Future Mode]
Enable=1
[DMR Network 1]
Enable=1
"""


class FakeSystem:
    def __init__(self, fail=None, manual=False):
        self.original = {unit: unit.endswith(".service") for unit in trace.UNITS}
        self.state = self.original.copy()
        self.actions = []
        self.fail = fail
        self.manual = manual

    def active(self, unit): return self.state[unit]
    def manual_hosts(self): return [999] if self.manual else []
    def service(self, action, unit):
        self.actions.append((action, unit))
        if self.fail == "stop" and action == "stop" and unit == trace.UNITS[2]:
            raise RuntimeError("stop failed")
        self.state[unit] = action == "start"
    def run_host(self, *args, **kwargs):
        self.actions.append(("host", None))
        if self.fail == "host": raise OSError("start failed")
        return {"exit_status": -15, "duration_limit_reached": True}


class TraceTests(unittest.TestCase):
    def test_transform_is_receive_only_and_preserves_rf_settings(self):
        text, profile = trace.transform_config(CONFIG, Path("/tmp/private-trace"))
        parsed = configparser.ConfigParser(interpolation=None)
        parsed.read_string(text)
        self.assertEqual(parsed["P25"]["Enable"], "1")
        for section in ("DMR", "System Fusion", "P25 Network", "DMR Network", "CW Id", "Remote Control", "Future Mode", "DMR Network 1"):
            self.assertEqual(parsed[section]["Enable"], "0")
        self.assertEqual(parsed["Modem"]["RXOffset"], "-123")
        self.assertEqual(parsed["Modem"]["P25TXLevel"], "52")
        self.assertEqual(parsed["Info"]["TXFrequency"], "145700000")
        self.assertEqual(parsed["Modem"]["Trace"], "1")
        self.assertEqual(parsed["General"]["Daemon"], "0")
        self.assertNotIn("secret-value", str(profile))
        self.assertIn("secret-value", text)  # Private alternate keeps required originals.

    def test_reject_ambiguous_keys(self):
        with self.assertRaises(ValueError):
            trace.transform_config(CONFIG.replace("Enable=0", "Enable=0\nenable=1", 1), Path("/tmp/private"))

    def run_fake(self, system, stop_after_call=False):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "original"
            source.write_text(CONFIG)
            report = {"original_config_sha256": trace.digest(source)}
            error = None
            try:
                trace.execute_capture(system, Path("/host"), Path("/alternate"), source,
                                      Path(directory), 5, report, stop_after_call=stop_after_call)
            except (OSError, RuntimeError) as caught:
                error = caught
            self.assertEqual(system.state, system.original)
            self.assertTrue(report["services_restored"])
            self.assertTrue(report["original_config_unchanged"])
            self.assertFalse(report["cleanup_errors"])
            return report, error

    def test_normal_restores_only_originally_active(self):
        system = FakeSystem()
        report, error = self.run_fake(system)
        self.assertIsNone(error)
        self.assertTrue(report["host"]["duration_limit_reached"])
        starts = {unit for action, unit in system.actions if action == "start"}
        self.assertEqual(starts, {unit for unit, active in system.original.items() if active})

    def test_host_start_failure_restores(self):
        report, error = self.run_fake(FakeSystem(fail="host"))
        self.assertIsInstance(error, OSError)
        self.assertIsNone(report["host"]["exit_status"])

    def test_partial_service_stop_failure_restores(self):
        report, error = self.run_fake(FakeSystem(fail="stop"))
        self.assertIsInstance(error, RuntimeError)

    def test_unmanaged_host_is_refused_after_stopping_and_restores(self):
        system = FakeSystem(manual=True)
        report, error = self.run_fake(system)
        self.assertIsInstance(error, RuntimeError)
        self.assertNotIn(("host", None), system.actions)

    def test_early_host_exit_is_failed_and_services_restored(self):
        system = FakeSystem()
        system.run_host = lambda *args: {"exit_status": 1, "duration_limit_reached": False}
        report, error = self.run_fake(system)
        self.assertIsInstance(error, RuntimeError)
        self.assertEqual(report["host"]["exit_status"], 1)

    def test_storage_failure_keeps_call_and_cleanup_evidence_in_failed_stdout(self):
        # Run main/execute_capture together, replacing only OS controls and the
        # selected failing filesystem operation. No services or RF are touched.
        for failure in ("config_digest", "report_stat", "report_write", "config_and_report"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory:
                source = Path(directory) / "original.ini"
                source.write_text(CONFIG)
                binary = Path(directory) / "MMDVMHost"
                binary.write_bytes(b"offline executable")
                output = Path(directory) / "capture"
                system = FakeSystem()
                system.run_host = mock.Mock(return_value={
                    "exit_status": -15, "duration_limit_reached": False,
                    "host_ready": True, "stop_reason": "rf_call_end",
                    "rf_call_started": True, "rf_call_termination": "end",
                    "stop_after_call_satisfied": True, "flush_linger_completed": True})
                real_open, real_digest = open, trace.digest
                real_is_dir, real_write_text = Path.is_dir, Path.write_text

                def isolated_open(path, *args, **kwargs):
                    if str(path) == "/run/lock/dm32-p25-session.lock":
                        return real_open(Path(directory) / "session.lock", *args, **kwargs)
                    return real_open(path, *args, **kwargs)

                def broken_digest(path):
                    if Path(path) == source and failure in ("config_digest", "config_and_report"):
                        raise OSError(5, "secret-value /private/config")
                    return real_digest(path)

                def broken_stat(path):
                    if path == output and failure in ("report_stat", "config_and_report"):
                        raise OSError(5, "secret-value /private/output")
                    return real_is_dir(path)

                def broken_write(path, *args, **kwargs):
                    if path == output / "report.json" and failure == "report_write":
                        raise OSError(5, "secret-value /private/report")
                    return real_write_text(path, *args, **kwargs)

                fake_fcntl = SimpleNamespace(flock=mock.Mock(), LOCK_EX=1, LOCK_NB=2)
                fake_os = SimpleNamespace(name="posix", geteuid=lambda: 0, umask=mock.Mock())
                stdout = io.StringIO()
                with mock.patch.object(trace, "os", fake_os), \
                        mock.patch.object(trace, "checked_file", side_effect=lambda value, executable=False: Path(value)), \
                        mock.patch.object(trace, "System", return_value=system), \
                        mock.patch.object(trace, "digest", side_effect=broken_digest), \
                        mock.patch.object(trace.signal, "signal"), \
                        mock.patch.object(trace.signal, "SIGHUP", 1, create=True), \
                        mock.patch.dict("sys.modules", {"fcntl": fake_fcntl}), \
                        mock.patch("builtins.open", side_effect=isolated_open), \
                        mock.patch.object(Path, "is_dir", broken_stat), \
                        mock.patch.object(Path, "write_text", broken_write), redirect_stdout(stdout):
                    result = trace.main(["--config", str(source), "--binary", str(binary),
                                         "--output", str(output), "--capture", "600", "--stop-after-call"])
                self.assertEqual(result, 1)
                summary = json.loads(stdout.getvalue())
                self.assertEqual(summary["result"], "failed")
                self.assertIn("services_restored", summary, summary)
                self.assertTrue(summary["services_restored"])
                self.assertEqual(system.state, system.original)
                self.assertTrue(summary["host"]["rf_call_started"])
                self.assertEqual(summary["host"]["rf_call_termination"], "end")
                self.assertTrue(summary["host"]["stop_after_call_satisfied"])
                self.assertNotIn("secret-value", stdout.getvalue())
                self.assertNotIn("/private", stdout.getvalue())
                self.assertLess(len(stdout.getvalue()), 2000)
                if failure in ("config_digest", "config_and_report"):
                    self.assertIsNone(summary["original_config_unchanged"])
                    self.assertEqual(summary["config_verification_error"], {"error_type": "OSError", "error_errno": 5})
                else:
                    self.assertTrue(summary["original_config_unchanged"])
                if failure in ("report_stat", "report_write", "config_and_report"):
                    self.assertFalse(summary["report_written"])
                    self.assertEqual(summary["report_write_error"], {"error_type": "OSError", "error_errno": 5})
                else:
                    self.assertTrue(summary["report_written"])
                    saved = json.loads((output / "report.json").read_text())
                    self.assertEqual(saved["result"], "failed")
                    self.assertTrue(saved["services_restored"])

    def test_run_host_timeout_escalates_to_kill(self):
        child = mock.Mock(pid=12345, returncode=-9)
        child.poll.return_value = None
        child.wait.side_effect = [trace.subprocess.TimeoutExpired("host", 5),
                                  trace.subprocess.TimeoutExpired("host", 3), -9]
        with tempfile.TemporaryDirectory() as directory:
            def started(*args, **kwargs):
                kwargs["stdout"].write(b"M: MMDVMHost-TEST is running\n")
                kwargs["stdout"].flush()
                return child
            with mock.patch.object(trace.subprocess, "Popen", side_effect=started), \
                    mock.patch.object(trace.signal, "SIGKILL", 9, create=True), \
                    mock.patch.object(trace.os, "killpg", create=True) as kill:
                result = trace.System().run_host(Path("/host"), Path("/config"), 5, Path(directory))
        self.assertTrue(result["duration_limit_reached"])
        self.assertEqual(result["exit_status"], -9)
        self.assertEqual(kill.call_args_list, [mock.call(12345, trace.signal.SIGTERM),
                                               mock.call(12345, 9)])

    def test_exit_before_ready_still_terminates_child(self):
        child = mock.Mock(pid=12345, returncode=1)
        child.poll.return_value = 1
        child.wait.return_value = 1
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(trace.subprocess, "Popen", return_value=child), \
                    mock.patch.object(trace.os, "killpg", create=True) as kill:
                with self.assertRaisesRegex(RuntimeError, "initialization"):
                    trace.System().run_host(Path("/host"), Path("/config"), 5, Path(directory))
        kill.assert_called_once_with(12345, trace.signal.SIGTERM)

    def test_opt_in_bounds_and_helper_forwarding(self):
        for parser in (trace.options, operator.options):
            field = "--capture" if parser is trace.options else "--seconds"
            prefix = ["--output", "/tmp/new"] if parser is trace.options else []
            self.assertFalse(parser(prefix + [field, "180"]).stop_after_call)
            self.assertTrue(parser(prefix + [field, "600", "--stop-after-call"]).stop_after_call)
            for args in ([field, "181"], [field, "601", "--stop-after-call"], [field, "4", "--stop-after-call"]):
                with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                    parser(prefix + args)
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            trace.options(["--output", "/tmp/new", "--stop-after-call"])
        args = operator.options(["--seconds", "600", "--stop-after-call"])
        self.assertTrue(operator.remote_command("/tmp/script.py", "/tmp/output", args).endswith("--capture 600 --stop-after-call"))
        self.assertNotIn("stop-after-call", operator.remote_command("/tmp/script.py", "/tmp/output", operator.options([])))

    def test_strict_matcher_requires_start_matching_identity_and_rf_terminal(self):
        false_lines = [END, LOST, END.replace("P25,", "DMR,"), END.replace("RF", "network"),
                       "M: 2026-11-03 03:41:33.695 Mode set to Idle\n", "RX P25 LDU\n",
                       START.replace("M:", "D:"), "P25, received RF voice transmission from N0CALL to TG 10\n"]
        matcher = trace.RFCallCompletion()
        for line in false_lines:
            self.assertIsNone(matcher.feed(line))
        self.assertIsNone(matcher.identity)
        self.assertEqual(matcher.feed(START), "start")
        self.assertIsNone(matcher.feed(END.replace("TG 10", "TG 11")))
        self.assertIsNone(matcher.feed(END.replace("RF", "network")))
        self.assertEqual(matcher.feed(END), "end")
        self.assertIsNone(matcher.feed(LOST))
        matcher = trace.RFCallCompletion()
        matcher.feed(START)
        matcher.feed(START.replace("TG 10", "TG 11"))
        self.assertTrue(matcher.ambiguous_start)
        self.assertIsNone(matcher.feed(LOST))

    def watch(self, scheduled, seconds=5, exit_at=None, overshoot_at=None):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "stdout.log"
            path.write_bytes(b"")
            pending = list(scheduled)
            def hook(now):
                while pending and pending[0][0] <= now:
                    _, text = pending.pop(0)
                    with path.open("ab") as output: output.write(text.encode())
                if overshoot_at is not None and now >= overshoot_at:
                    clock.now = seconds + 1
            clock = FakeClock(hook)
            child = mock.Mock()
            child.poll.side_effect = lambda: 1 if exit_at is not None and clock.now >= exit_at else None
            with mock.patch.object(trace.time, "monotonic", clock.monotonic), \
                    mock.patch.object(trace.time, "sleep", clock.sleep), redirect_stdout(io.StringIO()):
                result = trace.capture_until_call(child, path, seconds)
            return result, clock.now

    def test_call_end_and_lost_auto_stop_after_flush_linger(self):
        for terminal, kind in ((END, "end"), (LOST, "lost"), (LOST_IDENTITY, "lost")):
            with self.subTest(kind=kind):
                result, elapsed = self.watch([(0.1, START), (0.2, terminal)])
                self.assertTrue(result["stop_after_call_satisfied"])
                self.assertFalse(result["duration_limit_reached"])
                self.assertEqual(result["rf_call_termination"], kind)
                self.assertGreaterEqual(elapsed, .2 + trace.CALL_FLUSH_SECONDS)
                self.assertLess(elapsed, 5)

    def test_observed_identity_loss_requires_matching_unambiguous_rf_call(self):
        matcher = trace.RFCallCompletion()
        self.assertIsNone(matcher.feed(LOST_IDENTITY))
        self.assertEqual(matcher.feed(START), "start")
        for line in (LOST_IDENTITY.replace("TG 10", "TG 11"),
                     LOST_IDENTITY.replace("N0CALL", "OTHER"),
                     LOST_IDENTITY.replace("P25,", "DMR,"),
                     LOST_IDENTITY.replace("transmission lost", "network transmission lost"),
                     LOST_IDENTITY.replace("M:", "D:")):
            self.assertIsNone(matcher.feed(line))
        self.assertEqual(matcher.feed(LOST_IDENTITY), "lost")
        self.assertIsNone(matcher.feed(END))
        matcher = trace.RFCallCompletion()
        matcher.feed(START)
        matcher.feed(START.replace("TG 10", "TG 11"))
        self.assertIsNone(matcher.feed(LOST_IDENTITY))

    def test_missing_call_or_terminal_and_false_positives_use_hard_timeout(self):
        cases = ([], [(0.1, START)], [(0.1, END)], [(0.1, START), (0.2, END.replace("RF", "network"))],
                 [(0.1, START), (0.2, START), (0.3, END)])
        for scheduled in cases:
            with self.subTest(scheduled=scheduled):
                result, elapsed = self.watch(scheduled)
                self.assertTrue(result["duration_limit_reached"])
                self.assertFalse(result["stop_after_call_satisfied"])
                self.assertAlmostEqual(elapsed, 5)

    def test_complete_lines_only_and_late_terminal_does_not_extend_deadline(self):
        result, elapsed = self.watch([(0.1, START), (0.2, END.rstrip("\n")), (0.6, "\n")])
        self.assertGreaterEqual(elapsed + 1e-9, .6 + trace.CALL_FLUSH_SECONDS)
        self.assertTrue(result["stop_after_call_satisfied"])
        result, elapsed = self.watch([(0.1, START), (4.5, END)])
        self.assertAlmostEqual(elapsed, 5)
        self.assertTrue(result["duration_limit_reached"])
        self.assertFalse(result["flush_linger_completed"])
        self.assertEqual(result["rf_call_termination"], "end")

    def test_scheduling_overshoot_cannot_claim_linger_success_after_deadline(self):
        result, elapsed = self.watch([(0.1, START), (0.2, END)], overshoot_at=1)
        self.assertGreater(elapsed, 5)
        self.assertTrue(result["duration_limit_reached"])
        self.assertFalse(result["stop_after_call_satisfied"])
        self.assertFalse(result["flush_linger_completed"])

    def test_unexpected_host_exit_is_not_call_completion(self):
        result, _ = self.watch([(0.1, START)], exit_at=.3)
        self.assertEqual(result["stop_reason"], "host_exited")
        self.assertFalse(result["duration_limit_reached"])
        self.assertFalse(result["stop_after_call_satisfied"])

    def test_opt_in_restores_on_end_lost_timeout_and_early_exit(self):
        for terminal in ("end", "lost", None, "early_exit"):
            system = FakeSystem()
            result = {"exit_status": -15, "duration_limit_reached": terminal is None,
                      "stop_after_call_satisfied": terminal in ("end", "lost"),
                      "rf_call_termination": terminal if terminal in ("end", "lost") else None}
            system.run_host = mock.Mock(return_value=result)
            report, error = self.run_fake(system, stop_after_call=True)
            self.assertEqual(error is not None, terminal == "early_exit")
            self.assertTrue(report["services_restored"])
            self.assertTrue(report["original_config_unchanged"])
            self.assertTrue(system.run_host.call_args.kwargs["stop_after_call"])

    def test_opt_in_window_begins_after_readiness_and_cleanup_is_bounded(self):
        child = mock.Mock(pid=12345, returncode=-15)
        child.poll.return_value = None
        child.wait.return_value = -15
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "host-stdout.log"
            ready = False
            def started(*args, **kwargs):
                kwargs["stdout"].write(b"Initializing\n")
                kwargs["stdout"].flush()
                return child
            def hook(now):
                nonlocal ready
                if now >= .5 and not ready:
                    with path.open("ab") as output: output.write(b"M: MMDVMHost-TEST is running\n")
                    ready = True
            clock = FakeClock(hook)
            with mock.patch.object(trace.subprocess, "Popen", side_effect=started), \
                    mock.patch.object(trace.time, "monotonic", clock.monotonic), \
                    mock.patch.object(trace.time, "sleep", clock.sleep), \
                    mock.patch.object(trace.os, "killpg", create=True) as kill, redirect_stdout(io.StringIO()):
                result = trace.System().run_host(Path("/host"), Path("/config"), 5, Path(directory), stop_after_call=True)
            self.assertTrue(result["host_ready"])
            self.assertTrue(result["duration_limit_reached"])
            self.assertAlmostEqual(clock.now, 5.5)
            kill.assert_called_once_with(12345, trace.signal.SIGTERM)
            child.wait.assert_called_once_with(timeout=3)


if __name__ == "__main__":
    unittest.main()
