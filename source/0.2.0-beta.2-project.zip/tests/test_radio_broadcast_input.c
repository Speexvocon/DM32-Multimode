// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_broadcast_input.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

typedef struct {const char *text;uint32_t khz;} valid_input;
int main(void) {
    static const valid_input valid[]={
        {"65",65000},{"650",65000},{"6500",65000},{"65000",65000},
        {"650000",65000},{"6500000",65000},{"65.",65000},{"65.0",65000},
        {"65.05",65050},{"65.050",65050},{"6505",65050},
        {"87",87000},{"875",87500},{"87.5",87500},{"0875000",87500},
        {"1017",101700},{"10175",101750},{"1017000",101700},
        {"101.7",101700},{"101.75",101750},{"101.750",101750},
        {"108",108000},{"108.",108000},{"108.000",108000},{"1080000",108000},
        {"0000065",65000}
    };
    static const char *invalid[]={"","0","0000000","1","7","9","10","01","0000001","2","64","64.95","108.05","108.050",
        "101.725","101725","1017250","65001","9999999","999999.",
        "1017001","101.7000","10170000",".875",".","87..5","87.5.",
        "87 5"," 87","87 ","+87","-87","87,5","87#5","87e0","87\n","87\t"};
    uint32_t result;
    for(unsigned i=0;i<sizeof valid/sizeof *valid;++i) {
        result=0xdeadbeefu;
        assert(radio_broadcast_input_khz(valid[i].text,(unsigned)strlen(valid[i].text),&result));
        assert(result==valid[i].khz);
    }
    for(unsigned i=0;i<sizeof invalid/sizeof *invalid;++i) {
        result=0xdeadbeefu;
        assert(!radio_broadcast_input_khz(invalid[i],(unsigned)strlen(invalid[i]),&result));
        assert(result==0xdeadbeefu);
    }
    result=0xdeadbeefu;
    assert(!radio_broadcast_input_khz(NULL,2,&result) && result==0xdeadbeefu);
    assert(!radio_broadcast_input_khz("87",2,NULL));
    assert(!radio_broadcast_input_khz("87",0,&result) && result==0xdeadbeefu);
    assert(!radio_broadcast_input_khz("12345678",8,&result) && result==0xdeadbeefu);
    const char bounded[]={'1','0','1','.','7','5'};
    assert(radio_broadcast_input_khz(bounded,sizeof bounded,&result) && result==101750);
    assert(radio_broadcast_input_khz("87.5ignored",4,&result) && result==87500);
    const char embedded_zero[]={'8','7',0,'5'};
    result=0xdeadbeefu;
    assert(!radio_broadcast_input_khz(embedded_zero,sizeof embedded_zero,&result) && result==0xdeadbeefu);
    // Every supported 50-kHz channel round-trips through decimal, compact and
    // legacy seven-digit input, including values on either side of 100 MHz.
    for(uint32_t khz=RADIO_BCAST_MIN_KHZ;khz<=RADIO_BCAST_MAX_KHZ;khz+=RADIO_BCAST_STEP_KHZ) {
        char text[12];
        snprintf(text,sizeof text,"%lu.%03lu",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));
        assert(radio_broadcast_input_khz(text,(unsigned)strlen(text),&result) && result==khz);
        snprintf(text,sizeof text,"%lu",(unsigned long)(khz/10u));
        assert(radio_broadcast_input_khz(text,(unsigned)strlen(text),&result) && result==khz);
        snprintf(text,sizeof text,"%07lu",(unsigned long)(khz*10u));
        assert(radio_broadcast_input_khz(text,(unsigned)strlen(text),&result) && result==khz);
    }
    puts("Broadcast keypad parser: decimal, shorthand, legacy input and all 861 channels passed");
    return 0;
}
