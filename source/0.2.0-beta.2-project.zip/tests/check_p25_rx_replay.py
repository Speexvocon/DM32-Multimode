"""Independent pinned OP25 extraction vs bounded RX core, then identical codec PCM."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
build=root/'build/p25-rx'
raw=(root/'fixtures/p25-1011/tx-stream.bin').read_bytes()
dibits=bytes((b>>j)&3 for b in raw for j in (6,4,2,0))
(build/'tone-dibits.bin').write_bytes(dibits)
r=subprocess.run([str(build/'replay.exe'),str(build/'tone-dibits.bin'),str(build/'tone-test.s16le')],capture_output=True,text=True,check=True)
assert 'frames=58 ' in r.stdout and 'voice_frames=504 ' in r.stdout and 'corrected_voice_bits=0' in r.stdout
reference=root/'build/host-voice/p25_voice.exe'
subprocess.run([str(reference),'extract',str(root/'fixtures/p25-1011/tx-stream.bin'),str(build/'reference.imbe')],check=True)
subprocess.run([str(reference),'decode',str(build/'reference.imbe'),str(build/'reference.s16le')],check=True)
assert (build/'tone-test.s16le').read_bytes()==(build/'reference.s16le').read_bytes()
print('RX replay: 504 frames yield byte-exact PCM against independent OP25 extraction')

