// SPDX-License-Identifier: GPL-3.0-or-later
// Exploratory cross-check harness. Upstream pin/build/provenance: research/analysis/mmdvm-p25-fec-crosscheck.json
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include "P25Audio.h"
#include "Utils.h"
#include "p25_test_vectors.h"
#include "p25_interleave.h"
extern "C" {
#include "p25_live_frame.h"
}
unsigned int CUtils::countBits(unsigned int v) { return __builtin_popcount(v); }
static void check(const char *name,const unsigned char*data) {
 unsigned char buf[216];memcpy(buf,data,216);CP25Audio a;unsigned e=a.process(buf);unsigned changed=0;
 for(unsigned i=0;i<216;++i)changed+=__builtin_popcount(unsigned(buf[i]^data[i]));
 printf("%s corrected=%u changed=%u ber=%.6f\n",name,e,changed,e*100.0/1233.0);
}
int main() {
 check("fixture_ldu1",p25_test_ldu1);check("fixture_ldu2",p25_test_ldu2);
 unsigned char damaged[216];memcpy(damaged,p25_test_ldu1,216);unsigned bit=p25_voice_bits[0][0];damaged[bit/8]^=1u<<(7-bit%8);check("one_bit_injected",damaged);
 CP25Audio a;uint32_t rng=123;std::map<unsigned,unsigned> histogram;unsigned changed_frames=0,total_errors=0;
 for(unsigned trial=0;trial<1000;++trial) {
   uint8_t payload[9][11],ldu[216],orig[216];
   for(auto &p:payload)for(auto &b:p){rng=1664525u*rng+1013904223u;b=trial==0?0:trial==1?255:uint8_t(rng>>24);}
   p25_channel_frames ch;p25_channel_build(&ch,0x293,10,1234567);
   p25_live_ldu_template(ldu,payload,(trial&1)?ch.ldu2:ch.ldu1);memcpy(orig,ldu,216);
   unsigned e=a.process(ldu);histogram[e]++;total_errors+=e;changed_frames+=memcmp(orig,ldu,216)!=0;
   if(trial<3)printf("generated_trial%u corrected=%u ber=%.6f\n",trial,e,e*100.0/1233.0);
 }
 printf("generated_1000_ldus changed_frames=%u errors=%u ber=%.6f\n",changed_frames,total_errors,total_errors*100.0/1233000.0);
 for(auto p:histogram)printf("hist errors=%u ldus=%u\n",p.first,p.second);
}
