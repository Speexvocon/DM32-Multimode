// SPDX-License-Identifier: GPL-3.0-or-later
// Pinned OP25 coding/interleave conventions; see references/UPSTREAMS.json.
#include "p25_rx.h"
#include "p25_interleave.h"
#include <string.h>
#include "p25_rx_golay.h"
static uint32_t golay(uint32_t u) {
    static const uint32_t g[12]={040006165,020003073,010007550,04003664,02001732,01006631,
        0403315,0201547,0106706,045227,024476,014353};
    uint32_t v=0;
    for(unsigned i=0;i<12;++i) if(u&(1u<<(11-i))) v^=g[i];
    return v>>1;
}
static uint32_t hamming(uint32_t u) {
    static const uint16_t g[11]={0x400f,0x200e,0x100d,0x080c,0x040b,0x020a,0x0109,0x0087,0x0046,0x0025,0x0013};
    uint32_t v=0;
    for(unsigned i=0;i<11;++i) if(u&(1u<<(10-i))) v^=g[i];
    return v;
}
static uint32_t pn_bits(uint32_t *pn,unsigned bits) {
    uint32_t value=0;
    for(unsigned i=0;i<bits;++i) {
        *pn=(173u**pn+13849u)&0xffffu;
        value=(value<<1)|(*pn>>15);
    }
    return value;
}

static unsigned weight(uint32_t x) { unsigned n=0; while(x) {x&=x-1;++n;} return n; }
static unsigned bit(const uint8_t *p,unsigned i) {return (p[i/8]>>(7-i%8))&1;}
static uint64_t nid_encode(uint16_t u) {
 static const uint64_t g[16]={
        0x8000cd930bdd3b2a, 0x4000ab5a8e33a6be,
        0x2000983e4cc4e874, 0x10004c1f2662743a,
        0x0800eb9c98ec0136, 0x0400b85d47ab3bb0,
        0x02005c2ea3d59dd8, 0x01002e1751eaceec,
        0x0080170ba8f56776, 0x0040c616dfa78890,
        0x0020630b6fd3c448, 0x00103185b7e9e224,
        0x000818c2dbf4f112, 0x0004c1f2662743a2,
        0x0002ad6a38ce9afb, 0x00019b2617ba7657};
 uint64_t v=0; for(unsigned i=0;i<16;++i) if(u&(0x8000u>>i)) v^=g[i]; return v;
}
void p25_rx_init(p25_rx *r) {memset(r,0,sizeof *r);}
void p25_rx_gap(p25_rx *r) {r->shift=0;r->symbols=0;r->expected=0;}
bool p25_rx_push(p25_rx *r,uint8_t dibit) {
 if(dibit>3) {++r->bad_input;p25_rx_gap(r);return false;}
 r->shift=((r->shift<<2)|dibit)&UINT64_C(0xffffffffffff);
 if(!r->symbols) {
  uint64_t diff=r->shift^UINT64_C(0x5575f5ff77ff);
  if(weight((uint32_t)diff)+weight((uint32_t)(diff>>32))<=2) {
   memset(r->frame,0,sizeof r->frame);
   static const uint8_t sync[6]={0x55,0x75,0xf5,0xff,0x77,0xff};
   memcpy(r->frame,sync,6);r->symbols=24;++r->syncs;
  }
  return false;
 }
 unsigned pos=r->symbols++;
 r->frame[pos/4]|=(uint8_t)(dibit<<(6-2*(pos%4)));
 if(r->symbols==57) {
  uint64_t nid=0;
  for(unsigned i=24;i<57;++i) if(i!=35) nid=(nid<<2)|((r->frame[i/4]>>(6-2*(i%4)))&3);
  uint16_t u=(uint16_t)(nid>>48);r->nac=u>>4;r->duid=u&15;
  if(nid!=nid_encode(u)) {++r->bad_nid;r->symbols=0;return false;}
  switch(r->duid) {
   case 0:r->expected=396;break;
   case 3:r->expected=72;break;
   case 5:case 10:r->expected=864;break;
   case 15:r->expected=216;break;
   default:++r->bad_nid;r->symbols=0;return false;
  }
 }
 if(r->expected && r->symbols==r->expected) {
  r->symbols=r->expected=0;++r->frames;return true;
 }
 return false;
}
bool p25_rx_voice(const uint8_t ldu[216],unsigned voice,uint8_t payload[11],unsigned *corrected) {
 if(voice>=9 || !ldu || !payload || !corrected) return false;
 uint32_t u[8],pn=0;unsigned index=0,errors=0;
 for(unsigned j=0;j<8;++j) {
  unsigned bits=j<4?23:j<7?15:7;uint32_t v=0;
  for(unsigned b=0;b<bits;++b) v=(v<<1)|bit(ldu,p25_voice_bits[voice][index++]);
  if(j>0 && j<7) v^=pn_bits(&pn,bits);
  if(j<4) {
   uint32_t e=rx_golay_errors[(v^golay(v>>11))&2047];errors+=weight(e);u[j]=(v^e)>>11;
  } else if(j<7) {
   uint32_t syndrome=(v^hamming(v>>4))&15,e=0;
   if(syndrome) for(unsigned b=0;b<15;++b) {
    uint32_t candidate=1u<<b;
    if(((candidate^hamming(candidate>>4))&15)==syndrome) {e=candidate;break;}
   }
   errors+=weight(e);u[j]=(v^e)>>4;
  } else u[j]=v;
  if(j==0) pn=u[0]<<4;
 }
 memset(payload,0,11);unsigned out=0;
 for(unsigned j=0;j<8;++j) {
  unsigned bits=j<4?12:j<7?11:7;
  for(unsigned b=0;b<bits;++b,++out) payload[out/8]|=(uint8_t)(((u[j]>>(bits-1-b))&1)<<(7-out%8));
 }
 *corrected=errors;return true;
}
