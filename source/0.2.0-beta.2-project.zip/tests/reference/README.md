# Frozen receive reference

The demodulator, header, filter and FEC source here are frozen from candidate
256a180. They are test-only and are not linked into firmware. Preserve them
when optimizing production receive code. Host regressions compare selected
payloads, correction counts, unit counts and acquisition counts against this
implementation, including distorted synthetic inputs and saved RF captures.
This proves regression equivalence for the exercised corpus, not RF conformance.
