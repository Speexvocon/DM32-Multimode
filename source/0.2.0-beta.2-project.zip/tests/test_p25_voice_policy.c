// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_voice_policy.h"
#include "p25_rx.h"
#include "p25_interleave.h"
#include "p25_test_vectors.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

static void pitch_fields(void) {
    // Independent unpacking follows nostar decode_4400()'s 12/12/12/12/
    // 11/11/11/7 allocation, followed by decode_frame_vector()'s b0 formula.
    for(unsigned n=0;n<256;++n) {
        uint8_t payload[11];memset(payload,0xa5,sizeof payload);
        payload[0]=(uint8_t)((payload[0]&3u)|(n&0xfcu));
        payload[10]=(uint8_t)((payload[10]&0xf9u)|((n&3u)<<1));
        unsigned u[8]={0},pos=0;
        for(unsigned j=0;j<8;++j)
            for(unsigned b=0;b<(j<4 ? 12u : j<7 ? 11u : 7u);++b,++pos)
                u[j]=(u[j]<<1)|((payload[pos/8]>>(7-pos%8))&1u);
        unsigned decoded=((u[0]>>4)&0xfcu)|((u[7]>>1)&3u);
        assert(pos==88 && decoded==n && p25_voice_pitch(payload)==decoded);
        assert(p25_voice_plausible(payload)==(n<=207));
        // Every other bit is irrelevant to pitch, even when flipped together.
        for(unsigned i=1;i<10;++i)payload[i]^=0xff;
        payload[0]^=3;payload[10]^=0xf9;
        assert(p25_voice_pitch(payload)==n);
    }
    assert(!p25_voice_plausible(NULL));
}

static void bounded_damage(void) {
    uint8_t good[11]={0},bad[11]={0xff};
    p25_voice_policy p;p25_voice_policy_init(&p);
    for(unsigned i=0;i<1000;++i)
        assert(p25_voice_policy_missing(&p)==P25_VOICE_MUTE);
    assert(p.consecutive_bad==4 && !p.have_good);
    assert(p25_voice_policy_frame(&p,good,0,0)==P25_VOICE_ACCEPT);
    assert(p25_voice_policy_frame(&p,bad,0,0)==P25_VOICE_REPEAT);
    assert(p25_voice_policy_frame(&p,good,2,2)==P25_VOICE_REPEAT);
    assert(p25_voice_policy_missing(&p)==P25_VOICE_REPEAT);
    assert(p25_voice_policy_frame(&p,good,0,10)==P25_VOICE_MUTE);
    assert(!p.have_good);
    for(unsigned i=0;i<1000;++i)
        assert(p25_voice_policy_frame(&p,NULL,UINT_MAX,UINT_MAX)==P25_VOICE_MUTE);
    assert(p.consecutive_bad==4);
    assert(p25_voice_policy_frame(&p,good,1,9)==P25_VOICE_ACCEPT);
    assert(p.have_good && !p.consecutive_bad);
    assert(p25_voice_policy_missing(&p)==P25_VOICE_REPEAT);
    assert(p25_voice_policy_frame(&p,good,0,0)==P25_VOICE_ACCEPT);
    for(unsigned i=0;i<3;++i)assert(p25_voice_policy_missing(&p)==P25_VOICE_REPEAT);
    assert(p25_voice_policy_missing(&p)==P25_VOICE_MUTE);
    p25_voice_policy_init(&p); // A new caller may never inherit old PCM.
    assert(p25_voice_policy_missing(&p)==P25_VOICE_MUTE);
    assert(p25_voice_policy_frame(&p,good,1,0)==P25_VOICE_MUTE);
}

static void healthy_fec(void) {
    // The independent fixed fixture supplies real protected speech. Every
    // possible single protected bit error remains eligible for exact decode,
    // including errors in the most important first Golay codeword.
    for(unsigned l=0;l<2;++l) {
        const uint8_t *ldu=l ? p25_test_ldu2 : p25_test_ldu1;
        for(unsigned voice=0;voice<9;++voice) {
            uint8_t expected[11];unsigned corrections;
            assert(p25_rx_voice(ldu,voice,expected,&corrections));
            assert(!corrections && p25_voice_plausible(expected));
            for(unsigned b=0;b<137;++b) {
                uint8_t damaged[216],payload[11],copy[11];p25_voice_quality quality;
                memcpy(damaged,ldu,sizeof damaged);
                unsigned pos=p25_voice_bits[voice][b];
                damaged[pos/8]^=(uint8_t)(0x80u>>(pos%8));
                assert(p25_rx_voice_quality(damaged,voice,payload,&quality));
                assert(quality.et==1 && quality.e0==(b<23 ? 1u : 0u));
                assert(!memcmp(expected,payload,sizeof payload));
                memcpy(copy,payload,sizeof copy);
                p25_voice_policy p;p25_voice_policy_init(&p);
                assert(p25_voice_policy_frame(&p,payload,quality.e0,quality.et)==P25_VOICE_ACCEPT);
                assert(!memcmp(copy,payload,sizeof payload));
            }
            // A two-bit correction in u0 can still recover exact speech, but
            // deliberately crosses the OP25 first-word repeat threshold.
            uint8_t damaged[216],payload[11];p25_voice_quality quality;
            memcpy(damaged,ldu,sizeof damaged);
            for(unsigned b=0;b<2;++b) {
                unsigned pos=p25_voice_bits[voice][b];
                damaged[pos/8]^=(uint8_t)(0x80u>>(pos%8));
            }
            assert(p25_rx_voice_quality(damaged,voice,payload,&quality));
            assert(quality.e0==2 && quality.et==2 && !memcmp(expected,payload,sizeof payload));
            p25_voice_policy p;p25_voice_policy_init(&p);
            assert(p25_voice_policy_frame(&p,expected,0,0)==P25_VOICE_ACCEPT);
            assert(p25_voice_policy_frame(&p,payload,quality.e0,quality.et)==P25_VOICE_REPEAT);
        }
    }
}

static void bounded_pcm_integration(void) {
    // Exercise the caller contract with unique PCM, rather than re-decoding a
    // cached differential payload. A prolonged loss clears the cache; recovery
    // accepts the new output and may not reproduce the previous caller's audio.
    uint8_t good[11]={0};p25_voice_policy p;p25_voice_policy_init(&p);
    int16_t last[160]={0},out[160];unsigned resets=0;
    p25_voice_action previous=P25_VOICE_MUTE;
    const bool lost[]={false,true,true,true,true,true,false,true,false};
    for(unsigned f=0;f<sizeof lost/sizeof lost[0];++f) {
        p25_voice_action a=lost[f] ? p25_voice_policy_missing(&p) : p25_voice_policy_frame(&p,good,0,0);
        if(a==P25_VOICE_ACCEPT)
            for(unsigned n=0;n<160;++n)out[n]=last[n]=(int16_t)(1000+f*160+n);
        else if(a==P25_VOICE_REPEAT)memcpy(out,last,sizeof out);
        else {
            memset(out,0,sizeof out);memset(last,0,sizeof last);
            if(previous!=P25_VOICE_MUTE)++resets;
        }
        for(unsigned n=0;n<160;++n) {
            if(f>=1 && f<=3)assert(out[n]==(int16_t)(1000+n));
            if(f==4 || f==5)assert(!out[n]);
            if(f==7)assert(out[n]==(int16_t)(1000+6*160+n));
        }
        previous=a;
    }
    assert(resets==1);
}

int main(void) {
    _Static_assert(sizeof(p25_voice_policy)<=2,"Voice policy must remain tiny");
    pitch_fields();bounded_damage();healthy_fec();bounded_pcm_integration();
    puts("P25 voice policy: pitch, finite concealment, recovery and 2466 protected-bit cases passed");
    return 0;
}
