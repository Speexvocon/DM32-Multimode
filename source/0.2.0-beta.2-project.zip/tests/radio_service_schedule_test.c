// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_service_schedule.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    uint32_t key_last=0,power_last=0;
    unsigned scans=0,off_count=0;
    // A fast controller pass must not turn a 3-sample native switch debounce
    // into a 3-ms debounce. Brief low pulses reset on the next ON sample.
    for(uint32_t now=1000;now<=500000;now+=1000) {
        if(radio_service_due(&key_last,now,RADIO_INPUT_PERIOD_US))++scans;
        if(radio_service_due(&power_last,now,RADIO_POWER_PERIOD_US)) {
            bool knob_off=now>=99000 && now<=102000;
            off_count=knob_off ? off_count+1 : 0;
            assert(off_count<3);
        }
    }
    assert(scans==50 && power_last==500000 && off_count==0);
    // A steady switch-off needs three independently spaced observations.
    for(uint32_t now=501000;now<=800000;now+=1000) {
        if(radio_service_due(&power_last,now,RADIO_POWER_PERIOD_US))++off_count;
        if(now<800000)assert(off_count<3);
    }
    assert(off_count==3);
    // A blocked controller samples once on return; it cannot consume missed
    // periods as three immediate OFF readings.
    power_last=0;
    assert(radio_service_due(&power_last,500000,RADIO_POWER_PERIOD_US));
    for(unsigned i=0;i<50;++i)assert(!radio_service_due(&power_last,500000,RADIO_POWER_PERIOD_US));
    assert(!radio_service_due(&power_last,599999,RADIO_POWER_PERIOD_US));
    assert(radio_service_due(&power_last,600000,RADIO_POWER_PERIOD_US));
    // hrc_micros wraps during ordinary use; elapsed-time arithmetic remains valid.
    key_last=UINT32_MAX-4999u;
    assert(!radio_service_due(&key_last,4999,RADIO_INPUT_PERIOD_US));
    assert(radio_service_due(&key_last,5000,RADIO_INPUT_PERIOD_US));
    assert(!radio_service_due(&key_last,5000,RADIO_INPUT_PERIOD_US));
    _Static_assert(RADIO_CONTROL_PRIORITY<5u,"native audio must preempt control");
    puts("Service sampling, switch debounce, no catch-up and wrap checks passed");
    return 0;
}
