"""Compare the fixed-storage benchmark with the independently invoked public codec API."""
from pathlib import Path
import struct
import subprocess
import re

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/"build/imbe-bench-host"
samples=[]
noise=0x293
for frame in range(300):
    for i in range(160):
        if frame<100: value=0
        elif frame<200:
            phase=((frame-100)*160+i)%80
            value=(phase if phase<40 else 80-phase)*400-8000
        else:
            noise=(noise^(noise<<13))&0xffffffff
            noise^=noise>>17
            noise=(noise^(noise<<5))&0xffffffff
            value=(noise&32767)-16384
        samples.append(value)
pcm=out/"stimulus.s16le"
pcm.write_bytes(struct.pack("<48000h",*samples))
reference=out/"reference.imbe"
subprocess.run([str(ROOT/"build/host-voice/p25_voice.exe"),"encode",str(pcm),str(reference)],check=True)
expected=reference.read_bytes()
actual=(out/"payloads.bin").read_bytes()
assert actual==expected*2, "Fixed-storage output or repeat-run reset differs from public codec API"
checksum=2166136261
for b in expected: checksum=((checksum^b)*16777619)&0xffffffff
header=(ROOT/"src/firmware/imbe_bench_expected.h").read_text()
assert checksum==int(re.search(r"0x([0-9a-f]+)u",header)[1],16)
print(f"300 frames, repeated reset exact; reference FNV-1a {checksum:08x}")
