"""Compile generated deferred-worker/entry functions and pause real host threads.

The functions are extracted verbatim from the generated pinned glue; only its
hardware engine/RTOS edges are mocked. Target CI compiles the entire glue copy.
"""
import importlib.util
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
UPSTREAM=ROOT/"external/RadioFoundry/RadioFoundry"
spec=importlib.util.spec_from_file_location("drained_dmr",ROOT/"scripts/generate-drained-dmr.py")
GEN=importlib.util.module_from_spec(spec);spec.loader.exec_module(GEN)


def function(text,signature):
    start=text.index(signature);opening=text.index("{",start);depth=1;end=opening+1
    while depth:
        depth+=(text[end]=="{")-(text[end]=="}");end+=1
    return text[start:end]+"\n"


class DrainedDmrTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cc=shutil.which("gcc") or shutil.which("cc")
        if not cc:raise unittest.SkipTest("host C compiler unavailable")
        cls.tmp=tempfile.TemporaryDirectory();cls.addClassCleanup(cls.tmp.cleanup)
        d=Path(cls.tmp.name);cls.exe=d/"dmr-drain.exe"
        text=GEN.generate((UPSTREAM/"platform/hrc7000/dmr_glue.c").read_text())
        unit=text.split("// BEGIN GENERATED DEFERRED OWNERSHIP\n",1)[1].split("// END GENERATED DEFERRED OWNERSHIP",1)[0]
        for signature in ("void hrc_dmr_board_init(","void hrc_dmr_enter(void)","void hrc_dmr_leave(void)",
                          "static bool start(const dmr_config_t *cfg,", "static void stop(void)"):
            unit+=function(text,signature)
        f=d/"test.c";f.write_text(DECLARATIONS+unit+HARNESS)
        result=subprocess.run([cc,"-std=c11","-O2","-Wall","-Wextra","-Werror","-pthread",
                               "-I",str(ROOT/"src/firmware"),str(f),"-o",str(cls.exe)],capture_output=True,text=True)
        if result.returncode:raise AssertionError(result.stderr)

    def run_case(self,name):
        result=subprocess.run([str(self.exe),name],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_callback_drained_before_stop_and_reentry(self):self.run_case("callback")
    def test_poll_drained_before_leave_and_no_inactive_pop(self):self.run_case("poll")
    def test_event_copied_before_stop_is_not_dispatched(self):self.run_case("pop")
    def test_no_worker_until_active_and_new_callback_bound(self):self.run_case("inactive")
    def test_self_stop_does_not_deadlock_or_replace_live_stack(self):self.run_case("self")
    def test_reinitialize_waits_for_old_callback_before_reset(self):self.run_case("reinit")
    def test_missing_deferred_task_refuses_modem_start(self):self.run_case("no_task")
    def test_rx_snapshot_is_coherent_read_only_and_null_safe(self):self.run_case("rx_diag")
    def test_tx_snapshot_is_coherent_read_only_and_null_safe(self):self.run_case("tx_diag")
    def test_changed_source_refused(self):
        with self.assertRaises(ValueError):GEN.generate((UPSTREAM/"platform/hrc7000/dmr_glue.c").read_text()+"\n")


DECLARATIONS=r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include "radio_dmr_metrics.h"
typedef void *TaskHandle_t;
typedef struct { unsigned value; } dmr_event_t;
typedef struct { unsigned value; } dmr_burst_t;
typedef void (*dmr_event_cb_t)(const dmr_event_t *,void *);
typedef struct { unsigned dummy; } hrc7000_t,hrc_dmr_board_t,dmr_config_t;
typedef struct {
    uint32_t sys_ints,ts_rx_ints,ts_tx_ints,ticks,rx_voice,rx_lc_header,rx_terminator;
    uint32_t rx_crc_err,rx_unusable,late_entry,ev_overflow;
    uint32_t last_rx_type_info,last_sys_list,last_l2_status;
    uint32_t tx_bursts,tx_underrun,tx_rejected,tx_done;
    uint8_t last_cc;int8_t last_ts;
} mock_engine_stats_t;
typedef struct { hrc7000_t *dev;unsigned queue,generation;bool transmitting;mock_engine_stats_t st; } hrc7000_dmr_t;
static hrc7000_dmr_t eng;
static const hrc_dmr_board_t *brd;
static TaskHandle_t task;
static volatile bool active;
static dmr_event_cb_t volatile stack_cb;
static void *volatile stack_ctx;
static const unsigned ops=1;
enum { IRQ_MODEM_SYS=29,IRQ_MODEM_TS_TX=30,IRQ_MODEM_TS_RX=31,IRQ_MODEM_RF_TX=32,IRQ_TIMER3=12,
       DMR_TASK_STACK=512,DMR_TASK_PRIORITY=5,DMR_POLL_MS=10,pdTRUE=1 };
#define pdMS_TO_TICKS(x) (x)
uint32_t hrc_irq_save(void);void hrc_irq_restore(uint32_t);
TaskHandle_t xTaskGetCurrentTaskHandle(void);void vTaskDelay(unsigned);
unsigned ulTaskNotifyTake(unsigned,unsigned);
void hrc_irq_register(unsigned,void (*)(void));void hrc_irq_enable(unsigned,bool);
void xTaskCreate(void (*)(void *),const char *,unsigned,void *,unsigned,TaskHandle_t *);
void hrc7000_dmr_poll(hrc7000_dmr_t *);bool hrc7000_dmr_pop(hrc7000_dmr_t *,dmr_event_t *,dmr_burst_t *);
void hrc7000_dmr_init(hrc7000_dmr_t *,hrc7000_t *,const void *);
void hrc7000_dmr_run(hrc7000_dmr_t *);void hrc7000_dmr_halt(hrc7000_dmr_t *);
void hrc7000_dmr_configure(hrc7000_dmr_t *,const dmr_config_t *);
bool hrc7000_dmr_is_transmitting(hrc7000_dmr_t *);void hrc_dmr_tx_drop(void);
void hrc_dmr_leave(void);
static void hrc_barrier(void) { __asm__ volatile("" ::: "memory"); }
static void isr_sys(void) {} static void isr_ts_tx(void) {} static void isr_ts_rx(void) {}
static void isr_rftx(void) {} static void isr_pa_timer(void) {} static void irqs_enable(bool on) {(void)on;}
'''

HARNESS=r'''
static pthread_mutex_t irq_mutex=PTHREAD_MUTEX_INITIALIZER,gate_mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t gate_cond=PTHREAD_COND_INITIALIZER;
static bool paused,released;
static _Thread_local TaskHandle_t current;
static _Thread_local unsigned depth;
static atomic_uint callbacks,old_callbacks,polls,pops,delays,inits,halts;
static atomic_bool controller_returned,pause_poll,pause_pop,create_failed;
static unsigned controller_action;
static dmr_config_t config;
static hrc7000_t modem;
static hrc_dmr_board_t hooks;
static void pause_worker(void) {
    pthread_mutex_lock(&gate_mutex);paused=true;pthread_cond_broadcast(&gate_cond);
    while(!released)pthread_cond_wait(&gate_cond,&gate_mutex);
    pthread_mutex_unlock(&gate_mutex);
}
static void wait_paused(void) {
    pthread_mutex_lock(&gate_mutex);while(!paused)pthread_cond_wait(&gate_cond,&gate_mutex);pthread_mutex_unlock(&gate_mutex);
}
static void release_worker(void) {
    pthread_mutex_lock(&gate_mutex);released=true;pthread_cond_broadcast(&gate_cond);pthread_mutex_unlock(&gate_mutex);
}
uint32_t hrc_irq_save(void) {assert(!depth);pthread_mutex_lock(&irq_mutex);depth++;return 0;}
void hrc_irq_restore(uint32_t s) {(void)s;assert(depth==1);depth--;pthread_mutex_unlock(&irq_mutex);}
TaskHandle_t xTaskGetCurrentTaskHandle(void) {return current;}
void vTaskDelay(unsigned n) {assert(n==1 && !depth);atomic_fetch_add(&delays,1);sched_yield();}
unsigned ulTaskNotifyTake(unsigned a,unsigned b) {(void)a;(void)b;return 0;}
void hrc_irq_register(unsigned n,void (*fn)(void)) {(void)n;(void)fn;}
void hrc_irq_enable(unsigned n,bool on) {(void)n;(void)on;}
void xTaskCreate(void (*fn)(void *),const char *name,unsigned words,void *ctx,unsigned priority,TaskHandle_t *out) {
    (void)fn;(void)name;(void)words;(void)ctx;(void)priority;
    *out=atomic_load(&create_failed) ? NULL : (void *)1;
}
void hrc7000_dmr_poll(hrc7000_dmr_t *e) {(void)e;atomic_fetch_add(&polls,1);if(atomic_load(&pause_poll))pause_worker();}
bool hrc7000_dmr_pop(hrc7000_dmr_t *e,dmr_event_t *ev,dmr_burst_t *burst) {
    (void)burst;if(!e->queue)return false;e->queue--;ev->value=e->generation;atomic_fetch_add(&pops,1);
    if(atomic_load(&pause_pop))pause_worker();
    return true;
}
void hrc7000_dmr_init(hrc7000_dmr_t *e,hrc7000_t *m,const void *o) {
    (void)o;assert(!deferred_active);unsigned generation=e->generation+1;
    memset(e,0,sizeof *e);e->dev=m;e->generation=generation;atomic_fetch_add(&inits,1);
}
void hrc7000_dmr_run(hrc7000_dmr_t *e) {(void)e;}
void hrc7000_dmr_halt(hrc7000_dmr_t *e) {e->transmitting=false;atomic_fetch_add(&halts,1);}
void hrc7000_dmr_configure(hrc7000_dmr_t *e,const dmr_config_t *c) {(void)e;(void)c;assert(!deferred_active);}
bool hrc7000_dmr_is_transmitting(hrc7000_dmr_t *e) {return e->transmitting;}
void hrc_dmr_tx_drop(void) {eng.transmitting=false;}
static void fresh_callback(const dmr_event_t *ev,void *ctx) {assert(ctx==(void *)10 && ev->value==eng.generation);atomic_fetch_add(&callbacks,1);}
static void old_callback(const dmr_event_t *ev,void *ctx) {
    assert(ctx==(void *)9);unsigned generation=ev->value;pause_worker();
    assert(generation==eng.generation);atomic_fetch_add(&old_callbacks,1);
}
static void self_callback(const dmr_event_t *ev,void *ctx) {
    (void)ev;(void)ctx;assert(deferred_active);unsigned before=atomic_load(&inits);
    stop();assert(!start(&config,fresh_callback,(void *)10));
    hrc_dmr_board_init(&modem,&hooks);assert(atomic_load(&inits)==before);
    hrc_dmr_leave();atomic_fetch_add(&callbacks,1);
}
static void initialize(dmr_event_cb_t cb) {
    current=(void *)2;hrc_dmr_board_init(&modem,&hooks);assert(!active && deferred_closed);
    hrc_dmr_enter();assert(active && deferred_closed);assert(start(&config,cb,(void *)9));
}
static void *worker(void *p) {(void)p;current=task;dmr_deferred_once();return NULL;}
static void *controller(void *p) {
    (void)p;current=(void *)2;
    if(controller_action==1)hrc_dmr_leave();else if(controller_action==2)hrc_dmr_board_init(&modem,&hooks);else stop();
    atomic_store(&controller_returned,true);return NULL;
}
static void diag_seed(unsigned base) {
    uint32_t saved=hrc_irq_save();
    eng.st.sys_ints=base;eng.st.ts_rx_ints=base+1;eng.st.ts_tx_ints=base+2;
    eng.st.ticks=base+3;eng.st.rx_voice=base+4;eng.st.rx_lc_header=base+5;
    eng.st.rx_terminator=base+6;eng.st.rx_crc_err=base+7;eng.st.rx_unusable=base+8;
    eng.st.late_entry=base+9;eng.st.ev_overflow=base+10;
    eng.st.last_rx_type_info=base+11;eng.st.last_sys_list=base+12;eng.st.last_l2_status=base+13;
    eng.st.tx_bursts=base+14;eng.st.tx_underrun=base+15;
    eng.st.tx_rejected=base+16;eng.st.tx_done=base+17;
    eng.st.last_cc=base%16u;eng.st.last_ts=(int8_t)(base%2u-1);
    active=(base&1u)!=0;stack_cb=active ? fresh_callback : NULL;
    deferred_closed=(base&2u)!=0;deferred_active=(base&4u)!=0;
    hrc_irq_restore(saved);
}
static void *diag_writer(void *p) {
    (void)p;for(unsigned base=1;base<10001;++base)diag_seed(base);return NULL;
}
static void diag_check(const radio_dmr_rx_diag_t *d) {
    unsigned base=d->sys_ints;
    assert(d->ts_rx_ints==base+1 && d->ts_tx_ints==base+2 && d->ticks==base+3);
    assert(d->rx_voice==base+4 && d->rx_lc_header==base+5 && d->rx_terminator==base+6);
    assert(d->rx_crc_err==base+7 && d->rx_unusable==base+8 && d->late_entry==base+9);
    assert(d->ev_overflow==base+10 && d->last_rx_type_info==base+11);
    assert(d->last_sys_list==base+12 && d->last_l2_status==base+13);
    assert(d->last_cc==base%16u && d->last_ts==(int8_t)(base%2u-1));
    assert(d->active==((base&1u)!=0) && d->callback_bound==d->active);
    assert(d->deferred_closed==((base&2u)!=0) && d->deferred_active==((base&4u)!=0));
}
int main(int argc,char **argv) {
    assert(argc==2);
    if(!strcmp(argv[1],"tx_diag")) {
        radio_dmr_native_tx_diag_t d;
        hrc_dmr_tx_diag(NULL);assert(!depth);
        diag_seed(123);hrc7000_dmr_t before=eng;
        hrc_dmr_tx_diag(&d);
        assert(d.tx_bursts==137 && d.tx_underruns==138 && d.tx_rejected==139 && d.tx_done==140 && d.event_overflows==133);
        assert(!depth && !memcmp(&before,&eng,sizeof eng));
        assert(!atomic_load(&polls) && !atomic_load(&pops) && !atomic_load(&halts));
        pthread_t writer;pthread_create(&writer,NULL,diag_writer,NULL);
        for(unsigned i=0;i<10000;++i) {
            hrc_dmr_tx_diag(&d);unsigned base=d.tx_bursts-14;
            assert(d.tx_underruns==base+15 && d.tx_rejected==base+16 && d.tx_done==base+17 && d.event_overflows==base+10);
        }
        pthread_join(writer,NULL);return 0;
    }
    if(!strcmp(argv[1],"rx_diag")) {
        radio_dmr_rx_diag_t d;
        hrc_dmr_rx_diag(NULL);assert(!depth);
        diag_seed(123);
        hrc7000_dmr_t before=eng;
        hrc_dmr_rx_diag(&d);diag_check(&d);
        assert(!depth && !memcmp(&before,&eng,sizeof eng));
        assert(!atomic_load(&polls) && !atomic_load(&pops) && !atomic_load(&halts));
        pthread_t writer;pthread_create(&writer,NULL,diag_writer,NULL);
        for(unsigned i=0;i<10000;++i) {hrc_dmr_rx_diag(&d);diag_check(&d);}
        pthread_join(writer,NULL);return 0;
    }
    if(!strcmp(argv[1],"no_task")) {
        current=(void *)2;atomic_store(&create_failed,true);
        hrc_dmr_board_init(&modem,&hooks);hrc_dmr_enter();
        assert(task==NULL && !start(&config,fresh_callback,(void *)10));
        assert(deferred_closed && !stack_cb);
        hrc_dmr_leave();atomic_store(&create_failed,false);
        hrc_dmr_board_init(&modem,&hooks);hrc_dmr_enter();
        assert(start(&config,fresh_callback,(void *)10));return 0;
    }
    if(!strcmp(argv[1],"inactive")) {
        current=(void *)2;hrc_dmr_board_init(&modem,&hooks);eng.queue=1;dmr_deferred_once();
        assert(!atomic_load(&polls) && !atomic_load(&pops));
        hrc_dmr_enter();dmr_deferred_once();assert(!atomic_load(&polls));
        assert(start(&config,fresh_callback,(void *)10));dmr_deferred_once();
        assert(atomic_load(&callbacks)==1);stop();eng.queue=1;dmr_deferred_once();
        assert(atomic_load(&callbacks)==1);return 0;
    }
    if(!strcmp(argv[1],"self")) {
        initialize(self_callback);eng.queue=2;current=task;dmr_deferred_once();current=(void *)2;
        assert(!active && deferred_closed && !deferred_active && !atomic_load(&delays));
        assert(atomic_load(&callbacks)==1);hrc_dmr_board_init(&modem,&hooks);
        hrc_dmr_enter();assert(start(&config,fresh_callback,(void *)10));eng.queue=1;dmr_deferred_once();
        assert(atomic_load(&callbacks)==2);return 0;
    }
    initialize(old_callback);eng.queue=2;
    if(!strcmp(argv[1],"poll")) {controller_action=1;atomic_store(&pause_poll,true);}
    else if(!strcmp(argv[1],"pop"))atomic_store(&pause_pop,true);
    else if(!strcmp(argv[1],"reinit"))controller_action=2;
    else assert(!strcmp(argv[1],"callback"));
    pthread_t a,b;pthread_create(&a,NULL,worker,NULL);wait_paused();
    pthread_create(&b,NULL,controller,NULL);while(!atomic_load(&delays))sched_yield();
    assert(!atomic_load(&controller_returned) && deferred_active);
    release_worker();pthread_join(a,NULL);pthread_join(b,NULL);
    assert(atomic_load(&controller_returned) && !deferred_active && deferred_closed);
    if(controller_action==1)assert(!active && !atomic_load(&pops) && !atomic_load(&old_callbacks));
    if(!strcmp(argv[1],"pop"))assert(!atomic_load(&old_callbacks));
    if(controller_action==2)assert(!active && atomic_load(&inits)==2 && !eng.queue);
    // New stack/session starts only after old worker has finished.
    hrc_dmr_board_init(&modem,&hooks);hrc_dmr_enter();assert(start(&config,fresh_callback,(void *)10));
    atomic_store(&pause_poll,false);atomic_store(&pause_pop,false);eng.queue=1;dmr_deferred_once();
    assert(atomic_load(&callbacks)==1);stop();return 0;
}
'''


if __name__=="__main__":unittest.main()
