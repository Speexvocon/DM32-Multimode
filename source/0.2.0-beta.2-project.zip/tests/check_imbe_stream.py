"""Check the complete continuous stream against untouched encoder output."""
from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
build=root/'build/imbe-bench-host'
reference=(build/'stream-reference.imbe').read_bytes()
actual=(build/'stream.imbe').read_bytes()
assert len(reference)==3006*11 and actual==reference
hash_value=2166136261
for byte in reference:
    hash_value=((hash_value^byte)*16777619)&0xffffffff
header=(root/'src/firmware/imbe_bench_expected.h').read_text()
expected=int(re.search(r'IMBE_STREAM_EXPECTED 0x([0-9a-f]+)u',header)[1],16)
assert hash_value==expected, 'Full-stream reference checksum changed'
print(f'3006 continuous frames match original byte-for-byte; FNV-1a {hash_value:08x}')
