"""Check TDMA sampling and context/age handling in the actual C meter."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class SignalMeter(unittest.TestCase):
    def test_tdma_hold_context_changes_invalid_values_and_clock_wrap(self):
        compiler = shutil.which("gcc")
        if not compiler:
            self.skipTest("host GCC is required")
        with tempfile.TemporaryDirectory(prefix="signal-meter-") as tmp:
            binary = Path(tmp) / "signal-meter.exe"
            subprocess.run([compiler, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
                            "-I", str(ROOT / "src/firmware"),
                            str(ROOT / "tests/radio_signal_meter_test.c"),
                            "-o", str(binary)], check=True, capture_output=True, text=True)
            result = subprocess.run([str(binary)], check=True, capture_output=True, text=True)
            self.assertIn("checks passed", result.stdout)


if __name__ == "__main__":
    unittest.main()
