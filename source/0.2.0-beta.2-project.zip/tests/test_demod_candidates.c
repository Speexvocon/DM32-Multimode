// SPDX-License-Identifier: GPL-3.0-or-later
// Drive actual completed-frame arbitration with real FEC and count its work.
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "p25_demod.h"
#include "p25_live_frame.h"
#include "p25_interleave.h"

static unsigned voice_calls;
static bool counted_voice(const uint8_t *ldu,unsigned voice,uint8_t *payload,unsigned *corrected) {
    ++voice_calls;
    return p25_rx_voice(ldu,voice,payload,corrected);
}
// Include the production unit to exercise its private candidate arbitration,
// without adding an embedded test hook or changing its public ABI.
#define p25_rx_voice counted_voice
#include "../src/firmware/p25_demod.c"
#undef p25_rx_voice

static void make_ldu(uint8_t out[216],unsigned marker) {
    uint8_t payload[9][11];
    for(unsigned i=0;i<sizeof payload;++i)((uint8_t *)payload)[i]=(uint8_t)(i*37u+marker);
    p25_live_ldu(out,(const uint8_t (*)[11])payload,false);
}
static void damage(uint8_t ldu[216],unsigned voice,unsigned errors) {
    assert(voice<9 && errors<=3);
    for(unsigned i=0;i<errors;++i) {
        unsigned bit=p25_voice_bits[voice][i];
        ldu[bit/8]^=(uint8_t)(1u<<(7-bit%8));
    }
}
static unsigned score(const uint8_t ldu[216]) {
    unsigned sum=0;
    for(unsigned i=0;i<9;++i) {
        uint8_t payload[11];unsigned errors;
        assert(p25_rx_voice(ldu,i,payload,&errors));sum+=errors;
    }
    return sum;
}
static void complete(p25_demod *d,const uint8_t frame[216],unsigned quality) {
    p25_demod_lane *l=&d->lane[0];memset(l,0,sizeof *l);
    l->gain=1000;l->quality=quality;
    for(unsigned i=0;i<863;++i)
        assert(!p25_rx_push(&l->rx,(frame[i/4]>>(6-2*(i%4)))&3));
    assert(l->rx.symbols==863 && l->rx.expected==864);
    unsigned dibit=frame[215]&3;
    const int16_t levels[4]={1000,3000,-1000,-3000};
    voice_calls=0;symbol(d,l,levels[dibit]);
}
static void competitor(unsigned best_errors,unsigned best_quality,unsigned quality,
                       unsigned damaged_voice,unsigned candidate_errors,unsigned expected_calls,bool wins) {
    p25_demod d;p25_demod_init(&d);
    uint8_t best[216],candidate[216];make_ldu(best,1);make_ldu(candidate,2);
    damage(best,0,best_errors);damage(candidate,damaged_voice,candidate_errors);
    assert(score(best)==best_errors && score(candidate)==candidate_errors);
    complete(&d,best,best_quality);
    assert(voice_calls==9 && d.pending_ticks==11 && d.pending_errors==best_errors);
    const p25_rx previous=d.pending;
    complete(&d,candidate,quality);
    assert(voice_calls==expected_calls);
    assert(d.fec_candidates==2 && !d.fec_skipped);
    assert(d.pending_errors==(wins ? candidate_errors : best_errors));
    assert(d.pending_quality==(wins ? quality : best_quality));
    if(wins)assert(!memcmp(d.pending.frame,candidate,sizeof candidate));
    else assert(!memcmp(&d.pending,&previous,sizeof previous));
}
static void hunt_guards(void) {
    p25_demod d;p25_demod_init(&d);
    d.idle_ticks=28800;d.hunt_filled=240;d.pending_ticks=1;
    p25_demod before=d;hunting_rearm(&d);
    assert(!memcmp(&d,&before,sizeof d)); // Never overwrite a pending winner.
    d.pending_ticks=0;d.lane[4].rx.symbols=24;
    before=d;hunting_rearm(&d);
    assert(!memcmp(&d,&before,sizeof d)); // Or a sync/NID/unit in progress.
    d.lane[4].rx.symbols=0;
    d.frames=17;d.ticks=1234567;d.previous=-321;d.fir[3]=123;
    d.acquisitions=19;d.fec_candidates=23;d.fec_skipped=29;
    for(unsigned i=0;i<10;++i) {
        d.lane[i].rx.frames=31+i;d.lane[i].rx.syncs=41+i;
        d.lane[i].rx.bad_nid=51+i;d.lane[i].rx.bad_input=61+i;
    }
    before=d;hunting_rearm(&d);
    assert(d.hunt_rearms==1 && d.sync_tests==before.sync_tests+10);
    assert(d.frames==before.frames && d.ticks==before.ticks);
    assert(d.previous==before.previous && !memcmp(d.fir,before.fir,sizeof d.fir));
    assert(d.acquisitions==before.acquisitions && d.fec_candidates==before.fec_candidates
           && d.fec_skipped==before.fec_skipped);
    for(unsigned i=0;i<10;++i) {
        assert(d.lane[i].rx.frames==before.lane[i].rx.frames);
        assert(d.lane[i].rx.syncs==before.lane[i].rx.syncs);
        assert(d.lane[i].rx.bad_nid==before.lane[i].rx.bad_nid);
        assert(d.lane[i].rx.bad_input==before.lane[i].rx.bad_input);
    }
}
int main(void) {
    hunt_guards();
    // Stronger sync cannot rescue a candidate that already has more errors.
    competitor(0,900,1000,0,1,1,false);
    competitor(1,900,1000,2,2,3,false);
    competitor(2,900,1000,6,3,7,false);
    // The final codeword can still decide a late loss.
    competitor(0,900,1000,8,1,9,false);
    // Ties must finish all nine words, then honor the existing quality rule.
    competitor(2,900,1000,0,2,9,true);
    competitor(2,1000,900,0,2,9,false);
    competitor(2,1000,1000,0,2,9,false);
    // A candidate that is tied early can still finish with fewer corrections.
    competitor(2,1000,900,8,1,9,true);
    // No pending winner means there is no score ceiling to prune against.
    p25_demod d;p25_demod_init(&d);uint8_t ldu[216];make_ldu(ldu,3);
    for(unsigned i=0;i<9;++i)damage(ldu,i,3);
    complete(&d,ldu,900);assert(voice_calls==9 && d.pending_errors==27);
    // Existing identical-frame reuse keeps its counters and quality update.
    complete(&d,ldu,1000);
    assert(!voice_calls && d.fec_candidates==1 && d.fec_skipped==1 && d.pending_quality==1000);
    assert(!memcmp(d.pending.frame,ldu,sizeof ldu));
    puts("Demod candidate pruning: real-FEC early/late loss, ties, winners and unchanged counters passed");
}
