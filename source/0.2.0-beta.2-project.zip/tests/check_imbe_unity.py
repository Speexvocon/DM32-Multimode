"""Bit-exact comparison against the separately built original public encoder."""
from pathlib import Path
import math
import random
import struct
import subprocess

root = Path(__file__).resolve().parents[1]
out = root / 'build/imbe-bench-host'
rng = random.Random(0x293)
samples = []
for frame in range(2000):
    case = (frame // 100) % 10
    for i in range(160):
        n = frame * 160 + i
        if case == 0:
            value = 32767 if frame % 2 else -32768
        elif case == 1:
            value = 32767 if i % 2 else -32768
        elif case == 2:
            value = 32767 if i == frame % 160 else 0
        elif case == 3:
            value = rng.randrange(-32768, 32768)
        elif case == 4:
            value = round(30000 * math.sin(2 * math.pi * (100 + frame % 100 * 29) * n / 8000))
        elif case == 5:
            value = rng.randrange(-16, 17)
        elif case == 6:
            value = 0
        elif case == 7:
            # Abrupt silence/voiced transitions exercise analysis history.
            value = 0 if frame % 10 < 5 else round(24000 * math.sin(2 * math.pi * 173 * n / 8000))
        elif case == 8:
            # Alternate low energy and clipping to exercise both scale paths.
            amplitude = 8 if frame % 2 else 32767
            value = amplitude if i % 3 else -amplitude
        else:
            value = 0 if frame % 10 < 5 else rng.randrange(-32768, 32768)
        samples.append(value)
pcm = out / 'edge-stimulus.s16le'
reference, actual = out / 'edge-reference.imbe', out / 'edge-unity.imbe'
for start in range(0, len(samples), 400 * 160):
    # Each public-tool call is bounded to at most 504 speech frames.
    chunk = samples[start:start + 400 * 160]
    pcm.write_bytes(struct.pack('<' + str(len(chunk)) + 'h', *chunk))
    subprocess.run([str(root / 'build/host-voice/p25_voice.exe'), 'encode', str(pcm), str(reference)], check=True)
    subprocess.run([str(out / 'unity-probe.exe'), str(pcm), str(actual)], check=True)
    assert actual.read_bytes() == reference.read_bytes(), f'Unity encoder differs in batch {start}'
    assert actual.stat().st_size == 400 * 11
print('2000 adversarial/mixed/transition frames match the separate reference encoder exactly')
