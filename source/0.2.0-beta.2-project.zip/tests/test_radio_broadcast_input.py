"""Exercise the bounded broadcast keypad parser without hardware."""
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]

class BroadcastInputTest(unittest.TestCase):
    def test_parser(self):
        output=ROOT/'build'/'production-functions'/'broadcast-input-test.exe'
        output.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-pedantic',
            '-Isrc/firmware','tests/test_radio_broadcast_input.c','-o',str(output)],cwd=ROOT,check=True)
        subprocess.run([str(output)],cwd=ROOT,check=True)

if __name__=='__main__':unittest.main()
