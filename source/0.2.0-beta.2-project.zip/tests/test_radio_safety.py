"""Recovery gates with synthetic memories only; never open a serial port."""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/radio-safety.py"
spec = importlib.util.spec_from_file_location("radio_safety", SCRIPT)
safety = importlib.util.module_from_spec(spec)
spec.loader.exec_module(safety)


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.program = bytes(range(256)) * (safety.PROGRAM_SIZE // 256)
        data = bytearray(b"\xff" * safety.DATA_SIZE)
        data[0x5000:0x5008] = safety.HEADER
        data[0x5FFF] = 2
        self.data = bytes(data)
        for directory in (self.directory, self.directory / "readback"):
            directory.mkdir(exist_ok=True)
            (directory / "program.bin").write_bytes(self.program)
            (directory / "data.bin").write_bytes(self.data)

    def seal(self):
        return safety.seal(self.directory, "bench-unit-1", "recorded-version")

    def test_complete_backup_restores_application_without_bootloader(self):
        self.seal()
        self.assertEqual(safety.validate(self.directory, "bench-unit-1"), (self.program, self.data))
        self.assertEqual((self.directory / "restore-application.bin").read_bytes(), self.program[0xC000:])
        self.assertEqual((self.directory / "calibration/factory-005000.bin").stat().st_size, 4096)
        with self.assertRaises(FileExistsError):
            self.seal()

    def test_corruption_wrong_label_missing_files_fail_closed(self):
        self.seal()
        with self.assertRaises(ValueError):
            safety.validate(self.directory, "different-radio")
        target = self.directory / "restore-application.bin"
        target.write_bytes(b"wrong")
        with self.assertRaises(ValueError):
            safety.validate(self.directory, "bench-unit-1")
        target.unlink()
        with self.assertRaises(FileNotFoundError):
            safety.validate(self.directory, "bench-unit-1")

    def test_mismatching_second_read_never_seals(self):
        (self.directory / "readback/data.bin").write_bytes(bytes(safety.DATA_SIZE))
        with self.assertRaises(ValueError):
            self.seal()
        self.assertFalse((self.directory / "manifest.json").exists())

    def test_truncated_read_and_missing_calibration_refused(self):
        (self.directory / "program.bin").write_bytes(self.program[:-1])
        with self.assertRaises(ValueError):
            safety.read_memories(self.directory)
        with self.assertRaises(ValueError):
            safety.calibration_files(b"\xff" * safety.DATA_SIZE)

    def test_calibration_copy_and_multiple_factory_pages_preserved(self):
        data = bytearray(self.data)
        data[0x6FFF] = 2
        self.assertEqual(len(safety.calibration_files(data)), 3)
        data[0x5FFF] = data[0x6FFF] = 0xFF
        data[0x710000:0x710008] = safety.HEADER
        self.assertEqual(len(safety.calibration_files(data)), 1)

    def test_recovery_accepts_erased_app_but_rejects_changed_factory_data(self):
        blank_app = self.program[:0xC000] + b"\xff" * (safety.PROGRAM_SIZE - 0xC000)
        original = self.program, self.data
        safety.compare((blank_app, self.data), original)
        (self.directory / "program.bin").write_bytes(blank_app)
        safety.read_memories(self.directory, require_application=False)
        with self.assertRaises(ValueError):
            safety.read_memories(self.directory)
        with self.assertRaises(ValueError):
            safety.compare((blank_app, self.data), original, full=True)
        data = bytearray(self.data)
        data[0x5010] ^= 1
        with self.assertRaises(ValueError):
            safety.compare((blank_app, bytes(data)), original)
        changed_boot = bytes([self.program[0] ^ 1]) + self.program[1:]
        with self.assertRaises(ValueError):
            safety.compare((changed_boot, self.data), original)

    def test_default_backup_is_offline_and_existing_folder_refused(self):
        target = self.directory / "new"
        command = [sys.executable, str(SCRIPT), "backup", "--directory", str(target),
                   "--radio-label", "bench-unit-1", "--firmware", "version", "--port", "NOT_A_PORT"]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("PLAN ONLY", result.stdout)
        self.assertFalse(target.exists())
        target.mkdir()
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)

    def test_restore_default_never_reads_or_flashes_hardware(self):
        self.seal()
        library = {"MODELS": {"dm32": object()},
                   "unwrap": lambda data, model: (data, "raw"),
                   "check_image": lambda data, model: None}
        arguments = [str(SCRIPT), "restore", "--directory", str(self.directory),
                     "--radio-label", "bench-unit-1", "--port", "NOT_A_PORT"]
        with patch.object(sys, "argv", arguments), patch.object(safety, "tools", return_value=("stub", "loader")), \
                patch.object(safety.runpy, "run_path", return_value=library), \
                patch.object(safety, "dump") as read, patch.object(safety.subprocess, "run") as flash:
            safety.main()
            read.assert_not_called()
            flash.assert_not_called()

    def test_restore_execution_refuses_mismatch_before_updater(self):
        self.seal()
        library = {"MODELS": {"dm32": object()},
                   "unwrap": lambda data, model: (data, "raw"),
                   "check_image": lambda data, model: None}
        changed = bytearray(self.data)
        changed[0x5010] ^= 1
        arguments = [str(SCRIPT), "restore", "--directory", str(self.directory),
                     "--radio-label", "bench-unit-1", "--port", "NOT_A_PORT", "--execute"]
        with patch.object(sys, "argv", arguments), patch.object(safety, "tools", return_value=("stub", "loader")), \
                patch.object(safety.runpy, "run_path", return_value=library), \
                patch.object(safety, "dump", return_value=(self.program, bytes(changed))), \
                patch.object(safety.subprocess, "run") as flash:
            with self.assertRaises(ValueError):
                safety.main()
            flash.assert_not_called()


if __name__ == "__main__":
    unittest.main()
