// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_ux.h"
#include <assert.h>
#include <stdio.h>
static void test_received_call_wakes_screen(void) {
    // Run across the microsecond counter wrap, with both lights timed out.
    const uint32_t start=UINT32_MAX-2500000u;
    radio_ux u;radio_ux_init(&u,start);u.screen_seconds=2;u.keypad_seconds=1;u.locked=true;
    uint32_t now=start+3000000u;
    radio_ux_idle(&u,now,false);assert(!u.screen_on && !u.keypad_on);

    // A radio wake neither illuminates the keypad nor consumes the next key.
    assert(radio_ux_rx_activity(&u,now));
    radio_ux_idle(&u,now,false);
    assert(u.screen_on && !u.keypad_on && u.locked && !u.consume_release);

    // A call longer than the screen timeout remains visible throughout.
    for(unsigned second=1;second<=8;++second) {
        now=start+3000000u+second*1000000u;
        assert(!radio_ux_rx_activity(&u,now));radio_ux_idle(&u,now,false);
        assert(u.screen_on && !u.keypad_on && u.locked && !u.consume_release);
    }
    // The configured full timeout starts at the end of reception.
    radio_ux_idle(&u,now+1999999u,false);assert(u.screen_on && !u.keypad_on);
    radio_ux_idle(&u,now+2000000u,false);assert(!u.screen_on && !u.keypad_on);

    // Radio activity must not eat a subsequent intentional user action.
    assert(radio_ux_rx_activity(&u,now+2000001u));
    assert(!radio_ux_activity(&u,now+2000002u,true));
    assert(u.keypad_on && !u.consume_release && u.locked);
    radio_ux_idle(&u,now+3000002u,false);assert(u.screen_on && !u.keypad_on);
    radio_ux_idle(&u,now+4000002u,false);assert(!u.screen_on && !u.keypad_on);

    // An existing key-wake release guard also survives an intervening RX event.
    assert(radio_ux_activity(&u,now+4000003u,true) && u.consume_release);
    radio_ux_rx_activity(&u,now+4000004u);assert(u.consume_release);
}
int main(void) {
    test_received_call_wakes_screen();
    radio_ux u;uint32_t now=0xff000000u;radio_ux_init(&u,now);
    u.screen_seconds=2;u.keypad_seconds=1;
    radio_ux_idle(&u,now+1000000u,false);assert(u.screen_on && !u.keypad_on);
    radio_ux_idle(&u,now+2000000u,false);assert(!u.screen_on && !u.keypad_on);
    assert(radio_ux_activity(&u,now+2000100u,true) && u.consume_release);
    assert(!radio_ux_lock_chord(&u,now+2000200u,false,false,true) && !u.consume_release);
    assert(!radio_ux_lock_chord(&u,now+3000000u,true,true,true));
    assert(!radio_ux_lock_chord(&u,now+3999999u,true,true,true));
    assert(radio_ux_lock_chord(&u,now+4000000u,true,true,true) && u.locked);
    assert(!radio_ux_lock_chord(&u,now+5000000u,true,true,true) && u.locked);
    radio_ux_lock_chord(&u,now+5000100u,false,false,true);
    radio_ux_lock_chord(&u,now+5100000u,true,true,true);
    assert(radio_ux_lock_chord(&u,now+6100000u,true,true,true) && !u.locked);
    radio_ux_idle(&u,now+10000000u,true);assert(u.screen_on && u.keypad_on);
    u.screen_seconds=u.keypad_seconds=0;radio_ux_idle(&u,now+100000000u,false);
    assert(u.screen_on && u.keypad_on);
    radio_scan s;radio_scan_start(&s,now,0,2);
    assert(!radio_scan_due(&s,now+999999u,false));
    assert(radio_scan_due(&s,now+1000000u,false));
    assert(!radio_scan_due(&s,now+1100000u,true) && s.holding);
    assert(!radio_scan_due(&s,now+3099999u,false));
    assert(radio_scan_due(&s,now+3100000u,false) && !s.holding);
    s.running=false;assert(!radio_scan_due(&s,now+9000000u,false));
    radio_scan_start(&s,now,255,15);s.dwell_us=250000u;s.hold_us=700000u;s.due_us=now+s.dwell_us;
    assert(s.cursor==255 && s.list==15 && !radio_scan_due(&s,now+249999u,false));
    assert(radio_scan_due(&s,now+250000u,false) && s.due_us==now+500000u);
    assert(!radio_scan_due(&s,now+300000u,true) && s.due_us==now+1000000u);
    assert(!radio_scan_due(&s,now+999999u,false) && radio_scan_due(&s,now+1000000u,false));
    s.hold_us=0;assert(!radio_scan_due(&s,now+1100000u,true));
    assert(radio_scan_due(&s,now+1100000u,false));
    puts("Radio UX: independent RX screen wake, wrap-safe light timers, wake consumption, one-shot lock chord and scan dwell/hold passed");
}
