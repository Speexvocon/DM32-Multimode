// SPDX-License-Identifier: GPL-3.0-or-later
#include <cassert>
#include <cstdio>
#include "op25_imbe_frame.h"
#include "p25_test_vectors.h"
extern "C" {
#include "p25_live_frame.h"
}
int main() {
    uint32_t rng=123;
    for(unsigned trial=0;trial<1000;++trial) {
        uint8_t payload[9][11],actual[216];
        for(auto &frame:payload) for(auto &byte:frame) {
            rng=1664525u*rng+1013904223u;
            byte=trial==0 ? 0 : trial==1 ? 255 : (uint8_t)(rng>>24);
        }
        for(unsigned kind=0;kind<2;++kind) {
            p25_channel_frames channel;
            assert(p25_channel_build(&channel,trial%4096,trial*61%65536,trial*16777%16777216));
            const uint8_t *base=kind ? channel.ldu2 : channel.ldu1;
            p25_live_ldu_template(actual,payload,base);
            bit_vector expected(1728);
            for(unsigned bit=0;bit<1728;++bit) expected[bit]=(base[bit/8]>>(7-bit%8))&1;
            for(unsigned f=0;f<9;++f) {
                packed_codeword packed(payload[f],payload[f]+11);
                uint32_t u[8];
                imbe_unpack(packed,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]);
                voice_codeword cw(144);
                imbe_header_encode(cw,u[0],u[1],u[2],u[3],u[4],u[5],u[6],u[7]<<1);
                imbe_interleave(expected,cw,f);
            }
            for(unsigned bit=0;bit<1728;++bit) assert(expected[bit]==((actual[bit/8]>>(7-bit%8))&1));
        }
    }
    puts("2000 configurable fixed-storage LDUs exactly match OP25 including control/status bits");
}
