"""Compare complete generated channel templates against pinned OP25."""
from pathlib import Path
import ctypes as c
import importlib.util
import random
import subprocess
import unittest
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('channel_reference',ROOT/'scripts/generate-p25-channel.py')
ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
class Frames(c.Structure):
    _fields_=[('hdu',c.c_uint8*99),('ldu1',c.c_uint8*216),('ldu2',c.c_uint8*216),('tdu',c.c_uint8*18)]
class ChannelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        out=ROOT/'build/channel';out.mkdir(parents=True,exist_ok=True)
        dll=out/'channel.dll'
        subprocess.run(['gcc','-std=c11','-O2','-shared','-Wall','-Wextra','-Werror','-fPIC','-Isrc/firmware','-Ifixtures/p25-1011','src/firmware/p25_live_frame.c','-o',str(dll)],cwd=ROOT,check=True)
        cls.lib=c.CDLL(str(dll));cls.build=cls.lib.p25_channel_build
        cls.build.argtypes=[c.POINTER(Frames),c.c_uint32,c.c_uint32,c.c_uint32];cls.build.restype=c.c_bool
        cls.craft=ref.reference()
    def test_full_frames(self):
        rng=random.Random(4321)
        cases=[(0x293,1,1),(0,0,0),(4095,65535,16777215)]
        for field,width in enumerate((12,16,24)):
            for bit in range(width):
                case=[0x293,1,1];case[field]^=1<<bit;cases.append(tuple(case))
        cases += [(rng.randrange(4096),rng.randrange(65536),rng.randrange(16777216)) for _ in range(300)]
        for args in cases:
            out=Frames();self.assertTrue(self.build(c.byref(out),*args))
            self.assertEqual(bytes(out),ref.call(self.craft,*args),args)
    def test_invalid_no_partial_output(self):
        out=Frames();c.memset(c.byref(out),0x5a,c.sizeof(out));before=bytes(out)
        for args in ((4096,1,1),(0x293,65536,1),(0x293,1,16777216)):
            self.assertFalse(self.build(c.byref(out),*args));self.assertEqual(bytes(out),before)
        self.assertFalse(self.build(None,0x293,1,1))
if __name__=='__main__':unittest.main()
