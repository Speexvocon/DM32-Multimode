"""Offline positive controls using the existing OP25 transmit-filter source.

Requires numpy/scipy, the local OP25 checkout and built RX replay executable.
No device access. Results describe these controls, not receiver conformance.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import math

import numpy as np
from scipy import signal

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from p25_fm_search import search

out = root / 'build/fm-search-validation'
out.mkdir(parents=True, exist_ok=True)
source = root / 'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/op25_c4fm_mod.py'
# Execute only the existing pure coefficient generators, without GNU Radio.
tree = ast.parse(source.read_text())
names = {'transfer_function_tx', 'c4fm_taps'}
nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names]
assert len(nodes) == 2
scope = dict(np=np, pi=math.pi, sin=math.sin, cos=math.cos,
             _def_symbol_rate=4800, _def_output_sample_rate=48000, _def_span=13)
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), scope)
taps = scope['c4fm_taps']().generate()
raw = (root / 'fixtures/p25-1011/call.bin').read_bytes()
dibits = np.array([(v >> shift) & 3 for v in raw for shift in (6,4,2,0)], dtype=np.uint8)
# Same symbol map and interpolating FIR structure as OP25's modulator.
impulses = np.zeros(len(dibits)*10)
impulses[::10] = np.array([1,3,-1,-3])[dibits]
wave48 = signal.fftconvolve(impulses, taps, mode='full') * 60000
wave8 = signal.resample_poly(wave48, 1, 6)
results = []
for name, samples in [('clean', wave8), ('inverted_gain_dc', -0.7*wave8+350)]:
    details, decoded = search(samples)
    path = out / (name+'.dibits')
    decoded.tofile(path)
    replay = subprocess.run([str(root/'build/p25-rx/replay.exe'), str(path),
                             str(out/(name+'.s16le'))], text=True, capture_output=True, check=True)
    counts = dict(item.split('=') for item in replay.stdout.split() if '=' in item)
    ok = counts.get('frames') == '58' and counts.get('voice_frames') == '504' and counts.get('corrected_voice_bits') == '0'
    # Compare actual decoded PCM to the independent fixture reference as well.
    reference = root/'build/p25-rx/reference.s16le'
    pcm_equal = reference.exists() and (out/(name+'.s16le')).read_bytes() == reference.read_bytes()
    results.append(dict(case=name, passed=ok and pcm_equal, search=details,
                        replay=counts, reference_pcm_equal=pcm_equal))
    print(name, replay.stdout.strip(), 'PCM equal:', pcm_equal, flush=True)
report = dict(op25_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
              fixture_sha256=hashlib.sha256(raw).hexdigest(), results=results,
              limitation='Ideal OP25-filtered 4800-symbol/s waveform, anti-aliased to 8 kHz; no analog radio model, clock drift or noise. Not a general demodulator validation.')
(out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
assert all(r['passed'] for r in results), 'Positive control failed; inspect report before interpreting hardware captures'
