// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_monitor.h"
#include <assert.h>
static p25_monitor m;
// Deterministic single-core scheduling model, not a hardware timing claim.
// 32-ms input blocks, 19-ms demod work, a 45-ms nine-frame codec burst,
// and a separately scheduled 4-ms speaker chunk. Check sustained backlog,
// exact sample order and end-of-call drain over 48 seconds of input.
static void scheduled_stream(void) {
    uint8_t ram[1024]={0},raw[512];int16_t pcm[160];
    unsigned received=0,processed=0,produced=0,consumed=0,due=0,voices=0;
    bool busy=false;
    mon_init(&m);
    for(unsigned ms=0;ms<50000;++ms) {
        if(ms && ms%32==0 && received<1500) {
            assert(mon_raw_push(&m,ram,(received&1)+1,ms*1000));++received;
        }
        if(busy && ms==due) {
            for(unsigned f=0;f<voices;++f) {
                for(unsigned i=0;i<160;++i)pcm[i]=(int16_t)(produced*160+i);
                assert(mon_pcm_push(&m,pcm));++produced;
            }
            busy=false;
        }
        if(!busy && mon_raw_pop(&m,raw)) {
            voices=((processed+1)*256/1440-processed*256/1440)*9;
            ++processed;due=ms+19+(voices ? 45 : 0);busy=true;
        }
        if(processed==1500 && !busy)m.ending=true;
        if(ms%4==0) {
            const int16_t *chunk=mon_pcm_peek(&m);
            if(chunk) {
                for(unsigned i=0;i<32;++i)assert(chunk[i]==(int16_t)(consumed+i));
                consumed+=32;mon_pcm_commit(&m);
            }
        }
    }
    assert(produced==2394 && consumed==produced*160 && m.played==produced);
    assert(!m.starved && !m.raw_overflow && !m.pcm_overflow && !m.gaps);
}
#if DM32_LAB_DIAGNOSTICS
static void trace_wrap(void) {
    mon_init(&m);assert(!pcm_trace_kept(&m.trace) && !m.trace.from_hdu);
    uint32_t expected=2166136261u;
    for(unsigned f=0;f<600;++f) {
        int16_t samples[160];uint8_t bits[11];memset(bits,f,11);
        for(unsigned i=0;i<160;++i) {
            samples[i]=(int16_t)(f*160+i);
            uint16_t x=(uint16_t)samples[i];
            expected=(expected^(x&255u))*16777619u;expected=(expected^(x>>8))*16777619u;
        }
        pcm_trace_record(&m.trace,bits,samples);
    }
    assert(m.trace.frames==600 && pcm_trace_kept(&m.trace)==PCM_TRACE_FRAMES && m.trace.hash==expected);
    for(unsigned f=600-PCM_TRACE_FRAMES;f<600;++f)
        for(unsigned i=0;i<160;++i)assert(m.trace.pcm[f%PCM_TRACE_FRAMES][i]==(int16_t)(f*160+i));
    for(unsigned f=0;f<PCM_TRACE_PAYLOADS;++f)assert(m.trace.payload[f][0]==(uint8_t)f);
    pcm_trace_init(&m.trace,true);assert(!pcm_trace_kept(&m.trace) && m.trace.from_hdu && m.trace.hash==2166136261u);
}
#endif
int main(void) {
#if DM32_LAB_DIAGNOSTICS
    trace_wrap();
#endif
    uint8_t ram[1024],out[512];int16_t pcm[160];
    for(unsigned i=0;i<1024;++i)ram[i]=(uint8_t)i;
    mon_init(&m);
    uint32_t now=0xffff0000u;
    for(unsigned round=0;round<50;++round) {
        for(unsigned i=0;i<15;++i) {now+=32000;assert(mon_raw_push(&m,ram,(m.raw_blocks&1)+1,now));}
        for(unsigned i=0;i<15;++i)assert(mon_raw_pop(&m,out));
        assert(!mon_raw_pop(&m,out));
    }
    assert(!m.gaps && !m.raw_overflow && m.raw_high==15);
    assert(!mon_raw_push(&m,ram,m.last_half,now+32000) && m.gaps==1);
    mon_init(&m);
    for(unsigned f=0;f<18;++f) {
        for(unsigned i=0;i<160;++i)pcm[i]=(int16_t)(f*160+i);
        assert(mon_pcm_push(&m,pcm));if(f<17)assert(!mon_pcm_peek(&m));
    }
    for(unsigned i=0;i<18*160;i+=32) {
        const int16_t *a=mon_pcm_peek(&m);assert(a);
        assert(mon_pcm_peek(&m)==a); // full FIFO retry does not consume
        for(unsigned j=0;j<32;++j)assert(a[j]==(int16_t)(i+j));
        mon_pcm_commit(&m);
    }
    assert(!mon_pcm_peek(&m) && m.starved==1 && m.played==18);
    assert(!mon_pcm_peek(&m) && m.starved==1);
    assert(mon_pcm_push(&m,pcm));assert(!mon_pcm_peek(&m));m.ending=true;
    assert(mon_pcm_peek(&m));for(unsigned i=0;i<5;++i)mon_pcm_commit(&m);
    assert(!mon_pcm_peek(&m) && m.starved==1);
    mon_init(&m);
    for(unsigned i=0;i<47;++i)assert(mon_pcm_push(&m,pcm));
    assert(!mon_pcm_push(&m,pcm) && m.pcm_overflow==1);
    scheduled_stream();
}
