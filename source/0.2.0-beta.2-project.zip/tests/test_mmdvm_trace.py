"""Exercise pre-FEC trace preservation and strict rejection of damaged evidence."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("mmdvm_trace", ROOT / "scripts/analyze-mmdvm-p25.py")
trace = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(trace)


def log(message, timestamp="2026-11-02 03:04:05.123", prefix="D"):
    return f"{prefix}: {timestamp} {message}\n"


def rf_data(duid=5, length=216):
    data = bytearray((i * 37 + 11) & 255 for i in range(length))
    data[:8] = bytes.fromhex("5575f5ff77ff2930")
    data[7] |= duid
    return bytes(data)


def serial_frame(label="LDU", flag=1, duid=5, rssi=None):
    if label == "Lost":
        return bytes.fromhex("e00332")
    data = rf_data(duid, 216 if label == "LDU" else 99)
    payload = bytes((flag,)) + data
    if rssi is not None:
        payload += rssi.to_bytes(2, "big")
    return bytes((0xE0, len(payload) + 3, trace.TYPES[label])) + payload


def dump(raw, label="LDU", ascii_column=True):
    rows = [log(f"RX P25 {label}")]
    for offset in range(0, len(raw), 16):
        part = raw[offset:offset + 16]
        body = f"{offset:04X}:  " + " ".join(f"{v:02X}" for v in part)
        if ascii_column:
            body = body.ljust(57) + "   *" + "." * len(part) + "*"
        rows.append(log(body))
    return "".join(rows)


class TraceTests(unittest.TestCase):
    def test_observed_host_loss_wording_without_literal_rf(self):
        body = "P25, transmission lost from N0CALL to TG 10, 5.4 seconds, BER: 3.5%"
        result = trace.parse_trace(log(body, prefix="M"))
        self.assertEqual(result["summary"]["event_counts"], {"rf_lost": 1})
        for other in (body.replace("P25,", "DMR,"), body.replace("BER:", "missing:"),
                      "P25, transmission lost"):
            self.assertIsNone(trace.event_kind(other))
        self.assertEqual(trace.event_kind(body.replace("transmission lost", "network transmission lost")),
                         ("network", "lost"))

    def test_complete_trace_with_corrections_and_events(self):
        first, second = serial_frame(), serial_frame(duid=10, flag=0, rssi=0x8123)
        text = log("P25, received RF voice transmission from N0CALL to TG 10", prefix="M")
        text += dump(serial_frame("Header", duid=0), "Header")
        text += dump(first) + log("P25, LDU1 audio, errs: 17/1233 (1.4%)")
        text += dump(second) + log("P25, LDU2 audio, errs: 0/1233 (0.0%)")
        text += dump(serial_frame("Lost"), "Lost")
        text += log("P25, RF transmission lost, 0.5 seconds, BER: 1.4%", prefix="M")
        text += log("P25, received network transmission from N0CALL to TG 10", prefix="M")
        text += log("P25, network end of transmission from N0CALL to TG 10, 0.5 seconds, 0% packet loss", prefix="M")
        parsed = trace.parse_trace(text, expected_calls=1)
        self.assertEqual(parsed["frames"][1]["serial_hex"], first.hex())
        self.assertEqual(parsed["frames"][2]["ldu_hex"], rf_data(10).hex())
        self.assertEqual(parsed["frames"][2]["rssi_raw"], 0x8123)
        self.assertEqual(parsed["frames"][2]["sync_flag"], 0)
        self.assertEqual(parsed["frames"][1]["raw_nac_hex"], "293")
        self.assertEqual(parsed["summary"]["host_corrected_bits"], 17)
        self.assertEqual(parsed["summary"]["host_protected_voice_bits"], 2466)
        self.assertEqual(parsed["summary"]["event_counts"], {"rf_start": 1, "rf_lost": 1, "network_start": 1, "network_end": 1})
        self.assertTrue(parsed["summary"]["expected_acquisition_count_matched"])
        self.assertEqual([c["candidate_frame_index"] for c in parsed["corrections"]], [1, 2])

    def test_ascii_optional_and_journal_prefix(self):
        text = dump(serial_frame(), ascii_column=False)
        text = "".join("Nov 02 pi-star MMDVMHost[120]: " + line for line in text.splitlines(keepends=True))
        self.assertEqual(len(trace.parse_trace(text)["frames"]), 1)

    def test_lost_only_and_unknown_flag_preserved(self):
        parsed = trace.parse_trace(dump(serial_frame(flag=0x81)) + dump(serial_frame("Lost"), "Lost"))
        self.assertEqual(parsed["frames"][0]["sync_flag"], 0x81)
        self.assertEqual(parsed["summary"]["serial_counts"], {"LDU": 1, "Lost": 1})

    def test_header_control_lengths(self):
        for length in (18, 45, 54, 99):
            raw = bytes((0xE0, length + 4, 0x30, 1)) + rf_data(3, length)
            self.assertEqual(trace.parse_trace(dump(raw, "Header"))["frames"][0]["rf_length"], length)

    def test_reference_excludes_sync_and_reports_true_rf_positions(self):
        raw = bytearray(serial_frame())
        raw[4] ^= 0x80  # Sync may be rewritten by the modem.
        raw[4 + 100] ^= 0xA0
        parsed = trace.parse_trace(dump(raw), {5: rf_data()})
        comparison = parsed["frames"][0]["known_reference"]
        self.assertEqual(comparison["compared_bits"], 1680)
        self.assertEqual(comparison["rf_bit_positions_msb_first"], [800, 802])
        self.assertEqual(comparison["bit_errors"], 2)
        self.assertNotIn("known_reference", trace.parse_trace(dump(serial_frame()))["frames"][0])

    def test_unknown_duid_not_forced_to_reference(self):
        parsed = trace.parse_trace(dump(serial_frame(duid=4)), {5: rf_data()})
        self.assertNotIn("known_reference", parsed["frames"][0])

    def test_corrections_without_trace_are_explicitly_unassociated(self):
        parsed = trace.parse_trace(log("P25, LDU1 audio, errs: 1/1233 (0.1%)"), expected_calls=1)
        self.assertEqual(parsed["summary"]["status"], "no_trace_frames")
        self.assertEqual(parsed["summary"]["unassociated_correction_records"], 1)
        self.assertTrue(parsed["summary"]["no_acquisition_observed"])
        self.assertFalse(parsed["summary"]["expected_acquisition_count_matched"])

    def test_incomplete_dump_at_eof(self):
        with self.assertRaisesRegex(trace.TraceError, "incomplete"):
            trace.parse_trace("\n".join(dump(serial_frame()).splitlines()[:-1]))

    def test_heading_without_rows_or_timestamp_rejected(self):
        for text in (log("RX P25 LDU"), "RX P25 LDU\n"):
            with self.assertRaises(trace.TraceError):
                trace.parse_trace(text)

    def test_interrupted_dump_rejected(self):
        rows = dump(serial_frame()).splitlines(keepends=True)
        rows.insert(3, log("P25, received RF voice transmission from N0CALL to TG 10"))
        with self.assertRaisesRegex(trace.TraceError, "incomplete"):
            trace.parse_trace("".join(rows))

    def test_offsets_gap_duplicate_and_nonzero_start_rejected(self):
        original = dump(serial_frame())
        for old, new in (("0010:", "0020:"), ("0010:", "0000:"), ("0000:", "0010:")):
            with self.subTest(new=new), self.assertRaisesRegex(trace.TraceError, "non-contiguous"):
                trace.parse_trace(original.replace(old, new, 1))

    def test_bad_envelopes_sizes_and_type_rejected(self):
        good = serial_frame()
        bad_frames = [bytes((0xE1,)) + good[1:], good[:2] + bytes((0x30,)) + good[3:],
                      good[:1] + bytes((0,)) + good[2:],
                      bytes((0xE0, 219, 0x31)) + good[3:-1],
                      bytes((0xE0, 221, 0x31)) + good[3:] + b"\x00",
                      bytes((0xE0, 4, 0x32, 0))]
        for raw in bad_frames:
            with self.subTest(raw=raw[:4]), self.assertRaises(trace.TraceError):
                trace.parse_trace(dump(raw, "Lost" if raw[2] == 0x32 else "LDU"))

    def test_declared_length_too_small_or_large_rejected(self):
        good = bytearray(serial_frame())
        for size in (len(good) - 1, len(good) + 1):
            good[1] = size
            with self.assertRaises(trace.TraceError):
                trace.parse_trace(dump(good))

    def test_extra_row_rejected(self):
        with self.assertRaisesRegex(trace.TraceError, "extra row"):
            trace.parse_trace(dump(serial_frame()) + log("00E0:  00"))

    def test_malformed_hex_and_short_nonfinal_row_rejected(self):
        text = dump(serial_frame())
        for damaged in (text.replace("E0 DC", "XX DC", 1), text.replace("E0 DC", "E0", 1)):
            with self.assertRaises(trace.TraceError):
                trace.parse_trace(damaged)

    def test_invalid_correction_denominator_or_count_rejected(self):
        for value in ("1/1232", "1234/1233", "x/1233"):
            with self.assertRaises(trace.TraceError):
                trace.parse_trace(log(f"P25, LDU1 audio, errs: {value} (0.1%)"))

    def test_cli_preserves_binary_order_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output, binary = root / "input.log", root / "parsed.json", root / "ldus.bin"
            source.write_text(dump(serial_frame()) + dump(serial_frame(duid=10)), encoding="utf-8")
            argv = [str(source), "--output", str(output), "--ldu-output", str(binary)]
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(trace.main(argv), 0)
                self.assertEqual(trace.main(argv), 2)
            self.assertEqual(binary.read_bytes(), rf_data() + rf_data(10))
            self.assertEqual(json.loads(output.read_text())["ldu_output"]["length"], 432)

    def test_invalid_trace_creates_no_outputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output, binary = root / "input.log", root / "parsed.json", root / "ldus.bin"
            source.write_text(log("RX P25 LDU"), encoding="utf-8")
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(trace.main([str(source), "--output", str(output), "--ldu-output", str(binary)]), 2)
            self.assertFalse(output.exists())
            self.assertFalse(binary.exists())

    def test_cli_empty_requires_explicit_opt_in(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "idle.log", Path(directory) / "parsed.json"
            source.write_text(log("P25, enabled"), encoding="utf-8")
            argv = [str(source), "--output", str(output), "--expected-calls", "1"]
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(trace.main(argv), 2)
                self.assertEqual(trace.main(argv + ["--allow-empty"]), 0)
            self.assertFalse(json.loads(output.read_text())["summary"]["expected_acquisition_count_matched"])

    def test_cli_output_cannot_destroy_input_or_other_artifact(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "input.log", Path(directory) / "parsed.json"
            original = dump(serial_frame())
            source.write_text(original, encoding="utf-8")
            for argv in ([str(source), "--output", str(source)],
                         [str(source), "--output", str(output), "--ldu-output", str(source)],
                         [str(source), "--output", str(output), "--ldu-output", str(output)]):
                with contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(trace.main(argv), 2)
            self.assertEqual(source.read_text(), original)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
