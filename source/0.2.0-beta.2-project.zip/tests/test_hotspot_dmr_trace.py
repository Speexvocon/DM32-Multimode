"""Offline DMR adaptation checks; no systemd, serial or network operations."""
import configparser
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("dmr_trace", ROOT / "scripts/hotspot-dmr-trace-session.py")
dmr = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(dmr)
CONFIG = """[General]
Callsign=N0CALL
Id=1234567
Duplex=0
Daemon=1
[Modem]
Protocol=uart
UARTPort=/dev/ttyACM0
UARTSpeed=115200
RXOffset=-123
TXOffset=250
RXLevel=50
DMRTXLevel=50
RFLevel=100
[Info]
RXFrequency=145700000
TXFrequency=145700000
[P25]
Enable=1
NAC=293
[DMR]
Enable=1
ColorCode=1
SelfOnly=1
Beacons=1
[DMR Network]
Enable=1
Password=private-secret
[DMR Network 1]
Enable=1
[P25 Network]
Enable=1
[CW Id]
Enable=1
[Remote Control]
Enable=1
[Future Mode]
Enable=1
"""


class DMRTraceTests(unittest.TestCase):
    def test_only_dmr_no_networks_or_beacons_preserves_modem(self):
        text, profile = dmr.transform_config(CONFIG, Path("/tmp/dmr-private"))
        cfg = configparser.ConfigParser(interpolation=None)
        cfg.read_string(text)
        self.assertEqual(cfg["DMR"]["Enable"], "1")
        for section in ("P25", "DMR Network", "DMR Network 1", "P25 Network", "CW Id", "Remote Control", "Future Mode"):
            self.assertEqual(cfg[section]["Enable"], "0")
        self.assertEqual(cfg["DMR"]["Beacons"], "0")
        self.assertEqual(cfg["DMR"]["SelfOnly"], "1")
        self.assertEqual(cfg["Modem"]["UARTPort"], "/dev/ttyACM0")
        self.assertEqual(cfg["Modem"]["DMRTXLevel"], "50")
        self.assertEqual(cfg["Modem"]["RXOffset"], "-123")
        self.assertEqual(cfg["Modem"]["TXOffset"], "250")
        self.assertEqual(cfg["Modem"]["Trace"], "1")
        self.assertEqual(cfg["General"]["Daemon"], "0")
        self.assertNotIn("Password", repr(profile))
        self.assertEqual(profile["DMR"]["ColorCode"], "1")

    def test_refuses_duplex_or_bad_metadata(self):
        for bad in (CONFIG.replace("Duplex=0", "Duplex=1"), CONFIG.replace("ColorCode=1", "ColorCode=16"),
                    CONFIG.replace("Id=1234567", "Id=0"), CONFIG.replace("SelfOnly=1", "SelfOnly=1\nselfonly=0")):
            with self.subTest(bad=bad[-40:]), self.assertRaises(ValueError):
                dmr.transform_config(bad, Path("/tmp/private"))

    def test_default_prepares_only_and_bounded_ten_minute_window(self):
        self.assertIsNone(dmr.ENGINE.options(["--output", "/tmp/new"]).capture)
        self.assertEqual(dmr.ENGINE.options(["--output", "/tmp/new", "--capture", "600", "--stop-after-call"]).capture, 600)

    def test_completion_requires_matching_rf_slot_and_identity(self):
        line = lambda body: "M: 2026-11-04 23:56:00.123 " + body
        start = "DMR Slot 2, received RF voice header from N0CALL to TG 9"
        end = "DMR Slot 2, received RF end of voice transmission from N0CALL to TG 9, 3.0 seconds, BER: 0.1%"
        s = dmr.RFCallCompletion()
        self.assertIsNone(s.feed(line(end)))
        self.assertEqual(s.feed(line(start)), "start")
        self.assertIsNone(s.feed(line(end.replace("Slot 2", "Slot 1"))))
        self.assertIsNone(s.feed(line(end.replace("TG 9", "TG 10"))))
        self.assertEqual(s.feed(line(end + ", RSSI: -80/-90/-100 dBm")), "end")
        self.assertEqual(s.termination, "end")

    def test_network_data_late_entry_and_ambiguous_headers_do_not_finish(self):
        prefix = "M: 2026-11-04 23:56:00.123 "
        s = dmr.RFCallCompletion()
        for body in ("DMR Slot 2, received network voice header from A to TG 9",
                     "DMR Slot 2, received RF late entry from A to TG 9",
                     "DMR Slot 2, received RF data header from A to TG 9"):
            self.assertIsNone(s.feed(prefix + body))
        self.assertIsNone(s.identity)
        self.assertEqual(s.feed(prefix + "DMR Slot 2, received RF voice header from A to TG 9"), "start")
        s.feed(prefix + "DMR Slot 2, received RF voice header from B to TG 9")
        self.assertTrue(s.ambiguous_start)
        self.assertIsNone(s.feed(prefix + "DMR Slot 2, received RF end of voice transmission from A to TG 9, 3.0 seconds, BER: 0.0%"))

    def test_explicit_loss_is_retained_as_loss(self):
        s = dmr.RFCallCompletion()
        prefix = "M: 2026-11-04 23:56:00.123 "
        s.feed(prefix + "DMR Slot 2, received RF voice header from A to TG 9")
        self.assertEqual(s.feed(prefix + "DMR Slot 2, RF voice transmission lost from A to TG 9, 1.0 seconds, BER: 3.0%"), "lost")

    def test_shared_capture_loop_stops_after_dmr_terminal_and_linger(self):
        class Clock:
            now = 0.0
            def monotonic(self): return self.now
            def time(self): return self.now
            def sleep(self, seconds): self.now += seconds
        class Child:
            def poll(self): return None
        prefix = "M: 2026-11-04 23:56:00.123 "
        for message, expected in (("received RF end of voice transmission", "end"), ("RF voice transmission lost", "lost")):
            with self.subTest(expected=expected), tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / "host.log"
                path.write_text(prefix + "DMR Slot 2, received RF voice header from A to TG 9\n"
                                + prefix + f"DMR Slot 2, {message} from A to TG 9, 3.0 seconds, BER: 0.1%\n")
                clock = Clock()
                with mock.patch.object(dmr.ENGINE, "RFCallCompletion", dmr.RFCallCompletion), \
                        mock.patch.object(dmr.ENGINE, "time", clock):
                    result = dmr.ENGINE.capture_until_call(Child(), path, 600)
                self.assertEqual(result["rf_call_termination"], expected)
                self.assertTrue(result["stop_after_call_satisfied"])
                self.assertFalse(result["duration_limit_reached"])
                self.assertGreaterEqual(clock.now, dmr.ENGINE.CALL_FLUSH_SECONDS)
                self.assertLess(clock.now, 2)

    def test_existing_cleanup_restores_active_set_after_failure(self):
        engine = dmr.ENGINE
        class Fake:
            def __init__(self):
                self.state = {u: u.endswith(".service") for u in engine.UNITS}
                self.original = self.state.copy()
            def active(self, unit): return self.state[unit]
            def service(self, action, unit): self.state[unit] = action == "start"
            def manual_hosts(self): return []
            def run_host(self, *args, **kwargs): raise OSError("offline injected failure")
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "original.ini"
            source.write_text(CONFIG)
            system = Fake()
            report = {"original_config_sha256": engine.digest(source)}
            with self.assertRaises(OSError):
                engine.execute_capture(system, "/fake", "/fake-config", source, Path(temporary), 10, report)
            self.assertEqual(system.state, system.original)
            self.assertTrue(report["services_restored"])
            self.assertTrue(report["original_config_unchanged"])


if __name__ == "__main__":
    unittest.main()
