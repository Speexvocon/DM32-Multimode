"""Reproduce bounded RF qualification calls from the pinned OP25 encoder.

These negative controls intentionally retain the known clear 1011-Hz voice bits
while labeling their control metadata encrypted or unsupported. They do not
contain encrypted voice and exercise receiver classification, not cryptography.
Damaged controls replace valid inner-code symbols beyond the outer RS radius;
the target metadata decoder must reject the exact resulting words in tests.
Late entry omits the header rather than manufacturing a different header.
No serial, network, service or RF access is performed.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIRECTORY = ROOT / 'fixtures/p25-rx-qualification'
OP25_SHA = '27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9'
TONE = 0x38928490d433c0be1b91844ff058a589d839
PAIRS = 14
MIDCALL_PAIR = 8  # One-based; seven complete clear pairs precede the damage.


def split_units(data):
    """Split complete packed wire units without interpreting their metadata."""
    units = []
    offset = 0
    while offset < len(data):
        if data[offset:offset+6] != bytes.fromhex('5575f5ff77ff'):
            raise ValueError('Missing P25 frame sync')
        duid = data[offset+7] & 15
        size = {0: 99, 3: 18, 5: 216, 10: 216}.get(duid)
        if size is None or offset+size > len(data):
            raise ValueError('Unsupported or truncated P25 unit')
        units.append((duid, data[offset:offset+size]))
        offset += size
    return units


def metadata_positions(duid, symbol):
    """MSB-first wire bits, including status dibits, from OP25 interleaving."""
    count = 18 if duid == 0 else 10
    start = 112+18*symbol if duid == 0 else 400+(symbol//4)*184+(symbol%4)*10
    return [bit+2*(bit//70) for bit in range(start, start+count)]


def damage_metadata(frame, duid, craft):
    """Replace t+1 leading RS symbols with other valid inner codewords.

    All-zero metadata would be a valid linear-code word and could describe an
    encrypted call. These deterministic nonzero substitutions instead produce
    the tested uncorrectable words, with voice/NID/sync/status bits unchanged.
    A word beyond radius t is not generally guaranteed to fail rather than
    miscorrect; the regression suite independently requires rejection here.
    """
    out = bytearray(frame)
    substitutions = {0: 9, 5: 7, 10: 5}[duid]
    for symbol in range(substitutions):
        positions = metadata_positions(duid, symbol)
        word = 0
        for bit in positions:
            word = (word << 1) | ((frame[bit//8] >> (7-bit%8)) & 1)
        value = (word >> (12 if duid == 0 else 4)) ^ 1
        encoded = craft.golay_18_6_8_encode(value) if duid == 0 else craft.hamming_10_6_3_encode(value)
        for shift, bit in enumerate(positions):
            mask = 1 << (7-bit%8)
            out[bit//8] = (out[bit//8] & ~mask) | (((encoded >> (len(positions)-1-shift)) & 1)*mask)
    return bytes(out)


def generate():
    spec = importlib.util.spec_from_file_location('channel_reference', ROOT/'scripts/generate-p25-channel.py')
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    if hashlib.sha256(generator.CRAFT.read_bytes()).hexdigest() != OP25_SHA:
        raise ValueError('OP25 reference hash changed')
    craft = generator.reference()
    output = []
    craft.print_spec = lambda dibits: output.append(bytes(
        sum(dibits[i+j] << (6-2*j) for j in range(4)) for i in range(0, len(dibits), 4)))

    def unit(function, *args):
        output.clear()
        function(*args)
        if len(output) != 1:
            raise ValueError('OP25 encoder did not emit one complete unit')
        return output[0]

    hdu = unit(craft.construct_hdu, 0x293, 0, 0, 0, 0x80, 0, 1)
    lc = unit(craft.construct_ldu1, 0x293, 0, TONE, 0, 0, 0, 0, 0, 1, 0, 1)
    ess = unit(craft.construct_ldu2, 0x293, 0, TONE, 0, 0, 0x80, 0)
    tdu = unit(craft.construct_stdu, 0x293, 0)
    if [len(x) for x in (hdu, lc, ess, tdu)] != [99, 216, 216, 18]:
        raise ValueError('Unexpected reference frame lengths')
    original = (ROOT/'fixtures/p25-1011/call.bin').read_bytes()
    if hdu + lc + ess + tdu != original[:531] + original[-18:]:
        raise ValueError('Independent clear reference differs from the pinned tone call')

    mi, algid, keyid = 0x123456789abcdef012, 0x84, 0x4321
    encrypted_hdu = unit(craft.construct_hdu, 0x293, 0, mi, 0, algid, keyid, 1)
    encrypted_ess = unit(craft.construct_ldu2, 0x293, 0, TONE, 0, mi, algid, keyid)
    # p25craft's public LC builder supports only opcodes 0/3. Supply the exact
    # 72-bit opcode-7 LC word, then let its independent RS/Hamming/interleaving
    # encoder construct the entire wire LDU, as in test_p25_call.py.
    previous = craft.construct_lc
    craft.construct_lc = lambda *args: (7 << 64) | (1 << 24) | 1
    try:
        unsupported_lc = unit(craft.construct_ldu1, 0x293, 0, TONE, 0, 0, 0, 0, 0, 1, 0, 1)
    finally:
        craft.construct_lc = previous

    clear_units = [hdu] + [unit for _ in range(PAIRS) for unit in (lc, ess)] + [tdu]
    damaged_lc = list(clear_units)
    damaged_lc[1+2*(MIDCALL_PAIR-1)] = damage_metadata(lc, 5, craft)
    damaged_ess = list(clear_units)
    damaged_ess[2+2*(MIDCALL_PAIR-1)] = damage_metadata(ess, 10, craft)
    return {
        'encrypted-hdu': encrypted_hdu + (lc + encrypted_ess) * PAIRS + tdu,
        'unsupported-lc': hdu + (unsupported_lc + ess) * PAIRS + tdu,
        'damaged-hdu': damage_metadata(hdu, 0, craft) + (lc + ess) * PAIRS + tdu,
        'damaged-lc': b''.join(damaged_lc),
        'damaged-ess': b''.join(damaged_ess),
        'late-entry': (lc + ess) * PAIRS + tdu,
    }


def expected_timeline(name, data):
    """Explicit expected policy boundary, independently specified by unit.

    LDU2 ESS authorizes the *next* pair: recovering clear ESS cannot authorize
    that LDU2's own voice. Counts describe the synchronous host receiver;
    hardware PCM still queued at a bad boundary may additionally be discarded.
    """
    result = []
    for index, (duid, _) in enumerate(split_units(data)):
        voice = duid in (5, 10)
        valid = None if duid == 3 else True
        state = 'WAIT_METADATA' if duid in (0, 3) else 'CLEAR'
        if name == 'encrypted-hdu':
            state, voice = ('WAIT_METADATA', False) if duid == 3 else ('ENCRYPTED', False)
        elif name == 'unsupported-lc':
            if duid in (5, 10):
                state, voice = 'UNSUPPORTED', False
        elif name == 'damaged-hdu':
            if index == 0:
                state, valid = 'BAD_METADATA', False
            elif index == 1:
                state, voice = 'BAD_METADATA', False
            elif index == 2:
                voice = False
        elif name == 'damaged-lc':
            if index in (15, 16):
                state, voice = 'BAD_METADATA', False
            if index == 15:
                valid = False
        elif name == 'damaged-ess':
            if index in (16, 17):
                state, voice = 'BAD_METADATA', False
            if index == 18:
                voice = False
            if index == 16:
                valid = False
        elif name == 'late-entry':
            if index == 0:
                state, voice = 'WAIT_METADATA', False
            elif index == 1:
                voice = False
        else:
            raise ValueError('Unknown qualification case: '+name)
        result.append({'unit': index, 'duid': duid, 'metadata_valid': valid,
                       'receive_class': state, 'voice_frames': 9 if voice else 0})
    return result


def manifest(calls):
    original = (ROOT/'fixtures/p25-1011/call.bin').read_bytes()
    source_units = split_units(original)
    clear = b''.join(frame for _, frame in source_units[:29])+source_units[-1][1]
    baseline = split_units(clear)
    cases = {}
    for name, data in calls.items():
        units = split_units(data)
        aligned = baseline[1:] if name == 'late-entry' else baseline
        changes = []
        for index, ((duid, before), (actual_duid, after)) in enumerate(zip(aligned, units)):
            if duid != actual_duid or len(before) != len(after):
                raise ValueError('Qualification unit layout changed')
            bits = [bit for byte, (a, b) in enumerate(zip(before, after))
                    for bit in range(8*byte, 8*byte+8) if (a ^ b) & (0x80 >> (bit%8))]
            if bits:
                changes.append({'unit': index, 'duid': duid,
                                'wire_bits_msb_first': bits})
        timeline = expected_timeline(name, data)
        cases[name] = {
            'file': name+'.bin', 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'units': len(units), 'voice_frames_on_air': 252,
            'omitted_units': [{'baseline_unit': 0, 'duid': 0}] if name == 'late-entry' else [],
            'metadata_changes': changes,
            'expected': {
                'voice_frames': sum(unit['voice_frames'] for unit in timeline),
                'codec_calls': sum(unit['voice_frames'] for unit in timeline),
                'metadata_bad': sum(unit['metadata_valid'] is False for unit in timeline),
                'voice_repeated': 0, 'voice_muted': 0,
                'timeline': timeline,
            },
        }
    return {
        'schema': 2, 'kind': 'p25-rx-qualification', 'generator': 'tests/generate_hotspot_fixtures.py',
        'op25_source_sha256': OP25_SHA, 'nac': '293', 'tg': 1, 'source': 1,
        'pairs': PAIRS, 'voice_frames': 252, 'voice_s': 5.04,
        'voice_payload': 'Known clear 1011-Hz IMBE bits; deliberately labeled, not ciphertext',
        'damage': 'Valid inner-codeword substitutions in the first t+1 RS symbols: HDU 9, LC 7, ESS 5; xor 1 per six-bit symbol',
        'midcall_damage_pair_one_based': MIDCALL_PAIR,
        'timeline_limit': 'Synchronous host receiver; queued hardware audio may additionally be discarded at a bad-metadata boundary. No RF timing or BER claim.',
        'cases': cases,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true', help='Write reproducible fixture files; default checks only')
    args = parser.parse_args()
    calls = generate()
    files = {name + '.bin': data for name, data in calls.items()}
    files['manifest.json'] = (json.dumps(manifest(calls), indent=2) + '\n').encode()
    if args.write:
        DIRECTORY.mkdir(parents=True, exist_ok=True)
    for name, expected in files.items():
        path = DIRECTORY/name
        if args.write:
            path.write_bytes(expected)
        elif name == 'manifest.json':
            if json.loads(path.read_text()) != json.loads(expected):
                raise ValueError('Fixture differs from independent reference: '+name)
        elif path.read_bytes() != expected:
            raise ValueError('Fixture differs from independent reference: ' + name)
    print(json.dumps(manifest(calls), indent=2))


if __name__ == '__main__':
    main()
