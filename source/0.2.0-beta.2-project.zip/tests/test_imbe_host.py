"""No hardware: benchmark identity gate and result classification."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("bench", ROOT / "scripts/imbe-bench.py")
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)


class Port:
    def __init__(self, disabled=True):
        self.disabled, self.lines, self.writes = disabled, [], []
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def flush(self): pass
    def write(self, data):
        self.writes.append(data)
        if data == b"STATUS\n":
            self.lines.append(f"IMBE git=test running=0 frames=0 rf={'disabled' if self.disabled else 'enabled'}")
        elif data == b"RUN\n":
            self.lines.extend(["OK RUN 300 synthetic frames", "IMBE git=test running=0 frames=300 rf=disabled match=1"])
            self.lines.append("IMBE_STAGE case=0 stage=pitch frames=100 mean_us=12000 max_us=13000")
            self.lines.extend(f"IMBE_CASE index={i} frames=100 max_us=16000 mean_us=14000 over_15ms=2 over_20ms=0" for i in range(3))
        elif data == b"STOP\n": self.lines.append("OK STOP")
    def readline(self): return (self.lines.pop(0) + "\n").encode() if self.lines else b""


class HostTests(unittest.TestCase):
    def invoke(self, port, log):
        with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=lambda *a, **k: port)}), \
             patch.object(sys, "argv", ["bench", "--port", "MOCK", "--run", "--log", str(log)]):
            bench.main()
    def test_budget_is_stricter_than_deadline_and_stop_acknowledged(self):
        with tempfile.TemporaryDirectory() as folder:
            log = Path(folder) / "run.jsonl"
            port = Port()
            self.invoke(port, log)
            report = json.loads(log.with_suffix(".jsonl.summary.json").read_text())
            self.assertTrue(report["complete"] and report["payload_matches"] and report["within_20ms_deadline"])
            self.assertFalse(report["within_15ms_budget"])
            self.assertEqual(report["stages"]["0:pitch"]["mean_us"], "12000")
            self.assertEqual(port.writes, [b"STATUS\n", b"RUN\n", b"STOP\n"])
            self.assertIn("OK STOP", log.read_text())
    def test_wrong_identity_cannot_run(self):
        with tempfile.TemporaryDirectory() as folder:
            port = Port(False)
            with self.assertRaisesRegex(RuntimeError, "identity"):
                self.invoke(port, Path(folder) / "run.jsonl")
            self.assertEqual(port.writes, [b"STATUS\n"])
    def test_partial_statistics_cannot_pass(self):
        report = bench.summarize({"frames":"300", "running":"0", "rf":"disabled", "match":"1"}, {})
        self.assertFalse(report["complete"] or report["within_20ms_deadline"])


class StreamTests(unittest.TestCase):
    def test_stream_complete_and_stop(self):
        class StreamPort(Port):
            def write(self,data):
                if data==b"STREAM\n":
                    self.writes.append(data)
                    self.lines.extend(["OK STREAM 3006 synthetic frames",
                        "STREAM git=test running=0 captured=3006 encoded=3006 consumed=3006 done=1 match=1 overflow=0 underrun=0 rf=disabled",
                        "STREAM_TIMING startup_us=190000 max_latency_us=190000"])
                else:
                    super().write(data)
        with tempfile.TemporaryDirectory() as folder:
            log=Path(folder)/'stream.jsonl'; port=StreamPort()
            with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=lambda *a, **k: port)}), \
                 patch.object(sys, "argv", ["bench","--port","MOCK","--stream","--log",str(log)]):
                bench.main()
            report=json.loads(log.with_suffix('.jsonl.summary.json').read_text())
            self.assertTrue(report['queue_pass'] and report['payload_matches'])
            self.assertEqual(port.writes,[b'STATUS\n',b'STREAM\n',b'STOP\n'])

if __name__ == "__main__": unittest.main()
