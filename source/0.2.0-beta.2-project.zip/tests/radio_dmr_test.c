// SPDX-License-Identifier: GPL-3.0-or-later
// The real call/FEC/audio engines against a simulated modem and board HAL.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "radio_dmr.h"
#include "radio_dmr_metrics.h"
#include "dmr/ambe/ambeVoice.h"
#include "dmr/ambe/ambeFec.h"
#include "sim/dmr_sim_modem.h"

static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"%s:%d: %s\n",__FILE__,__LINE__,#x); exit(1); } } while (0)
static radio_dmr d;
static bool codec_ok, acquire_ok, acquire_codec_error, tune_ok, tx_ok, owned, speaker, audio_running;
static unsigned acquires, releases, txs, unkeys, resets, decodes, encodes;
static bool output_blocked;
static unsigned output_aborts, output_resumes;
static unsigned output_unkeyed;
static uint32_t clock_us,tx_cost_us,unkey_cost_us;
static radio_dmr_native_tx_diag_t native_tx;
static unsigned native_snapshots;
static bool reset_native_on_audio_stop;
static uint32_t read_clock(void *ctx) { CHECK(ctx==(void *)71);return clock_us; }
static void snapshot_native(radio_dmr_native_tx_diag_t *out,void *ctx) {
    CHECK(ctx==(void *)71);++native_snapshots;*out=native_tx;
}
void hrc_audio_pcm_output_abort(void) { output_blocked=true; ++output_aborts; output_unkeyed=unkeys; }
void hrc_audio_pcm_output_resume(void) {
    // The board must have been unkeyed after a TX gate before accepting RX.
    CHECK(!output_blocked || unkeys>output_unkeyed);
    output_blocked=false; ++output_resumes;
}
static radio_mode_t mode;
static uint32_t rx_hz, tx_hz;
static audio_block_cb_t audio_cb;
static void *audio_ctx;
static bool acquire(void *ctx) { (void)ctx; ++acquires; CHECK(!owned); if (!acquire_ok) {if(acquire_codec_error)d.error=RADIO_DMR_NO_CODEC;return false;} owned=true;return true; }
static void release(void *ctx) { (void)ctx; ++releases;CHECK(owned);CHECK(!audio_running);CHECK(mode==RADIO_MODE_FM);owned=false; }
static void set_mode(radio_mode_t value) { CHECK(owned);mode=value; }
static bool rx(uint32_t hz,radio_bw_t bw,const subtone_t *tone) { CHECK(owned && mode==RADIO_MODE_DMR);CHECK(bw==RADIO_BW_12K5 && !tone);rx_hz=hz;return tune_ok; }
static bool tx(uint32_t hz,radio_bw_t bw,uint8_t power,const subtone_t *tone) { (void)power;CHECK(owned && mode==RADIO_MODE_DMR);CHECK(bw==RADIO_BW_12K5 && !tone);CHECK(output_blocked);++txs;tx_hz=hz;clock_us+=tx_cost_us;return tx_ok; }
static void tx_off(void) { CHECK(owned);++unkeys;clock_us+=unkey_cost_us; }
static void audio(bool on) { CHECK(!on); }
static bool audio_start(audio_block_cb_t cb,void *ctx) { CHECK(owned);audio_cb=cb;audio_ctx=ctx;audio_running=true;return true; }
static void audio_stop(void) { audio_running=false;audio_cb=NULL;if(reset_native_on_audio_stop)memset(&native_tx,0,sizeof native_tx); }
static void audio_speaker(bool on) { speaker=on; }
static bool present(void) { CHECK(owned);return codec_ok; }
static void reset(void) { ++resets; }
static void encode(const int16_t pcm[160],uint8_t bits[49]) { (void)pcm;++encodes;for(unsigned i=0;i<49;i++)bits[i]=(uint8_t)((i+encodes)&1); }
static void decode(const uint8_t bits[49],int16_t pcm[160]) { (void)bits;++decodes;for(unsigned i=0;i<160;i++)pcm[i]=(int16_t)(100+i); }
static const hal_radio_t radio={.set_mode=set_mode,.rx=rx,.tx=tx,.tx_off=tx_off,.audio=audio};
static const hal_audio_t aud={.start=audio_start,.stop=audio_stop,.speaker_pcm=audio_speaker};
static const hal_vocoder_t voc={.present=present,.reset=reset,.encode=encode,.decode=decode};
static radio_dmr_hal hal(void) { return (radio_dmr_hal){.radio=&radio,.modem=&sim_modem,.audio=&aud,.vocoder=&voc,.acquire=acquire,.release=release}; }
static radio_dmr_config config(void) { return (radio_dmr_config){.rx_hz=145700000,.tx_hz=145700000,.source_id=1234567,.target_id=10,.tot_s=30,.cc=1,.ts=1,.power=0,.owner_permission=true}; }
static void setup(void) {
    radio_dmr_stop(&d);sim_reset();memset(&d,0,sizeof d);
    codec_ok=acquire_ok=tune_ok=tx_ok=true;owned=speaker=audio_running=false;
    acquire_codec_error=false;
    acquires=releases=txs=unkeys=resets=decodes=encodes=0;mode=RADIO_MODE_FM;rx_hz=tx_hz=0;audio_cb=NULL;
    output_blocked=false;output_aborts=output_resumes=output_unkeyed=0;
    clock_us=tx_cost_us=unkey_cost_us=0;memset(&native_tx,0,sizeof native_tx);
    native_snapshots=0;reset_native_on_audio_stop=false;
    radio_dmr_hal h=hal();radio_dmr_init(&d,&h);
}
static void start(void) { radio_dmr_config c=config();CHECK(radio_dmr_start(&d,&c));CHECK(d.running && owned && sim.started);CHECK(rx_hz==c.rx_hz); }
static void audio_block(void) { if(audio_running && audio_cb) {int16_t mic[160]={0},spk[160];audio_cb(mic,spk,audio_ctx);} }
static void run(unsigned from,unsigned to,bool down) {
    for(unsigned t=from;t<=to;t+=10) {if(t && t%30==0)sim_slot();radio_dmr_poll(&d,t,down,true);if(t%20==0)audio_block();}
}
static void malformed(void) {
    setup();radio_dmr_config c=config();
    for(unsigned k=0;k<9;k++) {radio_dmr_config bad=c;
        switch(k){case 0:bad.rx_hz=0;break;case 1:bad.tx_hz=520000001;break;case 2:bad.source_id=0;break;case 3:bad.target_id=0x1000000;break;case 4:bad.cc=16;break;case 5:bad.ts=0;break;case 6:bad.ts=3;break;case 7:bad.filter=(radio_dmr_filter)-1;break;default:bad.filter=(radio_dmr_filter)3;}
        CHECK(!radio_dmr_start(&d,&bad));CHECK(d.error==RADIO_DMR_BAD_CONFIG);CHECK(!acquires && !sim.started);
    }
    radio_dmr_hal h=hal();h.audio=NULL;radio_dmr_init(&d,&h);CHECK(!radio_dmr_start(&d,&c));CHECK(d.error==RADIO_DMR_NO_HAL && !acquires);
}
static void failures(void) {
    setup();radio_dmr_config c=config();acquire_ok=false;
    CHECK(!radio_dmr_start(&d,&c));CHECK(d.error==RADIO_DMR_NO_OWNERSHIP && acquires==1 && releases==0 && !txs);
    acquire_codec_error=true;CHECK(!radio_dmr_start(&d,&c));CHECK(d.error==RADIO_DMR_NO_CODEC && !releases);
    acquire_codec_error=false;
    acquire_ok=true;codec_ok=false;
    CHECK(!radio_dmr_start(&d,&c));CHECK(d.error==RADIO_DMR_NO_CODEC && releases==1 && !owned && !sim.started);
    codec_ok=true;tune_ok=false;
    CHECK(!radio_dmr_start(&d,&c));CHECK(d.error==RADIO_DMR_RX_FAILED && !owned && mode==RADIO_MODE_FM && releases==2);
    tune_ok=true;sim.refuse_start=true;
    CHECK(!radio_dmr_start(&d,&c));CHECK(d.error==RADIO_DMR_MODEM_FAILED && !owned && releases==3);
}
static void held_ptt(void) {
    setup();start();run(0,500,true);CHECK(!txs && !sim.tx_begins && !output_blocked && !output_aborts);
    radio_dmr_poll(&d,510,false,true);radio_dmr_poll(&d,520,true,true);
    CHECK(txs==1 && sim.tx_begins==1 && d.tx_armed && output_blocked && output_aborts==1);
    run(530,1200,true);CHECK(encodes>0);
    radio_dmr_stop(&d);CHECK(!owned && sim.tx_aborts==1 && !audio_running && output_blocked);
    start();CHECK(!output_blocked);radio_dmr_stop(&d);CHECK(output_blocked);
}
static void permission(void) {
    setup();start();radio_dmr_poll(&d,0,false,true);radio_dmr_poll(&d,10,true,false);
    radio_dmr_poll(&d,20,true,true);CHECK(!txs && !output_aborts && !output_blocked);
    radio_dmr_poll(&d,30,false,true);radio_dmr_poll(&d,40,true,true);CHECK(txs==1);
    radio_dmr_poll(&d,50,true,false);run(60,1500,true);
    CHECK(!d.tx_armed && txs==1); // permission return while held never restarts
    radio_dmr_poll(&d,1510,false,true);radio_dmr_poll(&d,1520,true,true);CHECK(txs==2);
    radio_dmr_stop(&d);
    setup();radio_dmr_config c=config();c.rx_only=true;CHECK(radio_dmr_start(&d,&c));run(0,500,false);run(510,1000,true);CHECK(!txs);radio_dmr_stop(&d);
}
static void normal_call(void) {
    setup();start();run(0,30,false);run(40,1000,true);
    radio_dmr_diagnostics diag;
    CHECK(radio_dmr_get_diagnostics(&d,&diag));
    CHECK(diag.result==RADIO_DMR_TX_ACTIVE && !diag.metrics_valid);
    unsigned before=unkeys;radio_dmr_poll(&d,1010,false,true);
    CHECK(d.tx_armed && unkeys==before && output_blocked); // queued voice and terminator must drain
    run(1020,2200,false);CHECK(!d.tx_armed && unkeys==before+1 && owned && d.running && !output_blocked);
    CHECK(sim.air_count>5 && sim.air[0].kind==DMR_BURST_VOICE_LC_HEADER);
    CHECK(sim.air[sim.air_count-1].kind==DMR_BURST_TERMINATOR_LC);
    CHECK(tx_hz==145700000 && radio_dmr_view(&d)->phase==DMR_CALL_PHASE_IDLE);
    CHECK(radio_dmr_get_diagnostics(&d,&diag));
    CHECK(diag.result==RADIO_DMR_TX_COMPLETE && diag.metrics_valid);
    CHECK(!diag.poll_timing_valid && !diag.native_metrics_valid && !diag.poll_cost.calls && !diag.poll_gap_max_us);
    CHECK(diag.tx_error==DMR_TX_OK && d.tx_error==DMR_TX_OK && diag.backend_error==RADIO_DMR_OK);
    CHECK(diag.calls==1 && !diag.denied && diag.start_ms==40 && diag.end_ms>1010);
    CHECK(diag.encoded_frames+diag.encoded_overflows==encodes && diag.mic_blocks==encodes);
    CHECK(diag.last_tx_phase==DMR_CALL_PHASE_TX_ENDING && diag.phase==DMR_CALL_PHASE_IDLE);
    radio_dmr_stop(&d);CHECK(releases==1 && mode==RADIO_MODE_FM);
    radio_dmr_diagnostics retained;CHECK(radio_dmr_get_diagnostics(&d,&retained));
    CHECK(!memcmp(&diag,&retained,sizeof diag));
}
static void timeout(void) {
    setup();radio_dmr_config c=config();c.tot_s=1;CHECK(radio_dmr_start(&d,&c));run(0,30,false);run(40,4000,true);
    CHECK(!d.tx_armed && txs==1 && radio_dmr_view(&d)->tx_error==DMR_TX_ERR_TIMEOUT);
    radio_dmr_diagnostics diag;CHECK(radio_dmr_get_diagnostics(&d,&diag));
    CHECK(diag.result==RADIO_DMR_TX_FAILED && d.tx_error==DMR_TX_ERR_TIMEOUT && diag.tx_error==DMR_TX_ERR_TIMEOUT);
    CHECK(diag.backend_error==RADIO_DMR_OK && d.error==RADIO_DMR_OK && diag.calls==1);
    run(4010,5000,true);CHECK(txs==1);radio_dmr_poll(&d,5010,false,true);
    CHECK(d.tx_error==DMR_TX_ERR_TIMEOUT && radio_dmr_view(&d)->phase==DMR_CALL_PHASE_IDLE);
    radio_dmr_stop(&d);CHECK(d.tx_error==DMR_TX_ERR_TIMEOUT);
}
static void tx_refused(void) {
    setup();start();tx_ok=false;radio_dmr_poll(&d,0,false,true);radio_dmr_poll(&d,10,true,true);
    CHECK(txs==1 && !sim.tx_begins && !d.tx_armed && d.error==RADIO_DMR_TX_REFUSED);
    CHECK(output_aborts==1 && output_resumes==2 && !output_blocked);
    radio_dmr_diagnostics diag;CHECK(radio_dmr_get_diagnostics(&d,&diag));
    CHECK(diag.result==RADIO_DMR_TX_FAILED && diag.backend_error==RADIO_DMR_TX_REFUSED);
    CHECK(diag.tx_error==DMR_TX_OK && !diag.calls && !diag.encoded_frames && !diag.mic_blocks);
    tx_ok=true;radio_dmr_poll(&d,20,true,true);CHECK(txs==1);radio_dmr_stop(&d);
}
static void native_failures(void) {
    setup();start();sim.refuse_tx=true;run(0,30,false);run(40,100,true);
    radio_dmr_diagnostics diag;CHECK(radio_dmr_get_diagnostics(&d,&diag));
    CHECK(!d.tx_armed && d.tx_error==DMR_TX_ERR_REJECTED && d.error==RADIO_DMR_OK);
    CHECK(diag.result==RADIO_DMR_TX_FAILED && diag.tx_error==DMR_TX_ERR_REJECTED);
    CHECK(diag.denied==1 && !diag.calls && !diag.mic_blocks);
    run(110,500,true);CHECK(txs==1);radio_dmr_poll(&d,510,false,true);
    CHECK(d.tx_error==DMR_TX_ERR_REJECTED);sim.refuse_tx=false;
    radio_dmr_poll(&d,520,true,true);CHECK(d.tx_error==DMR_TX_OK);
    CHECK(radio_dmr_get_diagnostics(&d,&diag) && diag.result==RADIO_DMR_TX_ACTIVE && !diag.metrics_valid);
    run(530,800,true);radio_dmr_stop(&d);
    CHECK(radio_dmr_get_diagnostics(&d,&diag) && diag.result==RADIO_DMR_TX_ABORTED && diag.metrics_valid);
    CHECK(diag.calls==1 && diag.encoded_frames>0 && diag.tx_error==DMR_TX_OK);

    setup();start();sim.stalled=true;run(0,30,false);run(40,2500,true);
    CHECK(!d.tx_armed && d.tx_error==DMR_TX_ERR_STALLED && d.error==RADIO_DMR_OK);
    CHECK(radio_dmr_get_diagnostics(&d,&diag) && diag.result==RADIO_DMR_TX_FAILED);
    CHECK(diag.tx_error==DMR_TX_ERR_STALLED && diag.calls==1 && diag.encoded_overflows>0);
    CHECK(diag.mic_blocks==encodes && diag.encoded_frames+diag.encoded_overflows==encodes);
    radio_dmr_stop(&d);CHECK(d.tx_error==DMR_TX_ERR_STALLED);
    radio_dmr_diagnostics retained;start();CHECK(d.tx_error==DMR_TX_ERR_STALLED);
    CHECK(radio_dmr_get_diagnostics(&d,&retained) && !memcmp(&diag,&retained,sizeof diag));
    radio_dmr_stop(&d);
}
static void diagnostic_baselines(void) {
    setup();start();CHECK(!radio_dmr_get_diagnostics(NULL,NULL));
    radio_dmr_diagnostics first,second;
    CHECK(!radio_dmr_get_diagnostics(NULL,&first) && !radio_dmr_get_diagnostics(&d,NULL));
    run(0,30,false);
    // Deliberately withhold microphone blocks past the three headers, then
    // resume: missing source frames must be visible independently of BER.
    for(unsigned t=40;t<=400;t+=10) {if(t%30==0)sim_slot();radio_dmr_poll(&d,t,true,true);}
    run(410,800,true);run(810,2200,false);
    CHECK(radio_dmr_get_diagnostics(&d,&first) && first.result==RADIO_DMR_TX_COMPLETE);
    CHECK(first.encoded_frames>0 && first.source_underruns>0);
    ambe_voice_stats_t voice_before,voice_after;dmr_call_stats_t call_before,call_after;
    ambeVoiceGetStats(&voice_before);dmr_call_get_stats(&call_before);
    run(2210,2500,true);
    for(unsigned i=0;i<20;i++)sim_event(DMR_EV_VOICE_LOST,1);
    run(2510,3200,true);run(3210,4500,false);
    ambeVoiceGetStats(&voice_after);dmr_call_get_stats(&call_after);
    CHECK(radio_dmr_get_diagnostics(&d,&second) && second.result==RADIO_DMR_TX_COMPLETE);
    CHECK(second.calls==1 && call_after.tx_calls==2);
    CHECK(second.encoded_frames==voice_after.tx_frames-voice_before.tx_frames);
    CHECK(second.encoded_repeats==voice_after.tx_repeats-voice_before.tx_repeats);
    CHECK(second.encoded_overflows==voice_after.tx_overflows-voice_before.tx_overflows);
    CHECK(second.source_underruns==call_after.tx_underruns-call_before.tx_underruns);
    CHECK(second.event_overflows==call_after.evq_overflows-call_before.evq_overflows && second.event_overflows>0);
    CHECK(second.mic_blocks<voice_after.tx_frames+voice_after.tx_overflows);
    radio_dmr_stop(&d);radio_dmr_diagnostics retained;CHECK(radio_dmr_get_diagnostics(&d,&retained));
    CHECK(!memcmp(&second,&retained,sizeof second));
    start();CHECK(radio_dmr_get_diagnostics(&d,&retained));
    CHECK(!memcmp(&second,&retained,sizeof second));radio_dmr_stop(&d);
    CHECK(!strcmp(radio_dmr_tx_error_name(DMR_TX_ERR_STALLED),"stalled"));
    CHECK(!strcmp(radio_dmr_tx_error_name(255),"unknown"));
    CHECK(!strcmp(radio_dmr_tx_result_name(RADIO_DMR_TX_COMPLETE),"complete"));
    CHECK(!strcmp(radio_dmr_tx_result_name((radio_dmr_tx_result)-1),"unknown"));
}
static void scan_hold(void) {
    CHECK(!radio_dmr_scan_hold(NULL));
    dmr_call_view_t v={.state=DMR_CALL_STATE_RX,.phase=DMR_CALL_PHASE_RX_BUSY};
    CHECK(!radio_dmr_scan_hold(&v));v.phase=DMR_CALL_PHASE_RX_VOICE;
    CHECK(radio_dmr_scan_hold(&v));v.caller.encrypted=true;CHECK(!radio_dmr_scan_hold(&v));
    v.caller.encrypted=false;v.state=DMR_CALL_STATE_TX;CHECK(!radio_dmr_scan_hold(&v));
    v.state=DMR_CALL_STATE_IDLE;CHECK(!radio_dmr_scan_hold(&v));
}
static void timing_diagnostics(void) {
    setup();start();d.hal.clock_us=read_clock;d.hal.ctx=(void *)71;
    tx_cost_us=37;unkey_cost_us=83;
    clock_us=1000;radio_dmr_poll(&d,0,false,true);
    CHECK(!d.diagnostics.poll_cost.calls);
    for(unsigned t=10;t<=2200;t+=10) {
        if(t%30==0)sim_slot();
        clock_us=t*1000u;
        radio_dmr_poll(&d,t,t<=800,true);if(t%20==0)audio_block();
    }
    radio_dmr_diagnostics first,retained;
    CHECK(radio_dmr_get_diagnostics(&d,&first) && first.result==RADIO_DMR_TX_COMPLETE);
    CHECK(first.poll_timing_valid && !first.native_metrics_valid);
    CHECK(first.poll_gap_max_us==10000 && first.poll_cost.max_us==83);
    CHECK(first.poll_cost.total_us==120 && !first.poll_cost.saturated);
    CHECK(first.poll_cost.calls==(first.end_ms-first.start_ms)/10u+1u);
    radio_dmr_stop(&d);clock_us=4000000000u;start();radio_dmr_poll(&d,3000,false,true);
    CHECK(radio_dmr_get_diagnostics(&d,&retained) && !memcmp(&first,&retained,sizeof first));
    clock_us=UINT32_MAX-20u;radio_dmr_poll(&d,3010,true,true);
    CHECK(d.diagnostics.poll_cost.calls==1 && d.diagnostics.poll_cost.total_us==37 && !d.diagnostics.poll_gap_max_us);
    clock_us=100;radio_dmr_poll(&d,3020,true,true);
    CHECK(d.diagnostics.poll_gap_max_us==121 && d.diagnostics.poll_cost.calls==2);
    clock_us=250100;radio_dmr_poll(&d,3030,true,true);
    CHECK(d.diagnostics.poll_gap_max_us==250000);
    radio_dmr_stop(&d);
}
static void native_diagnostics(void) {
    setup();start();d.hal.tx_diag=snapshot_native;d.hal.ctx=(void *)71;
    native_tx=(radio_dmr_native_tx_diag_t){UINT32_MAX-2u,40,50,60,70};
    radio_dmr_poll(&d,0,false,true);radio_dmr_poll(&d,10,true,true);
    CHECK(native_snapshots==1 && !d.diagnostics.native_metrics_valid);
    native_tx=(radio_dmr_native_tx_diag_t){4,42,53,64,75};
    reset_native_on_audio_stop=true;radio_dmr_stop(&d);
    radio_dmr_diagnostics first,retained;CHECK(radio_dmr_get_diagnostics(&d,&first));
    CHECK(first.result==RADIO_DMR_TX_ABORTED && first.native_metrics_valid && !first.poll_timing_valid);
    CHECK(first.native_tx_bursts==7 && first.native_tx_underruns==2 && first.native_tx_rejected==3);
    CHECK(first.native_tx_done==4 && first.native_event_overflows==5 && native_snapshots==2);
    CHECK(!native_tx.tx_bursts); // Snapshot preceded the audio/engine stop reset.
    start();radio_dmr_poll(&d,1000,false,true);radio_dmr_stop(&d);
    CHECK(radio_dmr_get_diagnostics(&d,&retained) && !memcmp(&first,&retained,sizeof first));
    start();radio_dmr_poll(&d,2000,false,true);radio_dmr_poll(&d,2010,true,true);
    native_tx=(radio_dmr_native_tx_diag_t){11,12,13,14,15};
    run(2020,2500,true);run(2510,4000,false);
    CHECK(radio_dmr_get_diagnostics(&d,&retained) && retained.result==RADIO_DMR_TX_COMPLETE);
    CHECK(retained.native_tx_bursts==11 && retained.native_tx_underruns==12 && retained.native_tx_rejected==13);
    CHECK(retained.native_tx_done==14 && retained.native_event_overflows==15);
    radio_dmr_stop(&d);
}
static void cancelled_access(void) {
    setup();start();
    dmr_call_config_t cfg;dmr_call_config_default(&cfg);cfg.own_id=1234567;
    cfg.talk_target.id=10;cfg.access_wait_ms=1000;dmr_call_configure(&cfg);
    dmr_burst_t b={.kind=DMR_BURST_VOICE_LC_HEADER,.sync=DMR_SYNC_BS,.cc=1,.ts=1,.crc_ok=true,.lc_valid=true};
    dmr_lc_t lc={.flco=DMR_FLCO_GROUP_VOICE,.src=123456,.dst=10};dmr_lc_pack(&lc,b.lc);
    sim_rx(&b);radio_dmr_poll(&d,0,false,true);radio_dmr_poll(&d,10,true,true);
    CHECK(d.tx_armed && radio_dmr_view(&d)->phase==DMR_CALL_PHASE_TX_ACCESS);
    radio_dmr_poll(&d,20,false,true);radio_dmr_diagnostics diag;
    CHECK(!d.tx_armed && radio_dmr_get_diagnostics(&d,&diag));
    CHECK(diag.result==RADIO_DMR_TX_CANCELLED && diag.tx_error==DMR_TX_OK);
    CHECK(diag.backend_error==RADIO_DMR_OK && !diag.calls && !diag.denied && !diag.mic_blocks);
    CHECK(diag.last_tx_phase==DMR_CALL_PHASE_TX_ACCESS && diag.metrics_valid);
    radio_dmr_stop(&d);
}
static void singleton(void) {
    setup();start();radio_dmr second;radio_dmr_hal h=hal();radio_dmr_init(&second,&h);radio_dmr_config c=config();
    CHECK(!radio_dmr_start(&second,&c));CHECK(second.error==RADIO_DMR_BUSY && acquires==1);
    radio_dmr_stop(&second);CHECK(owned && d.running);radio_dmr_stop(&d);
}
static void header(unsigned cc,unsigned ts,unsigned dst,unsigned svc) {
    dmr_burst_t b={.kind=DMR_BURST_VOICE_LC_HEADER,.sync=DMR_SYNC_BS,.cc=(uint8_t)cc,.ts=(int8_t)ts,.crc_ok=true,.lc_valid=true,.rssi_dbm=-65};
    dmr_lc_t lc={.flco=DMR_FLCO_GROUP_VOICE,.src=123456,.dst=dst,.svc=(uint8_t)svc};dmr_lc_pack(&lc,b.lc);sim_rx(&b);radio_dmr_poll(&d,100,false,true);
}
static void receive(void) {
    setup();start();header(1,1,10,0);CHECK(radio_dmr_view(&d)->phase==DMR_CALL_PHASE_RX_VOICE);
    dmr_burst_t b={.kind=DMR_BURST_VOICE,.sync=DMR_SYNC_BS,.cc=1,.ts=1,.voice_index=0,.len=27};
    uint8_t bits[49];for(unsigned i=0;i<49;i++)bits[i]=(uint8_t)(i&1);for(unsigned i=0;i<3;i++)ambeFecEncode(bits,&b.payload[i*9]);
    sim_rx(&b);radio_dmr_poll(&d,110,false,true);audio_block();CHECK(decodes==1 && speaker && resets>0);
    ambe_voice_stats_t st;ambeVoiceGetStats(&st);CHECK(st.rx_bad==0 && st.rx_in>=3);radio_dmr_stop(&d);
    setup();start();header(1,1,999,0);CHECK(radio_dmr_view(&d)->phase==DMR_CALL_PHASE_RX_BUSY);CHECK(!audio_running);radio_dmr_stop(&d);
    setup();start();header(2,1,10,0);CHECK(radio_dmr_view(&d)->phase==DMR_CALL_PHASE_IDLE);radio_dmr_stop(&d);
    setup();radio_dmr_config c=config();c.filter=RADIO_DMR_FILTER_PROM;CHECK(radio_dmr_start(&d,&c));CHECK(sim.cc_filter==-1);
    header(7,1,999,0);CHECK(radio_dmr_view(&d)->phase==DMR_CALL_PHASE_RX_VOICE);radio_dmr_stop(&d);
    setup();c=config();c.filter=RADIO_DMR_FILTER_PROM;CHECK(radio_dmr_start(&d,&c));header(7,2,999,0);CHECK(radio_dmr_view(&d)->phase==DMR_CALL_PHASE_IDLE);radio_dmr_stop(&d);
    setup();c=config();c.filter=RADIO_DMR_FILTER_PROM;CHECK(radio_dmr_start(&d,&c));header(7,1,999,DMR_SVC_PRIVACY);
    CHECK(radio_dmr_view(&d)->caller.encrypted);b.cc=7;sim_rx(&b);radio_dmr_poll(&d,110,false,true);audio_block();
    CHECK(!decodes);dmr_call_stats_t cs;dmr_call_get_stats(&cs);CHECK(cs.rx_enc_dropped==1);radio_dmr_stop(&d);
}
int main(int argc,char **argv) {
    CHECK(argc==2);
    if(!strcmp(argv[1],"malformed"))malformed();else if(!strcmp(argv[1],"failures"))failures();
    else if(!strcmp(argv[1],"held_ptt"))held_ptt();else if(!strcmp(argv[1],"permission"))permission();
    else if(!strcmp(argv[1],"normal_call"))normal_call();else if(!strcmp(argv[1],"timeout"))timeout();
    else if(!strcmp(argv[1],"tx_refused"))tx_refused();else if(!strcmp(argv[1],"singleton"))singleton();
    else if(!strcmp(argv[1],"receive"))receive();else if(!strcmp(argv[1],"native_failures"))native_failures();
    else if(!strcmp(argv[1],"diagnostic_baselines"))diagnostic_baselines();else if(!strcmp(argv[1],"scan_hold"))scan_hold();
    else if(!strcmp(argv[1],"cancelled_access"))cancelled_access();
    else if(!strcmp(argv[1],"timing_diagnostics"))timing_diagnostics();
    else if(!strcmp(argv[1],"native_diagnostics"))native_diagnostics();else CHECK(false);
    printf("%s: %u checks passed\n",argv[1],checks);return 0;
}
