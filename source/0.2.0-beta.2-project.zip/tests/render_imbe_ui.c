// SPDX-License-Identifier: GPL-3.0-or-later
// Render actual benchmark drawing code; any hardware/task access aborts.
#include <assert.h>
#include <stdlib.h>
#include "../src/firmware/dm32_imbe_bench.c"
const board_t board={0};
uint32_t hrc_micros(void) { abort(); }
void board_rf_safe(void) { abort(); }
void board_init(void) { abort(); }
bool imbe_bench_init(void) { abort(); }
void imbe_bench_prepare(uint32_t frame) { abort(); }
void imbe_bench_encode(uint8_t payload[11]) { abort(); }
size_t imbe_bench_state_bytes(void) { abort(); }
UBaseType_t uxTaskGetStackHighWaterMark(TaskHandle_t handle) { abort(); }
void vTaskDelete(TaskHandle_t handle) { abort(); }
void vTaskDelay(TickType_t ticks) { abort(); }
BaseType_t xTaskCreate(TaskFunction_t fn,const char *const name,configSTACK_DEPTH_TYPE depth,
    void *const arg,UBaseType_t priority,TaskHandle_t *const handle) { abort(); }
static void flush(const void *fb,const uint16_t *palette,uint16_t y0,uint16_t y1) {
    (void)fb;(void)palette;(void)y0;(void)y1;
}
int main(int argc,char **argv) {
    assert(argc==2);
    const hal_display_t panel={.width=240,.height=320,.bpp=4,.inset_left=10,.inset_right=10,
        .inset_top=5,.inset_bottom=5,.flush_indexed=flush};
    display_ok=gfx_init(&panel);assert(display_ok);
    const char *titles[]={"READY / PC RUN","ENCODING","DONE / DATA MATCH","DATA MISMATCH","STOPPED"};
    for (unsigned n=0;n<5;++n) {
        frames=n>=2 ? 300 : 0;
        screen(titles[n]);
        char path[512];snprintf(path,sizeof path,"%s/imbe-%u.ppm",argv[1],n);
        FILE *file=fopen(path,"wb");assert(file);
        fprintf(file,"P6\n240 320\n255\n");
        for (unsigned y=0;y<320;++y) {
            uint8_t row[480];gfx_read_rgb565(y*480,row,sizeof row);
            for (unsigned x=0;x<240;++x) {
                unsigned rgb=row[x*2]|(unsigned)row[x*2+1]<<8;
                fputc((int)(((rgb>>11)&31)*255/31),file);
                fputc((int)(((rgb>>5)&63)*255/63),file);
                fputc((int)((rgb&31)*255/31),file);
            }
        }
        assert(!fclose(file));
    }
    puts("Rendered five IMBE benchmark states with actual fonts/framebuffer");
}
