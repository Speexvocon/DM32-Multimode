// SPDX-License-Identifier: GPL-3.0-or-later
// Real state helper with a fake tuner; no serial, MMIO or RF access.
#include <assert.h>
#include <stdio.h>
#include "radio_broadcast.h"

static char events[128];
static unsigned event_n,volume_level,tune_khz,status_calls;
static bool power_ok,tune_ok,seek_ok,status_ok,off_ok;
static bcast_status_t input;
static void event(char c) {assert(event_n+1<sizeof events);events[event_n++]=c;events[event_n]=0;}
static bool power(bool on) {event(on ? 'P' : 'p');return on ? power_ok : off_ok;}
static bool tune(uint32_t khz) {event('T');tune_khz=khz;return tune_ok;}
static bool seek(bool up) {event(up ? 'U' : 'D');return seek_ok;}
static void volume(uint8_t level) {event('V');volume_level=level;}
static bool status(bcast_status_t *out) {event('S');++status_calls;*out=input;return status_ok;}
static void audio(bool on) {event(on ? 'A' : 'a');}
static const hal_bcast_t hal={65000,108000,50,power,tune,seek,volume,status,audio};
static void reset(void) {
    memset(events,0,sizeof events);event_n=volume_level=tune_khz=status_calls=0;
    power_ok=tune_ok=seek_ok=status_ok=off_ok=true;
    input=(bcast_status_t){.khz=87500,.tuning=true,.rssi=53};
}
static void test_start_poll_stop(void) {
    radio_broadcast b={0};reset();
    assert(radio_broadcast_start(&b,&hal,0));
    assert(!strcmp(events,"aPVT") && volume_level==15 && tune_khz==87500);
    assert(b.owned && b.running && b.busy && !b.audio_open && !b.have_status && !b.failed);
    unsigned count=event_n;assert(!radio_broadcast_start(&b,&hal,90000) && event_n==count);
    assert(!radio_broadcast_tune(&b,90000) && !radio_broadcast_seek(&b,true) && event_n==count);
    assert(radio_broadcast_poll(&b) && b.busy && !b.audio_open && b.have_status);
    input.tuning=false;input.station=input.stereo=true;
    assert(radio_broadcast_poll(&b) && !b.busy && b.audio_open && b.status.stereo && b.status.station && b.status.rssi==53);
    count=event_n;assert(radio_broadcast_poll(&b) && event_n==count+1); // No repeated audio routing.
    radio_broadcast_stop(&b);assert(!strcmp(events+event_n-2,"ap"));
    assert(!b.owned && !b.running && !b.busy && !b.audio_open && !b.have_status && !b.failed);
    count=event_n;radio_broadcast_stop(&b);assert(event_n==count && !radio_broadcast_poll(&b));
}
static void test_tune_seek_and_domain(void) {
    radio_broadcast b={0};reset();assert(radio_broadcast_start(&b,&hal,65000));
    input.khz=65000;input.tuning=false;assert(radio_broadcast_poll(&b));
    const uint32_t bad[]={0,64950,65001,108050,UINT32_MAX};
    for(unsigned i=0;i<sizeof bad/sizeof bad[0];++i) {
        unsigned count=event_n;assert(!radio_broadcast_tune(&b,bad[i]) && event_n==count);
        assert(b.running && b.audio_open && b.khz==65000);
    }
    assert(radio_broadcast_tune(&b,108000) && b.busy && !b.audio_open && !b.have_status);
    unsigned count=event_n;assert(!radio_broadcast_seek(&b,true) && event_n==count);
    input.khz=108000;input.tuning=false;assert(radio_broadcast_poll(&b));
    assert(radio_broadcast_seek(&b,false) && events[event_n-1]=='D' && b.busy && !b.audio_open);
    input.khz=107950;input.seek_failed=true;assert(radio_broadcast_poll(&b));
    assert(!b.busy && b.audio_open && b.status.seek_failed && b.khz==107950);
    assert(radio_broadcast_seek(&b,true) && events[event_n-1]=='U');radio_broadcast_stop(&b);
    count=event_n;assert(!radio_broadcast_tune(&b,87500) && !radio_broadcast_seek(&b,true) && event_n==count);
}
static void test_failures_unwind(void) {
    for(unsigned failure=0;failure<5;++failure) {
        radio_broadcast b={0};reset();
        if(failure==0)power_ok=false;
        if(failure==1)tune_ok=false;
        bool started=radio_broadcast_start(&b,&hal,87500);
        if(failure<2)assert(!started);
        else {
            assert(started);input.tuning=false;assert(radio_broadcast_poll(&b));
            if(failure==2) {tune_ok=false;assert(!radio_broadcast_tune(&b,90000));}
            if(failure==3) {seek_ok=false;assert(!radio_broadcast_seek(&b,true));}
            if(failure==4) {status_ok=false;assert(!radio_broadcast_poll(&b));}
        }
        assert(b.failed && !b.owned && !b.running && !b.busy && !b.audio_open && !b.have_status);
        assert(!strcmp(events+event_n-2,"ap"));unsigned count=event_n;
        radio_broadcast_stop(&b);assert(event_n==count);
        power_ok=tune_ok=seek_ok=status_ok=true;assert(radio_broadcast_start(&b,&hal,87500) && !b.failed);
        radio_broadcast_stop(&b);
    }
    radio_broadcast b={0};reset();assert(radio_broadcast_start(&b,&hal,87500));
    input.khz=12345;assert(!radio_broadcast_poll(&b) && b.failed && !b.owned && !b.busy);
    reset();assert(radio_broadcast_start(&b,&hal,87500));off_ok=false;radio_broadcast_stop(&b);
    assert(b.failed && !b.owned && !strcmp(events+event_n-2,"ap"));
}
static void test_invalid_hal_no_side_effect(void) {
    radio_broadcast b={0};reset();
    assert(!radio_broadcast_start(NULL,&hal,87500) && !radio_broadcast_start(&b,NULL,87500));
    hal_bcast_t bad=hal;bad.grid_khz=0;assert(!radio_broadcast_start(&b,&bad,87500));
    bad=hal;bad.lo_khz=90000;assert(!radio_broadcast_start(&b,&bad,87500));
    bad=hal;bad.grid_khz=100;assert(!radio_broadcast_start(&b,&bad,87550));
    bad=hal;bad.audio=NULL;assert(!radio_broadcast_start(&b,&bad,87500));
    bad=hal;bad.status=NULL;assert(!radio_broadcast_start(&b,&bad,87500));
    assert(!event_n && !b.owned && !b.running);
}
int main(void) {
    test_start_poll_stop();test_tune_seek_and_domain();test_failures_unwind();test_invalid_hal_no_side_effect();
    puts("Broadcast helper passed: ownership, mute/power order, bounds/grid, asynchronous tune/seek and failure unwind");
    return 0;
}
