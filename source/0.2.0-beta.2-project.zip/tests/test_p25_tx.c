// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (c) 2026 DM32 P25 research contributors
#include "p25_test_tx.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    assert(argc == 2);
    FILE *fixture = fopen(argv[1], "rb");
    assert(fixture);
    p25_test_tx tx;
    uint8_t block[36];
    p25_test_tx_init(&tx);
    assert(!p25_test_tx_start(&tx, 0, false));
    assert(!p25_test_tx_active(&tx) && tx.reason == P25_TX_NOT_ARMED);
    assert(p25_test_tx_start(&tx, 0, true));
    assert(!p25_test_tx_start(&tx, 0, true));
    uint32_t now=1000, bytes=0;
    while (p25_test_tx_boundary(&tx, now, block)) {
        for (unsigned i=0; i<36; ++i) {
            if (bytes < p25_test_tx_stream_bytes()) assert(fgetc(fixture) == block[i]);
            else assert(block[i] == 0x77);
            ++bytes;
        }
        assert(!p25_test_tx_boundary(&tx, now+100, block)); // same-boundary SYS + TS IRQ
        now += 30000;
    }
    assert(fgetc(fixture) == EOF);
    fclose(fixture);
    assert(tx.state == P25_TX_DRAINING && tx.blocks == 346 && bytes == 12456);
    assert(tx.offset == 12453 && tx.max_gap_us == 30000 && tx.duplicate_irqs == 345);
    p25_test_tx_poll(&tx, tx.drain_until_us-1, true);
    assert(tx.state == P25_TX_DRAINING);
    p25_test_tx_poll(&tx, tx.drain_until_us, true);
    assert(tx.state == P25_TX_DONE);

    assert(p25_test_tx_start(&tx, 0, true));
    p25_test_tx_poll(&tx, 100, false);
    assert(tx.state == P25_TX_ABORTED && tx.reason == P25_TX_RELEASED);
    assert(!p25_test_tx_boundary(&tx, 1000, block));
    assert(p25_test_tx_start(&tx, 0, true));
    p25_test_tx_poll(&tx, 200000, true);
    assert(tx.reason == P25_TX_STALLED);
    assert(p25_test_tx_start(&tx, 0, true));
    assert(p25_test_tx_boundary(&tx, 1000, block));
    assert(!p25_test_tx_boundary(&tx, 61000, block));
    assert(tx.reason == P25_TX_LATE && tx.late_irqs == 1);
    assert(p25_test_tx_start(&tx, 0, true));
    p25_test_tx_poll(&tx, P25_TX_MAX_US, true);
    assert(tx.reason == P25_TX_TIMEOUT);
    assert(p25_test_tx_start(&tx, 0xfffffff0u, true));
    assert(p25_test_tx_boundary(&tx, 0xfffffff0u+1000u, block));
    assert(p25_test_tx_boundary(&tx, 0xfffffff0u+31000u, block));
    p25_test_tx_abort(&tx, P25_TX_CANCELLED);
    assert(tx.reason == P25_TX_CANCELLED);
    assert(p25_test_tx_start(&tx, 0, true));
    assert(!p25_test_tx_boundary(&tx, P25_TX_STALL_US, block));
    assert(tx.reason == P25_TX_STALLED);
    puts("P25 TX stream, boundary, drain, abort, stall, timeout and wrap checks passed");
    return 0;
}
