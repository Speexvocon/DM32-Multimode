"""Independent qualification fixtures, target metadata policy and real codec.

Only host files/processes are used. The unit timeline tests compile the actual
metadata decoder and receive-policy header. The optional real-codec replay is
mandatory in host CI after test-stream-demod builds it; this covers codec calls
and emitted PCM, but not hardware queue flushing, sample timing or RF BER.
"""
import argparse
import ctypes as C
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT/'build/hotspot-qualification'
spec = importlib.util.spec_from_file_location('qualification_generator', ROOT/'tests/generate_hotspot_fixtures.py')
generator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(generator)
REQUIRE_QUALIFIED = False
QUALIFIED = ROOT/'build/p25-rx/qualified-replay.exe'
CLASSES = ['WAIT_METADATA', 'CLEAR', 'ENCRYPTED', 'UNSUPPORTED', 'BAD_METADATA']
PRESERVED_HASHES = {
    'encrypted-hdu': '50436bd6e166994cd5648b7a702e4edbd6d63eb5ae6d0d63614d6c2dd9f60fc5',
    'unsupported-lc': '42bebe17cab0153c0dd4b6db9fd9bfdd549416abf55caac9896d3dd746c473d8',
}


class Event(C.Structure):
    _fields_ = [(name, C.c_uint32) for name in (
        'valid', 'classification', 'state', 'voice', 'reset', 'discard', 'end',
        'lc_valid', 'ess_valid', 'inner_corrected', 'rs_corrected')]


def build_policy():
    BUILD.mkdir(parents=True, exist_ok=True)
    source = BUILD/'policy-probe.c'
    source.write_text('''#include "p25_receive_policy.h"
typedef struct {unsigned valid,classification,state,voice,reset,discard,end,
    lc_valid,ess_valid,inner_corrected,rs_corrected;} result;
unsigned qualify(const unsigned char *records,unsigned count,result *out) {
    p25_receive_policy state; p25_receive_reset(&state); unsigned now=0;
    for(unsigned i=0;i<count;++i) {
        const unsigned char *r=records+219*i; unsigned duid=r[2];
        now+=duid==0?82500:duid==3?15000:180000;
        p25_call_metadata m; bool valid=p25_call_decode(r+3,duid,&m);
        p25_receive_event e=p25_receive_update(&state,(r[0]<<8)|r[1],duid,&m,valid,now);
        out[i]=(result){valid,m.classification,state.state,e.voice,e.reset,e.discard,e.end,
            state.lc_valid,state.ess_valid,m.inner_corrected,m.rs_corrected};
    }
    return count;
}
''')
    library = BUILD/('policy.dll' if os.name == 'nt' else 'policy.so')
    subprocess.run(['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                    '-shared', '-fPIC', '-Isrc/firmware', str(source),
                    'src/firmware/p25_call.c', '-o', str(library)], cwd=ROOT, check=True)
    handle = C.CDLL(str(library))
    handle.qualify.argtypes = [C.POINTER(C.c_uint8), C.c_uint, C.POINTER(Event)]
    handle.qualify.restype = C.c_uint
    return handle


def records(data):
    return b''.join(bytes.fromhex('0293')+bytes([duid])+frame.ljust(216, b'\0')
                    for duid, frame in generator.split_units(data))


class QualificationFixtures(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.calls = generator.generate()
        cls.manifest = generator.manifest(cls.calls)
        cls.library = build_policy()

    def test_reproducible_and_previous_hashes_unchanged(self):
        self.assertEqual(json.loads((generator.DIRECTORY/'manifest.json').read_text()), self.manifest)
        self.assertEqual(set(self.calls), {'encrypted-hdu', 'unsupported-lc', 'damaged-hdu',
                                         'damaged-lc', 'damaged-ess', 'late-entry'})
        for name, data in self.calls.items():
            self.assertEqual((generator.DIRECTORY/(name+'.bin')).read_bytes(), data)
            if name in PRESERVED_HASHES:
                self.assertEqual(hashlib.sha256(data).hexdigest(), PRESERVED_HASHES[name])
            self.assertEqual(len(generator.split_units(data)), 29 if name == 'late-entry' else 30)
            self.assertEqual(len(data), 6066 if name == 'late-entry' else 6165)

    def test_changes_are_only_described_protected_metadata(self):
        # Independent table coordinates: do not use the generator's arithmetic
        # to decide which bits it was permitted to modify.
        source = (ROOT/'research/references/boatbod/op25/op25/gr-op25_repeater/lib/op25_imbe_frame.h').read_text()
        def independent_positions(name, count):
            body = re.search(r'\b'+name+r'\b[^=]*=\s*\{([^}]+)', source).group(1)
            values = re.findall(r'\b\d+\b', re.sub(r'//[^\n]*', '', body))
            result = set(map(int, values[:count]))
            self.assertEqual(len(result), count)
            return result
        allowed_hdu = independent_positions('hdu_codeword_bits', 648)
        allowed_ldu = independent_positions('imbe_ldu_ls_data_bits', 240)
        for duid in (0, 5, 10):
            self.assertEqual({bit for symbol in range(36 if duid == 0 else 24)
                              for bit in generator.metadata_positions(duid, symbol)},
                             allowed_hdu if duid == 0 else allowed_ldu)
        original = generator.split_units((ROOT/'fixtures/p25-1011/call.bin').read_bytes())
        baseline = original[:29]+original[-1:]
        damaged_indices = {'damaged-hdu': [0], 'damaged-lc': [15], 'damaged-ess': [16]}
        for name, data in self.calls.items():
            expected = baseline[1:] if name == 'late-entry' else baseline
            units = generator.split_units(data)
            actual_changes = []
            for index, ((duid, before), (after_duid, after)) in enumerate(zip(expected, units)):
                self.assertEqual(duid, after_duid)
                changed = {bit for byte, (a, b) in enumerate(zip(before, after))
                           for bit in range(8*byte, 8*byte+8) if (a^b) & (0x80 >> (bit%8))}
                if not changed:
                    continue
                self.assertIn(duid, (0, 5, 10))
                allowed = allowed_hdu if duid == 0 else allowed_ldu
                self.assertTrue(changed <= allowed, (name, index))
                actual_changes.append({'unit': index, 'duid': duid,
                                       'wire_bits_msb_first': sorted(changed)})
            self.assertEqual(actual_changes, self.manifest['cases'][name]['metadata_changes'])
            if name in damaged_indices:
                self.assertEqual([change['unit'] for change in actual_changes], damaged_indices[name])
            if name == 'late-entry':
                self.assertEqual(units, baseline[1:])
                self.assertFalse(actual_changes)

    def test_every_unit_against_actual_metadata_and_receive_policy(self):
        totals = {'encrypted-hdu': 0, 'unsupported-lc': 0, 'damaged-hdu': 234,
                  'damaged-lc': 234, 'damaged-ess': 225, 'late-entry': 234}
        for name, data in self.calls.items():
            wire = records(data)
            count = len(wire)//219
            events = (Event*count)()
            self.assertEqual(self.library.qualify((C.c_uint8*len(wire)).from_buffer_copy(wire), count, events), count)
            timeline = self.manifest['cases'][name]['expected']['timeline']
            voices = 0
            for expected, actual in zip(timeline, events):
                with self.subTest(case=name, unit=expected['unit']):
                    if expected['metadata_valid'] is not None:
                        self.assertEqual(bool(actual.valid), expected['metadata_valid'])
                    self.assertEqual(CLASSES[actual.state], expected['receive_class'])
                    self.assertEqual(9 if actual.voice else 0, expected['voice_frames'])
                    voices += 9 if actual.voice else 0
                    # Exact bad words must be rejected, not decoded as another
                    # valid LC/ESS or merely classified unsupported/encrypted.
                    if expected['metadata_valid'] is False:
                        self.assertEqual(actual.classification, 0)
                        self.assertEqual(actual.inner_corrected, 0)
                        self.assertEqual(actual.rs_corrected, 0)
            self.assertEqual(voices, totals[name])
            self.assertEqual(voices, self.manifest['cases'][name]['expected']['voice_frames'])

    def test_actual_qualified_receiver_and_real_codec(self):
        if not QUALIFIED.exists():
            if REQUIRE_QUALIFIED:
                self.fail('Build test-stream-demod.ps1 before --require-qualified')
            self.skipTest('Real codec replay not built; CI requires it after test-stream-demod')
        report = {}
        for name, data in self.calls.items():
            input_path, output_path = BUILD/(name+'.frames'), BUILD/(name+'.s16le')
            input_path.write_bytes(records(data))
            run = subprocess.run([str(QUALIFIED), str(input_path), str(output_path), 'PROM'],
                                 cwd=ROOT, check=True, capture_output=True, text=True)
            actual = json.loads(run.stdout)
            expected = self.manifest['cases'][name]['expected']
            for field in ('voice_frames', 'codec_calls', 'metadata_bad'):
                self.assertEqual(actual[field], expected[field], (name, field, actual))
            self.assertEqual(actual['repeated'], expected['voice_repeated'])
            self.assertEqual(actual['muted'], expected['voice_muted'])
            self.assertEqual(actual['corrected'], 0)
            self.assertEqual(actual['units'], self.manifest['cases'][name]['units'])
            self.assertEqual(actual['terminators'], 1)
            self.assertEqual(actual['ends'], 1)
            self.assertEqual(actual['final_class'], 0)
            pcm = output_path.read_bytes()
            self.assertEqual(len(pcm), expected['voice_frames']*320)
            actual['pcm_sha256'] = hashlib.sha256(pcm).hexdigest()
            report[name] = actual
        (BUILD/'report.json').write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--require-qualified', action='store_true')
    args, remaining = parser.parse_known_args()
    REQUIRE_QUALIFIED = args.require_qualified
    unittest.main(argv=[sys.argv[0]]+remaining)
