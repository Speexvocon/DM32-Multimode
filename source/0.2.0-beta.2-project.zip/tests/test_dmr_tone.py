"""Independent pinned C FEC/LC checks on the actual MMDVM tone fixture."""
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RF = ROOT / "external/RadioFoundry/RadioFoundry"
SPEC = importlib.util.spec_from_file_location("dmr_tone", ROOT / "scripts/generate-dmr-tone.py")
GEN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GEN)


class DmrTone(unittest.TestCase):
    def test_fixture_matches_generator_and_finite_inventory(self):
        call = (ROOT / "fixtures/dmr-1031/call.bin").read_bytes()
        manifest = json.loads((ROOT / "fixtures/dmr-1031/manifest.json").read_text())
        self.assertTrue(GEN.validate_fixture(call, manifest))
        self.assertEqual(len(call), 86 * 33)
        self.assertEqual(manifest["voice_frames_20ms"], 252)
        self.assertEqual(manifest["voice_seconds"], 5.04)
        self.assertEqual(manifest["controls"], [0x41] + [0x20, 1, 2, 3, 4, 5] * 14 + [0x42])
        self.assertNotEqual(manifest["source_id"], 1234567)

    def test_header_voice_tail_metadata_and_hash_tampering_refused(self):
        call, manifest = GEN.make_fixture()
        for at in (0, 33 + 13, 33 + 20, len(call) - 1):
            damaged = bytearray(call);damaged[at] ^= 1
            with self.assertRaises(ValueError):GEN.validate_fixture(bytes(damaged), manifest)
        for name, value in (("talkgroup", 98638), ("color_code", 2), ("source_id", 1234567), ("voice_bursts", 83)):
            altered = copy.deepcopy(manifest);altered[name] = value
            with self.assertRaises(ValueError):GEN.validate_fixture(call, altered)
        altered = copy.deepcopy(manifest);altered["files"]["call.bin"]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):GEN.validate_fixture(call, altered)
        with self.assertRaises(ValueError):GEN.voice_burst(6)

    def test_local_mmdvm_arrays_match_reviewed_source_when_available(self):
        source = ROOT / "external/g4klx/MMDVM/CalDMR.cpp"
        if not source.exists():self.skipTest("Optional complete MMDVM source checkout unavailable")
        GEN.validate_reference(source)

    def test_retargeted_fixture_rebuilds_all_lc_and_preserves_audio(self):
        if not (shutil.which("gcc") or shutil.which("cc")):
            self.skipTest("Host C compiler unavailable")
        original, original_manifest = GEN.make_fixture()
        self.assertEqual(GEN.retarget_call(9), original)
        call, manifest = GEN.make_fixture(98638)
        self.assertTrue(GEN.validate_fixture(call, manifest))
        saved = ROOT / "fixtures/dmr-1031/tg98638"
        self.assertEqual(call, (saved / "call.bin").read_bytes())
        self.assertEqual(manifest, json.loads((saved / "manifest.json").read_text()))
        self.assertEqual(GEN.voice_payload(call), GEN.voice_payload(original))
        self.assertEqual(manifest["controls"], original_manifest["controls"])
        self.assertEqual(manifest["talkgroup"], 98638)
        self.assertEqual(manifest["color_code"], 1)
        self.assertEqual(manifest["source_id"], 1)
        # Full LC and embedded-LC-bearing B-E bursts change; voice A's sync
        # and F's null signaling must remain identical, along with all audio.
        for index in range(86):
            if index in (0, 85) or 1 <= (index - 1) % 6 <= 4:
                self.assertNotEqual(call[index*33:(index+1)*33], original[index*33:(index+1)*33])
            else:
                self.assertEqual(call[index*33:(index+1)*33], original[index*33:(index+1)*33])
        with self.assertRaises(ValueError):GEN.make_fixture(10)

    def test_real_radiofoundry_fec_decodes_lc_emb_and_252_clean_tone_frames(self):
        cc = shutil.which("gcc") or shutil.which("cc")
        if not cc:self.skipTest("Host C compiler unavailable")
        with tempfile.TemporaryDirectory(prefix="dmr-tone-") as tmp:
            tmp = Path(tmp);source = tmp / "check.c";binary = tmp / "check.exe"
            source.write_text(CHECK_C)
            cmd = [cc, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-I", str(RF / "core"), str(source)]
            cmd += [str(RF / name) for name in ("core/dmr/call/dmr_lc.c", "core/dmr/fec/dmrFec.c", "core/dmr/ambe/ambeFec.c")]
            cmd += ["-o", str(binary)]
            compiled = subprocess.run(cmd, capture_output=True, text=True)
            self.assertEqual(compiled.returncode, 0, compiled.stdout + compiled.stderr)
            for talkgroup, relative in ((9, "fixtures/dmr-1031/call.bin"),
                                       (98638, "fixtures/dmr-1031/tg98638/call.bin")):
                result = subprocess.run([str(binary), str(ROOT / relative), str(talkgroup)], capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn("252 clean tone frames", result.stdout)


CHECK_C = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dmr/call/dmr_lc.h"
#include "dmr/fec/dmrFec.h"
#include "dmr/ambe/ambeFec.h"
static uint8_t wanted_lc[9]={0,0,0,0,0,9,0,0,1};
static const uint8_t tone[9]={0xce,0xa8,0xfe,0x83,0xac,0xc4,0x58,0x20,0x0a};
static const uint8_t sync[6]={0x7f,0x7d,0x5d,0xd5,0x7d,0xfd};
static void full_lc(const uint8_t *b,uint8_t dt,uint8_t mask) {
    uint8_t cc=0,kind=0,info[12],lc[9];
    assert(dmrFecSlotTypeDecode(b,&cc,&kind) && cc==1 && kind==dt);
    assert(dmrFecBptcDecode(b,info)==0);
    assert(dmr_lc_decode_full(info,mask,lc)==0);
    assert(!memcmp(lc,wanted_lc,sizeof lc));
}
int main(int argc,char **argv) {
    assert(argc==3);unsigned long tg=strtoul(argv[2],0,10);assert(tg==9 || tg==98638);
    wanted_lc[3]=(uint8_t)(tg>>16);wanted_lc[4]=(uint8_t)(tg>>8);wanted_lc[5]=(uint8_t)tg;
    FILE *f=fopen(argv[1],"rb");assert(f);
    uint8_t call[86][33];assert(fread(call,33,86,f)==86 && fgetc(f)==EOF);fclose(f);
    full_lc(call[0],1,0x96);full_lc(call[85],2,0x99);
    unsigned clean=0;uint8_t fragments[16]={0};
    for(unsigned i=0;i<84;++i) {
        const uint8_t *b=call[i+1];unsigned n=i%6;uint8_t mid[6];
        for(unsigned j=0;j<6;++j)mid[j]=(uint8_t)((b[13+j]<<4)|(b[14+j]>>4));
        if(!n)assert(!memcmp(mid,sync,6));
        else {
            uint8_t cc=0,lcss=0;bool pi=true;
            assert(dmrFecEmbDecode((uint16_t)((uint16_t)mid[0]<<8|mid[5]),&cc,&pi,&lcss)==0);
            assert(cc==1 && !pi && lcss==dmr_emb_lcss((uint8_t)n));
            if(n<=4)memcpy(fragments+(n-1)*4,mid+1,4);
            else assert(mid[1]==0 && mid[2]==0 && mid[3]==0 && mid[4]==0);
            if(n==4) {uint8_t lc[9];assert(dmr_emb_lc_decode_bits(fragments,lc));assert(!memcmp(lc,wanted_lc,9));}
        }
        uint8_t frames[3][9];ambeFullBurstSplit(b,frames);
        for(unsigned j=0;j<3;++j) {
            uint8_t bits[49],roundtrip[9];ambe_fec_result_t result;
            assert(!memcmp(frames[j],tone,9));
            assert(ambeFecDecode(frames[j],bits,&result)==0 && !result.c0_failed);
            assert(!result.c0_errors && !result.c1_errors);
            ambeFecEncode(bits,roundtrip);assert(!memcmp(roundtrip,tone,9));++clean;
        }
    }
    assert(clean==252);puts("252 clean tone frames; full and embedded LC verified");return 0;
}
'''


if __name__ == "__main__":
    unittest.main()
