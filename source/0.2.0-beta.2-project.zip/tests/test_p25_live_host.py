import contextlib
import importlib.util
import io
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('live',Path(__file__).resolve().parents[1]/'scripts/p25-live.py')
live=importlib.util.module_from_spec(spec); spec.loader.exec_module(live)

class Port:
    def __init__(self,identity='LIVE git=test active=0 rf=0 cal=factory',reject=False):
        self.identity=identity;self.reject=reject;self.lines=[];self.writes=[]
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def write(self,s):
        self.writes.append(s)
        if s==b'STATUS\n': self.lines.extend([self.identity,'LIVE_AUDIO peak=123 mode=00000002'])
        elif s==b'STOP\n': self.lines.append('OK STOP')
        elif s.startswith(b'SESSION '): self.lines.append('ERR busy' if self.reject else 'OK LIVE SESSION; fresh PTT per call; STOP or power off ends')
        elif s.startswith(b'ARM '): self.lines.append('ERR busy' if self.reject else 'OK LIVE ARMED 30s; unplug cable then fresh PTT')
    def readline(self):return ((self.lines.pop(0)+'\n').encode() if self.lines else b'')

class Host(unittest.TestCase):
    def invoke(self,port,args):
        with tempfile.TemporaryDirectory() as d,patch.dict(sys.modules,{'serial':types.SimpleNamespace(Serial=lambda *a,**k:port)}),patch.object(sys,'argv',['live','--port','MOCK','--log',str(Path(d)/'capture.jsonl')]+args),contextlib.redirect_stdout(io.StringIO()):
            live.main()
    def test_arm_detaches_only_after_ack(self):
        p=Port();self.invoke(p,['--arm','--allow-rf','--frequency','440075000'])
        self.assertEqual(p.writes,[b'STATUS\n',b'ARM 440075000 ALLOW_RF\n'])
    def test_session_detaches_after_ack(self):
        p=Port();self.invoke(p,['--session','--allow-rf','--frequency','440075000'])
        self.assertEqual(p.writes,[b'STATUS\n',b'SESSION 440075000 ALLOW_RF\n'])
    def test_session_refusal_stops(self):
        p=Port(reject=True)
        with self.assertRaises(RuntimeError):self.invoke(p,['--session','--allow-rf','--frequency','440075000'])
        self.assertEqual(p.writes[-1],b'STOP\n')
    def test_refusal_stops(self):
        p=Port(reject=True)
        with self.assertRaises(RuntimeError):self.invoke(p,['--arm','--allow-rf','--frequency','440075000'])
        self.assertEqual(p.writes[-1],b'STOP\n')
    def test_bad_state_never_arms(self):
        for state in ('active=1 rf=1 cal=factory','active=0 rf=0 cal=none'):
            p=Port('LIVE git=test '+state)
            with self.assertRaises(RuntimeError):self.invoke(p,['--arm','--allow-rf','--frequency','440075000'])
            self.assertEqual(p.writes,[b'STATUS\n'])
    def test_stop_does_not_wait_for_idle(self):
        p=Port();self.invoke(p,['--stop']);self.assertEqual(p.writes,[b'STOP\n'])
    def test_status_collects_audio_diagnostics(self):
        p=Port();self.invoke(p,[]);self.assertEqual(p.lines,[])

if __name__=='__main__':unittest.main()
