"""Exercise the actual broadcast HAL ownership helper without hardware."""
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]

class BroadcastTest(unittest.TestCase):
    def test_state_and_failures(self):
        output=ROOT/'build'/'production-functions'/'broadcast-test.exe'
        output.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror',
            '-Isrc/firmware','-Iexternal/RadioFoundry/RadioFoundry/hal',
            'tests/test_radio_broadcast.c','-o',str(output)],cwd=ROOT,check=True)
        subprocess.run([str(output)],cwd=ROOT,check=True)

if __name__=='__main__':unittest.main()
