"""Compile the generated PCM driver and exercise real callback/stop interleavings."""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
UPSTREAM=ROOT/"external/RadioFoundry/RadioFoundry"
spec=importlib.util.spec_from_file_location("drained_audio",ROOT/"scripts/generate-drained-audio.py")
GEN=importlib.util.module_from_spec(spec)
spec.loader.exec_module(GEN)


class DrainedAudioTest(unittest.TestCase):
    def compile_run(self,body,vox=0):
        cc=shutil.which("gcc") or shutil.which("cc")
        if not cc:self.skipTest("host C compiler unavailable")
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            (d/"audio_pcm_drained.c").write_text(GEN.generate((UPSTREAM/"platform/hrc7000/audio_pcm.c").read_text()))
            (d/"hal_time.h").write_text("#include <stdint.h>\nuint32_t hal_micros(void);\n")
            (d/"config.h").write_text(f"#define CONFIG_DMR 1\n#define CONFIG_VOX {vox}\n")
            (d/"FreeRTOS.h").write_text('''#include <stdint.h>
typedef int BaseType_t; typedef void *TaskHandle_t;
#define pdFALSE 0
#define pdTRUE 1
#define pdPASS 1
#define portMAX_DELAY 0xffffffffu
#define pdMS_TO_TICKS(x) (x)
#define portYIELD_FROM_ISR(x) ((void)(x))
''')
            (d/"task.h").write_text('''void vTaskDelay(unsigned ticks);
TaskHandle_t xTaskGetCurrentTaskHandle(void);
BaseType_t xTaskCreate(void (*fn)(void *),const char *,unsigned,void *,unsigned,TaskHandle_t *);
uint32_t ulTaskNotifyTake(BaseType_t,unsigned);
void vTaskNotifyGiveFromISR(TaskHandle_t,BaseType_t *);
''')
            (d/"platform.h").write_text('''uint32_t hrc_irq_save(void);
void hrc_irq_restore(uint32_t);
void hrc_irq_enable(unsigned,bool);
void hrc_irq_register(unsigned,void (*)(void));
static inline void hrc_barrier(void) { __asm__ volatile("" ::: "memory"); }
#define IRQ_PCM_WR 28
#define IRQ_PCM_RD 27
''')
            (d/"audio_pcm.h").write_text('''#include <stdint.h>
#include <stdbool.h>
#include "hal_audio.h"
typedef struct { unsigned dummy; } hrc7000_t;
extern int16_t mock_mic[80];
extern uint8_t mock_speaker[160];
#define C7_PCM_MIC_ADDR mock_mic
#define C7_PCM_SPK_ADDR mock_speaker
#define C7_PCM_SAMPLES 80
#define C7_PROMPT_CHUNK 32
#define C7_INTERP_CLEAR 1
#define C7_AUDIO_CONTROL 3
#define C7_INT_PCM_WR 2
#define C7_INT_PCM_RD 32
#define C7_AUDIO_PCM_MIC 16
#define C7_AUDIO_PCM_SPK 32
#define C7_AUDIO_RING_PLAY 128
#define C7_AUDIO_FM_PLAY 64
void hrc7000_wr(hrc7000_t *,unsigned,unsigned);
uint32_t hrc7000_rd(hrc7000_t *,unsigned);
void hrc7000_audio_bits(hrc7000_t *,unsigned,unsigned);
bool hrc7000_prompt_push(hrc7000_t *,const int16_t *);
void hrc7000_set_crit(hrc7000_t *,uint32_t (*)(void),void (*)(uint32_t));
''')
            meter=d/"audio/miclevel/miclevel.h";meter.parent.mkdir(parents=True)
            meter.write_text('''#include <stdint.h>
#include <string.h>
typedef struct { uint8_t level;uint16_t peak;uint32_t blocks; } miclevel_t;
static inline void miclevel_block(miclevel_t *m,volatile const int16_t *p,unsigned n) {(void)p;(void)n;m->blocks++;}
static inline void miclevel_reset(miclevel_t *m) {memset(m,0,sizeof *m);}
''')
            # Direct work-unit calls must have the same task identity as the
            # real audio worker, including normal route-off/drain semantics.
            (d/"test.c").write_text(COMMON+body.replace("audio_work_once();", "run_worker_once();"))
            exe=d/"audio-test.exe"
            result=subprocess.run([cc,"-std=c11","-O2","-Wall","-Wextra","-Werror","-pthread",
                                   "-I",str(d),"-I",str(ROOT/"src/firmware"),"-I",str(UPSTREAM/"hal"),str(d/"test.c"),"-o",str(exe)],
                                  capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            result=subprocess.run([str(exe)],capture_output=True,text=True,timeout=15)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_external_stop_waits_for_callback_and_blocks_stale_route(self):
        self.compile_run(r'''
static void blocking_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;assert(ctx==(void *)9);atomic_fetch_add(&callbacks,1);
    pause_worker();
    // This is deliberately after stop closed the gate.
    speaker_pcm(true);out[0]=123;
}
int main(void) {
    initialize();assert(start(blocking_callback,(void *)9));mic_ready=0;
    pthread_t a,b;pthread_create(&a,NULL,work_thread,NULL);wait_paused();
    pthread_create(&b,NULL,stop_thread,NULL);wait_stopping();
    assert(!atomic_load(&stop_returned));assert(worker_active);
    release_worker();pthread_join(a,NULL);pthread_join(b,NULL);
    assert(atomic_load(&stop_returned));assert(!worker_active && !running && stopping);
    assert(atomic_load(&callbacks)==1 && atomic_load(&route_on)==0);
    assert(spk_head==0 && atomic_load(&pushes)==0);
    audio_work_once();assert(atomic_load(&callbacks)==1);
    hrc_audio_pcm_output_resume();assert(start(normal_callback,NULL));mic_ready=0;audio_work_once();
    assert(atomic_load(&callbacks)==2 && atomic_load(&route_on)==1 && spk_head==1);
    stop();return 0;
}
''')

    def test_external_stop_also_drains_pcm_only_work(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(normal_callback,NULL));
    spk_routed=true;spk_head=1;mic_ready=-1;atomic_store(&pause_service,true);
    pthread_t a,b;pthread_create(&a,NULL,work_thread,NULL);wait_paused();
    pthread_create(&b,NULL,stop_thread,NULL);wait_stopping();
    assert(worker_active && !atomic_load(&stop_returned));
    release_worker();pthread_join(a,NULL);pthread_join(b,NULL);
    assert(atomic_load(&callbacks)==0);
    unsigned old_enables=pcm_enables;
    audio_work_once();assert(pcm_enables==old_enables && !enabled_irqs[IRQ_PCM_RD]);
    return 0;
}
''')

    def test_self_stop_never_waits_or_restarts_its_own_stack(self):
        self.compile_run(r'''
static void self_stop_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)out;(void)ctx;atomic_fetch_add(&callbacks,1);
    assert(worker_active);stop();assert(!running && stopping);
    assert(!start(normal_callback,NULL));speaker_pcm(true);
}
int main(void) {
    initialize();assert(start(self_stop_callback,NULL));mic_ready=0;
    current_task=task;audio_work_once();current_task=(void *)2;
    assert(!worker_active && !running && stopping);
    assert(atomic_load(&delays)==0 && atomic_load(&route_on)==0);
    assert(spk_head==0 && atomic_load(&pushes)==0);
    hrc_audio_pcm_output_resume();assert(start(normal_callback,NULL));mic_ready=0;audio_work_once();
    assert(atomic_load(&callbacks)==2);stop();return 0;
}
''')

    def test_start_replacement_drains_before_changing_callback(self):
        self.compile_run(r'''
static void old_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)out;assert(ctx==(void *)9);atomic_fetch_add(&callbacks,1);pause_worker();
}
static void *replace_thread(void *p) {
    (void)p;current_task=(void *)2;assert(start(normal_callback,NULL));atomic_store(&stop_returned,true);return NULL;
}
int main(void) {
    initialize();assert(start(old_callback,(void *)9));mic_ready=0;
    pthread_t a,b;pthread_create(&a,NULL,work_thread,NULL);wait_paused();
    pthread_create(&b,NULL,replace_thread,NULL);wait_stopping();
    assert(block_cb==NULL && !atomic_load(&stop_returned));
    release_worker();pthread_join(a,NULL);pthread_join(b,NULL);
    assert(running && !stopping && block_cb==normal_callback && block_ctx==NULL);
    mic_ready=0;audio_work_once();assert(atomic_load(&callbacks)==2);stop();return 0;
}
''')

    def test_stop_preserves_active_vox_meter(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(normal_callback,NULL));meter_on=true;
    atomic_store(&mic_off,0);stop();
    assert(!running && meter_on && atomic_load(&mic_off)==0);
    assert(atomic_load(&irq_enabled));
    meter_on=false;stop();assert(atomic_load(&mic_off)==1 && !atomic_load(&irq_enabled));
    return 0;
}
''',vox=1)

    def test_external_pcm_speaker_route_does_not_require_microphone_start(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(normal_callback,NULL));stop();
    assert(stopping && !running && !worker_active);
    // The higher-priority P25 PCM service runs without a mic callback stream.
    speaker_pcm(true);assert(atomic_load(&route_on)==1 && spk_routed);
    speaker_pcm(false);assert(!spk_routed);
    return 0;
}
''')

    def test_changed_source_is_rejected(self):
        text=(UPSTREAM/"platform/hrc7000/audio_pcm.c").read_text()
        with self.assertRaises(ValueError):GEN.generate(text+"\n/* changed */\n")

    def test_timing_counts_wrap_safe_gaps_and_retained_stop_snapshot(self):
        self.compile_run(r'''
static void timed_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)out;(void)ctx;fake_now+=7000u;
}
int main(void) {
    (void)normal_callback;initialize();blocks=20;overruns=4;underruns=2;
    assert(start(timed_callback,NULL));
    fake_now=UINT32_MAX-10000u;mic_ready=0;audio_work_once();
    fake_now+=13000u;mic_ready=1;overruns+=2;audio_work_once();
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.service.calls==2 && d.callback.calls==2);
    assert(d.service.total_us==14000 && d.callback.total_us==14000);
    assert(d.service.max_us==7000 && d.callback.max_us==7000);
    assert(d.service_gap_max_us==20000 && d.callback_gap_max_us==20000);
    assert(d.blocks==22 && d.overruns==6 && d.underruns==2);
    stop();fake_now+=1000000u;audio_work_once();hrc_audio_pcm_diag(&d);
    assert(d.callback.calls==2 && d.callback_gap_max_us==20000);
    hrc_audio_pcm_diag(NULL);
    hrc_audio_pcm_output_resume();assert(start(timed_callback,NULL));hrc_audio_pcm_diag(&d);
    assert(d.callback.calls==2 && d.callback_gap_max_us==20000 && d.overruns==6);
    fake_now+=1000000u;mic_ready=0;audio_work_once();hrc_audio_pcm_diag(&d);
    assert(d.callback.calls==3 && d.callback_gap_max_us==20000);
    return 0;
}
''')

    def test_pcm_overwrite_diagnostics_keep_native_two_half_cadence(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(normal_callback,NULL));
    for(unsigned i=0;i<80;i++)mock_mic[i]=10;
    isr_pcm_wr();assert(mic_ready==-1 && mic_half==1);
    isr_pcm_wr();assert(mic_ready==0 && mic_half==0);
    isr_pcm_wr();isr_pcm_wr(); // previous unread block overwritten once
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.overruns==1 && d.blocks==0 && d.callback.calls==0);
    audio_work_once();hrc_audio_pcm_diag(&d);
    assert(d.overruns==1 && d.blocks==1 && d.callback.calls==1);
    hrc_audio_pcm_reset_stats();hrc_audio_pcm_diag(&d);
    assert(d.overruns==0 && d.blocks==0 && d.callback.calls==1);
    return 0;
}
''')

    def test_pcm_primes_before_irq_and_consumes_80_sample_halves_in_order(self):
        self.compile_run(r'''
int main(void) {
    initialize();memset(mock_speaker,0xa5,sizeof mock_speaker);
    assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();assert(atomic_load(&callbacks)==1);
    assert(!enabled_irqs[IRQ_PCM_RD] && !(mock_audio_control&C7_AUDIO_PCM_SPK));
    assert(!pcm_enables); // One 20-ms block is below the 40-ms startup reserve.
    mic_ready=1;audio_work_once();assert(atomic_load(&callbacks)==2);
    assert(enabled_irqs[IRQ_PCM_RD] && (mock_audio_control&C7_AUDIO_PCM_SPK));
    assert(!(mock_audio_control&(C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY)));
    check_pcm_bytes(mock_speaker,0);check_pcm_bytes(speaker_at_enable,0);
    unsigned enables=pcm_enables;
    end_call_in_worker(); // Normal end callback drains the published tail.
    for(unsigned half=1;half<=4;++half) {
        fake_now+=10000u;unsigned before=atomic_load(&callbacks);fire_pcm_rd();
        assert(atomic_load(&callbacks)==before); // IRQ never decodes/calls back.
        if(half<4)check_pcm_bytes(mock_speaker,80u*half);
    }
    assert(!enabled_irqs[IRQ_PCM_RD] && !(mock_audio_control&C7_AUDIO_PCM_SPK));
    mic_ready=-1;audio_work_once(); // Amplifier off/drain accounting is task-only.
    assert(pcm_enables==enables && !atomic_load(&pushes));
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_submitted==320 && d.output_consumed==320 && d.output_irqs==4);
    assert(d.output_irq_gap_max_us==10000 && d.output_starvations==0 && d.output_drains==1);
    assert(d.output_overflows==0 && d.output_discarded==0);stop();return 0;
}
''')

    def test_short_call_drains_one_block_without_waiting_for_full_prime(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));mic_ready=0;audio_work_once();
    assert(!enabled_irqs[IRQ_PCM_RD]);
    end_call_in_worker();
    mic_ready=-1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);check_pcm_bytes(mock_speaker,0);
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,80);
    fake_now+=10000u;fire_pcm_rd();assert(!enabled_irqs[IRQ_PCM_RD]);
    mic_ready=-1;audio_work_once();
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_submitted==160 && d.output_consumed==160 && d.output_irqs==2);
    assert(d.output_drains==1 && d.output_starvations==0);stop();return 0;
}
''')

    def test_repeated_route_on_preserves_pending_half_and_queue(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    unsigned enables=pcm_enables;check_pcm_bytes(mock_speaker,0);
    current_task=task;speaker_pcm(true);speaker_pcm(true);current_task=(void *)2;
    assert(pcm_enables==enables);check_pcm_bytes(mock_speaker,0);
    assert(!(mock_audio_control&C7_AUDIO_RING_PLAY));
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,80);
    current_task=task;speaker_pcm(true);current_task=(void *)2;
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,160);
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_submitted==240 && d.output_consumed==160 && d.output_irqs==2);
    stop();assert(!enabled_irqs[IRQ_PCM_RD]);return 0;
}
''')

    def test_full_queue_discards_new_block_without_corrupting_pending_audio(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    mic_ready=0;audio_work_once();assert(atomic_load(&callbacks)==3);
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_overflows==1 && d.output_discarded==160);
    check_pcm_bytes(mock_speaker,0);
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,80);
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,160);
    mic_ready=1;audio_work_once(); // New block starts at480; discarded320 never publishes.
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,240);
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,480);
    hrc_audio_pcm_diag(&d);assert(d.output_overflows==1 && d.output_discarded==160);
    stop();return 0;
}
''')

    def test_abort_and_resume_during_callback_rejects_stale_route_and_publication(self):
        self.compile_run(r'''
static void stale_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)ctx;assert(!in_irq && !lock_depth);atomic_fetch_add(&callbacks,1);
    for(unsigned i=0;i<160;++i)out[i]=1234;
    pause_worker();speaker_pcm(true);
}
int main(void) {
    initialize();assert(start(stale_callback,NULL));mic_ready=0;
    pthread_t worker,aborter;pthread_create(&worker,NULL,work_thread,NULL);wait_paused();
    pthread_create(&aborter,NULL,abort_thread,NULL);wait_stopping();
    assert(output_blocked && !atomic_load(&stop_returned));
    release_worker();pthread_join(worker,NULL);pthread_join(aborter,NULL);
    assert(!enabled_irqs[IRQ_PCM_RD] && !atomic_load(&route_on));
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);assert(!d.output_submitted);
    hrc_audio_pcm_output_resume();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);check_pcm_bytes(mock_speaker,0);stop();return 0;
}
''')

    def test_abort_rejects_stale_callback_off_without_losing_live_rx_request(self):
        self.compile_run(r'''
static void stale_off_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)ctx;memset(out,0,320);assert(!lock_depth && !in_irq);
    pause_worker();speaker_pcm(false);
}
int main(void) {
    initialize();assert(start(pattern_callback,NULL));mic_ready=0;audio_work_once();
    assert(output_wanted);block_cb=stale_off_callback;mic_ready=1;
    pthread_t worker,aborter;pthread_create(&worker,NULL,work_thread,NULL);wait_paused();
    pthread_create(&aborter,NULL,abort_thread,NULL);wait_stopping();
    assert(output_blocked && !atomic_load(&stop_returned));
    release_worker();pthread_join(worker,NULL);pthread_join(aborter,NULL);
    assert(output_wanted && !spk_routed && !enabled_irqs[IRQ_PCM_RD]);
    unsigned routed=atomic_load(&route_on);hrc_audio_pcm_output_resume();
    assert(atomic_load(&route_on)==routed); // Resume grants ownership; the task routes.
    block_cb=pattern_callback;mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);check_pcm_bytes(mock_speaker,160);stop();return 0;
}
''')

    def test_abort_waits_for_inflight_board_route_before_handoff(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));mic_ready=0;
    atomic_store(&pause_route,true);
    pthread_t worker,aborter;pthread_create(&worker,NULL,work_thread,NULL);wait_paused();
    pthread_create(&aborter,NULL,abort_thread,NULL);wait_stopping();
    assert(output_blocked && worker_active && !atomic_load(&stop_returned));
    release_worker();pthread_join(worker,NULL);pthread_join(aborter,NULL);
    assert(atomic_load(&stop_returned) && !spk_routed && !enabled_irqs[IRQ_PCM_RD]);
    assert(!(mock_audio_control&(C7_AUDIO_PCM_SPK|C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY)));
    mic_ready=-1;audio_work_once();assert(!spk_routed);stop();return 0;
}
''')

    def test_abort_gate_survives_stream_start_and_keeps_microphone_callbacks(self):
        self.compile_run(r'''
int main(void) {
    initialize();hrc_audio_pcm_output_abort();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(atomic_load(&callbacks)==2 && atomic_load(&irq_enabled));
    assert(!enabled_irqs[IRQ_PCM_RD] && !(mock_audio_control&C7_AUDIO_PCM_SPK));
    assert(!atomic_load(&route_on));
    hrc_audio_pcm_output_resume();
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);check_pcm_bytes(mock_speaker,320);
    stop();return 0;
}
''')

    def test_irq_during_unpublished_callback_never_reads_partial_staging(self):
        self.compile_run(r'''
static void slow_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)ctx;assert(!lock_depth && !in_irq);atomic_fetch_add(&callbacks,1);
    for(unsigned i=0;i<80;++i)out[i]=pattern_sample(320+i);
    pause_worker();
    for(unsigned i=80;i<160;++i)out[i]=pattern_sample(320+i);
    pattern_sequence=480;speaker_pcm(true);
}
int main(void) {
    initialize();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,80);
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,160);
    block_cb=slow_callback;mic_ready=0;
    pthread_t worker;pthread_create(&worker,NULL,work_thread,NULL);wait_paused();
    fake_now+=10000u;fire_pcm_rd();check_pcm_bytes(mock_speaker,240);
    fake_now+=10000u;fire_pcm_rd();assert(!enabled_irqs[IRQ_PCM_RD]);
    release_worker();pthread_join(worker,NULL);
    assert(!enabled_irqs[IRQ_PCM_RD]); // One recovered block alone is not a new prime.
    block_cb=pattern_callback;mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);check_pcm_bytes(mock_speaker,320);
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_starvations==1 && !d.output_overflows);stop();return 0;
}
''')

    def test_missing_pcm_irq_stops_consumer_without_replaying_stale_window(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);fake_now+=30001u;mic_ready=-1;audio_work_once();
    assert(!enabled_irqs[IRQ_PCM_RD] && !(mock_audio_control&C7_AUDIO_PCM_SPK));
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_timeouts==1 && !d.output_consumed);
    unsigned enables=pcm_enables;fake_now+=100000u;audio_work_once();
    assert(pcm_enables==enables); // No restart from the old pending RAM.
    stop();return 0;
}
''')

    def test_fifo_hold_preserves_other_source_and_resumes_with_fresh_prefill(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);hrc_audio_pcm_hold(true);
    assert(!enabled_irqs[IRQ_PCM_RD] && !(mock_audio_control&C7_AUDIO_PCM_SPK));
    // The other owner deliberately enables its source after acquiring hold.
    mock_audio_control|=C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY;
    unsigned enables=pcm_enables;mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(atomic_load(&callbacks)==4 && atomic_load(&irq_enabled));
    assert(pcm_enables==enables && (mock_audio_control&C7_AUDIO_RING_PLAY));
    assert(mock_audio_control&C7_AUDIO_FM_PLAY); // Native service must not clear it.
    hrc_audio_pcm_hold(false);mic_ready=0;audio_work_once();
    assert(!enabled_irqs[IRQ_PCM_RD]); // Held callbacks cannot prime after release.
    mic_ready=1;audio_work_once();assert(enabled_irqs[IRQ_PCM_RD]);
    check_pcm_bytes(mock_speaker,640);
    assert(!(mock_audio_control&(C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY)));
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_discarded==320 && !d.output_consumed && !d.output_overflows);
    stop();return 0;
}
''')

    def test_external_p25_route_and_irq_are_not_owned_by_stopped_native_driver(self):
        self.compile_run(r'''
static void external_pcm_irq(void) {++pcm_ack_count;}
int main(void) {
    initialize();assert(start(normal_callback,NULL));stop();
    hrc_irq_register(IRQ_PCM_RD,external_pcm_irq);hrc_irq_enable(IRQ_PCM_RD,true);
    mock_audio_control=C7_AUDIO_PCM_SPK;
    speaker_pcm(true);assert(enabled_irqs[IRQ_PCM_RD]);
    assert(registered_irqs[IRQ_PCM_RD]==external_pcm_irq);
    assert(mock_audio_control&C7_AUDIO_PCM_SPK);
    audio_work_once();speaker_pcm(false);
    assert(enabled_irqs[IRQ_PCM_RD] && (mock_audio_control&C7_AUDIO_PCM_SPK));
    assert(registered_irqs[IRQ_PCM_RD]==external_pcm_irq);
    // The common owner first stops external P25 consumption before returning
    // the physical IRQ to a fresh native DMR stream.
    hrc_irq_enable(IRQ_PCM_RD,false);mock_audio_control=0;
    hrc_audio_pcm_output_resume();assert(start(pattern_callback,NULL));
    assert(registered_irqs[IRQ_PCM_RD]!=external_pcm_irq);
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    assert(enabled_irqs[IRQ_PCM_RD]);check_pcm_bytes(mock_speaker,0);stop();return 0;
}
''')

    def test_pcm_irq_gap_and_watchdog_are_safe_across_microsecond_wrap(self):
        self.compile_run(r'''
int main(void) {
    initialize();assert(start(pattern_callback,NULL));fake_now=UINT32_MAX-5000u;
    mic_ready=0;audio_work_once();mic_ready=1;audio_work_once();
    end_call_in_worker();
    for(unsigned i=0;i<4;++i) {fake_now+=10000u;fire_pcm_rd();}
    radio_dmr_audio_diag_t d;hrc_audio_pcm_diag(&d);
    assert(d.output_irq_gap_max_us==10000 && !d.output_timeouts);
    assert(d.output_consumed==320 && d.output_irqs==4);stop();return 0;
}
''')


COMMON=r'''
#include <assert.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdlib.h>
#include "audio_pcm_drained.c"
int16_t mock_mic[80];
uint8_t mock_speaker[160];
static uint32_t fake_now;
uint32_t hal_micros(void);
static pthread_mutex_t irq_mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t gate_mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t gate_cond=PTHREAD_COND_INITIALIZER;
static bool worker_paused,worker_released;
static _Thread_local TaskHandle_t current_task;
static _Thread_local unsigned lock_depth;
static atomic_uint callbacks,route_on,pushes,delays,mic_off;
static atomic_bool stop_returned,pause_fifo,irq_enabled;
static atomic_bool pause_service,pause_route;
static uint32_t mock_audio_control;
static bool enabled_irqs[64];
static void (*registered_irqs[64])(void);
static uint32_t pcm_ack_count,pcm_enables;
static uint8_t speaker_at_enable[160];
static _Thread_local bool in_irq;
static void pause_worker(void) {
    pthread_mutex_lock(&gate_mutex);worker_paused=true;pthread_cond_broadcast(&gate_cond);
    while(!worker_released)pthread_cond_wait(&gate_cond,&gate_mutex);
    pthread_mutex_unlock(&gate_mutex);
}
void wait_paused(void) {
    pthread_mutex_lock(&gate_mutex);while(!worker_paused)pthread_cond_wait(&gate_cond,&gate_mutex);
    pthread_mutex_unlock(&gate_mutex);
}
void release_worker(void) {
    pthread_mutex_lock(&gate_mutex);worker_released=true;pthread_cond_broadcast(&gate_cond);pthread_mutex_unlock(&gate_mutex);
}
void wait_stopping(void) { while(!atomic_load(&delays))sched_yield(); }
uint32_t hal_micros(void) {
    if(worker_active && !lock_depth && atomic_exchange(&pause_service,false))pause_worker();
    return fake_now;
}
uint32_t hrc_irq_save(void) {assert(!lock_depth);pthread_mutex_lock(&irq_mutex);lock_depth++;return 0;}
void hrc_irq_restore(uint32_t s) {(void)s;assert(lock_depth==1);lock_depth--;pthread_mutex_unlock(&irq_mutex);}
void hrc_irq_enable(unsigned n,bool on) {
    assert(n<64);enabled_irqs[n]=on;
    if(n==IRQ_PCM_WR)atomic_store(&irq_enabled,on);
    if(n==IRQ_PCM_RD && on) {++pcm_enables;memcpy(speaker_at_enable,mock_speaker,160);}
}
void hrc_irq_register(unsigned n,void (*fn)(void)) {assert(n<64);registered_irqs[n]=fn;}
void hrc7000_wr(hrc7000_t *m,unsigned a,unsigned b) {
    (void)m;if(a==C7_INTERP_CLEAR && (b&C7_INT_PCM_RD))++pcm_ack_count;
}
uint32_t hrc7000_rd(hrc7000_t *m,unsigned reg) {(void)m;assert(reg==C7_AUDIO_CONTROL);return mock_audio_control;}
void hrc7000_audio_bits(hrc7000_t *m,unsigned set,unsigned clear) {
    (void)m;mock_audio_control=(mock_audio_control|set)&~clear;
    if(clear&C7_AUDIO_PCM_MIC)atomic_fetch_add(&mic_off,1);
}
bool hrc7000_prompt_push(hrc7000_t *m,const int16_t *p) {
    (void)m;(void)p;atomic_fetch_add(&pushes,1);if(atomic_load(&pause_fifo))pause_worker();return false;
}
void hrc7000_set_crit(hrc7000_t *m,uint32_t (*a)(void),void (*b)(uint32_t)) {(void)m;(void)a;(void)b;}
void vTaskDelay(unsigned ticks) {assert(ticks==1 && !lock_depth);atomic_fetch_add(&delays,1);sched_yield();}
TaskHandle_t xTaskGetCurrentTaskHandle(void) {return current_task;}
BaseType_t xTaskCreate(void (*fn)(void *),const char *name,unsigned words,void *ctx,unsigned priority,TaskHandle_t *out) {
    (void)fn;(void)name;(void)words;(void)ctx;(void)priority;*out=(void *)1;return pdPASS;
}
uint32_t ulTaskNotifyTake(BaseType_t clear,unsigned ticks) {(void)clear;(void)ticks;return 0;}
void vTaskNotifyGiveFromISR(TaskHandle_t t,BaseType_t *w) {(void)t;*w=0;}
static void route(bool on) {
    assert(!lock_depth && !in_irq);
    if(on && atomic_exchange(&pause_route,false))pause_worker();
    if(on) {atomic_fetch_add(&route_on,1);mock_audio_control|=C7_AUDIO_RING_PLAY;}
    else mock_audio_control&=~C7_AUDIO_RING_PLAY;
}
void normal_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)ctx;assert(!in_irq);atomic_fetch_add(&callbacks,1);out[0]=123;speaker_pcm(true);
}
static void initialize(void) {
    static hrc7000_t m;current_task=(void *)2;hrc_audio_pcm_attach(&m,route);hrc_audio_pcm_output_resume();
}
void *work_thread(void *p) {(void)p;current_task=task;audio_work_once();return NULL;}
void *stop_thread(void *p) {(void)p;current_task=(void *)2;stop();atomic_store(&stop_returned,true);return NULL;}
void *abort_thread(void *p) {(void)p;current_task=(void *)2;hrc_audio_pcm_output_abort();atomic_store(&stop_returned,true);return NULL;}
void run_worker_once(void) {
    TaskHandle_t old=current_task;current_task=task;audio_work_once();current_task=old;
}
void end_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)out;(void)ctx;assert(worker_active && current_task==task);speaker_pcm(false);
}
void end_call_in_worker(void) {
    audio_block_cb_t saved=block_cb;void *saved_ctx=block_ctx;
    block_cb=end_callback;block_ctx=NULL;mic_ready=0;run_worker_once();
    block_cb=saved;block_ctx=saved_ctx;
}
void fire_pcm_rd(void) {
    assert(enabled_irqs[IRQ_PCM_RD] && registered_irqs[IRQ_PCM_RD]);
    assert(!in_irq);in_irq=true;registered_irqs[IRQ_PCM_RD]();in_irq=false;
}
static unsigned pattern_sequence;
int16_t pattern_sample(unsigned i) {return (int16_t)(0x8123u+i*257u);}
void pattern_callback(const int16_t *mic,int16_t *out,void *ctx) {
    (void)mic;(void)ctx;assert(!in_irq && !lock_depth && current_task==task);
    atomic_fetch_add(&callbacks,1);
    for(unsigned i=0;i<160;++i)out[i]=pattern_sample(pattern_sequence+i);
    pattern_sequence+=160;speaker_pcm(true);
}
void check_pcm_bytes(const uint8_t *bytes,unsigned first) {
    for(unsigned i=0;i<80;++i) {
        uint16_t expected=(uint16_t)pattern_sample(first+i);
        assert(bytes[2*i]==(uint8_t)expected && bytes[2*i+1]==(uint8_t)(expected>>8));
    }
}
'''


if __name__=="__main__":unittest.main()
