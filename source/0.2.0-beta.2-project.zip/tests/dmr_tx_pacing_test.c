// SPDX-License-Identifier: GPL-3.0-or-later
// Deterministic scheduling tests of the pinned call, AMBE/FEC and modem engines.
// The mock vocoder returns immediately: these tests isolate service starvation,
// and make no claim about the native codec's measured execution cost.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "radio_dmr.h"
#include "radio_dmr_metrics.h"
#include "dmr/ambe/ambeVoice.h"
#include "dmr/ambe/ambeFec.h"
#include "sim/dmr_sim_modem.h"

static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) { fprintf(stderr,"%s:%d: %s\n",__FILE__,__LINE__,#x); exit(1); } } while (0)
static radio_dmr backend;
static bool owned, keyed, running_audio, output_blocked, tx_allowed=true;
static audio_block_cb_t callback;
static void *callback_ctx;
static uint32_t clock_base, now_ms, prior_encode, prior_poll, encode_gap_max, poll_gap_max;
static unsigned encodes, releases, tx_begins, poll_count, ui_ticks;
static bool encode_seen, poll_seen;

void hrc_audio_pcm_output_abort(void) { output_blocked=true; }
void hrc_audio_pcm_output_resume(void) { CHECK(!keyed);output_blocked=false; }
static bool acquire(void *ctx) { (void)ctx;CHECK(!owned);owned=true;return true; }
static void release_owner(void *ctx) { (void)ctx;CHECK(owned && !keyed && !running_audio);owned=false;++releases; }
static void set_mode(radio_mode_t mode) { (void)mode;CHECK(owned); }
static bool tune(uint32_t hz,radio_bw_t bw,const subtone_t *tone) {
    CHECK(owned && hz==145700000u && bw==RADIO_BW_12K5 && !tone);return true;
}
static bool transmit(uint32_t hz,radio_bw_t bw,uint8_t power,const subtone_t *tone) {
    (void)power;CHECK(tune(hz,bw,tone) && output_blocked);++tx_begins;keyed=tx_allowed;return tx_allowed;
}
static void unkey(void) { CHECK(owned);keyed=false; }
static void board_audio(bool on) { CHECK(!on); }
static bool audio_start(audio_block_cb_t cb,void *ctx) { CHECK(owned);callback=cb;callback_ctx=ctx;running_audio=true;return true; }
static void audio_stop(void) { callback=NULL;running_audio=false; }
static void speaker(bool on) { CHECK(!on); }
static bool codec_present(void) { return owned; }
static void codec_reset(void) {}
static void encode(const int16_t pcm[160],uint8_t bits[49]) {
    (void)pcm;CHECK(owned && running_audio && keyed);
    if(encode_seen) {uint32_t gap=now_ms-prior_encode;CHECK(gap==20u);if(gap>encode_gap_max)encode_gap_max=gap;}
    encode_seen=true;prior_encode=now_ms;++encodes;
    // Carry an independently FEC-decodable sequence, not a repeated fake tone.
    for(unsigned i=0;i<49;++i)bits[i]=(uint8_t)((encodes>>(i%16u))&1u);
}
static void decode(const uint8_t bits[49],int16_t pcm[160]) { (void)bits;(void)pcm;CHECK(false); }
static const hal_radio_t radio={.set_mode=set_mode,.rx=tune,.tx=transmit,.tx_off=unkey,.audio=board_audio};
static const hal_audio_t audio={.start=audio_start,.stop=audio_stop,.speaker_pcm=speaker};
static const hal_vocoder_t codec={.present=codec_present,.reset=codec_reset,.encode=encode,.decode=decode};

static void setup(unsigned tot_s,uint32_t base) {
    radio_dmr_stop(&backend);sim_reset();memset(&backend,0,sizeof backend);
    owned=keyed=running_audio=output_blocked=false;tx_allowed=true;callback=NULL;
    encodes=releases=tx_begins=poll_count=ui_ticks=0;encode_seen=poll_seen=false;
    encode_gap_max=poll_gap_max=0;clock_base=now_ms=base;
    ambeVoiceResetStats();
    radio_dmr_hal hal={.radio=&radio,.modem=&sim_modem,.audio=&audio,.vocoder=&codec,
        .acquire=acquire,.release=release_owner};
    radio_dmr_init(&backend,&hal);
    radio_dmr_config config={.rx_hz=145700000,.tx_hz=145700000,.source_id=1234567,
        .target_id=98638,.tot_s=(uint16_t)tot_s,.cc=1,.ts=2,.owner_permission=true};
    CHECK(radio_dmr_start(&backend,&config));CHECK(!output_blocked && owned);
}

typedef struct {
    unsigned release_at, stall_from, stall_until, audio_from;
    bool cooperative_ui, background_events, allowed;
} schedule_t;

static void run(unsigned from,unsigned until,const schedule_t *schedule) {
    for(unsigned t=from;t<=until;++t) {
        now_ms=clock_base+t;
        if(t && t%30u==0) {
            sim_slot();
            // Explicit pressure case: additional modem events from the other
            // slot. A pure TX stall alone need not overflow the 8-entry EVQ:
            // four queued bursts emit at most eight started/ended events.
            if(schedule->background_events)sim_event(DMR_EV_VOICE_LOST,1);
        }
        if(t%20u==0 && t>=schedule->audio_from && running_audio && callback) {
            int16_t mic[160]={0},spk[160];callback(mic,spk,callback_ctx);
        }
        bool ui_busy=t>=schedule->stall_from && t<schedule->stall_until;
        if(ui_busy)++ui_ticks;
        if(t%2u==0 && (!ui_busy || schedule->cooperative_ui)) {
            if(poll_seen && now_ms-prior_poll>poll_gap_max)poll_gap_max=now_ms-prior_poll;
            poll_seen=true;prior_poll=now_ms;++poll_count;
            radio_dmr_poll(&backend,now_ms,t>=40u && t<schedule->release_at,schedule->allowed);
        }
    }
}

static radio_dmr_diagnostics diagnostics(void) {
    radio_dmr_diagnostics d;CHECK(radio_dmr_get_diagnostics(&backend,&d));return d;
}

static unsigned check_air(bool continuous) {
    CHECK(sim.air_count>DMR_CALL_TX_HEADERS);
    CHECK(sim.air[0].kind==DMR_BURST_VOICE_LC_HEADER);
    CHECK(sim.air[sim.air_count-1].kind==DMR_BURST_TERMINATOR_LC);
    unsigned frames=0,previous_sequence=0,voice_index=0;
    for(unsigned i=0;i<sim.air_count;++i) {
        const sim_air_t *burst=&sim.air[i];
        if(i && continuous)CHECK(burst->slot-sim.air[i-1].slot==2u); // 60 ms RF.
        if(burst->kind!=DMR_BURST_VOICE)continue;
        CHECK(burst->len==27 && burst->voice_index==voice_index);
        voice_index=(voice_index+1u)%6u;
        for(unsigned j=0;j<3;++j) {
            const uint8_t *frame=&burst->payload[j*9u];
            if(!memcmp(frame,dmr_ambe_silence,9)) {CHECK(!continuous);continue;}
            uint8_t bits[49];ambe_fec_result_t result;ambeFecDecode(frame,bits,&result);
            CHECK(!result.c0_failed && !result.errors);
            unsigned sequence=0;for(unsigned k=0;k<16;++k)sequence|=(unsigned)bits[k]<<k;
            CHECK(sequence>previous_sequence);
            if(continuous && previous_sequence)CHECK(sequence==previous_sequence+1u);
            previous_sequence=sequence;++frames;
        }
    }
    CHECK(frames>10);return frames;
}

static void blocked_controller(void) {
    setup(30,0);schedule_t s={.release_at=2040,.stall_from=250,.stall_until=850,.allowed=true};
    run(0,4000,&s);radio_dmr_diagnostics d=diagnostics();
    printf("blocked: encode_gap=%lu poll_gap=%lu overflow=%lu source_empty=%lu modem_empty=%u events=%lu\n",
        (unsigned long)encode_gap_max,(unsigned long)poll_gap_max,(unsigned long)d.encoded_overflows,
        (unsigned long)d.source_underruns,sim.underflows,(unsigned long)d.event_overflows);
    CHECK(d.result==RADIO_DMR_TX_COMPLETE && d.calls==1);
    CHECK(encode_gap_max==20 && poll_gap_max>=600 && ui_ticks==600);
    CHECK(d.encoded_overflows>0 && sim.underflows>0);
    // The unserviced caller did not request silence itself. Driver/RF gaps
    // remain real even with this one call-level counter equal to zero.
    CHECK(!d.source_underruns && !d.event_overflows);
    CHECK(d.mic_blocks==encodes && d.encoded_frames+d.encoded_overflows==encodes);
    CHECK(check_air(false)>10);radio_dmr_stop(&backend);
}

static void event_pressure(void) {
    setup(30,0);schedule_t s={.release_at=2040,.stall_from=250,.stall_until=850,
        .background_events=true,.allowed=true};
    run(0,4000,&s);radio_dmr_diagnostics d=diagnostics();
    printf("events: overflow=%lu source_empty=%lu modem_empty=%u events=%lu\n",
        (unsigned long)d.encoded_overflows,(unsigned long)d.source_underruns,
        sim.underflows,(unsigned long)d.event_overflows);
    CHECK(d.encoded_overflows>0 && sim.underflows>0 && d.event_overflows>0);
    CHECK(encode_gap_max==20);CHECK(d.result==RADIO_DMR_TX_COMPLETE);radio_dmr_stop(&backend);
}

static void delayed_audio_and_controller(void) {
    setup(30,0);schedule_t s={.release_at=2040,.stall_from=250,.stall_until=850,
        .audio_from=200,.background_events=true,.allowed=true};
    run(0,4000,&s);radio_dmr_diagnostics d=diagnostics();
    // Delayed initial audio admission produces source silence independently
    // of the later controller stall; every encoder call still has a 20 ms gap.
    CHECK(encode_gap_max==20 && d.source_underruns>2);
    CHECK(d.encoded_overflows>0 && d.event_overflows>0 && sim.underflows>0);
    CHECK(d.result==RADIO_DMR_TX_COMPLETE && d.mic_blocks==encodes);
    radio_dmr_stop(&backend);
}

static void serviced_ui(bool wrap) {
    setup(30,wrap ? UINT32_MAX-500u : 0u);
    schedule_t s={.release_at=6040,.stall_from=250,.stall_until=2850,.cooperative_ui=true,.allowed=true};
    run(0,7600,&s);radio_dmr_diagnostics d=diagnostics();
    CHECK(d.result==RADIO_DMR_TX_COMPLETE && !keyed && !output_blocked);
    CHECK(encode_gap_max==20 && poll_gap_max==2 && ui_ticks==2600 && poll_count>3000);
    CHECK(!d.encoded_overflows && !d.source_underruns && !d.event_overflows && !sim.underflows);
    CHECK(check_air(true)>250);radio_dmr_stop(&backend);CHECK(releases==1);
}

static void tot_and_held_ptt(void) {
    setup(1,0);schedule_t s={.release_at=10000,.stall_from=250,.stall_until=2850,
        .cooperative_ui=true,.allowed=true};
    run(0,4000,&s);radio_dmr_diagnostics d=diagnostics();
    CHECK(d.result==RADIO_DMR_TX_FAILED && d.tx_error==DMR_TX_ERR_TIMEOUT);
    CHECK(tx_begins==1 && !keyed && !output_blocked && !d.encoded_overflows && !sim.underflows);
    CHECK(check_air(true)>10);run(4001,5000,&s);CHECK(tx_begins==1);
    radio_dmr_stop(&backend);
}

static void failures_and_lifecycle(void) {
    setup(30,0);schedule_t s={.release_at=2040,.cooperative_ui=true,.allowed=true};
    tx_allowed=false;run(0,1000,&s);radio_dmr_diagnostics d=diagnostics();
    CHECK(d.result==RADIO_DMR_TX_FAILED && d.backend_error==RADIO_DMR_TX_REFUSED);
    CHECK(!encodes && !sim.tx_begins && !keyed && !output_blocked);
    radio_dmr_stop(&backend);CHECK(!owned && releases==1 && output_blocked);
    setup(30,0);sim.stalled=true;run(0,2500,&s);d=diagnostics();
    CHECK(d.result==RADIO_DMR_TX_FAILED && d.tx_error==DMR_TX_ERR_STALLED && !keyed);
    radio_dmr_stop(&backend);CHECK(!running_audio && !owned);
    setup(30,0);run(0,900,&s);CHECK(keyed && running_audio);
    radio_dmr_stop(&backend);CHECK(!owned && !keyed && !running_audio && output_blocked);
    d=diagnostics();CHECK(d.result==RADIO_DMR_TX_ABORTED && d.encoded_frames>0);
    // A replacement owner starts with no old call, queued air or auto-rekey.
    setup(30,0);s.release_at=0;run(0,500,&s);CHECK(!encodes && !keyed && !sim.tx_begins);
    radio_dmr_stop(&backend);
}

int main(int argc,char **argv) {
    CHECK(argc==2);
    if(!strcmp(argv[1],"blocked"))blocked_controller();
    else if(!strcmp(argv[1],"events"))event_pressure();
    else if(!strcmp(argv[1],"combined"))delayed_audio_and_controller();
    else if(!strcmp(argv[1],"serviced"))serviced_ui(false);
    else if(!strcmp(argv[1],"wrap"))serviced_ui(true);
    else if(!strcmp(argv[1],"tot"))tot_and_held_ptt();
    else if(!strcmp(argv[1],"lifecycle"))failures_and_lifecycle();
    else CHECK(false);
    printf("%u checks passed\n",checks);return 0;
}
