"""Run the selected upstream regressions against generated, pinned DMR sources.

The same upstream suites must fail with their fixes removed, so a passing suite
cannot silently test an unselected replacement or lose the relevant regression.
"""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = ROOT / "external/RadioFoundry/RadioFoundry"
SPEC = importlib.util.spec_from_file_location("dmr_backports", ROOT / "scripts/generate-dmr-backports.py")
GEN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GEN)


class DmrBackportsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cc = shutil.which("gcc") or shutil.which("cc")
        if not cls.cc:
            raise unittest.SkipTest("host C compiler unavailable")
        cls.tmp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.tmp.cleanup)
        cls.root = Path(cls.tmp.name)
        for path in GEN.PINNED_SHA256:
            out = cls.root / path
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(GEN.generate(path, (UPSTREAM / path).read_text()), newline="\n")
        cls.common = [cls.cc, "-std=gnu99", "-Wall", "-Wextra", "-Wno-unused-parameter", "-Werror", "-g",
                      "-I" + str(cls.root / "core"),
                      "-I" + str(UPSTREAM / "core"), "-I" + str(UPSTREAM / "drivers"),
                      "-I" + str(UPSTREAM / "hal"), "-I" + str(UPSTREAM / "tests/host")]

    def run_suite(self, kind, remove_fix=False, split=False):
        stem = kind + ("-unfixed" if remove_fix else "") + ("-split" if split else "")
        exe = self.root / (stem + ".exe")
        if kind == "call":
            source = self.root / "core/dmr/call/dmr_call.c"
            if remove_fix:
                source = self.root / "unfixed-call.c"
                source.write_text((UPSTREAM / "core/dmr/call/dmr_call.c").read_text())
            sources = [self.root / "tests/host/dmrCallTest.c", UPSTREAM / "tests/host/sim/dmr_sim_modem.c", source]
            sources += [UPSTREAM / path for path in ("core/dmr/call/dmr_lc.c", "core/dmr/sfr.c", "core/dmr/dmrData.c",
                        "core/hotspot/dmrDataFrame.c", "core/dmr/fec/dmrFec.c", "core/dmr/dmrPrivacy.c",
                        "core/dmr/ambe/ambeFec.c")]
            flags = ["-Wshadow", "-DHAS_SFR", "-DDMR_RX_TRACE=0"]
        else:
            source = self.root / "drivers/modem/hrc7000/hrc7000_dmr.c"
            if remove_fix:
                source = self.root / "unfixed-driver.c"
                source.write_text((UPSTREAM / "drivers/modem/hrc7000/hrc7000_dmr.c").read_text())
            sources = [self.root / "tests/host/hrc7000DmrTest.c", source, UPSTREAM / "drivers/modem/hrc7000/hrc7000.c"]
            flags = ["-Wshadow", "-I" + str(UPSTREAM / "drivers/modem/hrc7000")]
            if split:
                flags.append("-DCONFIG_HOTSPOT_SPLIT=1")
                sources.append(UPSTREAM / "drivers/modem/hrc7000/hrc7000_bs.c")
        built = subprocess.run(self.common + flags + list(map(str, sources)) + ["-o", str(exe)],
                               capture_output=True, text=True, timeout=90)
        self.assertEqual(built.returncode, 0, built.stdout + built.stderr)
        run = subprocess.run([str(exe)], capture_output=True, text=True, timeout=30)
        if remove_fix:
            self.assertNotEqual(run.returncode, 0, "Upstream regression did not detect removal of its fix")
            self.assertIn("FAIL ", run.stdout)
        else:
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            self.assertNotIn("FAIL ", run.stdout)

    def test_upstream_call_suite_with_parrot_and_echo_guard(self):
        self.run_suite("call")

    def test_call_regressions_fail_without_backport(self):
        self.run_suite("call", remove_fix=True)

    def test_upstream_slot_engine_suite_with_restart(self):
        self.run_suite("driver")

    def test_slot_engine_split_configuration(self):
        self.run_suite("driver", split=True)

    def test_restart_regressions_fail_without_backport(self):
        self.run_suite("driver", remove_fix=True)

    def test_changed_source_refused(self):
        for path in GEN.PINNED_SHA256:
            with self.subTest(path=path), self.assertRaises(ValueError):
                GEN.generate(path, (UPSTREAM / path).read_text() + "\n")

    def test_unknown_source_refused(self):
        with self.assertRaises(ValueError):
            GEN.generate("core/other.c", "")

    def test_changed_patch_refused(self):
        patch_dir = self.root / "tampered-patches"
        patch_dir.mkdir()
        for name in GEN.PATCH_SHA256:
            shutil.copyfile(GEN.PATCH_DIR / name, patch_dir / name)
        with (patch_dir / next(iter(GEN.PATCH_SHA256))).open("a") as changed:
            changed.write("\n")
        with mock.patch.object(GEN, "PATCH_DIR", patch_dir), self.assertRaisesRegex(ValueError, "patch changed"):
            GEN.patches()

    def test_make_selects_generated_objects_only_for_unified_firmware(self):
        make = shutil.which("make") or shutil.which("mingw32-make")
        if not make:
            self.skipTest("GNU make unavailable")
        project = self.root / "make-selection"
        project.mkdir()
        (project / "overlay.mk").write_text((ROOT / "src/firmware/radiofoundry-imbe-bench.mk").read_text())
        (project / "Makefile").write_text("""BUILD := build/native
TARGET := $(BUILD)/radio
BOARD := dm32
OBJ := $(BUILD)/core/dmr/call/dmr_call.o $(BUILD)/drivers/modem/hrc7000/hrc7000_dmr.o $(BUILD)/keep.o
audit-select:
\t@echo SELECTED=$(OBJ)
""")
        for live in (0, 1):
            run = subprocess.run([make, "--no-print-directory", "-f", "overlay.mk", "audit-select",
                                  "PROJECT_ROOT=" + project.as_posix(), "BENCH_LIVE_RF=" + str(live)],
                                 cwd=project, capture_output=True, text=True, timeout=15)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            selected = run.stdout.split("SELECTED=", 1)[1].strip().split()
            for old, new in (("build/native/core/dmr/call/dmr_call.o", "build/native/multimode/dmr_call.o"),
                             ("build/native/drivers/modem/hrc7000/hrc7000_dmr.o", "build/native/multimode/hrc7000_dmr.o")):
                self.assertEqual(selected.count(old), 0 if live else 1)
                self.assertEqual(selected.count(new), 1 if live else 0)
            self.assertIn("build/native/keep.o", selected)

    def test_cli_cannot_write_external_checkout(self):
        path = "core/dmr/call/dmr_call.c"
        result = subprocess.run([shutil.which("python") or "python", str(ROOT / "scripts/generate-dmr-backports.py"),
                                 path, str(UPSTREAM / path), str(UPSTREAM / "must-not-be-created.c")],
                                capture_output=True, text=True, timeout=15)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("ignored project build directory", result.stderr)
        self.assertFalse((UPSTREAM / "must-not-be-created.c").exists())


if __name__ == "__main__":
    unittest.main()
