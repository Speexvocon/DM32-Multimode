"""Exact fixed-pattern exports, physical alignment, provenance and safe output."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/export-p25-fixed.py"
SPEC = importlib.util.spec_from_file_location("fixed_export", SCRIPT)
fixed = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(fixed)


class FixedExport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.craft = fixed.channel_ref.reference()

    def test_all_alignments_profiles_and_pair_extremes(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(fixed.channel_ref, "reference", return_value=self.craft):
            for nac, tg, src in ((0x293, 10, 1234567), (0, 0, 0), (0xFFF, 0xFFFF, 0xFFFFFF)):
                units = fixed.channel_ref.call(self.craft, nac, tg, src)
                expected_units = {"hdu.bin": units[:99], "ldu1.bin": units[99:315],
                                  "ldu2.bin": units[315:531], "tdu.bin": units[531:]}
                for pairs in (1, 28):
                    phases = set()
                    for extra in range(36):
                        with self.subTest(nac=nac, tg=tg, src=src, pairs=pairs, extra=extra):
                            out = Path(temp) / f"{nac}-{tg}-{src}-{pairs}-{extra}"
                            result = fixed.export(out, nac=nac, talkgroup=tg, source_id=src,
                                                  pairs=pairs, startup_extra=extra)
                            self.assertEqual(json.loads((out / "manifest.json").read_text()), result)
                            for name, data in expected_units.items():
                                self.assertEqual((out / name).read_bytes(), data)
                            call = units[:99] + units[99:531] * pairs + units[531:]
                            stream = b"\x77" * (240 + extra) + call
                            self.assertEqual((out / "call.bin").read_bytes(), call)
                            self.assertEqual((out / "tx-stream.bin").read_bytes(), stream)
                            transport = (out / "transport.bin").read_bytes()
                            self.assertEqual(transport, stream + b"\x77" * (-len(stream) % 36))
                            self.assertEqual(len(transport) % 36, 0)
                            self.assertEqual(result["ldu_first_byte_offset"], 339 + extra)
                            self.assertEqual(result["ldu_phase_mod36"], (339 + extra) % 36)
                            self.assertEqual(result["ldu_last_byte_phase_mod36"], (339 + extra + 215) % 36)
                            self.assertEqual(result["voice_frames_20ms"], pairs * 18)
                            self.assertEqual(result["transport_tail_bytes"], -len(stream) % 36)
                            phases.add(result["ldu_phase_mod36"])
                            for name, record in result["files"].items():
                                data = (out / name).read_bytes()
                                self.assertEqual(record, {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
                    self.assertEqual(phases, set(range(36)))

    def test_original_fixture_unchanged(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "original"
            fixed.export(out, talkgroup=1, source_id=1, pairs=28)
            for name in ("call.bin", "tx-stream.bin"):
                self.assertEqual((out / name).read_bytes(), (ROOT / "fixtures/p25-1011" / name).read_bytes())

    def test_invalid_values_leave_no_output(self):
        cases = [(name, value) for name, values in (
            ("nac", (-1, 4096, True)), ("talkgroup", (-1, 65536, False)),
            ("source_id", (-1, 16777216, True)), ("pairs", (0, 29, 1.5)),
            ("startup_extra", (-1, 36, True))) for value in values]
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "invalid"
            for name, value in cases:
                with self.subTest(name=name, value=value), self.assertRaises(ValueError):
                    fixed.export(out, **{name: value})
                self.assertFalse(out.exists())

    def test_refuses_existing_directory_or_file_without_changing_content(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "existing"
            fixed.export(out)
            before = {p.name: p.read_bytes() for p in out.iterdir()}
            with self.assertRaises(FileExistsError):
                fixed.export(out, startup_extra=1)
            self.assertEqual({p.name: p.read_bytes() for p in out.iterdir()}, before)
            file_path = Path(temp) / "file"
            file_path.write_bytes(b"keep")
            with self.assertRaises(FileExistsError):
                fixed.export(file_path)
            self.assertEqual(file_path.read_bytes(), b"keep")

    def test_reference_tamper_refused(self):
        with tempfile.TemporaryDirectory() as temp:
            craft = Path(temp) / "p25craft.py"
            craft.write_bytes(b"changed reference")
            out = Path(temp) / "output"
            with patch.object(fixed.channel_ref, "CRAFT", craft), self.assertRaisesRegex(ValueError, "pinned"):
                fixed.export(out)
            self.assertFalse(out.exists())

    def test_cli_defaults_hex_and_bad_arguments(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "default"
            result = subprocess.run([sys.executable, str(SCRIPT), "--output", str(out)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            manifest = json.loads((out / "manifest.json").read_text())
            self.assertEqual((manifest["nac_hex"], manifest["talkgroup"], manifest["source_id"],
                              manifest["ldu_pairs"], manifest["startup_extra_bytes"]),
                             ("293", 10, 1234567, 14, 0))
            custom = Path(temp) / "custom"
            result = subprocess.run([sys.executable, str(SCRIPT), "--nac", "2A3", "--pairs", "1",
                                     "--startup-extra", "35", "--output", str(custom)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads((custom / "manifest.json").read_text())["nac_hex"], "2A3")
            for option, value in (("--nac", "xyz"), ("--nac", "1000"), ("--tg", "65536"),
                                  ("--source", "16777216"), ("--pairs", "0"), ("--startup-extra", "36")):
                bad = Path(temp) / "bad"
                result = subprocess.run([sys.executable, str(SCRIPT), option, value, "--output", str(bad)],
                                        capture_output=True, text=True)
                self.assertEqual(result.returncode, 2, (option, result.stderr))
                self.assertFalse(bad.exists())
            result = subprocess.run([sys.executable, str(SCRIPT), "--output", str(out)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)


if __name__ == "__main__":
    unittest.main()
