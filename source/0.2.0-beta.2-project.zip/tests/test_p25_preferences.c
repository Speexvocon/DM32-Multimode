// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "p25_preferences.h"
static uint8_t mem[32768];static int budget=-1;
static unsigned erases,writes,reads;static uint32_t last_erased;
static bool rd(uint32_t a,void *p,uint32_t n) {
 assert(a>=0x711000 && a+n<=0x719000);++reads;memcpy(p,mem+a-0x711000,n);return true;
}
static bool wr(uint32_t a,const void *p,uint32_t n) {
 assert(a>=0x711000 && a+n<=0x719000);++writes;
 for(unsigned i=0;i<n;++i) {if(!budget)return false;if(budget>0)--budget;mem[a-0x711000+i]&=((const uint8_t *)p)[i];}return true;
}
static bool erase(uint32_t a) {
 assert(a>=0x711000 && a<0x719000 && !(a%4096));++erases;last_erased=a;
 memset(mem+a-0x711000,255,4096);return true;
}
static const hal_flash_map_t map={.settings_addr=0x711000,.settings_size=32768};
static const hal_flash_t flash={.size=0x1000000,.erase_size=4096,.read=rd,.write=wr,.erase=erase,.map=&map};
static const p25_preferences profile={145700000,145700000,0x293,10,1234567,0,22,0,0};
// Independent on-flash fixtures: little-endian fields and CRC-32 calculated
// outside the implementation. V1 has no TX-permission field at byte40.
static const uint8_t legacy[64]={
 0x50,0x32,0x35,0x50,0x01,0x00,0x00,0x00,
 0x07,0x00,0x00,0x00,0xa0,0x34,0xaf,0x08,
 0xa0,0x34,0xaf,0x08,0x93,0x02,0x00,0x00,
 0x0a,0x00,0x00,0x00,0x87,0xd6,0x12,0x00,
 0x00,0x00,0x00,0x00,0x16,0x00,0x00,0x00,
 0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
 0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
 0xdd,0xb7,0xcb,0x2c,0x00,0x00,0x00,0x00,
};
static const uint8_t version2[64]={
 0x50,0x32,0x35,0x50,0x02,0x00,0x00,0x00,
 0x08,0x00,0x00,0x00,0xa0,0x34,0xaf,0x08,
 0xa0,0x34,0xaf,0x08,0x93,0x02,0x00,0x00,
 0x0a,0x00,0x00,0x00,0x87,0xd6,0x12,0x00,
 0x00,0x00,0x00,0x00,0x16,0x00,0x00,0x00,
 0x00,0x00,0x00,0x00,0xff,0xff,0xff,0xff,
 0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
 0xd5,0xe1,0x31,0x03,0x00,0x00,0x00,0x00,
};
static const uint8_t version3[64]={
 0x50,0x32,0x35,0x50,0x03,0x00,0x00,0x00,
 0x09,0x00,0x00,0x00,0xa0,0x34,0xaf,0x08,
 0xa0,0x34,0xaf,0x08,0x93,0x02,0x00,0x00,
 0x0a,0x00,0x00,0x00,0x87,0xd6,0x12,0x00,
 0x00,0x00,0x00,0x00,0x16,0x00,0x00,0x00,
 0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
 0x8e,0x84,0xa5,0x0c,0x00,0x00,0x00,0x00,
};
static void fresh(void) {memset(mem,255,sizeof mem);budget=-1;erases=writes=reads=0;last_erased=0;}
static void checksum(uint8_t *b) {pref_put(b+56,pref_crc(b,56));}
static void old_record(unsigned slot,uint32_t seq,uint32_t tg) {
 uint8_t *b=mem+slot*64;memcpy(b,legacy,64);pref_put(b+8,seq);pref_put(b+24,tg);checksum(b);
}
static void v2_record(unsigned slot,uint32_t seq,uint32_t tg,uint32_t inhibit) {
 uint8_t *b=mem+slot*64;memcpy(b,version2,64);pref_put(b+8,seq);pref_put(b+24,tg);pref_put(b+40,inhibit);checksum(b);
}
static void new_record(unsigned slot,uint32_t seq,uint32_t tg,uint32_t inhibit,uint32_t prom) {
 p25_preferences p=profile;p.tg=tg;p.tx_inhibit=inhibit;p.prom_mode=prom;pref_pack(mem+slot*64,&p,seq);
}
static void test_literals_and_migration(void) {
 p25_preferences p,out;p25_pref_store st,boot;uint8_t b[64],original[32768];
 assert(pref_unpack(legacy,&out));assert(!memcmp(&out,&profile,sizeof out));
 assert(pref_unpack(version2,&out) && !memcmp(&out,&profile,sizeof out));
 p=profile;p.prom_mode=1;pref_pack(b,&p,9);assert(!memcmp(b,version3,64));
 assert(pref_unpack(version3,&out) && !memcmp(&out,&p,sizeof out));
 for(unsigned inhibit=0;inhibit<2;++inhibit)for(unsigned prom=0;prom<2;++prom) {
  p=profile;p.tx_inhibit=inhibit;p.prom_mode=prom;pref_pack(b,&p,10);
  assert(pref_get(b+4)==3 && pref_get(b+40)==inhibit && pref_get(b+44)==prom);
  assert(!pref_get(b+48) && !pref_get(b+52));
  assert(pref_unpack(b,&out) && !memcmp(&out,&p,sizeof out));
 }
 fresh();memcpy(mem,legacy,64);memcpy(original,mem,sizeof mem);
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7 && out.tx_inhibit==0 && out.prom_mode==0);
 assert(!writes && !erases && !memcmp(mem,original,sizeof mem)); // no eager migration
 assert(out.rx==145700000 && out.tg==10 && out.id==1234567 && out.mic_db==22);
 // An explicit save upgrades the record only; the V1 bytes remain untouched.
 assert(pref_save(&st,&out));assert(!memcmp(mem,legacy,64));
 assert(pref_get(mem+64+4)==3 && !pref_get(mem+64+40) && !pref_get(mem+64+44));
 assert(pref_load(&boot,&flash,&out) && boot.seq==8 && !out.tx_inhibit && !out.prom_mode);
 out.tx_inhibit=1;out.prom_mode=1;assert(pref_save(&boot,&out));
 assert(pref_load(&st,&flash,&out) && st.seq==9 && out.tx_inhibit==1 && out.prom_mode==1 && out.mic_db==22);
 // V1 reserved bytes never grant new semantics; normal TX/filtered RX are defaults.
 fresh();memcpy(mem,legacy,64);pref_put(mem+40,2);pref_put(mem+44,1);checksum(mem);
 assert(pref_load(&st,&flash,&out) && st.writable && !out.tx_inhibit && !out.prom_mode);
 // V2 preserves either owner choice but ignores its former reserved PROM word.
 for(unsigned inhibit=0;inhibit<2;++inhibit) {
  fresh();v2_record(0,8,10,inhibit);pref_put(mem+44,1);checksum(mem);memcpy(original,mem,sizeof mem);
  assert(pref_load(&st,&flash,&out) && st.writable && out.tx_inhibit==inhibit && !out.prom_mode);
  assert(!writes && !erases && !memcmp(mem,original,sizeof mem));
  assert(pref_save(&st,&out) && !memcmp(mem,original,64));
  assert(pref_load(&boot,&flash,&out) && boot.seq==9 && out.tx_inhibit==inhibit && !out.prom_mode);
 }
}
static void test_mixed_versions_and_wrap(void) {
 p25_preferences out;p25_pref_store st;
 fresh();old_record(0,7,10);v2_record(1,8,123,1);new_record(2,9,321,0,1);
 assert(pref_load(&st,&flash,&out) && st.writable && st.slot==2 && st.seq==9 && out.tg==321 && !out.tx_inhibit && out.prom_mode==1);
 // Every version can be the latest; physical placement does not supersede sequence.
 v2_record(1,10,234,1);
 assert(pref_load(&st,&flash,&out) && st.writable && st.slot==1 && st.seq==10 && out.tg==234 && out.tx_inhibit==1 && !out.prom_mode);
 old_record(100,11,456);
 assert(pref_load(&st,&flash,&out) && st.writable && st.slot==100 && st.seq==11 && out.tg==456 && !out.tx_inhibit && !out.prom_mode);
 fresh();new_record(0,9,321,1,1);v2_record(1,8,123,1);old_record(2,7,10);
 assert(pref_load(&st,&flash,&out) && st.writable && st.slot==0 && out.tg==321 && out.tx_inhibit==1 && out.prom_mode==1);
 // Modular sequence ordering crosses UINT32_MAX across all three formats.
 fresh();old_record(0,UINT32_MAX-1,10);v2_record(1,UINT32_MAX,20,1);new_record(2,0,30,0,1);
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==0 && out.tg==30 && !out.tx_inhibit && out.prom_mode==1);
 old_record(3,1,40);
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==1 && out.tg==40 && !out.tx_inhibit && !out.prom_mode);
 out.tg=50;assert(pref_save(&st,&out));
 assert(pref_load(&st,&flash,&out) && st.seq==2 && out.tg==50 && !out.tx_inhibit && !out.prom_mode);
}
static void test_torn_writes(void) {
 uint8_t original[32768];p25_pref_store st,boot;p25_preferences p,out;
 // All 65 byte cuts, each prior version and all four new owner/PROM choices.
 for(unsigned baseline=1;baseline<=3;++baseline)for(unsigned owner=0;owner<2;++owner)for(unsigned prom=0;prom<2;++prom) {
  unsigned old_owner=baseline==1 ? 0 : !owner,old_prom=baseline==3 ? !prom : 0;
  fresh();
  if(baseline==1)memcpy(mem,legacy,64);
  else if(baseline==2)v2_record(0,7,10,old_owner);
  else new_record(0,7,10,old_owner,old_prom);
  memcpy(original,mem,sizeof mem);
  for(int cut=0;cut<=64;++cut) {
   memcpy(mem,original,sizeof mem);budget=-1;assert(pref_load(&st,&flash,&out));
   p=out;p.tg=123;p.tx_inhibit=owner;p.prom_mode=prom;budget=cut;(void)pref_save(&st,&p);budget=-1;
   unsigned w=writes,e=erases;assert(pref_load(&boot,&flash,&out));assert(writes==w && erases==e);
   assert(out.tg==(cut==64 ? 123u : 10u));assert(out.tx_inhibit==(cut==64 ? owner : old_owner));
   assert(out.prom_mode==(cut==64 ? prom : old_prom));
   assert(boot.seq==(cut==64 ? 8u : 7u));assert(!memcmp(mem,original,64));
   // Incomplete headers can remain foreign/read-only, as in the V1 implementation.
   if(cut>=8)assert(boot.writable);
  }
 }
}
static void test_invalid_records_and_guards(void) {
 p25_preferences out,p=profile;p25_pref_store st;unsigned w,e,r;
 // Both retained-permission versions reject CRC-valid out-of-domain booleans.
 for(unsigned version=2;version<=3;++version) {
  fresh();memcpy(mem,legacy,64);
  if(version==2)v2_record(1,8,123,0);else new_record(1,8,123,0,1);
  pref_put(mem+64+40,2);checksum(mem+64);
  assert(!pref_unpack(mem+64,&out));
  assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7 && !out.tx_inhibit && !out.prom_mode && out.tg==10);
  pref_put(mem+64+40,UINT32_MAX);checksum(mem+64);
  assert(pref_load(&st,&flash,&out) && st.seq==7 && st.writable);
 }
 new_record(1,8,123,0,1);pref_put(mem+64+44,2);checksum(mem+64);
 assert(!pref_unpack(mem+64,&out));
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7 && !out.prom_mode);
 pref_put(mem+64+44,UINT32_MAX);checksum(mem+64);
 assert(pref_load(&st,&flash,&out) && st.seq==7 && st.writable);
 // The V3 reserved area must be zero and remains inside the CRC.
 for(unsigned offset=48;offset<=52;offset+=4) {
  new_record(1,8,123,0,1);pref_put(mem+64+offset,1);checksum(mem+64);
  assert(!pref_unpack(mem+64,&out));
  assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7);
 }
 // Either retained boolean changing without a CRC update falls back.
 new_record(1,8,123,0,1);mem[64+40]^=1;
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7);
 new_record(1,8,123,0,1);mem[64+44]^=1;
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7);
 // Neither an uncommitted record nor a corrupted legacy field supersedes V1.
 new_record(1,8,123,0,1);pref_put(mem+64+60,UINT32_MAX);
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7);
 new_record(1,8,123,0,1);mem[64+24]^=1;
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==7);
 // Unsupported future records lock writes even beside a known valid profile.
 new_record(1,8,123,0,1);pref_put(mem+64+4,4);checksum(mem+64);
 assert(pref_load(&st,&flash,&out) && !st.writable && st.seq==7);
 w=writes;e=erases;assert(!pref_save(&st,&p) && writes==w && erases==e);
 fresh();new_record(0,8,123,0,1);pref_put(mem+4,4);checksum(mem);
 assert(!pref_load(&st,&flash,&out) && !st.writable);
 // Foreign data anywhere in the ring also prevents erase/program operations.
 fresh();memcpy(mem,legacy,64);mem[32704]=0;
 assert(pref_load(&st,&flash,&out) && !st.writable);
 w=writes;e=erases;assert(!pref_save(&st,&p) && writes==w && erases==e);
 // Geometry rejection must precede even reads, including any calibration access.
 hal_flash_t wrong=flash;wrong.erase_size=8192;r=reads;
 assert(!pref_load(&st,&wrong,&out) && !st.writable && reads==r);
 wrong=flash;hal_flash_map_t wrong_map=map;wrong.map=&wrong_map;wrong_map.settings_addr=0x710000;
 assert(!pref_load(&st,&wrong,&out) && !st.writable && reads==r);
 fresh();assert(!pref_load(&st,&flash,&out) && st.writable);
 p.tx_inhibit=2;w=writes;e=erases;assert(!pref_values(&p) && !pref_save(&st,&p) && writes==w && erases==e);
 p=profile;p.prom_mode=2;assert(!pref_values(&p) && !pref_save(&st,&p) && writes==w && erases==e);
 p=profile;p.mic_db=43;assert(!pref_values(&p));p=profile;p.tx++;assert(!pref_values(&p));
}
static void test_mixed_ring_rollover(void) {
 p25_preferences p=profile,out;p25_pref_store st,boot;
 fresh();
 // Fill all eight sectors with all three versions; latest V2 retains owner inhibit.
 for(unsigned i=0;i<512;++i) {
  if(i%3==0)old_record(i,i+1,10);
  else if(i%3==1)v2_record(i,i+1,10,1);
  else new_record(i,i+1,10,0,1);
 }
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==512 && st.slot==511 && out.tx_inhibit==1 && !out.prom_mode);
 uint8_t latest[64];memcpy(latest,mem+511*64,64);
 // Power loss immediately after rollover erase cannot destroy the latest profile.
 budget=0;assert(!pref_save(&st,&p));budget=-1;
 assert(erases==1 && last_erased==0x711000 && !memcmp(latest,mem+511*64,64));
 assert(pref_load(&st,&flash,&out) && st.writable && st.seq==512 && st.slot==511 && out.tx_inhibit==1 && !out.prom_mode);
 for(unsigned n=0;n<1100;++n) {
  unsigned e=erases;uint32_t previous_sector=st.slot/64;
  p.tg=n+1;p.tx_inhibit=n&1;p.prom_mode=(n>>1)&1;assert(pref_save(&st,&p));
  if(erases!=e)assert((last_erased-0x711000)/4096!=previous_sector);
  assert(pref_get(mem+st.slot*64+4)==3 && !pref_get(mem+st.slot*64+48) && !pref_get(mem+st.slot*64+52));
 }
 assert(erases>2 && pref_load(&boot,&flash,&out) && boot.writable && boot.seq==1612 && out.tg==1100 && out.tx_inhibit==1 && out.prom_mode==1);
}
int main(void) {
 test_literals_and_migration();test_mixed_versions_and_wrap();test_torn_writes();
 test_invalid_records_and_guards();test_mixed_ring_rollover();
 puts("Preferences V1/V2/V3: literal migration, owner/PROM retention, 780 torn writes, mixed sequence/wrap, CRC/foreign guards and rollover passed");
}
