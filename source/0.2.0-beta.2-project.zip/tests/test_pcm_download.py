import io
from pathlib import Path
import runpy
import unittest

download = runpy.run_path(str(Path(__file__).resolve().parents[1]/'scripts/p25-pcm-download.py'))['download']


class Port:
    def __init__(self, running=False, bad=False):
        self.lines = []
        self.commands = []
        self.running, self.bad = running, bad

    def write(self, data):
        command = data.decode().strip()
        self.commands.append(command)
        if command == 'STATUS':
            self.lines = ['LIVE active=0 rf=0', f'RXMON enabled={int(self.running)} running={int(self.running)}',
                          'RXTRACE frames=120 kept=112 payloads=120 hash=00000000 from_hdu=1 output=DECODED', 'LIVE_AUDIO peak=0']
        elif command.startswith('RXPCM '):
            _, index, section = command.split()
            seq = int(index)+8
            self.lines = [f'RXPCM {index} {section} {seq+int(self.bad)} '+(seq.to_bytes(2, 'little')*32).hex()]
        elif command.startswith('RXBITS '):
            index = int(command.split()[1])
            self.lines = [f'RXBITS {index} '+bytes([index]*11).hex()]
        else:
            raise AssertionError('Unexpected command '+command)

    def readline(self):
        return (self.lines.pop(0)+'\n').encode()


class DownloadTests(unittest.TestCase):
    def test_chronological_tail_and_payloads(self):
        port = Port()
        status, pcm, bits = download(port, io.StringIO())
        self.assertEqual(len(pcm), 112*320)
        self.assertEqual(len(bits), 120*11)
        self.assertEqual(pcm[:320], b'\x08\x00'*160)
        self.assertEqual(pcm[-320:], b'\x77\x00'*160)
        self.assertEqual(bits[-11:], bytes([119]*11))
        self.assertEqual(status['RXTRACE']['from_hdu'], '1')
        self.assertFalse(any(x.startswith(('ARM', 'SESSION', 'RXMON')) for x in port.commands))

    def test_active_receiver_rejected(self):
        port = Port(running=True)
        with self.assertRaisesRegex(RuntimeError, 'Stop RX/TX'):
            download(port, io.StringIO())
        self.assertEqual(port.commands, ['STATUS'])

    def test_wrong_sequence_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'index mismatch'):
            download(Port(bad=True), io.StringIO())


if __name__ == '__main__':
    unittest.main()
