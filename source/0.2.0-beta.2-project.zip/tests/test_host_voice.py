"""Offline voice boundary checks; no serial/RF operations."""
from pathlib import Path
import hashlib
import json
import math
import random
import struct
import subprocess
import sys
import tempfile
import wave

ROOT = Path(__file__).resolve().parents[1]
EXE = Path(sys.argv[1]).resolve()


def main():
    with tempfile.TemporaryDirectory() as directory:
        work = Path(directory)
        counter = 0

        def run(mode, data, success=True):
            nonlocal counter
            counter += 1
            source, dest = work / f"in-{counter}", work / f"out-{counter}"
            source.write_bytes(data)
            result = subprocess.run([str(EXE), mode, str(source), str(dest)], capture_output=True)
            if success:
                assert result.returncode == 0, result.stderr.decode()
                return dest.read_bytes()
            assert result.returncode != 0, (mode, "unexpected acceptance")
            assert not dest.exists(), "Invalid input produced output"

        # Independent OP25/MMDVM fixture: decode/rebuild must reproduce EVERY bit,
        # including status and the alternating low speech bit, across 504 frames.
        golden = (ROOT / "fixtures/p25-1011/tx-stream.bin").read_bytes()
        golden_payload = run("extract", golden)
        assert len(golden_payload) == 504 * 11
        assert run("frame", golden_payload) == golden

        # Exercise every payload bit and frame position with deterministic varying
        # data, not just a tone. This catches OP25's asymmetric u7 representation.
        rng = random.Random(0x293)
        changing = bytes(rng.randrange(256) for _ in range(504 * 11))
        assert run("extract", run("frame", changing)) == changing

        # Exercise a sustained codec instance over silence and a changing harmonic
        # signal. Separate processes must encode identically; framing is lossless.
        samples = []
        for i in range(36 * 160):
            t = i / 8000
            samples.append(0 if i < 1600 else int(5000 * math.sin(2 * math.pi * 140 * t)
                           + 1500 * math.sin(2 * math.pi * 280 * t)))
        pcm = struct.pack("<" + "h" * len(samples), *samples)
        payload = run("encode", pcm)
        assert len(payload) == 36 * 11 and len(set(payload[i:i+11] for i in range(0,len(payload),11))) > 2
        assert run("encode", pcm) == payload
        recovered = run("extract", run("frame", payload))
        assert recovered == payload
        decoded = run("decode", recovered)
        assert decoded == run("decode", payload) and len(decoded) == len(pcm)
        assert any(struct.unpack("<" + "h" * len(samples), decoded))

        damaged = bytearray(golden)
        damaged[339] ^= 0x80  # LDU sync/control must not be silently accepted.
        run("extract", damaged, False)
        damaged = bytearray(golden)
        damaged[355] ^= 0x80  # Within first voice codeword: strict FEC check.
        run("extract", damaged, False)
        for mode, data in [("encode", b"\0" * 319), ("encode", b""),
                           ("decode", b"\0" * 12), ("frame", payload[:-1]),
                           ("frame", payload + b"\0" * 11),
                           ("frame", b"\0" * (522 * 11)),
                           ("extract", golden[:-1])]:
            run(mode, data, False)
        wav_path = work / "speech.wav"
        # Non-frame-aligned input must be padded as PCM before encoding.
        with wave.open(str(wav_path), "wb") as wav:
            wav.setparams((1, 2, 8000, 0, "NONE", "not compressed"))
            wav.writeframes(pcm[:-34])
        command = [sys.executable, str(ROOT / "scripts/encode-p25-wav.py"),
                   str(wav_path), str(work / "call"), "--tool", str(EXE)]
        result = subprocess.run(command, capture_output=True)
        assert result.returncode == 0, result.stderr.decode()
        manifest = json.loads((work / "call/manifest.json").read_text())
        assert manifest["padding_samples"] == 17
        assert manifest["speech_frames_20ms"] == 36
        assert manifest["payload_roundtrip_exact"]
        assert subprocess.run(command, capture_output=True).returncode != 0
        with wave.open(str(work / "call/decoded.wav"), "rb") as wav:
            assert (wav.getnframes(), wav.getframerate(), wav.getnchannels()) == (5760, 8000, 1)
        with wave.open(str(wav_path), "wb") as wav:
            wav.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
            wav.writeframes(pcm)
        command[3] = str(work / "invalid-call")
        assert subprocess.run(command, capture_output=True).returncode != 0
        assert not (work / "invalid-call").exists()
        print(json.dumps({"independent_fixture_exact": True,
                          "varying_payload_frames_exact": 504,
                          "encoded_audio_frames": 36,
                          "payload_sha256": hashlib.sha256(payload).hexdigest(),
                          "invalid_inputs_rejected": 9,
                          "wav_padding_preview_and_refusals": True,
                          "hardware_access": False}, indent=2))


if __name__ == "__main__":
    main()
