import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('capture',Path(__file__).resolve().parents[1]/'scripts/dm32-rx-capture.py')
capture=importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)

class CaptureTests(unittest.TestCase):
    def test_signal_telemetry(self):
        self.assertEqual(capture.decode_signal('RXSIGNAL 59 5999999 -73 12',59)['elapsed_us'],5999999)
        self.assertEqual(capture.decode_signal('RXSIGNAL 1 100123 -73 12',1),
                         {'elapsed_us':100123,'rssi_dbm_estimate':-73,'noise':12})
        for line in ('RXSIGNAL 2 0 -73 12','RXSIGNAL 1 -1 -73 12','RXSIGNAL 1 0 -73 256'):
            with self.assertRaises(ValueError):capture.decode_signal(line,1)
    def test_raw_bytes_and_metadata(self):
        data=bytes(range(64))
        self.assertEqual(capture.decode_record('RXDATA 4 7 4294967295 2 '+data.hex(),4,7),
                         (data,4294967295,2))

    def test_reject_wrong_slice_short_data_and_bad_half(self):
        good='RXDATA 4 7 123 2 '+'ab'*64
        for value in (good.replace('4 7','4 6'),good[:-2],good.replace('123 2','123 3'),
                      good.replace('123 2','-1 2'),good+' ff'):
            with self.assertRaises(ValueError):capture.decode_record(value,4,7)

if __name__=='__main__':unittest.main()
