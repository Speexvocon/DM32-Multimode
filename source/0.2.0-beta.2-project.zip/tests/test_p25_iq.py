import json
from pathlib import Path
import numpy as np
from scipy import signal
rng=np.random.default_rng(814);fs=48000;n=fs*12
sym=rng.integers(0,4,n//10);lev=np.array([1,3,-1,-3])
sync=np.array([(v>>j)&3 for v in bytes.fromhex('5575f5ff77ff') for j in (6,4,2,0)])
for i in range(480, len(sym)-24,864):sym[i:i+24]=sync
imp=np.zeros(n);imp[::10]=lev[sym]*600
f=np.fft.rfftfreq(n,1/fs);h=np.zeros_like(f);h[f<1920]=1
sel=(f>=1920)&(f<=2880);h[sel]=.5+.5*np.cos(2*np.pi*(f[sel]-1920)/1920)
h/=np.sinc(f/4800)+1e-20
freq=np.fft.irfft(np.fft.rfft(imp)*h,n)*10+123
x=np.exp(2j*np.pi*np.cumsum(freq)/fs)
x=signal.resample_poly(x,64,3)
b=np.empty((len(x),2),np.uint8);b[:,0]=np.clip(np.rint(x.real*75+127.5),0,255);b[:,1]=np.clip(np.rint(x.imag*75+127.5),0,255)
p=Path('build/iq-synthetic.cu8');b.tofile(p)
p.with_suffix('.cu8.json').write_text(json.dumps({'sample_rate':1024000,'center_hz':440075000,'test_counter':False,'sha256':'synthetic validation fixture'}))
print('Created independent synthetic C4FM reference: +/-600,1800 Hz; offset +123 Hz')

import subprocess,sys
subprocess.run([sys.executable,'scripts/analyze-p25-iq.py',str(p),'--start','0','--end','12'],check=True)
r=json.loads(Path('build/iq-synthetic-symbols.json').read_text())
assert max(abs(np.array(r['centered_levels_hz'])-[-1800,-600,600,1800]))<5
assert abs(r['mean_center_hz']-123)<1
assert len(r['sync_hits'])==67 and all(x['sync_symbol_errors']==0 for x in r['sync_hits'])
print('Synthetic deviation, offset and sync checks passed')
