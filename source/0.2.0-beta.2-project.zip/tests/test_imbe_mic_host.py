import importlib.util
from pathlib import Path
import unittest
import contextlib
import io
import json
import subprocess
import sys
import tempfile
import types
import wave
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('mic',Path(__file__).resolve().parents[1]/'scripts/imbe-mic.py')
mic=importlib.util.module_from_spec(spec); spec.loader.exec_module(mic)
class MicHost(unittest.TestCase):
    def setUp(self):
        self.data=bytes(306*11)
        h=2166136261
        for b in self.data: h=((h^b)*16777619)&0xffffffff
        self.status=dict(running='0',rf='disabled',done='1',reason='complete',captured='300',encoded='306',overflow='0',driver_overruns='0',pcm='0',span_us='5980000',peak='0',hash=f'{h:08x}')
    def test_complete_silence_is_transport_pass_not_audio_confirmation(self):
        result=mic.validate(self.status,self.data)
        self.assertTrue(result['transport_pass']); self.assertFalse(result['audio_present'])
    def test_loss_incomplete_and_cadence_rejected(self):
        for key,value in [('running','1'),('rf','enabled'),('driver_overruns','1'),('overflow','1'),('encoded','305'),('captured','299'),('span_us','3000000'),('pcm','1')]:
            with self.subTest(key=key),self.assertRaises(ValueError): mic.validate(dict(self.status,**{key:value}),self.data)
    def test_download_corruption_rejected(self):
        with self.assertRaises(ValueError): mic.validate(self.status,b'\x01'+self.data[1:])
        with self.assertRaises(ValueError): mic.validate(self.status,self.data[:-11])
    def test_full_capture_download_reference_framing_and_wav(self):
        tool=Path(__file__).resolve().parents[1]/'build/host-voice/p25_voice.exe'
        if not tool.exists(): self.skipTest('Build host voice tool for integration test')
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); source=root/'source.imbe'; call=root/'call.bin'
            source.write_bytes(self.data)
            subprocess.run([str(tool),'frame',str(source),str(call)],check=True,stdout=subprocess.DEVNULL)
            h=2166136261
            for b in call.read_bytes()[339:-18]: h=((h^b)*16777619)&0xffffffff
            status='MIC git=test '+' '.join(f'{k}={v}' for k,v in self.status.items())
            class Port:
                def __init__(self,stored=False): self.lines=[]; self.writes=[]; self.stored=stored
                def __enter__(self): return self
                def __exit__(self,*args): pass
                def write(self,data):
                    self.writes.append(data)
                    if data==b'STATUS\n': self.lines+=([status,f'MIC_FRAMING ldus=34 hash={h:08x} sink=none'] if self.stored else ['IMBE git=test running=0 rf=disabled'])
                    elif data in (b'MIC\n',b'MIC_DMR\n',b'MIC_WAIT\n',b'MIC_PHY\n'):
                        ack='OK MIC_PHY 20 seconds' if data==b'MIC_PHY\n' else 'OK MIC_WAIT 20 seconds' if data==b'MIC_WAIT\n' else 'OK MIC 300 live frames'
                        self.lines+=[ack,status,'MIC_HW snapshot=start mode=0000006e txrx=00000000',f'MIC_FRAMING ldus=34 hash={h:08x} sink=none']
                    elif data==b'STOP\n': self.lines+=['OK STOP']
                    elif data==b'MIC_DUMP\n': self.lines += [f'MIC_DATA {i} '+('00'*11) for i in range(306)]+['OK MIC_DUMP']
                def readline(self): return (self.lines.pop(0)+'\n').encode() if self.lines else b''
            port=Port(); log=root/'capture.jsonl'
            with patch.dict(sys.modules,{'serial':types.SimpleNamespace(Serial=lambda *a,**k:port)}),patch.object(sys,'argv',['mic','--port','MOCK','--log',str(log)]),contextlib.redirect_stdout(io.StringIO()):
                mic.main()
            report=json.loads(log.with_suffix('.summary.json').read_text())
            self.assertTrue(report['framing_matches_reference'])
            self.assertEqual(report['hardware']['txrx'],'00000000')
            with wave.open(str(log.with_suffix('.wav'))) as wav:
                self.assertEqual((wav.getframerate(),wav.getnframes()),(8000,306*160))
            self.assertEqual(port.writes,[b'STATUS\n',b'MIC\n',b'STOP\n',b'MIC_DUMP\n'])
            for option,stored,commands in [('--start-only',False,[b'STATUS\n',b'MIC\n']),('--download-only',True,[b'STATUS\n',b'STOP\n',b'MIC_DUMP\n']),('--digital',False,[b'STATUS\n',b'MIC_DMR\n',b'STOP\n',b'MIC_DUMP\n']),('--delay',False,[b'STATUS\n',b'MIC_WAIT\n',b'STOP\n',b'MIC_DUMP\n']),('--phy',False,[b'STATUS\n',b'MIC_PHY\n',b'STOP\n',b'MIC_DUMP\n'])]:
                port=Port(stored); path=root/(option[2:]+'.jsonl')
                with patch.dict(sys.modules,{'serial':types.SimpleNamespace(Serial=lambda *a,**k:port)}),patch.object(sys,'argv',['mic','--port','MOCK','--log',str(path),option]),contextlib.redirect_stdout(io.StringIO()):
                    mic.main()
                self.assertEqual(port.writes,commands)
if __name__=='__main__': unittest.main()
