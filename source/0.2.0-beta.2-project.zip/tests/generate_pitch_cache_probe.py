"""Extract actual reference/candidate kernels for result and flag comparison."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / 'build/imbe-bench-host'
reference = (root / 'research/references/nostar/imbe_vocoder/pitch_est.cc').read_text()
candidate = (out / 'imbe_pitch_specialized.cc').read_text()


def kernels(source):
    start = source.index('Word32 imbe_vocoder_impl::autocorr(')
    end = source.index('void imbe_vocoder_impl::pitch_est(IMBE_PARAM', start)
    return source[start:end].replace('imbe_vocoder_impl::', '')


declarations = candidate[candidate.index('struct ImbePitchCacheEntry'):candidate.index('void imbe_vocoder_impl::pitch_est_init')]
probe = '''#include "imbe_vocoder_impl.h"
#include "globals.h"
#include "tbls.h"
#include <cassert>
#include <cstdio>
namespace reference {
''' + kernels(reference) + '\n}\nnamespace candidate {\n' + declarations + kernels(candidate) + '''
}
int main() {
    Word16 input[PITCH_EST_FRAME], expected[203], actual[203];
    unsigned random=0x293, hits=0;
    for (unsigned trial=0; trial<100; ++trial) {
        for (unsigned i=0; i<PITCH_EST_FRAME; ++i) {
            random ^= random<<13; random ^= random>>17; random ^= random<<5;
            input[i]=trial==0 ? 0 : trial==1 ? -32768 : trial==2 ? 32767 : Word16(random);
        }
        for (unsigned flags=0; flags<4; ++flags) {
            Overflow=flags&1; Carry=(flags>>1)&1;
            reference::e_p(input,expected);
            Flag overflow=Overflow, carry=Carry;
            for (unsigned repeat=0; repeat<2; ++repeat) {
                Overflow=flags&1; Carry=(flags>>1)&1;
                unsigned before=candidate::imbe_pitch_cache_next;
                candidate::e_p(input,actual);
                assert(memcmp(actual,expected,sizeof actual)==0);
                assert(Overflow==overflow && Carry==carry);
                if (repeat) {
                    assert(candidate::imbe_pitch_cache_next==before);
                    ++hits;
                }
            }
        }
    }
    assert(hits==400);
    puts("Pitch cache: 800 calls match reference arrays and flags; 400 confirmed hits");
}
'''
(out / 'pitch-cache-probe.cpp').write_text(probe)
