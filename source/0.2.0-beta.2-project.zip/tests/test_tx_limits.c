// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "radio_tx_guard.h"
#include "imbe_mic_queue.h"
int main(void) {
    radio_tx_guard guard={0};
    assert(!radio_tx_guard_tick(&guard));
    assert(!radio_tx_guard_start(&guard,0));
    assert(!radio_tx_guard_start(&guard,RADIO_TX_GUARD_MAX_SECONDS+1));
    for(unsigned seconds=1;seconds<=RADIO_TX_GUARD_MAX_SECONDS;++seconds) {
        assert(radio_tx_guard_start(&guard,seconds));
        for(unsigned n=1;n<seconds;++n)assert(!radio_tx_guard_tick(&guard));
        assert(radio_tx_guard_tick(&guard));
        assert(!radio_tx_guard_tick(&guard));
    }
    assert(radio_tx_guard_start(&guard,180));radio_tx_guard_stop(&guard);
    assert(!radio_tx_guard_tick(&guard));
    // A ten-minute microphone limit changes frame count, not queue capacity.
    imbe_mic_queue q={0};int16_t pcm[160]={0},out[160];q.accepting=true;
    const unsigned frames=600u*50u;
    for(unsigned n=0;n<frames;++n) {
        pcm[0]=(int16_t)(n%30000u);
        mic_queue_push_limit(&q,pcm,0xffff0000u+n*20000u,frames);
        assert(q.captured==n+1 && q.count==1 && q.high==1 && !q.overflow);
        assert(mic_queue_pop(&q,out) && out[0]==pcm[0]);
        assert(q.accepting==(n+1<frames));
    }
    mic_queue_push_limit(&q,pcm,0,frames);assert(q.captured==frames && !q.count);
    puts("TX limits: 1..610-second independent IRQ countdown, disarm, ten-minute frame cap and clock wrap passed");
    return 0;
}
