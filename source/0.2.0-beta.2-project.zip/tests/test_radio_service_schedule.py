"""Run board-service cadence regressions without hardware."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ServiceSchedule(unittest.TestCase):
    def test_switch_and_key_cadence_stalls_and_clock_wrap(self):
        compiler = shutil.which("gcc")
        if not compiler:
            self.skipTest("host GCC is required")
        with tempfile.TemporaryDirectory(prefix="radio-services-") as directory:
            binary = Path(directory) / "services.exe"
            subprocess.run([compiler, "-std=c11", "-Wall", "-Wextra", "-Werror", "-pedantic",
                            "-I", str(ROOT / "src/firmware"),
                            str(ROOT / "tests/radio_service_schedule_test.c"), "-o", str(binary)],
                           check=True, capture_output=True, text=True)
            result = subprocess.run([str(binary)], check=True, capture_output=True, text=True)
            self.assertIn("checks passed", result.stdout)


if __name__ == "__main__":
    unittest.main()
