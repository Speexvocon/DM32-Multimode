// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_demod_math.h"
#include <assert.h>
static uint32_t seed=293;
static uint32_t next(void) {seed=1664525u*seed+1013904223u;return seed;}
int main(void) {
    for(unsigned i=0;i<2000000;++i) {
        int16_t a=(int16_t)next(),b=(int16_t)next();uint32_t back=next()&65535;
        int32_t expected=b+(int32_t)(((int64_t)a-b)*back/65536);
        assert(p25_interpolate(a,b,back)==expected);
        int32_t g=100+(int32_t)(next()%65536),delta=(int32_t)(next()%800001)-400000;
        int64_t error=(int64_t)delta*65536/g;
        if(error>262144)error=262144;
        if(error< -262144)error=-262144;
        assert(p25_timing_error(delta,g)==error);
    }
    assert(p25_interpolate(-32768,32767,65535)==-32767);
    assert(p25_interpolate(32767,-32768,65535)==32766);
}
