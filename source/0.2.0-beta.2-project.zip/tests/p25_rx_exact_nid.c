// SPDX-License-Identifier: GPL-3.0-or-later
// Test-only counterfactual: current production receiver with NID correction
// disabled. Include the real header first so the guarded production include
// does not restore its normal four-bit policy. Never link this into firmware.
#include "p25_rx.h"
#undef P25_NID_MAX_CORRECTED
#define P25_NID_MAX_CORRECTED 0u
#include "../src/firmware/p25_rx.c"
