// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include "p25_channel_store.h"

static uint8_t memory[32768],snapshot[32768];
static int write_budget=-1,erase_budget=-1,read_budget=-1;
static unsigned writes,erases,reads;
static bool rd(uint32_t addr,void *out,uint32_t bytes) {
    assert(addr>=0x711000 && addr+bytes<=0x719000);++reads;
    if(!read_budget)return false;
    if(read_budget>0)--read_budget;
    memcpy(out,memory+addr-0x711000,bytes);return true;
}
static bool wr(uint32_t addr,const void *in,uint32_t bytes) {
    assert(addr>=0x711000 && addr+bytes<=0x719000);++writes;
    const uint8_t *p=in;
    for(unsigned i=0;i<bytes;++i) {
        if(!write_budget)return false;
        if(write_budget>0)--write_budget;
        uint8_t *dst=memory+addr-0x711000+i;
        assert((*dst&p[i])==p[i]);*dst&=p[i];
    }
    return true;
}
static bool erase(uint32_t addr) {
    assert(addr>=0x711000 && addr<0x719000 && !(addr%4096));++erases;
    for(unsigned i=0;i<4096;++i) {
        if(!erase_budget)return false;
        if(erase_budget>0)--erase_budget;
        memory[addr-0x711000+i]=255;
    }
    return true;
}
static const hal_flash_map_t map={.settings_addr=0x711000,.settings_size=32768};
static const hal_flash_t flash={.size=0x1000000,.erase_size=4096,.read=rd,.write=wr,.erase=erase,.map=&map};
static const p25_preferences old={145700000,145700000,0x293,10,1234567,0,22,0,1};
static const uint8_t v3[64]={
    0x50,0x32,0x35,0x50,0x03,0x00,0x00,0x00,
    0x09,0x00,0x00,0x00,0xa0,0x34,0xaf,0x08,
    0xa0,0x34,0xaf,0x08,0x93,0x02,0x00,0x00,
    0x0a,0x00,0x00,0x00,0x87,0xd6,0x12,0x00,
    0x00,0x00,0x00,0x00,0x16,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x8e,0x84,0xa5,0x0c,0x00,0x00,0x00,0x00,
};
static void fresh(void) {
    memset(memory,255,sizeof memory);write_budget=erase_budget=read_budget=-1;
    writes=erases=reads=0;
}
static void old_slot(unsigned slot,uint32_t sequence) {
    p25_preferences p=old;pref_pack(memory+64*slot,&p,sequence);
}
static void get(p25_cs_store *s,unsigned key,uint8_t *r) {assert(p25_cs_read(s,key,r));}
static void finish(p25_cs_store *s) {
    uint32_t crc;assert(p25_cs_stage_crc(s,&crc));assert(p25_cs_commit(s,crc));
}
static void named(uint8_t *r,const char *name) {
    memset(r,0,32);pref_put(r,440075000);pref_put(r+4,445075000);
    p25_cs_put16(r+8,0x293);p25_cs_put16(r+10,10);
    r[12]=P25_CS_OCCUPIED|P25_CS_TG_FILTER;r[13]=0;r[30]=5;
    memcpy(r+14,name,strlen(name));assert(p25_cs_record_valid(0,r));
}
static void test_defaults_and_legacy(void) {
    p25_cs_store s;uint8_t r[32],before[64];p25_preferences legacy;
    fresh();assert(p25_cs_open(&s,&flash) && s.writable && !s.have_active && !s.have_legacy);
    get(&s,P25_CS_VFO_A,r);assert(p25_cs_zero(r,32));
    get(&s,P25_CS_GLOBAL,r);assert(pref_get(r)==1 && r[4]==11 && p25_cs_get16(r+5)==60 && p25_cs_get16(r+7)==15);
    assert(!writes && !erases && !s.revision);
    assert(p25_cs_begin(&s,0));finish(&s);
    assert(p25_cs_open(&s,&flash) && s.have_active && s.revision==1);
    for(unsigned version=1;version<=3;++version) {
        fresh();memcpy(memory+511*64,v3,64);pref_put(memory+511*64+4,version);
        pref_put(memory+511*64+56,pref_crc(memory+511*64,56));memcpy(before,memory+511*64,64);
        assert(p25_cs_open(&s,&flash) && s.writable && s.have_legacy && !s.have_active && s.revision==9);
        get(&s,P25_CS_VFO_A,r);assert(pref_get(r)==145700000 && p25_cs_get16(r+10)==10);
        assert(((r[12]>>2)&3u)==(version==3 ? 1u : 0u));
        get(&s,P25_CS_GLOBAL,r);assert(pref_get(r)==1234567 && r[4]==22 && !r[13]);
        if(version==3) {uint32_t crc;assert(p25_cs_stage_crc(&s,&crc));}
        assert(!writes && !erases && !memcmp(before,memory+511*64,64));
        assert(p25_cs_begin(&s,9));finish(&s);
        assert(s.active_bank==0 && s.revision==10 && !memcmp(before,memory+511*64,64));
        assert(!memcmp(before,memory+64,64));
        p25_pref_store downgrade;
        assert(pref_load(&downgrade,&flash,&legacy) && !downgrade.writable && legacy.id==1234567 && legacy.tg==10);
    }
}
static void test_record_semantics(void) {
    uint8_t r[32],bad[32];named(r,"REPEATER");
    assert(p25_cs_record_valid(31,r) && p25_cs_record_valid(P25_CS_VFO_B,r));
    assert(!p25_cs_record_valid(P25_CS_RECORDS,r));
    for(unsigned i=0;i<32;++i) {
        memset(bad,0,32);bad[i]=1;
        // An unoccupied record may not hide settings or noncanonical bytes.
        if(i!=12)assert(!p25_cs_record_valid(0,bad));
    }
    memcpy(bad,r,32);bad[12]|=0x80;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[12]|=12;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[13]=16;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[14]=0;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[14]=127;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[30]=10;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[31]=9;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[12]|=P25_CS_WIDE;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);p25_cs_put16(bad+26,0x4000|670);assert(!p25_cs_record_valid(0,bad));
    bad[12]|=P25_CS_FM|P25_CS_WIDE;assert(p25_cs_record_valid(0,bad));
    p25_cs_put16(bad+26,0x4000|599);assert(!p25_cs_record_valid(0,bad));
    p25_cs_put16(bad+26,0x4000|2600);p25_cs_put16(bad+28,0xc000|511);assert(p25_cs_record_valid(0,bad));
    p25_cs_put16(bad+28,0xc000|512);assert(!p25_cs_record_valid(0,bad));
    p25_cs_store s;fresh();assert(p25_cs_open(&s,&flash));get(&s,P25_CS_GLOBAL,r);
    assert(p25_cs_record_valid(P25_CS_GLOBAL,r));
    for(unsigned i=28;i<32;++i) {memcpy(bad,r,32);bad[i]=1;assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));}
    for(unsigned version=1;version<=2;++version)for(unsigned i=14;i<32;++i) {
        memcpy(bad,r,32);bad[i]=1;assert(!p25_cs_record_valid_version(version,P25_CS_GLOBAL,bad));
    }
    memcpy(bad,r,32);p25_cs_put16(bad+5,601);assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
    memcpy(bad,r,32);p25_cs_put16(bad+7,601);assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
    memcpy(bad,r,32);bad[9]=2;assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
    memcpy(bad,r,32);bad[24]=2;assert(!p25_cs_record_valid(P25_CS_GLOBAL,bad));
}
static void test_function_fields(void) {
    p25_cs_store s;uint8_t r[32],global[32],before[32];
    fresh();assert(p25_cs_open(&s,&flash));get(&s,P25_CS_GLOBAL,global);
    memcpy(before,global,32);
    assert(radio_functions_get_tot_seconds(global)==30 && radio_functions_get_broadcast_khz(global)==87500);
    const radio_function_action defaults[]={RADIO_FUNCTION_MEMORY,RADIO_FUNCTION_STATUS,RADIO_FUNCTION_BROADCAST,RADIO_FUNCTION_AB};
    for(unsigned key=0;key<RADIO_FUNCTION_KEYS;++key) {
        assert(radio_functions_get_action_raw(global,(radio_function_key)key)==0);
        assert(radio_functions_get_action(global,(radio_function_key)key)==defaults[key]);
    }
    assert(!memcmp(before,global,32) && !writes && !erases);
    const unsigned valid_tot[]={0,15,30,600},invalid_tot[]={1,14,601,65535,65536};
    for(unsigned i=0;i<sizeof valid_tot/sizeof valid_tot[0];++i) {
        unsigned seconds=valid_tot[i];assert(radio_functions_set_tot_seconds(global,seconds));
        assert(radio_functions_tot_raw(global)==seconds && radio_functions_get_tot_seconds(global)==(seconds ? seconds : 30));
        assert(p25_cs_record_valid(P25_CS_GLOBAL,global));
    }
    for(unsigned i=0;i<sizeof invalid_tot/sizeof invalid_tot[0];++i) {
        memcpy(before,global,32);assert(!radio_functions_set_tot_seconds(global,invalid_tot[i]) && !memcmp(before,global,32));
        if(invalid_tot[i]<=65535) {p25_cs_put16(global+14,(uint16_t)invalid_tot[i]);assert(!p25_cs_record_valid(P25_CS_GLOBAL,global));memcpy(global,before,32);}
    }
    for(unsigned key=0;key<RADIO_FUNCTION_KEYS;++key)for(unsigned action=0;action<RADIO_FUNCTION_COUNT;++action) {
        assert(radio_functions_set_action(global,(radio_function_key)key,(radio_function_action)action));
        assert(radio_functions_get_action_raw(global,(radio_function_key)key)==action);
        assert(radio_functions_get_action(global,(radio_function_key)key)==(action ? (radio_function_action)action : defaults[key]));
        assert(p25_cs_record_valid(P25_CS_GLOBAL,global));
    }
    memcpy(before,global,32);
    assert(!radio_functions_set_action(global,RADIO_FUNCTION_KEYS,RADIO_FUNCTION_NONE));
    assert(!radio_functions_set_action(global,RADIO_FUNCTION_P1,RADIO_FUNCTION_COUNT));
    assert(!radio_functions_set_action(global,(radio_function_key)-1,RADIO_FUNCTION_NONE));
    assert(!radio_functions_set_action(global,RADIO_FUNCTION_P1,(radio_function_action)-1));
    assert(!memcmp(before,global,32));
    for(unsigned key=16;key<20;++key) {global[key]=9;assert(!p25_cs_record_valid(P25_CS_GLOBAL,global));memcpy(global,before,32);}
    const uint32_t valid_bcast[]={0,65000,87500,108000},invalid_bcast[]={64950,65001,108050,UINT32_MAX};
    for(unsigned i=0;i<sizeof valid_bcast/sizeof valid_bcast[0];++i) {
        uint32_t khz=valid_bcast[i];assert(radio_functions_set_broadcast_khz(global,khz));
        assert(radio_functions_broadcast_raw(global)==khz && radio_functions_get_broadcast_khz(global)==(khz ? khz : 87500));
        assert(p25_cs_record_valid(P25_CS_GLOBAL,global));
    }
    for(unsigned i=0;i<sizeof invalid_bcast/sizeof invalid_bcast[0];++i) {
        memcpy(before,global,32);assert(!radio_functions_set_broadcast_khz(global,invalid_bcast[i]) && !memcmp(before,global,32));
        pref_put(global+20,invalid_bcast[i]);assert(!p25_cs_record_valid(P25_CS_GLOBAL,global));memcpy(global,before,32);
    }
    named(r,"POWER");
    for(unsigned level=0;level<RADIO_POWER_LEVELS;++level) {
        assert(radio_functions_set_power(r,level) && radio_functions_get_power(r)==level && p25_cs_record_valid(0,r));
        for(unsigned version=1;version<=2;++version)assert(p25_cs_record_valid_version(version,0,r)==(level==0));
    }
    memcpy(before,r,32);assert(!radio_functions_set_power(r,9) && !memcmp(before,r,32));
    assert(!p25_cs_version(0) && p25_cs_version(4) && !p25_cs_version(5));
    assert(p25_cs_version(1) && p25_cs_version(2) && p25_cs_version(3));
}
static void test_dmr_helpers_and_semantics(void) {
    uint8_t r[32],common[32],bad[32];named(r,"DMR MEMORY");memcpy(common,r,32);
    assert(radio_channel_set_mode(r,RADIO_CHANNEL_DMR) && radio_channel_get_mode(r)==RADIO_CHANNEL_DMR);
    assert(!memcmp(r,common,8) && !memcmp(r+13,common+13,13) && (r[12]&P25_CS_OCCUPIED));
    assert(radio_channel_get_destination(r)==1 && radio_channel_get_color_code(r)==1 && radio_channel_get_timeslot(r)==1);
    assert(!radio_channel_get_private(r) && !radio_channel_get_repeater(r));
    assert(p25_cs_record_valid(0,r) && !p25_cs_record_valid_version(1,0,r));
    assert(!radio_channel_set_destination(r,0) && !radio_channel_set_destination(r,0x1000000));
    assert(!radio_channel_set_color_code(r,16) && !radio_channel_set_timeslot(r,0) && !radio_channel_set_timeslot(r,3));
    for(unsigned cc=0;cc<16;++cc)for(unsigned ts=1;ts<=2;++ts)for(unsigned kind=0;kind<4;++kind) {
        assert(radio_channel_set_destination(r,0xffffff) && radio_channel_set_color_code(r,cc) && radio_channel_set_timeslot(r,ts));
        radio_channel_set_private(r,(kind&1)!=0);radio_channel_set_repeater(r,(kind&2)!=0);
        assert(radio_channel_get_destination(r)==0xffffff && radio_channel_get_color_code(r)==cc && radio_channel_get_timeslot(r)==ts);
        assert(radio_channel_get_private(r)==((kind&1)!=0) && radio_channel_get_repeater(r)==((kind&2)!=0));
        assert(p25_cs_record_valid(33,r));
    }
    for(unsigned filter=0;filter<3;++filter){r[12]=(uint8_t)((r[12]&~12u)|(filter<<2));assert(p25_cs_record_valid(0,r));}
    r[12]&=(uint8_t)~12u;
    for(unsigned flag=2;flag<=128;flag<<=1)if(flag!=4 && flag!=8 && flag!=16 && flag!=64) {
        memcpy(bad,r,32);bad[12]|=(uint8_t)flag;assert(!p25_cs_record_valid(0,bad));
    }
    memcpy(bad,r,32);bad[11]|=128;assert(!p25_cs_record_valid(0,bad));
    memcpy(bad,r,32);bad[26]=1;assert(!p25_cs_record_valid(0,bad));
    assert(radio_channel_set_mode(r,RADIO_CHANNEL_P25));
    assert(p25_cs_get16(r+8)==0x293 && radio_channel_get_destination(r)==1 && p25_cs_record_valid(0,r));
    assert(!radio_channel_set_color_code(r,1) && !radio_channel_set_timeslot(r,1));
    assert(radio_channel_set_mode(r,RADIO_CHANNEL_FM) && p25_cs_record_valid(0,r));
}

static void old_pack(uint8_t *b,unsigned version,unsigned key,const uint8_t *record) {
    memset(b,0,64);pref_put(b,P25_CS_MAGIC);b[4]=(uint8_t)version;b[5]=(uint8_t)key;
    p25_cs_put16(b+6,32);memcpy(b+8,record,32);pref_put(b+56,pref_crc(b,56));
}
static void old_bank(unsigned version,unsigned bank,uint32_t revision) {
    p25_cs_store defaults;uint8_t record[32],header[32]={0};uint32_t crc=~0u;
    fresh();assert(p25_cs_open(&defaults,&flash));
    unsigned base=bank*16384;memcpy(memory+base+64,v3,64);
    for(unsigned key=0;key<35;++key) {
        assert(p25_cs_old_read(&defaults,key,record));
        if(key==0 || key==31 || key==32 || key==33) {
            named(record,key==31 ? "LAST OLD" : "OLD KEPT");record[13]=(uint8_t)(key==0 ? 1 : key==31 ? 8 : 0);
        }
        if(key==34) {record[10]=1;record[11]=32;record[12]=3;}
        assert(p25_cs_record_valid_version(version,key,record));
        old_pack(memory+base+(key+2)*64,version,key,record);crc=p25_cs_crc_add(crc,record,32);
    }
    old_pack(memory+base,version,255,header);uint8_t *h=memory+base;
    pref_put(h+8,revision);pref_put(h+12,crc^~0u);p25_cs_put16(h+16,35);p25_cs_put16(h+18,32);
    pref_put(h+20,p25_cs_crc_add(crc,v3,64)^~0u);pref_put(h+56,pref_crc(h,56));
    writes=erases=reads=0;
}
static void test_legacy_projection(void) {
    p25_cs_store s,boot;uint8_t r[32],before[16384],canonical[P25_CS_PAYLOAD_BYTES];uint32_t crc;
    for(unsigned version=1;version<=3;++version)for(unsigned bank=0;bank<2;++bank) {
        old_bank(version,bank,23);memcpy(before,memory+bank*16384,16384);
        assert(p25_cs_open(&s,&flash) && s.writable && s.active_version==version && s.revision==23);
        assert(!writes && !erases);
        get(&s,0,r);assert(!r[13] && !memcmp(r+14,"OLD KEPT",8));
        get(&s,31,r);assert(!r[13] && !memcmp(r+14,"LAST OLD",8));get(&s,255,r);assert(p25_cs_zero(r,32));
        get(&s,P25_CS_VFO_A,r);assert(pref_get(r)==440075000);
        get(&s,P25_CS_GLOBAL,r);assert(p25_cs_selection(r,0)==1 && p25_cs_selection(r,1)==32 && r[12]==3);
        for(unsigned list=0;list<4;++list) {
            get(&s,p25_cs_scan_key(list),r);assert(r[0] && r[12]==P25_CS_SCAN_CHANNEL && r[13]==P25_CS_REPLY_LAST
                && p25_cs_get16(r+18)==1000 && p25_cs_get16(r+20)==2000);
            get(&s,p25_cs_scan_key(list)+1,r);
            assert(p25_cs_map_test(r,0)==(list==0) && p25_cs_map_test(r,31)==(list==3));
        }
        for(unsigned key=0;key<P25_CS_RECORDS;++key)get(&s,key,canonical+key*32);
        assert(p25_cs_stage_crc(&s,&crc));assert(p25_cs_begin(&s,23));finish(&s);
        assert(!memcmp(before,memory+bank*16384,16384));assert(p25_cs_open(&boot,&flash) && boot.active_version==4 && boot.revision==24);
        uint32_t after;assert(p25_cs_stage_crc(&boot,&after) && after==crc);
        for(unsigned key=0;key<P25_CS_RECORDS;++key){get(&boot,key,r);assert(!memcmp(r,canonical+key*32,32));}
        assert(!memcmp(memory+boot.active_bank*16384+64,v3,64));
    }
}
static void setup_full(p25_cs_store *s) {
    uint8_t r[32],g[32];fresh();memcpy(memory+500*64,v3,64);assert(p25_cs_open(s,&flash));assert(p25_cs_begin(s,s->revision));
    for(unsigned key=0;key<=P25_CS_VFO_B;++key) {named(r,"ALL CHANNELS");p25_cs_put16(r+10,(uint16_t)(key+1));assert(p25_cs_stage_write(s,key,r));}
    get(s,P25_CS_GLOBAL,g);assert(p25_cs_set_selection(g,0,256) && p25_cs_set_selection(g,1,1));g[12]=15;g[26]=g[27]=16;
    assert(p25_cs_stage_write(s,P25_CS_GLOBAL,g));
    memset(r,0,32);memcpy(r,"Home zone",9);assert(p25_cs_stage_write(s,p25_cs_zone_key(15),r));memset(r,255,32);
    assert(p25_cs_stage_write(s,p25_cs_zone_key(15)+1,r));
    memset(r,0,32);memcpy(r,"P25 groups",10);r[12]=P25_CS_SCAN_TG;r[13]=P25_CS_REPLY_FIXED;
    p25_cs_put16(r+14,256);p25_cs_put16(r+16,256);p25_cs_put16(r+18,1000);p25_cs_put16(r+20,2000);r[22]=64;
    assert(p25_cs_stage_write(s,p25_cs_scan_key(15),r));
    for(unsigned part=0;part<4;++part) {for(unsigned i=0;i<16;++i)p25_cs_put16(r+2*i,(uint16_t)(part*16+i+1));assert(p25_cs_stage_write(s,p25_cs_scan_key(15)+2+part,r));}
    finish(s);
}
static void test_expanded_snapshots(void) {
    p25_cs_store s,boot;uint8_t r[32],global[32],before[32];uint32_t crc;
    setup_full(&s);assert(p25_cs_open(&boot,&flash) && boot.revision==10 && boot.active_version==4 && boot.writable);
    for(unsigned key=0;key<=P25_CS_VFO_B;++key){get(&boot,key,r);assert(p25_cs_get16(r+10)==key+1);}
    get(&boot,P25_CS_GLOBAL,global);assert(p25_cs_selection(global,0)==256 && p25_cs_selection(global,1)==1 && global[26]==16);
    assert(!p25_cs_set_selection(global,0,257) && !p25_cs_set_selection(global,2,0));
    assert(p25_cs_begin(&boot,10));named(r,"CH256 NEW");assert(p25_cs_stage_write(&boot,255,r));
    unsigned w=writes;assert(p25_cs_stage_write(&boot,255,r) && writes==w);
    memcpy(before,r,32);r[14]='X';assert(!p25_cs_stage_write(&boot,255,r));
    get(&boot,255,r);assert(memcmp(r,before,32));assert(p25_cs_stage_read(&boot,255,r) && !memcmp(r,before,32));
    assert(p25_cs_stage_crc(&boot,&crc) && !p25_cs_commit(&boot,crc^1));finish(&boot);
    assert(p25_cs_open(&s,&flash) && s.revision==11);get(&s,255,r);assert(!memcmp(r,before,32));
    assert(p25_cs_begin(&s,11));named(r,"ABORTED");assert(p25_cs_stage_write(&s,254,r));p25_cs_abort(&s);
    assert(p25_cs_open(&boot,&flash) && boot.revision==11);get(&boot,254,r);assert(!memcmp(r+14,"ALL CHANNELS",12));
    // Every field and all 256 membership bits survive the dense CRC round trip.
    uint32_t independent=~0u;for(unsigned key=0;key<P25_CS_RECORDS;++key){get(&boot,key,r);independent=p25_cs_crc_add(independent,r,32);}
    assert(p25_cs_stage_crc(&boot,&crc) && crc==(independent^~0u));
}
static bool invalid_commit(unsigned key,const uint8_t *record) {
    p25_cs_store s;uint32_t crc;assert(p25_cs_open(&s,&flash));assert(p25_cs_begin(&s,s.revision));
    assert(p25_cs_stage_write(&s,key,record));assert(p25_cs_stage_crc(&s,&crc));bool refused=!p25_cs_commit(&s,crc);p25_cs_abort(&s);return refused;
}
static void test_references_and_metadata(void) {
    p25_cs_store s;uint8_t r[32],g[32];setup_full(&s);memcpy(snapshot,memory,sizeof memory);
    // Local validation is structural; publication resolves every reference.
    get(&s,P25_CS_GLOBAL,g);g[26]=1;assert(invalid_commit(P25_CS_GLOBAL,g));
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);assert(invalid_commit(p25_cs_zone_key(15),r));
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);assert(invalid_commit(p25_cs_zone_key(15)+1,r));
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);assert(invalid_commit(255,r)); // global and TG list refer to CH256
    memcpy(memory,snapshot,sizeof memory);get(&s,p25_cs_scan_key(15),r);r[22]=63;assert(invalid_commit(p25_cs_scan_key(15),r));
    memcpy(memory,snapshot,sizeof memory);get(&s,p25_cs_scan_key(15)+2,r);p25_cs_put16(r+2,1);assert(invalid_commit(p25_cs_scan_key(15)+2,r));
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);r[31]=128;assert(invalid_commit(p25_cs_scan_key(15)+1,r));
    memcpy(memory,snapshot,sizeof memory);get(&s,255,r);r[12]|=P25_CS_FM;assert(invalid_commit(255,r));
    memcpy(memory,snapshot,sizeof memory);get(&s,p25_cs_scan_key(15),r);r[12]=P25_CS_SCAN_CHANNEL;p25_cs_put16(r+14,0);r[22]=0;
    assert(invalid_commit(p25_cs_scan_key(15),r)); // channel lists cannot hide TG records
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);assert(invalid_commit(p25_cs_scan_key(15),r));
    // Unnamed dependencies and channel map references are checked for every list and zone.
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);r[0]=1;assert(invalid_commit(p25_cs_zone_key(0)+1,r));
    memcpy(memory,snapshot,sizeof memory);memset(r,0,32);r[0]=1;assert(invalid_commit(p25_cs_scan_key(0)+2,r));
    memcpy(memory,snapshot,sizeof memory);
    // Descriptor bounds, padding, reserved bytes and incompatible field encodings.
    get(&s,p25_cs_scan_key(15),r);
    for(unsigned i=23;i<32;++i){uint8_t b[32];memcpy(b,r,32);b[i]=1;assert(!p25_cs_record_valid(p25_cs_scan_key(15),b));}
    r[12]=2;assert(!p25_cs_record_valid(p25_cs_scan_key(15),r));r[12]=1;r[22]=65;assert(!p25_cs_record_valid(p25_cs_scan_key(15),r));
    r[22]=64;p25_cs_put16(r+18,99);assert(!p25_cs_record_valid(p25_cs_scan_key(15),r));p25_cs_put16(r+18,5001);assert(!p25_cs_record_valid(p25_cs_scan_key(15),r));
    p25_cs_put16(r+18,1000);p25_cs_put16(r+20,10001);assert(!p25_cs_record_valid(p25_cs_scan_key(15),r));
}
static void assert_old_or_new(const p25_cs_store *boot,bool done,const uint8_t *before,const uint8_t *after,unsigned old_revision) {
    uint8_t r[32];assert(boot->revision==(done ? old_revision+1u : old_revision));get((p25_cs_store *)boot,0,r);assert(!memcmp(r,done ? after : before,32));
}
static void exercise_cuts(bool migration,unsigned bank) {
    p25_cs_store s,boot;uint8_t before[32],after[32],kept[16384];uint32_t crc;unsigned revision;
    if(migration)old_bank(3,bank,23);else {setup_full(&s);}
    assert(p25_cs_open(&s,&flash));get(&s,0,before);named(after,"POWER CUT");revision=s.revision;
    memcpy(snapshot,memory,sizeof memory);memcpy(kept,memory+s.active_bank*16384,16384);unsigned active=s.active_bank;
    // All record boundaries and every byte of final header publication, plus
    // intent/fallback cuts and dense data interior samples.
    unsigned total=8+64+P25_CS_PAYLOAD_BYTES+64,cases=0;
    for(unsigned cut=0;cut<=total;++cut) {
        bool test=cut<80 || cut>total-66 || (cut>=72 && ((cut-72)%32<=1 || (cut-72)%32==31));if(!test)continue;
        memcpy(memory,snapshot,sizeof memory);write_budget=-1;assert(p25_cs_open(&s,&flash));write_budget=(int)cut;
        bool done=p25_cs_begin(&s,revision);
        if(done)done=p25_cs_stage_write(&s,0,after) && p25_cs_stage_crc(&s,&crc) && p25_cs_commit(&s,crc);
        write_budget=-1;assert(!memcmp(kept,memory+active*16384,16384));assert(p25_cs_open(&boot,&flash));
        assert_old_or_new(&boot,done,before,after,revision);assert(!done || boot.active_version==4);++cases;
    }
    const int cuts[]={0,1,63,64,4095,4096,8191,8192,12287,12288,16383,16384};
    for(unsigned i=0;i<sizeof cuts/sizeof cuts[0];++i) {
        memcpy(memory,snapshot,sizeof memory);assert(p25_cs_open(&s,&flash));erase_budget=cuts[i];bool began=p25_cs_begin(&s,revision);erase_budget=-1;
        assert(began==(cuts[i]==16384));assert(!memcmp(kept,memory+active*16384,16384));assert(p25_cs_open(&boot,&flash));
        assert_old_or_new(&boot,false,before,after,revision);++cases;
    }
    printf("%s bank%u power-cut cases: %u\n",migration ? "Migration" : "V4 update",bank,cases);
}
static void test_full_legacy_ring_cuts(void) {
    p25_cs_store s,boot;uint8_t kept[64],r[32];uint32_t crc;
    const int cuts[]={0,1,4,7,8,9,63,64,71,72,73,103,104,4096,8192,12455,12456,12457,12515,12516,12519,12520};
    for(unsigned half=0;half<2;++half) {
        fresh();for(unsigned slot=0;slot<512;++slot)old_slot(slot,slot+1);
        unsigned latest=half ? 511 : 0;old_slot(latest,1000);memcpy(kept,memory+latest*64,64);memcpy(snapshot,memory,sizeof memory);
        for(unsigned i=0;i<sizeof cuts/sizeof cuts[0];++i) {
            memcpy(memory,snapshot,sizeof memory);assert(p25_cs_open(&s,&flash));write_budget=cuts[i];bool done=p25_cs_begin(&s,1000);
            if(done)done=p25_cs_stage_crc(&s,&crc) && p25_cs_commit(&s,crc);
            write_budget=-1;assert(p25_cs_open(&boot,&flash));assert(!memcmp(kept,memory+latest*64,64));
            get(&boot,P25_CS_VFO_A,r);assert(pref_get(r)==145700000 && p25_cs_get16(r+10)==10);
            assert(boot.revision==(done ? 1001u : 1000u) && boot.have_active==done);
        }
    }
}
static void recheck_dense(unsigned bank) {
    uint8_t *header=memory+bank*16384;uint32_t crc=p25_cs_crc_add(~0u,header+128,P25_CS_PAYLOAD_BYTES);
    pref_put(header+12,crc^~0u);pref_put(header+20,p25_cs_crc_add(crc,header+64,64)^~0u);pref_put(header+56,pref_crc(header,56));
}
static void test_corruption_unknown_and_io(void) {
    p25_cs_store s,boot;uint8_t r[32];uint32_t crc;setup_full(&s);unsigned previous=s.active_bank;uint32_t revision=s.revision;
    assert(p25_cs_begin(&s,revision));named(r,"NEWER");assert(p25_cs_stage_write(&s,0,r));finish(&s);memcpy(snapshot,memory,sizeof memory);
    unsigned h=s.active_bank*16384;
    memory[h+12]^=1;assert(p25_cs_open(&boot,&flash) && boot.revision==revision && boot.active_bank==previous);
    memcpy(memory,snapshot,sizeof memory);memory[h+128+14]^=1;assert(p25_cs_open(&boot,&flash) && boot.revision==revision);
    // CRC-correct data still cannot publish dangling references or duplicate TGs.
    memcpy(memory,snapshot,sizeof memory);memory[h+128+P25_CS_GLOBAL*32+26]=1;recheck_dense(s.active_bank);
    assert(p25_cs_open(&boot,&flash) && boot.revision==revision);
    memcpy(memory,snapshot,sizeof memory);unsigned groups=h+128+(p25_cs_scan_key(15)+2)*32;
    p25_cs_put16(memory+groups+2,p25_cs_get16(memory+groups));recheck_dense(s.active_bank);
    assert(p25_cs_open(&boot,&flash) && boot.revision==revision);
    memcpy(memory,snapshot,sizeof memory);memory[h+4]=5;assert(p25_cs_open(&boot,&flash) && !boot.writable && boot.revision==revision);
    unsigned w=writes,e=erases;assert(!p25_cs_begin(&boot,boot.revision) && writes==w && erases==e);
    memcpy(memory,snapshot,sizeof memory);p25_cs_put16(memory+h+16,P25_CS_RECORDS+1);pref_put(memory+h+56,pref_crc(memory+h,56));
    assert(p25_cs_open(&boot,&flash) && !boot.writable && boot.revision==revision);
    memcpy(memory,snapshot,sizeof memory);p25_cs_put16(memory+h+18,P25_CS_PAYLOAD_BYTES+32);pref_put(memory+h+56,pref_crc(memory+h,56));
    assert(p25_cs_open(&boot,&flash) && !boot.writable && boot.revision==revision);
    memcpy(memory,snapshot,sizeof memory);memory[h+P25_CS_USED_BYTES]=0;assert(p25_cs_open(&boot,&flash) && !boot.writable);
    memcpy(memory,snapshot,sizeof memory);
    // A read error during payload/reference verification must not authorize a replacement.
    unsigned allreads;reads=0;assert(p25_cs_open(&s,&flash));allreads=reads;
    for(unsigned cut=0;cut<allreads;cut+=13){read_budget=(int)cut;assert(!p25_cs_open(&boot,&flash) && !boot.writable);read_budget=-1;}
    assert(p25_cs_open(&s,&flash));
    // Modular revisions survive wrap while retained fallback bytes stay exact.
    pref_put(memory+h+8,UINT32_MAX);pref_put(memory+h+56,pref_crc(memory+h,56));unsigned old=previous*16384;
    pref_put(memory+old+8,UINT32_MAX-1u);pref_put(memory+old+56,pref_crc(memory+old,56));
    assert(p25_cs_open(&s,&flash) && s.revision==UINT32_MAX);assert(p25_cs_begin(&s,UINT32_MAX));finish(&s);
    assert(p25_cs_open(&boot,&flash) && boot.revision==0 && boot.writable);
    for(unsigned i=0;i<8;++i){assert(p25_cs_begin(&boot,boot.revision));finish(&boot);assert(!memcmp(memory+boot.active_bank*16384+64,v3,64));}
    assert(p25_cs_stage_crc(&boot,&crc));
    fresh();memcpy(memory,v3,64);memory[32704]=0;assert(p25_cs_open(&s,&flash) && s.have_legacy && !s.writable && !writes && !erases);
    fresh();memcpy(memory,v3,64);old_slot(300,10);pref_put(memory+300*64+4,99);assert(p25_cs_open(&s,&flash) && !s.writable && s.have_legacy);
    hal_flash_t wrong=flash;wrong.erase_size=8192;unsigned count=reads;assert(!p25_cs_open(&s,&wrong) && reads==count);
    hal_flash_map_t other=map;other.settings_addr=0x710000;wrong=flash;wrong.map=&other;assert(!p25_cs_open(&s,&wrong) && reads==count);
}
int main(void) {
    test_defaults_and_legacy();test_record_semantics();test_function_fields();test_dmr_helpers_and_semantics();test_legacy_projection();
    test_expanded_snapshots();test_references_and_metadata();exercise_cuts(true,0);exercise_cuts(true,1);exercise_cuts(false,0);test_full_legacy_ring_cuts();test_corruption_unknown_and_io();
    printf("Atomic V4 store passed: 387 dense records, 256 channels, zones/scans, legacy projection, interruption/reference gates; sizeof=%zu\n",sizeof(p25_cs_store));
}
