// SPDX-License-Identifier: GPL-3.0-or-later
// Test-only timestamps for independent synthetic-source unit alignment.
#include "p25_demod.h"
#include "p25_receive_policy.h"
#include <stdio.h>
typedef struct {p25_demod *demod;FILE *out;bool failed;p25_receive_policy call;} probe;
static void frame(const p25_rx *r,void *context) {
    probe *p=context;uint32_t ticks=p->demod->ticks;
    p25_call_metadata metadata;bool valid=p25_call_decode(r->frame,r->duid,&metadata);
    p25_receive_event event=p25_receive_update(&p->call,r->nac,r->duid,&metadata,valid,
                                              (uint32_t)((uint64_t)ticks*1000000/48000));
    const uint8_t header[12]={(uint8_t)(r->nac>>8),(uint8_t)r->nac,r->duid,r->nid_corrected,
        (uint8_t)ticks,(uint8_t)(ticks>>8),(uint8_t)(ticks>>16),(uint8_t)(ticks>>24),
        (uint8_t)valid,metadata.classification,(uint8_t)event.voice,(uint8_t)p->call.state};
    if(fwrite(header,1,sizeof header,p->out)!=sizeof header ||
       fwrite(r->frame,1,sizeof r->frame,p->out)!=sizeof r->frame)p->failed=true;
}
int main(int argc,char **argv) {
    if(argc!=3)return 2;
    FILE *in=fopen(argv[1],"rb"),*out=fopen(argv[2],"wb");
    if(!in || !out) {if(in)fclose(in);if(out)fclose(out);return 3;}
    p25_demod d;p25_demod_init(&d);probe p={.demod=&d,.out=out};int a,b;
    while((a=fgetc(in))!=EOF) {
        b=fgetc(in);if(b==EOF) {fclose(in);fclose(out);return 4;}
        p25_demod_push(&d,(int16_t)((unsigned)a*256+(unsigned)b),frame,&p);
    }
    bool failed=ferror(in)!=0;
    for(unsigned i=0;i<32;++i)p25_demod_push(&d,0,frame,&p);
    fclose(in);int close_result=fclose(out);return failed || p.failed || close_result ? 5 : 0;
}
