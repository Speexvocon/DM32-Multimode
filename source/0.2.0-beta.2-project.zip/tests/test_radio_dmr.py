"""Exercise the real pinned call/FEC/voice engines through the project adapter."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RF = ROOT / "external/RadioFoundry/RadioFoundry"


class RadioDmr(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("gcc")
        if not compiler:
            raise unittest.SkipTest("host GCC is required")
        cls.temp = tempfile.TemporaryDirectory(prefix="radio-dmr-")
        build = Path(cls.temp.name)
        (build / "config.h").write_text(
            "#define CONFIG_SFR 0\n#define CONFIG_SFR_DUALPATH_RX 0\n"
            "#define CONFIG_DMR_TALKER_ALIAS 0\n#define CONFIG_DMR_GPS 0\n"
            "#define CONFIG_DMR_PRIVACY 0\n#define CONFIG_DEBUGLINK 0\n"
        )
        cls.binary = build / "radio_dmr_test.exe"
        sources = [ROOT / "tests/radio_dmr_test.c", ROOT / "src/firmware/radio_dmr.c"]
        sources += [RF / p for p in (
            "tests/host/sim/dmr_sim_modem.c", "core/dmr/call/dmr_call.c",
            "core/dmr/call/dmr_lc.c", "core/dmr/ambe/ambeVoice.c",
            "core/dmr/ambe/ambeFec.c", "core/dmr/fec/dmrFec.c",
        )]
        command = [compiler, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror"]
        for include in (build, ROOT / "src/firmware", RF / "core", RF / "hal", RF / "tests/host"):
            command += ["-I", str(include)]
        command += [str(p) for p in sources] + ["-o", str(cls.binary)]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def check_case(self, case):
        result = subprocess.run([str(self.binary), case], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("checks passed", result.stdout)

    def test_malformed_channel_and_incomplete_hal_do_not_acquire(self): self.check_case("malformed")
    def test_failed_ownership_codec_tune_and_modem_unwind(self): self.check_case("failures")
    def test_held_boot_ptt_requires_release(self): self.check_case("held_ptt")
    def test_permission_and_receive_only_gate_fresh_ptt(self): self.check_case("permission")
    def test_real_call_drains_terminator_then_returns_to_rx(self): self.check_case("normal_call")
    def test_real_tot_never_restarts_held_ptt(self): self.check_case("timeout")
    def test_board_refusal_never_starts_modem_tx(self): self.check_case("tx_refused")
    def test_second_backend_cannot_take_ownership(self): self.check_case("singleton")
    def test_real_fec_audio_filters_prom_and_privacy_mute(self): self.check_case("receive")
    def test_native_deny_stall_abort_errors_survive_release_and_stop(self): self.check_case("native_failures")
    def test_per_call_metrics_exclude_prior_native_totals(self): self.check_case("diagnostic_baselines")
    def test_only_accepted_clear_voice_holds_scan(self): self.check_case("scan_hold")
    def test_cancelled_access_is_not_a_completed_voice_call(self): self.check_case("cancelled_access")
    def test_poll_microsecond_timing_covers_finishing_poll_and_wrap(self): self.check_case("timing_diagnostics")
    def test_native_engine_deltas_precede_stop_reset_and_survive_handoff(self): self.check_case("native_diagnostics")


if __name__ == "__main__":
    unittest.main()
