"""Offline packet, serial-fragmentation, flow-control and fault tests."""
import importlib.util
import contextlib
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('hotspot', ROOT/'scripts/hotspot-p25-replay.py')
hs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hs)
generator_spec = importlib.util.spec_from_file_location('hotspot_fixtures', ROOT/'tests/generate_hotspot_fixtures.py')
generator = importlib.util.module_from_spec(generator_spec)
generator_spec.loader.exec_module(generator)


class ReplayTests(unittest.TestCase):
    def test_negative_calls_reproduce_independent_op25(self):
        calls = generator.generate()
        expected_manifest = generator.manifest(calls)
        actual_manifest = json.loads((generator.DIRECTORY/'manifest.json').read_text())
        self.assertEqual(actual_manifest, expected_manifest)
        for name, data in calls.items():
            with self.subTest(case=name):
                self.assertEqual((generator.DIRECTORY/(name+'.bin')).read_bytes(), data)
                self.assertEqual(hashlib.sha256(data).hexdigest(), hs.CASES[name]['sha256'])
                packets = hs.load_frames(generator.DIRECTORY/(name+'.bin'), 14, name)
                has_hdu = hs.CASES[name].get('has_hdu', True)
                self.assertEqual(len(packets), 30 if has_hdu else 29)
                self.assertEqual(b''.join(p[4:] for p in packets), data)
                self.assertEqual([len(packets[0]), len(packets[1]), len(packets[-1])],
                                 [103 if has_hdu else 220, 220, 22])
                self.assertEqual(packets[0][:4], bytes.fromhex('e0673000' if has_hdu else 'e0dc3100'))
                self.assertTrue(all(p[2:4] == b'\x31\0' for p in packets[int(has_hdu):]))

    def test_negative_calls_change_only_independent_metadata_positions(self):
        text = (ROOT/'research/references/boatbod/op25/op25/gr-op25_repeater/lib/op25_imbe_frame.h').read_text()
        def positions(name, count):
            body = re.search(r'\b'+name+r'\b[^=]*=\s*\{([^}]+)', text).group(1)
            values = re.findall(r'\b\d+\b', re.sub(r'//[^\n]*', '', body))
            return list(map(int, values))[:count]
        hdu_bits = set(positions('hdu_codeword_bits', 648))
        ldu_bits = set(positions('imbe_ldu_ls_data_bits', 240))
        self.assertEqual(len(hdu_bits), 648)
        self.assertEqual(len(ldu_bits), 240)
        clear = hs.load_frames(ROOT/'fixtures/p25-1011/call.bin', 14)
        for name in ('encrypted-hdu', 'unsupported-lc'):
            frames = hs.load_frames(ROOT/hs.CASES[name]['path'], 14, name)
            differences = 0
            for i, (before, after) in enumerate(zip(clear, frames)):
                self.assertEqual(before[:4], after[:4])
                expected_change = ((i == 0 or 0 < i < 29 and i % 2 == 0)
                                   if name == 'encrypted-hdu' else 0 < i < 29 and i % 2 == 1)
                changed = {bit for byte, (a, b) in enumerate(zip(before[4:], after[4:]))
                           for bit in range(byte*8, byte*8+8) if (a^b) & (0x80 >> (bit%8))}
                self.assertEqual(bool(changed), bool(expected_change), (name, i))
                self.assertTrue(changed <= (hdu_bits if i == 0 else ldu_bits), (name, i))
                differences += bool(changed)
            self.assertEqual(differences, 15 if name == 'encrypted-hdu' else 14)

    def test_named_case_hash_mismatch_tamper_and_unknown_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'relocated.bin'
            for name in hs.CASES:
                source = ROOT/hs.CASES[name]['path']
                for other in hs.CASES:
                    if other != name:
                        with self.subTest(case=name, wrong_case=other), self.assertRaises(ValueError):
                            hs.load_frames(source, 14, other)
                damaged = bytearray(source.read_bytes()); damaged[100] ^= 1
                path.write_bytes(damaged)
                with self.subTest(case=name), self.assertRaises(ValueError):
                    hs.load_frames(path, 14, name)
                path.write_bytes(source.read_bytes())
                self.assertEqual(hs.load_frames(path, 14, name), hs.load_frames(source, 14, name))
            with self.assertRaises(ValueError):
                hs.load_frames(path, 14, 'unknown')
        for name in (name for name in hs.CASES if name != 'clear'):
            for pairs in (0, 1, 13, 15, 28, 29):
                with self.subTest(case=name, pairs=pairs), self.assertRaises(ValueError):
                    hs.load_frames(ROOT/hs.CASES[name]['path'], pairs, name)

    def test_named_dry_runs_never_reach_modem_services_or_configuration(self):
        for name in hs.CASES:
            output = io.StringIO()
            with mock.patch.object(sys, 'argv', ['hotspot-p25-replay.py', '--case', name]), \
                 mock.patch.object(hs, 'configuration', side_effect=AssertionError('configuration touched')), \
                 mock.patch.object(hs, 'require_exclusive_services', side_effect=AssertionError('services touched')), \
                 mock.patch.dict(sys.modules, {'serial': None}), contextlib.redirect_stdout(output):
                hs.main()
            report = json.loads(output.getvalue())
            expected_units = 30 if hs.CASES[name].get('has_hdu', True) else 29
            self.assertEqual((report['case'], report['units'], report['voice_frames']), (name, expected_units, 252))
            self.assertTrue(report['dry_run'])
            self.assertEqual(report['negative_control_not_ciphertext'], name != 'clear')
            self.assertEqual(report['fixture_sha256'], hs.CASES[name]['sha256'])

    def test_named_cases_keep_bounded_flow_control_and_duration(self):
        schedules = {}
        for name in hs.CASES:
            frames = hs.load_frames(ROOT/hs.CASES[name]['path'], 14, name)
            now, sent = [0.0], []
            class Link:
                def status(self):
                    return dict(p25=True, mode=4, tx=0.2 <= now[0] < 6.0,
                                space=0 if now[0] < 0.2 else 6)
                def send(self, data):
                    sent.append((now[0], data))
            result = hs.replay(Link(), frames, 0.15, lambda: now[0],
                               lambda delay: now.__setitem__(0, now[0]+delay))
            self.assertEqual([data for _, data in sent], frames)
            has_hdu = hs.CASES[name].get('has_hdu', True)
            self.assertEqual(result['units_sent'], 30 if has_hdu else 29)
            self.assertTrue(result['tx_observed'])
            self.assertGreaterEqual(result['elapsed_s'], 6)
            self.assertLess(result['elapsed_s'], 7)
            schedule = ([at for at, _ in sent], result['elapsed_s'])
            if has_hdu in schedules:
                self.assertEqual(schedule, schedules[has_hdu])
            schedules[has_hdu] = schedule

    def test_invalid_transmit_requests_fail_before_hardware_checks(self):
        for args in (['--case', 'unknown'],
                     ['--case', 'encrypted-hdu', '--fixture', str(ROOT/'fixtures/p25-1011/call.bin')],
                     ['--case', 'unsupported-lc', '--pairs', '28']):
            with mock.patch.object(sys, 'argv', ['hotspot-p25-replay.py', '--transmit', '--frequency', '145700000']+args), \
                 mock.patch.object(hs, 'configuration', side_effect=AssertionError('configuration touched')), \
                 mock.patch.object(hs, 'require_exclusive_services', side_effect=AssertionError('services touched')), \
                 contextlib.redirect_stderr(io.StringIO()), self.assertRaises((ValueError, SystemExit)):
                hs.main()

    def test_air_bytes_preserved(self):
        frames = hs.load_frames(ROOT/'fixtures/p25-1011/call.bin', 28)
        self.assertEqual(len(frames), 58)
        self.assertEqual(b''.join(f[4:] for f in frames),
                         (ROOT/'fixtures/p25-1011/call.bin').read_bytes())
        self.assertEqual([len(frames[0]), len(frames[1]), len(frames[-1])], [103, 220, 22])
        self.assertEqual(frames[0][:4], bytes.fromhex('e0673000'))
        self.assertTrue(all(f[2:4] == b'\x31\0' for f in frames[1:]))

    def test_corrupt_fixture_and_bounds(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory)/'bad.bin'
            p.write_bytes(b'bad')
            with self.assertRaises(ValueError):
                hs.load_frames(p, 1)
        for pairs in (0, 29, -1):
            with self.assertRaises(ValueError):
                hs.load_frames(ROOT/'fixtures/p25-1011/call.bin', pairs)

    def test_config_uart_frequency_and_level(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory)/'config'
            p.write_text('[General]\nDuplex=0\n[Modem]\nProtocol=uart\n'
                         'UARTPort=/dev/ttyAMA0\nPort=/dev/ttyACM0\n'
                         'TXInvert=1\nRXOffset=-100\nTXOffset=200\nP25TXLevel=50\n')
            port, baud, freq, config, lead = hs.configuration(p, 145700000, 10)
            self.assertEqual((port, baud), ('/dev/ttyAMA0', 115200))
            self.assertEqual(int.from_bytes(freq[4:8], 'little'), 145699900)
            self.assertEqual(int.from_bytes(freq[8:12], 'little'), 145700200)
            self.assertEqual(freq[12], 26)
            self.assertEqual(config[3:7], bytes((0x82, 8, 10, 0)))
            self.assertEqual(config[15], 128)
            self.assertAlmostEqual(lead, 0.15)

    def test_fragmented_serial_and_nak(self):
        class Serial:
            def __init__(self, chunks): self.chunks = iter(chunks)
            def read(self, size): return next(self.chunks, b'')
        link = hs.Link(Serial([b'junk\xe0', b'\x05', b'\x70\x02\x00']))
        self.assertEqual(link.receive(), bytes.fromhex('e005700200'))
        with self.assertRaises(RuntimeError):
            hs.Link(Serial([bytes.fromhex('e0057f3105')])).receive()
        with self.assertRaises(RuntimeError):
            hs.Link(Serial([bytes.fromhex('e002')])).receive()

    def test_flow_control_and_drain(self):
        frames = hs.load_frames(ROOT/'fixtures/p25-1011/call.bin', 1)
        now = [0.0]
        sent = []
        class Link:
            def status(self):
                return dict(p25=True, mode=4, tx=0.2 <= now[0] < 1.0,
                            space=0 if now[0] < 0.2 else 6)
            def send(self, data):
                self_test.assertGreaterEqual(now[0], 0.2)
                sent.append(data)
        self_test = self
        result = hs.replay(Link(), frames, 0.15, lambda: now[0],
                           lambda delay: now.__setitem__(0, now[0]+delay))
        self.assertEqual(sent, frames)
        self.assertTrue(result['tx_observed'])
        self.assertGreaterEqual(now[0], 1.0)

    def test_stalled_fifo_bounded(self):
        now = [0.0]
        class Link:
            def status(self): return dict(p25=True, mode=0, tx=False, space=0)
            def send(self, data): raise AssertionError('No FIFO space')
        with self.assertRaises(TimeoutError):
            hs.replay(Link(), hs.load_frames(ROOT/'fixtures/p25-1011/call.bin', 1),
                      0.15, lambda: now[0], lambda d: now.__setitem__(0, now[0]+d))
        self.assertLess(now[0], 10)


if __name__ == '__main__':
    unittest.main()
