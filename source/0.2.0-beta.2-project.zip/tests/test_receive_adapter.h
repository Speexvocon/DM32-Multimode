// SPDX-License-Identifier: GPL-3.0-or-later
// Included by the actual adapter harness so every assertion exercises the
// production metadata gate, real FEC extraction and PCM queue adapter.
static void receive_gate_start(void) {
    reset();issue("RXBACKEND PCM",false);issue("RXMON 440075000 CLEAR",false);mon_poll(false);
    mock_decode_value=1234;
    assert(mon_running && !decode_calls && !rf_keys && !pa_keys);
}
static void receive_gate_clear(p25_rx *unit) {
    receive_unit(unit,0x293,0,call_vector_hdu_clear);
    receive_unit(unit,0x293,5,call_vector_ldu1_group);
    assert(monitor.call.state==P25_RX_CLEAR && decode_calls==9 && monitor.voices==9);
}
static void receive_no_output(void) {
    assert(!decode_calls && !monitor.voices && !monitor.trace.frames);
    assert(monitor.pcm_head==monitor.pcm_tail && !mon_pcm_pending && !mon_routed);
    assert(!rf_keys && !pa_keys && !mon_failed);
}
static void test_receive_tail_and_context(void) {
    p25_rx unit={0};char context[48];
    receive_gate_start();receive_gate_clear(&unit);mon_context(context,sizeof context);
    assert(strstr(context,"RX 293") && strstr(context,"TG 10") && strstr(context,"1234567"));
    radio_state state=control.state;control.state=RADIO_TX_PREPARE;mon_context(context,sizeof context);
    assert(!strstr(context,"RX 293") && !strstr(context,"1234567"));
    control.state=state;mon_stop("transmit");mon_context(context,sizeof context);
    assert(!strstr(context,"RX 293") && !strstr(context,"1234567"));
    // A validated completed tail can still be in the hardware/software queue
    // when the next clear call's HDU arrives. Keep its exact samples and half
    // position while independently resetting metadata, prediction and cache.
    receive_gate_start();receive_gate_clear(&unit);
    receive_unit(&unit,0x293,3,NULL);mon_speaker_step();
    assert(monitor.ending && !monitor.call.active && mon_pcm_pending && mon_routed && monitor.pcm_pos==80);
    unsigned inits=codec_inits,head=monitor.pcm_head,tail=monitor.pcm_tail;
    receive_unit(&unit,0x293,0,call_vector_hdu_clear);
    assert(monitor.pcm_head==head && monitor.pcm_tail==tail && monitor.pcm_pos==80 && !monitor.discarded_pcm);
    assert(mon_pcm_pending && pcm_irq_enabled && mon_routed && monitor.ending);
    assert(codec_inits==inits+1 && !monitor.trace.frames && !monitor.quality.have_good);
    assert(monitor.call.ess_valid && !monitor.call.lc_valid && !monitor.call.source_valid);
    for(unsigned i=0;i<160;++i)assert(!monitor.last_good_pcm[i]);
    mock_decode_value=2345;receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(decode_calls==18 && monitor.voices==18 && monitor.trace.frames==9 && !monitor.ending);
    assert(monitor.pcm_head==18 && monitor.pcm_tail==tail && monitor.pcm_pos==80 && !monitor.discarded_pcm);
    for(unsigned frame=0;frame<18;++frame)for(unsigned sample=0;sample<160;++sample)
        assert(monitor.pcm[frame][sample]==(frame<9 ? 1234 : 2345));
    receive_unit(&unit,0x293,3,NULL);
    for(unsigned half=0;half<36;++half){now+=10000;mon_pcm_irq();}
    mon_speaker_step();
    assert(monitor.played==18 && mon_pcm_submitted==2880 && mon_pcm_consumed==2880);
    assert(!monitor.starved && !mon_pcm_pending && !mon_routed && monitor.pcm_head==monitor.pcm_tail);
    // Nonclear or invalid new headers never inherit that drain exception.
    uint8_t invalid[216];memset(invalid,0x55,sizeof invalid);p25_call_metadata metadata;
    assert(!p25_call_decode(invalid,0,&metadata));
    const uint8_t *headers[]={call_vector_hdu_encrypted,invalid,call_vector_hdu_vendor};
    for(unsigned i=0;i<sizeof headers/sizeof *headers;++i) {
        receive_gate_start();receive_gate_clear(&unit);receive_unit(&unit,0x293,3,NULL);mon_speaker_step();
        receive_unit(&unit,0x293,0,headers[i]);
        assert(monitor.discarded_pcm==9 && monitor.pcm_head==monitor.pcm_tail && !mon_pcm_pending && !pcm_irq_enabled && !mon_routed);
        assert(decode_calls==9 && !monitor.quality.have_good && !monitor.trace.frames);
        unsigned submitted=mon_pcm_submitted;mon_pcm_irq();assert(mon_pcm_submitted==submitted && !mon_pcm_pending);
    }
    // A clear header can preserve a completed tail, but later bad/unsupported
    // LC must flush it even though the new call was still waiting for metadata.
    const uint8_t *links[]={invalid,call_vector_ldu1_vendor,call_vector_ldu1_protected};
    for(unsigned i=0;i<sizeof links/sizeof *links;++i) {
        receive_gate_start();receive_gate_clear(&unit);receive_unit(&unit,0x293,3,NULL);mon_speaker_step();
        receive_unit(&unit,0x293,0,call_vector_hdu_clear);assert(!monitor.discarded_pcm && mon_pcm_pending);
        receive_unit(&unit,0x293,5,links[i]);
        assert(monitor.discarded_pcm==9 && monitor.pcm_head==monitor.pcm_tail && !mon_pcm_pending && !mon_routed);
        assert(decode_calls==9 && !monitor.trace.frames);
    }
    // A new HDU interrupting an unfinished call has no completed-tail right.
    receive_gate_start();receive_gate_clear(&unit);
    receive_unit(&unit,0x293,0,call_vector_hdu_clear);
    assert(monitor.discarded_pcm==9 && monitor.pcm_head==monitor.pcm_tail && !monitor.call.lc_valid && !monitor.trace.frames);
}
static void test_receive_qualification(void) {
    p25_rx unit={0};
    // Clear HDU alone cannot establish a group voice call, and encrypted ESS
    // cannot be overridden by an otherwise supported clear group LC.
    receive_gate_start();receive_unit(&unit,0x293,0,call_vector_hdu_clear);receive_no_output();
    receive_gate_start();receive_unit(&unit,0x293,0,call_vector_hdu_encrypted);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(monitor.call.state==P25_RX_ENCRYPTED && monitor.encrypted_units==1);receive_no_output();
    // Each unsupported/protected LC is independently generated by OP25; no
    // codec call or PCM publication is allowed, even with a clear HDU.
    const uint8_t *blocked[]={call_vector_ldu1_encrypted_service,call_vector_ldu1_protected,
        call_vector_ldu1_individual,call_vector_ldu1_vendor,call_vector_ldu1_unsupported};
    for(unsigned i=0;i<sizeof blocked/sizeof *blocked;++i) {
        receive_gate_start();receive_unit(&unit,0x293,0,call_vector_hdu_clear);
        receive_unit(&unit,0x293,5,blocked[i]);
        assert(monitor.call.state==(i<2 ? P25_RX_ENCRYPTED : P25_RX_UNSUPPORTED));receive_no_output();
    }
    // PROM affects network selection only, including encrypted and unsupported
    // traffic on a foreign NAC; it never bypasses content qualification.
    receive_gate_start();rx_promiscuous=true;
    receive_unit(&unit,0x2a3,0,call_vector_hdu_encrypted);
    receive_unit(&unit,0x2a3,5,call_vector_ldu1_group);receive_no_output();
    assert(!monitor.rejected && monitor.call.state==P25_RX_ENCRYPTED);
    // Late entry in either order requires both independently validated parts.
    receive_gate_start();receive_unit(&unit,0x293,5,call_vector_ldu1_group);receive_no_output();
    assert(monitor.call.lc_valid && !monitor.call.ess_valid);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);
    receive_no_output(); // This ESS qualifies the next pair, not this LDU2.
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(monitor.call.state==P25_RX_CLEAR && decode_calls==9 && monitor.voices==9);
    receive_gate_start();receive_unit(&unit,0x293,10,call_vector_ldu2_clear);receive_no_output();
    assert(monitor.call.ess_valid && !monitor.call.lc_valid);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(monitor.call.state==P25_RX_CLEAR && decode_calls==9);
    // A valid encrypted LDU2 transition gates this unit's voice before decode
    // and immediately discards previously queued clear audio.
    receive_gate_start();receive_gate_clear(&unit);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    mon_speaker_step();assert(mon_pcm_pending && pcm_irq_enabled && mon_routed && mon_pcm_submitted==80);
    receive_unit(&unit,0x293,10,call_vector_ldu2_encrypted);
    assert(monitor.call.state==P25_RX_ENCRYPTED && decode_calls==27 && monitor.voices==27);
    assert(monitor.discarded_pcm==27 && monitor.pcm_head==monitor.pcm_tail && !mon_pcm_pending && !pcm_irq_enabled && !mon_routed);
    // A clear ESS received after encrypted voice applies to the next pair;
    // it must not authorize this LDU2's still-encrypted voice payload.
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);assert(decode_calls==27);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);assert(decode_calls==27);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);assert(decode_calls==36);
    // Damaged control data cannot inherit an old clear authorization. A new
    // valid ESS alone is insufficient until fresh LC also recovers.
    uint8_t invalid[216];memset(invalid,0x55,sizeof invalid);p25_call_metadata metadata;
    assert(!p25_call_decode(invalid,5,&metadata));
    receive_gate_start();receive_gate_clear(&unit);
    receive_unit(&unit,0x293,5,invalid);
    assert(monitor.call.state==P25_RX_BAD_METADATA && monitor.metadata_bad==1 && decode_calls==9);
    assert(monitor.pcm_head==monitor.pcm_tail && monitor.discarded_pcm==9);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);assert(decode_calls==9);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(monitor.call.state==P25_RX_CLEAR && decode_calls==18 && !mon_failed);
    // Repeated same-type LDUs imply a missing unit. They revoke the missing
    // LC/ESS authorization rather than silently carrying it across the gap.
    receive_gate_start();receive_gate_clear(&unit);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);
    assert(!monitor.call.ess_valid && decode_calls==9 && monitor.pcm_head==monitor.pcm_tail);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);assert(decode_calls==9);
    receive_unit(&unit,0x293,5,call_vector_ldu1_group);assert(decode_calls==18);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);assert(decode_calls==27);
    receive_unit(&unit,0x293,10,call_vector_ldu2_clear);
    assert(!monitor.call.lc_valid && decode_calls==27 && monitor.pcm_head==monitor.pcm_tail);
    // Two correctly recovered first-Golay bits trigger the conservative E0
    // policy. Repeat exactly 3 cached PCM frames, then zero/mute, then recover.
    receive_gate_start();receive_gate_clear(&unit);
    uint8_t damaged[216];memcpy(damaged,call_vector_ldu2_clear,sizeof damaged);
    for(unsigned voice=0;voice<6;++voice)for(unsigned j=0;j<2;++j) {
        unsigned bit=p25_voice_bits[voice][j];damaged[bit/8]^=(uint8_t)(1u<<(7-bit%8));
    }
    unsigned inits=codec_inits;receive_unit(&unit,0x293,10,damaged);
    assert(monitor.repeated==3 && monitor.muted==3 && monitor.voices==18 && decode_calls==12);
    assert(codec_inits==inits+1 && monitor.quality.have_good && !monitor.quality.consecutive_bad);
    for(unsigned frame=0;frame<18;++frame)for(unsigned sample=0;sample<160;++sample) {
        int16_t expected=frame>=12 && frame<15 ? 0 : 1234;
        assert(monitor.pcm[frame][sample]==expected && monitor.trace.pcm[frame][sample]==expected);
    }
    assert(monitor.corrected==12 && !mon_failed && !monitor.pcm_overflow && !rf_keys && !pa_keys);
    test_receive_tail_and_context();
    reset();
}
