// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx.h"
#include <assert.h>
#include <string.h>
bool reference_voice(const uint8_t *,unsigned,uint8_t *,unsigned *);
int main(void) {
    uint32_t seed=293;
    for(unsigned trial=0;trial<4096;++trial) {
        uint8_t frame[216];
        for(unsigned j=0;j<sizeof frame;++j) {seed=1664525u*seed+1013904223u;frame[j]=(uint8_t)(seed>>24);}
        for(unsigned voice=0;voice<9;++voice) {
            uint8_t a[11],b[11];unsigned ea,eb;
            assert(p25_rx_voice(frame,voice,a,&ea)==reference_voice(frame,voice,b,&eb));
            assert(ea==eb && !memcmp(a,b,sizeof a));
        }
    }
}
