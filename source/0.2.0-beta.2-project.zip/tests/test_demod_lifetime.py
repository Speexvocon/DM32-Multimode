"""Persistent C4FM acquisition and sync-arrival regression; no hardware access.

Run: python tests/test_demod_lifetime.py
Requires GCC, numpy, scipy, and the checked-out pinned OP25 reference. All PCM is
generated in memory. Only a small first-failure waveform may be saved under build.
--source-dir permits testing a complete alternate source directory, never a stub
demodulator. The default compiles the actual production src/firmware sources.
"""
import argparse
import ast
import ctypes as C
import hashlib
import json
import math
import platform
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import scipy
from scipy import signal

ROOT = Path(__file__).resolve().parents[1]
OP25 = ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/op25_c4fm_mod.py'
# SHA256 of the exact LF Git blob at upstream commit
# 3f44d43eb449bb4753247ce848bb42a403823dea, not a Windows CRLF checkout.
OP25_SHA = 'b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef'
FIXTURE_SHA = '2a69279e41a97eb18a8aaa3c6ec566a847c934cac421e6fa0cc14365efd2ca04'
PAYLOAD_SHA = '3b36c3c21f980b4db07fb24c84be3ff523defa876172ffe3e594ed816e5cd3de'
# Two independently reproduced fresh-receiver channel-error outcomes at 500 SD.
# These contain residual unprotected voice-bit errors, not perfect audio. Pin
# their complete wire/payload hashes rather than treating arbitrary noise output
# as acceptable. Exact source output is also allowed as a future improvement.
NOISY_OUTCOMES = {
    (1,2): dict(wire='5f611f79179c1f76b7e80b4a3cee30a0c05f1674f2ddccfdb742ee0df14ca0e8',
                payload='03d01b5fcaa6063e30b32e8199a5011823f3e25a1ec61dbb38c28506ffbed669',
                differing_source_wire_bits=[26691,28555]),
    (1,18): dict(wire='0d992564727d7b0fb090004c6b8f32e3871ba49aa7be2536893ba4a564fbbdfd',
                 payload='7bd03d9917e3f6d4daaa5cc98d813784634051527230cd8113a569b3cfca3792',
                 differing_source_wire_bits=[23499]),
}
FIELDS = ('units','hdu','ldu1','ldu2','tdu','acquisitions','bad_nid',
          'fnv1a','wire_bytes','idle_units','clock_hook_retained','pending_ticks','invalid_output')
COUNTERS = ('ticks','frames','acquisitions','sync_tests','fir_us','sync_us','fec_us','symbol_us')
EXPECTED_COUNTS = (30,1,14,14,1)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_dependencies(source):
    paths = [source/'p25_demod.c',source/'p25_demod.h',source/'p25_rx.c',source/'p25_rx.h',
             ROOT/'tests/demod_lifetime_probe.c',Path(__file__).resolve(),OP25]
    for name in ('p25_demod_math.h','p25_demod_filter.h','p25_rx_golay.h','p25_interleave.h'):
        path = source/name if (source/name).exists() else ROOT/'src/firmware'/name
        if path.exists():
            paths.append(path)
    return paths


def shaped_call(raw,preamble_bytes=720):
    """Execute only the pinned reference's pure C4FM tap definitions."""
    # Git may check this file out with CRLF on Windows. Only normalize that
    # checkout conversion; every remaining source byte must match the Git blob.
    source = OP25.read_bytes().replace(b'\r\n',b'\n')
    if sha(source) != OP25_SHA:
        raise ValueError('Pinned OP25 C4FM source hash changed')
    tree = ast.parse(source)
    nodes = [node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))
             and node.name in {'transfer_function_tx','c4fm_taps'}]
    if len(nodes) != 2:
        raise ValueError('Pinned OP25 tap definitions not found')
    scope = dict(np=np,pi=math.pi,sin=math.sin,cos=math.cos,
                 _def_symbol_rate=4800,_def_output_sample_rate=48000,_def_span=13)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(OP25),'exec'),scope)
    # Match the hotspot's ordinary 600-ms modem preamble for lifetime testing.
    # The threshold-arrival sweep below removes it completely.
    air = bytes([0x77])*preamble_bytes+raw
    dibits = np.array([(value>>shift)&3 for value in air for shift in (6,4,2,0)])
    impulses = np.zeros(len(dibits)*10)
    impulses[::10] = np.array([1,3,-1,-3])[dibits]
    return signal.fftconvolve(impulses,scope['c4fm_taps']().generate())*60000


def generated_batch(high,batch,noise,ppm):
    # Name the bit generator explicitly so a future default_rng default change
    # cannot silently replace the proven deterministic acquisition reproducer.
    rng = np.random.Generator(np.random.PCG64(0x803+batch))
    filt = signal.butter(4,3400,fs=8000,output='sos')
    for index in range(20):
        phase = int(rng.integers(0,10))
        hz = signal.resample_poly(np.r_[np.zeros(phase),high],1,6)
        if ppm:
            ratio = round(1000000/abs(ppm))
            hz = signal.resample_poly(hz,ratio,ratio+(1 if ppm>0 else -1))
        hz = hz*.8+300+rng.normal(0,noise,len(hz))
        idle_n = int(rng.uniform(1.1,13.7)*8000)
        idle = signal.sosfilt(filt,rng.normal(0,3000,idle_n))+300
        tail = signal.sosfilt(filt,rng.normal(0,3000,800))+300
        samples = np.clip(np.rint(np.r_[idle,hz,tail]),-32768,32767).astype(np.int16)
        yield dict(batch=batch,call=index+1,noise_sd=noise,clock_ppm=ppm,
                   idle_samples=idle_n,launch_phase_48khz=phase),samples


class Probe:
    def __init__(self,source,out):
        self.source = source
        suffix = '.dll' if sys.platform=='win32' else '.so'
        self.path = out/('demod-lifetime-probe'+suffix)
        self.command = ['gcc','-std=c11','-O3','-shared','-Wall','-Wextra','-Werror']
        if sys.platform!='win32':
            self.command.append('-fPIC')
        self.command += ['-I'+str(source),'-I'+str(ROOT/'src/firmware'),
                         str(ROOT/'tests/demod_lifetime_probe.c'),str(source/'p25_demod.c'),
                         str(source/'p25_rx.c'),'-o',str(self.path)]
        subprocess.run(self.command,cwd=ROOT,check=True,timeout=120)
        self.lib = C.CDLL(str(self.path))
        pcm = C.POINTER(C.c_int16)
        words = C.POINTER(C.c_uint32)
        counters = C.POINTER(C.c_uint64)
        self.lib.lifetime_segment.argtypes = [C.c_uint,pcm,C.c_uint,C.c_uint,words,counters,counters]
        self.lib.lifetime_boundary.argtypes = [C.c_uint,pcm,C.c_uint,words,counters,counters]
        self.lib.lifetime_prime.argtypes = [pcm,C.c_uint]
        self.lib.lifetime_prime.restype = C.c_uint
        self.lib.lifetime_malformed_prime.argtypes = [pcm,C.c_uint,words,counters,counters]
        self.lib.lifetime_copy_wire.argtypes = [C.POINTER(C.c_uint8)]
        self.lib.lifetime_copy_wire.restype = C.c_uint
        self.lib.lifetime_copy_payloads.argtypes = [C.POINTER(C.c_uint8),C.c_uint,C.POINTER(C.c_uint)]
        self.lib.lifetime_copy_payloads.restype = C.c_uint

    def initialize(self):
        self.lib.lifetime_initialize()

    def run(self,samples,fresh,idle=0,boundary=False):
        output = (C.c_uint32*len(FIELDS))()
        before,after = (C.c_uint64*len(COUNTERS))(),(C.c_uint64*len(COUNTERS))()
        pcm = samples.ctypes.data_as(C.POINTER(C.c_int16))
        if boundary:
            self.lib.lifetime_boundary(fresh,pcm,len(samples),output,before,after)
        else:
            self.lib.lifetime_segment(fresh,pcm,idle,len(samples),output,before,after)
        wire = (C.c_uint8*32768)()
        length = self.lib.lifetime_copy_wire(wire)
        actual = dict(zip(FIELDS,map(int,output)))
        actual['before'] = dict(zip(COUNTERS,map(int,before)))
        actual['after'] = dict(zip(COUNTERS,map(int,after)))
        actual['wire_sha256'] = sha(bytes(wire[:length]))
        payloads,corrections = (C.c_uint8*4096)(),C.c_uint()
        payload_length = self.lib.lifetime_copy_payloads(payloads,len(payloads),C.byref(corrections))
        actual['payload_bytes'] = payload_length
        actual['payload_sha256'] = sha(bytes(payloads[:payload_length]))
        actual['corrected_voice_bits'] = int(corrections.value)
        return actual,bytes(wire[:length])

    def malformed_prime(self,samples):
        output = (C.c_uint32*len(FIELDS))()
        before,after = (C.c_uint64*len(COUNTERS))(),(C.c_uint64*len(COUNTERS))()
        self.lib.lifetime_malformed_prime(samples.ctypes.data_as(C.POINTER(C.c_int16)),
                                         len(samples),output,before,after)
        result = dict(zip(FIELDS,map(int,output)))
        result['before'] = dict(zip(COUNTERS,map(int,before)))
        result['after'] = dict(zip(COUNTERS,map(int,after)))
        return result


def malformed_hunt_inputs(raw):
    """A long hunt with real syncs but no NID within the four-bit radius.

    This is an external input property, not an inspection of the implementation's
    idle/rearm fields. A one-shot refresh can work after noise and still collapse
    during this approximately 134-second stream without any accepted units.
    """
    damaged = bytearray(raw)
    offset = 0
    for size in [99]+[216]*28+[18]:
        damaged[offset+6] ^= 0xf8  # Five BCH-protected NID bits in every unit.
        offset += size
    bad_high = shaped_call(bytes(damaged),240)
    clear_high = shaped_call(raw,0)
    rng = np.random.Generator(np.random.PCG64(0x600bad))
    filt = signal.butter(4,3400,fs=8000,output='sos')

    def noise(count):
        return signal.sosfilt(filt,rng.normal(0,3000,count))+300

    def shape(wave,phase,ppm=500):
        data = signal.resample_poly(np.r_[np.zeros(phase),wave],1,6)
        if ppm:
            data = signal.resample_poly(data,2000,2000+(1 if ppm>0 else -1))
        return data*.8+300+rng.normal(0,100,len(data))

    def quantize(data):
        return np.clip(np.rint(data),-32768,32767).astype(np.int16)

    chunks = []
    for _ in range(20):
        chunks.extend([noise(int(rng.uniform(.9,2)*8000)),
                       shape(bad_high,int(rng.integers(0,10)))])
    prefix = quantize(np.concatenate(chunks+[noise(800)]))
    yield dict(kind='prefix',damaged_air_sha256=sha(damaged)),prefix
    for phase in range(10):
        for ppm in (-500,0,500):
            samples = quantize(np.r_[noise(800),shape(clear_high,phase,ppm),noise(800)])
            yield dict(kind='clean',phase_48khz=phase,clock_ppm=ppm),samples


def check_result(actual,expected,processed,label,failures,noisy_outcome=None):
    if tuple(actual[field] for field in FIELDS[:5]) != EXPECTED_COUNTS:
        failures.append(label+': incomplete or duplicated call')
    allowed = {sha(expected):PAYLOAD_SHA}
    if noisy_outcome:
        allowed[noisy_outcome['wire']] = noisy_outcome['payload']
    if actual['wire_sha256'] not in allowed:
        failures.append(label+': wire differs from the source/known-noise oracle')
    elif actual['payload_sha256'] != allowed[actual['wire_sha256']]:
        failures.append(label+': decoded payload differs from the pinned oracle')
    if actual['payload_bytes'] != 252*11:
        failures.append(label+': missing or duplicated voice payloads')
    if actual['invalid_output'] or actual['idle_units'] or actual['pending_ticks']:
        failures.append(label+': invalid, idle, or pending output')
    if not actual['clock_hook_retained']:
        failures.append(label+': profiling clock hook lost')
    before,after = actual['before'],actual['after']
    if any(after[field]<before[field] for field in COUNTERS):
        failures.append(label+': cumulative counter regressed')
    if after['ticks']-before['ticks'] != processed*6:
        failures.append(label+': sample tick continuity lost')
    if after['frames']-before['frames'] != actual['units']:
        failures.append(label+': frame counter differs from callbacks')
    if any(after[field]==before[field] for field in ('fir_us','sync_us','symbol_us')):
        failures.append(label+': profiling stage did not advance')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',type=Path,default=ROOT/'src/firmware')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'build/demod-lifetime-validation')
    args = parser.parse_args()
    source,out = args.source_dir.resolve(),args.output_dir.resolve()
    out.mkdir(parents=True,exist_ok=True)
    raw = (ROOT/'fixtures/p25-1011/call.bin').read_bytes()
    raw = raw[:99+28*216]+raw[-18:]
    if sha(raw) != FIXTURE_SHA:
        raise ValueError('Pinned 30-unit source fixture changed')
    dependencies = source_dependencies(source)
    source_hashes = {str(path):sha(path.read_bytes()) for path in dependencies}
    high = shaped_call(raw)
    probe = Probe(source,out)
    failures,calls,boundaries,malformed_calls = [],[],[],[]
    started = time.monotonic()
    first_samples = first_idle = None
    first_failure_saved = False
    for batch,noise,ppm in ((0,100,0),(1,500,0),(2,100,500)):
        probe.initialize()
        cumulative = None
        for item,samples in generated_batch(high,batch,noise,ppm):
            if first_samples is None:
                first_samples,first_idle = samples.copy(),item['idle_samples']
            item['sample_sha256'] = sha(samples.astype('<i2').tobytes())
            for fresh,name in ((0,'continuous'),(1,'fresh')):
                actual,_ = probe.run(samples,fresh,item['idle_samples'])
                item[name] = actual
                label = f'batch {batch} call {item["call"]} {name}'
                count_before = len(failures)
                check_result(actual,raw,len(samples)-item['idle_samples'],label,failures,
                             NOISY_OUTCOMES.get((batch,item['call'])))
                if not fresh:
                    if cumulative and any(actual['before'][field]<cumulative[field] for field in COUNTERS):
                        failures.append(label+': cumulative history reset between calls')
                    cumulative = actual['after']
                if len(failures)>count_before and not first_failure_saved:
                    (out/'first-failure.s16le').write_bytes(samples.astype('<i2').tobytes())
                    first_failure_saved = True
            if item['continuous']['wire_sha256'] != item['fresh']['wire_sha256']:
                failures.append(f'batch {batch} call {item["call"]}: persistent/fresh wire mismatch')
            calls.append(item)

    # Begin each sweep from the exact end of a complete emitted TDU, and launch
    # the next sync at every 8-kHz input position around 600 ms. No TX preamble
    # can hide a reset that erases a partly received frame sync.
    used = int(probe.lib.lifetime_prime(first_samples.ctypes.data_as(C.POINTER(C.c_int16)),len(first_samples)))
    if not used:
        failures.append('boundary setup: priming source did not emit the complete 30-unit call')
    call = first_samples[first_idle+4800:]
    noise = first_samples[:4900]
    for offset in range(-48,49):
        gap = 4800+offset
        samples = np.r_[noise[:gap],call].astype(np.int16)
        item = dict(offset_samples=offset,gap_samples=gap,sample_sha256=sha(samples.astype('<i2').tobytes()))
        for fresh,name in ((0,'continuous'),(1,'fresh')):
            actual,_ = probe.run(samples,fresh,boundary=True)
            item[name] = actual
            check_result(actual,raw,len(samples),f'boundary {offset} {name}',failures)
        if item['continuous']['wire_sha256'] != item['fresh']['wire_sha256']:
            failures.append(f'boundary {offset}: persistent/fresh wire mismatch')
        boundaries.append(item)

    malformed_prefix = None
    for item,samples in malformed_hunt_inputs(raw):
        item['sample_sha256'] = sha(samples.astype('<i2').tobytes())
        if item['kind']=='prefix':
            item.update(samples=len(samples),seconds=len(samples)/8000,
                        received=probe.malformed_prime(samples))
            malformed_prefix = item
            actual = item['received']
            if actual['units'] or actual['wire_bytes'] or actual['invalid_output']:
                failures.append('malformed prefix: invalid NIDs unexpectedly emitted a unit')
            if actual['after']['ticks'] != len(samples)*6 or not actual['clock_hook_retained']:
                failures.append('malformed prefix: sample history or profiling hook lost')
            continue
        for fresh,name in ((0,'continuous'),(1,'fresh')):
            actual,_ = probe.run(samples,fresh,boundary=True)
            item[name] = actual
            label = f'malformed recovery phase {item["phase_48khz"]} ppm {item["clock_ppm"]} {name}'
            check_result(actual,raw,len(samples),label,failures)
        if item['continuous']['wire_sha256'] != item['fresh']['wire_sha256']:
            failures.append(f'malformed recovery phase {item["phase_48khz"]} ppm {item["clock_ppm"]}: persistent/fresh wire mismatch')
        malformed_calls.append(item)

    for path in dependencies:
        if sha(path.read_bytes()) != source_hashes[str(path)]:
            failures.append('test source changed while executing: '+str(path))
    report = dict(schema=1,command='python tests/test_demod_lifetime.py',
                  source_dir=str(source),build_command=probe.command,
                  source_hashes=source_hashes,
                  op25_reference=dict(commit='3f44d43eb449bb4753247ce848bb42a403823dea',
                                      canonical_lf_sha256=OP25_SHA,
                                      working_tree_sha256=source_hashes[str(OP25)],
                                      normalization='CRLF to LF only; strict canonical Git blob SHA256'),
                  versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
                  fixture_sha256=sha(raw),known_call_units=EXPECTED_COUNTS,prime_used_samples=used,
                  known_noise_outcomes={f'{batch}/{call}':value for (batch,call),value in NOISY_OUTCOMES.items()},
                  calls=calls,boundaries=boundaries,malformed_prefix=malformed_prefix,
                  malformed_recovery_calls=malformed_calls,failures=failures,
                  limitations='Synthetic discriminator samples; no RF/ADC, DMA, codec, or realtime cost evidence.',
                  summary=dict(calls=len(calls),fresh_complete=sum(c['fresh']['units']==30 for c in calls),
                               continuous_complete=sum(c['continuous']['units']==30 for c in calls),
                               fresh_source_wire_exact=sum(c['fresh']['wire_sha256']==sha(raw) for c in calls),
                               continuous_source_wire_exact=sum(c['continuous']['wire_sha256']==sha(raw) for c in calls),
                               boundary_cases=len(boundaries),
                               boundary_fresh_complete=sum(c['fresh']['units']==30 for c in boundaries),
                               boundary_continuous_complete=sum(c['continuous']['units']==30 for c in boundaries),
                               malformed_recovery_cases=len(malformed_calls),
                               malformed_recovery_fresh_complete=sum(c['fresh']['units']==30 for c in malformed_calls),
                               malformed_recovery_continuous_complete=sum(c['continuous']['units']==30 for c in malformed_calls),
                               failures=len(failures),elapsed_seconds=round(time.monotonic()-started,3)))
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['summary']))
    for failure in failures[:12]:
        print(failure,file=sys.stderr)
    return 1 if failures else 0


if __name__=='__main__':
    raise SystemExit(main())
