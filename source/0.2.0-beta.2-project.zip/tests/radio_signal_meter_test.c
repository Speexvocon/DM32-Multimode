// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "radio_signal_meter.h"

static int16_t level(const radio_signal_meter *m,uint32_t now) {
    int16_t dbm=0;assert(radio_signal_read(m,now,&dbm));return dbm;
}

static void tdma(void) {
    // At every possible phase, 25-ms sampling observes the 30-ms burst and
    // keeps it through the intervening empty slot; 250-ms sampling cannot.
    for(unsigned phase=0;phase<60;++phase) {
        radio_signal_meter m={0};
        radio_signal_configure(&m,RADIO_SIGNAL_DMR,145700000u,0);
        for(uint32_t now=0;now<600000u;now+=25000u) {
            assert(radio_signal_due(&m,now));
            bool on=((now/1000u+phase)%60u)<30u;
            radio_signal_sample(&m,now,on ? -65 : -125);
            if(now>=120000u)assert(level(&m,now)==-65);
            assert(!radio_signal_due(&m,now+24999u));
        }
    }
    radio_signal_meter m={0};
    radio_signal_configure(&m,RADIO_SIGNAL_DMR,145700000u,0);
    radio_signal_sample(&m,0,-65);
    for(uint32_t now=25000u;now<=100000u;now+=25000u)radio_signal_sample(&m,now,-125);
    assert(level(&m,119999u)==-65);
    assert(level(&m,120000u)==-125); // Old bursts cannot pin the peak.
    assert(!radio_signal_read(&m,220000u,0));
}

static void context_and_validity(void) {
    radio_signal_meter m={0};int16_t out=7;
    radio_signal_configure(&m,RADIO_SIGNAL_FM,145700000u,1);
    radio_signal_sample(&m,1,-88);
    assert(level(&m,1)==-88);
    radio_signal_configure(&m,RADIO_SIGNAL_FM,145700000u,2);
    assert(level(&m,2)==-88); // Same context keeps a recent sample.
    radio_signal_configure(&m,RADIO_SIGNAL_DMR,145700000u,3);
    assert(!radio_signal_read(&m,3,&out) && out==7);
    assert(radio_signal_due(&m,3));
    radio_signal_sample(&m,3,-65);
    radio_signal_configure(&m,RADIO_SIGNAL_DMR,440075000u,4);
    assert(!radio_signal_read(&m,4,0));
    radio_signal_sample(&m,4,-65);
    radio_signal_configure(&m,RADIO_SIGNAL_OFF,440075000u,5);
    assert(!radio_signal_due(&m,5) && !radio_signal_read(&m,5,0));
    radio_signal_configure(&m,RADIO_SIGNAL_DMR,440075000u,6);
    assert(!radio_signal_read(&m,6,0));
    for(unsigned i=0;i<3;++i) {
        static const int16_t invalid[]={0,20,-161};
        radio_signal_sample(&m,7+i*50000,-65);
        radio_signal_sample(&m,8+i*50000,invalid[i]);
        assert(!radio_signal_read(&m,8+i*50000,0));
    }
    radio_signal_configure(&m,RADIO_SIGNAL_FM,0,1000000u);
    assert(!radio_signal_due(&m,1000000u));
}

static void continuous_and_wrap(void) {
    radio_signal_meter m={0};uint32_t start=UINT32_MAX-10000u;
    radio_signal_configure(&m,RADIO_SIGNAL_P25,440075000u,start);
    radio_signal_sample(&m,start,-125);
    assert(level(&m,start)==-125);
    assert(radio_signal_bars(level(&m,start))==1);
    assert(!radio_signal_due(&m,start+249999u));
    assert(radio_signal_due(&m,start+250000u));
    radio_signal_sample(&m,start+250000u,-73);
    assert(level(&m,start+250000u)==-73); // Continuous RF has no peak history.
    assert(radio_signal_bars(level(&m,start+250000u))==5);
    assert(radio_signal_read(&m,start+1749999u,0));
    assert(!radio_signal_read(&m,start+1750000u,0));
    radio_signal_configure(&m,RADIO_SIGNAL_DMR,440075000u,start);
    radio_signal_sample(&m,start,-88);
    assert(level(&m,start+119999u)==-88);
    assert(!radio_signal_read(&m,start+120000u,0));
}

int main(void) {
    tdma();context_and_validity();continuous_and_wrap();
    puts("signal meter checks passed");return 0;
}
