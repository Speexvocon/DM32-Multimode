// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "p25_rx.h"
#include "p25_live_frame.h"
#include "p25_interleave.h"
static bool feed(p25_rx *r,const uint8_t *p,unsigned n) {
 bool done=false;for(unsigned i=0;i<n*4;++i) {bool d=p25_rx_push(r,(p[i/4]>>(6-2*(i%4)))&3);if(d) {assert(i==n*4-1);done=true;}}return done;
}
int main(void) {
 p25_rx r;p25_rx_init(&r);uint8_t p[9][11],ldu[216],out[11];uint32_t rng=14;unsigned corrected;
 for(unsigned trial=0;trial<300;++trial) {
  for(unsigned i=0;i<99;++i) {rng=rng*1664525+1013904223;((uint8_t*)p)[i]=(uint8_t)(rng>>24);}
  p25_live_ldu(ldu,(const uint8_t (*)[11])p,trial%2);
  assert(feed(&r,ldu,216) && r.nac==0x293 && r.duid==(trial%2?10:5));
  for(unsigned f=0;f<9;++f) {assert(p25_rx_voice(r.frame,f,out,&corrected));assert(!memcmp(out,p[f],11)&&!corrected);}
  // Correct 3 bits in first Golay block, including whitening seed; 1 Hamming bit.
  for(unsigned f=0;f<9;++f) {
   const unsigned indices[]={0,8,22,92};
   for(unsigned j=0;j<4;++j) {unsigned b=p25_voice_bits[f][indices[j]];ldu[b/8]^=1u<<(7-b%8);}
  }
  for(unsigned f=0;f<9;++f) {
   p25_voice_quality quality;
   assert(p25_rx_voice(ldu,f,out,&corrected));assert(corrected==4&&!memcmp(out,p[f],11));
   assert(p25_rx_voice_quality(ldu,f,out,&quality));assert(quality.e0==3&&quality.et==4);
  }
 }
 // Recover a damaged NID, canonicalize its header, then reacquire without stale data.
 p25_live_ldu(ldu,(const uint8_t (*)[11])p,false);ldu[6]^=0x80;
 assert(feed(&r,ldu,216)&&r.nid_corrected==1);ldu[6]^=0x80;
 assert(!memcmp(r.frame,ldu,sizeof ldu));assert(feed(&r,ldu,216)&&!r.nid_corrected);
 // Corruption of the separate parity bit is rejected, then clean reacquisition works.
 ldu[14]^=0x40;assert(!feed(&r,ldu,216)&&r.bad_nid);ldu[14]^=0x40;assert(feed(&r,ldu,216));
 p25_rx_gap(&r);for(unsigned i=0;i<60;++i) p25_rx_push(&r,(ldu[i/4]>>(6-2*(i%4)))&3);
 p25_rx_gap(&r);assert(feed(&r,ldu,216));
 assert(!p25_rx_push(&r,4)&&r.bad_input==1);assert(!p25_rx_voice(ldu,9,out,&corrected));
 ldu[0]^=3;assert(feed(&r,ldu,216)); // two sync-bit errors tolerated
 puts("RX: voice roundtrip, E0/ET quality, Golay/whitening/Hamming correction, bounded NID recovery, parity refusal and reacquisition passed");
}
