"""Compile and run both diagnostics profiles without touching a radio."""
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build'/'diagnostics-profile'
UPSTREAM=ROOT/'external'/'RadioFoundry'/'RadioFoundry'
INCLUDES=['-I'+str(UPSTREAM/path) for path in (
    'hal','core','drivers','boards/dm32','platform/hrc7000',
    'platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include')]


def run(args):
    return subprocess.run([str(arg) for arg in args],cwd=ROOT,check=True,
        capture_output=True,text=True).stdout


class DiagnosticsProfiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        BUILD.mkdir(parents=True,exist_ok=True)

    def test_monitor_queues_in_both_profiles(self):
        # The same sustained queue/order regression runs with and without the
        # retained trace; only the engineering build also exercises trace wrap.
        for lab in (0,1):
            with self.subTest(lab=lab):
                output=BUILD/f'monitor-{lab}.exe'
                run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror',
                    f'-DDM32_LAB_DIAGNOSTICS={lab}','-Isrc/firmware',
                    'tests/test_p25_monitor.c','src/firmware/p25_demod.c',
                    'src/firmware/p25_rx.c','-o',output])
                run([output])

    def test_default_adapter_is_operational_and_has_no_lab_paths(self):
        # Reuse the actual hardware mocks, not a second implementation of the
        # adapter. Only the pre-existing mock prefix is used; no lab test setup
        # or engineering default overrides are copied into this normal build.
        prefix=(ROOT/'tests/test_live_adapter.c').read_text().split(
            'static void reset(void) {',1)[0]
        prefix=prefix.replace('../src/firmware/','')
        prefix=prefix.replace('../external/RadioFoundry/RadioFoundry/',
            UPSTREAM.as_posix()+'/')
        prefix=prefix.replace('../external/','external/')
        source=BUILD/'normal-adapter.c'
        source.write_text(prefix+NORMAL_MAIN,encoding='utf-8',newline='\n')
        output=BUILD/'normal-adapter.exe'
        run(['gcc','-std=gnu11','-O1','-Wall','-Wextra','-Werror',
            '-Wno-unused-parameter','-Wno-unused-function','-Wno-unused-variable',
            '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
            '-DBENCH_GIT="normal-profile"','-DCONFIG_DMR=1',
            '-Itests/diag-stubs','-Itests','-Isrc/firmware','-Ifixtures/p25-1011',
            *INCLUDES,source,'tests/diag-stubs/radio_dmr_stub.c',
            'src/firmware/p25_demod.c','src/firmware/p25_rx.c',
            'src/firmware/p25_call.c','src/firmware/p25_live_tx.c',
            'src/firmware/p25_live_frame.c','src/firmware/p25_test_tx.c',
            '-o',output])
        report=run([output])
        self.assertIn('normal diagnostics profile: PASS',report)
        symbols=run(['nm','--defined-only',output])
        for symbol in ('mon_perf','rx_signals','rx_frame_test','mon_local_frame',
                'rx_bench_yield','p25_receive_bench_profile'):
            self.assertNotRegex(symbols,rf'(?m)\b{symbol}$')
        binary=output.read_bytes()
        for text in (b'RXTRACE frames=',b'OK RXMON LOCAL',b'OK RXCAP scheduled',
                b'Run frame test',b'Enter bench mode'):
            self.assertNotIn(text,binary)

    def test_invalid_profile_is_rejected(self):
        source=BUILD/'invalid.c'
        source.write_text('#include "p25_diagnostics.h"\n',newline='\n')
        result=subprocess.run(['gcc','-std=c11','-DDM32_LAB_DIAGNOSTICS=2',
            '-Isrc/firmware','-fsyntax-only',str(source)],cwd=ROOT,
            capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('must be 0 or 1',result.stderr)


NORMAL_MAIN=r"""
_Static_assert(DM32_LAB_DIAGNOSTICS==0,"Normal diagnostics must be the default");
_Static_assert(MON_RAW_BLOCKS==16 && MON_PCM_FRAMES==48,"Production queues must not shrink");
_Static_assert(sizeof(p25_monitor)<30000,"Retained diagnostic PCM must be absent");
_Static_assert(sizeof(rx_capture)<64,"Stored raw capture must be absent");
_Static_assert(sizeof(rx_storage)>=RADIO_CODEC_WORKSPACE_BYTES,"Native DMR overlay must still fit");
int main(void) {
    assert(!tx_fixed && tx_pairs==14 && !tx_startup_extra);
    assert(tx_writer==TX_WRITER_ALT1 && tx_dac_restore && mon_pcm_backend);
    assert(radio_codec_bind_dmr(&rx_storage,sizeof rx_storage));
    menu_page=MENU_DIAGNOSTICS;assert(menu_count()==1);
    char label[40],value[60];menu_row(0,label,sizeof label,value,sizeof value);
    assert(!strcmp(label,"Radio status") && strstr(value,"counters"));
    rx_lab=true;local_action(ACT_SELECT,false);assert(!decode_calls);
    rx_lab=false;
    const char *commands[]={"RXCAP 440075000 0","RXREAD 0 0","RXMON 440075000 LOCAL",
        "RXMON 440075000 REPLAY","RXDEMOD","RXPERF","RXSIGNAL 0","RXPCM 0 0",
        "RXBITS 0","RXPROFILE 6","RXBACKEND FIFO","RXTIMER 250","RXSERVICE 1",
        "RXTONE 997","RXOUTPUT TONE","RXFIFO SINGLE","RXAUDIO OFF",
        "TXSOURCE FIXED1011","TXPAIRS 1","TXALIGN 35","TXWRITER DUP","TXDAC KEEP",
        "ARM 440075000 ALLOW_RF","SESSION 440075000 ALLOW_RF"};
    mon_running=mon_enabled=true;digital_dmr.owned=true;
    for(unsigned i=0;i<sizeof commands/sizeof *commands;++i) {
        output_n=0;strcpy(command,commands[i]);parse_command(false);
        assert(strstr(output,"ERR UNAVAILABLE"));
        assert(mon_running && mon_enabled && digital_dmr.owned);
    }
    digital_dmr.owned=false;mon_running=mon_enabled=false;
    output_n=0;strcpy(command,"STATUS");parse_command(false);
    assert(strstr(output,"RADIO rx_hz=") && !strstr(output,"RXTRACE"));
    printf("normal diagnostics profile: PASS (monitor=%zu storage=%zu raw metadata=%zu)\n",
        sizeof(p25_monitor),sizeof(rx_storage),sizeof(rx_capture));
    return 0;
}
"""

if __name__=='__main__':unittest.main(verbosity=2)
