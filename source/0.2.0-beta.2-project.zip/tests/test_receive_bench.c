// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_receive_bench.h"
#include <assert.h>
static uint32_t now,yields;
static uint32_t clock_us(void) {return now;}
static void yield_block(void) {++yields;now+=1000;}
static void decode(const uint8_t *p,int16_t *x) {(void)p;(void)x;assert(0);}
int main(void) {
    uint8_t samples[1024]={0};p25_receive_result r;
    p25_receive_bench(samples,512,0x293,clock_us,decode,yield_block,&r);
    assert(yields==3 && r.elapsed_us==3000 && !r.active_us);
    assert(!r.units && !r.voices && !r.decode_us && !r.max_block_us && r.pcm_hash==2166136261u);
}
