"""Exercise native TX queues with independent audio, slot and UI/service clocks."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RF = ROOT / "external/RadioFoundry/RadioFoundry"


class DmrTxPacing(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("gcc")
        if not compiler:
            raise unittest.SkipTest("host GCC is required")
        cls.temp = tempfile.TemporaryDirectory(prefix="dmr-tx-pacing-")
        build = Path(cls.temp.name)
        (build / "config.h").write_text(
            "#define CONFIG_SFR 0\n#define CONFIG_SFR_DUALPATH_RX 0\n"
            "#define CONFIG_DMR_TALKER_ALIAS 0\n#define CONFIG_DMR_GPS 0\n"
            "#define CONFIG_DMR_PRIVACY 0\n#define CONFIG_DEBUGLINK 0\n"
        )
        cls.binary = build / "dmr_tx_pacing_test.exe"
        sources = [ROOT / "tests/dmr_tx_pacing_test.c", ROOT / "src/firmware/radio_dmr.c"]
        sources += [RF / path for path in (
            "tests/host/sim/dmr_sim_modem.c", "core/dmr/call/dmr_call.c",
            "core/dmr/call/dmr_lc.c", "core/dmr/ambe/ambeVoice.c",
            "core/dmr/ambe/ambeFec.c", "core/dmr/fec/dmrFec.c",
        )]
        command = [compiler, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror"]
        for include in (build, ROOT / "src/firmware", RF / "core", RF / "hal", RF / "tests/host"):
            command += ["-I", str(include)]
        command += [str(source) for source in sources] + ["-o", str(cls.binary)]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            cls.temp.cleanup()
            raise RuntimeError(result.stdout + result.stderr)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def check_case(self, case):
        result = subprocess.run([str(self.binary), case], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("checks passed", result.stdout)

    def test_controller_stall_overflows_encoder_queue_despite_exact_audio_cadence(self):
        self.check_case("blocked")

    def test_stall_with_explicit_modem_event_pressure_exposes_event_drops(self):
        self.check_case("events")

    def test_delayed_audio_admission_exposes_source_silence_independently_of_encoder_cost(self):
        self.check_case("combined")

    def test_call_service_during_ui_work_preserves_20ms_audio_and_60ms_air(self):
        self.check_case("serviced")

    def test_service_cadence_and_call_completion_survive_millisecond_wrap(self):
        self.check_case("wrap")

    def test_tot_drains_normally_and_never_rekeys_held_ptt_during_ui_work(self):
        self.check_case("tot")

    def test_board_refusal_stalled_modem_stop_and_replacement_release_ownership(self):
        self.check_case("lifecycle")


if __name__ == "__main__":
    unittest.main()
