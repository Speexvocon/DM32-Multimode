"""Offline finite replay/protocol gates and interrupted-session restoration."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), ROOT/'scripts'/name)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


REPLAY = module('hotspot-dmr-replay.py')
SESSION = module('hotspot-dmr-session.py')
FIXTURE = ROOT/'fixtures/dmr-1031/call.bin'
MANIFEST = FIXTURE.with_name('manifest.json')
RETARGET = FIXTURE.parent/'tg98638/call.bin'
RETARGET_MANIFEST = RETARGET.with_name('manifest.json')
CONFIG = '''[General]
Id=1234567
Callsign=TEST
Duplex=0
[Info]
RXFrequency=145700000
TXFrequency=145700000
[Modem]
Protocol=uart
UARTPort=/dev/ttyAMA0
UARTSpeed=115200
RXOffset=125
TXOffset=-250
RXLevel=42
DMRTXLevel=50
RFLevel=100
RXInvert=1
TXInvert=0
PTTInvert=1
TXDelay=100
[DMR]
Enable=1
ColorCode=1
Beacons=1
BeaconInterval=60
[DMR Network]
Enable=1
[P25]
Enable=1
[P25 Network]
Enable=1
[CW Id]
Enable=1
'''


class Clock:
    def __init__(self): self.now = 0.0
    def __call__(self): return self.now
    def sleep(self, seconds): self.now += seconds


class FakeLink:
    def __init__(self, clock, space=2, state=None):
        self.clock, self.space, self.state = clock, space, state
        self.sent = []; self.status_calls = 0; self.last_send = 0.0
    def status(self):
        self.status_calls += 1
        if self.state is not None: return self.state
        return {'dmr': True, 'mode': 2, 'space': self.space,
                'tx': bool(self.sent) and (len(self.sent) < 86 or self.clock()-self.last_send < .1)}
    def send(self, data): self.sent.append(data); self.last_send = self.clock()


class Services:
    def __init__(self, stop_fail=None, start_fail=None, manual=False):
        self.before = {unit: i % 3 != 1 for i, unit in enumerate(SESSION.ENGINE.UNITS)}
        self.states = dict(self.before); self.actions = []; self.stop_fail = stop_fail
        self.start_fail = start_fail; self.manual = manual
    def active(self, unit): return self.states[unit]
    def manual_hosts(self): return [321] if self.manual else []
    def service(self, action, unit):
        self.actions.append((action, unit))
        if action == 'stop' and unit == self.stop_fail: raise RuntimeError('stop failure')
        if action == 'start' and unit == self.start_fail: raise RuntimeError('start failure')
        self.states[unit] = action == 'start'


class ReplayTests(unittest.TestCase):
    def test_pinned_fixture_packet_shape_and_controls(self):
        frames, report = REPLAY.load_frames(FIXTURE, MANIFEST)
        self.assertEqual(len(frames), 86)
        self.assertEqual(report['voice_frames'], 252)
        self.assertEqual(b''.join(frame[4:] for frame in frames), FIXTURE.read_bytes())
        self.assertTrue(all(frame[:3] == b'\xe0\x25\x1a' and len(frame) == 37 for frame in frames))
        self.assertEqual([frame[3] for frame in frames], REPLAY.CONTROLS)
        self.assertFalse(any(frame[2] == 0x1d for frame in frames))

    def test_tampering_and_manifest_mislabel_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            raw = Path(temporary)/'call.bin'; manifest = Path(temporary)/'manifest.json'
            raw.write_bytes(FIXTURE.read_bytes()[:-1]+b'\0'); manifest.write_bytes(MANIFEST.read_bytes())
            with self.assertRaises(ValueError): REPLAY.load_frames(raw, manifest)
            raw.write_bytes(FIXTURE.read_bytes()); info = json.loads(MANIFEST.read_text()); info['talkgroup'] = 10
            manifest.write_text(json.dumps(info))
            with self.assertRaises(ValueError): REPLAY.load_frames(raw, manifest)

    def test_exact_retarget_fixture_and_dynamic_report(self):
        frames, report = REPLAY.load_frames(RETARGET, RETARGET_MANIFEST)
        original_frames, original_report = REPLAY.load_frames(FIXTURE, MANIFEST)
        self.assertEqual(report['tg'], 98638); self.assertEqual(original_report['tg'], 9)
        self.assertEqual(report['voice_frames'], 252); self.assertEqual(len(frames), 86)
        self.assertEqual(b''.join(frame[4:] for frame in frames), RETARGET.read_bytes())
        self.assertEqual([frame[:4] for frame in frames], [frame[:4] for frame in original_frames])
        # Being one of the two supported talkgroups is insufficient: the
        # manifest destination must match the exact pinned bytes selected.
        with self.assertRaises(ValueError): REPLAY.load_frames(FIXTURE, RETARGET_MANIFEST)
        with self.assertRaises(ValueError): REPLAY.load_frames(RETARGET, MANIFEST)

    def config(self, temporary, contents=CONFIG):
        path = Path(temporary)/'modem.ini'; path.write_text(contents); return path

    def test_configuration_keeps_calibration_and_caps_power(self):
        with tempfile.TemporaryDirectory() as temporary:
            port, baud, frequency, config, lead = REPLAY.configuration(self.config(temporary), 145700000, 10)
        self.assertEqual((port, baud), ('/dev/ttyAMA0', 115200))
        self.assertEqual(struct.unpack('<II', frequency[4:12]), (145700125, 145699750))
        self.assertEqual(frequency[-1], 25)
        self.assertLessEqual(frequency[-1]/255, .1)
        self.assertEqual(config[3:], bytes((0x85, 2, 10, 0, 107, 0, 1, 0, 128, 0, 128, 0, 0)))
        self.assertAlmostEqual(lead, .6)

    def test_invalid_config_refused_before_serial_access(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = self.config(temporary)
            for hz, power in ((None, 10), (435075000, 10), (145700000, 11), (145700000, 0)):
                with self.assertRaises(ValueError): REPLAY.configuration(path, hz, power)
            for contents in (CONFIG.replace('Duplex=0', 'Duplex=1'), CONFIG.replace('ColorCode=1', 'ColorCode=2'),
                             CONFIG.replace('Protocol=uart', 'Protocol=udp'), CONFIG.replace('DMRTXLevel=50', 'DMRTXLevel=101'),
                             CONFIG.replace('TXFrequency=145700000', 'TXFrequency=145800000'),
                             CONFIG.replace('RXLevel=42', 'RXLevel=42\nrxlevel=43')):
                with self.assertRaises((ValueError, REPLAY.configparser.Error)):
                    REPLAY.configuration(self.config(temporary, contents), 145700000, 10)

    def test_finite_inventory_and_observed_drain(self):
        frames, _ = REPLAY.load_frames(FIXTURE, MANIFEST); clock = Clock(); link = FakeLink(clock)
        result = REPLAY.replay(link, frames, .6, clock, clock.sleep)
        self.assertEqual(link.sent, frames); self.assertGreater(link.status_calls, len(frames))
        self.assertEqual(result['units_sent'], 86); self.assertTrue(result['tx_observed'])
        self.assertGreater(clock()-link.last_send, .5); self.assertFalse(result['rf_decode_verified'])

    def test_no_space_times_out_without_writing(self):
        frames, _ = REPLAY.load_frames(FIXTURE, MANIFEST); clock = Clock(); link = FakeLink(clock, space=1)
        with self.assertRaises(TimeoutError): REPLAY.replay(link, frames, .6, clock, clock.sleep)
        self.assertEqual(link.sent, []); self.assertLess(clock(), 14)

    def test_wrong_mode_and_nak_fail_closed(self):
        frames, _ = REPLAY.load_frames(FIXTURE, MANIFEST)
        for state in ({'dmr': False, 'mode': 4, 'space': 20, 'tx': False},
                      {'dmr': True, 'mode': 17, 'space': 20, 'tx': True}):
            clock = Clock(); link = FakeLink(clock, state=state)
            with self.assertRaises(RuntimeError): REPLAY.replay(link, frames, .6, clock, clock.sleep)
            self.assertEqual(link.sent, [])
        serial = types.SimpleNamespace(write=lambda value: len(value), read=lambda count: b'\xe0\x05\x7f\x1a\x05')
        with self.assertRaises(RuntimeError): REPLAY.Link(serial).query(1)

    def test_status_uses_dmr_fifo_not_p25_fifo(self):
        link = REPLAY.Link(None)
        link.query = lambda command: bytes((0xe0, 14, 1, 2, 2, 1, 0, 10, 3, 0, 99, 0, 0, 0))
        self.assertEqual(link.status(), {'dmr': True, 'mode': 2, 'tx': True, 'space': 3})
        link.query = lambda command: bytes((0xe0, 9, 1, 2, 2, 8, 0, 10, 3))
        with self.assertRaises(RuntimeError): link.status()

    def test_offline_default_never_queries_system_or_serial(self):
        args = ['--fixture', str(FIXTURE), '--manifest', str(MANIFEST)]
        with patch.object(REPLAY, 'transmit', side_effect=AssertionError('RF not allowed')):
            with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(REPLAY.main(args), 0)
        with patch.object(SESSION.ENGINE, 'System', side_effect=AssertionError('No service query')):
            with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(SESSION.main(args), 0)


class SessionTests(unittest.TestCase):
    def setup_session(self, temporary):
        source = Path(temporary)/'config.ini'; source.write_text(CONFIG)
        return source, {'original_config_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}

    def test_private_config_disables_every_network_and_beacons(self):
        text, _ = SESSION.REPLAY.TRACE.transform_config(CONFIG, Path('/private/test'))
        cfg = REPLAY.configparser.ConfigParser(); cfg.read_string(text)
        self.assertEqual(cfg.getint('General', 'Duplex'), 0)
        self.assertEqual(cfg.getint('DMR', 'Enable'), 1)
        self.assertEqual(cfg.getint('DMR', 'Beacons'), 0)
        self.assertEqual(cfg.getint('DMR', 'BeaconInterval'), 0)
        for section in ('DMR Network', 'P25 Network', 'CW Id', 'P25'):
            self.assertEqual(cfg.getint(section, 'Enable'), 0)
        self.assertEqual(cfg.getint('Modem', 'DMRTXLevel'), 50)
        self.assertEqual(cfg.getint('Info', 'TXFrequency'), 145700000)

    def test_p25_offline_dispatch_uses_only_pinned_clear_14_pairs(self):
        fixture = ROOT/'fixtures/p25-1011/call.bin'
        frames, report = SESSION.fixture_frames('p25', fixture, Path('/unused/manifest.json'))
        self.assertEqual(len(frames), 30); self.assertEqual(report['units'], 30)
        self.assertEqual(report['voice_frames'], 252); self.assertEqual(report['nac'], '293')
        with patch.object(SESSION.ENGINE, 'System', side_effect=AssertionError('No system access')):
            with contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(SESSION.main(['--mode', 'p25', '--fixture', str(fixture),
                                               '--manifest', '/unused/manifest.json']), 0)
        self.assertTrue(json.loads(output.getvalue())['dry_run'])
        self.assertEqual(json.loads(output.getvalue())['units'], 30)

    def test_p25_config_and_child_command_preserve_profile_below_ten_percent(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary)/'modem.ini'
            source.write_text(CONFIG.replace('DMRTXLevel=50', 'DMRTXLevel=50\nP25TXLevel=60'))
            _, _, freq, config, _ = SESSION.configuration('p25', source, 145700000, 10)
        self.assertEqual(struct.unpack('<II', freq[4:12]), (145700125, 145699750))
        self.assertEqual(freq[-1], 23); self.assertLessEqual(freq[-1]/255, .1)
        self.assertEqual(config[3] & 0x87, 0x85); self.assertEqual(config[4], 8)
        self.assertEqual(config[-1], 153)
        cmd = SESSION.child_command('/private/config.ini', '/private/call.bin', None, 145700000, 9, 'p25')
        self.assertEqual(Path(cmd[2]).name, 'hotspot-p25-replay.py')
        self.assertNotIn('--manifest', cmd)
        self.assertEqual(cmd[cmd.index('--pairs')+1], '14')
        self.assertEqual(cmd[cmd.index('--case')+1], 'clear')
        self.assertEqual(cmd[cmd.index('--rf-power')+1], '9')
        self.assertEqual(cmd[cmd.index('--frequency')+1], '145700000')
        for frequency, power in ((435075000, 9), (145700000, 11)):
            with self.assertRaises(ValueError): SESSION.configuration('p25', '/unused', frequency, power)

    def test_p25_private_config_preserves_ten_unit_guard_and_disables_other_modes(self):
        text, _ = SESSION.private_configuration('p25', CONFIG, Path('/private/test'))
        cfg = REPLAY.configparser.ConfigParser(); cfg.read_string(text)
        self.assertEqual(cfg.getint('P25', 'Enable'), 1)
        self.assertEqual(cfg.getint('DMR', 'Enable'), 0)
        self.assertEqual(cfg.getint('DMR', 'Beacons'), 0)
        for section in ('DMR Network', 'P25 Network', 'CW Id'):
            self.assertEqual(cfg.getint(section, 'Enable'), 0)
        self.assertEqual(len(SESSION.ENGINE.UNITS), 10)
        self.assertIn('dmrgateway.service', SESSION.ENGINE.UNITS)
        self.assertIn('p25parrot.service', SESSION.ENGINE.UNITS)

    def test_p25_child_requires_thirty_units_and_observed_tx(self):
        for units in (30, 86):
            with self.subTest(units=units), tempfile.TemporaryDirectory() as temporary:
                output = Path(temporary)
                def launch(command, stdout, **kwargs):
                    self.assertEqual(Path(command[2]).name, 'hotspot-p25-replay.py')
                    stdout.write((json.dumps({'units_sent': units, 'tx_observed': True})+'\n').encode())
                    stdout.flush()
                    return types.SimpleNamespace(returncode=0, wait=lambda timeout: 0, poll=lambda: 0)
                with patch.object(SESSION.subprocess, 'Popen', side_effect=launch):
                    args = ('/private/config', '/private/call.bin', None, 145700000, 9, output, 'p25')
                    if units == 30:
                        self.assertEqual(SESSION.child_replay(*args)['units_sent'], 30)
                    else:
                        with self.assertRaises(RuntimeError): SESSION.child_replay(*args)

    def test_success_restores_exact_set_after_settle(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, report = self.setup_session(temporary); system = Services(); events = []
            def operation():
                self.assertFalse(any(system.states.values())); events.append('operation'); return {'units_sent': 86}
            def settle(seconds):
                self.assertFalse(any(system.states.values())); self.assertEqual(seconds, 3); events.append('settle')
            SESSION.execute_session(system, operation, source, report, settle, lambda: events.append('cleanup'))
        self.assertEqual(events, ['operation', 'cleanup', 'settle'])
        self.assertEqual(system.states, system.before); self.assertTrue(report['services_restored'])
        self.assertTrue(report['original_config_unchanged']); self.assertEqual(report['cleanup_errors'], [])
        self.assertEqual([unit for action, unit in system.actions if action == 'start'],
                         [unit for unit in reversed(SESSION.ENGINE.UNITS) if system.before[unit]])

    def test_operation_and_partial_stop_failures_restore(self):
        for failure in ('operation', 'stop', 'manual'):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary:
                source, report = self.setup_session(temporary)
                system = Services(stop_fail=SESSION.ENGINE.UNITS[2] if failure == 'stop' else None,
                                  manual=failure == 'manual')
                def operation(): raise RuntimeError('injected child failure')
                with self.assertRaises(RuntimeError): SESSION.execute_session(system, operation, source, report, lambda _: None)
                self.assertEqual(system.states, system.before); self.assertTrue(report['services_restored'])

    def test_settle_failure_does_not_skip_service_restoration(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, report = self.setup_session(temporary); system = Services()
            def settle(_): raise OSError('interrupted settling')
            SESSION.execute_session(system, lambda: {}, source, report, settle)
            self.assertEqual(system.states, system.before); self.assertTrue(report['services_restored'])
            self.assertEqual(report['cleanup_errors'], ['OSError: settle'])

    def test_restore_failure_and_config_change_are_reported(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, report = self.setup_session(temporary)
            system = Services(start_fail=SESSION.ENGINE.UNITS[0])
            def operation(): source.write_text(CONFIG+'\n# changed\n'); return {}
            SESSION.execute_session(system, operation, source, report, lambda _: None)
            self.assertFalse(report['services_restored']); self.assertFalse(report['original_config_unchanged'])
            self.assertTrue(report['cleanup_errors'])

    def test_report_io_failure_preserves_safe_restoration_summary(self):
        report = {'result': 'complete', 'services_restored': True, 'original_config_unchanged': True}
        with patch.object(Path, 'write_text', side_effect=OSError(5, 'private filesystem path')):
            self.assertFalse(SESSION.write_report(Path('/private/session'), report))
        self.assertEqual(report['result'], 'failed')
        self.assertTrue(report['services_restored']); self.assertTrue(report['original_config_unchanged'])
        self.assertEqual(report['report_write_error'], {'error_type': 'OSError', 'error_errno': 5})
        self.assertNotIn('private', json.dumps(report))


if __name__ == '__main__':
    unittest.main(verbosity=2)
