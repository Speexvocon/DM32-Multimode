"""Settings restoration must verify the protocol without rewriting saved values."""
import contextlib
import importlib.util
import io
import itertools
import json
from pathlib import Path
import unittest
from unittest import mock


SPEC=importlib.util.spec_from_file_location('settings',Path(__file__).resolve().parents[1]/'scripts/p25-settings.py')
settings=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(settings)


def status(profile,*,state='saved',dirty=0,inhibit=1,monitor=False,version=None,tx_inhibit=None,
           operating=None,prom_mode=None,radio_prom=None):
    rows=[
        'LIVE git=test active=0 rf=0 armed=0 session=0',
        'RXCAP pending=0 sampling=0 blocks=0',
        f"RADIO rx_hz={profile['rx_hz']} tx_hz={profile['tx_hz']} split={int(profile['rx_hz']!=profile['tx_hz'])} "
        f"nac={profile['nac']:03x} tg={profile['talkgroup']} source={profile['source_id']} inhibit={inhibit}",
        f"PREF state={state} dirty={dirty} writable=1 sequence=4 mic_db={profile['mic_gain_db']}",
        'LIVE_AUDIO clipped=0',
    ]
    if version is not None:rows[-2]+=' version='+str(version)
    if tx_inhibit is not None:rows[-2]+=' tx_inhibit='+str(tx_inhibit)
    if prom_mode is not None:rows[-2]+=' prom_mode='+str(prom_mode)
    if radio_prom is not None:rows[-3]+=' prom='+str(radio_prom)
    if operating is not None:rows.insert(0,operating)
    elif version in (2,3) and tx_inhibit in (0,1):
        prom='' if prom_mode is None else f' prom={prom_mode}'
        rows.insert(0,f'OPERATING mode=BENCH owner_inhibit={tx_inhibit} ptt_release=0'+prom)
    if monitor:rows.insert(2,'RXMON enabled=0 running=0')
    return rows


class FakeSerial:
    def __init__(self,snapshots,ack='OK CHANNEL; TX inhibited'):
        self.snapshots=list(snapshots)
        self.ack=ack
        self.commands=[]
        self.lines=[]

    def write(self,raw):
        command=raw.decode('ascii').strip()
        self.commands.append(command)
        if command=='STATUS':
            if not self.snapshots:raise AssertionError('Unexpected extra STATUS')
            self.lines.extend(self.snapshots.pop(0))
        elif command.startswith('CHANNEL '):
            self.lines.append(self.ack)
        else:raise AssertionError('Unexpected command: '+command)
        return len(raw)

    def readline(self):
        return (self.lines.pop(0)+'\r\n').encode('ascii') if self.lines else b''


class Profile(unittest.TestCase):
    def setUp(self):
        self.p=dict(rx_hz=145700000,tx_hz=145700000,nac=659,talkgroup=10,
                    source_id=1234567,mic_gain_db=22,split=False)

    def run_configure(self,radio,profile=None):
        self.log=io.StringIO()
        with contextlib.redirect_stdout(io.StringIO()),mock.patch.object(
                settings.time,'monotonic',side_effect=itertools.count(0,.1)):
            return settings.configure(radio,self.log,self.p if profile is None else profile)

    def test_command(self):
        self.assertEqual(settings.command_for(self.p),'CHANNEL 145700000 145700000 659 10 1234567 22')

    def test_invalid(self):
        for key,value in [('rx_hz',1),('mic_gain_db',43),('mic_gain_db',-1),('source_id',0),
                          ('nac',4096),('talkgroup',True),('split',True)]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                settings.command_for(dict(self.p,**{key:value}))

    def test_identical_saved_22_db_does_not_write_channel(self):
        radio=FakeSerial([status(self.p)])
        result=self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS'])
        self.assertEqual(result['PREF']['sequence'],'4')
        self.assertEqual(result['PREF']['mic_db'],'22')
        self.assertEqual([json.loads(row)['line'] for row in self.log.getvalue().splitlines()],status(self.p))

    def test_saved_split_profile_with_idle_monitor_is_no_op(self):
        profile=dict(self.p,tx_hz=146300000,split=True)
        radio=FakeSerial([status(profile,monitor=True)])
        self.run_configure(radio,profile)
        self.assertEqual(radio.commands,['STATUS'])

    def test_gain_change_sends_channel_and_verifies_new_status(self):
        radio=FakeSerial([status(dict(self.p,mic_gain_db=20)),status(self.p)])
        result=self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])
        self.assertEqual(result['PREF']['mic_db'],'22')

    def test_v2_owner_permission_is_distinct_from_current_inhibit(self):
        for owner_inhibit in (0,1):
            with self.subTest(owner_inhibit=owner_inhibit):
                radio=FakeSerial([status(self.p,version=2,tx_inhibit=owner_inhibit)])
                result=self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])
                self.assertEqual(result['RADIO']['inhibit'],'1')
                self.assertEqual(result['PREF']['tx_inhibit'],str(owner_inhibit))

    def test_v2_gain_change_preserves_enabled_owner_permission(self):
        radio=FakeSerial([status(dict(self.p,mic_gain_db=20),version=2,tx_inhibit=0),
                          status(self.p,version=2,tx_inhibit=0)])
        result=self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])
        self.assertEqual(result['PREF']['tx_inhibit'],'0')
        self.assertEqual(result['RADIO']['inhibit'],'1')

    def test_explicit_tx_inhibit_profile_is_rejected_without_port_io(self):
        for value in (True,False,0,1,None,'1'):
            with self.subTest(value=value):
                radio=FakeSerial([])
                with self.assertRaisesRegex(ValueError,'tx_inhibit is not supported'):
                    self.run_configure(radio,dict(self.p,tx_inhibit=value))
                self.assertEqual(radio.commands,[])

    def test_malformed_v2_metadata_fails_before_channel(self):
        for version,inhibit in [(2,None),(2,2),(2,-1),(2,'oops'),(None,1),(3,1),('oops',1)]:
            with self.subTest(version=version,inhibit=inhibit):
                radio=FakeSerial([status(self.p,version=version,tx_inhibit=inhibit)])
                with self.assertRaises(RuntimeError):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])

    def test_malformed_v2_readback_never_confirms_save(self):
        radio=FakeSerial([status(dict(self.p,mic_gain_db=20),version=2,tx_inhibit=1),
                          status(self.p,version=2)])
        with self.assertRaisesRegex(RuntimeError,'PREF tx_inhibit'):self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_v3_owner_and_filter_are_preserved_for_no_op_and_channel(self):
        for owner_inhibit,prom in itertools.product((0,1),repeat=2):
            with self.subTest(owner_inhibit=owner_inhibit,prom=prom):
                metadata=dict(version=3,tx_inhibit=owner_inhibit,prom_mode=prom,radio_prom=prom)
                radio=FakeSerial([status(self.p,**metadata)])
                self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])
                radio=FakeSerial([status(dict(self.p,mic_gain_db=20),**metadata),status(self.p,**metadata)])
                result=self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])
                self.assertEqual(result['PREF']['prom_mode'],str(prom))
                self.assertEqual(result['PREF']['tx_inhibit'],str(owner_inhibit))

    def test_explicit_prom_profile_is_rejected_without_port_io(self):
        for value in (True,False,0,1,None,'1'):
            with self.subTest(value=value):
                radio=FakeSerial([])
                with self.assertRaisesRegex(ValueError,'prom_mode is not supported'):
                    self.run_configure(radio,dict(self.p,prom_mode=value))
                self.assertEqual(radio.commands,[])

    def test_v3_invalid_missing_or_disagreeing_filter_fails_closed(self):
        invalid=[dict(version=3,tx_inhibit=0),dict(version=3,tx_inhibit=0,prom_mode=2),
                 dict(version=3,tx_inhibit=0,prom_mode=-1),dict(version=3,tx_inhibit=0,prom_mode='oops'),
                 dict(prom_mode=0),dict(version=4,tx_inhibit=0,prom_mode=0),
                 dict(version=3,tx_inhibit=0,prom_mode=1,radio_prom=0),
                 dict(version=3,tx_inhibit=0,prom_mode=1,radio_prom='oops'),
                 dict(version=3,tx_inhibit=0,prom_mode=1,
                      operating='OPERATING mode=BENCH owner_inhibit=0 ptt_release=0 prom=0'),
                 dict(version=3,tx_inhibit=0,prom_mode=1,
                      operating='OPERATING mode=BENCH owner_inhibit=0 ptt_release=0')]
        for metadata in invalid:
            with self.subTest(metadata=metadata):
                radio=FakeSerial([status(self.p,**metadata)])
                with self.assertRaises(RuntimeError):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])

    def test_v3_filter_change_or_missing_filter_cannot_confirm_channel(self):
        for after in [status(self.p,version=3,tx_inhibit=0,prom_mode=0),
                      status(self.p,version=2,tx_inhibit=0)]:
            with self.subTest(after=after):
                radio=FakeSerial([status(dict(self.p,mic_gain_db=20),version=3,tx_inhibit=0,prom_mode=1),after])
                with self.assertRaisesRegex(RuntimeError,'Retained RX filter changed'):
                    self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_changed_or_missing_retained_permission_is_not_success(self):
        for after in [status(self.p,version=2,tx_inhibit=1),status(self.p)]:
            with self.subTest(after=after):
                radio=FakeSerial([status(dict(self.p,mic_gain_db=20),version=2,tx_inhibit=0),after])
                with self.assertRaisesRegex(RuntimeError,'Retained TX permission changed'):
                    self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_radio_mode_needs_bench_for_actual_restore(self):
        operating='OPERATING mode=RADIO owner_inhibit=1 ptt_release=0'
        radio=FakeSerial([status(dict(self.p,mic_gain_db=20),version=2,tx_inhibit=1,operating=operating)])
        with self.assertRaisesRegex(RuntimeError,'Bench / stop radio'):self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS'])
        # Merely verifying an already saved idle profile changes no operating state.
        radio=FakeSerial([status(self.p,version=2,tx_inhibit=1,operating=operating)])
        self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS'])

    def test_malformed_operating_state_or_owner_mismatch_fails_closed(self):
        for operating in ['OPERATING owner_inhibit=1 ptt_release=0',
                          'OPERATING mode=RADIO owner_inhibit=1 ptt_release=oops',
                          'OPERATING mode=BENCH owner_inhibit=2 ptt_release=0',
                          'OPERATING mode=BENCH owner_inhibit=1 ptt_release=1',
                          'OPERATING mode=BENCH owner_inhibit=0 ptt_release=0']:
            with self.subTest(operating=operating):
                radio=FakeSerial([status(self.p,version=2,tx_inhibit=1,operating=operating)])
                with self.assertRaises(RuntimeError):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])

    def test_each_profile_difference_requires_write(self):
        for key,value in [('rx_hz',146300000),('tx_hz',146300000),('nac',0x2a3),
                          ('talkgroup',123),('source_id',123456),('mic_gain_db',20)]:
            with self.subTest(key=key):
                radio=FakeSerial([status(dict(self.p,**{key:value})),status(self.p)])
                self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_non_saved_or_dirty_profile_never_skips(self):
        for state,dirty in [('pending',0),('read_only',0),('save_failed',1),('defaults',0),('saved',1)]:
            with self.subTest(state=state,dirty=dirty):
                radio=FakeSerial([status(self.p,state=state,dirty=dirty),status(self.p)])
                self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_uninhibited_idle_profile_requires_channel_to_inhibit(self):
        radio=FakeSerial([status(self.p,inhibit=0),status(self.p)])
        self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_unset_channel_can_be_restored(self):
        radio=FakeSerial([status(dict(self.p,rx_hz=0,tx_hz=0),state='defaults'),status(self.p)])
        self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_equal_frequency_split_is_normalized_by_channel(self):
        rows=[row.replace('split=0','split=1') for row in status(self.p)]
        radio=FakeSerial([rows,status(self.p)])
        self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_failed_save_or_uninhibited_readback_is_not_success(self):
        for state,dirty,inhibit in [('pending',0,1),('save_failed',1,1),('saved',1,1),('saved',0,0)]:
            with self.subTest(state=state,dirty=dirty,inhibit=inhibit):
                radio=FakeSerial([status(dict(self.p,mic_gain_db=20)),
                                  status(self.p,state=state,dirty=dirty,inhibit=inhibit)])
                with self.assertRaisesRegex(RuntimeError,'persistent save not verified'):
                    self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_readback_mismatch_is_not_success(self):
        for key,value in [('rx_hz',146300000),('tx_hz',146300000),('nac',0x2a3),
                          ('talkgroup',123),('source_id',123456),('mic_gain_db',20)]:
            with self.subTest(key=key):
                radio=FakeSerial([status(dict(self.p,mic_gain_db=20)),status(dict(self.p,**{key:value}))])
                with self.assertRaisesRegex(RuntimeError,'readback mismatch'):self.run_configure(radio)

    def test_busy_flags_reject_before_any_mutation(self):
        for row,key in [('LIVE','active'),('LIVE','rf'),('LIVE','armed'),('LIVE','session'),
                        ('RXCAP','pending'),('RXCAP','sampling'),('RXMON','enabled'),('RXMON','running')]:
            with self.subTest(row=row,key=key):
                rows=status(self.p,monitor=True)
                rows=[line.replace(key+'=0',key+'=1') if line.startswith(row+' ') else line for line in rows]
                radio=FakeSerial([rows])
                with self.assertRaisesRegex(RuntimeError,'Stop RX/TX'):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])

    def test_missing_status_rows_fail_closed(self):
        for missing in ('LIVE','RXCAP','RADIO','PREF','LIVE_AUDIO'):
            with self.subTest(missing=missing):
                radio=FakeSerial([[row for row in status(self.p) if not row.startswith(missing+' ')]])
                with self.assertRaises((RuntimeError,TimeoutError)):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])

    def test_malformed_or_missing_fields_fail_closed(self):
        replacements=[('active=0','active=oops'),('armed=0','armed=2'),('sampling=0',''),
                      ('nac=293','nac=xyz'),('mic_db=22','mic_db=43'),('dirty=0','dirty=2'),
                      ('split=0','split=2'),('inhibit=1','inhibit=-1'),('state=saved',''),
                      ('source=1234567','source=0'),('rx_hz=145700000','rx_hz=1'),
                      ('tg=10','tg=10 tg=11'),('state=saved','state=saved unexpected')]
        for old,new in replacements:
            with self.subTest(old=old,new=new):
                radio=FakeSerial([[row.replace(old,new) for row in status(self.p)]])
                with self.assertRaises(RuntimeError):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS'])

    def test_duplicate_required_row_fails_closed(self):
        rows=status(self.p);rows.insert(1,rows[0])
        radio=FakeSerial([rows])
        with self.assertRaisesRegex(RuntimeError,'Duplicate status'):self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS'])

    def test_missing_monitor_row_after_monitor_storage_fails_closed(self):
        rows=[row+' reason=monitor_storage' if row.startswith('RXCAP ') else row for row in status(self.p)]
        radio=FakeSerial([rows])
        with self.assertRaisesRegex(RuntimeError,'Missing RXMON'):self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS'])

    def test_missing_malformed_or_busy_readback_is_not_success(self):
        rows=status(self.p)
        bad_snapshots=[
            [row for row in rows if not row.startswith('PREF ')],
            [row.replace('mic_db=22','mic_db=oops') for row in rows],
            [row.replace('active=0','active=1') for row in rows],
        ]
        for after in bad_snapshots:
            with self.subTest(after=after):
                radio=FakeSerial([status(dict(self.p,mic_gain_db=20)),after])
                with self.assertRaises(RuntimeError):self.run_configure(radio)
                self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p),'STATUS'])

    def test_busy_response_or_command_rejection_fails(self):
        radio=FakeSerial([['LIVE BUSY; STATUS after capture/call']])
        with self.assertRaisesRegex(RuntimeError,'LIVE BUSY'):self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS'])
        radio=FakeSerial([status(dict(self.p,mic_gain_db=20))],ack='ERR CHANNEL requires idle')
        with self.assertRaisesRegex(RuntimeError,'ERR CHANNEL'):self.run_configure(radio)
        self.assertEqual(radio.commands,['STATUS',settings.command_for(self.p)])

    def test_invalid_profile_never_touches_port(self):
        radio=FakeSerial([])
        with self.assertRaises(ValueError):self.run_configure(radio,dict(self.p,mic_gain_db=43))
        self.assertEqual(radio.commands,[])


if __name__=='__main__':unittest.main()
