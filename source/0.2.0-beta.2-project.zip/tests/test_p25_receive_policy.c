// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_receive_policy.h"
#include "fixtures/p25_call_vectors.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

// Deliberately explicit, independently assembled metadata. These tests isolate
// authorization/lifecycle from the coding tests for HDU/LC/ESS extraction.
static p25_call_metadata header(uint16_t group,uint8_t algid) {
    p25_call_metadata m={0};m.group=group;m.algid=algid;m.keyid=algid==0x80 ? 0 : 0x1234;
    m.ess_valid=m.group_valid=m.mfid_valid=1;
    m.classification=algid==0x80 ? P25_CALL_CLEAR : P25_CALL_ENCRYPTED;
    return m;
}
static p25_call_metadata link(uint16_t group,uint32_t source) {
    p25_call_metadata m={0};m.group=group;m.source=source;
    m.lc_valid=m.group_valid=m.source_valid=m.mfid_valid=1;m.classification=P25_CALL_CLEAR;
    return m;
}
static p25_call_metadata ess(uint8_t algid) {
    p25_call_metadata m={0};m.algid=algid;m.keyid=algid==0x80 ? 0 : 0x1234;
    m.ess_valid=1;m.classification=algid==0x80 ? P25_CALL_CLEAR : P25_CALL_ENCRYPTED;
    return m;
}
static void qualify(p25_receive_policy *s,uint32_t at) {
    p25_call_metadata h=header(10,0x80),lc=link(10,1234567);
    p25_receive_reset(s);
    p25_receive_event e=p25_receive_update(s,0x293,0,&h,true,at);
    assert(e.new_call && e.reset && e.discard && !e.voice);
    assert(s->active && s->ess_valid && s->group_valid && !s->lc_valid && !s->source_valid);
    assert(s->state==P25_RX_WAIT_METADATA);
    e=p25_receive_update(s,0x293,5,&lc,true,at+180000u);
    assert(e.voice && e.reset && !e.discard && !e.new_call);
    assert(s->state==P25_RX_CLEAR && s->source==1234567 && s->group==10);
}

static void late_entry(void) {
    p25_receive_policy s;p25_receive_reset(&s);
    p25_call_metadata lc=link(10,1234567),en=ess(0x80);
    p25_receive_event e=p25_receive_update(&s,0x293,5,&lc,true,0);
    assert(e.new_call && e.discard && !e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,180000);
    assert(!e.voice && e.reset && s.state==P25_RX_CLEAR); // ESS applies to the next pair.
    e=p25_receive_update(&s,0x293,5,&lc,true,360000);
    assert(e.voice && s.state==P25_RX_CLEAR);
    p25_receive_reset(&s);
    e=p25_receive_update(&s,0x293,10,&en,true,0);
    assert(e.new_call && !e.voice && !s.lc_valid);
    e=p25_receive_update(&s,0x293,5,&lc,true,180000);
    assert(e.voice && e.reset && s.state==P25_RX_CLEAR);
}

static void damaged_control(void) {
    p25_receive_policy s;p25_receive_event e;
    p25_call_metadata lc=link(10,1234567),en=ess(0x80),h=header(10,0x80);
    qualify(&s,0);
    // Corrupt HDU is still a call boundary: no old ESS/LC may survive it.
    e=p25_receive_update(&s,0x293,0,&h,false,360000);
    assert(e.new_call && e.reset && e.discard && !e.voice && s.state==P25_RX_BAD_METADATA);
    assert(!s.ess_valid && !s.lc_valid && !s.group_valid && !s.source_valid);
    e=p25_receive_update(&s,0x293,5,&lc,true,540000);
    assert(!e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,720000);
    assert(!e.voice && e.reset); // Newly recovered ESS cannot authorize this LDU2.
    // Failed LC invalidates its identity fields despite a previously clear ESS.
    e=p25_receive_update(&s,0x293,5,&lc,false,900000);
    assert(!e.voice && e.discard && !s.lc_valid && !s.group_valid && !s.source_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,1080000);
    assert(!e.voice && !s.lc_valid);
    e=p25_receive_update(&s,0x293,5,&lc,true,1260000);
    assert(e.voice && e.reset);
    // Failed ESS must revoke clear voice before the next PCM is produced.
    e=p25_receive_update(&s,0x293,10,&en,false,1440000);
    assert(!e.voice && e.discard && !s.ess_valid && !s.algid && !s.keyid);
    e=p25_receive_update(&s,0x293,5,&lc,true,1620000);
    assert(!e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,1800000);
    assert(!e.voice && e.reset);
    // Valid decoder return without the applicable validity bit is also bad.
    lc.lc_valid=0;
    e=p25_receive_update(&s,0x293,5,&lc,true,1980000);
    assert(!e.voice && e.discard && !s.lc_valid);
    en.ess_valid=0;
    e=p25_receive_update(&s,0x293,10,&en,true,2160000);
    assert(!e.voice && !s.ess_valid);
}

static void encrypted_and_unsupported(void) {
    p25_receive_policy s;p25_receive_event e;
    p25_call_metadata lc=link(10,1234567),en=ess(0x84),h=header(10,0x80);
    qualify(&s,0);
    e=p25_receive_update(&s,0x293,10,&en,true,360000);
    assert(e.discard && !e.voice && s.state==P25_RX_ENCRYPTED && s.keyid==0x1234);
    assert(!strcmp(p25_receive_label(&s),"ENCRYPTED / MUTED"));
    // Encryption changes carried by an otherwise complete supported LC mute.
    lc.service_options=0x40;lc.classification=P25_CALL_ENCRYPTED;
    e=p25_receive_update(&s,0x293,5,&lc,true,540000);
    assert(!e.voice && s.state==P25_RX_ENCRYPTED);
    en=ess(0x80);
    e=p25_receive_update(&s,0x293,10,&en,true,720000);
    assert(!e.voice && s.state==P25_RX_ENCRYPTED); // ESS alone cannot clear encrypted LC.
    lc=link(10,1234567);
    e=p25_receive_update(&s,0x293,5,&lc,true,900000);
    assert(e.voice && e.reset && s.state==P25_RX_CLEAR);
    // Protected LC has opaque identity, even if a caller accidentally supplies
    // stale values alongside false validity flags.
    lc.protected_flag=1;lc.classification=P25_CALL_ENCRYPTED;
    lc.group_valid=lc.source_valid=lc.mfid_valid=0;
    e=p25_receive_update(&s,0x293,5,&lc,true,1080000);
    assert(!e.voice && e.discard && !s.group_valid && !s.source_valid);
    assert(s.state==P25_RX_ENCRYPTED);
    // Unsupported manufacturer/call type never becomes voice merely because
    // it carries clear ESS and numeric group/source values.
    qualify(&s,0);lc=link(10,1234567);lc.mfid=0x90;lc.classification=P25_CALL_UNSUPPORTED;
    e=p25_receive_update(&s,0x293,5,&lc,true,360000);
    assert(!e.voice && e.discard && s.state==P25_RX_UNSUPPORTED);
    e=p25_receive_update(&s,0x293,10,&en,true,540000);
    assert(!e.voice && s.state==P25_RX_UNSUPPORTED);
    h.mfid=0x90;h.classification=P25_CALL_UNSUPPORTED;
    e=p25_receive_update(&s,0x293,0,&h,true,720000);
    assert(!e.voice && e.new_call && s.header_unsupported);
    lc=link(10,1234567);
    e=p25_receive_update(&s,0x293,5,&lc,true,900000);
    assert(!e.voice && s.state==P25_RX_UNSUPPORTED);
    e=p25_receive_update(&s,0x293,10,&en,true,1080000);
    assert(!e.voice && s.state==P25_RX_UNSUPPORTED);
    h=header(10,0x80);
    e=p25_receive_update(&s,0x293,0,&h,true,1260000);
    assert(e.new_call && !s.header_unsupported);
    e=p25_receive_update(&s,0x293,5,&lc,true,1440000);
    assert(e.voice && s.state==P25_RX_CLEAR);
}

static void boundaries_and_missing_control(void) {
    p25_receive_policy s;p25_receive_event e;
    p25_call_metadata lc=link(10,1234567),en=ess(0x80);
    qualify(&s,0);
    e=p25_receive_update(&s,0x293,5,&lc,true,360000); // Missing LDU2.
    assert(e.reset && e.discard && !e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,540000);
    assert(!e.voice && e.reset);
    e=p25_receive_update(&s,0x293,10,&en,true,720000); // Missing LDU1.
    assert(e.reset && e.discard && !e.voice && !s.lc_valid && !s.source_valid && !s.group_valid);
    e=p25_receive_update(&s,0x293,5,&lc,true,900000);
    assert(e.voice && e.reset);
    // A changed caller or group cannot reuse the preceding call's ESS.
    e=p25_receive_update(&s,0x293,10,&en,true,1080000);assert(e.voice);
    lc.source=3166362;
    e=p25_receive_update(&s,0x293,5,&lc,true,1260000);
    assert(e.new_call && e.reset && e.discard && !e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,1440000);assert(!e.voice && s.state==P25_RX_CLEAR);
    lc.group=11;
    e=p25_receive_update(&s,0x293,5,&lc,true,1620000);
    assert(e.new_call && !e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,1800000);assert(!e.voice && s.state==P25_RX_CLEAR);
    // PROM's selection of another NAC requires completely fresh qualification.
    e=p25_receive_update(&s,0x2a3,5,&lc,true,1980000);
    assert(e.new_call && e.discard && !e.voice && !s.ess_valid && s.nac==0x2a3);
    e=p25_receive_update(&s,0x2a3,10,&en,false,2160000);
    assert(!e.voice && !s.ess_valid);
    e=p25_receive_update(&s,0x2a3,5,&lc,true,2340000);assert(!e.voice);
    e=p25_receive_update(&s,0x2a3,10,&en,true,2520000);assert(!e.voice && s.state==P25_RX_CLEAR);
    e=p25_receive_update(&s,0x2a3,5,&lc,true,2700000);assert(e.voice);
    // A genuinely different caller/group starts a fresh boundary even without
    // HDU, so an earlier manufacturer's header cannot poison the new call.
    p25_call_metadata h=header(10,0x80);h.mfid=0x90;h.classification=P25_CALL_UNSUPPORTED;
    p25_receive_reset(&s);
    e=p25_receive_update(&s,0x293,0,&h,true,0);assert(s.header_unsupported && !e.voice);
    lc=link(11,3166362);
    e=p25_receive_update(&s,0x293,5,&lc,true,180000);
    assert(e.new_call && !e.voice && !s.header_unsupported && !s.ess_valid);
    e=p25_receive_update(&s,0x293,10,&en,true,360000);
    assert(!e.voice && s.state==P25_RX_CLEAR);
    e=p25_receive_update(&s,0x293,5,&lc,true,540000);assert(e.voice);
}

static void terminators_and_expiry(void) {
    p25_receive_policy s,before;p25_receive_event e;
    p25_call_metadata lc=link(10,1234567),en=ess(0x80);
    qualify(&s,100);
    before=s;
    e=p25_receive_update(&s,0x2a3,3,NULL,false,360100);
    assert(!e.end && !e.voice && !memcmp(&s,&before,sizeof s));
    e=p25_receive_update(&s,0x2a3,15,NULL,false,540100);
    assert(!e.end && !e.voice && !memcmp(&s,&before,sizeof s));
    e=p25_receive_update(&s,0x293,7,NULL,false,720100); // Unknown DUID cannot refresh the call.
    assert(!e.end && !e.voice && !memcmp(&s,&before,sizeof s));
    e=p25_receive_update(&s,0x293,10,&en,true,780101); // Last qualified unit +600001 us.
    assert(e.new_call && e.reset && e.discard && !e.voice && !s.lc_valid);
    e=p25_receive_update(&s,0x293,5,&lc,true,960101);assert(e.voice);
    e=p25_receive_update(&s,0x293,3,NULL,false,1140101);
    assert(e.end && !s.active && !s.ess_valid && !s.lc_valid && !s.source && !s.group);
    e=p25_receive_update(&s,0x293,5,&lc,true,1320101);assert(!e.voice && e.new_call);
    e=p25_receive_update(&s,0x293,10,&en,true,1500101);assert(!e.voice && s.state==P25_RX_CLEAR);
    e=p25_receive_update(&s,0x293,15,NULL,false,1680101);assert(e.end && !s.active);
    // Timestamp wrap is normal operation, not automatically a stale call.
    qualify(&s,UINT32_MAX-200000u);
    e=p25_receive_update(&s,0x293,10,&en,true,159999u);
    assert(e.voice && !e.new_call);
    e=p25_receive_update(&s,0x293,5,&lc,true,760000u);
    assert(e.new_call && !e.voice && !s.ess_valid);
}

static void unknown_is_not_clear(void) {
    p25_receive_policy s;qualify(&s,0);
    p25_call_metadata en=ess(0x80),lc=link(10,1234567);
    assert(p25_receive_update(&s,0x293,10,&en,true,360000).voice);
    lc.classification=P25_CALL_UNKNOWN;
    p25_receive_event e=p25_receive_update(&s,0x293,5,&lc,true,540000);
    assert(!e.voice && e.discard && s.state!=P25_RX_CLEAR);
    lc=link(10,1234567);
    e=p25_receive_update(&s,0x293,10,&en,true,720000);assert(!e.voice);
    e=p25_receive_update(&s,0x293,5,&lc,true,900000);
    assert(e.voice && e.reset);
    en.classification=P25_CALL_UNKNOWN;
    e=p25_receive_update(&s,0x293,10,&en,true,1080000);
    assert(!e.voice && e.discard && !s.ess_valid && s.state!=P25_RX_CLEAR);
    p25_call_metadata h=header(10,0x80);h.classification=P25_CALL_UNKNOWN;
    e=p25_receive_update(&s,0x293,0,&h,true,1260000);assert(!e.voice);
    e=p25_receive_update(&s,0x293,5,&lc,true,1440000);assert(!e.voice);
    en=ess(0x80);
    e=p25_receive_update(&s,0x293,10,&en,true,1620000);assert(!e.voice);
    for(unsigned field=0;field<8;++field) {
        qualify(&s,0);lc=link(10,1234567);
        assert(p25_receive_update(&s,0x293,10,&en,true,360000).voice);
        switch(field) {
            case 0:lc.mfid_valid=0;break;
            case 1:lc.mfid=0x90;break;
            case 2:lc.lco=3;break;
            case 3:lc.protected_flag=1;break;
            case 4:lc.standard_format=1;break;
            case 5:lc.group_valid=0;break;
            case 6:lc.source_valid=0;break;
            default:lc.lc_options=1;break;
        }
        // A trusted label alone cannot override missing/contradictory fields.
        e=p25_receive_update(&s,0x293,5,&lc,true,540000);
        assert(!e.voice && e.discard && s.state!=P25_RX_CLEAR);
    }
}

static p25_receive_event actual_unit(p25_receive_policy *s,const uint8_t *unit,
        uint8_t duid,uint32_t at) {
    p25_call_metadata m;assert(p25_call_decode(unit,duid,&m));
    return p25_receive_update(s,0x293,duid,&m,true,at);
}

static void actual_wire_metadata(void) {
    // Complete independently generated wire units traverse the real metadata
    // decoder before policy. Their voice payload is not needed to authorize it.
    p25_receive_policy s;p25_receive_reset(&s);
    assert(!actual_unit(&s,call_vector_hdu_clear,0,0).voice);
    assert(actual_unit(&s,call_vector_ldu1_group,5,180000).voice);
    assert(actual_unit(&s,call_vector_ldu2_clear,10,360000).voice);
    assert(s.source==1234567 && s.group==10);
    const uint8_t *blocked[]={call_vector_ldu1_encrypted_service,call_vector_ldu1_protected,
        call_vector_ldu1_individual,call_vector_ldu1_vendor,call_vector_ldu1_unsupported};
    for(unsigned i=0;i<sizeof blocked/sizeof blocked[0];++i) {
        p25_receive_reset(&s);
        assert(!actual_unit(&s,call_vector_hdu_clear,0,0).voice);
        p25_receive_event e=actual_unit(&s,blocked[i],5,180000);
        assert(!e.voice && s.state!=P25_RX_CLEAR);
        e=actual_unit(&s,call_vector_ldu2_clear,10,360000);
        assert(!e.voice && s.state!=P25_RX_CLEAR);
    }
    p25_receive_reset(&s);
    assert(!actual_unit(&s,call_vector_hdu_encrypted,0,0).voice);
    assert(!actual_unit(&s,call_vector_ldu1_group,5,180000).voice);
    assert(!actual_unit(&s,call_vector_ldu2_encrypted,10,360000).voice);
    assert(s.state==P25_RX_ENCRYPTED);
    p25_receive_reset(&s);
    assert(!actual_unit(&s,call_vector_hdu_clear,0,0).voice);
    assert(actual_unit(&s,call_vector_ldu1_group,5,180000).voice);
    assert(!actual_unit(&s,call_vector_ldu2_encrypted,10,360000).voice);
    assert(s.state==P25_RX_ENCRYPTED);
}

int main(void) {
    late_entry();damaged_control();encrypted_and_unsupported();
    boundaries_and_missing_control();terminators_and_expiry();unknown_is_not_clear();actual_wire_metadata();
    puts("P25 receive policy: qualification, damaged control, encrypted transitions, boundaries and wrap passed");
    return 0;
}
