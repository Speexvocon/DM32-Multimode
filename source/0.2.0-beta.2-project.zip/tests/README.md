# TX diagnostic checks

`test_p25_tx.c` executes the portable finite-stream state machine against the
tracked binary fixture. It verifies buffer crossings, final tail/drain, failures
and timer wrap without any board implementation.

`test_diag_adapter.c` includes the actual firmware adapter and replaces only its
hardware/RTOS/time dependencies. It uses unchanged pinned RadioFoundry HAL and
FreeRTOS declarations, plus the narrow platform stub in `diag-stubs/`. Tests
execute MMIO writes and RF callbacks, including a full application loop with
slow RF tuning and repeated IRQs. No host test opens a serial port or accesses RF.

Run `scripts/test-transport.ps1` after cloning upstreams and initializing the
FreeRTOS submodule. These models validate software decisions and byte preservation;
they do not validate the real peripheral clock, analog waveform or radio revision.
