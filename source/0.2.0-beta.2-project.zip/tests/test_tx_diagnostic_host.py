"""Diagnostic setup must not authorize RF implicitly or keep a failed session."""
import contextlib
import importlib.util
import io
import itertools
import json
from pathlib import Path
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('txdiag', ROOT/'scripts/p25-tx-diagnostic.py')
diag = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(diag)


class Radio:
    def __init__(self, mismatch=False, reject_session=False, path=False,
                 path_mismatch=False, reject_command=None):
        self.source, self.pairs, self.extra = 'MIC', '14', '0'
        self.commands, self.lines = [], []
        self.mismatch, self.reject_session = mismatch, reject_session
        self.status_count = 0
        self.path = path
        self.writer, self.dac = 'DUP', 'KEEP'
        self.path_mismatch, self.reject_command = path_mismatch, reject_command

    def write(self, raw):
        command = raw.decode().strip()
        self.commands.append(command)
        if self.reject_command and command.startswith(self.reject_command+' '):
            self.lines.append('ERR control requires idle')
            return len(raw)
        if command == 'STATUS':
            self.status_count += 1
            source = 'MIC' if self.mismatch and self.status_count > 1 else self.source
            if self.path:
                writer = 'BAD' if self.path_mismatch and self.status_count > 1 else self.writer
                self.lines.append(f'TXPATH writer={writer} dac={self.dac}')
            self.lines += [f'TXDIAG source={source} pairs={self.pairs} startup_extra={self.extra}',
                           'LIVE git=test active=0 rf=0 cal=factory', 'LIVE_AUDIO clipped=0']
        elif command == 'STOP':
            self.lines.append('OK STOP')
        elif command.startswith('TXSOURCE '):
            self.source = command.split()[1]
            self.lines.append('OK TXSOURCE')
        elif command.startswith('TXPAIRS '):
            self.pairs = command.split()[1]
            self.lines.append('OK TXPAIRS')
        elif command.startswith('TXALIGN '):
            self.extra = command.split()[1]
            self.lines.append('OK TXALIGN')
        elif command.startswith('TXWRITER '):
            self.writer = command.split()[1]
            self.lines.append('OK TXWRITER')
        elif command.startswith('TXDAC '):
            self.dac = command.split()[1]
            self.lines.append('OK TXDAC')
        elif command.startswith('SESSION '):
            self.lines.append('ERR release PTT' if self.reject_session else 'OK LIVE SESSION; fresh PTT')
        else:
            raise AssertionError(command)
        return len(raw)

    def readline(self):
        return ((self.lines.pop(0)+'\n') if self.lines else '').encode()


class Tests(unittest.TestCase):
    def args(self, session=False, extras=()):
        values = ['--apply', '--log', 'unused.jsonl', '--startup-extra', '1']
        if session:
            values += ['--session', '--allow-rf', '--frequency', '145700000']
        values += list(extras)
        return diag.options(values)

    def run_radio(self, radio, args):
        with contextlib.redirect_stdout(io.StringIO()):
            diag.configure(radio, io.StringIO(), args)

    def test_default_plan_does_not_apply_or_arm(self):
        args = diag.options([])
        self.assertFalse(args.apply or args.session or args.allow_rf)
        self.assertIsNone(args.writer)
        self.assertIsNone(args.dac)

    def test_rf_flags_require_explicit_application_and_frequency(self):
        bad = [['--session'], ['--allow-rf'], ['--apply'],
               ['--apply', '--log', 'x', '--session', '--frequency', '145700000'],
               ['--apply', '--log', 'x', '--session', '--allow-rf', '--frequency', '100000000']]
        for arguments in bad:
            with self.subTest(arguments=arguments), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    diag.options(arguments)

    def test_configuration_only_never_sends_session(self):
        radio = Radio()
        self.run_radio(radio, self.args())
        self.assertFalse(any(c.startswith('SESSION') for c in radio.commands))
        self.assertEqual(radio.commands, ['STATUS', 'STOP', 'TXSOURCE FIXED1011',
                                         'TXPAIRS 14', 'TXALIGN 1', 'STATUS'])

    def test_session_follows_successful_readback_only(self):
        radio = Radio()
        self.run_radio(radio, self.args(session=True))
        self.assertEqual(radio.commands[-1], 'SESSION 145700000 ALLOW_RF')

    def test_readback_mismatch_stops_and_never_arms(self):
        radio = Radio(mismatch=True)
        with self.assertRaisesRegex(RuntimeError, 'readback mismatch'):
            self.run_radio(radio, self.args(session=True))
        self.assertEqual(radio.commands[-1], 'STOP')
        self.assertFalse(any(c.startswith('SESSION') for c in radio.commands))

    def test_rejected_session_stops(self):
        radio = Radio(reject_session=True)
        with self.assertRaisesRegex(RuntimeError, 'release PTT'):
            self.run_radio(radio, self.args(session=True))
        self.assertEqual(radio.commands[-1], 'STOP')

    def test_optional_path_controls_readback_before_explicit_session(self):
        radio = Radio(path=True)
        self.run_radio(radio, self.args(session=True, extras=('--writer', 'ALT1', '--dac', 'RESTORE')))
        self.assertEqual(radio.commands, ['STATUS', 'STOP', 'TXWRITER ALT1', 'TXDAC RESTORE',
                         'TXSOURCE FIXED1011', 'TXPAIRS 14', 'TXALIGN 1', 'STATUS',
                         'SESSION 145700000 ALLOW_RF'])
        self.assertEqual((radio.writer, radio.dac), ('ALT1', 'RESTORE'))

    def test_unrequested_controls_are_preserved_and_never_authorize_rf(self):
        for extras in ((), ('--writer', 'ALT0'), ('--dac', 'KEEP')):
            with self.subTest(extras=extras):
                radio = Radio(path=True)
                radio.writer, radio.dac = 'ALT1', 'RESTORE'
                self.run_radio(radio, self.args(extras=extras))
                if '--writer' not in extras:
                    self.assertEqual(radio.writer, 'ALT1')
                    self.assertFalse(any(c.startswith('TXWRITER') for c in radio.commands))
                if '--dac' not in extras:
                    self.assertEqual(radio.dac, 'RESTORE')
                    self.assertFalse(any(c.startswith('TXDAC') for c in radio.commands))
                self.assertFalse(any(c.startswith('SESSION') for c in radio.commands))

    def test_old_firmware_path_probe_fails_without_stop_or_mutation(self):
        for extras in (('--writer', 'DUP'), ('--dac', 'RESTORE')):
            radio = Radio()
            with mock.patch.object(diag.time, 'monotonic', side_effect=itertools.count()):
                with self.assertRaisesRegex(TimeoutError, 'TXPATH'):
                    self.run_radio(radio, self.args(session=True, extras=extras))
            self.assertEqual(radio.commands, ['STATUS'])

    def test_malformed_path_probe_fails_read_only(self):
        radio = Radio(path=True)
        radio.dac = 'UNSUPPORTED'
        with self.assertRaisesRegex(RuntimeError, 'Unsupported TXPATH'):
            self.run_radio(radio, self.args(extras=('--writer', 'ALT0')))
        self.assertEqual(radio.commands, ['STATUS'])

    def test_path_readback_mismatch_stops_and_never_arms(self):
        radio = Radio(path=True, path_mismatch=True)
        with self.assertRaisesRegex(RuntimeError, 'TXPATH settings readback mismatch'):
            self.run_radio(radio, self.args(session=True, extras=('--writer', 'ALT0')))
        self.assertEqual(radio.commands[-1], 'STOP')
        self.assertFalse(any(c.startswith('SESSION') for c in radio.commands))

    def test_rejected_path_controls_stop_and_never_arm(self):
        for rejected in ('TXWRITER', 'TXDAC'):
            radio = Radio(path=True, reject_command=rejected)
            with self.assertRaisesRegex(RuntimeError, 'requires idle'):
                self.run_radio(radio, self.args(session=True, extras=('--writer', 'ALT0', '--dac', 'RESTORE')))
            self.assertEqual(radio.commands[-1], 'STOP')
            self.assertFalse(any(c.startswith('SESSION') for c in radio.commands))

    def test_path_choices_are_strict_and_visible_in_read_only_plan(self):
        for args in (['--writer', 'BAD'], ['--dac', 'BAD']):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                diag.options(args)
        with contextlib.redirect_stdout(io.StringIO()) as output:
            diag.main(['--writer', 'ALT0', '--dac', 'RESTORE'])
        plan = json.loads(output.getvalue())
        self.assertEqual((plan['writer'], plan['dac']), ('ALT0', 'RESTORE'))
        self.assertFalse(plan['apply'] or plan['session'])


if __name__ == '__main__':
    unittest.main()
