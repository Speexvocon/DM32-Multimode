"""Streaming demodulator controls and optional captured-radio regressions. No RF."""
import ast
import hashlib
import json
import math
from pathlib import Path
import subprocess
import numpy as np
from scipy import signal

root=Path(__file__).resolve().parents[1]
out=root/'build/stream-demod-validation';out.mkdir(parents=True,exist_ok=True)
source=root/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/op25_c4fm_mod.py'
tree=ast.parse(source.read_text())
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'transfer_function_tx','c4fm_taps'}]
assert len(nodes)==2
scope=dict(np=np,pi=math.pi,sin=math.sin,cos=math.cos,_def_symbol_rate=4800,_def_output_sample_rate=48000,_def_span=13)
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),scope)
raw=(root/'fixtures/p25-1011/call.bin').read_bytes()
dibits=np.array([(v>>s)&3 for v in raw for s in (6,4,2,0)])
impulses=np.zeros(len(dibits)*10);impulses[::10]=np.array([1,3,-1,-3])[dibits]
wave=signal.resample_poly(signal.fftconvolve(impulses,scope['c4fm_taps']().generate())*60000,1,6)
reference=(root/'build/p25-rx/reference.imbe').read_bytes()
results=[]
manifest=json.loads((root/'fixtures/p25-1011/manifest.json').read_text())
assert hashlib.sha256(raw).hexdigest()==manifest['files']['call.bin']['sha256']
source_units=[dict(duid=0,frame=raw[:99])]
for i in range(2*manifest['ldu_pairs']):
    source_units.append(dict(duid=5 if i%2==0 else 10,frame=raw[99+i*216:99+(i+1)*216]))
source_units.append(dict(duid=3,frame=raw[-18:]))
assert sum(len(u['frame']) for u in source_units)==len(raw)
source_ends=np.cumsum([len(u['frame'])*40 for u in source_units]) # 48kHz, 4dibits/byte, 10samples/dibit
source_tick_offset=None
# This single severe-clipping control has no qualified voice in either build.
# Idle hunting changes which damaged units are found; it is not a monotonic
# recovery claim. Pin its exact input/output and both source-index sets so this
# exception cannot excuse unrelated weak-input or healthy-output regressions.
CLIPPED_INPUT_SHA256='6a6cee9cbd8aed6fa020c4d50c19b79660bfa35e464d0e1f0168abae005fdcea'
CLIPPED_FRAMES_SHA256='3755e8ce6361765f99c0983ce8b6a64a70f35b3b41691905e88421e65d083d87'
CLIPPED_PRIOR_BCH_SOURCE_UNITS=(1,5,11,15,19,21,27,45,47)
CLIPPED_IDLE_HUNT_SOURCE_UNITS=(1,5,13,15,23,25,33,35,43,45,53,55,57)

def demod(executable,path,dest):
    process=subprocess.run([str(root/'build/p25-rx'/executable),str(path),str(dest)],capture_output=True,text=True)
    assert process.returncode in (0,6),(executable,process.stderr)
    return process,{k:int(v) for k,v in (item.split('=') for item in process.stdout.split())}

def frame_probe(executable,path,dest):
    subprocess.run([str(root/'build/p25-rx'/executable),str(path),str(dest)],check=True,capture_output=True)
    data=dest.read_bytes();assert len(data)%219==0
    return data

def nid_probe(executable,path,dest,frames):
    subprocess.run([str(root/'build/p25-rx'/executable),str(path),str(dest)],check=True,capture_output=True)
    data=dest.read_bytes();assert len(data)%228==0
    records=[dict(nac=int.from_bytes(data[i:i+2],'big'),duid=data[i+2],corrected=data[i+3],
                  tick=int.from_bytes(data[i+4:i+8],'little'),metadata_valid=data[i+8],
                  metadata_class=data[i+9],voice_qualified=data[i+10],call_state=data[i+11],frame=data[i+12:i+228])
             for i in range(0,len(data),228)]
    # Instrumenting the callback must not change the normal emitted bytes.
    assert b''.join(r['nac'].to_bytes(2,'big')+bytes([r['duid']])+r['frame'] for r in records)==frames
    return records

def nid_word(frame):
    value=0
    for i in range(24,57):
        if i!=35:value=(value<<2)|((frame[i//4]>>(6-2*(i%4)))&3)
    return value

def align_source(records,payload):
    """Time-align emitted units to the independent transmitted fixture, no FEC oracle reuse."""
    assert source_tick_offset is not None
    aligned={};cursor=0;previous=-1;maximum_timing_error=0
    for record in records:
        index=int(np.argmin(np.abs(source_ends+source_tick_offset-record['tick'])))
        error=abs(int(source_ends[index])+source_tick_offset-record['tick'])
        # One 4800-symbol/s symbol is ten ticks. Adjacent source LDUs are8640
        # ticks apart, so this cannot silently align a missing/duplicate unit.
        assert error<=10,('unit outside one-symbol timing bound',index,record,error)
        assert index>previous,('duplicate/out-of-order source unit',index,previous)
        previous=index;maximum_timing_error=max(maximum_timing_error,error)
        expected=source_units[index]
        assert record['nac']==int(manifest['nac_hex'],16) and record['duid']==expected['duid']
        assert nid_word(record['frame'])==nid_word(expected['frame']),('wrong/corrupt accepted NID',index)
        assert 0<=record['corrected']<=4
        bits=sum((a^b).bit_count() for a,b in zip(record['frame'],expected['frame']))
        unit=dict(nid_corrected=record['corrected'],wire_bit_differences=bits,voice_bit_errors=0,exact_voices=0,
                  metadata_valid=record['metadata_valid'],voice_qualified=record['voice_qualified'])
        if record['duid'] in (5,10):
            got=payload[cursor:cursor+99];cursor+=99
            expected_payload=reference[(index-1)*99:index*99]
            assert len(got)==len(expected_payload)==99
            unit['voice_bit_errors']=sum((a^b).bit_count() for a,b in zip(got,expected_payload))
            unit['exact_voices']=sum(got[i:i+11]==expected_payload[i:i+11] for i in range(0,99,11))
        aligned[index]=unit
    assert cursor==len(payload)
    return aligned,maximum_timing_error

def compare_recovery(name,path,frames,exact_frames,payload,exact_payload,mode):
    current=nid_probe('demod-nid-probe.exe',path,out/(name+'.nid-probe'),frames)
    exact=nid_probe('demod-nid-probe-exact.exe',path,out/(name+'.exact-nid-probe'),exact_frames)
    recovered,new_error=align_source(current,payload);baseline,old_error=align_source(exact,exact_payload)
    assert set(baseline)<=set(recovered),('BCH recovery lost an existing source unit',name)
    added=sorted(set(recovered)-set(baseline));assert added,('expected exercised NID improvement',name)
    # Each added unit requires actual BCH correction, has the correct source
    # NAC/DUID at the correct time. Moderately noisy input also recovers all
    # nine payloads; severe clipping restores framing only and must stay muted.
    for i in added:
        assert recovered[i]['nid_corrected']>0,(name,i,recovered[i])
        if mode=='voice':assert recovered[i]['voice_bit_errors']==0 and recovered[i]['voice_qualified'],(name,i,recovered[i])
    if mode=='framing':
        assert all(not r['voice_qualified'] for r in current),(name,'unqualified clipped input became audible')
    # Recovery may change subsequent timing-lane arbitration. Compare every
    # common unit against the independent source, rather than excusing arbitrary
    # changed payloads or looking only at an aggregate decoder count.
    for i in baseline:
        assert recovered[i]['voice_bit_errors']<=baseline[i]['voice_bit_errors'],(name,i,'voice regression')
        assert recovered[i]['wire_bit_differences']<=baseline[i]['wire_bit_differences'],(name,i,'wire regression')
        assert recovered[i]['voice_qualified']>=baseline[i]['voice_qualified'],(name,i,'call qualification regression')
    def summary(units):
        missing_voices=9*sum(i not in units and u['duid'] in (5,10) for i,u in enumerate(source_units))
        voice_errors=sum(u['voice_bit_errors'] for u in units.values())
        return dict(units=len(units),exact_voice_frames=sum(u['exact_voices'] for u in units.values()),
                    qualified_voice_units=sum(u['voice_qualified'] for u in units.values()),
                    missing_voice_frames=missing_voices,received_voice_bit_errors=voice_errors,
                    voice_bit_errors_including_erasures=voice_errors+88*missing_voices)
    improved,prior=summary(recovered),summary(baseline)
    if mode=='voice':assert improved['voice_bit_errors_including_erasures']<prior['voice_bit_errors_including_erasures']
    return dict(contract=mode,added_source_unit_indices=added,production=improved,exact_nid=prior,
                maximum_source_timing_error_ticks=max(new_error,old_error),source_timing_bound_ticks=10)

def check_clipped_idle_hunt(path,frames,payload):
    assert hashlib.sha256(path.read_bytes()).hexdigest()==CLIPPED_INPUT_SHA256,'Clipped-control input changed'
    assert hashlib.sha256(frames).hexdigest()==CLIPPED_FRAMES_SHA256,'Clipped-control candidate bytes changed'
    records=nid_probe('demod-nid-probe.exe',path,out/'clipped_voice.idle-hunt-probe',frames)
    aligned,maximum_error=align_source(records,payload)
    assert tuple(aligned)==CLIPPED_IDLE_HUNT_SOURCE_UNITS,('Clipped-control source set changed',sorted(aligned))
    assert len(records)==13 and len(payload)==108*11
    assert all(not r['metadata_valid'] and not r['voice_qualified'] for r in records), \
        'Clipped-control damaged metadata became qualified'
    previous=set(CLIPPED_PRIOR_BCH_SOURCE_UNITS);current=set(aligned)
    lost=sorted(previous-current);added=sorted(current-previous)
    added_blocked=[i for i in added if source_units[i]['duid'] in (5,10)]
    added_terminators=[i for i in added if source_units[i]['duid'] in (3,15)]
    assert len(lost)==5 and len(added_blocked)==8 and added_terminators==[57]
    return dict(contract='source-aligned metadata-blocked candidates; not monotonic framing recovery',
                input_sha256=CLIPPED_INPUT_SHA256,frames_sha256=CLIPPED_FRAMES_SHA256,
                prior_bch_source_unit_indices=list(CLIPPED_PRIOR_BCH_SOURCE_UNITS),
                idle_hunt_source_unit_indices=list(CLIPPED_IDLE_HUNT_SOURCE_UNITS),
                lost_prior_blocked_source_units=lost,added_source_unit_indices=added,
                added_blocked_source_units=added_blocked,added_terminators=added_terminators,
                metadata_rejected_units=12,recovered_terminators=1,qualified_voice_units=0,
                maximum_source_timing_error_ticks=maximum_error,source_timing_bound_ticks=10,
                codec_and_pcm_zero_checked_by='tests/check_qualified_receive.py saved_clipped_voice',
                limitation='Changed candidate selection only; no audible-voice, sensitivity or BER improvement is claimed')

def run(name,samples,expected=None,minimum=0,nid_recovery=False):
    global source_tick_offset
    path=out/(name+'.be16');np.clip(np.rint(samples),-32768,32767).astype('>i2').tofile(path)
    dest=out/(name+'.imbe')
    p,counts=demod('demod.exe',path,dest)
    baseline=out/(name+'.reference.imbe')
    reference_run,reference_counts=demod('demod-reference.exe',path,baseline)
    exact_dest=out/(name+'.exact-nid.imbe')
    exact_run,exact_counts=demod('demod-exact-nid.exe',path,exact_dest)
    whole_frames=out/(name+'.frames');reference_frames=out/(name+'.reference.frames')
    exact_frames=out/(name+'.exact-nid.frames')
    current_bytes=frame_probe('demod-frames.exe',path,whole_frames)
    reference_bytes=frame_probe('demod-frames-reference.exe',path,reference_frames)
    exact_bytes=frame_probe('demod-frames-exact-nid.exe',path,exact_frames)
    assert len(current_bytes)==counts['units']*219,(name,'complete-frame record count mismatch')
    # The exact-NID counterfactual must remain byte-equivalent to the frozen
    # implementation on every saved input, including clipping. Normal firmware
    # retains four-bit NID recovery; its severe-clipping hunt change has the
    # additional narrowly pinned source/classification contract below.
    assert exact_run.returncode==reference_run.returncode,(name,'exact-NID status changed')
    assert exact_dest.read_bytes()==baseline.read_bytes(),(name,'exact-NID frozen payload mismatch')
    assert exact_bytes==reference_bytes,(name,'exact-NID frozen complete-frame mismatch')
    # Acquisition counts describe internal timing hypotheses, not emitted
    # output, and may change when BCH recovery keeps a lane locked longer.
    for key in ('units','voice_frames','corrected_voice_bits'):
        assert exact_counts[key]==reference_counts[key],(name,key,exact_counts,reference_counts)
    recovery=None
    if nid_recovery:
        recovery=compare_recovery(name,path,current_bytes,exact_bytes,dest.read_bytes(),exact_dest.read_bytes(),nid_recovery)
    else:
        assert p.returncode==reference_run.returncode,(name,reference_run.stderr)
        assert dest.read_bytes()==baseline.read_bytes(),(name,'frozen baseline payload mismatch')
        assert current_bytes==reference_bytes,(name,'frozen baseline complete-frame mismatch')
        for key in ('units','voice_frames','corrected_voice_bits'):
            assert counts[key]==reference_counts[key],(name,key,counts,reference_counts)
    idle_hunt=None
    if name=='clipped_voice':
        idle_hunt=check_clipped_idle_hunt(path,current_bytes,dest.read_bytes())
        assert counts['units']==13 and counts['voice_frames']==108
    if name=='clean':
        probe=nid_probe('demod-nid-probe.exe',path,out/(name+'.nid-probe'),current_bytes)
        assert len(probe)==len(source_units)
        offsets=[r['tick']-int(end) for r,end in zip(probe,source_ends)]
        source_tick_offset=int(np.median(offsets))
        assert max(abs(offset-source_tick_offset) for offset in offsets)<=2
        aligned,_=align_source(probe,dest.read_bytes())
        assert len(aligned)==len(source_units) and all(u['voice_bit_errors']==0 for u in aligned.values())
    same=None if expected is None else dest.read_bytes()==expected
    assert same is not False,(name,counts,'payload mismatch')
    assert counts['voice_frames']>=minimum,(name,counts)
    pcm=out/(name+'.s16le')
    if dest.stat().st_size:
        subprocess.run([str(root/'build/host-voice/p25_voice.exe'),'decode',str(dest),str(pcm)],check=True,capture_output=True)
    else:pcm.write_bytes(b'')
    hash_value=2166136261
    for byte in pcm.read_bytes():hash_value=((hash_value^byte)*16777619)&0xffffffff
    bench=subprocess.run([str(root/'build/p25-rx/receive.exe'),str(path)],check=True,capture_output=True,text=True)
    if name=='clean' or name.startswith('hardware_'):
        profiled=subprocess.run([str(root/'build/p25-rx/receive.exe'),str(path),'profile'],check=True,capture_output=True,text=True)
        assert profiled.stdout==bench.stdout,(name,'profile changed decode')
    bcounts=dict(item.split('=') for item in bench.stdout.split())
    assert int(bcounts['hash'],16)==hash_value,(name,bcounts,'PCM hash mismatch')
    assert int(bcounts['voices'])==counts['voice_frames']
    result=dict(case=name,counts=counts,reference_counts=reference_counts,
                exact_nid_counterfactual_frozen_exact=True,
                frozen_reference_exact=dest.read_bytes()==baseline.read_bytes(),complete_frames_exact=current_bytes==reference_bytes,
                nid_recovery_source_validation=recovery,idle_hunt_blocked_control=idle_hunt,
                payload_exact=same,pcm_hash=f'{hash_value:08x}',sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    results.append(result);print(name,counts,'exact',same,'source_recovery',recovery,flush=True)
for name,samples in [('clean',wave),('inverted_dc',-0.7*wave+350),('low_gain',wave*.15+1200)]:
    run(name,samples,reference)
for ppm in (-50,50,-500,500):
    ratio=round(1000000/abs(ppm))
    changed=signal.resample_poly(wave,ratio,ratio+(1 if ppm>0 else -1))
    run('clock_'+str(ppm),changed,reference)
run('silence',np.zeros(16000),b'')
run('dc',np.ones(16000)*12000,b'')
run('noise',np.random.default_rng(293).normal(0,4000,16000),b'')
rng=np.random.default_rng(256180)
run('noisy_voice',wave+rng.normal(0,1200,len(wave)),nid_recovery='voice')
run('clipped_voice',wave*3,nid_recovery='framing')
fade=wave.copy();fade[len(fade)//3:len(fade)//3+800]=0
run('dropout',fade)
run('full_scale_random',rng.integers(-32768,32768,16000))
for number,minimum in [('01',216),('02',225)]:
    path=root/('captures/rx/hotspot-231209b-dmr-bypass-narrow-'+number+'/rx.be16')
    if path.exists():run('hardware_'+number,np.frombuffer(path.read_bytes(),dtype='>i2'),minimum=minimum)
(out/'report.json').write_text(json.dumps(dict(results=results,limitation='Finite synthetic and saved-capture regressions; no RF sensitivity or conformance claim.'),indent=2)+'\n')
