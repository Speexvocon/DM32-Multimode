"""Real-codec qualified RX replay: exact healthy PCM and bounded failure paths.

The executable consumes already-framed records; this does not measure RF BER,
sampling/clock recovery, realtime scheduling, speaker hardware or queue flushes.
Exact PCM requires identical constructor/decode history: the pinned nostar
synthesis PRNG is file-static and deliberately retains its existing lifetime.
Encrypted vectors carry deliberately labeled clear test bits, not ciphertext.
"""
from pathlib import Path
import argparse
import hashlib
import json
import random
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build/p25-qualified"
SYNC = bytes.fromhex("5575f5ff77ff")


def record(unit, duid=None, nac=0x293):
    if duid is None:
        duid = unit[7] & 15
    assert len(unit) <= 216
    return nac.to_bytes(2, "big") + bytes([duid]) + unit.ljust(216, b"\0")


def fixture_records():
    raw = (ROOT / "fixtures/p25-1011/tx-stream.bin").read_bytes()
    pos = raw.index(SYNC)
    units = []
    while pos < len(raw):
        assert raw[pos:pos + 6] == SYNC
        duid = raw[pos + 7] & 15
        length = {0: 99, 3: 18, 5: 216, 10: 216, 15: 54}[duid]
        unit = raw[pos:pos + length]
        assert len(unit) == length
        units.append(record(unit))
        pos += length
    assert len(units) == 58
    return units


def vectors():
    text = (ROOT / "tests/fixtures/p25_call_vectors.h").read_text()
    return {name: bytes(int(x, 16) for x in re.findall(r"0x([0-9a-fA-F]+)", body))
            for name, body in re.findall(r"static const uint8_t (\w+)\[\d+\] = \{(.*?)\};", text, re.S)}


def voice_positions():
    text = (ROOT / "src/firmware/p25_interleave.h").read_text()
    body = text.split("p25_voice_bits[9][144] = {", 1)[1]
    words = [[int(x) for x in re.findall(r"\d+", word)]
             for word in re.findall(r"\{([^{}]*)\}", body)]
    assert len(words) == 9 and all(len(word) == 144 for word in words)
    return words


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--executable", type=Path, default=ROOT / "build/p25-rx/qualified-replay.exe")
    args = parser.parse_args()
    executable = args.executable.resolve()
    BUILD.mkdir(parents=True, exist_ok=True)
    results = {}
    reference_results = {}

    def run_reference(name, plan):
        path = BUILD / (name + ".plan")
        path.write_bytes(b"".join(bytes([ord(op)]) + payload.ljust(11, b"\0") for op, payload in plan))
        output = BUILD / (name + ".s16le")
        completed = subprocess.run([str(executable), "--reference", str(path), str(output)],
                                   check=True, capture_output=True, text=True)
        reference_results[name] = json.loads(completed.stdout)
        return output.read_bytes()

    def run(name, units=None, selection=None, input_path=None):
        path = input_path or BUILD / (name + ".frames")
        if units is not None:
            path.write_bytes(b"".join(units))
        output = BUILD / (name + ".s16le")
        command = [str(executable), str(path), str(output)]
        if selection is not None:
            command.append(selection)
        completed = subprocess.run(command, check=True, capture_output=True, text=True)
        result = json.loads(completed.stdout)
        pcm = output.read_bytes()
        assert len(pcm) == result["voice_frames"] * 320, (name, result)
        assert result["codec_calls"] + result["repeated"] + result["muted"] == result["voice_frames"]
        result["pcm_sha256"] = hashlib.sha256(pcm).hexdigest()
        results[name] = result
        return result, pcm

    clean = fixture_records()
    stats, qualified_clean = run("clean", clean)
    reference = (ROOT / "build/p25-rx/reference.s16le").read_bytes()
    payloads = (ROOT / "build/p25-rx/reference.imbe").read_bytes()
    assert len(payloads) == 504 * 11
    speech = [("D", payloads[i:i + 11]) for i in range(0, len(payloads), 11)]
    reset = ("R", b"")
    single_init = run_reference("reference_single_init", [reset] + speech)
    assert single_init == reference, "Direct nostar one-constructor reference changed"
    aligned_reference = run_reference("reference_three_inits", [reset] * 3 + speech)
    assert qualified_clean == aligned_reference, "Healthy PCM changed with identical initialization history"
    assert stats["voice_frames"] == stats["codec_calls"] == 504
    assert stats["codec_resets"] == 3
    assert not stats["metadata_bad"] and not stats["corrected"] and not stats["muted"] and not stats["repeated"]

    v = vectors()
    hdu = record(v["call_vector_hdu_clear"])
    lc = record(v["call_vector_ldu1_group"])
    ess = record(v["call_vector_ldu2_clear"])
    encrypted_ess = record(v["call_vector_ldu2_encrypted"])
    baseline, baseline_pcm = run("two_ldus", [hdu, lc, ess])
    assert baseline["voice_frames"] == baseline["codec_calls"] == 18
    for label in ("encrypted_service", "protected", "individual", "vendor", "unsupported"):
        blocked = record(v["call_vector_ldu1_" + label])
        stats, pcm = run("blocked_" + label, [hdu, blocked, ess, blocked], "PROM")
        assert not pcm and stats["codec_calls"] == stats["voice_frames"] == 0
    stats, pcm = run("encrypted_header", [record(v["call_vector_hdu_encrypted"]), lc, encrypted_ess], "PROM")
    assert not pcm and not stats["codec_calls"]

    # LDU2 ESS describes the next pair. A receiver joining at LDU1 cannot
    # authorize the preceding LDU2 speech retrospectively from its new ESS.
    stats, pcm = run("late_lc_then_ess", [lc, ess, lc])
    assert stats["unqualified_units"] == 2 and stats["voice_frames"] == stats["codec_calls"] == 9
    assert pcm == baseline_pcm[:9 * 320]
    stats, pcm = run("late_ess_then_lc", [ess, lc])
    assert stats["unqualified_units"] == 1 and stats["voice_frames"] == stats["codec_calls"] == 9
    assert pcm == baseline_pcm[:9 * 320]
    # A clear ESS after an encrypted pair can authorize only the next LDU1.
    stats, pcm = run("encrypted_to_clear", [record(v["call_vector_hdu_encrypted"]), lc, ess, lc])
    assert stats["voice_frames"] == stats["codec_calls"] == 9
    assert pcm == baseline_pcm[:9 * 320]
    stats, pcm = run("clear_to_encrypted", [hdu, lc, encrypted_ess, lc])
    assert stats["voice_frames"] == stats["codec_calls"] == 9
    assert pcm == baseline_pcm[:9 * 320]

    # Deliberately damage a complete control unit beyond useful correction.
    rng = random.Random(0x293)
    damaged_hdu = bytes(rng.randrange(256) for _ in range(99))
    stats, pcm = run("bad_header_boundary", [hdu, lc, record(damaged_hdu, 0), lc, ess, lc])
    assert stats["metadata_bad"] == 1 and stats["voice_frames"] == stats["codec_calls"] == 18
    stats, pcm = run("missing_ess", [hdu, lc, lc, ess, lc])
    assert stats["unqualified_units"] == 2 and stats["voice_frames"] == 18
    stats, pcm = run("missing_lc", [hdu, lc, ess, ess, lc])
    assert stats["unqualified_units"] == 1 and stats["voice_frames"] == 27

    # All seven protected codeword positions support single-bit correction.
    # Exercise a single first-Golay bit in every voice frame, preserving exact
    # payload and therefore the entire PCM stream, with real quality counters.
    positions = voice_positions()
    single_units = []
    for unit in clean:
        if unit[2] in (5, 10):
            unit = bytearray(unit)
            for voice in positions:
                pos = voice[0]
                unit[3 + pos // 8] ^= 0x80 >> (pos % 8)
            unit = bytes(unit)
        single_units.append(unit)
    stats, pcm = run("single_bit_per_voice", single_units)
    assert pcm == qualified_clean and stats["corrected"] == 504
    assert stats["codec_calls"] == 504 and not stats["repeated"] and not stats["muted"]

    # A two-bit first-Golay correction is intentionally treated as unreliable.
    # A good LDU primes PCM, then exactly three repeats precede six muted slots.
    damaged = bytearray(clean[2])
    for voice in positions:
        for pos in voice[:2]:
            damaged[3 + pos // 8] ^= 0x80 >> (pos % 8)
    stats, pcm = run("finite_voice_concealment", [clean[0], clean[1], bytes(damaged), clean[3]])
    assert stats["voice_frames"] == 27 and stats["codec_calls"] == 18
    assert stats["repeated"] == 3 and stats["muted"] == 6
    assert pcm[9 * 320:12 * 320] == pcm[8 * 320:9 * 320] * 3
    assert pcm[12 * 320:18 * 320] == bytes(6 * 320)
    recovery_plan = ([reset] * 3 + speech[:9] + [("P", b"")] * 3 +
                     [reset] + [("M", b"")] * 6 + speech[18:27])
    recovery_reference = run_reference("reference_concealment_history", recovery_plan)
    assert pcm == recovery_reference, "Concealment/recovery differs from independent direct-codec history"
    assert stats["codec_resets"] == 4

    stats, pcm = run("wrong_nac", [hdu, lc, ess], "2A3")
    assert stats["selection_rejected"] == 3 and not pcm and not stats["codec_calls"]
    stats, pcm = run("prom", [hdu, lc, ess], "PROM")
    assert pcm == baseline_pcm and stats["codec_calls"] == 18
    # Truncated record input is rejected rather than interpreted as a unit.
    bad_input = BUILD / "partial.frames";bad_input.write_bytes(hdu[:-1])
    failure = subprocess.run([str(executable), str(bad_input), str(BUILD / "partial.s16le")], capture_output=True)
    assert failure.returncode != 0

    # Characterize saved weak/noisy/dropped and hardware captures. Qualification
    # intentionally changes noisy PCM; do not enforce frozen audio equivalence.
    saved = ROOT / "build/stream-demod-validation"
    for name in ("clean", "noisy_voice", "clipped_voice", "dropout", "hardware_01", "hardware_02"):
        path = saved / (name + ".frames")
        if path.exists():
            stats, pcm = run("saved_" + name, input_path=path)
            if name == "clipped_voice":
                # Idle phase recovery deliberately changes the set of severely
                # clipped candidate units. The stream test independently pins
                # their source alignment; this actual metadata/policy/codec
                # path must withhold every candidate before any decode or PCM.
                assert hashlib.sha256(path.read_bytes()).hexdigest() == \
                    "3755e8ce6361765f99c0983ce8b6a64a70f35b3b41691905e88421e65d083d87"
                assert stats["units"] == 13
                assert stats["ldu"] == stats["metadata_bad"] == stats["unqualified_units"] == 12
                assert stats["terminators"] == stats["ends"] == 1 and stats["final_class"] == 0
                assert stats["voice_frames"] == stats["codec_calls"] == 0 and not pcm
                assert stats["repeated"] == stats["muted"] == 0
                assert stats["encrypted_units"] == stats["unsupported_units"] == 0
    report = {
        "scope": "Already-framed offline units, real metadata/FEC/policy/codec; no realtime or RF claim",
        "healthy_reference": str(ROOT / "build/p25-rx/reference.s16le"),
        "pcm_comparison": "Exact only for identical constructor/decode history; pinned synthesis PRNG lifetime unchanged",
        "direct_nostar_reference_cases": reference_results,
        "cases": results,
    }
    (BUILD / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Qualified real-codec replay passed {len(results)} cases: clean 504-frame PCM is byte-exact "
          "for matched constructor/decode history; "
          "encrypted/unsupported calls omitted before codec; finite concealment and recovery verified")
    for name, result in results.items():
        if name.startswith("saved_"):
            print(f"  {name}: units={result['units']} voice={result['voice_frames']} codec={result['codec_calls']} "
                  f"repeat={result['repeated']} mute={result['muted']} bad_metadata={result['metadata_bad']}")


if __name__ == "__main__":
    main()
