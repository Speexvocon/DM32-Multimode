// SPDX-License-Identifier: GPL-3.0-or-later
#include <assert.h>
#include "../src/firmware/dm32_imbe_mic.c"
static uint32_t now, overruns;
static audio_block_cb_t cb;
static bool fail_start;
static unsigned stopped, inits;
static uint32_t regs[512];
static uint8_t buf[16384];
static hrc7000_t mock_modem={.regs=regs,.buf=buf};
uint32_t hrc_micros(void) { return now; }
uint32_t hrc_irq_save(void) { return 0; }
void hrc_irq_restore(uint32_t s) { (void)s; }
void hrc_irq_enable(uint8_t source,bool enabled) { (void)source; assert(!enabled); }
void hrc_pin_write(uint8_t pin,bool value) { assert(pin==PIN_MIC_PATH && !value); }
void board_rf_safe(void) {}
bool imbe_bench_init(void) {return true;}
void imbe_bench_encode_pcm(int16_t *pcm,uint8_t *out) { memset(out,(uint8_t)pcm[0],11); now+=14000; }
void hrc_audio_pcm_stats(uint32_t *b,uint32_t *o,uint32_t *u) { *b=0; *o=overruns; *u=0; }
void hrc_audio_pcm_reset_stats(void) { overruns=0; }
static bool start(audio_block_cb_t callback,void *ctx) {
    (void)ctx; cb=callback;
    assert(regs[C7_LAYER2_TXRX_CTRL/4]==0 && regs[C7_FM_PTT/4]==0);
    assert(regs[C7_LAYER2_CONTROL/4]==0xc0 && regs[C7_SYS_INTERP_MASK/4]==0);
    regs[C7_AUDIO_CONTROL/4]=C7_AUDIO_PCM_MIC;
    return !fail_start;
}
static void stop(void) { ++stopped; cb=NULL; }
static void init(void) {
    ++inits; __wrap_hrc_dmr_board_init(&mock_modem,NULL);
    buf[C7_CODEC+C7_CODEC_CR_ADC]=0x20;
}
static void mute(bool on) { assert(!on); }
static size_t write_port(const uint8_t *p,size_t n) { (void)p; return n; }
static const hal_stream_t port={.write=write_port};
static const hal_audio_t audio={.start=start,.stop=stop};
// No tune/TX/set_mode/flash callbacks: any accidental use crashes the test.
static const hal_radio_t radio={.init=init,.audio=mute};
const board_t board={.audio=&audio,.radio=&radio,.host_port=&port};
static void block(int16_t value) {
    int16_t pcm[160],spk[160];
    for(unsigned i=0;i<160;++i) pcm[i]=value;
    assert(cb); cb(pcm,spk,NULL);
    for(unsigned i=0;i<160;++i) assert(spk[i]==0);
}
int main(void) {
    now=0xffff0000u; assert(imbe_mic_start()); assert(!imbe_mic_start());
    uint32_t base=now;
    for(unsigned f=0;f<MIC_FRAMES;++f) {
        now=base+(f+1)*20000u; block((int16_t)(f+1));
        assert(imbe_mic_poll());
    }
    while(imbe_mic_poll()) {}
    assert(done && encoded==306 && queue.count==0 && !queue.overflow && !audio_on);
    assert(ldus==34);
    assert(queue.last_us-queue.first_us==5980000 && queue.high==1);
    for(unsigned f=0;f<300;++f) assert(payloads[f][0]==(uint8_t)(f+1));
    for(unsigned f=300;f<306;++f) assert(payloads[f][0]==0);
    imbe_mic_status(); imbe_mic_dump();
    assert(imbe_mic_start());
    for(unsigned f=0;f<9;++f) block(-32768);
    assert(queue.overflow==1 && queue.peak==32768 && queue.clipped==1280);
    assert(!imbe_mic_poll() && !done && !strcmp(reason,"queue_overflow"));
    assert(imbe_mic_start()); overruns=1;
    assert(!imbe_mic_poll() && !done && !strcmp(reason,"driver_overrun"));
    assert(imbe_mic_start()); now+=8000001;
    assert(!imbe_mic_poll() && !strcmp(reason,"timeout"));
    assert(imbe_mic_start()); block(123); imbe_mic_stop();
    assert(!active && !queue.accepting && !strcmp(reason,"cancelled"));
    fail_start=true; assert(!imbe_mic_start() && !active && !done);
    assert(inits==1 && stopped==5);
    fail_start=false;
    assert(imbe_mic_start_digital());
    assert(capture_mode==C7_WORK_MODE_DMR && capture_txrx==0);
    assert(capture_adc==0x20 && capture_audio==C7_AUDIO_PCM_MIC);
    imbe_mic_stop(); assert(regs[C7_WORK_MODE/4]==C7_WORK_MODE_FM);
    assert(imbe_mic_start()); assert(capture_mode==C7_WORK_MODE_FM);
    imbe_mic_stop();
    now=0xffff0000u;
    assert(imbe_mic_start_delayed() && waiting && !audio_on && !queue.accepting);
    assert(imbe_mic_wait_seconds()==20);
    now+=19999999u; assert(imbe_mic_poll() && waiting && !audio_on);
    assert(imbe_mic_wait_seconds()==1 && queue.captured==0);
    now+=1; assert(imbe_mic_poll() && !waiting && audio_on && queue.accepting);
    block(42); assert(imbe_mic_poll());
    imbe_mic_stop();
    assert(imbe_mic_start_delayed()); imbe_mic_stop(); now+=21000000u;
    assert(!imbe_mic_poll() && !audio_on && !strcmp(reason,"cancelled"));
    assert(imbe_mic_start_phy_delayed());
    assert(capture_mode==0x02u && capture_txrx==0 && !audio_on);
    now+=20000000u; assert(imbe_mic_poll() && audio_on);
    assert(capture_mode==0x02u && capture_txrx==0);
    base=now;
    for(unsigned f=0;f<MIC_FRAMES;++f) {
        now=base+(f+1)*20000u; block((int16_t)(f+1));
        assert(imbe_mic_poll());
    }
    while(imbe_mic_poll()) {}
    assert(done && encoded==306 && ldus==34 && !queue.overflow);
    assert(regs[C7_WORK_MODE/4]==C7_WORK_MODE_FM);
    assert(imbe_mic_start_phy_delayed()); imbe_mic_stop(); now+=21000000u;
    assert(!imbe_mic_poll() && !audio_on && !strcmp(reason,"cancelled"));
    puts("Live mic: ordered capture, encoded padding, timer wrap, overload, driver loss, timeout, PHY mode and STOP passed");
}
