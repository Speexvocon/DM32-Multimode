// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_dmr_stub.h"
#include "radio_codec_workspace.h"
#include "dmr_glue.h"
#include "radio_dmr_metrics.h"
#include "app/watchdog.h"
#include "crash/crash.h"
#include "platform.h"
#include "dmr/ambe/ambeVoice.h"
#include <string.h>

void hrc_audio_pcm_diag(radio_dmr_audio_diag_t *out) {memset(out,0,sizeof *out);}
void hrc_vocoder_diag(radio_dmr_vocoder_diag_t *out) {memset(out,0,sizeof *out);}
void hrc_dmr_rx_diag(radio_dmr_rx_diag_t *out) {memset(out,0,sizeof *out);}
void hrc_dmr_tx_diag(radio_dmr_native_tx_diag_t *out) {memset(out,0,sizeof *out);}
void ambeVoiceGetStats(ambe_voice_stats_t *out) {memset(out,0,sizeof *out);}
void dmr_call_get_stats(dmr_call_stats_t *out) {memset(out,0,sizeof *out);}
const watchdog_state_t *watchdog_state(void) {static const watchdog_state_t wd={0};return &wd;}
void crash_init(void) {}
const crash_record_t *crash_last(void) {return NULL;}
const crash_reset_t *crash_reset(void) {static const crash_reset_t boot={0};return &boot;}
const char *crash_reset_name(uint8_t cause) {(void)cause;return "unknown";}

radio_dmr_stub_state radio_dmr_stub={.codec_present=true,.ownership_available=true};
static radio_dmr *active;
static radio_codec_owner_t codec_owner;
static bool codec_busy;
static uint8_t storage[RADIO_CODEC_P25_STORAGE_BYTES];
static uint8_t *borrowed;
static size_t borrowed_capacity;

void radio_dmr_stub_reset(void) {
    memset(&radio_dmr_stub,0,sizeof radio_dmr_stub);
    radio_dmr_stub.codec_present=radio_dmr_stub.ownership_available=true;
    active=NULL;codec_owner=RADIO_CODEC_NONE;codec_busy=false;borrowed=NULL;borrowed_capacity=0;
}
bool radio_codec_bind_dmr(void *memory,size_t bytes) {
    if(codec_owner!=RADIO_CODEC_NONE || codec_busy || !memory || ((uintptr_t)memory&7u) || bytes<RADIO_CODEC_WORKSPACE_BYTES)return false;
    borrowed=memory;borrowed_capacity=bytes;return true;
}
bool radio_codec_unbind_dmr(void) {
    if(codec_owner!=RADIO_CODEC_NONE || codec_busy)return false;
    borrowed=NULL;borrowed_capacity=0;return true;
}
bool radio_codec_acquire(radio_codec_owner_t who) {
    if(!radio_dmr_stub.ownership_available || (who!=RADIO_CODEC_P25 && who!=RADIO_CODEC_DMR)
       || (codec_owner!=RADIO_CODEC_NONE && codec_owner!=who)
       || (who==RADIO_CODEC_DMR && (!borrowed || borrowed_capacity<RADIO_CODEC_WORKSPACE_BYTES)))return false;
    codec_owner=who;return true;
}
bool radio_codec_release(radio_codec_owner_t who) {
    if(codec_owner!=who || codec_busy || who==RADIO_CODEC_NONE)return false;
    codec_owner=RADIO_CODEC_NONE;return true;
}
bool radio_codec_begin(radio_codec_owner_t who) {
    if(codec_owner!=who || codec_busy || who==RADIO_CODEC_NONE)return false;
    codec_busy=true;return true;
}
void radio_codec_end(radio_codec_owner_t who) {if(codec_owner==who)codec_busy=false;}
radio_codec_owner_t radio_codec_owner(void) {return codec_owner;}
bool radio_codec_busy(radio_codec_owner_t who) {return codec_owner==who && codec_busy;}
void *radio_codec_storage(radio_codec_owner_t who,size_t bytes) {
    if(codec_owner!=who)return NULL;
    if(who==RADIO_CODEC_P25 && bytes<=sizeof storage)return storage;
    return who==RADIO_CODEC_DMR && bytes<=RADIO_CODEC_WORKSPACE_BYTES && borrowed_capacity>=RADIO_CODEC_WORKSPACE_BYTES ? borrowed : NULL;
}
void *radio_codec_dmr_storage(radio_codec_dmr_slice_t slice) {
    static const unsigned offsets[]={0,6144,13312,13456};
    return codec_owner==RADIO_CODEC_DMR && (unsigned)slice<4 ? borrowed+offsets[slice] : NULL;
}
bool hrc_vocoder_resume(void) {
    if(!radio_dmr_stub.codec_present || !radio_codec_acquire(RADIO_CODEC_DMR))return false;
    // Native state is deliberately recognizable non-P25 data, so accidental
    // evidence/status/demod use of this shared region is observable.
    memset(borrowed,0xa7,RADIO_CODEC_WORKSPACE_BYTES);return true;
}
bool hrc_vocoder_quiesce(void) {return codec_owner!=RADIO_CODEC_DMR || radio_codec_release(RADIO_CODEC_DMR);}
static void native_pic(bool on) {
    hrc_irq_enable(IRQ_MODEM_SYS,on);hrc_irq_enable(IRQ_MODEM_TS_TX,on);
    hrc_irq_enable(IRQ_MODEM_TS_RX,on);hrc_irq_enable(IRQ_MODEM_RF_TX,on);
}
void __real_hrc_dmr_board_init(hrc7000_t *m,const hrc_dmr_board_t *hooks) {
    (void)m;(void)hooks;++radio_dmr_stub.native_inits;native_pic(false);hrc_irq_enable(IRQ_TIMER3,true);
}
void __real_hrc_dmr_enter(void) {++radio_dmr_stub.native_enters;native_pic(true);}
void __real_hrc_dmr_leave(void) {++radio_dmr_stub.native_leaves;native_pic(false);}
static bool present(void) {return radio_dmr_stub.codec_present;}
static void reset(void) {}
static void encode(const int16_t *pcm,uint8_t *bits) {(void)pcm;memset(bits,0,VOCODER_BITS);}
static void decode(const uint8_t *bits,int16_t *pcm) {(void)bits;memset(pcm,0,VOCODER_FRAME_SAMPLES*sizeof *pcm);}
const hal_vocoder_t radio_dmr_stub_vocoder={.present=present,.reset=reset,.encode=encode,.decode=decode};
const hal_dmr_modem_t radio_dmr_stub_modem={0};

void radio_dmr_init(radio_dmr *d,const radio_dmr_hal *h) {memset(d,0,sizeof *d);if(h)d->hal=*h;d->release_required=true;}
bool radio_dmr_config_valid(const radio_dmr_config *c) {return c && c->source_id && c->source_id<=0xffffffu && c->target_id && c->target_id<=0xffffffu && c->cc<=15 && (c->ts==1 || c->ts==2);}
bool radio_dmr_start(radio_dmr *d,const radio_dmr_config *c) {
    ++radio_dmr_stub.starts;
    if(active) {d->error=RADIO_DMR_BUSY;return false;}
    if(!radio_dmr_config_valid(c)) {d->error=RADIO_DMR_BAD_CONFIG;return false;}
    d->error=RADIO_DMR_OK;
    if(!d->hal.acquire || !d->hal.acquire(d->hal.ctx)) {if(d->error==RADIO_DMR_OK)d->error=RADIO_DMR_NO_OWNERSHIP;return false;}
    if(!radio_dmr_stub.codec_present) {d->hal.release(d->hal.ctx);d->error=RADIO_DMR_NO_CODEC;return false;}
    d->config=*c;d->owned=d->running=true;d->release_required=true;d->error=RADIO_DMR_OK;active=d;
    if(d->hal.radio) {d->hal.radio->audio(false);d->hal.radio->tx_off();d->hal.radio->set_mode(RADIO_MODE_FM);d->hal.radio->set_mode(RADIO_MODE_DMR);
        if(!d->hal.radio->rx(c->rx_hz,RADIO_BW_12K5,NULL)) {radio_dmr_stop(d);d->error=RADIO_DMR_RX_FAILED;return false;}}
    radio_dmr_stub.view.cc=c->cc;radio_dmr_stub.view.ts=c->ts;
    radio_dmr_stub.view.tx_target.id=c->target_id;radio_dmr_stub.view.tx_target.private_call=c->private_call;
    radio_dmr_stub.view.rmo=c->rmo;++radio_dmr_stub.view.serial;return true;
}
void radio_dmr_stop(radio_dmr *d) {
    if(!d || active!=d)return;
    ++radio_dmr_stub.stops;
    if(d->hal.audio)d->hal.audio->stop();
    if(d->hal.radio) {d->hal.radio->tx_off();d->hal.radio->set_mode(RADIO_MODE_FM);}
    d->owned=d->running=d->tx_armed=d->ptt_last=false;d->release_required=true;active=NULL;
    if(d->hal.release)d->hal.release(d->hal.ctx);
    radio_dmr_stub.view.phase=DMR_CALL_PHASE_IDLE;radio_dmr_stub.view.state=DMR_CALL_STATE_IDLE;++radio_dmr_stub.view.serial;
}
void radio_dmr_poll(radio_dmr *d,uint32_t now,bool down,bool allowed) {
    (void)now;if(active!=d || !d->running)return;++radio_dmr_stub.polls;
    bool permit=allowed && d->config.owner_permission && !d->config.rx_only;
    if(!down)d->release_required=false;else if(!permit)d->release_required=true;
    if(down && !d->ptt_last && !d->release_required && permit) {
        ++radio_dmr_stub.ptt_starts;d->tx_armed=true;
        d->error=RADIO_DMR_OK;d->tx_error=DMR_TX_OK;
        memset(&d->diagnostics,0,sizeof d->diagnostics);d->diagnostics.start_ms=now;
        d->diagnostics.result=RADIO_DMR_TX_ACTIVE;
        radio_dmr_stub.view.phase=DMR_CALL_PHASE_TX_VOICE;radio_dmr_stub.view.state=DMR_CALL_STATE_TX;++radio_dmr_stub.view.serial;
    }
    if(d->tx_armed && (!down || !permit)) {
        d->tx_armed=false;radio_dmr_stub.view.phase=DMR_CALL_PHASE_IDLE;radio_dmr_stub.view.state=DMR_CALL_STATE_IDLE;++radio_dmr_stub.view.serial;
        d->tx_error=radio_dmr_stub.view.tx_error;d->diagnostics.tx_error=d->tx_error;
        d->diagnostics.result=d->tx_error ? RADIO_DMR_TX_FAILED : RADIO_DMR_TX_COMPLETE;
        d->diagnostics.end_ms=now;d->diagnostics.metrics_valid=true;
    }
    d->ptt_last=down;
}
const dmr_call_view_t *radio_dmr_view(const radio_dmr *d) {return d && d->running ? &radio_dmr_stub.view : NULL;}
const char *radio_dmr_error_name(radio_dmr_error e) {return e==RADIO_DMR_NO_CODEC ? "no_ambe_codec" : e==RADIO_DMR_OK ? "ok" : "dmr_error";}
bool radio_dmr_get_diagnostics(const radio_dmr *d,radio_dmr_diagnostics *out) {if(!d || !out)return false;*out=d->diagnostics;return true;}
bool radio_dmr_scan_hold(const dmr_call_view_t *v) {return v && v->state==DMR_CALL_STATE_RX && v->phase==DMR_CALL_PHASE_RX_VOICE && !v->caller.encrypted;}
const char *radio_dmr_tx_error_name(uint8_t e) {static const char *const names[]={"ok","no_modem","busy","no_repeater","rejected","timeout","stalled"};return e<sizeof names/sizeof names[0] ? names[e] : "unknown";}
const char *radio_dmr_tx_result_name(radio_dmr_tx_result r) {static const char *const names[]={"none","active","complete","failed","aborted","cancelled"};return (unsigned)r<sizeof names/sizeof names[0] ? names[r] : "unknown";}
