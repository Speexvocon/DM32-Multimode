// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_DMR_STUB_H
#define RADIO_DMR_STUB_H
#include "radio_dmr.h"
// Central-controller/UI test double. Actual adapter/stack tests live separately
// in test_radio_dmr.py; this double makes mode-routing and handoffs observable.
typedef struct {
    unsigned starts, stops, polls, ptt_starts, native_inits, native_enters, native_leaves;
    bool codec_present, ownership_available;
    dmr_call_view_t view;
} radio_dmr_stub_state;
extern radio_dmr_stub_state radio_dmr_stub;
extern const hal_vocoder_t radio_dmr_stub_vocoder;
extern const hal_dmr_modem_t radio_dmr_stub_modem;
void radio_dmr_stub_reset(void);
#endif
