// SPDX-License-Identifier: GPL-3.0-or-later
// Private, fixed passive receiver profile. This is not a codeplug default.
#ifndef DM32_OMAHA_RX_ONLY_H
#define DM32_OMAHA_RX_ONLY_H
#ifndef DM32_OMAHA_RX_ONLY
#define DM32_OMAHA_RX_ONLY 0
#endif
#if DM32_OMAHA_RX_ONLY != 0 && DM32_OMAHA_RX_ONLY != 1
#error DM32_OMAHA_RX_ONLY must be 0 or 1
#endif
#if DM32_OMAHA_RX_ONLY && (!DM32_TRUNK_SUBSCRIBER || DM32_LAB_DIAGNOSTICS || DM32_RF_B_EXPERIMENTAL)
#error The Omaha passive profile requires named-system support and production receive paths
#endif
#define DM32_OMAHA_PROFILE_MARKER "OMAHA_DUALSITE_RX_ONLY_TG3075_V2"
#if DM32_OMAHA_RX_ONLY
enum {DM32_OMAHA_CONTROL_COUNT=7u};
static inline bool dm32_omaha_candidate(unsigned index,uint32_t hz,
    uint16_t *nac,uint8_t *site,const char **name) {
    static const uint32_t controls[DM32_OMAHA_CONTROL_COUNT]={
        172287500u,172600000u,173762500u,
        154680000u,154950000u,155872500u,156142500u};
    if(index>=DM32_OMAHA_CONTROL_COUNT || hz!=controls[index])return false;
    if(nac)*nac=(uint16_t)(index<3u ? 0xb85u:0xb83u);
    if(site)*site=(uint8_t)(index<3u ? 70u:83u);
    if(name)*name=index<3u ? "NDOT Yard":"Hummel Park";
    return true;
}
static inline bool dm32_omaha_system(unsigned selection,p25_cs_trunk_system *out) {
    if(selection!=1u || !out)return false;
    const p25_cs_trunk_system system={
        .control_hz={172287500u,172600000u,173762500u,
            154680000u,154950000u,155872500u,156142500u},
        .wacn=0xbee00u,.source_id=1u,.system_id=0xb8fu,.nac=0xb85u,
        .talkgroup=3075u,.mode=P25_CS_TRUNK_RX_ONLY,.control_count=DM32_OMAHA_CONTROL_COUNT,
        .rfss=1u,.site=70u,.name="NDOT Yard"};
    *out=system;return true;
}
#endif
#endif
