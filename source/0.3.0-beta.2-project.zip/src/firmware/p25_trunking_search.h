// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded receive-only control acquisition. No RF, storage or duplicate map.
#ifndef P25_TRUNKING_SEARCH_H
#define P25_TRUNKING_SEARCH_H
#include "p25_trunking.h"

#define P25_TRUNK_SEARCH_CONTROLS 8u
#define P25_TRUNK_SEARCH_DWELL_MS 3000u
#define P25_TRUNK_SEARCH_ACQUIRE_MS 12000u
#define P25_TRUNK_SEARCH_IDENTITY_MS 30000u
#define P25_TRUNK_SEARCH_PROBE_MS 450u
#define P25_TRUNK_SEARCH_PROBE_SAMPLES 2400u
#define P25_TRUNK_SEARCH_INPUT_FRESH_MS 100u
#define P25_TRUNK_SEARCH_LOSS_MS 3000u
#define P25_TRUNK_SEARCH_TUNE_MS 1000u
typedef enum {P25_TRUNK_SEARCH_OFF,P25_TRUNK_SEARCH_TUNE_READY,
    P25_TRUNK_SEARCH_TUNING,P25_TRUNK_SEARCH_ACQUIRE,
    P25_TRUNK_SEARCH_LOCKED,P25_TRUNK_SEARCH_PAUSED,
    P25_TRUNK_SEARCH_FAILED} p25_trunking_search_phase;
typedef enum {P25_TRUNK_SEARCH_OK,P25_TRUNK_SEARCH_CLOCK,
    P25_TRUNK_SEARCH_TUNE_TIMEOUT,P25_TRUNK_SEARCH_SERIAL} p25_trunking_search_reason;
typedef struct {
    uint32_t control_hz[P25_TRUNK_SEARCH_CONTROLS],min_hz,max_hz,wacn;
    uint16_t system,nac;
    uint8_t rfss,site,count;
} p25_trunking_search_config;
typedef struct {uint32_t id,hz;uint8_t index;} p25_trunking_search_action;
typedef struct {
    p25_trunking_search_config config;
    uint32_t serial,epoch,last_poll_ms,started_ms,last_control_ms,site_ms,network_ms,gate_ms;
    p25_trunking_search_phase phase;
    p25_trunking_search_reason reason;
    uint16_t site_channel,network_channel;
    uint64_t probe_next_tick;
    uint32_t probe_last_ms;
    uint16_t probe_samples;
    uint8_t index,seen,resume_phase;
    bool allow_tune,manual_pause,probe_input,probe_evidence;
} p25_trunking_search;
// Zero-initialize before first start. OFF-only start is non-mutating on error.
// Identity zeroes are literal; this API has no wildcard/roaming interpretation.
bool p25_trunking_search_start(p25_trunking_search *s,
    const p25_trunking_search_config *config,uint32_t now_ms);
// busy covers requests, granted/active voice and other receiver owners. No new
// tuning action is available while held. Returning from an automatic hold
// restarts acquisition on the same candidate, without inventing valid traffic.
void p25_trunking_search_poll(p25_trunking_search *s,uint32_t now_ms,bool busy);
bool p25_trunking_search_take_tune(p25_trunking_search *s,
    p25_trunking_search_action *out,uint32_t now_ms);
// Success requires a fresh nonzero RX epoch. The adapter must stop/reset the
// recorder and maps before tuning. A missing ACK fails closed, never overlaps
// another tune. A reported failure advances to the next candidate once.
bool p25_trunking_search_tune_result(p25_trunking_search *s,uint32_t action_id,
    bool success,uint32_t stream_epoch,uint32_t now_ms);
// Report a just-processed contiguous block from THIS receiver/epoch. first_tick
// is the first input sample's actual origin in nominal 48-kHz ticks, six ticks
// per 8-kHz sample; input_age_ms is measured from its capture IRQ, not delivery.
// Blocks must contain 1..800 samples. Stale/discontinuous input cannot support
// an early skip. p25_evidence means a real sync acquisition in this fresh block;
// it only grants bounded acquisition time, never establishes identity/RF rights.
// With multiple candidates, 300 ms of continuous fresh input and no evidence
// permit moving on after 450 ms. Genuine sync/accepted metadata extends only
// this acquisition to 12 seconds. Otherwise the ordinary dwell is 3 seconds.
bool p25_trunking_search_input(p25_trunking_search *s,uint32_t stream_epoch,
    uint64_t first_tick,unsigned samples,uint32_t input_age_ms,bool p25_evidence,
    uint32_t now_ms);
// Feed only an event/opcode from native CRC-validated control metadata decoded
// by p25_trunking_consume[_control] or a validated AMBT envelope normalized by
// the parser on THIS map/carrier/epoch. A 0x33 BANDPLAN is accepted FDMA type1.
// Fresh matching SITE(3A)+NETWORK(3B) within 12 seconds in this epoch, both
// advertising this mapped candidate, are required to lock. An invalidated
// mapping revokes the lock. Each identity row expires after 30 seconds.
// Unknown, wrong-site and unsupported traffic cannot manufacture/refresh it.
bool p25_trunking_search_observe(p25_trunking_search *s,const p25_trunking *map,
    p25_trunking_event event,uint8_t opcode,uint32_t stream_epoch,uint32_t now_ms);
// A CRC-valid standard/unprotected block may refresh carrier health only
// after exact identity and both mapped advertisements have established LOCK.
// This never creates maps/identity/lock or renews the separate identity lease.
// The caller supplies the actual decoded block on this receiver and epoch.
bool p25_trunking_search_activity(p25_trunking_search *s,const p25_trunking *map,
    uint16_t nac,const uint8_t block[12],uint32_t stream_epoch,uint32_t now_ms);
// Explicit RX-away hold. Resume requires a fresh epoch and real new metadata;
// it stays on the current control candidate. Attachment is NOT owned here:
// switching controls must revoke the subscriber and register again.
bool p25_trunking_search_suspend(p25_trunking_search *s,uint32_t now_ms);
bool p25_trunking_search_resume(p25_trunking_search *s,uint32_t stream_epoch,uint32_t now_ms);
// Operator cancellation revokes pending actions but preserves their generation.
void p25_trunking_search_stop(p25_trunking_search *s);
#endif
