// SPDX-License-Identifier: GPL-3.0-or-later
// Normal subscriber transport. Nominal CC scheduling is explicitly experimental;
// none of these software timestamps qualify sample origin or RF access timing.
#ifndef P25_TRUNKING_SUBSCRIBER_LIVE_H
#define P25_TRUNKING_SUBSCRIBER_LIVE_H
#include "p25_trunking_preload.h"
#include "p25_voice_receipt.h"
static void poll_call(bool down);
static bool trunk_subscriber_menu_paused(void);

enum {SUB_IO_IDLE,SUB_IO_PREPARE,SUB_IO_CLOCK_WAIT,SUB_IO_CLOCK,SUB_IO_REQUEST,
      SUB_IO_REQUEST_RETURN,SUB_IO_VOICE_PREPARE,SUB_IO_VOICE,SUB_IO_VOICE_STOP,
      SUB_IO_VOICE_RETURN,SUB_IO_FAILED};
enum {SUB_LOGOUT_NONE,SUB_LOGOUT_PENDING,SUB_LOGOUT_SENT,SUB_LOGOUT_FAILED};
#define SUB_LOGOUT_LIMIT_US 5000000u
static struct {
    p25_trunking_access_action action;
    uint32_t owner_hash,control_hz,saved_tx_hz,image_hash;
    volatile uint32_t deadline_us,target_us,clock_due_us,start_us,last_phy_us;
    uint32_t return_epoch,voice_start_us,logout_deadline_us;
    uint64_t source_first_tick;
    uint32_t source_irq_us;
    volatile uint8_t phase,native_count,publications;
    volatile bool request_success,voice_started;
    volatile bool selected;
    bool handoff,cleaning,source_valid,voice_acknowledged,receive_follow,receive_returning,saved_split;
    uint8_t logout;
} trunk_subscriber_io;
_Static_assert(sizeof trunk_subscriber_io<=160u,"Subscriber hardware state exceeds its bounded budget");
enum {SUB_FAIL_NONE,SUB_FAIL_CONTEXT,SUB_FAIL_RENDER,SUB_FAIL_SETUP,SUB_FAIL_PREPARE_DEADLINE,
      SUB_FAIL_GUARD,SUB_FAIL_CLOCK_LATE,SUB_FAIL_NATIVE_CADENCE,SUB_FAIL_EDGE,
      SUB_FAIL_PA_LATE,SUB_FAIL_PUBLICATIONS,SUB_FAIL_CUTOFF,SUB_FAIL_RETURN,
      SUB_FAIL_COMPLETION,SUB_FAIL_TASK_DEADLINE,SUB_FAIL_PTT,SUB_FAIL_CLEANUP,SUB_FAIL_VOICE};
// For CONTEXT only, delay_us holds the negative first failed admission guard.
// Keep the original short-circuit order: no new state, later re-evaluation or
// diagnostic bus reads may change the reason observed before RF is killed.
enum {SUB_GUARD_SELECTED=1,SUB_GUARD_TRUNK_ENABLED,SUB_GUARD_SESSION_RUNNING,
      SUB_GUARD_NORMAL_MODE,SUB_GUARD_FEATURES_READY,SUB_GUARD_P25,SUB_GUARD_CANCEL,
      SUB_GUARD_OWNER_INHIBIT,SUB_GUARD_CHANNEL_INHIBIT,SUB_GUARD_RADIO_FAULT,
      SUB_GUARD_CONTROL_HZ,SUB_GUARD_SOURCE_ID,SUB_GUARD_TALKGROUP,SUB_GUARD_NAC,
      SUB_GUARD_OWNER_HASH,SUB_GUARD_PRIVATE,SUB_GUARD_SCAN,SUB_GUARD_APPS,
      SUB_GUARD_PCM_OWNER,SUB_GUARD_APPLET,SUB_GUARD_CPS_ACTIVE,SUB_GUARD_CPS_LINK,
      SUB_GUARD_EDITING,SUB_GUARD_MENU,SUB_GUARD_RX_LAB,SUB_GUARD_RX_JOB,
      SUB_GUARD_BROADCAST,SUB_GUARD_AIRBAND,SUB_GUARD_DMR_OWNER,SUB_GUARD_FM_OWNER,
      SUB_GUARD_PROBE,SUB_GUARD_LAB_RETURN,SUB_GUARD_LAB_ATTACH,SUB_GUARD_LAB_PTT,
      SUB_GUARD_DEV,SUB_GUARD_HOOKS,SUB_GUARD_AUDIO,SUB_GUARD_RADIO,SUB_GUARD_TX_FIXED,
      SUB_GUARD_POWER,SUB_GUARD_TX_SETTINGS,SUB_GUARD_CALIBRATION,SUB_GUARD_RX_BAND,
      SUB_GUARD_BATTERY,SUB_GUARD_ACTION_ID,SUB_GUARD_ACTION_SERIAL,
      SUB_GUARD_ACTION_SOURCE,SUB_GUARD_ACTION_GROUP,SUB_GUARD_ACTION_NAC,
      SUB_GUARD_PREPARED,SUB_GUARD_CALL_ACTIVE,SUB_GUARD_MESSAGE_PACKET,
      SUB_GUARD_MON_RUNNING,SUB_GUARD_IMAGE,SUB_GUARD_PTT,SUB_GUARD_ACTION_PTR,
      SUB_GUARD_PREFIX,SUB_GUARD_TRANSPORT,SUB_GUARD_TX_BAND,SUB_GUARD_WRITER,
      SUB_GUARD_DAC_RESTORE,SUB_GUARD_SUSPEND};
typedef struct {
    int32_t delay_us;
    uint32_t prepare_us,switch_us;
    uint8_t cause,phase,native_count,publications;
} trunk_subscriber_failure_record;
static volatile trunk_subscriber_failure_record trunk_subscriber_failure;
static p25_voice_receipt trunk_subscriber_voice_receipt;
_Static_assert(sizeof trunk_subscriber_failure<=24u,"Subscriber failure record exceeds budget");
// Last admitted transport's software milestones. Zero is a valid clock value;
// flags, rather than timestamps, establish presence. No sample/air-clock claim.
enum {SUB_RETURN_OFF=1u,SUB_RETURN_BEGIN=2u,SUB_RETURN_RX=4u,SUB_RETURN_IRQ=8u,
      SUB_RETURN_CONTROL=16u,SUB_RETURN_READY=32u,SUB_RETURN_FAILED=64u};
enum {SUB_RETURN_REQUEST=1u,SUB_RETURN_VOICE=2u};
typedef struct {
    uint32_t sequence,action,old_epoch,rx_epoch;
    uint32_t off_us,begin_us,rx_us,irq_us,control_us,ready_us;
    uint8_t flags,kind;
} trunk_subscriber_return_record;
static volatile trunk_subscriber_return_record trunk_subscriber_return_trace;
_Static_assert(sizeof trunk_subscriber_return_trace==44u,"Control return trace budget changed");
static void trunk_subscriber_return_fail(void) {
    uint32_t lock=hrc_irq_save();
    unsigned done=SUB_RETURN_READY|SUB_RETURN_CONTROL;
    if(trunk_subscriber_return_trace.sequence
       &&(trunk_subscriber_return_trace.flags&done)!=done)
        trunk_subscriber_return_trace.flags|=SUB_RETURN_FAILED;
    hrc_irq_restore(lock);
}
static void trunk_subscriber_return_arm(uint32_t action,unsigned kind) {
    uint32_t lock=hrc_irq_save();
    uint32_t sequence=trunk_subscriber_return_trace.sequence+1u;if(!sequence)sequence=1u;
    memset((void *)&trunk_subscriber_return_trace,0,sizeof trunk_subscriber_return_trace);
    trunk_subscriber_return_trace.sequence=sequence;trunk_subscriber_return_trace.action=action;
    trunk_subscriber_return_trace.kind=(uint8_t)kind;
    trunk_subscriber_return_trace.old_epoch=trunk_stream_epoch;
    hrc_irq_restore(lock);
}
static void trunk_subscriber_return_off(uint32_t now) {
    uint32_t lock=hrc_irq_save();
    if(trunk_subscriber_return_trace.sequence && !trunk_subscriber_return_trace.flags) {
        trunk_subscriber_return_trace.off_us=now;
        trunk_subscriber_return_trace.flags=SUB_RETURN_OFF;
    }
    hrc_irq_restore(lock);
}
static void trunk_subscriber_return_stopping(void) {
    // Preparation also calls hardware_stop. Only a running admitted transmitter
    // can establish this software shutdown marker, never a preparation stop.
    if(hardware_running&&trunk_subscriber_transport_owned()
       &&!trunk_subscriber_return_trace.flags)trunk_subscriber_return_off(hrc_micros());
}
static void trunk_subscriber_return_begin(void) {
    uint32_t lock=hrc_irq_save();
    if(trunk_subscriber_return_trace.flags==SUB_RETURN_OFF) {
        trunk_subscriber_return_trace.begin_us=hrc_micros();
        trunk_subscriber_return_trace.flags|=SUB_RETURN_BEGIN;
    }
    hrc_irq_restore(lock);
}
static void trunk_subscriber_return_enable(void) {
    // Called inside recorder admission's IRQ lock, before its mask/enable.
    if(trunk_subscriber_return_trace.flags==(SUB_RETURN_OFF|SUB_RETURN_BEGIN)
       &&trunk_stream_epoch && trunk_stream_epoch!=trunk_subscriber_return_trace.old_epoch) {
        trunk_subscriber_return_trace.rx_epoch=trunk_stream_epoch;
        trunk_subscriber_return_trace.rx_us=hrc_micros();
        trunk_subscriber_return_trace.flags|=SUB_RETURN_RX;
    }
}
static void trunk_subscriber_return_input(uint32_t now) {
    // This hook is after a successful raw push, with the already sampled IRQ
    // time. It adds no clock read or serial formatting to recorder interrupts.
    if(mon_subscriber_control_only&&trunk_subscriber_return_trace.flags
       ==(SUB_RETURN_OFF|SUB_RETURN_BEGIN|SUB_RETURN_RX)
       &&trunk_stream_epoch==trunk_subscriber_return_trace.rx_epoch) {
        trunk_subscriber_return_trace.irq_us=now;
        trunk_subscriber_return_trace.flags|=SUB_RETURN_IRQ;
    }
}
static bool trunk_subscriber_return_receiving(void) {
    unsigned flags=trunk_subscriber_return_trace.flags;
    return (flags&SUB_RETURN_IRQ)&&!(flags&SUB_RETURN_FAILED)
        &&mon_subscriber_control_only&&trunk_stream_epoch==trunk_subscriber_return_trace.rx_epoch;
}
static void trunk_subscriber_return_control(void) {
    if(!trunk_subscriber_return_receiving()||(trunk_subscriber_return_trace.flags&SUB_RETURN_CONTROL))return;
    uint32_t lock=hrc_irq_save();
    if(trunk_subscriber_return_receiving()&&!(trunk_subscriber_return_trace.flags&SUB_RETURN_CONTROL)) {
        trunk_subscriber_return_trace.control_us=hrc_micros();
        trunk_subscriber_return_trace.flags|=SUB_RETURN_CONTROL;
    }
    hrc_irq_restore(lock);
}
static void trunk_subscriber_return_ready(void) {
    if(!trunk_subscriber_return_receiving()||(trunk_subscriber_return_trace.flags&SUB_RETURN_READY))return;
    uint32_t lock=hrc_irq_save();
    if(trunk_subscriber_return_receiving()&&!(trunk_subscriber_return_trace.flags&SUB_RETURN_READY)) {
        trunk_subscriber_return_trace.ready_us=hrc_micros();
        trunk_subscriber_return_trace.flags|=SUB_RETURN_READY;
    }
    hrc_irq_restore(lock);
}
static void trunk_subscriber_return_epoch_end(void) {
    // A later control tune cannot fill this record with unrelated samples.
    if(trunk_subscriber_return_trace.flags&SUB_RETURN_RX)trunk_subscriber_return_fail();
}
static int trunk_subscriber_return_row(unsigned row,char *line,size_t capacity) {
    if(row)return -1;
    uint32_t lock=hrc_irq_save();trunk_subscriber_return_record value=trunk_subscriber_return_trace;
    hrc_irq_restore(lock);
    return snprintf(line,capacity,"TRUNK_RETURN version=1 sequence=%lu action=%lu kind=%s flags=%u off_us=%lu begin_us=%lu rx_us=%lu irq_us=%lu control_us=%lu ready_us=%lu old_epoch=%lu rx_epoch=%lu\r\n",
        (unsigned long)value.sequence,(unsigned long)value.action,
        value.kind==SUB_RETURN_VOICE?"voice":"request",(unsigned)value.flags,
        (unsigned long)value.off_us,(unsigned long)value.begin_us,(unsigned long)value.rx_us,
        (unsigned long)value.irq_us,(unsigned long)value.control_us,(unsigned long)value.ready_us,
        (unsigned long)value.old_epoch,(unsigned long)value.rx_epoch);
}
static void trunk_subscriber_failure_clear(void) {
    uint32_t lock=hrc_irq_save();memset((void *)&trunk_subscriber_failure,0,sizeof trunk_subscriber_failure);
    hrc_irq_restore(lock);
}
static const char *trunk_subscriber_failure_name(unsigned cause) {
    switch(cause) {
    case SUB_FAIL_NONE:return "none";case SUB_FAIL_CONTEXT:return "context";
    case SUB_FAIL_RENDER:return "render";case SUB_FAIL_SETUP:return "setup";
    case SUB_FAIL_PREPARE_DEADLINE:return "prepare_deadline";case SUB_FAIL_GUARD:return "guard";
    case SUB_FAIL_CLOCK_LATE:return "clock_late";case SUB_FAIL_NATIVE_CADENCE:return "native_cadence";
    case SUB_FAIL_EDGE:return "native_edge";case SUB_FAIL_PA_LATE:return "pa_late";
    case SUB_FAIL_PUBLICATIONS:return "publications";case SUB_FAIL_CUTOFF:return "cutoff";
    case SUB_FAIL_RETURN:return "return_rx";case SUB_FAIL_COMPLETION:return "completion";
    case SUB_FAIL_TASK_DEADLINE:return "task_deadline";case SUB_FAIL_PTT:return "ptt_released";
    case SUB_FAIL_CLEANUP:return "cleanup";case SUB_FAIL_VOICE:return "voice";
    default:return "unknown";
    }
}
static void trunk_subscriber_failure_latch(unsigned cause,int32_t delay_us) {
    uint32_t lock=hrc_irq_save();
    if(!trunk_subscriber_failure.cause) {
        trunk_subscriber_failure.delay_us=delay_us;
        trunk_subscriber_failure.phase=trunk_subscriber_io.phase;
        trunk_subscriber_failure.native_count=trunk_subscriber_io.native_count;
        trunk_subscriber_failure.publications=trunk_subscriber_io.publications;
        hrc_barrier();trunk_subscriber_failure.cause=(uint8_t)cause;
    }
    hrc_irq_restore(lock);
}

static bool trunk_subscriber_active(void) {return trunk_subscriber_io.selected;}
static bool trunk_subscriber_logout_pending(void) {return trunk_subscriber_io.logout==SUB_LOGOUT_PENDING;}
static bool trunk_subscriber_logout_finished(void) {
    return trunk_subscriber_io.logout==SUB_LOGOUT_SENT||trunk_subscriber_io.logout==SUB_LOGOUT_FAILED;
}
static bool trunk_subscriber_logout_succeeded(void) {return trunk_subscriber_io.logout==SUB_LOGOUT_SENT;}
static bool trunk_subscriber_request_owned(void) {
    return trunk_subscriber_io.selected&&trunk_subscriber_io.phase>=SUB_IO_PREPARE
        &&trunk_subscriber_io.phase<=SUB_IO_REQUEST_RETURN;
}
static bool trunk_subscriber_voice_owned(void) {
    return trunk_subscriber_io.selected&&trunk_subscriber_io.phase>=SUB_IO_VOICE_PREPARE
        &&trunk_subscriber_io.phase<=SUB_IO_VOICE_RETURN;
}
static bool trunk_subscriber_transport_owned(void) {
    // An already-ended producer can acknowledge STOP immediately. Its task
    // receipt clears IO before RETURN_CONTROL is dispatched on the next pass.
    // Keep that gap owned: ordinary RX must not restart, and a paused saved
    // system must keep polling its subscriber until cleanup has finished.
    bool cleanup=trunk_subscriber_io.selected&&trunk_subscriber_io.phase==SUB_IO_IDLE
        &&(trunk_session.access.phase==P25_TRUNK_ACCESS_DRAIN
            ||trunk_session.access.phase==P25_TRUNK_ACCESS_RETURN);
    return trunk_subscriber_request_owned()||trunk_subscriber_voice_owned()||cleanup;
}
static void trunk_subscriber_voice_snapshot(bool down) {
    if(call_active||hardware_running
       ||(trunk_subscriber_io.action.type!=P25_TRUNK_ACTION_VOICE_START
           &&trunk_subscriber_io.action.type!=P25_TRUNK_ACTION_VOICE_STOP))return;
    uint32_t voice_id=trunk_subscriber_io.action.id;
    if(trunk_subscriber_io.action.type==P25_TRUNK_ACTION_VOICE_STOP) {
        // STOP is the immediately following access action (serial skips zero).
        // A setup failure before voice sources were initialized must not turn
        // an older request's terminal buffers into evidence for a new call.
        uint32_t stop_id=trunk_subscriber_voice_receipt.action_id+1u;
        if(!stop_id)stop_id=1u;
        if(voice_id!=stop_id)return;
        voice_id=trunk_subscriber_voice_receipt.action_id;
    }
    uint32_t lock=hrc_irq_save();
    (void)p25_voice_receipt_latch(&trunk_subscriber_voice_receipt,
        voice_id,&live,&pcmq,encoded,driver_loss,
        max_encode,reason,down,call_tot_expired);
    hrc_irq_restore(lock);
}
static bool trunk_subscriber_handoff(void) {
    return trunk_subscriber_io.selected&&(trunk_subscriber_io.handoff
        ||trunk_subscriber_transport_owned()||trunk_subscriber_io.cleaning
        ||trunk_subscriber_io.receive_follow);
}
static bool trunk_subscriber_control_receive_allowed(void) {
    // Only a stopped subscriber transport may publish a fresh control epoch.
    // No transmit permission is inferred from starting this receive-only path.
    return trunk_subscriber_active() && trunk_subscriber_handoff()
        && (trunk_subscriber_io.phase==SUB_IO_REQUEST_RETURN
            || trunk_subscriber_io.phase==SUB_IO_VOICE_RETURN || trunk_subscriber_io.phase==SUB_IO_FAILED)
        && trunk_enabled && trunk.phase==P25_TRUNKING_CONTROL && trunk_session.running
        && receiver_frequency()==trunk_subscriber_io.control_hz
        && trunk_subscriber_io.control_hz==trunk_session.config.control_rx_hz
        && !mon_running && mon_frontend_exclusive() && !trunk_lab_return_owned();
}
static bool trunk_subscriber_allow_follow(void) {
    return trunk_subscriber_active()&&!trunk_subscriber_transport_owned()
        &&!trunk_subscriber_logout_pending()
        &&!trunk_subscriber_io.receive_follow&&!trunk_subscriber_backend.inflight
        &&!trunk_subscriber_backend.reacquiring&&!trunk_subscriber_backend.receive_suspended&&!menu_open
        &&trunk_session.access.phase==P25_TRUNK_ACCESS_READY
        &&trunk_session.access.registered&&trunk_session.access.affiliated
        &&!trunk_session.access.ptt_down&&!trunk_session.access.outstanding;
}
static bool trunk_subscriber_receive_following(void) {
    return trunk_subscriber_active()&&trunk_subscriber_io.receive_follow;
}
static bool trunk_subscriber_receive_restoring(void) {
    return trunk_subscriber_active()&&(trunk_subscriber_io.receive_returning
        ||trunk_subscriber_backend.reacquiring);
}
static bool trunk_subscriber_receive_begin(void) {
    if(!trunk_subscriber_allow_follow()
       ||!p25_trunking_backend_receive_suspend(&trunk_subscriber_backend,&trunk_session))return false;
    trunk_subscriber_io.receive_follow=true;trunk_subscriber_io.receive_returning=false;
    trunk_subscriber_io.return_epoch=trunk_stream_epoch;return true;
}
static void trunk_subscriber_receive_return(void) {
    if(trunk_subscriber_io.receive_follow) {
        trunk_subscriber_io.receive_returning=true;
        trunk_subscriber_io.deadline_us=hrc_micros()+1000000u;
    }
}
static uint32_t trunk_subscriber_owner_hash(void) {
    uint32_t hash=2166136261u;
    for(unsigned i=0;i<32u;++i)hash=(hash^channel_record[i])*16777619u;
    for(unsigned i=0;i<32u;++i)hash=(hash^global_record[i])*16777619u;
    return hash?hash:1u;
}
static uint32_t trunk_subscriber_image_hash(void) {
    uint32_t hash=2166136261u;
    for(unsigned i=0;i<72u;++i)hash=(hash^dev->buf[i])*16777619u;
    return hash;
}
static unsigned trunk_subscriber_context_guard(void) {
    if(!trunk_subscriber_active())return SUB_GUARD_SELECTED;
    if(!trunk_enabled)return SUB_GUARD_TRUNK_ENABLED;
    if(!trunk_session.running)return SUB_GUARD_SESSION_RUNNING;
    if(!normal_mode)return SUB_GUARD_NORMAL_MODE;
    if(!features_ready)return SUB_GUARD_FEATURES_READY;
    if(!feature_p25())return SUB_GUARD_P25;
    if(control.cancel)return SUB_GUARD_CANCEL;
    if(owner_tx_inhibit)return SUB_GUARD_OWNER_INHIBIT;
    if(channel_record[12]&16u)return SUB_GUARD_CHANNEL_INHIBIT;
    if(control.state==RADIO_FAULT)return SUB_GUARD_RADIO_FAULT;
    if(frequency!=trunk_subscriber_io.control_hz)return SUB_GUARD_CONTROL_HZ;
    if(control.source_id!=trunk_session.config.subscriber.radio_id)return SUB_GUARD_SOURCE_ID;
    if(control.talkgroup!=trunk_session.config.subscriber.group)return SUB_GUARD_TALKGROUP;
    if(control.nac!=trunk_session.config.subscriber.nac)return SUB_GUARD_NAC;
    if(trunk_subscriber_io.owner_hash!=trunk_subscriber_owner_hash())return SUB_GUARD_OWNER_HASH;
    if(radio_channel_get_private(channel_record))return SUB_GUARD_PRIVATE;
    if(channel_scan.running)return SUB_GUARD_SCAN;
    if(apps_active())return SUB_GUARD_APPS;
    if(pcm_owner)return SUB_GUARD_PCM_OWNER;
    if(applet_owns_radio)return SUB_GUARD_APPLET;
    if(cps_active)return SUB_GUARD_CPS_ACTIVE;
    if(cps_link)return SUB_GUARD_CPS_LINK;
    if(editing)return SUB_GUARD_EDITING;
    if(menu_open)return SUB_GUARD_MENU;
    if(rx_lab)return SUB_GUARD_RX_LAB;
    if(rx_job)return SUB_GUARD_RX_JOB;
    if(broadcast_show)return SUB_GUARD_BROADCAST;
    if(airband_show)return SUB_GUARD_AIRBAND;
    if(digital_dmr.owned)return SUB_GUARD_DMR_OWNER;
    if(analog_fm.owned)return SUB_GUARD_FM_OWNER;
    if(trunk_probe.active)return SUB_GUARD_PROBE;
    if(trunk_lab_return_owned())return SUB_GUARD_LAB_RETURN;
    if(trunk_lab_attach_selected())return SUB_GUARD_LAB_ATTACH;
    if(trunk_lab_ptt_selected())return SUB_GUARD_LAB_PTT;
    if(!dev)return SUB_GUARD_DEV;
    if(!hooks)return SUB_GUARD_HOOKS;
    if(!board.audio)return SUB_GUARD_AUDIO;
    if(!board.radio)return SUB_GUARD_RADIO;
    if(tx_fixed)return SUB_GUARD_TX_FIXED;
    if(!board.power->switch_on())return SUB_GUARD_POWER;
    return 0;
}
static bool trunk_subscriber_context(void) {return !trunk_subscriber_context_guard();}
static unsigned trunk_subscriber_permission_guard(void) {
    unsigned guard=trunk_subscriber_context_guard();if(guard)return guard;
    if(!feature_tx_settings_valid())return SUB_GUARD_TX_SETTINGS;
    if(!bf_cal_valid())return SUB_GUARD_CALIBRATION;
    if(!channel_in_band(frequency,false))return SUB_GUARD_RX_BAND;
    if(board.power->battery_mv()<board.battery_critical_mv)return SUB_GUARD_BATTERY;
    return 0;
}
static bool trunk_subscriber_permission(void) {return !trunk_subscriber_permission_guard();}
static unsigned trunk_subscriber_action_guard(void) {
    const p25_trunking_access_action *a=&trunk_subscriber_io.action;
    if(!a->id)return SUB_GUARD_ACTION_ID;
    if(a->id!=trunk_session.access.serial)return SUB_GUARD_ACTION_SERIAL;
    if(a->radio_id!=control.source_id)return SUB_GUARD_ACTION_SOURCE;
    if(a->group!=control.talkgroup)return SUB_GUARD_ACTION_GROUP;
    if(a->nac!=control.nac)return SUB_GUARD_ACTION_NAC;
    return 0;
}
static bool trunk_subscriber_action_current(void) {return !trunk_subscriber_action_guard();}
static bool trunk_subscriber_prepare_permission(bool packet,uint32_t tx_hz) {
    return trunk_subscriber_io.handoff&&trunk_subscriber_permission()
        &&trunk_subscriber_action_current()&&tx_hz==trunk_subscriber_io.action.tx_hz
        &&channel_in_band(tx_hz,true)
        &&(packet?trunk_subscriber_io.phase==SUB_IO_PREPARE
            :trunk_subscriber_io.phase==SUB_IO_VOICE_PREPARE);
}
static void trunk_subscriber_abort_irq(unsigned cause,int32_t delay_us) {
    trunk_subscriber_failure_latch(cause,delay_us);
    board_rf_safe();hardware_stop();call_active=false;pcmq.accepting=false;
    trunk_subscriber_return_fail();
    p25_test_tx_abort(&live.timing,P25_TX_CANCELLED);
    trunk_subscriber_io.request_success=false;trunk_subscriber_io.phase=SUB_IO_FAILED;
    reason="trunk_transport_failed";
}
static unsigned trunk_subscriber_request_guard(void) {
    unsigned guard=trunk_subscriber_context_guard();if(guard)return guard;
    guard=trunk_subscriber_action_guard();if(guard)return guard;
    if(!prepared)return SUB_GUARD_PREPARED;
    if(!call_active)return SUB_GUARD_CALL_ACTIVE;
    if(!message_packet_tx)return SUB_GUARD_MESSAGE_PACKET;
    if(mon_running)return SUB_GUARD_MON_RUNNING;
    if(trunk_subscriber_io.image_hash!=trunk_subscriber_image_hash())return SUB_GUARD_IMAGE;
    if(trunk_subscriber_io.action.type==P25_TRUNK_ACTION_GROUP_REQUEST&&hrc_pin_read(PIN_PTT))return SUB_GUARD_PTT;
    return 0;
}
static bool trunk_subscriber_request_irq_permission(void) {
    return !trunk_subscriber_request_guard();
}
// Call only where a failed admission already terminates with CONTEXT. Cutoff
// classification and speculative permission queries keep the pure wrapper.
static bool trunk_subscriber_request_admission(void) {
    unsigned guard=trunk_subscriber_request_guard();
    if(guard)trunk_subscriber_failure_latch(SUB_FAIL_CONTEXT,-(int32_t)guard);
    return !guard;
}
static bool trunk_subscriber_voice_irq_permission(void) {
    if(!trunk_subscriber_voice_owned())return true;
    bool ready=trunk_subscriber_context()&&trunk_subscriber_action_current()
        &&prepared&&call_active&&!message_packet_tx
        &&(trunk_subscriber_io.voice_started
            ||(!hrc_pin_read(PIN_PTT)
                &&(uint32_t)(hrc_micros()-trunk_subscriber_io.voice_start_us)<250000u));
    if(!ready)trunk_subscriber_abort_irq(SUB_FAIL_VOICE,0);
    return ready;
}
static bool trunk_subscriber_voice_pa_started(void) {
    if(!trunk_subscriber_voice_owned())return true;
    if(trunk_subscriber_io.voice_started||!trunk_subscriber_voice_irq_permission())return false;
    trunk_subscriber_io.voice_started=true;return true;
}
static bool trunk_subscriber_pa_timer(void) {
    if(!trunk_subscriber_request_owned())return false;
    if(trunk_subscriber_io.phase!=SUB_IO_CLOCK_WAIT)return true;
    uint32_t now=hrc_micros();
    int32_t late=(int32_t)(now-trunk_subscriber_io.clock_due_us);
    if(late<0||late>500||(int32_t)(now-trunk_subscriber_io.deadline_us)>=0) {
        trunk_subscriber_abort_irq(SUB_FAIL_CLOCK_LATE,late);return true;
    }
    if(!trunk_subscriber_request_admission()) {trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,0);return true;}
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);
    wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    trunk_subscriber_io.start_us=now;trunk_subscriber_io.phase=SUB_IO_CLOCK;
    wr(C7_LAYER2_CONTROL,0x82);hrc_irq_enable(IRQ_MODEM_SYS,true);return true;
}
static bool trunk_subscriber_boundary(uint32_t now,unsigned source) {
    if(!trunk_subscriber_request_owned())return false;
    if(source!=1u)return true;
    if(trunk_subscriber_io.phase!=SUB_IO_CLOCK&&trunk_subscriber_io.phase!=SUB_IO_REQUEST)return true;
    if(!trunk_subscriber_request_admission()) {trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,0);return true;}
    if((int32_t)(now-trunk_subscriber_io.deadline_us)>=0) {
        trunk_subscriber_abort_irq(SUB_FAIL_TASK_DEADLINE,(int32_t)(now-trunk_subscriber_io.deadline_us));return true;
    }
    if(trunk_subscriber_io.native_count) {
        uint32_t gap=now-trunk_subscriber_io.last_phy_us;
        if(gap<15000u)return true;
        if(gap<27000u||gap>33000u) {trunk_subscriber_abort_irq(SUB_FAIL_NATIVE_CADENCE,(int32_t)gap);return true;}
    } else if((uint32_t)(now-trunk_subscriber_io.start_us)<27000u
              ||(uint32_t)(now-trunk_subscriber_io.start_us)>33000u) {
        trunk_subscriber_abort_irq(SUB_FAIL_NATIVE_CADENCE,(int32_t)(now-trunk_subscriber_io.start_us));return true;
    }
    trunk_subscriber_io.last_phy_us=now;
    if(trunk_subscriber_io.phase==SUB_IO_CLOCK) {
        if(++trunk_subscriber_io.native_count<4u)return true;
        int32_t error=(int32_t)(now-trunk_subscriber_io.target_us);
        if(trunk_subscriber_io.native_count!=4u||error< -3000||error>3000
           ||!p25_test_tx_start(&live.timing,now,true)) {
            trunk_subscriber_abort_irq(SUB_FAIL_EDGE,error);return true;
        }
        trunk_subscriber_io.phase=SUB_IO_REQUEST;trunk_subscriber_io.deadline_us=now+37000u;
        if(tx_dac_restore)hrc_dac_b_power(true);
        hardware_running=true;pa_started=true;control.state=RADIO_TX_PREPARE;
        uint32_t arm_us=hrc_micros();
        if((int32_t)(arm_us-trunk_subscriber_io.deadline_us)>=0) {
            trunk_subscriber_abort_irq(SUB_FAIL_CUTOFF,(int32_t)(arm_us-trunk_subscriber_io.deadline_us));return true;
        }
        hrc_timer_oneshot(TIMER_BOARD,trunk_subscriber_io.deadline_us-arm_us);
        uint32_t switch_begin=hrc_micros();
        hooks->rf_switch(true);
        uint32_t switch_end=hrc_micros();
        if(!trunk_subscriber_failure.cause)trunk_subscriber_failure.switch_us=switch_end-switch_begin;
        if(!trunk_subscriber_request_admission()) {trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,0);return true;}
        uint32_t pa_us=hrc_micros();
        // The proven compact path's PA admission origin is SWITCH_END. The
        // synchronous RF-chip bus work is not PA lateness; the absolute PHY
        // edge+37ms cutoff remains armed throughout it and cannot be extended.
        if(pa_us-switch_end>500u||(int32_t)(pa_us-trunk_subscriber_io.deadline_us)>=0) {
            trunk_subscriber_abort_irq(SUB_FAIL_PA_LATE,(int32_t)(pa_us-switch_end));return true;
        }
        hooks->pa_on();tx_dac.pa=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PA;
        // Match the compact launch: service native RF latches only after PA
        // admission. Our RF handler acknowledges them without re-keying RF.
        hrc_irq_enable(IRQ_MODEM_RF_TX,true);hrc_irq_enable(IRQ_MODEM_RF_RX,true);
    }
    if(++trunk_subscriber_io.publications>2u) {trunk_subscriber_abort_irq(SUB_FAIL_PUBLICATIONS,0);return true;}
    live.timing.have_boundary=true;live.timing.last_boundary_us=now;
    live.timing.state=P25_TX_STREAMING;live.timing.blocks=trunk_subscriber_io.publications;
    wr(C7_LAYER2_TXRX_CTRL,0x80);return true;
}
static bool trunk_subscriber_rf_irq(void) {
    if(!trunk_subscriber_request_owned())return false;
    if(trunk_subscriber_io.phase==SUB_IO_REQUEST&&!trunk_subscriber_request_admission())
        trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,0);
    return true;
}
static bool trunk_subscriber_cutoff(void) {
    // Timer 5 belongs to the restored receiver once REQUEST_RETURN starts.
    // A repeated cutoff must neither revoke completion nor stop that timer.
    if(!trunk_subscriber_request_owned()||trunk_subscriber_io.phase==SUB_IO_REQUEST_RETURN)return false;
    board_rf_safe();uint32_t now=hrc_micros();
    trunk_subscriber_return_off(now);
    bool success=trunk_subscriber_io.phase==SUB_IO_REQUEST
        &&trunk_subscriber_request_irq_permission()&&trunk_subscriber_io.publications==2u
        &&(int32_t)(now-trunk_subscriber_io.deadline_us)>=0
        &&now-trunk_subscriber_io.deadline_us<=500u;
    if(!success)trunk_subscriber_failure_latch(SUB_FAIL_CUTOFF,(int32_t)(now-trunk_subscriber_io.deadline_us));
    hardware_stop();call_active=false;pcmq.accepting=false;
    if(!success)trunk_subscriber_return_fail();
    live.timing.state=success?P25_TX_DONE:P25_TX_ABORTED;
    live.timing.reason=success?P25_TX_OK:P25_TX_TIMEOUT;
    trunk_subscriber_io.request_success=success;
    trunk_subscriber_io.phase=success?SUB_IO_REQUEST_RETURN:SUB_IO_FAILED;
    reason=success?"complete":"trunk_request_timeout";return true;
}
enum {SUB_CUTOFF_UNAVAILABLE,SUB_CUTOFF_ARMED,SUB_CUTOFF_PENDING};
static unsigned trunk_subscriber_cutoff_timer(void) {
#if defined(TMR_INTSTAT) && defined(TMR_CTRL) && defined(PIC_MASK)
    // Side-effect-free hardware evidence. Rearming the request timer clears
    // its previous EOI; a stopped/masked timer cannot authorize completion.
    if((TMR_CTRL(TIMER_BOARD)&(TMR_CTRL_EN|TMR_CTRL_PERIODIC|TMR_CTRL_INT_MASK))!=TMR_CTRL_EN
       ||(PIC_MASK&(1u<<IRQ_TIMER5)))return SUB_CUTOFF_UNAVAILABLE;
    return (TMR_INTSTAT(TIMER_BOARD)&1u)?SUB_CUTOFF_PENDING:SUB_CUTOFF_ARMED;
#else
    // HAL mocks without a pending-register model keep the fail-closed path.
    return SUB_CUTOFF_UNAVAILABLE;
#endif
}
static void trunk_subscriber_cleanup(void) {
    // The adapter owns RX restoration and acknowledges completion in its task.
    // Generic cleanup may be called by STOP/fault; it must not silently finish
    // a subscriber transaction or manufacture an addressed network response.
    if(trunk_subscriber_transport_owned()&&!trunk_subscriber_io.cleaning) {
        trunk_subscriber_failure_latch(SUB_FAIL_CLEANUP,0);
        trunk_subscriber_io.phase=SUB_IO_FAILED;
    }
}
static void trunk_subscriber_release_tx(void) {
    trunk_subscriber_io.cleaning=true;cleanup();trunk_subscriber_io.cleaning=false;
    message_packet_tx=false;live.packet=NULL;live.packet_length=live.packet_pos=0;
}
static bool trunk_subscriber_begin_request(const p25_trunking_access_action *action,
    const uint8_t prefix[45],uint32_t target_us) {
    unsigned guard=!action?SUB_GUARD_ACTION_PTR:!prefix?SUB_GUARD_PREFIX
        :trunk_subscriber_transport_owned()?SUB_GUARD_TRANSPORT:trunk_subscriber_permission_guard();
    if(!guard&&!channel_in_band(action->tx_hz,true))guard=SUB_GUARD_TX_BAND;
    if(!guard&&tx_writer!=TX_WRITER_ALT1)guard=SUB_GUARD_WRITER;
    if(!guard&&!tx_dac_restore)guard=SUB_GUARD_DAC_RESTORE;
    if(guard) {trunk_subscriber_failure_latch(SUB_FAIL_CONTEXT,-(int32_t)guard);return false;}
    uint8_t image[72];p25_trunking_preload_plan plan;
    p25_trunking_preload_config config={0u,0u,0u};
    if(!p25_trunking_preload_plan_make(&plan,&config)
       ||!p25_trunking_preload_render(&plan,prefix,image)) {
        trunk_subscriber_failure_latch(SUB_FAIL_RENDER,0);return false;
    }
    trunk_subscriber_io.action=*action;trunk_subscriber_io.phase=SUB_IO_PREPARE;
    trunk_subscriber_return_arm(action->id,SUB_RETURN_REQUEST);
    trunk_subscriber_io.handoff=true;trunk_subscriber_io.request_success=false;
    trunk_subscriber_io.voice_started=false;trunk_subscriber_io.native_count=0;
    trunk_subscriber_io.publications=0;trunk_subscriber_io.last_phy_us=0;
    trunk_subscriber_io.target_us=target_us;trunk_subscriber_io.clock_due_us=target_us-120000u;
    uint32_t prepare_begin=hrc_micros();trunk_subscriber_io.deadline_us=prepare_begin+250000u;
    bool ready=prepare_p25_tx_at(true,action->tx_hz);
    if(!trunk_subscriber_failure.cause)trunk_subscriber_failure.prepare_us=hrc_micros()-prepare_begin;
    if(!ready) {trunk_subscriber_failure_latch(SUB_FAIL_SETUP,0);trunk_subscriber_io.phase=SUB_IO_FAILED;return false;}
    p25_live_tx_init(&live);memset(&pcmq,0,sizeof pcmq);message_packet_tx=true;
    memcpy(message_packet,prefix,40u);
    control.state=RADIO_TX_PREPARE;call_active=true;control.cancel=false;
    uint32_t lock=hrc_irq_save();
    for(unsigned i=0;i<72u;++i)dev->buf[i]=image[i];
    trunk_subscriber_io.image_hash=trunk_subscriber_image_hash();
    wr(C7_LAYER2_TXRX_CTRL,0);wr(C7_SYS_INTERP_CLEAR,0xffffffffu);
    wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    wr(C7_SYS_INTERP_MASK,PHY_READY);
    uint32_t now=hrc_micros();bool okay=(int32_t)(trunk_subscriber_io.clock_due_us-now)>0
        &&(int32_t)(trunk_subscriber_io.target_us-trunk_subscriber_io.deadline_us)<0;
    if(!okay)trunk_subscriber_failure_latch(SUB_FAIL_PREPARE_DEADLINE,(int32_t)(now-trunk_subscriber_io.clock_due_us));
    if(okay&&!hard_guard_arm(2u)) {trunk_subscriber_failure_latch(SUB_FAIL_GUARD,0);okay=false;}
    if(okay&&!trunk_subscriber_request_admission())okay=false;
    if(okay) {
        trunk_subscriber_io.phase=SUB_IO_CLOCK_WAIT;
        hrc_barrier(); // Publish the immutable action/image before any timer can observe it.
        hrc_irq_enable(IRQ_TIMER5,true);hrc_timer_oneshot(TIMER_BOARD,trunk_subscriber_io.deadline_us-now);
        hrc_irq_enable(IRQ_MODEM_TS_TX,true);hrc_irq_enable(IRQ_MODEM_TS_RX,true);
        hrc_timer_ack(TIMER_PA);hrc_timer_oneshot(TIMER_PA,trunk_subscriber_io.clock_due_us-now);
        reason="trunk_request";
    } else trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,0);
    hrc_irq_restore(lock);return okay;
}
static bool trunk_subscriber_begin_voice(const p25_trunking_access_action *action) {
    if(!action||trunk_subscriber_transport_owned()||!trunk_subscriber_permission()
       ||!channel_in_band(action->tx_hz,true)||hrc_pin_read(PIN_PTT))return false;
    trunk_subscriber_io.action=*action;trunk_subscriber_io.phase=SUB_IO_VOICE_PREPARE;
    trunk_subscriber_return_arm(action->id,SUB_RETURN_VOICE);
    trunk_subscriber_io.handoff=true;trunk_subscriber_io.voice_started=false;
    trunk_subscriber_io.voice_acknowledged=false;
    trunk_subscriber_io.voice_start_us=hrc_micros();
    control.tx_frequency=action->tx_hz;control.split=action->tx_hz!=frequency;
    if(!p25_channel_build_group_options(&call_frames,action->nac,action->group,action->radio_id,action->options)
       ||!prepare_p25_tx_at(false,action->tx_hz)||!imbe_bench_init())return false;
    p25_live_tx_init(&live);memcpy(live.hdu,call_frames.hdu,sizeof live.hdu);
    memcpy(live.tdu,call_frames.tdu,sizeof live.tdu);memset(&pcmq,0,sizeof pcmq);memset(payload,0,sizeof payload);
    (void)p25_voice_receipt_begin(&trunk_subscriber_voice_receipt,action->id);
    unsigned seconds=action->tot_ms/1000u;
    if(!seconds||!p25_live_tx_set_startup_extra(&live,tx_startup_extra)
       ||!p25_live_tx_set_rf_limit(&live,(seconds+5u)*1000000u))return false;
    encoded=target=max_encode=max_pack=driver_loss=rf_audio=0;payload_hash=2166136261u;
    // Prime real encoded quiet speech rather than waiting360ms for two live
    // LDUs. Those two ordinary transport banks do not extend microphone TOT.
    int16_t quiet[160]={0};uint8_t ldu[216];
    imbe_bench_encode_pcm(quiet,payload[0]);if(!imbe_bench_ready())return false;
    for(unsigned i=1;i<9u;++i)memcpy(payload[i],payload[0],11u);
    for(unsigned i=0;i<2u;++i) {
        p25_live_ldu_template(ldu,(const uint8_t (*)[11])payload,i?call_frames.ldu2:call_frames.ldu1);
        if(!p25_live_tx_push(&live,ldu))return false;
    }
    ui_subscriber_grant_preview();
    // A key release or display delay must revoke admission before MIC starts;
    // preview work does not extend the existing voice preparation lease.
    if(!trunk_subscriber_permission()||!trunk_subscriber_action_current()||hrc_pin_read(PIN_PTT)
       ||(uint32_t)(hrc_micros()-trunk_subscriber_io.voice_start_us)>=250000u)return false;
    call_capture_frames=seconds*50u;call_tot_expired=false;call_soft_limit_us=(seconds+3u)*1000000u;
    capture_started=last_pcm=hrc_micros();call_active=true;message_packet_tx=false;pcmq.accepting=true;
    hrc_audio_pcm_reset_stats();hrc7000_set_mic_gain(dev,(uint8_t)mic_gain_db);
    audio_on=board.audio->start(capture,NULL);control.state=RADIO_TX_PREPARE;
    if(!audio_on||!trunk_subscriber_permission()||hrc_pin_read(PIN_PTT)
       ||(uint32_t)(hrc_micros()-trunk_subscriber_io.voice_start_us)>=250000u)return false;
    trunk_subscriber_io.phase=SUB_IO_VOICE;reason="voice_call";start_rf();
    return hardware_running;
}
static void trunk_subscriber_block(uint64_t first_tick,uint32_t irq_us,bool valid) {
    trunk_subscriber_io.source_valid=valid&&trunk_subscriber_active()
        &&!trunk_subscriber_transport_owned();
    if(trunk_subscriber_io.source_valid) {
        trunk_subscriber_io.source_first_tick=first_tick;
        trunk_subscriber_io.source_irq_us=irq_us;
    }
}
static void trunk_subscriber_status(const p25_demod_status *status) {
    if(!trunk_subscriber_active()||trunk_subscriber_transport_owned()
       ||trunk_subscriber_io.receive_follow||!status)return;
    p25_trunking_slot_observation o={.sample_tick=status->sample_tick,
        .stream_epoch=status->stream_epoch,.lane_epoch=status->lane_epoch,
        .status=status->status,.selected=status->selected,
        .qualified=status->qualified&&status->duid==7u
            &&status->nac==trunk_session.config.subscriber.nac
            &&receiver_frequency()==trunk_subscriber_io.control_hz};
    uint64_t before=trunk_subscriber_backend.anchor_tick;
    bool had=trunk_subscriber_backend.have_anchor;
    (void)p25_trunking_backend_observe(&trunk_subscriber_backend,&trunk_session,&o,trunk_now_ms());
    if(!trunk_subscriber_backend.have_anchor||(!trunk_subscriber_io.source_valid)
       ||(had&&before==trunk_subscriber_backend.anchor_tick))return;
    uint64_t first=trunk_subscriber_io.source_first_tick,tick=trunk_subscriber_backend.anchor_tick;
    if(first>UINT64_MAX-1536u||tick>first+1536u||first+1536u-tick>2304u) {
        trunk_subscriber_backend.have_anchor=false;return;
    }
    uint32_t anchor=trunk_subscriber_io.source_irq_us-(uint32_t)((first+1536u-tick)*125u/6u);
    if((uint32_t)(hrc_micros()-anchor)>48000u) {
        trunk_subscriber_backend.have_anchor=false;return;
    }
    trunk_subscriber_io.target_us=anchor+225000u;
}
static bool trunk_subscriber_consume_control(uint16_t nac,uint32_t hz,
    const uint8_t block[12],uint32_t now) {
    if(!trunk_subscriber_active())return p25_trunking_session_consume_control(&trunk_session,nac,hz,block,now);
    return p25_trunking_backend_consume_control(&trunk_subscriber_backend,&trunk_session,
        nac,hz,trunk_stream_epoch,block,now);
}
static bool trunk_subscriber_start(const p25_trunking_session_config *config) {
    if(!config||trunk_subscriber_active()||!trunk_enabled||!mon_running||trunk_session.running
       ||config->control_rx_hz!=frequency||config->subscriber.nac!=control.nac
       ||config->subscriber.radio_id!=control.source_id||config->subscriber.group!=control.talkgroup
       ||call_active||prepared||hardware_running||!hrc_pin_read(PIN_PTT)
       ||!trunk_probe_mailbox_idle()||trunk_probe.active||trunk_lab_return_owned()
       ||trunk_lab_attach_selected()||trunk_lab_ptt_selected()||trunk_preload_cc_active())return false;
    if(!p25_trunking_backend_start(&trunk_subscriber_backend,&trunk_session,config,
            P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL,trunk_now_ms()))return false;
    memset(&trunk_subscriber_io,0,sizeof trunk_subscriber_io);
    trunk_subscriber_io.selected=true;trunk_subscriber_io.control_hz=frequency;
    trunk_subscriber_io.saved_tx_hz=control.tx_frequency;trunk_subscriber_io.saved_split=control.split;
    trunk_subscriber_io.owner_hash=trunk_subscriber_owner_hash();
    // PROM does not change the explicitly selected subscriber's site identity.
    trunk.configured_nac=trunk.learned_nac=config->subscriber.nac;trunk.have_nac=true;
    ptt_release_required=true;ptt_release_seen=false;
    trunk_reason="experimental_registering";return true;
}
static bool trunk_subscriber_begin_logout(void) {
    if(!trunk_subscriber_active()||trunk_subscriber_logout_pending()||trunk_subscriber_transport_owned()
       ||trunk_subscriber_io.receive_follow||trunk_subscriber_backend.inflight
       ||trunk_subscriber_backend.reacquiring||trunk_subscriber_backend.receive_suspended||!trunk_session.site_qualified
       ||!mon_running||mon_control_only||receiver_frequency()!=trunk_subscriber_io.control_hz
       ||trunk.phase!=P25_TRUNKING_CONTROL||!hrc_pin_read(PIN_PTT)
       ||(board.input->scan()&ptt_mask)||!trunk_subscriber_permission()
       ||!p25_trunking_backend_deregister(&trunk_subscriber_backend,&trunk_session,trunk_now_ms()))return false;
    // This is an explicit one-way departure request, not a network acceptance.
    // A new PTT press cannot replace it with voice or restart registration.
    trunk_subscriber_io.logout=SUB_LOGOUT_PENDING;
    trunk_subscriber_io.logout_deadline_us=hrc_micros()+SUB_LOGOUT_LIMIT_US;
    ptt_release_required=true;ptt_release_seen=false;
    trunk_reason="subscriber_logging_out";return true;
}
static void trunk_subscriber_cancel(void) {
    if(!trunk_subscriber_active()) {trunk_subscriber_io.logout=SUB_LOGOUT_NONE;return;}
    uint32_t lock=hrc_irq_save();
    bool owned=trunk_subscriber_transport_owned()||trunk_subscriber_io.phase==SUB_IO_FAILED;
    trunk_subscriber_io.cleaning=true;trunk_subscriber_io.handoff=true;
    if(owned) {
        board_rf_safe();hardware_stop();call_active=false;pcmq.accepting=false;
        p25_test_tx_abort(&live.timing,P25_TX_CANCELLED);
    }
    trunk_subscriber_return_fail();
    hrc_irq_restore(lock);
    if(owned) {audio_stop();reason="cancelled";trunk_subscriber_voice_snapshot(!hrc_pin_read(PIN_PTT));trunk_subscriber_release_tx();}
    control.tx_frequency=trunk_subscriber_io.saved_tx_hz;control.split=trunk_subscriber_io.saved_split;
    if(!hardware_running) {
        // An explicit operator stop owns the immediate physical kill above.
        // The backend retires the policy only after that physical RF-off
        // acknowledgement; no completion survives into the next system.
        (void)p25_trunking_backend_stop(&trunk_subscriber_backend,&trunk_session,true);
    }
    memset(&trunk_subscriber_io,0,sizeof trunk_subscriber_io);
    ptt_release_required=true;ptt_release_seen=false;
}
static void trunk_subscriber_logout_fail(void) {
    // Explicit Stop/fault remains immediate; the task never waits for a slot,
    // fresh RX or a nonexistent acknowledgement once this bound is exhausted.
    trunk_subscriber_cancel();trunk_subscriber_io.logout=SUB_LOGOUT_FAILED;
    trunk_reason="subscriber_logout_failed";
}
static bool trunk_subscriber_restore_control(void) {
    trunk_subscriber_io.handoff=true;
    trunk_subscriber_return_begin();
    if(call_active||hardware_running) {board_rf_safe();hardware_stop();call_active=false;pcmq.accepting=false;}
    // Voice completion already retires the producer before STOP/RETURN. Do
    // not replay generic fault completion after its error has been transferred
    // into the subscriber policy. A live preparation/audio owner still needs
    // its ordinary cleanup before reception can restart.
    if(prepared||audio_on)trunk_subscriber_release_tx();
    control.tx_frequency=trunk_subscriber_io.saved_tx_hz;control.split=trunk_subscriber_io.saved_split;
    trunk_receiver_hz=trunk_subscriber_io.control_hz;
    // Preparation can fail before it stopped the old receiver. Retire that
    // stream under handoff ownership before publishing the fresh return epoch.
    if(mon_running)mon_stop("subscriber_return");
    mon_enabled=true;trunk_subscriber_io.return_epoch=trunk_stream_epoch;
    if(!mon_start_subscriber_control()) {trunk_subscriber_return_fail();return false;}
    trunk_subscriber_io.deadline_us=hrc_micros()+1000000u;
    return mon_running&&trunk_stream_epoch!=trunk_subscriber_io.return_epoch;
}
static void trunk_subscriber_result(bool success,bool ready) {
    bool logout=trunk_subscriber_logout_pending();
    bool deregister=trunk_subscriber_io.action.type==P25_TRUNK_ACTION_DEREGISTER;
    bool accepted=p25_trunking_backend_result(&trunk_subscriber_backend,&trunk_session,
        trunk_subscriber_io.action.id,success,!hardware_running,ready,trunk_stream_epoch,trunk_now_ms());
    if(accepted&&success&&ready)trunk_subscriber_return_ready();
    else if(!accepted||!success)trunk_subscriber_return_fail();
    if(!accepted) {
        trunk_subscriber_failure_latch(SUB_FAIL_COMPLETION,0);
        // A revoked generation or expired receipt is not a successful network
        // transaction. Retire the backend only behind the actual RF-off kill;
        // never leave an invisible in-flight action after clearing this owner.
        if(hardware_running||call_active) {board_rf_safe();hardware_stop();call_active=false;pcmq.accepting=false;}
        if(prepared)trunk_subscriber_release_tx();
        (void)p25_trunking_backend_stop(&trunk_subscriber_backend,&trunk_session,true);
        trunk_reason="subscriber_stale_completion";
    }
    trunk_subscriber_io.phase=SUB_IO_IDLE;trunk_subscriber_io.handoff=false;
    trunk_subscriber_io.voice_started=false;
    memset(&trunk_subscriber_io.action,0,sizeof trunk_subscriber_io.action);
    if(!trunk_subscriber_backend.running)trunk_subscriber_io.selected=false;
    if(logout) {
        bool sent=accepted&&success&&ready&&deregister&&!hardware_running
            &&!trunk_subscriber_backend.running&&!trunk_session.running;
        trunk_subscriber_io.logout=sent?SUB_LOGOUT_SENT:SUB_LOGOUT_FAILED;
        trunk_reason=sent?"subscriber_logout_sent":"subscriber_logout_failed";
    }
}
static void trunk_subscriber_poll(bool down) {
    if(!trunk_subscriber_active())return;
    if(trunk_subscriber_menu_paused()) {
        ptt_release_required=true;ptt_release_seen=false;return;
    }
    if(trunk_subscriber_logout_pending()) {
        down=false;
        if((int32_t)(hrc_micros()-trunk_subscriber_io.logout_deadline_us)>=0) {
            trunk_subscriber_logout_fail();return;
        }
    }
    unsigned permission_guard=trunk_subscriber_permission_guard();
    if(permission_guard) {
        // Failed RX may also leave the generic controller faulted. Preserve
        // the terminal cause instead of replacing it on every later poll;
        // any still-owned physical transport is killed regardless below.
        if(trunk_session.access.phase!=P25_TRUNK_ACCESS_FAILED)
            p25_trunking_backend_cancel(&trunk_subscriber_backend,&trunk_session,
                P25_TRUNK_ACCESS_PERMISSION,trunk_now_ms());
        if(trunk_subscriber_transport_owned())trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,-(int32_t)permission_guard);
    }
    if(trunk_subscriber_io.receive_follow) {
        if(down) {
            ptt_release_required=true;ptt_release_seen=false;
            p25_trunking_end(&trunk,trunk_now_ms());
        }
        if(!trunk_subscriber_io.receive_returning)return;
        int32_t late=(int32_t)(hrc_micros()-trunk_subscriber_io.deadline_us);
        if(late>=0) {
            trunk_subscriber_failure_latch(SUB_FAIL_RETURN,late);
            trunk_subscriber_io.receive_follow=trunk_subscriber_io.receive_returning=false;
            p25_trunking_backend_cancel(&trunk_subscriber_backend,&trunk_session,
                P25_TRUNK_ACCESS_TRANSPORT,trunk_now_ms());return;
        }
        if(mon_running&&monitor.raw_blocks&&trunk_stream_epoch!=trunk_subscriber_io.return_epoch) {
            bool resumed=p25_trunking_backend_receive_resume(&trunk_subscriber_backend,&trunk_session,
                trunk_stream_epoch,trunk_now_ms());
            trunk_subscriber_io.receive_follow=trunk_subscriber_io.receive_returning=false;
            if(!resumed)p25_trunking_backend_cancel(&trunk_subscriber_backend,&trunk_session,
                P25_TRUNK_ACCESS_TRANSPORT,trunk_now_ms());
        }
        return;
    }
    if(trunk_subscriber_io.phase==SUB_IO_FAILED) {
        trunk_subscriber_voice_snapshot(down);
        bool restored=trunk_subscriber_restore_control();
        trunk_subscriber_result(false,false);
        if(!restored) {mon_enabled=false;radio_inhibit(&control,true);board_rf_safe();}
        trunk_reason="subscriber_transport_failed";
        if(!hardware_running&&!call_active&&!prepared&&!audio_on) {
            // Task-side, once per failed transport. An active receiver paints
            // this changed context through its existing cooperative renderer;
            // failed RX cannot service that renderer, so refresh home here.
            mon_render_cancel();mon_shown_context[0]=0;mon_badge_phase=255u;ui_header_shown=UINT32_MAX;
            if(!mon_running)screen("HOME");
        }
        return;
    }
    if(trunk_subscriber_request_owned()) {
        // A due cutoff can complete during the clock read. Check its fresh
        // owner/phase only afterward, with the decision and abort atomic.
        uint32_t request_now=hrc_micros(),request_lock=hrc_irq_save();
        int32_t request_late=(int32_t)(request_now-trunk_subscriber_io.deadline_us);
        bool expired=trunk_subscriber_request_owned()
            &&trunk_subscriber_io.phase!=SUB_IO_REQUEST_RETURN&&request_late>=0;
        if(expired) {
            // Timer 5 interrupts do not turn RF off autonomously. Kill it
            // immediately. The relative timer's register writes can place its
            // expiry a few us after deadline_us. Only its completion handoff
            // may wait within the existing 500-us ceiling, with RF already off.
            // Never rearm the timer or infer a successful missing interrupt.
            board_rf_safe();
            unsigned cutoff=trunk_subscriber_cutoff_timer();
            if(trunk_subscriber_io.phase==SUB_IO_REQUEST&&cutoff==SUB_CUTOFF_PENDING) {
                // Claim the pending timer before the task can cancel its ISR;
                // the common cutoff retains every completion admission check.
                (void)trunk_subscriber_cutoff();
                expired=trunk_subscriber_io.phase==SUB_IO_FAILED;
            } else if(trunk_subscriber_io.phase==SUB_IO_REQUEST&&cutoff==SUB_CUTOFF_ARMED
                      &&request_late<=500&&trunk_subscriber_io.publications==2u) {
                if(!trunk_subscriber_request_admission())
                    trunk_subscriber_abort_irq(SUB_FAIL_CONTEXT,0);
                // Otherwise return with RF off and let the still-armed IRQ
                // finish. At +501 us a missing interrupt fails below.
            } else trunk_subscriber_abort_irq(SUB_FAIL_TASK_DEADLINE,request_late);
        }
        hrc_irq_restore(request_lock);
        if(expired)return;
        if(trunk_subscriber_io.action.type==P25_TRUNK_ACTION_GROUP_REQUEST&&!down) {
            trunk_subscriber_abort_irq(SUB_FAIL_PTT,0);return;
        }
        if(trunk_subscriber_io.phase==SUB_IO_REQUEST_RETURN) {
            if(prepared||!mon_running) {
                if(!trunk_subscriber_restore_control()) {trunk_subscriber_abort_irq(SUB_FAIL_RETURN,0);return;}
            }
            int32_t late=(int32_t)(hrc_micros()-trunk_subscriber_io.deadline_us);
            if(late>=0) {trunk_subscriber_abort_irq(SUB_FAIL_RETURN,late);return;}
            if(mon_running&&monitor.raw_blocks&&trunk_stream_epoch!=trunk_subscriber_io.return_epoch) {
                // Arm WAIT_* before any returned raw block can dispatch a reply.
                trunk_subscriber_result(trunk_subscriber_io.request_success,true);
            }
        }
        return;
    }
    if(trunk_subscriber_voice_owned()) {
        if(trunk_subscriber_io.phase==SUB_IO_VOICE_RETURN) {
            if(!mon_running&&!trunk_subscriber_restore_control()) {trunk_subscriber_abort_irq(SUB_FAIL_RETURN,0);return;}
            int32_t late=(int32_t)(hrc_micros()-trunk_subscriber_io.deadline_us);
            if(late>=0) {trunk_subscriber_abort_irq(SUB_FAIL_RETURN,late);return;}
            if(mon_running&&monitor.raw_blocks&&trunk_stream_epoch!=trunk_subscriber_io.return_epoch)
                trunk_subscriber_result(true,true);
            return;
        }
        if(trunk_subscriber_io.action.type==P25_TRUNK_ACTION_VOICE_START
           &&trunk_subscriber_io.voice_started&&!trunk_subscriber_io.voice_acknowledged) {
            bool accepted=p25_trunking_backend_result(&trunk_subscriber_backend,&trunk_session,
                trunk_subscriber_io.action.id,true,false,false,trunk_stream_epoch,trunk_now_ms());
            if(!accepted) {trunk_subscriber_abort_irq(SUB_FAIL_COMPLETION,0);return;}
            trunk_subscriber_io.voice_acknowledged=true;
        }
        // The normal producer owns microphone frames, configured TOT and TDU
        // drain; it is deliberately not the finite six-second lab producer.
        if(call_active)poll_call(down&&!control.cancel);
        if(!call_active&&!hardware_running&&prepared) {
            bool success=live.timing.state==P25_TX_DONE;
            trunk_subscriber_voice_snapshot(down);
            trunk_subscriber_release_tx();
            if(!success) {
                p25_trunking_backend_cancel(&trunk_subscriber_backend,&trunk_session,
                    P25_TRUNK_ACCESS_TRANSPORT,trunk_now_ms());
                // The access policy now owns this latched producer failure.
                // Retire only the generic TX fault so RF-off STOP/RETURN and
                // receive recovery can run. Inhibit and failed access remain;
                // no new transmission is authorized by this state transfer.
                if(control.state==RADIO_FAULT&&trunk_session.access.failure_return
                   &&trunk_session.access.reason==P25_TRUNK_ACCESS_TRANSPORT)
                    radio_complete(&control,false);
            }
        }
        if(trunk_subscriber_io.phase==SUB_IO_VOICE_STOP&&!call_active&&!hardware_running)
            trunk_subscriber_result(true,false);
    }
    p25_trunking_session_clock clock=trunk_access_clock();uint32_t now=trunk_now_ms();
    p25_trunking_backend_poll(&trunk_subscriber_backend,&trunk_session,now,&clock,
        trunk_subscriber_permission(),down);
    if(trunk_subscriber_logout_pending()&&trunk_session.access.phase!=P25_TRUNK_ACCESS_DEREGISTER) {
        // Site loss can move the ordinary access policy back to WAIT_SITE.
        // Departure must never turn that recovery path into a new REGISTER.
        trunk_subscriber_logout_fail();return;
    }
    p25_trunking_backend_action action;
    if(!p25_trunking_backend_take(&trunk_subscriber_backend,&trunk_session,&action,now,&clock))return;
    const p25_trunking_access_action *a=&action.session.access;
    if(trunk_subscriber_logout_pending()&&a->type!=P25_TRUNK_ACTION_DEREGISTER) {
        trunk_subscriber_logout_fail();return;
    }
    if(a->type==P25_TRUNK_ACTION_REGISTER||a->type==P25_TRUNK_ACTION_AFFILIATE
       ||a->type==P25_TRUNK_ACTION_GROUP_REQUEST||a->type==P25_TRUNK_ACTION_DEREGISTER) {
        bool suspended=p25_trunking_backend_suspend(&trunk_subscriber_backend,&trunk_session,a->id);
        if(!suspended)trunk_subscriber_failure_latch(SUB_FAIL_CONTEXT,-(int32_t)SUB_GUARD_SUSPEND);
        if(!suspended||!trunk_subscriber_begin_request(a,action.session.tsdu,trunk_subscriber_io.target_us)) {
            trunk_subscriber_failure_latch(SUB_FAIL_CONTEXT,0);
            trunk_subscriber_io.action=*a;trunk_subscriber_io.phase=SUB_IO_FAILED;
        }
    } else if(a->type==P25_TRUNK_ACTION_VOICE_START) {
        bool suspended=p25_trunking_backend_suspend(&trunk_subscriber_backend,&trunk_session,a->id);
        if(!suspended||!trunk_subscriber_begin_voice(a)) {
            trunk_subscriber_failure_latch(SUB_FAIL_VOICE,0);
            trunk_subscriber_io.action=*a;trunk_subscriber_io.phase=SUB_IO_FAILED;
        }
    } else if(a->type==P25_TRUNK_ACTION_VOICE_STOP) {
        trunk_subscriber_io.action=*a;trunk_subscriber_io.phase=SUB_IO_VOICE_STOP;
        if(call_active)poll_call(false);
        if(!hardware_running&&!call_active) {
            trunk_subscriber_voice_snapshot(down);
            if(prepared)trunk_subscriber_release_tx();
            trunk_subscriber_result(true,false);
        }
    } else if(a->type==P25_TRUNK_ACTION_RETURN_CONTROL) {
        trunk_subscriber_io.action=*a;trunk_subscriber_io.phase=SUB_IO_VOICE_RETURN;
        (void)p25_trunking_backend_suspend(&trunk_subscriber_backend,&trunk_session,a->id);
        if(!trunk_subscriber_restore_control())trunk_subscriber_abort_irq(SUB_FAIL_RETURN,0);
    }
}
#endif
