// SPDX-License-Identifier: GPL-3.0-or-later
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {WebFlashDevice, DM32, MONITOR_SHA256} from '../flasher/device.js';
// Test-only pinned simulations. No production import depends on the checkout.
import {FakeC7000} from '../../../external/RadioFoundry/RadioFoundry/site/static/js/flasher/fakec7000.js';

const assetUrl = new URL('../flasher/vendor/dm32-loader.json', import.meta.url);
const assets = JSON.parse(await readFile(assetUrl, 'utf8'));
const hash = value => createHash('sha256').update(value).digest('hex');

test('loader fetch uses the global receiver and caches the validated asset', async () => {
  let calls = 0;
  const device = new WebFlashDevice({fetch: async function (url) {
    assert.equal(this, globalThis, 'native Chromium fetch requires its global receiver');
    assert.equal(url.href, assetUrl.href);
    calls++;
    return {ok: true, json: async () => assets};
  }});
  const loaded = await device._loadAssets();
  assert.equal(loaded.image.sha, MONITOR_SHA256);
  assert.equal(loaded.profile.id, 1);
  assert.equal(await device._loadAssets(), loaded);
  assert.equal(calls, 1);
  assert.equal(device.connected, false);
});

function bench(options = {}) {
  const program = new Uint8Array(DM32.programSize).fill(0xff);
  program.set(new TextEncoder().encode(options.loaderId || DM32.loaderId), 32);
  program.set([0x2c, 0x11, 1, 0xc0], DM32.appStart);
  const radio = new FakeC7000({progmem: program, board: 'DM-32UV', loaderId: DM32.loaderId,
    speed: 100000, romWindow: 100, bootTime: 100, faults: options.faults || {}});
  const port = {}; const sent = []; const logs = []; let requests = 0, opens = 0;
  const device = new WebFlashDevice({serial: {requestPort: async () => {requests++; return port;}},
    assets: options.assets || assets, romTimeoutMs: options.romTimeoutMs || 3000,
    factoryTimeoutMs: 5000, log: line => logs.push(line),
    streamFactory: async selected => {
      assert.equal(selected, port); opens++;
      const stream = radio.makeStream(), write = stream.write;
      stream.write = async bytes => {sent.push(bytes.slice()); return write(bytes);};
      radio.stream = stream; return stream;
    }});
  return {device, radio, port, sent, logs, requests: () => requests, opens: () => opens};
}

test('vendored MIT sources are byte-identical and monitor asset has its independently pinned hash', async () => {
  const base = new URL('../flasher/vendor/', import.meta.url);
  const provenance = JSON.parse(await readFile(new URL('UPSTREAM.json', base), 'utf8'));
  const upstream = fileURLToPath(new URL('../../../external/RadioFoundry/RadioFoundry/', import.meta.url));
  const sourceBlob = path => execFileSync('git', ['-C', upstream, 'show', `${provenance.commit}:${path}`]);
  for (const [path, wanted] of Object.entries(provenance.files)) {
    const data = await readFile(new URL(path, base));
    assert.deepEqual(data, sourceBlob(`site/static/js/${path}`), `${path}: pinned Git blob`);
    assert.equal(hash(data), wanted, path);
    assert.equal(data.length, provenance.byteCounts[path], path);
    assert.match(data.toString(), /SPDX-License-Identifier: MIT/);
  }
  const license = await readFile(new URL('LICENSE.RadioFoundry', base));
  assert.deepEqual(license, sourceBlob('LICENSE'));
  assert.equal(hash(license), provenance.licenseSha256);
  assert.equal(license.length, provenance.licenseBytes);
  assert.match(license.toString(), /Permission is hereby granted/);
  for (const path of ['UPSTREAM.json', 'dm32-loader.json']) {
    assert.ok(!(await readFile(new URL(path, base))).includes(13), `${path}: canonical LF`);
  }
  assert.equal(hash(Buffer.from(assets.stub.univ.data, 'base64')), MONITOR_SHA256);
});

test('connect opens only on explicit request, sends no radio bytes and close forgets selection', async () => {
  const b = bench();
  assert.equal(b.device.connected, false); assert.equal(b.device.selectedPort, null);
  await b.device.connect(); await b.device.connect();
  assert.equal(b.requests(), 1); assert.equal(b.opens(), 1); assert.equal(b.device.selectedPort, b.port);
  assert.equal(b.device.connected, true); assert.equal(b.sent.length, 0);
  await b.device.close(); assert.equal(b.device.connected, false); assert.equal(b.device.selectedPort, null);
  b.radio.stop();
});

test('close during a pending port chooser or open cannot reopen a forgotten cable', async () => {
  let choose, open, closed = 0;
  const port = {};
  const chooser = new WebFlashDevice({serial: {requestPort: () => new Promise(resolve => {choose = resolve;})},
    streamFactory: async () => {assert.fail('closed chooser must not open');}});
  const choosing = chooser.connect();
  await chooser.close(); choose(port);
  await assert.rejects(choosing, {code: 'ABORTED'});
  assert.equal(chooser.connected, false); assert.equal(chooser.selectedPort, null);
  const openingDevice = new WebFlashDevice({port, streamFactory: () => new Promise(resolve => {open = resolve;})});
  const opening = openingDevice.connect();
  await openingDevice.close();
  open({close: async () => {closed++;}});
  await assert.rejects(opening, {code: 'ABORTED'});
  assert.equal(closed, 1); assert.equal(openingDevice.connected, false); assert.equal(openingDevice.selectedPort, null);
});

test('full snapshots use actual pinned ROM/stub CRC protocol and second read reuses monitor', async t => {
  const b = bench({faults: {misplace: [0x10000, 0x710000]}});
  t.after(async () => {await b.device.close(); b.radio.stop();});
  await b.device.connect();
  const progress = [];
  const first = await b.device.readSnapshot({onProgress: p => progress.push(p),
    onPhase: phase => {if (phase === 'power-on') b.radio.powerOn();}});
  assert.deepEqual(first.program, b.radio.progmem); assert.deepEqual(first.data, b.radio.q128);
  assert.equal(first.program.length, 0x100000); assert.equal(first.data.length, 0x1000000);
  assert.equal(b.radio.state, 'stub'); assert.equal(b.radio.stubCfg.board, 1);
  assert.equal(b.radio.faults.misplace.length, 0, 'misplaced sector frames were reconciled');
  assert.ok(progress.some(p => p.memory === 'program' && p.current === 0x100000));
  assert.ok(progress.some(p => p.memory === 'data' && p.current === 0x1000000));
  b.radio.q128[0xa40000] ^= 1;
  const second = await b.device.readSnapshot();
  assert.equal(second.data[0xa40000], b.radio.q128[0xa40000]);
  assert.notEqual(second.data[0xa40000], first.data[0xa40000]);
  assert.equal(b.logs.filter(s => s.startsWith('RAM reader is listening.')).length, 1);
  assert.equal(b.opens(), 1); assert.equal(b.radio.writes, 0);
});

test('factory identify reopens same port, never erases, and its exact instance completes transfer then fresh readback', async t => {
  const b = bench();
  t.after(async () => {await b.device.close(); b.radio.stop();});
  await b.device.connect();
  await assert.rejects(b.device.write(Uint8Array.of(1)), {code: 'NEED_IDENTIFY'});
  const beforeBoot = b.radio.progmem.slice(0, DM32.appStart), beforeData = hash(b.radio.q128);
  const identity = await b.device.factoryIdentify({onPhase: phase => {
    if (phase === 'factory-mode') b.radio.powerOn({keys: true});
  }});
  assert.equal(identity.id, DM32.loaderId); assert.equal(b.requests(), 1); assert.equal(b.opens(), 2);
  assert.ok(!b.radio.events.includes('erase')); assert.equal(b.radio.writes, 0);
  const image = new Uint8Array(3 * 1024 + 3); image.fill(0xa5); image[0] = 0x2c;
  b.radio.bf.corrupt.add(2); // NAK once; retry must retain the same identified loader.
  const phases = [], result = await b.device.write(image, {onPhase: phase => phases.push(phase)});
  assert.deepEqual(result, {blocksWritten: 4, transferred: true, independentlyVerified: false});
  assert.deepEqual(phases, ['erase', 'write']); assert.equal(b.radio.bf.ignored, 0, 'no second step1 handshake');
  assert.equal(b.radio.bf.naks, 1); assert.deepEqual(b.radio.bf.errors, []);
  assert.deepEqual(b.radio.progmem.slice(0, DM32.appStart), beforeBoot);
  assert.deepEqual(b.radio.progmem.slice(DM32.appStart, DM32.appStart + image.length), image);
  assert.equal(hash(b.radio.q128), beforeData, 'data/calibration/settings never written');
  await assert.rejects(b.device.write(image), {code: 'NEED_IDENTIFY'});
  b.radio.powerOff();
  const readback = await b.device.readSnapshot({fresh: true,
    onPhase: phase => {if (phase === 'power-on') b.radio.powerOn();}});
  assert.deepEqual(readback.program.slice(DM32.appStart, DM32.appStart + image.length), image);
  assert.equal(hash(readback.data), beforeData);
});

test('asset corruption fails before ROM requests or erase', async t => {
  const corrupt = structuredClone(assets); corrupt.stub.univ.data = corrupt.stub.univ.data.slice(4);
  const b = bench({assets: corrupt}); t.after(async () => {await b.device.close(); b.radio.stop();});
  await b.device.connect();
  await assert.rejects(b.device.readSnapshot(), {code: 'ASSET'});
  assert.equal(b.sent.length, 0); assert.equal(b.radio.writes, 0);
});

test('wrong bootloader model rejects snapshot before data read or flash commands', async t => {
  const b = bench({loaderId: 'BFUV31-V1'});
  t.after(async () => {await b.device.close(); b.radio.stop();});
  await b.device.connect(); let dataRead = false;
  await assert.rejects(b.device.readSnapshot({onPhase: phase => {
    if (phase === 'power-on') b.radio.powerOn(); if (phase === 'read-data') dataRead = true;
  }}), {code: 'WRONG_MODEL'});
  assert.equal(dataRead, false); assert.equal(b.radio.writes, 0);
});

test('abort, missing power-on and concurrent calls leave flash untouched', async t => {
  const b = bench({romTimeoutMs: 30}); t.after(async () => {await b.device.close(); b.radio.stop();});
  await b.device.connect();
  const controller = new AbortController(); controller.abort();
  await assert.rejects(b.device.readSnapshot({signal: controller.signal}), {code: 'ABORTED'});
  const pending = b.device.readSnapshot();
  await assert.rejects(b.device.factoryIdentify(), {code: 'IN_USE'});
  await assert.rejects(pending, /boot ROM did not answer/);
  assert.equal(b.sent.length, 0); assert.equal(b.radio.writes, 0);
});

test('image validation is enforced before the factory erase', async t => {
  const b = bench(); t.after(async () => {await b.device.close(); b.radio.stop();});
  await b.device.connect();
  await b.device.factoryIdentify({onPhase: phase => {if (phase === 'factory-mode') b.radio.powerOn({keys: true});}});
  for (const image of [new Uint8Array(0), new Uint8Array(16), new Uint8Array(DM32.appEnd - DM32.appStart + 1).fill(1)]) {
    await assert.rejects(b.device.write(image));
    assert.ok(!b.radio.events.includes('erase')); assert.equal(b.radio.writes, 0);
  }
});
