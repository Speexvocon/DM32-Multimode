"""Execute fixed RX-only native HAL and stale-IRQ denial with actual RF driver."""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RF = ROOT / 'external/RadioFoundry/RadioFoundry'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RxOnlyBoardTest(unittest.TestCase):
    def test_native_tx_stale_irq_and_pcm_denied_but_receive_works(self):
        cc = shutil.which('gcc')
        if not cc:
            self.skipTest('host GCC required for generated board integration')
        board = load('rx_only_board', ROOT / 'scripts/generate-pcm-radio.py')
        driver = load('rx_only_driver', ROOT / 'scripts/generate-rf-driver-backports.py')
        for experimental in (False, True):
            with self.subTest(experimental=experimental), tempfile.TemporaryDirectory(prefix='rx-only-board-') as tmp:
                build = Path(tmp)
                (build / 'radio_dm32_generated.c').write_text(board.generate(
                    (RF / 'boards/dm32/radio_dm32.c').read_text(), experimental))
                for suffix in ('c', 'h'):
                    relative = f'drivers/rf/fd6818/fd6818.{suffix}'
                    target = build / f'rf/fd6818/fd6818.{suffix}'
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(driver.generate(relative, (RF / relative).read_text()))
                binary = build / 'rx-only-board.exe'
                command = [cc, '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                           '-DDM32_OMAHA_RX_ONLY=1', '-DDM32_RF_B_EXPERIMENTAL=' + str(int(experimental))]
                for include in (ROOT / 'tests/rf-board-stubs', build, ROOT / 'src/firmware', RF / 'hal', RF / 'drivers'):
                    command += ['-I', str(include)]
                command += [str(ROOT / 'tests/test_dm32_rx_only_board.c'),
                            str(build / 'rf/fd6818/fd6818.c'), str(ROOT / 'src/firmware/fd6818_setup_b.c'),
                            str(RF / 'drivers/rf/subaudio/subaudio.c'), '-o', str(binary)]
                result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                result = subprocess.run([str(binary)], cwd=ROOT, text=True, capture_output=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn('interlock checks passed', result.stdout)


if __name__ == '__main__':
    unittest.main()
