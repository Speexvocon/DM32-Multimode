"""The downloadable applet kit must be reproducible on Windows and Linux."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('applet_kit', ROOT / 'scripts/package-applet-builder.py')
kit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kit)


class BuilderKitTest(unittest.TestCase):
    def test_windows_and_unix_produce_identical_artifacts(self):
        with patch.object(zipfile.sys, 'platform', 'win32'):
            windows = kit.artifacts()
        with patch.object(zipfile.sys, 'platform', 'linux'):
            linux = kit.artifacts()
        self.assertEqual(windows, linux)
        with zipfile.ZipFile(io.BytesIO(windows['applet-builder.zip'])) as archive:
            for item in archive.infolist():
                self.assertEqual(item.create_system, 3)
                self.assertEqual(item.compress_type, zipfile.ZIP_STORED)
                self.assertEqual(item.date_time, (2026, 1, 1, 0, 0, 0))

    def test_archive_contains_exact_public_compiler_examples_and_manifest_hashes(self):
        outputs = kit.artifacts()
        manifest = json.loads(outputs['builder.json'])
        self.assertEqual(hashlib.sha256(outputs['applet-builder.zip']).hexdigest(), manifest['archive_sha256'])
        with zipfile.ZipFile(io.BytesIO(outputs['applet-builder.zip'])) as archive:
            self.assertEqual(set(archive.namelist()), {
                'tools/dm32-applet.py', 'tools/dm32_applet.py', 'README.md', 'AGENT_GUIDE.md', 'LICENSE',
                'examples/counter.dappsrc', 'examples/counter.dapp',
                'examples/same-watch.dappsrc', 'examples/same-watch.dapp',
            })
            for name, wanted in manifest['files'].items():
                self.assertEqual(hashlib.sha256(archive.read(name)).hexdigest(), wanted)
            self.assertEqual(archive.read('tools/dm32_applet.py'), kit.text_bytes(ROOT / 'scripts/dm32_applet.py'))
            self.assertEqual(archive.read('README.md'), kit.text_bytes(kit.DEST / 'README.md'))
            self.assertIn(b'GNU GENERAL PUBLIC LICENSE', archive.read('LICENSE'))
            self.assertIn(b'Version 3, 29 June 2007', archive.read('LICENSE'))


if __name__ == '__main__':
    unittest.main()
