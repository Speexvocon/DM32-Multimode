# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline software-return evidence: wrapping clocks, epochs and log ambiguity."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts/analyze-p25-control-return.py'
SPEC = importlib.util.spec_from_file_location('return_analysis', SCRIPT)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def values(**changes):
    record = dict(version=1, sequence=1, action=5, kind='voice', flags=63,
                  off_us=1000, begin_us=1100, rx_us=3400, irq_us=3500,
                  control_us=4200, ready_us=3600, old_epoch=7, rx_epoch=9)
    record.update(changes)
    return record


def wire(**changes):
    return 'TRUNK_RETURN ' + ' '.join(key + '=' + str(value) for key, value in values(**changes).items())


class ReturnAnalysis(unittest.TestCase):
    def result(self, text=None, **changes):
        return M.analyze_text(wire(**changes) if text is None else text)['observations'][0]

    def test_completed_voice_measures_software_intervals_only(self):
        result = M.analyze_text(wire())
        item = result['observations'][0]
        self.assertEqual(item['elapsed_us'], dict(
            off_to_begin_us=100, off_to_rx_enabled_us=2400, off_to_first_irq_us=2500,
            off_to_ready_us=2600, off_to_first_control_crc_us=3200,
            rx_enabled_to_first_irq_us=100, first_irq_to_first_control_crc_us=700))
        self.assertTrue(item['complete'])
        self.assertEqual(item['epochs'], dict(old=7, receive=9))
        self.assertTrue(result['offline_only'])
        self.assertTrue(result['software_intervals_only'])
        for key in ('physical_rf_off_qualified', 'earliest_receive_readiness_qualified',
                    'calibrated_clock_rate_qualified', 'rf_timing_qualified', 'access_slot_timing_qualified'):
            self.assertFalse(result[key])
            self.assertFalse(item[key])
        self.assertTrue(item['first_crc_includes_wait_for_complete_control_frame'])

    def test_first_control_crc_can_precede_backend_ready(self):
        item = self.result(kind='request', control_us=3550)
        self.assertTrue(item['complete'])
        self.assertEqual(item['elapsed_us']['first_irq_to_first_control_crc_us'], 50)
        self.assertEqual(item['elapsed_us']['off_to_ready_us'], 2600)

    def test_uint32_wrap_preserves_small_causal_intervals(self):
        item = self.result(off_us=0xffffff00, begin_us=0xffffff80, rx_us=0,
                           irq_us=0x40, ready_us=0x80, control_us=0x90,
                           old_epoch=0xffffffff, rx_epoch=1)
        self.assertEqual(item['elapsed_us']['off_to_rx_enabled_us'], 256)
        self.assertEqual(item['elapsed_us']['off_to_ready_us'], 384)
        self.assertEqual(item['elapsed_us']['off_to_first_control_crc_us'], 400)

    def test_zero_is_a_real_timestamp_when_its_flag_is_set(self):
        item = self.result(off_us=0, begin_us=0, rx_us=0, irq_us=1, control_us=2, ready_us=3)
        self.assertEqual(item['elapsed_us']['off_to_rx_enabled_us'], 0)
        self.assertEqual(item['elapsed_us']['off_to_ready_us'], 3)
        self.assertIn('rx_us', item['timestamps_us'])

    def test_failed_partial_trace_keeps_only_observed_milestones(self):
        item = self.result(flags=1|2|64, rx_epoch=0, rx_us=0xffffffff, irq_us=0xffffffff)
        self.assertTrue(item['failed'])
        self.assertFalse(item['complete'])
        self.assertEqual(item['elapsed_us'], {'off_to_begin_us': 100})
        self.assertEqual(set(item['timestamps_us']), {'off_us', 'begin_us'})
        self.assertIsNone(item['epochs']['receive'])
        self.assertNotIn('completed_software_off_to_ready_us_by_kind', M.analyze_text(wire(flags=65, rx_epoch=0))['summary'])

    def test_ready_and_first_crc_are_independent_observations(self):
        self.assertEqual(self.result(flags=47)['state'], 'ready_observed_waiting_crc')
        self.assertEqual(self.result(flags=31)['state'], 'control_observed_waiting_ready')
        self.assertFalse(self.result(flags=47)['complete'])

    def test_absent_initial_record_has_no_timing(self):
        item = self.result(sequence=0, action=0, flags=0, old_epoch=0, rx_epoch=0)
        self.assertEqual(item['state'], 'absent')
        self.assertEqual(item['elapsed_us'], {})
        self.assertFalse(item['complete'])
        for changes in (dict(sequence=0, action=1, flags=0), dict(sequence=0, action=0, flags=1),
                        dict(sequence=1, action=0)):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                M.analyze_text(wire(**changes))

    def test_admitted_preparation_and_pre_off_failure_are_not_absence(self):
        for flags, state in ((0, 'armed_no_off_marker'), (64, 'failed_before_off_marker')):
            with self.subTest(flags=flags):
                item = self.result(flags=flags, rx_epoch=0)
                self.assertEqual(item['sequence'], 1)
                self.assertEqual(item['action'], 5)
                self.assertEqual(item['state'], state)
                self.assertEqual(item['elapsed_us'], {})
                self.assertEqual(item['timestamps_us'], {})
                self.assertEqual(item['failed'], bool(flags & 64))
                self.assertFalse(item['complete'])
        failed = M.analyze_text(wire(flags=0, rx_epoch=0)+'\n'+wire(flags=64, rx_epoch=0))
        self.assertEqual(failed['observations'][0]['state'], 'failed_before_off_marker')
        self.assertEqual(failed['observations'][0]['snapshots'], 2)
        for changes in (dict(flags=2, rx_epoch=0), dict(flags=64|2, rx_epoch=0),
                        dict(flags=0, old_epoch=0, rx_epoch=0), dict(flags=64, rx_epoch=7)):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                M.analyze_text(wire(**changes))

    def test_epoch_mismatch_or_missing_epoch_is_refused(self):
        for changes in (dict(old_epoch=0), dict(rx_epoch=0), dict(rx_epoch=7),
                        dict(flags=3, rx_epoch=9)):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                M.analyze_text(wire(**changes))

    def test_invalid_prefix_and_crc_before_irq_are_refused(self):
        for changes in (dict(flags=5), dict(flags=1|2|4|16), dict(flags=1|2|4|32),
                        dict(control_us=3499), dict(ready_us=3499)):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                M.analyze_text(wire(**changes))

    def test_ambiguous_and_reversed_clock_intervals_are_refused(self):
        for changes in (dict(begin_us=999), dict(rx_us=1050),
                        dict(ready_us=1000+(1<<31)), dict(control_us=1000+(1<<31)+1)):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                M.analyze_text(wire(**changes))

    def test_schema_numbers_and_field_errors_are_refused(self):
        bad = [wire(version=2), wire(kind='receive'), wire(flags=127|128),
               wire(sequence=-1), wire(action=1<<32), wire(off_us='1.5'),
               wire(flags='0x3f'), wire().replace('version=1', 'version=1 version=1'),
               wire()+' unexpected=1', wire().replace(' ready_us=3600', ''),
               wire().replace(' rx_us=3400', ' rx_us'), 'TRUNK_RETURN_bad version=1']
        for line in bad:
            with self.subTest(line=line), self.assertRaises(ValueError):
                M.analyze_text(line)

    def test_consistent_progressive_snapshots_and_duplicates_collapse(self):
        rows = [wire(flags=1, rx_epoch=0), wire(flags=3, rx_epoch=0),
                wire(flags=7), wire(flags=15), wire(flags=31), wire(), wire()]
        report = M.analyze_text('\n'.join(rows))
        self.assertEqual(report['summary']['traces'], 1)
        self.assertEqual(report['input_timing_observations'], 7)
        self.assertEqual(report['observations'][0]['snapshots'], 7)
        self.assertTrue(report['observations'][0]['complete'])

    def test_conflicting_reused_sequences_or_terminal_mutation_are_refused(self):
        pairs = [(wire(), wire(control_us=4300)), (wire(), wire(action=6)),
                 (wire(), wire(kind='request')), (wire(), wire(old_epoch=8)),
                 (wire(), wire(rx_epoch=10)), (wire(), wire(flags=31)),
                 (wire(flags=79), wire(flags=127))]
        for before, after in pairs:
            with self.subTest(after=after), self.assertRaises(ValueError):
                M.analyze_text(before+'\n'+after)

    def test_text_json_and_ndjson_logs_have_identical_evidence(self):
        expected = M.analyze_text(wire())['observations']
        formats = ['noise\r\n'+wire()+'\r\nOK\r\n',
                   json.dumps({'epoch': 123, 'rows': ['TRUNK enabled=1', wire()]}),
                   json.dumps({'event': 'ignored'})+'\n'+json.dumps({'rows': [wire()]}),
                   '\ufeff'+json.dumps({'rows': [wire()+'\n']}),
                   json.dumps({'rows': [wire(flags=15)]})+'\n'+json.dumps({'rows': [wire()]})]
        for text in formats:
            with self.subTest(text=text):
                actual = M.analyze_text(text)['observations']
                self.assertEqual(actual[0]['elapsed_us'], expected[0]['elapsed_us'])
                self.assertEqual(actual[0]['state'], 'complete')

    def test_invalid_log_containers_missing_trace_and_bounds(self):
        for text in ('STATUS\nOK', '{}', '[]', '{"rows":42}', '{"rows":[5]}',
                     '{"rows":[]}\n{', '{"rows":[]', 'x'*(M.MAX_INPUT_BYTES+1)):
            with self.subTest(text=text[:60]), self.assertRaises(ValueError):
                M.analyze_text(text)

    def test_multiple_traces_are_separate_and_sequence_selection_is_explicit(self):
        log = wire()+'\n'+wire(sequence=2, action=8, kind='request', ready_us=4000)
        report = M.analyze_text(log)
        self.assertEqual([row['sequence'] for row in report['observations']], [1, 2])
        self.assertEqual(report['summary']['completed_software_off_to_ready_us_by_kind'],
                         dict(voice=dict(count=1, minimum=2600, median=2600, maximum=2600),
                              request=dict(count=1, minimum=3000, median=3000, maximum=3000)))
        selected = M.analyze_text(log, sequence=2)
        self.assertEqual(selected['observations'][0]['action'], 8)
        for sequence in (0, 3, -1, 1<<32, True):
            with self.subTest(sequence=sequence), self.assertRaises(ValueError):
                M.analyze_text(log, sequence=sequence)

    def test_mixed_kind_summary_never_pools_different_off_anchors(self):
        log = '\n'.join((wire(), wire(sequence=2, action=8, ready_us=3800),
                         wire(sequence=3, action=9, kind='request', ready_us=4500)))
        summary = M.analyze_text(log)['summary']
        self.assertNotIn('completed_software_off_to_ready_us', summary)
        self.assertEqual(summary['completed_software_off_to_ready_us_by_kind'],
                         dict(voice=dict(count=2, minimum=2600, median=2700, maximum=2800),
                              request=dict(count=1, minimum=3500, median=3500, maximum=3500)))

    def test_cli_preserves_input_and_does_not_overwrite_reports(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            source, output = folder/'serial.ndjson', folder/'timing.json'
            source.write_text(json.dumps({'rows': [wire()]}), encoding='utf-8')
            original = source.read_bytes()
            run = subprocess.run([sys.executable, '-B', str(SCRIPT), str(source), '--output', str(output)],
                                 capture_output=True, text=True, timeout=10)
            self.assertEqual(run.returncode, 0, run.stderr)
            report = json.loads(output.read_text())
            self.assertEqual(report['input_sha256'], hashlib.sha256(original).hexdigest())
            self.assertEqual(report['observations'][0]['elapsed_us']['off_to_ready_us'], 2600)
            self.assertEqual(source.read_bytes(), original)
            result_bytes = output.read_bytes()
            for destination in (source, output):
                run = subprocess.run([sys.executable, '-B', str(SCRIPT), str(source), '--output', str(destination)],
                                     capture_output=True, text=True, timeout=10)
                self.assertNotEqual(run.returncode, 0)
            self.assertEqual(source.read_bytes(), original)
            self.assertEqual(output.read_bytes(), result_bytes)


if __name__ == '__main__':
    unittest.main()
