"""Expose the pinned DM32's native prompt-PCM FM modulation route.

The original APRS hook is private and CONFIG_APRS-guarded. This generated
translation unit adds a narrowly scoped entry point using the same board state,
microphone mute and prompt routing. Prepare keeps the PA off while the caller
primes the FIFO; key is a separate, explicit guarded operation.
Optional RF-B composition always starts from the exact reviewed classic pin.
The dedicated Omaha receiver also rejects TX at the actual board entry points,
independently of the controller, codeplug, PTT policy and serial commands.
"""
import argparse
import hashlib
import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PINNED_SHA256='5c9fc8a0b1a411dc57afa1b7325661b315cef23abe07e3d889546702dc10a2e7'
EXTENSION='''
// Generated native PCM extension. Caller exclusively owns FM TX and its guard.
// This follows the DM32 APRS route; the prompt FIFO reaches this board's FM
// modulator directly. No mixer loopback: that is a different board's route.
bool dm32_pcm_fm_route(bool on)
{
    if (on && (DM32_OMAHA_RX_ONLY || !transmitting || mode != RADIO_MODE_FM)) {
        return false;
    }
    afsk_tx = on;
    hrc7000_codec_mute(&modem, on, false);
    ring_play();
    return true;
}

// This is the native calibrated FM preparation with the PA and microphone
// path held off. The caller arms its independent guard before preparing,
// primes the prompt FIFO, then explicitly keys under the same ownership.
bool dm32_pcm_fm_prepare(uint32_t hz, bool wide, uint8_t power)
{
#if DM32_OMAHA_RX_ONLY
    pa_off();
    return false;
#endif
    if (mode != RADIO_MODE_FM || transmitting || pcm_preparing || pcm_prepared) {
        return false;
    }
    pa_off();
    pcm_preparing = true;
    bool ok = tx(hz, wide ? RADIO_BW_25K : RADIO_BW_12K5, power, NULL);
    pcm_preparing = false;
    if (!ok) {
        return false;
    }
    if (!dm32_pcm_fm_route(true)) {
        tx_off();
        return false;
    }
    pcm_prepared = true;
    return true;
}

bool dm32_pcm_fm_key(void)
{
#if DM32_OMAHA_RX_ONLY
    pa_off();
    return false;
#endif
    if (!pcm_prepared || pcm_preparing || !transmitting || mode != RADIO_MODE_FM || !afsk_tx) {
        return false;
    }
    pcm_prepared = false; // A prepare grants exactly one key operation.
    pa_key();
    return true;
}
'''


def generate(text,experimental_rf_b=False):
    text=text.replace('\r\n','\n')
    if hashlib.sha256(text.encode()).hexdigest()!=PINNED_SHA256:
        raise ValueError('PCM radio input does not match the reviewed DM32 source pin')
    if experimental_rf_b:
        spec=importlib.util.spec_from_file_location('pcm_rf_board',ROOT/'scripts/generate-rf-board-backport.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        text=module.generate(text)
    def replace(old,new):
        nonlocal text
        if text.count(old)!=1:
            raise ValueError('Pinned PCM board anchor is absent or ambiguous: '+old[:60])
        text=text.replace(old,new,1)
    replace('static hrc7000_t modem;',
            'static hrc7000_t modem;\nstatic bool pcm_preparing, pcm_prepared;')
    replace('static void init(void)\n{',
            'static void init(void)\n{\n\tpcm_preparing = pcm_prepared = false;')
    replace('static bool tx(uint32_t hz, radio_bw_t bw, uint8_t power, const subtone_t *tone)\n{',
            'static bool tx(uint32_t hz, radio_bw_t bw, uint8_t power, const subtone_t *tone)\n{\n'
            '\tpcm_prepared = false;\n'
            '#if DM32_OMAHA_RX_ONLY\n'
            '\t// Fixed receiver build: fail before retune, modulation or PA setup.\n'
            '\tpa_off();\n\tdmr_keyed = false;\n\ttransmitting = false;\n\treturn false;\n'
            '#endif')
    replace('\t\thrc_pin_write(PIN_MIC_PATH, true);',
            '\t\thrc_pin_write(PIN_MIC_PATH, !pcm_preparing);')
    replace('\t\tpa_key();\n\t}\n\ttransmitting = true;',
            '\t\tif (!pcm_preparing) pa_key();\n\t}\n\ttransmitting = true;')
    replace('static void tx_off(void)\n{',
            'static void tx_off(void)\n{\n\tpcm_prepared = false;')
    # These native hooks are also called directly by the P25 RF ISR. Denying
    # only radio.tx() would leave stale IRQ state capable of keying the board.
    replace('static void pa_key(void)\n{',
            'static void pa_key(void)\n{\n#if DM32_OMAHA_RX_ONLY\n'
            '\tpa_off();\n\treturn;\n#endif')
    replace('static void dmr_rf_switch(bool tx)\n{',
            'static void dmr_rf_switch(bool tx)\n{\n#if DM32_OMAHA_RX_ONLY\n'
            '\tif (tx) { pa_off(); return; }\n#endif')
    replace('static void dmr_pa_on(void)\n{',
            'static void dmr_pa_on(void)\n{\n#if DM32_OMAHA_RX_ONLY\n'
            '\tpa_off();\n\treturn;\n#endif')
    # Optional tone/APRS senders must remain denied even with stale caller
    # flags. Their false/off cleanup and all receiver audio paths still work.
    replace('if (on && (!transmitting || mode != RADIO_MODE_FM))',
            'if (on && (DM32_OMAHA_RX_ONLY || !transmitting || mode != RADIO_MODE_FM))')
    text=text.replace('if (!transmitting || mode != RADIO_MODE_FM',
                      'if (DM32_OMAHA_RX_ONLY || !transmitting || mode != RADIO_MODE_FM')
    anchor='#include "radio/ref_trim.h"'
    if text.count(anchor)!=1:
        raise ValueError('PCM radio include anchor is absent or ambiguous')
    text=text.replace(anchor,anchor+'\n#include "radio_pcm_fm_tx.h"\n'
                      '// Compile-time board interlock; no menu or serial override.\n'
                      '#ifndef DM32_OMAHA_RX_ONLY\n#define DM32_OMAHA_RX_ONLY 0\n#endif\n'
                      '#if DM32_OMAHA_RX_ONLY != 0 && DM32_OMAHA_RX_ONLY != 1\n'
                      '#error "DM32_OMAHA_RX_ONLY must be 0 or 1"\n#endif\n'
                      '// Retain with --undefined for the post-link profile audit.\n'
                      'const uint32_t dm32_omaha_tx_blocked = DM32_OMAHA_RX_ONLY;',1)
    return text.rstrip()+'\n'+EXTENSION


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--experimental-rf-b',action='store_true')
    args=parser.parse_args()
    output=args.output.resolve()
    if not output.is_relative_to((ROOT/'build').resolve()):
        parser.error('generated sources must remain under the ignored project build directory')
    result=generate(args.source.read_text(),args.experimental_rf_b)
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(result,newline='\n')


if __name__=='__main__':main()
