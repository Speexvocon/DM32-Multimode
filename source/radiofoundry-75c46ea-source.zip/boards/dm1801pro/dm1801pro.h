// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// Internal interfaces between the DM-1801 Pro board files
#ifndef DM1801PRO_H
#define DM1801PRO_H

#include <stdint.h>
#include <stdbool.h>
#include "board.h"
#include "dmr_glue.h"
#include "audio_pcm.h"
#include "vocoder.h"
#include "rf/fd6818/fd6818.h"

// Ops each board file provides
extern const hal_display_t dm1801pro_display;
extern const hal_input_t dm1801pro_input;
extern const hal_radio_t dm1801pro_radio;
extern const hal_power_t dm1801pro_power;
// The FD6818 set-up tables (rf_tables_dm1801pro.c, hardware-dm1801pro.md 5)
extern const fd6818_variant_t fd6818_variant_dm1801pro;

// Physical key bits returned by dm1801pro_input.scan(); the matrix positions and the four direct pins are in
// input_dm1801pro.c (hardware-dm1801pro.md 9.1)
enum {
	KEY_0, KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6, KEY_7, KEY_8, KEY_9,
	KEY_STAR, KEY_HASH, KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_MENU, KEY_BACK, KEY_VFO_MR, KEY_AB,
	KEY_SK1, KEY_SK2, KEY_SOS, KEY_PTT,
	KEY_COUNT
};

// Raw key state for the diagnostics page: matrix keys as a bit per strobe * 4 + input, the direct pins in bits 20-23
uint32_t dm1801pro_key_raw(void);
// Key scans with the PTT pin low that were ignored as host serial data (hardware-dm1801pro.md 9.1)
uint32_t dm1801pro_input_ptt_ignored(void);

uint16_t dm1801pro_battery_raw(void);	// the last ADC channel C reading

// --- Radio (radio_dm1801pro.c) ---
typedef struct {
	uint16_t rssi_raw, noise_raw;	// FD6818 0x67 / 0x65 from the last status poll
	uint16_t fm_noise;		// HR_C7000 FM_SQL
	uint32_t rf_writes;
	uint32_t c7_audio, c7_rf_mode;	// HR_C7000 AUDIO_CONTROL and RF_MODE, read now
	uint8_t c7_work_mode, c7_fm_ptt;	// WORK_MODE, FM_PTT b0
	uint32_t pa_hz;			// the last TX frequency, or the RX frequency before the first transmission
	uint16_t pa_drive;		// the DAC B drive of the last transmission, 0 before the first
} dm1801pro_radio_diag_t;
void dm1801pro_radio_diag(dm1801pro_radio_diag_t *d);
// DAC B drive for a TX frequency and power level 0..2 (L, M, H; above 2 is H) from the factory calibration, as tx()
// uses it; 0 without calibration (hardware-dm1801pro.md 6.4)
uint16_t dm1801pro_pa_drive(uint32_t hz, uint8_t power);
uint8_t dm1801pro_codec_byte(uint8_t reg);	// the HR_C7000's internal codec, byte registers 0x00-0x3F
// DMR PCM to the speaker instead of the FM path (the speaker_pcm hook of hrc_audio_pcm)
void dm1801pro_speaker_pcm(bool on);
// The speaker amplifier (PTA16) is on while any user wants it: the channel audio, the broadcast tuner, speaker PCM
#define DM1801PRO_AMP_RADIO	0x01u
#define DM1801PRO_AMP_BCAST	0x02u
#define DM1801PRO_AMP_PCM	0x04u
void dm1801pro_amp(uint8_t who, bool on);

// --- Accelerometer (accel_dm1801pro.c, CONFIG_DIAG): milli-g on x, y, z; false when the chip doesn't answer ---
bool dm1801pro_accel_read(int16_t mg[3]);
int16_t dm1801pro_accel_id(void);	// WHO_AM_I, -1 = no acknowledge

// --- Diagnostics (diag_dm1801pro.c) ---
bool dm1801pro_diag_line(uint8_t i, char *buf, uint8_t len);
void dm1801pro_diag_reset(void);

#endif
